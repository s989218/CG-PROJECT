package fms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
//@EnableResourceServer
@SpringBootApplication
public class FMSMain extends WebSecurityConfigurerAdapter  {

	/***
	 * @param args
	 */
	public static void main(String[] args) throws InterruptedException  {
		SpringApplication.run(FMSMain.class, args);
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
		.antMatcher("/**")
			.authorizeRequests()
				.anyRequest().permitAll()
		.and()
			.formLogin().disable()
			.csrf().disable();
	}  
	

//  	public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
//		resources.resourceId("openid");
//	}

}