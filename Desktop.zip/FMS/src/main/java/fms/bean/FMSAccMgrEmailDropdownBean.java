package fms.bean;

import java.io.Serializable;

public class FMSAccMgrEmailDropdownBean implements Serializable {
	
	private static final long serialVersionUID = -130890036803647618L;
	private String cAccountMgrEmail;
	public String getcAccountMgrEmail() {
		return cAccountMgrEmail;
	}
	public void setcAccountMgrEmail(String cAccountMgrEmail) {
		this.cAccountMgrEmail = cAccountMgrEmail;
	}
	
	
	

}
