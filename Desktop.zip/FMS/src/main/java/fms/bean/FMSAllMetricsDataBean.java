package fms.bean;

import java.io.Serializable;

public class FMSAllMetricsDataBean implements Serializable {

	private static final long serialVersionUID = 2069061748396484839L;
	private String allMetricsDataRegion;
	private String allMetricsDataYear;
	private String allMetricsDataQuarter;
	private String coverageValue;
	private String penetrationValue;
	private String fleetPenF2FValue;
	private String caloricIndexValue;
	private String conversionIndexValue;
	private String dollarByIBValue;
	private String iboByRegionValue;
	private String revDollarByRegionValue;

	public String getAllMetricsDataRegion() {
		return allMetricsDataRegion;
	}

	public void setAllMetricsDataRegion(String allMetricsDataRegion) {
		this.allMetricsDataRegion = allMetricsDataRegion;
	}

	public String getAllMetricsDataYear() {
		return allMetricsDataYear;
	}

	public void setAllMetricsDataYear(String allMetricsDataYear) {
		this.allMetricsDataYear = allMetricsDataYear;
	}

	public String getAllMetricsDataQuarter() {
		return allMetricsDataQuarter;
	}

	public void setAllMetricsDataQuarter(String allMetricsDataQuarter) {
		this.allMetricsDataQuarter = allMetricsDataQuarter;
	}

	public String getCoverageValue() {
		return coverageValue;
	}

	public void setCoverageValue(String coverageValue) {
		this.coverageValue = coverageValue;
	}

	public String getPenetrationValue() {
		return penetrationValue;
	}

	public void setPenetrationValue(String penetrationValue) {
		this.penetrationValue = penetrationValue;
	}

	public String getFleetPenF2FValue() {
		return fleetPenF2FValue;
	}

	public void setFleetPenF2FValue(String fleetPenF2FValue) {
		this.fleetPenF2FValue = fleetPenF2FValue;
	}

	public String getCaloricIndexValue() {
		return caloricIndexValue;
	}

	public void setCaloricIndexValue(String caloricIndexValue) {
		this.caloricIndexValue = caloricIndexValue;
	}

	public String getConversionIndexValue() {
		return conversionIndexValue;
	}

	public void setConversionIndexValue(String conversionIndexValue) {
		this.conversionIndexValue = conversionIndexValue;
	}

	public String getDollarByIBValue() {
		return dollarByIBValue;
	}

	public void setDollarByIBValue(String dollarByIBValue) {
		this.dollarByIBValue = dollarByIBValue;
	}

	public String getIboByRegionValue() {
		return iboByRegionValue;
	}

	public void setIboByRegionValue(String iboByRegionValue) {
		this.iboByRegionValue = iboByRegionValue;
	}

	public String getRevDollarByRegionValue() {
		return revDollarByRegionValue;
	}

	public void setRevDollarByRegionValue(String revDollarByRegionValue) {
		this.revDollarByRegionValue = revDollarByRegionValue;
	}

}
