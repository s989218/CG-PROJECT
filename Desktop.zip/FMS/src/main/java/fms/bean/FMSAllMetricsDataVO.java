package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSAllMetricsDataVO implements Serializable {
	
	private static final long serialVersionUID = -3932175163398839631L;
	private List<FMSAllMetricsDataBean> hisMetricsdata;
	private List<FMSAllMetricsDataBean> curMetricsdata;
	public List<FMSAllMetricsDataBean> getHisMetricsdata() {
		return hisMetricsdata;
	}
	public void setHisMetricsdata(List<FMSAllMetricsDataBean> hisMetricsdata) {
		this.hisMetricsdata = hisMetricsdata;
	}
	public List<FMSAllMetricsDataBean> getCurMetricsdata() {
		return curMetricsdata;
	}
	public void setCurMetricsdata(List<FMSAllMetricsDataBean> curMetricsdata) {
		this.curMetricsdata = curMetricsdata;
	}

}
