package fms.bean;

import java.io.Serializable;
import java.util.Map;

public class FMSAllMetricsDetailsVO implements Serializable {

	private static final long serialVersionUID = 299238602401775994L;
	private transient Map<String, Object> averageBasedOnYear;
	private transient Map<String, Object> historyData;
	private transient Map<String, Object> currentData;
	private transient Map<String, Object> averageData;



	public Map<String, Object> getHistoryData() {
		return historyData;
	}
	public void setHistoryData(Map<String, Object> historyData) {
		this.historyData = historyData;
	}
	public Map<String, Object> getCurrentData() {
		return currentData;
	}
	public void setCurrentData(Map<String, Object> currentData) {
		this.currentData = currentData;
	}
	public Map<String, Object> getAverageData() {
		return averageData;
	}
	public void setAverageData(Map<String, Object> averageData) {
		this.averageData = averageData;
	}
	public Map<String, Object> getAverageBasedOnYear() {
		return averageBasedOnYear;
	}
	public void setAverageBasedOnYear(Map<String, Object> averageBasedOnYear) {
		this.averageBasedOnYear = averageBasedOnYear;
	}
}
