package fms.bean;

import java.io.Serializable;

public class FMSAverageCalcDTO implements Serializable{

	private static final long serialVersionUID = 6385590523213383198L;

	private String region;
	private String average;
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getAverage() {
		return average;
	}
	public void setAverage(String average) {
		this.average = average;
	}
	
}
