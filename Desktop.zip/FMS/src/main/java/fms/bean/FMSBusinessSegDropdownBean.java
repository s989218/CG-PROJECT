package fms.bean;

import java.io.Serializable;

public class FMSBusinessSegDropdownBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6328436676406076195L;

	private String businessSegmentFilter;

	public String getBusinessSegmentFilter() {
		return businessSegmentFilter;
	}

	public void setBusinessSegmentFilter(String businessSegmentFilter) {
		this.businessSegmentFilter = businessSegmentFilter;
	}
}
