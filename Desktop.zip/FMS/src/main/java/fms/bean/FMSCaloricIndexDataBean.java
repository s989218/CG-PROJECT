package fms.bean;

import java.io.Serializable;

public class FMSCaloricIndexDataBean implements Serializable {

	private static final long serialVersionUID = 2249280917783806278L;
	private String calIndexDataRegion;  
	private String calIndexDataYear;
	private String calIndexDataQuarter;
	private String caloricIndexValue;
	
	public String getCalIndexDataRegion() {
		return calIndexDataRegion;
	}
	public void setCalIndexDataRegion(String calIndexDataRegion) {
		this.calIndexDataRegion = calIndexDataRegion;
	}
	public String getCalIndexDataYear() {
		return calIndexDataYear;
	}
	public void setCalIndexDataYear(String calIndexDataYear) {
		this.calIndexDataYear = calIndexDataYear;
	}
	public String getCalIndexDataQuarter() {
		return calIndexDataQuarter;
	}
	public void setCalIndexDataQuarter(String calIndexDataQuarter) {
		this.calIndexDataQuarter = calIndexDataQuarter;
	}
	public String getCaloricIndexValue() {
		return caloricIndexValue;
	}
	public void setCaloricIndexValue(String caloricIndexValue) {
		this.caloricIndexValue = caloricIndexValue;
	}
}
