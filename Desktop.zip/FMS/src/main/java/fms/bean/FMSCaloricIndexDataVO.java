package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSCaloricIndexDataVO implements Serializable {

	private static final long serialVersionUID = 3021716018832955827L;
	private List<FMSCaloricIndexDataBean> caloricIndexCurrentData;
	private List<FMSCaloricIndexDataBean> caloricIndexHistoryData;
	public List<FMSCaloricIndexDataBean> getCaloricIndexCurrentData() {
		return caloricIndexCurrentData;
	}
	public void setCaloricIndexCurrentData(
			List<FMSCaloricIndexDataBean> caloricIndexCurrentData) {
		this.caloricIndexCurrentData = caloricIndexCurrentData;
	}
	public List<FMSCaloricIndexDataBean> getCaloricIndexHistoryData() {
		return caloricIndexHistoryData;
	}
	public void setCaloricIndexHistoryData(
			List<FMSCaloricIndexDataBean> caloricIndexHistoryData) {
		this.caloricIndexHistoryData = caloricIndexHistoryData;
	}
	
	
}
