package fms.bean;

import java.io.Serializable;

public class FMSConversionIndexDataBean implements Serializable {

	private static final long serialVersionUID = 7194238383781474728L;
	private String conversionIndexRegion;  
	private String conversionIndexYear;
	private String conversionIndexQuarter;
	private String conversionIndexValue;
	
	public String getConversionIndexRegion() {
		return conversionIndexRegion;
	}
	public void setConversionIndexRegion(String conversionIndexRegion) {
		this.conversionIndexRegion = conversionIndexRegion;
	}
	public String getConversionIndexYear() {
		return conversionIndexYear;
	}
	public void setConversionIndexYear(String conversionIndexYear) {
		this.conversionIndexYear = conversionIndexYear;
	}
	public String getConversionIndexQuarter() {
		return conversionIndexQuarter;
	}
	public void setConversionIndexQuarter(String conversionIndexQuarter) {
		this.conversionIndexQuarter = conversionIndexQuarter;
	}
	public String getConversionIndexValue() {
		return conversionIndexValue;
	}
	public void setConversionIndexValue(String conversionIndexValue) {
		this.conversionIndexValue = conversionIndexValue;
	}
	
	
	
}
