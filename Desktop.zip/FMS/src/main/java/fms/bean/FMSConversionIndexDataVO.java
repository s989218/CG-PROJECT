package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSConversionIndexDataVO implements Serializable {

	private static final long serialVersionUID = 2617872046350787400L;
	private List<FMSConversionIndexDataBean> conversionIndexCurrentData;
	private List<FMSConversionIndexDataBean> conversionIndexHistoryData;
	public List<FMSConversionIndexDataBean> getConversionIndexCurrentData() {
		return conversionIndexCurrentData;
	}
	public void setConversionIndexCurrentData(
			List<FMSConversionIndexDataBean> conversionIndexCurrentData) {
		this.conversionIndexCurrentData = conversionIndexCurrentData;
	}
	public List<FMSConversionIndexDataBean> getConversionIndexHistoryData() {
		return conversionIndexHistoryData;
	}
	public void setConversionIndexHistoryData(
			List<FMSConversionIndexDataBean> conversionIndexHistoryData) {
		this.conversionIndexHistoryData = conversionIndexHistoryData;
	}
	
	
}
