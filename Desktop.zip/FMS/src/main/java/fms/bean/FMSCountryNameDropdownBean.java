package fms.bean;

import java.io.Serializable;

public class FMSCountryNameDropdownBean implements Serializable {

	private static final long serialVersionUID = 830900480357580583L;
	private String countryName;

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	
	
}
