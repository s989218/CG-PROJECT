package fms.bean;

import java.io.Serializable;

public class FMSCurrentQuarterDTO implements Serializable{

	private static final long serialVersionUID = -3218631027307319203L;
	private String currentQuarter;
	public String getCurrentQuarter() {
		return currentQuarter;
	}
	public void setCurrentQuarter(String currentQuarter) {
		this.currentQuarter = currentQuarter;
	}
}
