package fms.bean;

import java.io.Serializable;

public class FMSCurrentYearDTO implements Serializable{

	private static final long serialVersionUID = -3218631027307319203L;
	private String yearQtr;
	public String getYearQtr() {
		return yearQtr;
	}
	public void setYearQtr(String yearQtr) {
		this.yearQtr = yearQtr;
	}
	
}
