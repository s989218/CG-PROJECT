package fms.bean;

import java.io.Serializable;

public class FMSCustomerDropdownBean implements Serializable {
	
	private static final long serialVersionUID = 5689487057953572551L;
	private String customerName;

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	

}
