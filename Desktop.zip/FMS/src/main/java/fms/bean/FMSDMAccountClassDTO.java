package fms.bean;

import java.io.Serializable;

public class FMSDMAccountClassDTO implements Serializable{

	private static final long serialVersionUID = -1745437341012970603L;
	private String accountClass;
	public String getAccountClass() {
		return accountClass;
	}
	public void setAccountClass(String accountClass) {
		this.accountClass = accountClass;
	}

}
