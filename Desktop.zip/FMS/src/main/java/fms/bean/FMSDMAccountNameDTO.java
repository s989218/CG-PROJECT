package fms.bean;

import java.io.Serializable;

public class FMSDMAccountNameDTO implements Serializable{

	private static final long serialVersionUID = 277691070351777701L;
	private String accountName;
	
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

}
