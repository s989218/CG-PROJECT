package fms.bean;

import java.io.Serializable;

public class FMSDMAccountTypeDTO implements Serializable{

	private static final long serialVersionUID = -3218631027307319203L;
	private String accountType;
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

}
