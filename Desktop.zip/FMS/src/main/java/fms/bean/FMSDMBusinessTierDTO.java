package fms.bean;

import java.io.Serializable;

public class FMSDMBusinessTierDTO implements Serializable{

	private static final long serialVersionUID = -6260124796706392245L;
	private String businessTier;
	public String getBusinessTier() {
		return businessTier;
	}
	public void setBusinessTier(String businessTier) {
		this.businessTier = businessTier;
	}
}
