package fms.bean;

import java.io.Serializable;

public class FMSDMDataBean implements Serializable {

	private static final long serialVersionUID = 2971889018848295490L;
	
	private String opptyId; 						//  OPPTY_ID
	private String opptyNo; 						//  OPPTY_NUMBER
	private String expectedOrderDate; 				//	EXPECTED_ORDER_DATE
	private int    expectedOrderYear;				//  EXPECTED_ORDER_YEAR
	private int    expectedOrderQuarter;			//  EXPECTED_ORDER_QUARTER
	private String primaryIndustry;					//  PRIMARY_INDUSTRY
	private String projectNumber;					//  PROJECT_NUMBER
	private int    opptyAmountUsd;					//  OPPTY_AMOUNT_USD
	private int    opptyCmUsd;						//  OPPTY_CM_USD
	private String primarySalesName;				//  PRIMARY_SALES_NAME
	private String isComopsNeeded;					//  IS_COMOPS_NEEDED
	private String commAccountName;					//  COMM_ACCOUNT_NAME
	private String endUserAccountDuns;				//  END_USER_ACCOUNT_DUNS
	private String dealRiskLevel;					//  DEAL_RISK_LEVEL
	private String dealQuoteType;					//  DEAL_QUOTE_TYPE
	private String rfqReceivedDate;					//  RFQ_RECEIVED_DATE
	private String bidDueDate;						//  BID_DUE_DATE
	private String expectedDeliveryDate;			//  EXPECTED_DELIVERY_DATE
	private String bidSentDate;						//  BID_SENT_DATE
	private String dispPrimaryReason;				//  DISP_PRIMARY_REASON
	private String repBusinessTier3;				//  REP_BUSINESS_TIER_3
	private String repBusinessTier4;				//  REP_BUSINESS_TIER_4
	private String projectFlowType;					//  PROJECT_FLOW_TYPE
	private String createdByName;					//  CREATED_BY_NAME
	private String createdDate;						//  CREATED_DATE
	private String staleDealIndicator;				//  STALE_DEAL_INDICATOR
	private String dealUnsolicitedType;				//  DEAL_UNSOLICITED_TYPE
	private String forecastCategory;				//  FORECAST_CATEGORY
	private String businessTier3;					//  BUSINESS_TIER_3
	private String primaryCountry;					//  PRIMARY_COUNTRY
	private String primaryRegion;					//  PRIMARY_REGION
	private String convertibleThisQtr;			    //  CONVERTIBLE_THIS_QTR
	private String endUserAccountName;				//  END_USER_ACCOUNT_NAME
	private String dealRiskPath;					//  DEAL_RISK_PATH
	private String globalAccountClass;				//  GLOBAL_ACCOUNT_CLASS
	private String globalAccountType;				//  GLOBAL_ACCOUNT_TYPE
	private String recordTypeId;					//  RECORDTYPE_ID
	private String opptyName;						//  OPPTY_NAME
	private String opptySalesStage;					//  PPTY_SALES_STAGE
	private String lastSalesStageChanged;			//  LAST_SALES_STAGE_CHANGED		
	private String projectName;						//  PROJECT_NAME
	private String primarySalesId;					//  PRIMARY_SALES_ID
	private String repBizAbbrTier4;					//  REP_BIZ_ABBR_TIER_4
	private String dealBudgetaryType;				//  DEAL_BUDGETARY_TYPE
	private String opptyExternalId;
	

	public String getOpptyExternalId() {
		return opptyExternalId;
	}
	public void setOpptyExternalId(String opptyExternalId) {
		this.opptyExternalId = opptyExternalId;
	}
	public String getOpptyId() {
		return opptyId;
	}
	public void setOpptyId(String opptyId) {
		this.opptyId = opptyId;
	}
	public String getOpptyNo() {
		return opptyNo;
	}
	public void setOpptyNo(String opptyNo) {
		this.opptyNo = opptyNo;
	}
	public String getExpectedOrderDate() {
		return expectedOrderDate;
	}
	public void setExpectedOrderDate(String expectedOrderDate) {
		this.expectedOrderDate = expectedOrderDate;
	}
	public int getExpectedOrderYear() {
		return expectedOrderYear;
	}
	public void setExpectedOrderYear(int expectedOrderYear) {
		this.expectedOrderYear = expectedOrderYear;
	}
	public int getExpectedOrderQuarter() {
		return expectedOrderQuarter;
	}
	public void setExpectedOrderQuarter(int expectedOrderQuarter) {
		this.expectedOrderQuarter = expectedOrderQuarter;
	}
	public String getPrimaryIndustry() {
		return primaryIndustry;
	}
	public void setPrimaryIndustry(String primaryIndustry) {
		this.primaryIndustry = primaryIndustry;
	}
	public String getProjectNumber() {
		return projectNumber;
	}
	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}
	public int getOpptyAmountUsd() {
		return opptyAmountUsd;
	}
	public void setOpptyAmountUsd(int opptyAmountUsd) {
		this.opptyAmountUsd = opptyAmountUsd;
	}
	public int getOpptyCmUsd() {
		return opptyCmUsd;
	}
	public void setOpptyCmUsd(int opptyCmUsd) {
		this.opptyCmUsd = opptyCmUsd;
	}
	public String getPrimarySalesName() {
		return primarySalesName;
	}
	public void setPrimarySalesName(String primarySalesName) {
		this.primarySalesName = primarySalesName;
	}
	public String getIsComopsNeeded() {
		return isComopsNeeded;
	}
	public void setIsComopsNeeded(String isComopsNeeded) {
		this.isComopsNeeded = isComopsNeeded;
	}
	public String getCommAccountName() {
		return commAccountName;
	}
	public void setCommAccountName(String commAccountName) {
		this.commAccountName = commAccountName;
	}
	public String getEndUserAccountDuns() {
		return endUserAccountDuns;
	}
	public void setEndUserAccountDuns(String endUserAccountDuns) {
		this.endUserAccountDuns = endUserAccountDuns;
	}
	public String getDealRiskLevel() {
		return dealRiskLevel;
	}
	public void setDealRiskLevel(String dealRiskLevel) {
		this.dealRiskLevel = dealRiskLevel;
	}
	public String getDealQuoteType() {
		return dealQuoteType;
	}
	public void setDealQuoteType(String dealQuoteType) {
		this.dealQuoteType = dealQuoteType;
	}
	public String getRfqReceivedDate() {
		return rfqReceivedDate;
	}
	public void setRfqReceivedDate(String rfqReceivedDate) {
		this.rfqReceivedDate = rfqReceivedDate;
	}
	public String getBidDueDate() {
		return bidDueDate;
	}
	public void setBidDueDate(String bidDueDate) {
		this.bidDueDate = bidDueDate;
	}
	public String getExpectedDeliveryDate() {
		return expectedDeliveryDate;
	}
	public void setExpectedDeliveryDate(String expectedDeliveryDate) {
		this.expectedDeliveryDate = expectedDeliveryDate;
	}
	public String getBidSentDate() {
		return bidSentDate;
	}
	public void setBidSentDate(String bidSentDate) {
		this.bidSentDate = bidSentDate;
	}
	public String getDispPrimaryReason() {
		return dispPrimaryReason;
	}
	public void setDispPrimaryReason(String dispPrimaryReason) {
		this.dispPrimaryReason = dispPrimaryReason;
	}
	public String getRepBusinessTier3() {
		return repBusinessTier3;
	}
	public void setRepBusinessTier3(String repBusinessTier3) {
		this.repBusinessTier3 = repBusinessTier3;
	}
	public String getRepBusinessTier4() {
		return repBusinessTier4;
	}
	public void setRepBusinessTier4(String repBusinessTier4) {
		this.repBusinessTier4 = repBusinessTier4;
	}
	public String getProjectFlowType() {
		return projectFlowType;
	}
	public void setProjectFlowType(String projectFlowType) {
		this.projectFlowType = projectFlowType;
	}
	public String getCreatedByName() {
		return createdByName;
	}
	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getStaleDealIndicator() {
		return staleDealIndicator;
	}
	public void setStaleDealIndicator(String staleDealIndicator) {
		this.staleDealIndicator = staleDealIndicator;
	}
	public String getDealUnsolicitedType() {
		return dealUnsolicitedType;
	}
	public void setDealUnsolicitedType(String dealUnsolicitedType) {
		this.dealUnsolicitedType = dealUnsolicitedType;
	}
	public String getForecastCategory() {
		return forecastCategory;
	}
	public void setForecastCategory(String forecastCategory) {
		this.forecastCategory = forecastCategory;
	}
	public String getBusinessTier3() {
		return businessTier3;
	}
	public void setBusinessTier3(String businessTier3) {
		this.businessTier3 = businessTier3;
	}
	public String getPrimaryCountry() {
		return primaryCountry;
	}
	public void setPrimaryCountry(String primaryCountry) {
		this.primaryCountry = primaryCountry;
	}
	public String getPrimaryRegion() {
		return primaryRegion;
	}
	public void setPrimaryRegion(String primaryRegion) {
		this.primaryRegion = primaryRegion;
	}
	public String getConvertibleThisQtr() {
		return convertibleThisQtr;
	}
	public void setConvertibleThisQtr(String convertibleThisQtr) {
		this.convertibleThisQtr = convertibleThisQtr;
	}
	public String getEndUserAccountName() {
		return endUserAccountName;
	}
	public void setEndUserAccountName(String endUserAccountName) {
		this.endUserAccountName = endUserAccountName;
	}
	public String getDealRiskPath() {
		return dealRiskPath;
	}
	public void setDealRiskPath(String dealRiskPath) {
		this.dealRiskPath = dealRiskPath;
	}
	public String getGlobalAccountClass() {
		return globalAccountClass;
	}
	public void setGlobalAccountClass(String globalAccountClass) {
		this.globalAccountClass = globalAccountClass;
	}
	public String getGlobalAccountType() {
		return globalAccountType;
	}
	public void setGlobalAccountType(String globalAccountType) {
		this.globalAccountType = globalAccountType;
	}
	public String getRecordTypeId() {
		return recordTypeId;
	}
	public void setRecordTypeId(String recordTypeId) {
		this.recordTypeId = recordTypeId;
	}
	public String getOpptyName() {
		return opptyName;
	}
	public void setOpptyName(String opptyName) {
		this.opptyName = opptyName;
	}
	public String getOpptySalesStage() {
		return opptySalesStage;
	}
	public void setOpptySalesStage(String opptySalesStage) {
		this.opptySalesStage = opptySalesStage;
	}
	public String getLastSalesStageChanged() {
		return lastSalesStageChanged;
	}
	public void setLastSalesStageChanged(String lastSalesStageChanged) {
		this.lastSalesStageChanged = lastSalesStageChanged;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getPrimarySalesId() {
		return primarySalesId;
	}
	public void setPrimarySalesId(String primarySalesId) {
		this.primarySalesId = primarySalesId;
	}
	public String getRepBizAbbrTier4() {
		return repBizAbbrTier4;
	}
	public void setRepBizAbbrTier4(String repBizAbbrTier4) {
		this.repBizAbbrTier4 = repBizAbbrTier4;
	}
	public String getDealBudgetaryType() {
		return dealBudgetaryType;
	}
	public void setDealBudgetaryType(String dealBudgetaryType) {
		this.dealBudgetaryType = dealBudgetaryType;
	}
}
