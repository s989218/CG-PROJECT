package fms.bean;

import java.io.Serializable;

public class FMSDMFilterDataBean implements Serializable{

	private static final long serialVersionUID = 9145633691159276952L;
	private String fdPrimaryRegion;
	private String fdForecastCategory;
	private String fdBusinessTier3;
	private String fdPrimaryCountry;
	private String fdcQtr;
	private String fdAccountName;
	private String fdRiskPath;
	private String fdAccountClass;
	private String fdAccountType;
	private String fdYear;
	private String fdQuarter;
	private String fdopptyExternalId;
	private String opptySalesStage;
	private String businessSegment;
	private String dmAccountManager;
	private String dmMarketIndustry;
	
	
	public String getDmMarketIndustry() {
		return dmMarketIndustry;
	}
	public void setDmMarketIndustry(String dmMarketIndustry) {
		this.dmMarketIndustry = dmMarketIndustry;
	}
	public String getDmAccountManager() {
		return dmAccountManager;
	}
	public void setDmAccountManager(String dmAccountManager) {
		this.dmAccountManager = dmAccountManager;
	}
	public String getBusinessSegment() {
		return businessSegment;
	}
	public void setBusinessSegment(String businessSegment) {
		this.businessSegment = businessSegment;
	}
	public String getOpptySalesStage() {
		return opptySalesStage;
	}
	public void setOpptySalesStage(String opptySalesStage) {
		this.opptySalesStage = opptySalesStage;
	}
	public String getFdopptyExternalId() {
		return fdopptyExternalId;
	}
	public void setFdopptyExternalId(String fdopptyExternalId) {
		this.fdopptyExternalId = fdopptyExternalId;
	}
	public String getFdPrimaryRegion() {
		return fdPrimaryRegion;
	}
	public void setFdPrimaryRegion(String fdPrimaryRegion) {
		this.fdPrimaryRegion = fdPrimaryRegion;
	}
	public String getFdForecastCategory() {
		return fdForecastCategory;
	}
	public void setFdForecastCategory(String fdForecastCategory) {
		this.fdForecastCategory = fdForecastCategory;
	}
	public String getFdBusinessTier3() {
		return fdBusinessTier3;
	}
	public void setFdBusinessTier3(String fdBusinessTier3) {
		this.fdBusinessTier3 = fdBusinessTier3;
	}
	public String getFdPrimaryCountry() {
		return fdPrimaryCountry;
	}
	public void setFdPrimaryCountry(String fdPrimaryCountry) {
		this.fdPrimaryCountry = fdPrimaryCountry;
	}
	public String getFdcQtr() {
		return fdcQtr;
	}
	public void setFdcQtr(String fdcQtr) {
		this.fdcQtr = fdcQtr;
	}
	public String getFdAccountName() {
		return fdAccountName;
	}
	public void setFdAccountName(String fdAccountName) {
		this.fdAccountName = fdAccountName;
	}
	public String getFdRiskPath() {
		return fdRiskPath;
	}
	public void setFdRiskPath(String fdRiskPath) {
		this.fdRiskPath = fdRiskPath;
	}
	public String getFdAccountClass() {
		return fdAccountClass;
	}
	public void setFdAccountClass(String fdAccountClass) {
		this.fdAccountClass = fdAccountClass;
	}
	public String getFdAccountType() {
		return fdAccountType;
	}
	public void setFdAccountType(String fdAccountType) {
		this.fdAccountType = fdAccountType;
	}
	public String getFdYear() {
		return fdYear;
	}
	public void setFdYear(String fdYear) {
		this.fdYear = fdYear;
	}
	public String getFdQuarter() {
		return fdQuarter;
	}
	public void setFdQuarter(String fdQuarter) {
		this.fdQuarter = fdQuarter;
	}

}
