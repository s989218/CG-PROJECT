package fms.bean;

import java.io.Serializable;

public class FMSDMForecastCategoryDTO implements Serializable{

	private static final long serialVersionUID = 9156729069721758012L;
	private String forecastCategory;
	public String getForecastCategory() {
		return forecastCategory;
	}
	public void setForecastCategory(String forecastCategory) {
		this.forecastCategory = forecastCategory;
	}

}
