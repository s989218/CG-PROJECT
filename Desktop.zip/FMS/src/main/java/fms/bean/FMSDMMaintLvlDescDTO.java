package fms.bean;

import java.io.Serializable;

public class FMSDMMaintLvlDescDTO implements Serializable{

	private static final long serialVersionUID = -8905359986361290557L;
	private String dmMaintLvlDesc;
	public String getDmMaintLvlDesc() {
		return dmMaintLvlDesc;
	}
	public void setDmMaintLvlDesc(String dmMaintLvlDesc) {
		this.dmMaintLvlDesc = dmMaintLvlDesc;
	}
	
}
