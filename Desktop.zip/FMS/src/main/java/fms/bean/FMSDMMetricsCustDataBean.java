package fms.bean;

import java.io.Serializable;

public class FMSDMMetricsCustDataBean implements Serializable {

	private static final long serialVersionUID = -8394877885415676728L;
	private String dcCountry;
	private String dcRegion;
	private String dcUserAccountName;
	private int dcCustomerCount;
	private int dcRegionId;
	private String dcColorCode;
	public String getDcCountry() {
		return dcCountry;
	}
	public void setDcCountry(String dcCountry) {
		this.dcCountry = dcCountry;
	}
	public String getDcRegion() {
		return dcRegion;
	}
	public void setDcRegion(String dcRegion) {
		this.dcRegion = dcRegion;
	}
	public String getDcUserAccountName() {
		return dcUserAccountName;
	}
	public void setDcUserAccountName(String dcUserAccountName) {
		this.dcUserAccountName = dcUserAccountName;
	}
	public int getDcCustomerCount() {
		return dcCustomerCount;
	}
	public void setDcCustomerCount(int dcCustomerCount) {
		this.dcCustomerCount = dcCustomerCount;
	}
	public int getDcRegionId() {
		return dcRegionId;
	}
	public void setDcRegionId(int dcRegionId) {
		this.dcRegionId = dcRegionId;
	}
	public String getDcColorCode() {
		return dcColorCode;
	}
	public void setDcColorCode(String dcColorCode) {
		this.dcColorCode = dcColorCode;
	}
}
