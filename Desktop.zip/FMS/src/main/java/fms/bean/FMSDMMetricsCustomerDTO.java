package fms.bean;

import java.io.Serializable;

public class FMSDMMetricsCustomerDTO implements Serializable{

	private static final long serialVersionUID = -1307403060367394311L;
	private String dmcCountry;
	private String dmcRegion;
	private String dmcUserAccountName;
	private int dmcCustomerCount;
	private int dmcRegionId;
	private String dmcColorCode;
	public String getDmcCountry() {
		return dmcCountry;
	}
	public void setDmcCountry(String dmcCountry) {
		this.dmcCountry = dmcCountry;
	}
	public String getDmcRegion() {
		return dmcRegion;
	}
	public void setDmcRegion(String dmcRegion) {
		this.dmcRegion = dmcRegion;
	}
	public String getDmcUserAccountName() {
		return dmcUserAccountName;
	}
	public void setDmcUserAccountName(String dmcUserAccountName) {
		this.dmcUserAccountName = dmcUserAccountName;
	}
	public int getDmcCustomerCount() {
		return dmcCustomerCount;
	}
	public void setDmcCustomerCount(int dmcCustomerCount) {
		this.dmcCustomerCount = dmcCustomerCount;
	}
	public int getDmcRegionId() {
		return dmcRegionId;
	}
	public void setDmcRegionId(int dmcRegionId) {
		this.dmcRegionId = dmcRegionId;
	}
	public String getDmcColorCode() {
		return dmcColorCode;
	}
	public void setDmcColorCode(String dmcColorCode) {
		this.dmcColorCode = dmcColorCode;
	}
	
		
}
