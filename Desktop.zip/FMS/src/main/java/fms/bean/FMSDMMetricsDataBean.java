package fms.bean;

import java.io.Serializable;

public class FMSDMMetricsDataBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6940761346453867408L;
	private String dmPrimaryRegion;
	private String dmForecastCategory;
	private String dmBusinessTier3;
	private String dmPrimaryCountry;
	private String dmcQtr;
	private String dmAccountName;
	private String dmRiskPath;
	private String dmAccountClass;
	private String dmAccountType;
	public String getDmPrimaryRegion() {
		return dmPrimaryRegion;
	}
	public void setDmPrimaryRegion(String dmPrimaryRegion) {
		this.dmPrimaryRegion = dmPrimaryRegion;
	}
	public String getDmForecastCategory() {
		return dmForecastCategory;
	}
	public void setDmForecastCategory(String dmForecastCategory) {
		this.dmForecastCategory = dmForecastCategory;
	}
	public String getDmBusinessTier3() {
		return dmBusinessTier3;
	}
	public void setDmBusinessTier3(String dmBusinessTier3) {
		this.dmBusinessTier3 = dmBusinessTier3;
	}
	public String getDmPrimaryCountry() {
		return dmPrimaryCountry;
	}
	public void setDmPrimaryCountry(String dmPrimaryCountry) {
		this.dmPrimaryCountry = dmPrimaryCountry;
	}
	public String getDmcQtr() {
		return dmcQtr;
	}
	public void setDmcQtr(String dmcQtr) {
		this.dmcQtr = dmcQtr;
	}
	public String getDmAccountName() {
		return dmAccountName;
	}
	public void setDmAccountName(String dmAccountName) {
		this.dmAccountName = dmAccountName;
	}
	public String getDmRiskPath() {
		return dmRiskPath;
	}
	public void setDmRiskPath(String dmRiskPath) {
		this.dmRiskPath = dmRiskPath;
	}
	public String getDmAccountClass() {
		return dmAccountClass;
	}
	public void setDmAccountClass(String dmAccountClass) {
		this.dmAccountClass = dmAccountClass;
	}
	public String getDmAccountType() {
		return dmAccountType;
	}
	public void setDmAccountType(String dmAccountType) {
		this.dmAccountType = dmAccountType;
	}
	
}
