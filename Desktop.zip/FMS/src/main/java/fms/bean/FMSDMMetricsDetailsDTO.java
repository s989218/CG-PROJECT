package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSDMMetricsDetailsDTO implements Serializable{

	private static final long serialVersionUID = 5277340493597072449L;
	private List<FMSDMMetricsTechDTO> technologyDetails;
	private List<FMSDMMetricsCustomerDTO> topCustomer;
	
	public List<FMSDMMetricsTechDTO> getTechnologyDetails() {
		return technologyDetails;
	}
	public void setTechnologyDetails(List<FMSDMMetricsTechDTO> technologyDetails) {
		this.technologyDetails = technologyDetails;
	}
	public List<FMSDMMetricsCustomerDTO> getTopCustomer() {
		return topCustomer;
	}
	public void setTopCustomer(List<FMSDMMetricsCustomerDTO> topCustomer) {
		this.topCustomer = topCustomer;
	}

}
