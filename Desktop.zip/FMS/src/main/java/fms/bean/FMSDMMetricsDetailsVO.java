package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSDMMetricsDetailsVO implements Serializable {

	private static final long serialVersionUID = -837805907429599862L;
	private List<FMSDMMetricsTechDataBean> technologyDataBean;
	private List<FMSDMMetricsCustDataBean> custNameDataBean;
	
	public List<FMSDMMetricsTechDataBean> getTechnologyDataBean() {
		return technologyDataBean;
	}
	public void setTechnologyDataBean(
			List<FMSDMMetricsTechDataBean> technologyDataBean) {
		this.technologyDataBean = technologyDataBean;
	}
	public List<FMSDMMetricsCustDataBean> getCustNameDataBean() {
		return custNameDataBean;
	}
	public void setCustNameDataBean(List<FMSDMMetricsCustDataBean> custNameDataBean) {
		this.custNameDataBean = custNameDataBean;
	}
	
	
}
