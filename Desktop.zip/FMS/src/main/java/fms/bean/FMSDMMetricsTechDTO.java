package fms.bean;

import java.io.Serializable;

public class FMSDMMetricsTechDTO implements Serializable{

	private static final long serialVersionUID = 5448721005464143607L;
	private String dTechRegion;
	private String dTechOpptyType;
	private int dTechDmAmount;
	private String dTechColorCode;
	public String getdTechRegion() {
		return dTechRegion;
	}
	public void setdTechRegion(String dTechRegion) {
		this.dTechRegion = dTechRegion;
	}
	public String getdTechOpptyType() {
		return dTechOpptyType;
	}
	public void setdTechOpptyType(String dTechOpptyType) {
		this.dTechOpptyType = dTechOpptyType;
	}
	public int getdTechDmAmount() {
		return dTechDmAmount;
	}
	public void setdTechDmAmount(int dTechDmAmount) {
		this.dTechDmAmount = dTechDmAmount;
	}
	public String getdTechColorCode() {
		return dTechColorCode;
	}
	public void setdTechColorCode(String dTechColorCode) {
		this.dTechColorCode = dTechColorCode;
	}

	}
