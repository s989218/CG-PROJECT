package fms.bean;

import java.io.Serializable;

public class FMSDMMetricsTechDataBean implements Serializable {

	private static final long serialVersionUID = -1110680179184911571L;
	private String dmTechRegion;
	private String dmTechOpptyType;
	private long dmTechDmAmount;
	private String dmTechColorCode;
	private int dmTechRegionId;
	private String dmTechCountry;
	public String getDmTechRegion() {
		return dmTechRegion;
	}
	public void setDmTechRegion(String dmTechRegion) {
		this.dmTechRegion = dmTechRegion;
	}
	public String getDmTechOpptyType() {
		return dmTechOpptyType;
	}
	public void setDmTechOpptyType(String dmTechOpptyType) {
		this.dmTechOpptyType = dmTechOpptyType;
	}
	
	public long getDmTechDmAmount() {
		return dmTechDmAmount;
	}
	public void setDmTechDmAmount(long dmTechDmAmount) {
		this.dmTechDmAmount = dmTechDmAmount;
	}
	public String getDmTechColorCode() {
		return dmTechColorCode;
	}
	public void setDmTechColorCode(String dmTechColorCode) {
		this.dmTechColorCode = dmTechColorCode;
	}
	public int getDmTechRegionId() {
		return dmTechRegionId;
	}
	public void setDmTechRegionId(int dmTechRegionId) {
		this.dmTechRegionId = dmTechRegionId;
	}
	public String getDmTechCountry() {
		return dmTechCountry;
	}
	public void setDmTechCountry(String dmTechCountry) {
		this.dmTechCountry = dmTechCountry;
	}
}
