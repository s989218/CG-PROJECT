package fms.bean;

import java.io.Serializable;

public class FMSDMPathDTO implements Serializable{

	private static final long serialVersionUID = -6637505133829781021L;
	private String path;

	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
}
