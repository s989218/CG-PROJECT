package fms.bean;

import java.io.Serializable;

public class FMSDMPrimaryCountryDTO implements Serializable{

	private static final long serialVersionUID = 6863727757393464082L;
	private String primaryCountry;

	public String getPrimaryCountry() {
		return primaryCountry;
	}
	public void setPrimaryCountry(String primaryCountry) {
		this.primaryCountry = primaryCountry;
	}
}
