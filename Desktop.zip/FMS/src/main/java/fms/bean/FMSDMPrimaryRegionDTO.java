package fms.bean;

import java.io.Serializable;

public class FMSDMPrimaryRegionDTO implements Serializable{

	private static final long serialVersionUID = 7593567317012943155L;
	private String primaryRegion;

	public String getPrimaryRegion() {
		return primaryRegion;
	}
	public void setPrimaryRegion(String primaryRegion) {
		this.primaryRegion = primaryRegion;
	}
}
