package fms.bean;

import java.io.Serializable;

public class FMSDMQtrDTO implements Serializable{

	private static final long serialVersionUID = 5349583597233071395L;
	private String qtr;

	public String getQtr() {
		return qtr;
	}
	public void setQtr(String qtr) {
		this.qtr = qtr;
	}
}
