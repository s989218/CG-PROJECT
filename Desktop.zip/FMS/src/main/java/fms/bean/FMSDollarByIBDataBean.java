package fms.bean;

import java.io.Serializable;

public class FMSDollarByIBDataBean implements Serializable {
	
	private static final long serialVersionUID = 5520336597240028867L;
	private String dollarByIBRegion;  
	private String dollarByIBYear;
	private String dollarByIBQuarter;
	private String dollarByIBValue;
	
	public String getDollarByIBRegion() {
		return dollarByIBRegion;
	}
	public void setDollarByIBRegion(String dollarByIBRegion) {
		this.dollarByIBRegion = dollarByIBRegion;
	}
	public String getDollarByIBYear() {
		return dollarByIBYear;
	}
	public void setDollarByIBYear(String dollarByIBYear) {
		this.dollarByIBYear = dollarByIBYear;
	}
	public String getDollarByIBQuarter() {
		return dollarByIBQuarter;
	}
	public void setDollarByIBQuarter(String dollarByIBQuarter) {
		this.dollarByIBQuarter = dollarByIBQuarter;
	}
	public String getDollarByIBValue() {
		return dollarByIBValue;
	}
	public void setDollarByIBValue(String dollarByIBValue) {
		this.dollarByIBValue = dollarByIBValue;
	}
	
	
	
}
