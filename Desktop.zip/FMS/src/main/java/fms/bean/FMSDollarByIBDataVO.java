package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSDollarByIBDataVO implements Serializable {
	
	private static final long serialVersionUID = -5541859245171194559L;
	private List<FMSDollarByIBDataBean> dollarByIBCurrentData;
	private List<FMSDollarByIBDataBean> dollarByIBHistoryData;
	public List<FMSDollarByIBDataBean> getDollarByIBCurrentData() {
		return dollarByIBCurrentData;
	}
	public void setDollarByIBCurrentData(
			List<FMSDollarByIBDataBean> dollarByIBCurrentData) {
		this.dollarByIBCurrentData = dollarByIBCurrentData;
	}
	public List<FMSDollarByIBDataBean> getDollarByIBHistoryData() {
		return dollarByIBHistoryData;
	}
	public void setDollarByIBHistoryData(
			List<FMSDollarByIBDataBean> dollarByIBHistoryData) {
		this.dollarByIBHistoryData = dollarByIBHistoryData;
	}
	
	

}
