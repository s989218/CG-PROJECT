package fms.bean;

import java.io.Serializable;

public class FMSEndUserNameDropdownBean implements Serializable {

	private static final long serialVersionUID = 2526385576690532170L;
	private String endUserName;

	public String getEndUserName() {
		return endUserName;
	}

	public void setEndUserName(String endUserName) {
		this.endUserName = endUserName;
	}
	
	
}
