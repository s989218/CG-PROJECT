package fms.bean;

import java.io.Serializable;

public class FMSEquipCodeDropdownBean implements Serializable {

	private static final long serialVersionUID = -1639121618579225523L;
	private String equipCode;

	public String getEquipCode() {
		return equipCode;
	}

	public void setEquipCode(String equipCode) {
		this.equipCode = equipCode;
	}
	
}
