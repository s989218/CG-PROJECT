package fms.bean;

import java.io.Serializable;

public class FMSEquipmentCodeDropdownBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1814330788770326462L;

	private String equipmentCodeFilter;

	public String getEquipmentCodeFilter() {
		return equipmentCodeFilter;
	}

	public void setEquipmentCodeFilter(String equipmentCodeFilter) {
		this.equipmentCodeFilter = equipmentCodeFilter;
	}
}
