package fms.bean;

import java.io.Serializable;

public class FMSFleetCoverageDataBean implements Serializable {

	private static final long serialVersionUID = 8267410115688903945L;
	private String coverageRegion;  
	private String coverageYear;
	private String coverageQuarter;
	private String coverageValue;
	
	public String getCoverageRegion() {
		return coverageRegion;
	}
	public void setCoverageRegion(String coverageRegion) {
		this.coverageRegion = coverageRegion;
	}
	public String getCoverageYear() {
		return coverageYear;
	}
	public void setCoverageYear(String coverageYear) {
		this.coverageYear = coverageYear;
	}
	public String getCoverageQuarter() {
		return coverageQuarter;
	}
	public void setCoverageQuarter(String coverageQuarter) {
		this.coverageQuarter = coverageQuarter;
	}
	public String getCoverageValue() {
		return coverageValue;
	}
	public void setCoverageValue(String coverageValue) {
		this.coverageValue = coverageValue;
	}
	
}
