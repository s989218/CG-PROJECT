package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSFleetCoverageDataVO implements Serializable {
	
	private static final long serialVersionUID = -8445301514154914646L;
	private List<FMSFleetCoverageDataBean> fleetCoverageCurrentData;
	private List<FMSFleetCoverageDataBean> fleetCoverageHistoryData;
	public List<FMSFleetCoverageDataBean> getFleetCoverageCurrentData() {
		return fleetCoverageCurrentData;
	}
	public void setFleetCoverageCurrentData(
			List<FMSFleetCoverageDataBean> fleetCoverageCurrentData) {
		this.fleetCoverageCurrentData = fleetCoverageCurrentData;
	}
	public List<FMSFleetCoverageDataBean> getFleetCoverageHistoryData() {
		return fleetCoverageHistoryData;
	}
	public void setFleetCoverageHistoryData(
			List<FMSFleetCoverageDataBean> fleetCoverageHistoryData) {
		this.fleetCoverageHistoryData = fleetCoverageHistoryData;
	}
	

}
