package fms.bean;

import java.io.Serializable;

public class FMSFleetPenetrationDataBean implements Serializable {

	private static final long serialVersionUID = 5476428457389959774L;
	private String penetrationRegion;  
	private String penetrationYear;
	private String penetrationQuarter;
	private String penetrationValue;
	
	public String getPenetrationRegion() {
		return penetrationRegion;
	}
	public void setPenetrationRegion(String penetrationRegion) {
		this.penetrationRegion = penetrationRegion;
	}
	public String getPenetrationYear() {
		return penetrationYear;
	}
	public void setPenetrationYear(String penetrationYear) {
		this.penetrationYear = penetrationYear;
	}
	public String getPenetrationQuarter() {
		return penetrationQuarter;
	}
	public void setPenetrationQuarter(String penetrationQuarter) {
		this.penetrationQuarter = penetrationQuarter;
	}
	public String getPenetrationValue() {
		return penetrationValue;
	}
	public void setPenetrationValue(String penetrationValue) {
		this.penetrationValue = penetrationValue;
	}
	
}
