package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSFleetPenetrationDataVO implements Serializable{

	private static final long serialVersionUID = 8515410783952903245L;
	private List<FMSFleetPenetrationDataBean> fleetPenetrationCurrentData;
	private List<FMSFleetPenetrationDataBean> fleetPenetrationHistoryData;
	public List<FMSFleetPenetrationDataBean> getFleetPenetrationCurrentData() {
		return fleetPenetrationCurrentData;
	}
	public void setFleetPenetrationCurrentData(
			List<FMSFleetPenetrationDataBean> fleetPenetrationCurrentData) {
		this.fleetPenetrationCurrentData = fleetPenetrationCurrentData;
	}
	public List<FMSFleetPenetrationDataBean> getFleetPenetrationHistoryData() {
		return fleetPenetrationHistoryData;
	}
	public void setFleetPenetrationHistoryData(
			List<FMSFleetPenetrationDataBean> fleetPenetrationHistoryData) {
		this.fleetPenetrationHistoryData = fleetPenetrationHistoryData;
	}
	
}
