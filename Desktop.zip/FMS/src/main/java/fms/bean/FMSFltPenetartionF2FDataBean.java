package fms.bean;

import java.io.Serializable;

public class FMSFltPenetartionF2FDataBean implements Serializable {

	private static final long serialVersionUID = 4431780149256073757L;
	private String fltPenFFRegion;  
	private String year;
	private String quarter;
	private String fleetPenF2FValue;
	public String getFltPenFFRegion() {
		return fltPenFFRegion;
	}
	public void setFltPenFFRegion(String fltPenFFRegion) {
		this.fltPenFFRegion = fltPenFFRegion;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getQuarter() {
		return quarter;
	}
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}
	public String getFleetPenF2FValue() {
		return fleetPenF2FValue;
	}
	public void setFleetPenF2FValue(String fleetPenF2FValue) {
		this.fleetPenF2FValue = fleetPenF2FValue;
	}
	
	
}
