package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSFltPenetrationF2FDataVO implements Serializable {

	private static final long serialVersionUID = 9136743542782346460L;
	private List<FMSFltPenetartionF2FDataBean> fltPentrtnF2FCurrentData;
	private List<FMSFltPenetartionF2FDataBean> fltPentrtnF2FHistoryData;
	public List<FMSFltPenetartionF2FDataBean> getFltPentrtnF2FCurrentData() {
		return fltPentrtnF2FCurrentData;
	}
	public void setFltPentrtnF2FCurrentData(
			List<FMSFltPenetartionF2FDataBean> fltPentrtnF2FCurrentData) {
		this.fltPentrtnF2FCurrentData = fltPentrtnF2FCurrentData;
	}
	public List<FMSFltPenetartionF2FDataBean> getFltPentrtnF2FHistoryData() {
		return fltPentrtnF2FHistoryData;
	}
	public void setFltPentrtnF2FHistoryData(
			List<FMSFltPenetartionF2FDataBean> fltPentrtnF2FHistoryData) {
		this.fltPentrtnF2FHistoryData = fltPentrtnF2FHistoryData;
	}
	
}
