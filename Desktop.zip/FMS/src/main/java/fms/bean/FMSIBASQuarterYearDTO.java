package fms.bean;

import java.io.Serializable;

public class FMSIBASQuarterYearDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4822529451619593681L;
	private int year;
	private String quarter;
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getQuarter() {
		return quarter;
	}
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}

}
