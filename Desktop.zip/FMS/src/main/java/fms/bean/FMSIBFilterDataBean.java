package fms.bean;

import java.io.Serializable;

public class FMSIBFilterDataBean implements Serializable{

	private static final long serialVersionUID = 9145633691159276952L;
	private String region;
	private String technology;
	private String custName;
	private String unitStatusDesc;
	private String siteCustCountry;
	private String servRelDesc;
	private String marketSegment;
	private String oemLoc;
	private String siteCustDunsName;
	private String siteCustName;
	private String siteNameAlias;
	private String equipmentCodeFilter;
	private String businessSegmentFilter;
	private String accountManagerFilter;
	private String marketIndustryIB;
	private String iboType;
	
	
	public String getIboType() {
		return iboType;
	}
	public void setIboType(String iboType) {
		this.iboType = iboType;
	}
	public String getMarketIndustryIB() {
		return marketIndustryIB;
	}
	public void setMarketIndustryIB(String marketIndustryIB) {
		this.marketIndustryIB = marketIndustryIB;
	}
	public String getAccountManagerFilter() {
		return accountManagerFilter;
	}
	public void setAccountManagerFilter(String accountManagerFilter) {
		this.accountManagerFilter = accountManagerFilter;
	}
	public String getBusinessSegmentFilter() {
		return businessSegmentFilter;
	}
	public void setBusinessSegmentFilter(String businessSegmentFilter) {
		this.businessSegmentFilter = businessSegmentFilter;
	}
	public String getSiteNameAlias() {
		return siteNameAlias;
	}
	public void setSiteNameAlias(String siteNameAlias) {
		this.siteNameAlias = siteNameAlias;
	}
	public String getSiteCustName() {
		return siteCustName;
	}
	public void setSiteCustName(String siteCustName) {
		this.siteCustName = siteCustName;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getUnitStatusDesc() {
		return unitStatusDesc;
	}
	public void setUnitStatusDesc(String unitStatusDesc) {
		this.unitStatusDesc = unitStatusDesc;
	}
	public String getSiteCustCountry() {
		return siteCustCountry;
	}
	public void setSiteCustCountry(String siteCustCountry) {
		this.siteCustCountry = siteCustCountry;
	}
	public String getServRelDesc() {
		return servRelDesc;
	}
	public void setServRelDesc(String servRelDesc) {
		this.servRelDesc = servRelDesc;
	}
	public String getMarketSegment() {
		return marketSegment;
	}
	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}
	public String getOemLoc() {
		return oemLoc;
	}
	public void setOemLoc(String oemLoc) {
		this.oemLoc = oemLoc;
	}
	public String getSiteCustDunsName() {
		return siteCustDunsName;
	}
	public void setSiteCustDunsName(String siteCustDunsName) {
		this.siteCustDunsName = siteCustDunsName;
	}
	public String getEquipmentCodeFilter() {
		return equipmentCodeFilter;
	}
	public void setEquipmentCodeFilter(String equipmentCodeFilter) {
		this.equipmentCodeFilter = equipmentCodeFilter;
	}
	

}
