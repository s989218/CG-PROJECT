package fms.bean;

import java.io.Serializable;

public class FMSIBMetricsCustDataBean implements Serializable {

	private static final long serialVersionUID = -8394877885415676728L;
	private String region;  
	private String custName;
	private String custNameCount;
	private String regId;
	private String country;
	private String technologyIB;
	private String techCountIB;
	private String custColorCodeIB;
	
	
	public String getTechnologyIB() {
		return technologyIB;
	}
	public void setTechnologyIB(String technologyIB) {
		this.technologyIB = technologyIB;
	}
	public String getTechCountIB() {
		return techCountIB;
	}
	public void setTechCountIB(String techCountIB) {
		this.techCountIB = techCountIB;
	}
	public String getCustColorCodeIB() {
		return custColorCodeIB;
	}
	public void setCustColorCodeIB(String custColorCodeIB) {
		this.custColorCodeIB = custColorCodeIB;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustNameCount() {
		return custNameCount;
	}
	public void setCustNameCount(String custNameCount) {
		this.custNameCount = custNameCount;
	}
	
	
	
}
