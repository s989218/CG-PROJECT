package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSIBMetricsDetailsVO implements Serializable {

	private static final long serialVersionUID = -837805907429599862L;
	private List<FMSIBMetricsTechDataBean> technologyDataBean;
	private List<FMSIBMetricsCustDataBean> custNameDataBean;
	
	public List<FMSIBMetricsTechDataBean> getTechnologyDataBean() {
		return technologyDataBean;
	}
	public void setTechnologyDataBean(
			List<FMSIBMetricsTechDataBean> technologyDataBean) {
		this.technologyDataBean = technologyDataBean;
	}
	public List<FMSIBMetricsCustDataBean> getCustNameDataBean() {
		return custNameDataBean;
	}
	public void setCustNameDataBean(List<FMSIBMetricsCustDataBean> custNameDataBean) {
		this.custNameDataBean = custNameDataBean;
	}
	
	
}
