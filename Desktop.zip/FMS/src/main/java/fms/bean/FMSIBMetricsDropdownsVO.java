package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSIBMetricsDropdownsVO implements Serializable {
	
	private static final long serialVersionUID = 2717954999928883903L;
	private List<FMSRegionDropdownBean> regionDropdownBean;
	private List<FMSTechnologyDropdownBean> techDropdownBean;
	private List<FMSCustomerDropdownBean> custDropdownBean;
	private List<FMSUnitStatusDesDropdownBean> unitStatusDropdownBean;
	private List<FMSSiteCustCountryDropdownBean> siteCustCountryDropdownBean;
	private List<FMSServRelDescOngDropdownBean> servRelationDropdownBean;
	private List<FMSMarketSegmentDescDropdownBean> marketSegmentDropdownBean;
	private List<FMSSiteCustomerNameDropdownBean> siteCustomerNameDropdownBean;
	private List<FMSSiteNameAliasDropdownBean> siteNameAliasDropdownBean;
	private List<FMSStringDropdownBean> oemLocationDDBean;
	private List<FMSStringDropdownBean> siteCustDunsNameDDBean;
	private List<FMSEquipmentCodeDropdownBean> equipmentCodeDropdown;
	private List<FMSBusinessSegDropdownBean> businessSegmentDropdown;
	private List<FMSIBOTypeDropdownBean> iboTypeDropdown;
	
	public List<FMSIBOTypeDropdownBean> getIboTypeDropdown() {
		return iboTypeDropdown;
	}
	public void setIboTypeDropdown(List<FMSIBOTypeDropdownBean> iboTypeDropdown) {
		this.iboTypeDropdown = iboTypeDropdown;
	}
	public List<FMSBusinessSegDropdownBean> getBusinessSegmentDropdown() {
		return businessSegmentDropdown;
	}
	public void setBusinessSegmentDropdown(
			List<FMSBusinessSegDropdownBean> businessSegmentDropdown) {
		this.businessSegmentDropdown = businessSegmentDropdown;
	}
	public List<FMSSiteNameAliasDropdownBean> getSiteNameAliasDropdownBean() {
		return siteNameAliasDropdownBean;
	}
	public void setSiteNameAliasDropdownBean(
			List<FMSSiteNameAliasDropdownBean> siteNameAliasDropdownBean) {
		this.siteNameAliasDropdownBean = siteNameAliasDropdownBean;
	}
	public List<FMSRegionDropdownBean> getRegionDropdownBean() {
		return regionDropdownBean;
	}
	public void setRegionDropdownBean(List<FMSRegionDropdownBean> regionDropdownBean) {
		this.regionDropdownBean = regionDropdownBean;
	}
	public List<FMSTechnologyDropdownBean> getTechDropdownBean() {
		return techDropdownBean;
	}
	public void setTechDropdownBean(List<FMSTechnologyDropdownBean> techDropdownBean) {
		this.techDropdownBean = techDropdownBean;
	}
	public List<FMSCustomerDropdownBean> getCustDropdownBean() {
		return custDropdownBean;
	}
	public void setCustDropdownBean(List<FMSCustomerDropdownBean> custDropdownBean) {
		this.custDropdownBean = custDropdownBean;
	}
	public List<FMSUnitStatusDesDropdownBean> getUnitStatusDropdownBean() {
		return unitStatusDropdownBean;
	}
	public void setUnitStatusDropdownBean(
			List<FMSUnitStatusDesDropdownBean> unitStatusDropdownBean) {
		this.unitStatusDropdownBean = unitStatusDropdownBean;
	}
	public List<FMSSiteCustCountryDropdownBean> getSiteCustCountryDropdownBean() {
		return siteCustCountryDropdownBean;
	}
	public void setSiteCustCountryDropdownBean(
			List<FMSSiteCustCountryDropdownBean> siteCustCountryDropdownBean) {
		this.siteCustCountryDropdownBean = siteCustCountryDropdownBean;
	}
	public List<FMSServRelDescOngDropdownBean> getServRelationDropdownBean() {
		return servRelationDropdownBean;
	}
	public void setServRelationDropdownBean(
			List<FMSServRelDescOngDropdownBean> servRelationDropdownBean) {
		this.servRelationDropdownBean = servRelationDropdownBean;
	}
	public List<FMSMarketSegmentDescDropdownBean> getMarketSegmentDropdownBean() {
		return marketSegmentDropdownBean;
	}
	public void setMarketSegmentDropdownBean(
			List<FMSMarketSegmentDescDropdownBean> marketSegmentDropdownBean) {
		this.marketSegmentDropdownBean = marketSegmentDropdownBean;
	}
	public List<FMSSiteCustomerNameDropdownBean> getSiteCustomerNameDropdownBean() {
		return siteCustomerNameDropdownBean;
	}
	public void setSiteCustomerNameDropdownBean(
			List<FMSSiteCustomerNameDropdownBean> siteCustomerNameDropdownBean) {
		this.siteCustomerNameDropdownBean = siteCustomerNameDropdownBean;
	}
	public List<FMSStringDropdownBean> getOemLocationDDBean() {
		return oemLocationDDBean;
	}
	public void setOemLocationDDBean(List<FMSStringDropdownBean> oemLocationDDBean) {
		this.oemLocationDDBean = oemLocationDDBean;
	}
	public List<FMSStringDropdownBean> getSiteCustDunsNameDDBean() {
		return siteCustDunsNameDDBean;
	}
	public void setSiteCustDunsNameDDBean(
			List<FMSStringDropdownBean> siteCustDunsNameDDBean) {
		this.siteCustDunsNameDDBean = siteCustDunsNameDDBean;
	}
	public List<FMSEquipmentCodeDropdownBean> getEquipmentCodeDropdown() {
		return equipmentCodeDropdown;
	}
	public void setEquipmentCodeDropdown(List<FMSEquipmentCodeDropdownBean> equipmentCodeDropdown) {
		this.equipmentCodeDropdown = equipmentCodeDropdown;
	}
	
	
}
