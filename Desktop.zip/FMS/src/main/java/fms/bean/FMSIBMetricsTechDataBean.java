package fms.bean;

import java.io.Serializable;

public class FMSIBMetricsTechDataBean implements Serializable {

	private static final long serialVersionUID = -1110680179184911571L;
	private String mTechRegion;  
	private String mTechTechnology;
	private String mTechTechnologyCount;
	private String mTechRegId;
	private String mTechCountry;
	private String colorCode;
	
	public String getmTechRegion() {
		return mTechRegion;
	}
	public void setmTechRegion(String mTechRegion) {
		this.mTechRegion = mTechRegion;
	}
	public String getmTechTechnology() {
		return mTechTechnology;
	}
	public void setmTechTechnology(String mTechTechnology) {
		this.mTechTechnology = mTechTechnology;
	}
	public String getmTechTechnologyCount() {
		return mTechTechnologyCount;
	}
	public void setmTechTechnologyCount(String mTechTechnologyCount) {
		this.mTechTechnologyCount = mTechTechnologyCount;
	}
	public String getmTechRegId() {
		return mTechRegId;
	}
	public void setmTechRegId(String mTechRegId) {
		this.mTechRegId = mTechRegId;
	}
	public String getmTechCountry() {
		return mTechCountry;
	}
	public void setmTechCountry(String mTechCountry) {
		this.mTechCountry = mTechCountry;
	}
	public String getColorCode() {
		return colorCode;
	}
	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}
	
}
