package fms.bean;

import java.io.Serializable;

public class FMSIBNByRegionDataBean implements Serializable {
	
	private static final long serialVersionUID = 8355366419081194938L;
	private String region;  
	private String regionYear;
	private String regionQuarter;
	private String ibByRegion;
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getRegionYear() {
		return regionYear;
	}
	public void setRegionYear(String regionYear) {
		this.regionYear = regionYear;
	}
	public String getRegionQuarter() {
		return regionQuarter;
	}
	public void setRegionQuarter(String regionQuarter) {
		this.regionQuarter = regionQuarter;
	}
	public String getIbByRegion() {
		return ibByRegion;
	}
	public void setIbByRegion(String ibByRegion) {
		this.ibByRegion = ibByRegion;
	}
	
	
	
	
}
