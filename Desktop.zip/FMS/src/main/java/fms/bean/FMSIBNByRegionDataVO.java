package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSIBNByRegionDataVO implements Serializable {

	private static final long serialVersionUID = -8226926863091503440L;
	private List<FMSIBNByRegionDataBean> ibnByRegionCurrentData;
	private List<FMSIBNByRegionDataBean> ibnByRegionHistoryData;
	
	public List<FMSIBNByRegionDataBean> getIbnByRegionCurrentData() {
		return ibnByRegionCurrentData;
	}
	public void setIbnByRegionCurrentData(
			List<FMSIBNByRegionDataBean> ibnByRegionCurrentData) {
		this.ibnByRegionCurrentData = ibnByRegionCurrentData;
	}
	public List<FMSIBNByRegionDataBean> getIbnByRegionHistoryData() {
		return ibnByRegionHistoryData;
	}
	public void setIbnByRegionHistoryData(
			List<FMSIBNByRegionDataBean> ibnByRegionHistoryData) {
		this.ibnByRegionHistoryData = ibnByRegionHistoryData;
	}
	
	
}
