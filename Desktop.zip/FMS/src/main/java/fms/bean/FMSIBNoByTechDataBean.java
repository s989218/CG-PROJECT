package fms.bean;

import java.io.Serializable;

public class FMSIBNoByTechDataBean implements Serializable {

	private static final long serialVersionUID = 1679507004156615919L;
	private String techDesc;  
	private String techYear;
	private String techQuarter;
	private String ibNoByTechnology;
	public String getTechDesc() {
		return techDesc;
	}
	public void setTechDesc(String techDesc) {
		this.techDesc = techDesc;
	}
	public String getTechYear() {
		return techYear;
	}
	public void setTechYear(String techYear) {
		this.techYear = techYear;
	}
	public String getTechQuarter() {
		return techQuarter;
	}
	public void setTechQuarter(String techQuarter) {
		this.techQuarter = techQuarter;
	}
	public String getIbNoByTechnology() {
		return ibNoByTechnology;
	}
	public void setIbNoByTechnology(String ibNoByTechnology) {
		this.ibNoByTechnology = ibNoByTechnology;
	}
	
}
