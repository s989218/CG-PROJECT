package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSIBNoByTechDataVO implements Serializable {

	private static final long serialVersionUID = 514636424561022595L;
	private List<FMSIBNoByTechDataBean> ibNoByTechnologyCurrentData;
	private List<FMSIBNoByTechDataBean> ibNoByTechnologyHistoryData;
	public List<FMSIBNoByTechDataBean> getIbNoByTechnologyCurrentData() {
		return ibNoByTechnologyCurrentData;
	}
	public void setIbNoByTechnologyCurrentData(
			List<FMSIBNoByTechDataBean> ibNoByTechnologyCurrentData) {
		this.ibNoByTechnologyCurrentData = ibNoByTechnologyCurrentData;
	}
	public List<FMSIBNoByTechDataBean> getIbNoByTechnologyHistoryData() {
		return ibNoByTechnologyHistoryData;
	}
	public void setIbNoByTechnologyHistoryData(
			List<FMSIBNoByTechDataBean> ibNoByTechnologyHistoryData) {
		this.ibNoByTechnologyHistoryData = ibNoByTechnologyHistoryData;
	}
	
}
