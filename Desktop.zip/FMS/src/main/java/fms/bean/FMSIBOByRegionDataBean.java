package fms.bean;

import java.io.Serializable;

public class FMSIBOByRegionDataBean implements Serializable {
	
	private static final long serialVersionUID = -4915958575699877253L;
	private String iboRegion;  
	private String iboYear;
	private String iboQuarter;
	private String iboByRegionValue;
	
	public String getIboRegion() {
		return iboRegion;
	}
	public void setIboRegion(String iboRegion) {
		this.iboRegion = iboRegion;
	}
	public String getIboYear() {
		return iboYear;
	}
	public void setIboYear(String iboYear) {
		this.iboYear = iboYear;
	}
	public String getIboQuarter() {
		return iboQuarter;
	}
	public void setIboQuarter(String iboQuarter) {
		this.iboQuarter = iboQuarter;
	}
	public String getIboByRegionValue() {
		return iboByRegionValue;
	}
	public void setIboByRegionValue(String iboByRegionValue) {
		this.iboByRegionValue = iboByRegionValue;
	}
	
	
}
