package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSIBOByRegionDataVO implements Serializable {

	private static final long serialVersionUID = -7138694109078004052L;
	private List<FMSIBOByRegionDataBean> iboByRegionCurrentData;
	private List<FMSIBOByRegionDataBean> iboByRegionHistoryData;
	public List<FMSIBOByRegionDataBean> getIboByRegionCurrentData() {
		return iboByRegionCurrentData;
	}
	public void setIboByRegionCurrentData(
			List<FMSIBOByRegionDataBean> iboByRegionCurrentData) {
		this.iboByRegionCurrentData = iboByRegionCurrentData;
	}
	public List<FMSIBOByRegionDataBean> getIboByRegionHistoryData() {
		return iboByRegionHistoryData;
	}
	public void setIboByRegionHistoryData(
			List<FMSIBOByRegionDataBean> iboByRegionHistoryData) {
		this.iboByRegionHistoryData = iboByRegionHistoryData;
	}
	
	
}
