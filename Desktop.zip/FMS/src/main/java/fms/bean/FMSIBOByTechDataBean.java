package fms.bean;

import java.io.Serializable;

public class FMSIBOByTechDataBean implements Serializable {

	private static final long serialVersionUID = 1092416312111611265L;
	private String techDesc;  
	private String year;
	private String quarter;
	private String iboByTechnology;
	public String getTechDesc() {
		return techDesc;
	}
	public void setTechDesc(String techDesc) {
		this.techDesc = techDesc;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getQuarter() {
		return quarter;
	}
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}
	public String getIboByTechnology() {
		return iboByTechnology;
	}
	public void setIboByTechnology(String iboByTechnology) {
		this.iboByTechnology = iboByTechnology;
	}
	
	
	
}
