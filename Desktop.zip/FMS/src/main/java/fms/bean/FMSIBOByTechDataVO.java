package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSIBOByTechDataVO implements Serializable {
	
	private static final long serialVersionUID = 5160837075311886883L;
	private List<FMSIBOByTechDataBean> iboByTechnologyCurrentData;
	private List<FMSIBOByTechDataBean> iboByTechnologyHistoryData;
	public List<FMSIBOByTechDataBean> getIboByTechnologyCurrentData() {
		return iboByTechnologyCurrentData;
	}
	public void setIboByTechnologyCurrentData(
			List<FMSIBOByTechDataBean> iboByTechnologyCurrentData) {
		this.iboByTechnologyCurrentData = iboByTechnologyCurrentData;
	}
	public List<FMSIBOByTechDataBean> getIboByTechnologyHistoryData() {
		return iboByTechnologyHistoryData;
	}
	public void setIboByTechnologyHistoryData(
			List<FMSIBOByTechDataBean> iboByTechnologyHistoryData) {
		this.iboByTechnologyHistoryData = iboByTechnologyHistoryData;
	}

	
}
