package fms.bean;

import java.io.Serializable;

public class FMSIBOMetricsCustDataBean implements Serializable {

	private static final long serialVersionUID = -4743310763561728577L;
	private String iBCustRegion;  
	private String geDunsName;
	private String iBCustAvtotSum;
	private String iBCustRegionId;
	private String iBCustcountry;
	private String technologyIBO;
	private String techSumIBO;
	private String custColorCodeIBO;
	
	public String getiBCustRegion() {
		return iBCustRegion;
	}
	public void setiBCustRegion(String iBCustRegion) {
		this.iBCustRegion = iBCustRegion;
	}
	public String getGeDunsName() {
		return geDunsName;
	}
	public void setGeDunsName(String geDunsName) {
		this.geDunsName = geDunsName;
	}
	public String getiBCustAvtotSum() {
		return iBCustAvtotSum;
	}
	public void setiBCustAvtotSum(String iBCustAvtotSum) {
		this.iBCustAvtotSum = iBCustAvtotSum;
	}
	public String getiBCustRegionId() {
		return iBCustRegionId;
	}
	public void setiBCustRegionId(String iBCustRegionId) {
		this.iBCustRegionId = iBCustRegionId;
	}
	public String getTechnologyIBO() {
		return technologyIBO;
	}
	public void setTechnologyIBO(String technologyIBO) {
		this.technologyIBO = technologyIBO;
	}
	
	public String getTechSumIBO() {
		return techSumIBO;
	}
	public void setTechSumIBO(String techSumIBO) {
		this.techSumIBO = techSumIBO;
	}
	public String getCustColorCodeIBO() {
		return custColorCodeIBO;
	}
	public void setCustColorCodeIBO(String custColorCodeIBO) {
		this.custColorCodeIBO = custColorCodeIBO;
	}
	public String getiBCustcountry() {
		return iBCustcountry;
	}
	public void setiBCustcountry(String iBCustcountry) {
		this.iBCustcountry = iBCustcountry;
	}

	
	
	
}
