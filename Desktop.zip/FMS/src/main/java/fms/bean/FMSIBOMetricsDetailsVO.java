package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSIBOMetricsDetailsVO implements Serializable {
	
	private static final long serialVersionUID = 2762278291950474355L;
	private List<FMSIBOMetricsTechDataBean> iBTechnologyDataBean;
	private List<FMSIBOMetricsCustDataBean> iBCustNameDataBean;
	public List<FMSIBOMetricsTechDataBean> getiBTechnologyDataBean() {
		return iBTechnologyDataBean;
	}
	public void setiBTechnologyDataBean(
			List<FMSIBOMetricsTechDataBean> iBTechnologyDataBean) {
		this.iBTechnologyDataBean = iBTechnologyDataBean;
	}
	public List<FMSIBOMetricsCustDataBean> getiBCustNameDataBean() {
		return iBCustNameDataBean;
	}
	public void setiBCustNameDataBean(
			List<FMSIBOMetricsCustDataBean> iBCustNameDataBean) {
		this.iBCustNameDataBean = iBCustNameDataBean;
	}
	
	
}
