package fms.bean;

import java.io.Serializable;

public class FMSIBOMetricsTechDataBean implements Serializable {
	
	private static final long serialVersionUID = 3341900995399472212L;
	private String iBTchRegion;  
	private String iBTechnologyDes;
	private String iBTechAvtotSum;
	private String iBTechRegionId; 
	private String iBTechCountry;
	private String iBColorCode;
	private String iBTechId;
	public String getiBTechId() {
		return iBTechId;
	}

	public void setiBTechId(String iBTechId) {
		this.iBTechId = iBTechId;
	}

	
	public String getiBTchRegion() {
		return iBTchRegion;
	}

	public void setiBTchRegion(String iBTchRegion) {
		this.iBTchRegion = iBTchRegion;
	}

	public String getiBTechnologyDes() {
		return iBTechnologyDes;
	}

	public void setiBTechnologyDes(String iBTechnologyDes) {
		this.iBTechnologyDes = iBTechnologyDes;
	}

	public String getiBTechAvtotSum() {
		return iBTechAvtotSum;
	}

	public void setiBTechAvtotSum(String iBTechAvtotSum) {
		this.iBTechAvtotSum = iBTechAvtotSum;
	}

	public String getiBTechRegionId() {
		return iBTechRegionId;
	}

	public void setiBTechRegionId(String iBTechRegionId) {
		this.iBTechRegionId = iBTechRegionId;
	}

	public String getiBTechCountry() {
		return iBTechCountry;
	}

	public void setiBTechCountry(String iBTechCountry) {
		this.iBTechCountry = iBTechCountry;
	}

	public String getiBColorCode() {
		return iBColorCode;
	}

	public void setiBColorCode(String iBColorCode) {
		this.iBColorCode = iBColorCode;
	}

	
}
