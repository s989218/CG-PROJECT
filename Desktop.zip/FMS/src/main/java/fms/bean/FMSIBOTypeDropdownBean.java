package fms.bean;

import java.io.Serializable;

public class FMSIBOTypeDropdownBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -9124594514216681232L;
	
	private String iboType;

	public String getIboType() {
		return iboType;
	}

	public void setIboType(String iboType) {
		this.iboType = iboType;
	}

}
