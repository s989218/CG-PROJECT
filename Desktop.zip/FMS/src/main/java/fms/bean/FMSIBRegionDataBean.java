package fms.bean;

import java.io.Serializable;

public class FMSIBRegionDataBean implements Serializable {
	
	private static final long serialVersionUID = -17856697611906420L;
	private String ibRegion;  
	private String ibLatitude;
	private String ibLongitude;
	public String getIbRegion() {
		return ibRegion;
	}
	public void setIbRegion(String ibRegion) {
		this.ibRegion = ibRegion;
	}
	public String getIbLatitude() {
		return ibLatitude;
	}
	public void setIbLatitude(String ibLatitude) {
		this.ibLatitude = ibLatitude;
	}
	public String getIbLongitude() {
		return ibLongitude;
	}
	public void setIbLongitude(String ibLongitude) {
		this.ibLongitude = ibLongitude;
	}
}
