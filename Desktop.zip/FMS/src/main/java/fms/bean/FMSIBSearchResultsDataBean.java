package fms.bean;

import java.io.Serializable;

public class FMSIBSearchResultsDataBean implements Serializable {

	private static final long serialVersionUID = -4681783354928147555L;
	
	private String siteName; 
    private String region;
    private String market; 
    private String serialNum;
    private String technology;
    private String installBaseSiteCustName;
    private String installBaseSiteCustAliasDDBean;
    private String installBaseOEMLoc;
    private String installBaseSrvRelDescOG;
    private String accountManager;
    private String country;
    private String geDuns;
    private String businessSegment;
    private String marketIndustryIB;
    
    public String getMarketIndustryIB() {
		return marketIndustryIB;
	}
	public void setMarketIndustryIB(String marketIndustryIB) {
		this.marketIndustryIB = marketIndustryIB;
	}
	public String getBusinessSegment() {
		return businessSegment;
	}
	public void setBusinessSegment(String businessSegment) {
		this.businessSegment = businessSegment;
	}
	public String getAccountManager() {
		return accountManager;
	}
	public void setAccountManager(String accountManager) {
		this.accountManager = accountManager;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getGeDuns() {
		return geDuns;
	}
	public void setGeDuns(String geDuns) {
		this.geDuns = geDuns;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	public String getSerialNum() {
		return serialNum;
	}
	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getInstallBaseSiteCustName() {
		return installBaseSiteCustName;
	}
	public void setInstallBaseSiteCustName(String installBaseSiteCustName) {
		this.installBaseSiteCustName = installBaseSiteCustName;
	}
	
	public String getInstallBaseSiteCustAliasDDBean() {
		return installBaseSiteCustAliasDDBean;
	}
	public void setInstallBaseSiteCustAliasDDBean(
			String installBaseSiteCustAliasDDBean) {
		this.installBaseSiteCustAliasDDBean = installBaseSiteCustAliasDDBean;
	}
	public String getInstallBaseOEMLoc() {
		return installBaseOEMLoc;
	}
	public void setInstallBaseOEMLoc(String installBaseOEMLoc) {
		this.installBaseOEMLoc = installBaseOEMLoc;
	}
	public String getInstallBaseSrvRelDescOG() {
		return installBaseSrvRelDescOG;
	}
	public void setInstallBaseSrvRelDescOG(String installBaseSrvRelDescOG) {
		this.installBaseSrvRelDescOG = installBaseSrvRelDescOG;
	}
}
