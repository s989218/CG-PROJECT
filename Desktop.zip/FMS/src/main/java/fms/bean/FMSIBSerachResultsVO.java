package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSIBSerachResultsVO implements Serializable {

	private static final long serialVersionUID = -5116099331749538560L;
	
	private List<FMSIBRegionDataBean> regionDataBean;
	private List<FMSIBSiteNameDataBean> siteNameDataBean;
	private List<FMSIBSerialNumDataBean> installBaseNoOfUnitsData;
	
	public List<FMSIBRegionDataBean> getRegionDataBean() {
		return regionDataBean;
	}
	public void setRegionDataBean(List<FMSIBRegionDataBean> regionDataBean) {
		this.regionDataBean = regionDataBean;
	}
	public List<FMSIBSiteNameDataBean> getSiteNameDataBean() {
		return siteNameDataBean;
	}
	public void setSiteNameDataBean(List<FMSIBSiteNameDataBean> siteNameDataBean) {
		this.siteNameDataBean = siteNameDataBean;
	}
	public List<FMSIBSerialNumDataBean> getInstallBaseNoOfUnitsData() {
		return installBaseNoOfUnitsData;
	}
	public void setInstallBaseNoOfUnitsData(
			List<FMSIBSerialNumDataBean> installBaseNoOfUnitsData) {
		this.installBaseNoOfUnitsData = installBaseNoOfUnitsData;
	}
	
}
