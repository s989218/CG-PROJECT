package fms.bean;

import java.io.Serializable;

public class FMSIBSerialNumDataBean implements Serializable {

	private static final long serialVersionUID = -8331941553930330767L;
	
	private String installBaseSerialNum;
	private String installBaseRegion;
	private String installBaseLatitude;
	private String installBaseLongitude;
	
	public String getInstallBaseSerialNum() {
		return installBaseSerialNum;
	}
	public void setInstallBaseSerialNum(String installBaseSerialNum) {
		this.installBaseSerialNum = installBaseSerialNum;
	}
	public String getInstallBaseRegion() {
		return installBaseRegion;
	}
	public void setInstallBaseRegion(String installBaseRegion) {
		this.installBaseRegion = installBaseRegion;
	}
	public String getInstallBaseLatitude() {
		return installBaseLatitude;
	}
	public void setInstallBaseLatitude(String installBaseLatitude) {
		this.installBaseLatitude = installBaseLatitude;
	}
	public String getInstallBaseLongitude() {
		return installBaseLongitude;
	}
	public void setInstallBaseLongitude(String installBaseLongitude) {
		this.installBaseLongitude = installBaseLongitude;
	}
}
