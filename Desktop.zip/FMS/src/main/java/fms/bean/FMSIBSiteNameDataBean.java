package fms.bean;

import java.io.Serializable;

public class FMSIBSiteNameDataBean implements Serializable {

	private static final long serialVersionUID = -8331941553930330767L;
	private String siteName;
	private String region;
	private String latitude;
	private String longitude;
	private String serviceRelationDesc;
	
	public String getServiceRelationDesc() {
		return serviceRelationDesc;
	}
	public void setServiceRelationDesc(String serviceRelationDesc) {
		this.serviceRelationDesc = serviceRelationDesc;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}  
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	
	
	
}
