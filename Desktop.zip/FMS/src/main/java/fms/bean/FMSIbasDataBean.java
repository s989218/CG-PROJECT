package fms.bean;

import java.io.Serializable;

public class FMSIbasDataBean implements Serializable {

	private static final long serialVersionUID = 2971889018848295490L;
	private String ongRegion;  /*OnG_Region*/
	private String cSiteCustCntry; /*C_SITE_CUST_COUNTRY*/
	private String cGibSrNo; /*C_GIB_SERIAL_NUM*/
	private float nMaintPolicyId; /*N_MAINT_POLICY_ID*/
	private String cMaintPolicyCode; /*C_MAINT_POLICY_COD*/
	private String cMaintPolicyDesc; /*C_MAINT_POLICY_DESC*/
	private float nInstallLtDays; /*N_INSTALL_LT_DAYS*/
	private float nAvgRepairVal; /*N_AVG_REPAIR_VALUE*/
	private float nAvgPartsVal; /*N_AVG_PARTS_VALUE*/
	private float nAvgSvcsVal; /*N_AVG_SVCS_VALUE*/
	private String tOtherMaintPolicy; /*T_OTHER_MAINT_POLICY*/
	private String dEstManufComplete; /*D_EST_MANUF_COMPLETE*/
	private String dEstShipDate; /*D_EST_SHIP_DATE*/
	private String dEstSerStrtDate; /*D_EST_SERV_START_DATE*/
	private float nEstServHrsCnt; /*N_EST_SERV_HOURS_COUNT*/
	private String dEstServHrsDate; /*D_EST_SERV_HOURS_DATE*/
	private int nMaintYr; /*N_MAINT_YEAR*/
	private String cHqCustName; /*C_HQ_CUST_NAME*/
	private String cHqCustCntry; /*C_HQ_CUST_COUNTRY*/
	private String cDomCustDuns; /*C_DOM_CUST_DUNS*/
	private String cDomCustName; /*C_DOM_CUST_NAME*/
	private String cTechDesc; /*C_TECH_DESC*/
	private String cTechCodeOg; /*C_TECH_CODE_OG*/
	private String cTechDescOg; /*C_TECH_DESC_OG*/
	private String cEquipCode; /*C_EQUIP_CODE*/
	private String cEquipDesc; /*C_EQUIP_DESC*/
	private String cEquipEngDes; /*C_EQUIP_ENG_DESC*/
	private String cOemLocDesc; /*C_OEM_LOCATION_DESC*/
	private String dUnitShipDate;/*D_UNIT_SHIP_DATE*/
	private String dUnitCodDate; /*D_UNIT_COD_DATE*/
	private String cServMgrLast; /*C_SERV_MGR_LAST*/
	private String cMktSegmentDesc; /*C_MARKET_SEGMENT_DESC*/
	private String cMktIndustryDesc; /*C_MARKET_INDUSTRY_DESC*/
	private String cSalesChannelDesc; /*C_SALES_CHANNEL_DESC*/
	private String cServRelationDescGib; /*C_SERV_RELATION_DESC_GIB*/
	private String cControlSystemDesc; /*C_CONTROL_SYSTEM_DESC*/
	private String cServTypeDesc; /*C_SERV_TYPE_DESC*/
	private String cDrivenEquipDesc; /*C_DRIVEN_EQUIP_DESC*/
	private String cMkt; /*C_MARKET*/
	private String cProdEscPl; /*C_PROD_EXC_PL*/
	private int nFfhCnt; /*N_FFH_CNT*/
	private String cUnitStatusDesc; /*C_UNIT_STATUS_DESC*/
	private String cServRelnDescOng; /*C_SERV_RELATION_DESC_OG*/
	private String cGloCustDuns; /*C_GLO_CUST_DUNS*/
	private String cGloCustName; /*C_GLO_CUST_NAME*/
	private String level; /*level*/
	private int avmanpow; /*avmanpow*/
	private int avaux; /*avaux*/
	private float avf2f; /*avf2f*/
	private float avtot; /*avtot*/
	private String geGlobalDuns; /*geGlobalDuns*/
	private String geDunsName; /*geDunsName*/
	private String siteCustomerName;/*siteCustomerName*/
	private String ibasCSiteCustDuns;	// c_site_customer_duns
	private String ibasCSiteNameAlias;	// c_site_name_alias
	private String ibasCSiteCustCity;	// c_site_customer_city
	private String ibasCTierCod;	// c_tier_cod
	private String ibasCEngProjectRef;	// c_eng_project_ref
	private String ibasCOemSerialNumber;	// c_oem_serial_number
	private String ibasCParentSerialNumber;	// c_parent_serial_number
	private float ibasNServFactor;	// n_serv_factor
	private String ibasCAccountMgrLast;	// c_account_mgr_last
	private String cServMgrFirst;	// c_service_mgr_first

	
	public String getCServMgrFirst() {
		return cServMgrFirst;
	}
	public void setCServMgrFirst(String cServMgrFirst) {
		this.cServMgrFirst = cServMgrFirst;
	}
	public  String getOngRegion() {
		return ongRegion;
	}
	public  void setOngRegion(String ongRegion) {
		this.ongRegion = ongRegion;
	}
	public  String getcSiteCustCntry() {
		return cSiteCustCntry;
	}
	public  void setcSiteCustCntry(String cSiteCustCntry) {
		this.cSiteCustCntry = cSiteCustCntry;
	}
	public  String getcGibSrNo() {
		return cGibSrNo;
	}
	public  void setcGibSrNo(String cGibSrNo) {
		this.cGibSrNo = cGibSrNo;
	}
	public  float getnMaintPolicyId() {
		return nMaintPolicyId;
	}
	public  void setnMaintPolicyId(float nMaintPolicyId) {
		this.nMaintPolicyId = nMaintPolicyId;
	}
	public  String getcMaintPolicyCode() {
		return cMaintPolicyCode;
	}
	public  void setcMaintPolicyCode(String cMaintPolicyCode) {
		this.cMaintPolicyCode = cMaintPolicyCode;
	}
	public  String getcMaintPolicyDesc() {
		return cMaintPolicyDesc;
	}
	public  void setcMaintPolicyDesc(String cMaintPolicyDesc) {
		this.cMaintPolicyDesc = cMaintPolicyDesc;
	}
	public  float getnInstallLtDays() {
		return nInstallLtDays;
	}
	public  void setnInstallLtDays(float nInstallLtDays) {
		this.nInstallLtDays = nInstallLtDays;
	}
	public  float getnAvgRepairVal() {
		return nAvgRepairVal;
	}
	public  void setnAvgRepairVal(float nAvgRepairVal) {
		this.nAvgRepairVal = nAvgRepairVal;
	}
	public  float getnAvgPartsVal() {
		return nAvgPartsVal;
	}
	public  void setnAvgPartsVal(float nAvgPartsVal) {
		this.nAvgPartsVal = nAvgPartsVal;
	}
	public  float getnAvgSvcsVal() {
		return nAvgSvcsVal;
	}
	public  void setnAvgSvcsVal(float nAvgSvcsVal) {
		this.nAvgSvcsVal = nAvgSvcsVal;
	}
	public  String gettOtherMaintPolicy() {
		return tOtherMaintPolicy;
	}
	public  void settOtherMaintPolicy(String tOtherMaintPolicy) {
		this.tOtherMaintPolicy = tOtherMaintPolicy;
	}
	public  String getdEstManufComplete() {
		return dEstManufComplete;
	}
	public  void setdEstManufComplete(String dEstManufComplete) {
		this.dEstManufComplete = dEstManufComplete;
	}
	
	public String getdEstShipDate() {
		return dEstShipDate;
	}
	public void setdEstShipDate(String dEstShipDate) {
		this.dEstShipDate = dEstShipDate;
	}
	public String getdEstServHrsDate() {
		return dEstServHrsDate;
	}
	public void setdEstServHrsDate(String dEstServHrsDate) {
		this.dEstServHrsDate = dEstServHrsDate;
	}
	public String getdEstSerStrtDate() {
		return dEstSerStrtDate;
	}
	public void setdEstSerStrtDate(String dEstSerStrtDate) {
		this.dEstSerStrtDate = dEstSerStrtDate;
	}
	public  float getnEstServHrsCnt() {
		return nEstServHrsCnt;
	}
	public  void setnEstServHrsCnt(float nEstServHrsCnt) {
		this.nEstServHrsCnt = nEstServHrsCnt;
	}
	public  int getnMaintYr() {
		return nMaintYr;
	}
	public  void setnMaintYr(int nMaintYr) {
		this.nMaintYr = nMaintYr;
	}
	public  String getcHqCustName() {
		return cHqCustName;
	}
	public  void setcHqCustName(String cHqCustName) {
		this.cHqCustName = cHqCustName;
	}
	public  String getcHqCustCntry() {
		return cHqCustCntry;
	}
	public  void setcHqCustCntry(String cHqCustCntry) {
		this.cHqCustCntry = cHqCustCntry;
	}
	public  String getcDomCustDuns() {
		return cDomCustDuns;
	}
	public  void setcDomCustDuns(String cDomCustDuns) {
		this.cDomCustDuns = cDomCustDuns;
	}
	public  String getcDomCustName() {
		return cDomCustName;
	}
	public  void setcDomCustName(String cDomCustName) {
		this.cDomCustName = cDomCustName;
	}
	public  String getcTechDesc() {
		return cTechDesc;
	}
	public  void setcTechDesc(String cTechDesc) {
		this.cTechDesc = cTechDesc;
	}
	public  String getcTechCodeOg() {
		return cTechCodeOg;
	}
	public  void setcTechCodeOg(String cTechCodeOg) {
		this.cTechCodeOg = cTechCodeOg;
	}
	public  String getcTechDescOg() {
		return cTechDescOg;
	}
	public  void setcTechDescOg(String cTechDescOg) {
		this.cTechDescOg = cTechDescOg;
	}
	public  String getcEquipCode() {
		return cEquipCode;
	}
	public  void setcEquipCode(String cEquipCode) {
		this.cEquipCode = cEquipCode;
	}
	public  String getcEquipDesc() {
		return cEquipDesc;
	}
	public  void setcEquipDesc(String cEquipDesc) {
		this.cEquipDesc = cEquipDesc;
	}
	public  String getcEquipEngDes() {
		return cEquipEngDes;
	}
	public  void setcEquipEngDes(String cEquipEngDes) {
		this.cEquipEngDes = cEquipEngDes;
	}
	public  String getcOemLocDesc() {
		return cOemLocDesc;
	}
	public  void setcOemLocDesc(String cOemLocDesc) {
		this.cOemLocDesc = cOemLocDesc;
	}
	public String getdUnitShipDate() {
		return dUnitShipDate;
	}
	public void setdUnitShipDate(String dUnitShipDate) {
		this.dUnitShipDate = dUnitShipDate;
	}
	public String getdUnitCodDate() {
		return dUnitCodDate;
	}
	public void setdUnitCodDate(String dUnitCodDate) {
		this.dUnitCodDate = dUnitCodDate;
	}
	public  String getcServMgrLast() {
		return cServMgrLast;
	}
	public  void setcServMgrLast(String cServMgrLast) {
		this.cServMgrLast = cServMgrLast;
	}
	public  String getcMktSegmentDesc() {
		return cMktSegmentDesc;
	}
	public  void setcMktSegmentDesc(String cMktSegmentDesc) {
		this.cMktSegmentDesc = cMktSegmentDesc;
	}
	public  String getcMktIndustryDesc() {
		return cMktIndustryDesc;
	}
	public  void setcMktIndustryDesc(String cMktIndustryDesc) {
		this.cMktIndustryDesc = cMktIndustryDesc;
	}
	public  String getcSalesChannelDesc() {
		return cSalesChannelDesc;
	}
	public  void setcSalesChannelDesc(String cSalesChannelDesc) {
		this.cSalesChannelDesc = cSalesChannelDesc;
	}
	public  String getcServRelationDescGib() {
		return cServRelationDescGib;
	}
	public  void setcServRelationDescGib(String cServRelationDescGib) {
		this.cServRelationDescGib = cServRelationDescGib;
	}
	public  String getcControlSystemDesc() {
		return cControlSystemDesc;
	}
	public  void setcControlSystemDesc(String cControlSystemDesc) {
		this.cControlSystemDesc = cControlSystemDesc;
	}
	public  String getcServTypeDesc() {
		return cServTypeDesc;
	}
	public  void setcServTypeDesc(String cServTypeDesc) {
		this.cServTypeDesc = cServTypeDesc;
	}
	public  String getcDrivenEquipDesc() {
		return cDrivenEquipDesc;
	}
	public  void setcDrivenEquipDesc(String cDrivenEquipDesc) {
		this.cDrivenEquipDesc = cDrivenEquipDesc;
	}
	public  String getcMkt() {
		return cMkt;
	}
	public  void setcMkt(String cMkt) {
		this.cMkt = cMkt;
	}
	public  String getcProdEscPl() {
		return cProdEscPl;
	}
	public  void setcProdEscPl(String cProdEscPl) {
		this.cProdEscPl = cProdEscPl;
	}
	public  int getnFfhCnt() {
		return nFfhCnt;
	}
	public  void setnFfhCnt(int nFfhCnt) {
		this.nFfhCnt = nFfhCnt;
	}
	public  String getcUnitStatusDesc() {
		return cUnitStatusDesc;
	}
	public  void setcUnitStatusDesc(String cUnitStatusDesc) {
		this.cUnitStatusDesc = cUnitStatusDesc;
	}
	public  String getcServRelnDescOng() {
		return cServRelnDescOng;
	}
	public  void setcServRelnDescOng(String cServRelnDescOng) {
		this.cServRelnDescOng = cServRelnDescOng;
	}
	public  String getcGloCustDuns() {
		return cGloCustDuns;
	}
	public  void setcGloCustDuns(String cGloCustDuns) {
		this.cGloCustDuns = cGloCustDuns;
	}
	public  String getcGloCustName() {
		return cGloCustName;
	}
	public  void setcGloCustName(String cGloCustName) {
		this.cGloCustName = cGloCustName;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public int getAvmanpow() {
		return avmanpow;
	}
	public void setAvmanpow(int avmanpow) {
		this.avmanpow = avmanpow;
	}
	public int getAvaux() {
		return avaux;
	}
	public void setAvaux(int avaux) {
		this.avaux = avaux;
	}
	public float getAvf2f() {
		return avf2f;
	}
	public void setAvf2f(float avf2f) {
		this.avf2f = avf2f;
	}
	public float getAvtot() {
		return avtot;
	}
	public void setAvtot(float avtot) {
		this.avtot = avtot;
	}
	public String getGeGlobalDuns() {
		return geGlobalDuns;
	}
	public void setGeGlobalDuns(String geGlobalDuns) {
		this.geGlobalDuns = geGlobalDuns;
	}
	public String getGeDunsName() {
		return geDunsName;
	}
	public void setGeDunsName(String geDunsName) {
		this.geDunsName = geDunsName;
	}
	public String getSiteCustomerName() {
		return siteCustomerName;
	}
	public void setSiteCustomerName(String siteCustomerName) {
		this.siteCustomerName = siteCustomerName;
	}
	public String getIbasCSiteCustDuns() {
		return ibasCSiteCustDuns;
	}
	public void setIbasCSiteCustDuns(String ibasCSiteCustDuns) {
		this.ibasCSiteCustDuns = ibasCSiteCustDuns;
	}
	public String getIbasCSiteNameAlias() {
		return ibasCSiteNameAlias;
	}
	public void setIbasCSiteNameAlias(String ibasCSiteNameAlias) {
		this.ibasCSiteNameAlias = ibasCSiteNameAlias;
	}
	public String getIbasCSiteCustCity() {
		return ibasCSiteCustCity;
	}
	public void setIbasCSiteCustCity(String ibasCSiteCustCity) {
		this.ibasCSiteCustCity = ibasCSiteCustCity;
	}
	public String getIbasCTierCod() {
		return ibasCTierCod;
	}
	public void setIbasCTierCod(String ibasCTierCod) {
		this.ibasCTierCod = ibasCTierCod;
	}
	public String getIbasCEngProjectRef() {
		return ibasCEngProjectRef;
	}
	public void setIbasCEngProjectRef(String ibasCEngProjectRef) {
		this.ibasCEngProjectRef = ibasCEngProjectRef;
	}
	public String getIbasCOemSerialNumber() {
		return ibasCOemSerialNumber;
	}
	public void setIbasCOemSerialNumber(String ibasCOemSerialNumber) {
		this.ibasCOemSerialNumber = ibasCOemSerialNumber;
	}
	public String getIbasCParentSerialNumber() {
		return ibasCParentSerialNumber;
	}
	public void setIbasCParentSerialNumber(String ibasCParentSerialNumber) {
		this.ibasCParentSerialNumber = ibasCParentSerialNumber;
	}
	public float getIbasNServFactor() {
		return ibasNServFactor;
	}
	public void setIbasNServFactor(float ibasNServFactor) {
		this.ibasNServFactor = ibasNServFactor;
	}
	public String getIbasCAccountMgrLast() {
		return ibasCAccountMgrLast;
	}
	public void setIbasCAccountMgrLast(String ibasCAccountMgrLast) {
		this.ibasCAccountMgrLast = ibasCAccountMgrLast;
	}
}
