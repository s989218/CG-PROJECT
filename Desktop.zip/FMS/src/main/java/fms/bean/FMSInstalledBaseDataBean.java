package fms.bean;

import java.io.Serializable;

public class FMSInstalledBaseDataBean implements Serializable {
	
	private static final long serialVersionUID = -6076582436248922275L;
	private String ibDataRegion;  
	private String latitude;
	private String longitude;
	private String siteName;
	private String custName;
	private String siteCustCity;
	private String siteCustCountry;
	private String prodExcPL;
	private String marketSegmentDesc;
	private String serialNumber;
	private String technologyDescOG;
	private String unitShipData;
	private String estServiceHrsCount;
	private String serviceRelationDesc;
	private String avTot;
	private String level;
	private String techDesc;
	private String maintPolicyCOD;
	private String oemLocationDesc;
	private String unitRating;
	private String unitSpeedRPM;
	private String controlSystemDesc;
	private String drivenEquipDesc;
	private String combustionSystemDesc;
	private String primaryFuelTypeDesc;
	private String equipmentModel;
	private String unitCustomerName;
	private String eventDate;
	private String eventType;
	private String eventStatus;
	private String equipmentEngDesc;
	private String equipmentCode;
	
	
	
	public String getEquipmentEngDesc() {
		return equipmentEngDesc;
	}
	public void setEquipmentEngDesc(String equipmentEngDesc) {
		this.equipmentEngDesc = equipmentEngDesc;
	}
	public String getEquipmentCode() {
		return equipmentCode;
	}
	public void setEquipmentCode(String equipmentCode) {
		this.equipmentCode = equipmentCode;
	}
	public String getEventDate() {
		return eventDate;
	}
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getEventStatus() {
		return eventStatus;
	}
	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}
	public String getEquipmentModel() {
		return equipmentModel;
	}
	public void setEquipmentModel(String equipmentModel) {
		this.equipmentModel = equipmentModel;
	}
	public String getUnitCustomerName() {
		return unitCustomerName;
	}
	public void setUnitCustomerName(String unitCustomerName) {
		this.unitCustomerName = unitCustomerName;
	}
	public String getIbDataRegion() {
		return ibDataRegion;
	}
	public void setIbDataRegion(String ibDataRegion) {
		this.ibDataRegion = ibDataRegion;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getSiteCustCity() {
		return siteCustCity;
	}
	public void setSiteCustCity(String siteCustCity) {
		this.siteCustCity = siteCustCity;
	}
	public String getSiteCustCountry() {
		return siteCustCountry;
	}
	public void setSiteCustCountry(String siteCustCountry) {
		this.siteCustCountry = siteCustCountry;
	}
	public String getProdExcPL() {
		return prodExcPL;
	}
	public void setProdExcPL(String prodExcPL) {
		this.prodExcPL = prodExcPL;
	}
	public String getMarketSegmentDesc() {
		return marketSegmentDesc;
	}
	public void setMarketSegmentDesc(String marketSegmentDesc) {
		this.marketSegmentDesc = marketSegmentDesc;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	public String getTechnologyDescOG() {
		return technologyDescOG;
	}
	public void setTechnologyDescOG(String technologyDescOG) {
		this.technologyDescOG = technologyDescOG;
	}
	public String getUnitShipData() {
		return unitShipData;
	}
	public void setUnitShipData(String unitShipData) {
		this.unitShipData = unitShipData;
	}
	public String getEstServiceHrsCount() {
		return estServiceHrsCount;
	}
	public void setEstServiceHrsCount(String estServiceHrsCount) {
		this.estServiceHrsCount = estServiceHrsCount;
	}
	public String getServiceRelationDesc() {
		return serviceRelationDesc;
	}
	public void setServiceRelationDesc(String serviceRelationDesc) {
		this.serviceRelationDesc = serviceRelationDesc;
	}
	public String getAvTot() {
		return avTot;
	}
	public void setAvTot(String avTot) {
		this.avTot = avTot;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getTechDesc() {
		return techDesc;
	}
	public void setTechDesc(String techDesc) {
		this.techDesc = techDesc;
	}
	public String getMaintPolicyCOD() {
		return maintPolicyCOD;
	}
	public void setMaintPolicyCOD(String maintPolicyCOD) {
		this.maintPolicyCOD = maintPolicyCOD;
	}
	public String getOemLocationDesc() {
		return oemLocationDesc;
	}
	public void setOemLocationDesc(String oemLocationDesc) {
		this.oemLocationDesc = oemLocationDesc;
	}
	public String getUnitRating() {
		return unitRating;
	}
	public void setUnitRating(String unitRating) {
		this.unitRating = unitRating;
	}
	public String getUnitSpeedRPM() {
		return unitSpeedRPM;
	}
	public void setUnitSpeedRPM(String unitSpeedRPM) {
		this.unitSpeedRPM = unitSpeedRPM;
	}
	public String getControlSystemDesc() {
		return controlSystemDesc;
	}
	public void setControlSystemDesc(String controlSystemDesc) {
		this.controlSystemDesc = controlSystemDesc;
	}
	public String getDrivenEquipDesc() {
		return drivenEquipDesc;
	}
	public void setDrivenEquipDesc(String drivenEquipDesc) {
		this.drivenEquipDesc = drivenEquipDesc;
	}
	public String getCombustionSystemDesc() {
		return combustionSystemDesc;
	}
	public void setCombustionSystemDesc(String combustionSystemDesc) {
		this.combustionSystemDesc = combustionSystemDesc;
	}
	public String getPrimaryFuelTypeDesc() {
		return primaryFuelTypeDesc;
	}
	public void setPrimaryFuelTypeDesc(String primaryFuelTypeDesc) {
		this.primaryFuelTypeDesc = primaryFuelTypeDesc;
	}
	
	
	
	
}
