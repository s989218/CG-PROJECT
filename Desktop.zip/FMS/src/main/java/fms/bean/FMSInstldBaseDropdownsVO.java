package fms.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class FMSInstldBaseDropdownsVO implements Serializable {
	
	private static final long serialVersionUID = 3111225565983061483L;
	
	private List<FMSRegionDropdownBean> regionDropdownBean;
	private List<FMSSiteDropdownBean> siteDropdownBean;
	private List<FMSTechnologyDropdownBean> technologyDropdownBean;
	private List<FMSStringDropdownBean> marketDDBean;
	private List<FMSStringDropdownBean> installBaseSiteCustAliasDDBean;
	private List<FMSStringDropdownBean> installBaseOEMLocDDBean;
	private List<FMSSiteCustomerNameDropdownBean> installBaseSiteCustNameDDBean;
	private List<FMSServRelDescOngDropdownBean>  installBaseServRelationDDBean;
	private transient List<Map<String, Object>>  countryDropdownBean ;
	private transient List<Map<String, Object>>  accountManagerDropdownBean;
	private transient List<Map<String, Object>>  geDunsNameDropdownBean;
	
	
	
	
	public List<Map<String, Object>> getCountryDropdownBean() {
		return countryDropdownBean;
	}
	public void setCountryDropdownBean(List<Map<String, Object>> countryDropdownBean) {
		this.countryDropdownBean = countryDropdownBean;
	}
	public List<Map<String, Object>> getAccountManagerDropdownBean() {
		return accountManagerDropdownBean;
	}
	public void setAccountManagerDropdownBean(
			List<Map<String, Object>> accountManagerDropdownBean) {
		this.accountManagerDropdownBean = accountManagerDropdownBean;
	}
	public List<Map<String, Object>> getGeDunsNameDropdownBean() {
		return geDunsNameDropdownBean;
	}
	public void setGeDunsNameDropdownBean(
			List<Map<String, Object>> geDunsNameDropdownBean) {
		this.geDunsNameDropdownBean = geDunsNameDropdownBean;
	}
	public List<FMSRegionDropdownBean> getRegionDropdownBean() {
		return regionDropdownBean;
	}
	public void setRegionDropdownBean(List<FMSRegionDropdownBean> regionDropdownBean) {
		this.regionDropdownBean = regionDropdownBean;
	}
	public List<FMSSiteDropdownBean> getSiteDropdownBean() {
		return siteDropdownBean;
	}
	public void setSiteDropdownBean(List<FMSSiteDropdownBean> siteDropdownBean) {
		this.siteDropdownBean = siteDropdownBean;
	}
	public List<FMSTechnologyDropdownBean> getTechnologyDropdownBean() {
		return technologyDropdownBean;
	}
	public void setTechnologyDropdownBean(
			List<FMSTechnologyDropdownBean> technologyDropdownBean) {
		this.technologyDropdownBean = technologyDropdownBean;
	}
	public List<FMSStringDropdownBean> getMarketDDBean() {
		return marketDDBean;
	}
	public void setMarketDDBean(List<FMSStringDropdownBean> marketDDBean) {
		this.marketDDBean = marketDDBean;
	}
	public List<FMSStringDropdownBean> getInstallBaseSiteCustAliasDDBean() {
		return installBaseSiteCustAliasDDBean;
	}
	public void setInstallBaseSiteCustAliasDDBean(
			List<FMSStringDropdownBean> installBaseSiteCustAliasDDBean) {
		this.installBaseSiteCustAliasDDBean = installBaseSiteCustAliasDDBean;
	}
	public List<FMSStringDropdownBean> getInstallBaseOEMLocDDBean() {
		return installBaseOEMLocDDBean;
	}
	public void setInstallBaseOEMLocDDBean(
			List<FMSStringDropdownBean> installBaseOEMLocDDBean) {
		this.installBaseOEMLocDDBean = installBaseOEMLocDDBean;
	}
	public List<FMSSiteCustomerNameDropdownBean> getInstallBaseSiteCustNameDDBean() {
		return installBaseSiteCustNameDDBean;
	}
	public void setInstallBaseSiteCustNameDDBean(
			List<FMSSiteCustomerNameDropdownBean> installBaseSiteCustNameDDBean) {
		this.installBaseSiteCustNameDDBean = installBaseSiteCustNameDDBean;
	}
	public List<FMSServRelDescOngDropdownBean> getInstallBaseServRelationDDBean() {
		return installBaseServRelationDDBean;
	}
	public void setInstallBaseServRelationDDBean(
			List<FMSServRelDescOngDropdownBean> installBaseServRelationDDBean) {
		this.installBaseServRelationDDBean = installBaseServRelationDDBean;
	}
}
