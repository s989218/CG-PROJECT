package fms.bean;

import java.io.Serializable;

public class FMSLegalEntityDescDropdownBean implements Serializable {

	private static final long serialVersionUID = 9213835612561798804L;
	private String legalEntityDesc;

	public String getLegalEntityDesc() {
		return legalEntityDesc;
	}

	public void setLegalEntityDesc(String legalEntityDesc) {
		this.legalEntityDesc = legalEntityDesc;
	}

}
