package fms.bean;

import java.io.Serializable;

public class FMSLevelDropdownBean implements Serializable {
	
	private static final long serialVersionUID = -7070118243083326718L;
	private String level;

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}
	

}
