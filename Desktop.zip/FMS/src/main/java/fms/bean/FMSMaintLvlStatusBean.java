package fms.bean;

import java.io.Serializable;

public class FMSMaintLvlStatusBean implements Serializable{

	private static final long serialVersionUID = 1117048811859016904L;
	private String oEventStatusDesc;

	public String getoEventStatusDesc() {
		return oEventStatusDesc;
	}

	public void setoEventStatusDesc(String oEventStatusDesc) {
		this.oEventStatusDesc = oEventStatusDesc;
	}

}
