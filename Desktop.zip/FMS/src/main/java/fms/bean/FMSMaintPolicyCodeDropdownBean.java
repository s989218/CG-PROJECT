package fms.bean;

import java.io.Serializable;

public class FMSMaintPolicyCodeDropdownBean implements Serializable {

	private static final long serialVersionUID = 4244919399900823628L;
	private String maintPolicyCode;

	public String getMaintPolicyCode() {
		return maintPolicyCode;
	}

	public void setMaintPolicyCode(String maintPolicyCode) {
		this.maintPolicyCode = maintPolicyCode;
	}
	
}
