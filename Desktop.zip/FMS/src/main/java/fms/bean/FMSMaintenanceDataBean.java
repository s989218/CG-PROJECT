package fms.bean;

import java.io.Serializable;


public class FMSMaintenanceDataBean implements Serializable {
	
	private static final long serialVersionUID = -1483333127863545246L;
	private String id;
	private String policy;
	private String policyAggr;
	private String level;
	private String hours;
	private String age;
	private String parts;
	private String repairs;
	private String services;
	private String manpower;
	private String aux;
	private String total;

	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getPolicy() {
		return policy;
	}



	public void setPolicy(String policy) {
		this.policy = policy;
	}



	public String getPolicyAggr() {
		return policyAggr;
	}



	public void setPolicyAggr(String policyAggr) {
		this.policyAggr = policyAggr;
	}



	public String getLevel() {
		return level;
	}



	public void setLevel(String level) {
		this.level = level;
	}



	public String getHours() {
		return hours;
	}



	public void setHours(String hours) {
		this.hours = hours;
	}



	public String getAge() {
		return age;
	}



	public void setAge(String age) {
		this.age = age;
	}



	public String getParts() {
		return parts;
	}



	public void setParts(String parts) {
		this.parts = parts;
	}



	public String getRepairs() {
		return repairs;
	}



	public void setRepairs(String repairs) {
		this.repairs = repairs;
	}



	public String getServices() {
		return services;
	}



	public void setServices(String services) {
		this.services = services;
	}



	public String getManpower() {
		return manpower;
	}



	public void setManpower(String manpower) {
		this.manpower = manpower;
	}



	public String getAux() {
		return aux;
	}



	public void setAux(String aux) {
		this.aux = (aux==null)?"0":aux;
		
	}



	public String getTotal() {
		return total;
	}



	public void setTotal(String total) {
		this.total = total;
	}

		
}
