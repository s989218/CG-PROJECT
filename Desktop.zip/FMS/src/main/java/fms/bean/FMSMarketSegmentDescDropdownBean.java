package fms.bean;

import java.io.Serializable;

public class FMSMarketSegmentDescDropdownBean implements Serializable {

	private static final long serialVersionUID = 6799261799594983762L;
	private String marketSegmentDesc;

	public String getMarketSegmentDesc() {
		return marketSegmentDesc;
	}

	public void setMarketSegmentDesc(String marketSegmentDesc) {
		this.marketSegmentDesc = marketSegmentDesc;
	}
	
}
