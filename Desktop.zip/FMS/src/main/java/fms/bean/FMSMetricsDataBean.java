package fms.bean;

import java.io.Serializable;

public class FMSMetricsDataBean implements Serializable {
	
	private static final long serialVersionUID = -4511417691148215494L;
	private String metricsDataRegion;  
	private String metricsDataYear;
	private String metricsDataQuarter;
	private float coverageValue;
	private float penetrationValue;
	private float dollarByIBValue;
	private float fleetPenF2FValue;
	private float caloricIndexValue;
	private float conversionIndexValue;
	private float iboByRegionValue;
	private float revDollarByRegionValue;
	
	
	public String getMetricsDataRegion() {
		return metricsDataRegion;
	}
	public void setMetricsDataRegion(String metricsDataRegion) {
		this.metricsDataRegion = metricsDataRegion;
	}
	public String getMetricsDataYear() {
		return metricsDataYear;
	}
	public void setMetricsDataYear(String metricsDataYear) {
		this.metricsDataYear = metricsDataYear;
	}
	public String getMetricsDataQuarter() {
		return metricsDataQuarter;
	}
	public void setMetricsDataQuarter(String metricsDataQuarter) {
		this.metricsDataQuarter = metricsDataQuarter;
	}
	public float getCoverageValue() {
		return coverageValue;
	}
	public void setCoverageValue(float coverageValue) {
		this.coverageValue = coverageValue;
	}
	public float getPenetrationValue() {
		return penetrationValue;
	}
	public void setPenetrationValue(float penetrationValue) {
		this.penetrationValue = penetrationValue;
	}
	public float getDollarByIBValue() {
		return dollarByIBValue;
	}
	public void setDollarByIBValue(float dollarByIBValue) {
		this.dollarByIBValue = dollarByIBValue;
	}
	public float getFleetPenF2FValue() {
		return fleetPenF2FValue;
	}
	public void setFleetPenF2FValue(float fleetPenF2FValue) {
		this.fleetPenF2FValue = fleetPenF2FValue;
	}
	public float getCaloricIndexValue() {
		return caloricIndexValue;
	}
	public void setCaloricIndexValue(float caloricIndexValue) {
		this.caloricIndexValue = caloricIndexValue;
	}
	public float getConversionIndexValue() {
		return conversionIndexValue;
	}
	public void setConversionIndexValue(float conversionIndexValue) {
		this.conversionIndexValue = conversionIndexValue;
	}
	public float getIboByRegionValue() {
		return iboByRegionValue;
	}
	public void setIboByRegionValue(float iboByRegionValue) {
		this.iboByRegionValue = iboByRegionValue;
	}
	public float getRevDollarByRegionValue() {
		return revDollarByRegionValue;
	}
	public void setRevDollarByRegionValue(float revDollarByRegionValue) {
		this.revDollarByRegionValue = revDollarByRegionValue;
	}
	
	
	
}
