package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSMetricsDataVO implements Serializable {
	
	private static final long serialVersionUID = -1338951979423198007L;
	private List<FMSMetricsDataBean> hisMetricsdata;
	private List<FMSMetricsDataBean> curMetricsdata;
	
	public List<FMSMetricsDataBean> getHisMetricsdata() {
		return hisMetricsdata;
	}
	public void setHisMetricsdata(List<FMSMetricsDataBean> hisMetricsdata) {
		this.hisMetricsdata = hisMetricsdata;
	}
	public List<FMSMetricsDataBean> getCurMetricsdata() {
		return curMetricsdata;
	}
	public void setCurMetricsdata(List<FMSMetricsDataBean> curMetricsdata) {
		this.curMetricsdata = curMetricsdata;
	}
	

}
