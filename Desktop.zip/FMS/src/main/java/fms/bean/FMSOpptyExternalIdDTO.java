package fms.bean;

import java.io.Serializable;

public class FMSOpptyExternalIdDTO implements Serializable{

	private static final long serialVersionUID = -3218631027307319203L;
	private String opptyExternalId;
	public String getOpptyExternalId() {
		return opptyExternalId;
	}
	public void setOpptyExternalId(String opptyExternalId) {
		this.opptyExternalId = opptyExternalId;
	}
	
}
