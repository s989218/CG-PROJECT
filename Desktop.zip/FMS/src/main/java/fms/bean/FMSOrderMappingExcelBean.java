package fms.bean;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

/***
 *  
 * @author kdhamans
 *
 */

public class FMSOrderMappingExcelBean implements SQLData {


	private String  mmCmgmtEntityCode ;
	private String  mmMappingInclSCCorrections ;
	private String  mmPandL ;
	private String  mmSVCEQ ;
	private String  mmTierThree ;
	private String  mmDMTierThree ;
	private String  mmTierFour ;
	private String  mmUsage ;

	private String  skCSrcNewSegment ;
	private String  skSegmentMapping ;

	private String  pkCProductTypeDesc ;
	private String  pkProductMapping ;
	
	

	public String getMmCmgmtEntityCode() {
		return mmCmgmtEntityCode;
	}

	public void setMmCmgmtEntityCode(String mmCmgmtEntityCode) {
		this.mmCmgmtEntityCode = mmCmgmtEntityCode;
	}

	public String getMmMappingInclSCCorrections() {
		return mmMappingInclSCCorrections;
	}

	public void setMmMappingInclSCCorrections(String mmMappingInclSCCorrections) {
		this.mmMappingInclSCCorrections = mmMappingInclSCCorrections;
	}

	public String getMmPandL() {
		return mmPandL;
	}

	public void setMmPandL(String mmPandL) {
		this.mmPandL = mmPandL;
	}

	public String getMmSVCEQ() {
		return mmSVCEQ;
	}

	public void setMmSVCEQ(String mmSVCEQ) {
		this.mmSVCEQ = mmSVCEQ;
	}

	public String getMmTierThree() {
		return mmTierThree;
	}

	public void setMmTierThree(String mmTierThree) {
		this.mmTierThree = mmTierThree;
	}

	public String getMmDMTierThree() {
		return mmDMTierThree;
	}

	public void setMmDMTierThree(String mmDMTierThree) {
		this.mmDMTierThree = mmDMTierThree;
	}

	public String getMmTierFour() {
		return mmTierFour;
	}

	public void setMmTierFour(String mmTierFour) {
		this.mmTierFour = mmTierFour;
	}

	public String getMmUsage() {
		return mmUsage;
	}

	public void setMmUsage(String mmUsage) {
		this.mmUsage = mmUsage;
	}

	public String getSkCSrcNewSegment() {
		return skCSrcNewSegment;
	}

	public void setSkCSrcNewSegment(String skCSrcNewSegment) {
		this.skCSrcNewSegment = skCSrcNewSegment;
	}

	public String getSkSegmentMapping() {
		return skSegmentMapping;
	}

	public void setSkSegmentMapping(String skSegmentMapping) {
		this.skSegmentMapping = skSegmentMapping;
	}

	public String getPkCProductTypeDesc() {
		return pkCProductTypeDesc;
	}

	public void setPkCProductTypeDesc(String pkCProductTypeDesc) {
		this.pkCProductTypeDesc = pkCProductTypeDesc;
	}

	public String getPkProductMapping() {
		return pkProductMapping;
	}

	public void setPkProductMapping(String pkProductMapping) {
		this.pkProductMapping = pkProductMapping;
	}

	@Override
	public void readSQL(SQLInput stream, String arg1) throws SQLException {

		setMmCmgmtEntityCode(stream.readString());
		setMmMappingInclSCCorrections(stream.readString());
		setMmPandL(stream.readString());
		setMmSVCEQ(stream.readString());
		setMmTierThree(stream.readString());
		setMmDMTierThree(stream.readString());
		setMmTierFour(stream.readString());
		setMmUsage(stream.readString());

		setSkCSrcNewSegment(stream.readString());
		setSkSegmentMapping(stream.readString());

		setPkCProductTypeDesc(stream.readString());
		setPkProductMapping(stream.readString());
	}

	@Override
	public void writeSQL(SQLOutput arg0) throws SQLException {
	/**
	 * Its implementing interface of SQLData.
	 * 
	 */
	}

	@Override
	public String getSQLTypeName() throws SQLException {
		return null;
	}



}
