package fms.bean;

import java.io.Serializable;

public class FMSOrderRegionDropdownBean implements Serializable {
	
	private static final long serialVersionUID = 7338664924538447444L;
	private String orderRegion;
	private String orderRegionId;
	public String getOrderRegion() {
		return orderRegion;
	}
	public void setOrderRegion(String orderRegion) {
		this.orderRegion = orderRegion;
	}
	public String getOrderRegionId() {
		return orderRegionId;
	}
	public void setOrderRegionId(String orderRegionId) {
		this.orderRegionId = orderRegionId;
	}
	
	
}
