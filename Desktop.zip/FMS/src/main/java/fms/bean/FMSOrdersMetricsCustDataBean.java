package fms.bean;

import java.io.Serializable;

public class FMSOrdersMetricsCustDataBean implements Serializable {

	private static final long serialVersionUID = -4743310763561728577L;
	private String orderCustRegion;  
	private String orderCustEndUserName;
	private String orderCustOrdersSum;
	private String orderCustCountry;
	private String orderCustTechnology;
	private String orderCustTechOrderSum;
	private String orderCustColorCode;
	public String getOrderCustRegion() {
		return orderCustRegion;
	}
	public void setOrderCustRegion(String orderCustRegion) {
		this.orderCustRegion = orderCustRegion;
	}
	public String getOrderCustEndUserName() {
		return orderCustEndUserName;
	}
	public void setOrderCustEndUserName(String orderCustEndUserName) {
		this.orderCustEndUserName = orderCustEndUserName;
	}
	public String getOrderCustOrdersSum() {
		return orderCustOrdersSum;
	}
	public void setOrderCustOrdersSum(String orderCustOrdersSum) {
		this.orderCustOrdersSum = orderCustOrdersSum;
	}
	public String getOrderCustCountry() {
		return orderCustCountry;
	}
	public void setOrderCustCountry(String orderCustCountry) {
		this.orderCustCountry = orderCustCountry;
	}
	public String getOrderCustTechnology() {
		return orderCustTechnology;
	}
	public void setOrderCustTechnology(String orderCustTechnology) {
		this.orderCustTechnology = orderCustTechnology;
	}
	public String getOrderCustTechOrderSum() {
		return orderCustTechOrderSum;
	}
	public void setOrderCustTechOrderSum(String orderCustTechOrderSum) {
		this.orderCustTechOrderSum = orderCustTechOrderSum;
	}
	public String getOrderCustColorCode() {
		return orderCustColorCode;
	}
	public void setOrderCustColorCode(String orderCustColorCode) {
		this.orderCustColorCode = orderCustColorCode;
	}
}
