package fms.bean;
import java.io.Serializable;

public class FMSOrdersMetricsDataBean implements Serializable{


	private static final long serialVersionUID = 3341900995399472211L;
	private String countryName; 
	private String serviceType;
	private String endUserName;
	private String region;
	private String geDunsName;
	private String smSegmentMapping;
	private String pmProductMapping;
	private String meTier4;
	private String meDMTier3;
	private String ordersState;
	private String ordersBusinessSegment;
	private String accountManager;
	private String marketIndustry;


	public String getMarketIndustry() {
		return marketIndustry;
	}
	public void setMarketIndustry(String marketIndustry) {
		this.marketIndustry = marketIndustry;
	}
	public String getAccountManager() {
		return accountManager;
	}
	public void setAccountManager(String accountManager) {
		this.accountManager = accountManager;
	}
	public String getOrdersBusinessSegment() {
		return ordersBusinessSegment;
	}
	public void setOrdersBusinessSegment(String ordersBusinessSegment) {
		this.ordersBusinessSegment = ordersBusinessSegment;
	}
	public String getOrdersState() {
		return ordersState;
	}
	public void setOrdersState(String ordersState) {
		this.ordersState = ordersState;
	}

	public String getRegion() {
		return region;
	}
	public String getGeDunsName() {
		return geDunsName;
	}
	public void setGeDunsName(String geDunsName) {
		this.geDunsName = geDunsName;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getEndUserName() {
		return endUserName;
	}
	public void setEndUserName(String endUserName) {
		this.endUserName = endUserName;
	}
	public String getSmSegmentMapping() {
		return smSegmentMapping;
	}
	public void setSmSegmentMapping(String smSegmentMapping) {
		this.smSegmentMapping = smSegmentMapping;
	}
	public String getPmProductMapping() {
		return pmProductMapping;
	}
	public void setPmProductMapping(String pmProductMapping) {
		this.pmProductMapping = pmProductMapping;
	}
	public String getMeTier4() {
		return meTier4;
	}
	public void setMeTier4(String meTier4) {
		this.meTier4 = meTier4;
	}
	public String getMeDMTier3() {
		return meDMTier3;
	}
	public void setMeDMTier3(String meDMTier3) {
		this.meDMTier3 = meDMTier3;
	}
}
