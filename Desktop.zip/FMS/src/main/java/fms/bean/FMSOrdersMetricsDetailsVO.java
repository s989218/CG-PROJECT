package fms.bean;

import java.io.Serializable;
import java.util.List;
import fms.bean.FMSOrdersMetricsCustDataBean;


public class FMSOrdersMetricsDetailsVO implements Serializable {
	
	private static final long serialVersionUID = 2762278291950474355L;
	private List<FMSOrdersMetricsTechDataBean> technologyDataBean;
	private List<FMSOrdersMetricsCustDataBean> custNameDataBean;
	public List<FMSOrdersMetricsTechDataBean> getTechnologyDataBean() {
		return technologyDataBean;
	}
	public void setTechnologyDataBean(
			List<FMSOrdersMetricsTechDataBean> technologyDataBean) {
		this.technologyDataBean = technologyDataBean;
	}
	public List<FMSOrdersMetricsCustDataBean> getCustNameDataBean() {
		return custNameDataBean;
	}
	public void setCustNameDataBean(
			List<FMSOrdersMetricsCustDataBean> custNameDataBean) {
		this.custNameDataBean = custNameDataBean;
	}
	

}
