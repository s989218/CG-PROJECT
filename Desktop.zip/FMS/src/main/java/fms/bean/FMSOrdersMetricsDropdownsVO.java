package fms.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class FMSOrdersMetricsDropdownsVO implements Serializable {

	private static final long serialVersionUID = -426750680850635943L;
	
	private List<FMSCountryNameDropdownBean> countryNameDropdownData;
	private List<FMSServiceTypeDropdownBean> serviceTypeDropdownData;
	private List<FMSEndUserNameDropdownBean> endUserNameDropdownData;
	private List<FMSOrderRegionDropdownBean> regionDropdownBean;
	private List<FMSSiteCustomerNameDropdownBean> geCustomerDunsName;
	private List<FMSStringDropdownBean> smSegmentMappingDDBean;
	private List<FMSStringDropdownBean> pmProductMappingDDBean;
	private List<FMSStringDropdownBean> meTier4DDBean;
	private List<FMSStringDropdownBean> meDMTier3DDBean;
    private transient List<Map<String, Object>> stateDropdownData;
    private transient List<Map<String, Object>> businessSegmentDropdownData;
	
	
	
	public List<Map<String, Object>> getBusinessSegmentDropdownData() {
		return businessSegmentDropdownData;
	}
	public void setBusinessSegmentDropdownData(
			List<Map<String, Object>> businessSegmentDropdownData) {
		this.businessSegmentDropdownData = businessSegmentDropdownData;
	}
	public List<Map<String, Object>> getStateDropdownData() {
		return stateDropdownData;
	}
	public void setStateDropdownData(List<Map<String, Object>> stateDropdownData) {
		this.stateDropdownData = stateDropdownData;
	}
	
	
	public List<FMSCountryNameDropdownBean> getCountryNameDropdownData() {
		return countryNameDropdownData;
	}
	public void setCountryNameDropdownData(
			List<FMSCountryNameDropdownBean> countryNameDropdownData) {
		this.countryNameDropdownData = countryNameDropdownData;
	}
	public List<FMSServiceTypeDropdownBean> getServiceTypeDropdownData() {
		return serviceTypeDropdownData;
	}
	public void setServiceTypeDropdownData(
			List<FMSServiceTypeDropdownBean> serviceTypeDropdownData) {
		this.serviceTypeDropdownData = serviceTypeDropdownData;
	}
	public List<FMSEndUserNameDropdownBean> getEndUserNameDropdownData() {
		return endUserNameDropdownData;
	}
	public void setEndUserNameDropdownData(
			List<FMSEndUserNameDropdownBean> endUserNameDropdownData) {
		this.endUserNameDropdownData = endUserNameDropdownData;
	}
	public List<FMSOrderRegionDropdownBean> getRegionDropdownBean() {
		return regionDropdownBean;
	}
	public void setRegionDropdownBean(List<FMSOrderRegionDropdownBean> regionDropdownBean) {
		this.regionDropdownBean = regionDropdownBean;
	}
	public List<FMSSiteCustomerNameDropdownBean> getGeCustomerDunsName() {
		return geCustomerDunsName;
	}
	public void setGeCustomerDunsName(
			List<FMSSiteCustomerNameDropdownBean> geCustomerDunsName) {
		this.geCustomerDunsName = geCustomerDunsName;
	}
	public List<FMSStringDropdownBean> getSmSegmentMappingDDBean() {
		return smSegmentMappingDDBean;
	}
	public void setSmSegmentMappingDDBean(
			List<FMSStringDropdownBean> smSegmentMappingDDBean) {
		this.smSegmentMappingDDBean = smSegmentMappingDDBean;
	}
	public List<FMSStringDropdownBean> getPmProductMappingDDBean() {
		return pmProductMappingDDBean;
	}
	public void setPmProductMappingDDBean(
			List<FMSStringDropdownBean> pmProductMappingDDBean) {
		this.pmProductMappingDDBean = pmProductMappingDDBean;
	}
	public List<FMSStringDropdownBean> getMeTier4DDBean() {
		return meTier4DDBean;
	}
	public void setMeTier4DDBean(List<FMSStringDropdownBean> meTier4DDBean) {
		this.meTier4DDBean = meTier4DDBean;
	}
	public List<FMSStringDropdownBean> getMeDMTier3DDBean() {
		return meDMTier3DDBean;
	}
	public void setMeDMTier3DDBean(List<FMSStringDropdownBean> meDMTier3DDBean) {
		this.meDMTier3DDBean = meDMTier3DDBean;
	}
}
