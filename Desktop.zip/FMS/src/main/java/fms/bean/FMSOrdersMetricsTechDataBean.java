package fms.bean;

import java.io.Serializable;

public class FMSOrdersMetricsTechDataBean implements Serializable {
	
	private static final long serialVersionUID = 3341900995399472212L;
	private String orderTechRegion;  
	private String orderTechProduct;
	private String orderTechOrdersSum;
	private String orderTechRegionId; 
	private String orderTechCountry;
	private String orderColorCode;
	
	public String getOrderColorCode() {
		return orderColorCode;
	}
	public void setOrderColorCode(String orderColorCode) {
		this.orderColorCode = orderColorCode;
	}
	public String getOrderTechRegion() {
		return orderTechRegion;
	}
	public void setOrderTechRegion(String orderTechRegion) {
		this.orderTechRegion = orderTechRegion;
	}
	public String getOrderTechProduct() {
		return orderTechProduct;
	}
	public void setOrderTechProduct(String orderTechProduct) {
		this.orderTechProduct = orderTechProduct;
	}
	public String getOrderTechOrdersSum() {
		return orderTechOrdersSum;
	}
	public void setOrderTechOrdersSum(String orderTechOrdersSum) {
		this.orderTechOrdersSum = orderTechOrdersSum;
	}
	public String getOrderTechRegionId() {
		return orderTechRegionId;
	}
	public void setOrderTechRegionId(String orderTechRegionId) {
		this.orderTechRegionId = orderTechRegionId;
	}
	public String getOrderTechCountry() {
		return orderTechCountry;
	}
	public void setOrderTechCountry(String orderTechCountry) {
		this.orderTechCountry = orderTechCountry;
	}
	
	
	

}
