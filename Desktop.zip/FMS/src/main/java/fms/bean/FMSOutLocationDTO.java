package fms.bean;

import java.io.Serializable;

public class FMSOutLocationDTO implements Serializable{

	private static final long serialVersionUID = 4787319205786098207L;
	private String loactionDesc;
	public String getLoactionDesc() {
		return loactionDesc;
	}
	public void setLoactionDesc(String loactionDesc) {
		this.loactionDesc = loactionDesc;
	}
}
