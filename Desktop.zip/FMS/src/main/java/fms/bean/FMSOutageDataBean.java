package fms.bean;

import java.io.Serializable;

public class FMSOutageDataBean implements Serializable {

	private static final long serialVersionUID = 2971889018848295490L;
	
	
	
	private int    nEventId;										
	private String cGibSerialNumber;
	private int    nMaintPolicyCyc;
	private int    nMaintLevelSeq;
	private String dEventDate;
	private String tEventNotes;
	private String cDemSvcsStatus;
	private String cUsrIns;
	private String dIns;
	private String cEventDemStatusParts;
	private String cEventDemStatusSvcs;
	private String ceventDemStatusRepairs;
	private String fUnsolicedStatusFlag;
	private String cGibSerialNumber2;   // no db column
	private String dEstServiceStartDate;
	private double    nEstServHoursCount;
	private int    nMaintYear;
	private String cCustLoyaltyDescParts;
	private String cCustBehaviorDescParts;
	private String cSiteCustomerDuns;
	private String cSiteCustomerName;
	private String cSiteNameAlias;
	private String cSiteCustomerCity;
	private String cSiteCustomerCountry;
	private String cTechnologyDesc;
	private String cTechnologyDescOg;
	private String cEquipmentDesc;
	private String cEngProjectRef;
	private String cOemLocationDesc;
	private String cUnitStatusDesc;
	private String dUnitShipDate;
	private String dUnitCodDate;
	private String cAccountMgrEmail;
	private String cServiceMgrEmail;
	private String cMarketSegmentDesc;
	private String cServiceRelationDescOg;
	private String cOgSalesRegion;
	private String cMainLvlCod;
	private String cMaintLvlDesc;
	private String ceventStatus;
	private String geDunsName;
	private String eventYear;
	private String eventQuarter;
	
	public String getGeDunsName() {
		return geDunsName;
	}
	public void setGeDunsName(String geDunsName) {
		this.geDunsName = geDunsName;
	}
	public String getEventYear() {
		return eventYear;
	}
	public void setEventYear(String eventYear) {
		this.eventYear = eventYear;
	}
	public String getEventQuarter() {
		return eventQuarter;
	}
	public void setEventQuarter(String eventQuarter) {
		this.eventQuarter = eventQuarter;
	}		
	public String getCeventStatus() {
		return ceventStatus;
	}
	public void setCeventStatus(String ceventStatus) {
		this.ceventStatus = ceventStatus;
	}
	public String getcMainLvlCod() {
		return cMainLvlCod;
	}
	public void setcMainLvlCod(String cMainLvlCod) {
		this.cMainLvlCod = cMainLvlCod;
	}
	public String getcMaintLvlDesc() {
		return cMaintLvlDesc;
	}
	public void setcMaintLvlDesc(String cMaintLvlDesc) {
		this.cMaintLvlDesc = cMaintLvlDesc;
	}
	public int getnEventId() {
		return nEventId;
	}
	public void setnEventId(int nEventId) {
		this.nEventId = nEventId;
	}
	public String getcGibSerialNumber() {
		return cGibSerialNumber;
	}
	public void setcGibSerialNumber(String cGibSerialNumber) {
		this.cGibSerialNumber = cGibSerialNumber;
	}
	public int getnMaintPolicyCyc() {
		return nMaintPolicyCyc;
	}
	public void setnMaintPolicyCyc(int nMaintPolicyCyc) {
		this.nMaintPolicyCyc = nMaintPolicyCyc;
	}
	public int getnMaintLevelSeq() {
		return nMaintLevelSeq;
	}
	public void setnMaintLevelSeq(int nMaintLevelSeq) {
		this.nMaintLevelSeq = nMaintLevelSeq;
	}
	public String getdEventDate() {
		return dEventDate;
	}
	public void setdEventDate(String dEventDate) {
		this.dEventDate = dEventDate;
	}
	public String gettEventNotes() {
		return tEventNotes;
	}
	public void settEventNotes(String tEventNotes) {
		this.tEventNotes = tEventNotes;
	}
	public String getcDemSvcsStatus() {
		return cDemSvcsStatus;
	}
	public void setcDemSvcsStatus(String cDemSvcsStatus) {
		this.cDemSvcsStatus = cDemSvcsStatus;
	}
	public String getcUsrIns() {
		return cUsrIns;
	}
	public void setcUsrIns(String cUsrIns) {
		this.cUsrIns = cUsrIns;
	}
	public String getdIns() {
		return dIns;
	}
	public void setdIns(String dIns) {
		this.dIns = dIns;
	}
	public String getcEventDemStatusParts() {
		return cEventDemStatusParts;
	}
	public void setcEventDemStatusParts(String cEventDemStatusParts) {
		this.cEventDemStatusParts = cEventDemStatusParts;
	}
	public String getcEventDemStatusSvcs() {
		return cEventDemStatusSvcs;
	}
	public void setcEventDemStatusSvcs(String cEventDemStatusSvcs) {
		this.cEventDemStatusSvcs = cEventDemStatusSvcs;
	}
	public String getCeventDemStatusRepairs() {
		return ceventDemStatusRepairs;
	}
	public void setCeventDemStatusRepairs(String ceventDemStatusRepairs) {
		this.ceventDemStatusRepairs = ceventDemStatusRepairs;
	}
	public String getfUnsolicedStatusFlag() {
		return fUnsolicedStatusFlag;
	}
	public void setfUnsolicedStatusFlag(String fUnsolicedStatusFlag) {
		this.fUnsolicedStatusFlag = fUnsolicedStatusFlag;
	}
	public String getcGibSerialNumber2() {
		return cGibSerialNumber2;
	}
	public void setcGibSerialNumber2(String cGibSerialNumber2) {
		this.cGibSerialNumber2 = cGibSerialNumber2;
	}
	public String getdEstServiceStartDate() {
		return dEstServiceStartDate;
	}
	public void setdEstServiceStartDate(String dEstServiceStartDate) {
		this.dEstServiceStartDate = dEstServiceStartDate;
	}
	public double getnEstServHoursCount() {
		return nEstServHoursCount;
	}
	public void setnEstServHoursCount(double nEstServHoursCount) {
		this.nEstServHoursCount = nEstServHoursCount;
	}
	public int getnMaintYear() {
		return nMaintYear;
	}
	public void setnMaintYear(int nMaintYear) {
		this.nMaintYear = nMaintYear;
	}
	public String getcCustLoyaltyDescParts() {
		return cCustLoyaltyDescParts;
	}
	public void setcCustLoyaltyDescParts(String cCustLoyaltyDescParts) {
		this.cCustLoyaltyDescParts = cCustLoyaltyDescParts;
	}
	public String getcCustBehaviorDescParts() {
		return cCustBehaviorDescParts;
	}
	public void setcCustBehaviorDescParts(String cCustBehaviorDescParts) {
		this.cCustBehaviorDescParts = cCustBehaviorDescParts;
	}
	public String getcSiteCustomerDuns() {
		return cSiteCustomerDuns;
	}
	public void setcSiteCustomerDuns(String cSiteCustomerDuns) {
		this.cSiteCustomerDuns = cSiteCustomerDuns;
	}
	public String getcSiteCustomerName() {
		return cSiteCustomerName;
	}
	public void setcSiteCustomerName(String cSiteCustomerName) {
		this.cSiteCustomerName = cSiteCustomerName;
	}
	public String getcSiteNameAlias() {
		return cSiteNameAlias;
	}
	public void setcSiteNameAlias(String cSiteNameAlias) {
		this.cSiteNameAlias = cSiteNameAlias;
	}
	public String getcSiteCustomerCity() {
		return cSiteCustomerCity;
	}
	public void setcSiteCustomerCity(String cSiteCustomerCity) {
		this.cSiteCustomerCity = cSiteCustomerCity;
	}
	public String getcSiteCustomerCountry() {
		return cSiteCustomerCountry;
	}
	public void setcSiteCustomerCountry(String cSiteCustomerCountry) {
		this.cSiteCustomerCountry = cSiteCustomerCountry;
	}
	public String getcTechnologyDesc() {
		return cTechnologyDesc;
	}
	public void setcTechnologyDesc(String cTechnologyDesc) {
		this.cTechnologyDesc = cTechnologyDesc;
	}
	public String getcTechnologyDescOg() {
		return cTechnologyDescOg;
	}
	public void setcTechnologyDescOg(String cTechnologyDescOg) {
		this.cTechnologyDescOg = cTechnologyDescOg;
	}
	public String getcEquipmentDesc() {
		return cEquipmentDesc;
	}
	public void setcEquipmentDesc(String cEquipmentDesc) {
		this.cEquipmentDesc = cEquipmentDesc;
	}
	public String getcEngProjectRef() {
		return cEngProjectRef;
	}
	public void setcEngProjectRef(String cEngProjectRef) {
		this.cEngProjectRef = cEngProjectRef;
	}
	public String getcOemLocationDesc() {
		return cOemLocationDesc;
	}
	public void setcOemLocationDesc(String cOemLocationDesc) {
		this.cOemLocationDesc = cOemLocationDesc;
	}
	public String getcUnitStatusDesc() {
		return cUnitStatusDesc;
	}
	public void setcUnitStatusDesc(String cUnitStatusDesc) {
		this.cUnitStatusDesc = cUnitStatusDesc;
	}
	public String getdUnitShipDate() {
		return dUnitShipDate;
	}
	public void setdUnitShipDate(String dUnitShipDate) {
		this.dUnitShipDate = dUnitShipDate;
	}
	public String getdUnitCodDate() {
		return dUnitCodDate;
	}
	public void setdUnitCodDate(String dUnitCodDate) {
		this.dUnitCodDate = dUnitCodDate;
	}
	public String getcAccountMgrEmail() {
		return cAccountMgrEmail;
	}
	public void setcAccountMgrEmail(String cAccountMgrEmail) {
		this.cAccountMgrEmail = cAccountMgrEmail;
	}
	public String getcServiceMgrEmail() {
		return cServiceMgrEmail;
	}
	public void setcServiceMgrEmail(String cServiceMgrEmail) {
		this.cServiceMgrEmail = cServiceMgrEmail;
	}
	public String getcMarketSegmentDesc() {
		return cMarketSegmentDesc;
	}
	public void setcMarketSegmentDesc(String cMarketSegmentDesc) {
		this.cMarketSegmentDesc = cMarketSegmentDesc;
	}
	public String getcServiceRelationDescOg() {
		return cServiceRelationDescOg;
	}
	public void setcServiceRelationDescOg(String cServiceRelationDescOg) {
		this.cServiceRelationDescOg = cServiceRelationDescOg;
	}
	public String getcOgSalesRegion() {
		return cOgSalesRegion;
	}
	public void setcOgSalesRegion(String cOgSalesRegion) {
		this.cOgSalesRegion = cOgSalesRegion;
	}
}
