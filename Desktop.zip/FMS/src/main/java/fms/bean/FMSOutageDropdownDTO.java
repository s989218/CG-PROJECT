package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSOutageDropdownDTO implements Serializable {

	private static final long serialVersionUID = 1273153531642501447L;
	private List<FMSSiteCustomerNameDropdownBean> outageCustName;
	private List<FMSTechnologyDropdownBean> outageTechnology;
	private List<FMSEquipCodeDropdownBean> outageEquip;
	private List<FMSOutLocationDTO> outageLocation;
	private List<FMSUnitStatusDesDropdownBean> outageUnitStatus;
	private List<FMSSrcNewSegmentDropdownBean> outageSegment;
	private List<FMSServRelDescOngDropdownBean> outageRelation;
	private List<FMSRegionDropdownBean> outageRegion;
	private List<FMSCurrentYearDTO> outageYearQtr;
	private List<FMSCountryNameDropdownBean> outageCountry;
	private List<FMSCustomerDropdownBean> outageDunsName;
	private List<FMSAccMgrEmailDropdownBean> outageaccMgrEmail;
	private List<FMSServiceMgrEmailDropdownBean> outageserviceMgrEmail;
	private List<FMSDMMaintLvlDescDTO> maintLvlDescDTO;
	private List<FMSMaintLvlStatusBean> maintLvlStatus;
	
	
	
	public List<FMSMaintLvlStatusBean> getMaintLvlStatus() {
		return maintLvlStatus;
	}
	public void setMaintLvlStatus(List<FMSMaintLvlStatusBean> maintLvlStatus) {
		this.maintLvlStatus = maintLvlStatus;
	}
	public List<FMSDMMaintLvlDescDTO> getMaintLvlDescDTO() {
		return maintLvlDescDTO;
	}
	public void setMaintLvlDescDTO(List<FMSDMMaintLvlDescDTO> maintLvlDescDTO) {
		this.maintLvlDescDTO = maintLvlDescDTO;
	}
	public List<FMSAccMgrEmailDropdownBean> getOutageaccMgrEmail() {
		return outageaccMgrEmail;
	}
	public void setOutageaccMgrEmail(
			List<FMSAccMgrEmailDropdownBean> outageaccMgrEmail) {
		this.outageaccMgrEmail = outageaccMgrEmail;
	}
	public List<FMSServiceMgrEmailDropdownBean> getOutageserviceMgrEmail() {
		return outageserviceMgrEmail;
	}
	public void setOutageserviceMgrEmail(
			List<FMSServiceMgrEmailDropdownBean> outageserviceMgrEmail) {
		this.outageserviceMgrEmail = outageserviceMgrEmail;
	}
	public List<FMSCustomerDropdownBean> getOutageDunsName() {
		return outageDunsName;
	}
	public void setOutageDunsName(List<FMSCustomerDropdownBean> outageDunsName) {
		this.outageDunsName = outageDunsName;
	}
	public List<FMSCountryNameDropdownBean> getOutageCountry() {
		return outageCountry;
	}
	public void setOutageCountry(List<FMSCountryNameDropdownBean> outageCountry) {
		this.outageCountry = outageCountry;
	}
	public List<FMSCurrentYearDTO> getOutageYearQtr() {
		return outageYearQtr;
	}
	public void setOutageYearQtr(List<FMSCurrentYearDTO> outageYearQtr) {
		this.outageYearQtr = outageYearQtr;
	}
	public List<FMSSiteCustomerNameDropdownBean> getOutageCustName() {
		return outageCustName;
	}
	public void setOutageCustName(List<FMSSiteCustomerNameDropdownBean> outageCustName) {
		this.outageCustName = outageCustName;
	}
	public List<FMSTechnologyDropdownBean> getOutageTechnology() {
		return outageTechnology;
	}
	public void setOutageTechnology(List<FMSTechnologyDropdownBean> outageTechnology) {
		this.outageTechnology = outageTechnology;
	}
	public List<FMSEquipCodeDropdownBean> getOutageEquip() {
		return outageEquip;
	}
	public void setOutageEquip(List<FMSEquipCodeDropdownBean> outageEquip) {
		this.outageEquip = outageEquip;
	}
	public List<FMSOutLocationDTO> getOutageLocation() {
		return outageLocation;
	}
	public void setOutageLocation(List<FMSOutLocationDTO> outageLocation) {
		this.outageLocation = outageLocation;
	}
	public List<FMSUnitStatusDesDropdownBean> getOutageUnitStatus() {
		return outageUnitStatus;
	}
	public void setOutageUnitStatus(List<FMSUnitStatusDesDropdownBean> outageUnitStatus) {
		this.outageUnitStatus = outageUnitStatus;
	}
	public List<FMSSrcNewSegmentDropdownBean> getOutageSegment() {
		return outageSegment;
	}
	public void setOutageSegment(List<FMSSrcNewSegmentDropdownBean> outageSegment) {
		this.outageSegment = outageSegment;
	}
	public List<FMSServRelDescOngDropdownBean> getOutageRelation() {
		return outageRelation;
	}
	public void setOutageRelation(List<FMSServRelDescOngDropdownBean> outageRelation) {
		this.outageRelation = outageRelation;
	}
	public List<FMSRegionDropdownBean> getOutageRegion() {
		return outageRegion;
	}
	public void setOutageRegion(List<FMSRegionDropdownBean> outageRegion) {
		this.outageRegion = outageRegion;
	}

}
