package fms.bean;

import java.io.Serializable;

public class FMSOutageFilterCustDTO implements Serializable{

	private static final long serialVersionUID = -3186306355902620023L;
	private String ofCountry;
	private String ofRegion;
	private String  ofCustomerName;
	private String  ofOutages;
	private String  ofRegId;
	private int ofTechCount;
	private String ofTechDesc;
	private String ofColorCode;
	public String getOfCountry() {
		return ofCountry;
	}
	public void setOfCountry(String ofCountry) {
		this.ofCountry = ofCountry;
	}
	public String getOfRegion() {
		return ofRegion;
	}
	public void setOfRegion(String ofRegion) {
		this.ofRegion = ofRegion;
	}
	public String getOfCustomerName() {
		return ofCustomerName;
	}
	public void setOfCustomerName(String ofCustomerName) {
		this.ofCustomerName = ofCustomerName;
	}
	public String getOfOutages() {
		return ofOutages;
	}
	public void setOfOutages(String ofOutages) {
		this.ofOutages = ofOutages;
	}
	public String getOfRegId() {
		return ofRegId;
	}
	public void setOfRegId(String ofRegId) {
		this.ofRegId = ofRegId;
	}
	public int getOfTechCount() {
		return ofTechCount;
	}
	public void setOfTechCount(int ofTechCount) {
		this.ofTechCount = ofTechCount;
	}
	public String getOfTechDesc() {
		return ofTechDesc;
	}
	public void setOfTechDesc(String ofTechDesc) {
		this.ofTechDesc = ofTechDesc;
	}
	public String getOfColorCode() {
		return ofColorCode;
	}
	public void setOfColorCode(String ofColorCode) {
		this.ofColorCode = ofColorCode;
	}
	
	
	
}
