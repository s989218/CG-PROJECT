package fms.bean;

import java.io.Serializable;

public class FMSOutageFilterDataDTO implements Serializable{

	private static final long serialVersionUID = 5990034531555062954L;
	private String outageYear;
	private String outageQuarter;
	private String outageCustomerName;
	private String outageTechnology;
	private String outageEquipment;
	private String outageLocation;
	private String outageUnitStatus;
	private String outageSegment;
	private String outageServiceRel;
	private String outageRegion;
	private String outageCountry; 
	private String outageDunsName;
	private String outageAccMgrEmail;
	private String outageServiceMgrEmail;
	private String outageMaintLvlDesc;
	private String outageEvntStatusDesc;
	private String outageAccountManager;
	
		
	public String getOutageAccountManager() {
		return outageAccountManager;
	}
	public void setOutageAccountManager(String outageAccountManager) {
		this.outageAccountManager = outageAccountManager;
	}
	public String getOutageEvntStatusDesc() {
		return outageEvntStatusDesc;
	}
	public void setOutageEvntStatusDesc(String outageEvntStatusDesc) {
		this.outageEvntStatusDesc = outageEvntStatusDesc;
	}
	public String getOutageMaintLvlDesc() {
		return outageMaintLvlDesc;
	}
	public void setOutageMaintLvlDesc(String outageMaintLvlDesc) {
		this.outageMaintLvlDesc = outageMaintLvlDesc;
	}
	public String getOutageAccMgrEmail() {
		return outageAccMgrEmail;
	}
	public void setOutageAccMgrEmail(String outageAccMgrEmail) {
		this.outageAccMgrEmail = outageAccMgrEmail;
	}
	public String getOutageServiceMgrEmail() {
		return outageServiceMgrEmail;
	}
	public void setOutageServiceMgrEmail(String outageServiceMgrEmail) {
		this.outageServiceMgrEmail = outageServiceMgrEmail;
	}
	public String getOutageDunsName() {
		return outageDunsName;
	}
	public void setOutageDunsName(String outageDunsName) {
		this.outageDunsName = outageDunsName;
	}
	public String getOutageCountry() {
		return outageCountry;
	}
	public void setOutageCountry(String outageCountry) {
		this.outageCountry = outageCountry;
	}
	public String getOutageYear() {
		return outageYear;
	}
	public void setOutageYear(String outageYear) {
		this.outageYear = outageYear;
	}
	public String getOutageQuarter() {
		return outageQuarter;
	}
	public void setOutageQuarter(String outageQuarter) {
		this.outageQuarter = outageQuarter;
	}
	public String getOutageCustomerName() {
		return outageCustomerName;
	}
	public void setOutageCustomerName(String outageCustomerName) {
		this.outageCustomerName = outageCustomerName;
	}
	public String getOutageTechnology() {
		return outageTechnology;
	}
	public void setOutageTechnology(String outageTechnology) {
		this.outageTechnology = outageTechnology;
	}
	public String getOutageEquipment() {
		return outageEquipment;
	}
	public void setOutageEquipment(String outageEquipment) {
		this.outageEquipment = outageEquipment;
	}
	public String getOutageLocation() {
		return outageLocation;
	}
	public void setOutageLocation(String outageLocation) {
		this.outageLocation = outageLocation;
	}
	public String getOutageUnitStatus() {
		return outageUnitStatus;
	}
	public void setOutageUnitStatus(String outageUnitStatus) {
		this.outageUnitStatus = outageUnitStatus;
	}
	public String getOutageSegment() {
		return outageSegment;
	}
	public void setOutageSegment(String outageSegment) {
		this.outageSegment = outageSegment;
	}
	public String getOutageServiceRel() {
		return outageServiceRel;
	}
	public void setOutageServiceRel(String outageServiceRel) {
		this.outageServiceRel = outageServiceRel;
	}
	public String getOutageRegion() {
		return outageRegion;
	}
	public void setOutageRegion(String outageRegion) {
		this.outageRegion = outageRegion;
	}

}
