package fms.bean;

import java.io.Serializable;

public class FMSOutageFilterTechDTO implements Serializable{

	private static final long serialVersionUID = -1544338831863913478L;
	private String otRegion;
	private String otTech;
	private String otOutages;
	private String otRegId;
	private String otColorCode;
	private String otCountry;
	public String getOtRegion() {
		return otRegion;
	}
	public void setOtRegion(String otRegion) {
		this.otRegion = otRegion;
	}
	public String getOtTech() {
		return otTech;
	}
	public void setOtTech(String otTech) {
		this.otTech = otTech;
	}
	public String getOtOutages() {
		return otOutages;
	}
	public void setOtOutages(String otOutages) {
		this.otOutages = otOutages;
	}
	public String getOtRegId() {
		return otRegId;
	}
	public void setOtRegId(String otRegId) {
		this.otRegId = otRegId;
	}
	public String getOtColorCode() {
		return otColorCode;
	}
	public void setOtColorCode(String otColorCode) {
		this.otColorCode = otColorCode;
	}
	public String getOtCountry() {
		return otCountry;
	}
	public void setOtCountry(String otCountry) {
		this.otCountry = otCountry;
	}
	
}
