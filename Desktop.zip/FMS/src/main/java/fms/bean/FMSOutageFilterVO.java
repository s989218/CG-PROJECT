package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSOutageFilterVO implements Serializable{

	private static final long serialVersionUID = -1671805927050885450L;
	private List<FMSOutageFilterTechDTO> outageTechnologies;
	private List<FMSOutageFilterCustDTO> outageCustomers;
	public List<FMSOutageFilterTechDTO> getOutageTechnologies() {
		return outageTechnologies;
	}
	public void setOutageTechnologies(List<FMSOutageFilterTechDTO> outageTechnologies) {
		this.outageTechnologies = outageTechnologies;
	}
	public List<FMSOutageFilterCustDTO> getOutageCustomers() {
		return outageCustomers;
	}
	public void setOutageCustomers(List<FMSOutageFilterCustDTO> outageCustomers) {
		this.outageCustomers = outageCustomers;
	}

}
