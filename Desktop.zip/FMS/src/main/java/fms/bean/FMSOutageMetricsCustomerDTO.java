package fms.bean;

import java.io.Serializable;

public class FMSOutageMetricsCustomerDTO implements Serializable{

	private static final long serialVersionUID = -893449085233349035L;
	private String ocRegion;
	private String ocCustomerName;
	private int ocOutages;
	private int ocRegId;
	private int ocTechCount;
	private String ocTechDesc;
	private String ocColorCode;
	public int getOcTechCount() {
		return ocTechCount;
	}
	public void setOcTechCount(int ocTechCount) {
		this.ocTechCount = ocTechCount;
	}
	public String getOcTechDesc() {
		return ocTechDesc;
	}
	public void setOcTechDesc(String ocTechDesc) {
		this.ocTechDesc = ocTechDesc;
	}
	public String getOcColorCode() {
		return ocColorCode;
	}
	public void setOcColorCode(String ocColorCode) {
		this.ocColorCode = ocColorCode;
	}
	public String getOcRegion() {
		return ocRegion;
	}
	public void setOcRegion(String ocRegion) {
		this.ocRegion = ocRegion;
	}
	public String getOcCustomerName() {
		return ocCustomerName;
	}
	public void setOcCustomerName(String ocCustomerName) {
		this.ocCustomerName = ocCustomerName;
	}
	public int getOcOutages() {
		return ocOutages;
	}
	public void setOcOutages(int ocOutages) {
		this.ocOutages = ocOutages;
	}
	public int getOcRegId() {
		return ocRegId;
	}
	public void setOcRegId(int ocRegId) {
		this.ocRegId = ocRegId;
	}
			
}
