package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSOutageMetricsDetailsDTO implements Serializable{

	private static final long serialVersionUID = 4364769241194846486L;
	private List<FMSOutageMetricsTechDTO> technologyDetails;
	private List<FMSOutageMetricsCustomerDTO> topCustomer;
	public List<FMSOutageMetricsTechDTO> getTechnologyDetails() {
		return technologyDetails;
	}
	public void setTechnologyDetails(List<FMSOutageMetricsTechDTO> technologyDetails) {
		this.technologyDetails = technologyDetails;
	}
	public List<FMSOutageMetricsCustomerDTO> getTopCustomer() {
		return topCustomer;
	}
	public void setTopCustomer(List<FMSOutageMetricsCustomerDTO> topCustomer) {
		this.topCustomer = topCustomer;
	}
	
}
