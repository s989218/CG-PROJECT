package fms.bean;

import java.io.Serializable;

public class FMSOutageMetricsTechDTO implements Serializable{

	private static final long serialVersionUID = -4534950788127353915L;
	private String orRegion;
	private String orTech;
	private int orTotalOutages;
	private String orColorCode;
	public String getOrRegion() {
		return orRegion;
	}
	public void setOrRegion(String orRegion) {
		this.orRegion = orRegion;
	}
	public String getOrTech() {
		return orTech;
	}
	public void setOrTech(String orTech) {
		this.orTech = orTech;
	}
	public int getOrTotalOutages() {
		return orTotalOutages;
	}
	public void setOrTotalOutages(int orTotalOutages) {
		this.orTotalOutages = orTotalOutages;
	}
	public String getOrColorCode() {
		return orColorCode;
	}
	public void setOrColorCode(String orColorCode) {
		this.orColorCode = orColorCode;
	}
	
}
