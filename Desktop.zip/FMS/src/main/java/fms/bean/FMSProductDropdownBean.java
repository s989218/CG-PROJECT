package fms.bean;

import java.io.Serializable;

public class FMSProductDropdownBean implements Serializable {

	private static final long serialVersionUID = 6652667381487141235L;
	private String product;

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}
	
}
