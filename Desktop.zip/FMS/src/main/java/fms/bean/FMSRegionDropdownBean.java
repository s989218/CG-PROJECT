package fms.bean;

import java.io.Serializable;

public class FMSRegionDropdownBean implements Serializable {
	
	private static final long serialVersionUID = 7338664924538447444L;
	private String region;

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	} 
	

}
