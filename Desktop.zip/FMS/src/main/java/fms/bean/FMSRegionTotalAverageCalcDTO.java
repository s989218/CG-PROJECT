package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSRegionTotalAverageCalcDTO implements Serializable{

	private static final long serialVersionUID = -6640421217953887334L;
	private List<FMSAverageCalcDTO> fleetCoverageAverageDTO;
	private List<FMSAverageCalcDTO> fleetPenetrationAverageDTO;
	private List<FMSAverageCalcDTO> fltPentrtnF2FAverageDTO;
	private List<FMSAverageCalcDTO> dollarByIBAverageDTO;
	private List<FMSAverageCalcDTO> caloricIndexAverageDTO;
	private List<FMSAverageCalcDTO> conversionIndexAverageDTO;
	private List<FMSAverageCalcDTO> iboByRegionAverageDTO;
	private List<FMSAverageCalcDTO> revDollarByRegAverageDTO;
	private List<FMSAverageCalcDTO> ibnByRegionAverageDTO;
	private List<FMSAverageCalcDTO> iboByTechnologyAverageDTO;
	private List<FMSAverageCalcDTO> ibNoByTechnologyAverageDTO;
	public List<FMSAverageCalcDTO> getFleetCoverageAverageDTO() {
		return fleetCoverageAverageDTO;
	}
	public void setFleetCoverageAverageDTO(List<FMSAverageCalcDTO> fleetCoverageAverageDTO) {
		this.fleetCoverageAverageDTO = fleetCoverageAverageDTO;
	}
	public List<FMSAverageCalcDTO> getFleetPenetrationAverageDTO() {
		return fleetPenetrationAverageDTO;
	}
	public void setFleetPenetrationAverageDTO(List<FMSAverageCalcDTO> fleetPenetrationAverageDTO) {
		this.fleetPenetrationAverageDTO = fleetPenetrationAverageDTO;
	}
	public List<FMSAverageCalcDTO> getFltPentrtnF2FAverageDTO() {
		return fltPentrtnF2FAverageDTO;
	}
	public void setFltPentrtnF2FAverageDTO(List<FMSAverageCalcDTO> fltPentrtnF2FAverageDTO) {
		this.fltPentrtnF2FAverageDTO = fltPentrtnF2FAverageDTO;
	}
	public List<FMSAverageCalcDTO> getDollarByIBAverageDTO() {
		return dollarByIBAverageDTO;
	}
	public void setDollarByIBAverageDTO(List<FMSAverageCalcDTO> dollarByIBAverageDTO) {
		this.dollarByIBAverageDTO = dollarByIBAverageDTO;
	}
	public List<FMSAverageCalcDTO> getCaloricIndexAverageDTO() {
		return caloricIndexAverageDTO;
	}
	public void setCaloricIndexAverageDTO(List<FMSAverageCalcDTO> caloricIndexAverageDTO) {
		this.caloricIndexAverageDTO = caloricIndexAverageDTO;
	}
	public List<FMSAverageCalcDTO> getConversionIndexAverageDTO() {
		return conversionIndexAverageDTO;
	}
	public void setConversionIndexAverageDTO(List<FMSAverageCalcDTO> conversionIndexAverageDTO) {
		this.conversionIndexAverageDTO = conversionIndexAverageDTO;
	}
	public List<FMSAverageCalcDTO> getIboByRegionAverageDTO() {
		return iboByRegionAverageDTO;
	}
	public void setIboByRegionAverageDTO(List<FMSAverageCalcDTO> iboByRegionAverageDTO) {
		this.iboByRegionAverageDTO = iboByRegionAverageDTO;
	}
	public List<FMSAverageCalcDTO> getRevDollarByRegAverageDTO() {
		return revDollarByRegAverageDTO;
	}
	public void setRevDollarByRegAverageDTO(List<FMSAverageCalcDTO> revDollarByRegAverageDTO) {
		this.revDollarByRegAverageDTO = revDollarByRegAverageDTO;
	}
	public List<FMSAverageCalcDTO> getIbnByRegionAverageDTO() {
		return ibnByRegionAverageDTO;
	}
	public void setIbnByRegionAverageDTO(List<FMSAverageCalcDTO> ibnByRegionAverageDTO) {
		this.ibnByRegionAverageDTO = ibnByRegionAverageDTO;
	}
	public List<FMSAverageCalcDTO> getIboByTechnologyAverageDTO() {
		return iboByTechnologyAverageDTO;
	}
	public void setIboByTechnologyAverageDTO(List<FMSAverageCalcDTO> iboByTechnologyAverageDTO) {
		this.iboByTechnologyAverageDTO = iboByTechnologyAverageDTO;
	}
	public List<FMSAverageCalcDTO> getIbNoByTechnologyAverageDTO() {
		return ibNoByTechnologyAverageDTO;
	}
	public void setIbNoByTechnologyAverageDTO(List<FMSAverageCalcDTO> ibNoByTechnologyAverageDTO) {
		this.ibNoByTechnologyAverageDTO = ibNoByTechnologyAverageDTO;
	}

}
