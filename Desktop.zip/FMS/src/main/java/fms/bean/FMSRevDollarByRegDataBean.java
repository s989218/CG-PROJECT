package fms.bean;

import java.io.Serializable;

public class FMSRevDollarByRegDataBean implements Serializable {

	private static final long serialVersionUID = -7336004135925249045L;
	private String revDollarByRegion;  
	private String revDollarByRegionYear;
	private String revDollarByRegionQuarter;
	private String revDollarByRegionValue;
	
	public String getRevDollarByRegion() {
		return revDollarByRegion;
	}
	public void setRevDollarByRegion(String revDollarByRegion) {
		this.revDollarByRegion = revDollarByRegion;
	}
	public String getRevDollarByRegionYear() {
		return revDollarByRegionYear;
	}
	public void setRevDollarByRegionYear(String revDollarByRegionYear) {
		this.revDollarByRegionYear = revDollarByRegionYear;
	}
	public String getRevDollarByRegionQuarter() {
		return revDollarByRegionQuarter;
	}
	public void setRevDollarByRegionQuarter(String revDollarByRegionQuarter) {
		this.revDollarByRegionQuarter = revDollarByRegionQuarter;
	}
	public String getRevDollarByRegionValue() {
		return revDollarByRegionValue;
	}
	public void setRevDollarByRegionValue(String revDollarByRegionValue) {
		this.revDollarByRegionValue = revDollarByRegionValue;
	}
	
	
}
