package fms.bean;

import java.io.Serializable;
import java.util.List;

public class FMSRevDollarByRegionDataVO implements Serializable {

	private static final long serialVersionUID = 8070034994885845216L;
	private List<FMSRevDollarByRegDataBean> revDollarByRegCurrentData;
	private List<FMSRevDollarByRegDataBean> revDollarByRegHistoryData;
	public List<FMSRevDollarByRegDataBean> getRevDollarByRegCurrentData() {
		return revDollarByRegCurrentData;
	}
	public void setRevDollarByRegCurrentData(
			List<FMSRevDollarByRegDataBean> revDollarByRegCurrentData) {
		this.revDollarByRegCurrentData = revDollarByRegCurrentData;
	}
	public List<FMSRevDollarByRegDataBean> getRevDollarByRegHistoryData() {
		return revDollarByRegHistoryData;
	}
	public void setRevDollarByRegHistoryData(
			List<FMSRevDollarByRegDataBean> revDollarByRegHistoryData) {
		this.revDollarByRegHistoryData = revDollarByRegHistoryData;
	}
	
	
	
}
