package fms.bean;

import java.io.Serializable;

public class FMSServRelDescOngDropdownBean implements Serializable {

	private static final long serialVersionUID = 6018629004000894175L;
	private String servRelationDescOng;

	public String getServRelationDescOng() {
		return servRelationDescOng;
	}

	public void setServRelationDescOng(String servRelationDescOng) {
		this.servRelationDescOng = servRelationDescOng;
	}
	
}
