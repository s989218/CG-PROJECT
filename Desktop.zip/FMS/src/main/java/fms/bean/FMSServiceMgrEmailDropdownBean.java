package fms.bean;

import java.io.Serializable;

public class FMSServiceMgrEmailDropdownBean implements Serializable {
	
	private static final long serialVersionUID = -130890036803647618L;
	private String cServiceMgrEmail;
	public String getcServiceMgrEmail() {
		return cServiceMgrEmail;
	}
	public void setcServiceMgrEmail(String cServiceMgrEmail) {
		this.cServiceMgrEmail = cServiceMgrEmail;
	}
	
}
