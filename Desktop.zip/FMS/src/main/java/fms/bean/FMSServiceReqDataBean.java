package fms.bean;
import java.io.Serializable;

public class FMSServiceReqDataBean implements Serializable {


	private static final long serialVersionUID = 2971889018848295490L;
	
	private String caseNo; 							//  case_number
	private String opened; 					     	//  opened
	private String originalTypeofIssue; 			//	original_type_of_issue
	private String currentTypeofIssue;				//  current_type_of_issue
	private String issueEventDate;					//  issue_event_date
	private String projectPhase;					//  project_phase
	private String custAddReq;						//  customer_add_request
	private String suggByRedFlgReview;				//  suggested_by_red_flag_review
	private String rcaReqByCust;					//  rca_required_by_customer
	private String ehsImpact;						//  ehs_impact
	private String category;						//  category
	private String state;							//  state
	private String curStaLastinActDate;				//  cur_sta_last_in_actual_date
	private String assignedGroup;					//  assigned_group
	private String status;							//  status
	private String entryInCurStatus;				//  entry_in_the_cur_status
	private String asRunningLastInDate;				//  as_running_last_in_date
	private String asRunningLastOutDate;			//  as_running_last_out_date
	private String techSoluType;					//  tech_solu_type
	private String swTeamNeeded;					//  software_team_needed
	private String jobType;							//  job_type
	private String jobTypeDetails;					//  job_type_details
	private String business;						//  business
	private String customerName;					//  customer_name
	private String expectedResolDate;				//  expected_resol_date
	private String machineType;						//  machine_type
	private String machineTechnology;				//  machine_technology
	private String controlPanelType;				//  control_panel_type
	private String machineTechOg;					//  machine_technology_og
	private String cod;								//  cod
	private String costingProjectCharged;			//  costing_project_to_be_charged
	private String projectManager;			 	    //  project_manager
	private String instaManagerCoordinator;			//  insta_manager_coordinator
	private String problemDesc;						//  problem_description
	private String cin;								//  cin
	private String assignedFun;						//  assigned_function
	private String actVsSupMateSol;					//  act_vs_sup_mate_sol
	private String supplierNameMateSol;				//  supplier_name_mate_sol
	private String solDesc;							//  sol_description
	private String asRunningNeeded;					//  as_running_needed		
	private String mateNeeded;						//  mate_needed
	private String supplierResp;					//  supplier_resp
	private String wfcaTimeInvalid;					//  wfca_time_in_valid
	private String wfcaTimeInSol;					//  wfca_time_in_sol
	private String wfcaTimeInFulfSp;				//  wfca_time_in_fulf_sp
	private String wfcaTimeInImple;					//  wfca_time_in_imple
	private String wfcaTimeInAsBuilt;				//  wfca_time_in_as_built
	private String wfcaTimeInExpertAss;				//  wfca_time_in_expert_ass
	private String sEventYear;                        //  event_year
	private String sEventQuarter;                        //event_quarter
	

	public String getsEventQuarter() {
		return sEventQuarter;
	}
	public void setsEventQuarter(String sEventQuarter) {
		this.sEventQuarter = sEventQuarter;
	}
	public String getsEventYear() {
		return sEventYear;
	}
	public void setsEventYear(String sEventYear) {
		this.sEventYear = sEventYear;
	}
	public String getWfcaTimeInvalid() {
		return wfcaTimeInvalid;
	}
	public void setWfcaTimeInvalid(String wfcaTimeInvalid) {
		this.wfcaTimeInvalid = wfcaTimeInvalid;
	}
	public String getWfcaTimeInSol() {
		return wfcaTimeInSol;
	}
	public void setWfcaTimeInSol(String wfcaTimeInSol) {
		this.wfcaTimeInSol = wfcaTimeInSol;
	}
	public String getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public String getOpened() {
		return opened;
	}
	public void setOpened(String opened) {
		this.opened = opened;
	}
	public String getOriginalTypeofIssue() {
		return originalTypeofIssue;
	}
	public void setOriginalTypeofIssue(String originalTypeofIssue) {
		this.originalTypeofIssue = originalTypeofIssue;
	}
	public String getCurrentTypeofIssue() {
		return currentTypeofIssue;
	}
	public void setCurrentTypeofIssue(String currentTypeofIssue) {
		this.currentTypeofIssue = currentTypeofIssue;
	}
	public String getIssueEventDate() {
		return issueEventDate;
	}
	public void setIssueEventDate(String issueEventDate) {
		this.issueEventDate = issueEventDate;
	}
	public String getProjectPhase() {
		return projectPhase;
	}
	public void setProjectPhase(String projectPhase) {
		this.projectPhase = projectPhase;
	}
	public String getCustAddReq() {
		return custAddReq;
	}
	public void setCustAddReq(String custAddReq) {
		this.custAddReq = custAddReq;
	}
	public String getSuggByRedFlgReview() {
		return suggByRedFlgReview;
	}
	public void setSuggByRedFlgReview(String suggByRedFlgReview) {
		this.suggByRedFlgReview = suggByRedFlgReview;
	}
	public String getRcaReqByCust() {
		return rcaReqByCust;
	}
	public void setRcaReqByCust(String rcaReqByCust) {
		this.rcaReqByCust = rcaReqByCust;
	}
	public String getEhsImpact() {
		return ehsImpact;
	}
	public void setEhsImpact(String ehsImpact) {
		this.ehsImpact = ehsImpact;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCurStaLastinActDate() {
		return curStaLastinActDate;
	}
	public void setCurStaLastinActDate(String curStaLastinActDate) {
		this.curStaLastinActDate = curStaLastinActDate;
	}
	public String getAssignedGroup() {
		return assignedGroup;
	}
	public void setAssignedGroup(String assignedGroup) {
		this.assignedGroup = assignedGroup;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEntryInCurStatus() {
		return entryInCurStatus;
	}
	public void setEntryInCurStatus(String entryInCurStatus) {
		this.entryInCurStatus = entryInCurStatus;
	}
	public String getAsRunningLastInDate() {
		return asRunningLastInDate;
	}
	public void setAsRunningLastInDate(String asRunningLastInDate) {
		this.asRunningLastInDate = asRunningLastInDate;
	}
	public String getAsRunningLastOutDate() {
		return asRunningLastOutDate;
	}
	public void setAsRunningLastOutDate(String asRunningLastOutDate) {
		this.asRunningLastOutDate = asRunningLastOutDate;
	}
	public String getTechSoluType() {
		return techSoluType;
	}
	public void setTechSoluType(String techSoluType) {
		this.techSoluType = techSoluType;
	}
	public String getSwTeamNeeded() {
		return swTeamNeeded;
	}
	public void setSwTeamNeeded(String swTeamNeeded) {
		this.swTeamNeeded = swTeamNeeded;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getJobTypeDetails() {
		return jobTypeDetails;
	}
	public void setJobTypeDetails(String jobTypeDetails) {
		this.jobTypeDetails = jobTypeDetails;
	}
	public String getBusiness() {
		return business;
	}
	public void setBusiness(String business) {
		this.business = business;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getExpectedResolDate() {
		return expectedResolDate;
	}
	public void setExpectedResolDate(String expectedResolDate) {
		this.expectedResolDate = expectedResolDate;
	}
	public String getMachineType() {
		return machineType;
	}
	public void setMachineType(String machineType) {
		this.machineType = machineType;
	}
	public String getMachineTechnology() {
		return machineTechnology;
	}
	public void setMachineTechnology(String machineTechnology) {
		this.machineTechnology = machineTechnology;
	}
	public String getControlPanelType() {
		return controlPanelType;
	}
	public void setControlPanelType(String controlPanelType) {
		this.controlPanelType = controlPanelType;
	}
	public String getMachineTechOg() {
		return machineTechOg;
	}
	public void setMachineTechOg(String machineTechOg) {
		this.machineTechOg = machineTechOg;
	}
	public String getCod() {
		return cod;
	}
	public void setCod(String cod) {
		this.cod = cod;
	}
	public String getCostingProjectCharged() {
		return costingProjectCharged;
	}
	public void setCostingProjectCharged(String costingProjectCharged) {
		this.costingProjectCharged = costingProjectCharged;
	}
	public String getProjectManager() {
		return projectManager;
	}
	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}
	public String getInstaManagerCoordinator() {
		return instaManagerCoordinator;
	}
	public void setInstaManagerCoordinator(String instaManagerCoordinator) {
		this.instaManagerCoordinator = instaManagerCoordinator;
	}
	public String getProblemDesc() {
		return problemDesc;
	}
	public void setProblemDesc(String problemDesc) {
		this.problemDesc = problemDesc;
	}
	public String getCin() {
		return cin;
	}
	public void setCin(String cin) {
		this.cin = cin;
	}
	public String getAssignedFun() {
		return assignedFun;
	}
	public void setAssignedFun(String assignedFun) {
		this.assignedFun = assignedFun;
	}
	public String getActVsSupMateSol() {
		return actVsSupMateSol;
	}
	public void setActVsSupMateSol(String actVsSupMateSol) {
		this.actVsSupMateSol = actVsSupMateSol;
	}
	public String getSupplierNameMateSol() {
		return supplierNameMateSol;
	}
	public void setSupplierNameMateSol(String supplierNameMateSol) {
		this.supplierNameMateSol = supplierNameMateSol;
	}
	public String getSolDesc() {
		return solDesc;
	}
	public void setSolDesc(String solDesc) {
		this.solDesc = solDesc;
	}
	public String getAsRunningNeeded() {
		return asRunningNeeded;
	}
	public void setAsRunningNeeded(String asRunningNeeded) {
		this.asRunningNeeded = asRunningNeeded;
	}
	public String getMateNeeded() {
		return mateNeeded;
	}
	public void setMateNeeded(String mateNeeded) {
		this.mateNeeded = mateNeeded;
	}
	public String getSupplierResp() {
		return supplierResp;
	}
	public void setSupplierResp(String supplierResp) {
		this.supplierResp = supplierResp;
	}
	public String getWfcaTimeInFulfSp() {
		return wfcaTimeInFulfSp;
	}
	public void setWfcaTimeInFulfSp(String wfcaTimeInFulfSp) {
		this.wfcaTimeInFulfSp = wfcaTimeInFulfSp;
	}
	public String getWfcaTimeInImple() {
		return wfcaTimeInImple;
	}
	public void setWfcaTimeInImple(String wfcaTimeInImple) {
		this.wfcaTimeInImple = wfcaTimeInImple;
	}
	public String getWfcaTimeInAsBuilt() {
		return wfcaTimeInAsBuilt;
	}
	public void setWfcaTimeInAsBuilt(String wfcaTimeInAsBuilt) {
		this.wfcaTimeInAsBuilt = wfcaTimeInAsBuilt;
	}
	public String getWfcaTimeInExpertAss() {
		return wfcaTimeInExpertAss;
	}
	public void setWfcaTimeInExpertAss(String wfcaTimeInExpertAss) {
		this.wfcaTimeInExpertAss = wfcaTimeInExpertAss;
	}
	
	
	

}
