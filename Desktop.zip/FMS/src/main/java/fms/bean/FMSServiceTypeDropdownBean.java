package fms.bean;

import java.io.Serializable;

public class FMSServiceTypeDropdownBean implements Serializable {

	private static final long serialVersionUID = -9206930927709070977L;
	private String serviceType;

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	
	
}
