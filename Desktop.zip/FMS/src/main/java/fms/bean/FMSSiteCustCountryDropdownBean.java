package fms.bean;

import java.io.Serializable;

public class FMSSiteCustCountryDropdownBean implements Serializable {

	private static final long serialVersionUID = 3560785715698733136L;
	private String siteCustCountry;

	public String getSiteCustCountry() {
		return siteCustCountry;
	}

	public void setSiteCustCountry(String siteCustCountry) {
		this.siteCustCountry = siteCustCountry;
	}
	
}
