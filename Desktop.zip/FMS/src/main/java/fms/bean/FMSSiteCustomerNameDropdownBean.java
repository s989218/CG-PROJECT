package fms.bean;

import java.io.Serializable;

public class FMSSiteCustomerNameDropdownBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5462451286891221871L;

	private String customerName;

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

}
