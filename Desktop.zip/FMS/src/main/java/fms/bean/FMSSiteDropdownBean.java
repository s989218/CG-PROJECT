package fms.bean;

import java.io.Serializable;

public class FMSSiteDropdownBean implements Serializable {
	
	private static final long serialVersionUID = -130890036803647618L;
	private String siteName;

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	

}
