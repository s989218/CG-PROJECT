package fms.bean;

import java.io.Serializable;

public class FMSSiteNameAliasDropdownBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5462451286891221871L;

	private String siteNameAlias;

	public String getSiteNameAlias() {
		return siteNameAlias;
	}

	public void setSiteNameAlias(String siteNameAlias) {
		this.siteNameAlias = siteNameAlias;
	}

	

}
