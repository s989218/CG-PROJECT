package fms.bean;

import java.io.Serializable;

public class FMSSrcNewSegmentDropdownBean implements Serializable {

	private static final long serialVersionUID = 8892114151607962675L;
	private String srcNewSegment;
	public String getSrcNewSegment() {
		return srcNewSegment;
	}
	public void setSrcNewSegment(String srcNewSegment) {
		this.srcNewSegment = srcNewSegment;
	}

	
	
}
