package fms.bean;

import java.io.Serializable;

public class FMSStringDropdownBean implements Serializable {

	private static final long serialVersionUID = -1639121618579225523L;
	
	private String strColumn;

	public String getStrColumn() {
		return strColumn;
	}

	public void setStrColumn(String strColumn) {
		this.strColumn = strColumn;
	}
}
