package fms.bean;

import java.io.Serializable;

public class FMSTechnologyDropdownBean implements Serializable {
	
	private static final long serialVersionUID = -2119614842060576884L;
	private String technology;

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}
	

}
