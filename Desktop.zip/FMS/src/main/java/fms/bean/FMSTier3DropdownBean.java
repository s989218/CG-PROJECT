package fms.bean;

import java.io.Serializable;

public class FMSTier3DropdownBean implements Serializable {

	private static final long serialVersionUID = -7582460917637851152L;
	private String teir3;

	public String getTeir3() {
		return teir3;
	}

	public void setTeir3(String teir3) {
		this.teir3 = teir3;
	}
	
}
