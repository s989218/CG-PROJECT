package fms.bean;

import java.io.Serializable;

public class FMSTier4DropdownBean implements Serializable {

	private static final long serialVersionUID = 116235669318767515L;
	private String tier4;

	public String getTier4() {
		return tier4;
	}

	public void setTier4(String tier4) {
		this.tier4 = tier4;
	}
	
}
