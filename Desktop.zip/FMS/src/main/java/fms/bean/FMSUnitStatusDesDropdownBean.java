package fms.bean;

import java.io.Serializable;

public class FMSUnitStatusDesDropdownBean implements Serializable {

	private static final long serialVersionUID = 8754178180404002057L;
	private String unitStatusDesc;

	public String getUnitStatusDesc() {
		return unitStatusDesc;
	}

	public void setUnitStatusDesc(String unitStatusDesc) {
		this.unitStatusDesc = unitStatusDesc;
	}
	
}
