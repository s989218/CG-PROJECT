package fms.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class FMSUserBean implements Serializable {

	private static final long serialVersionUID = -1639121618579225523L;
	
	private String userId;
	private String userFirstName;
	private String userLastName;
	private String userEmailId;
	private String userActiveFlag;
	private String userCrtdBy;
	private String userUpdtBy;
	private Date   userCrtdDt;
	private Date   userUpdtDt;
	private List<FMSUserRoleBean> userRoles;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserFirstName() {
		return userFirstName;
	}
	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}
	public String getUserLastName() {
		return userLastName;
	}
	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}
	public String getUserEmailId() {
		return userEmailId;
	}
	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}
	public String getUserActiveFlag() {
		return userActiveFlag;
	}
	public void setUserActiveFlag(String userActiveFlag) {
		this.userActiveFlag = userActiveFlag;
	}
	public String getUserCrtdBy() {
		return userCrtdBy;
	}
	public void setUserCrtdBy(String userCrtdBy) {
		this.userCrtdBy = userCrtdBy;
	}
	public String getUserUpdtBy() {
		return userUpdtBy;
	}
	public void setUserUpdtBy(String userUpdtBy) {
		this.userUpdtBy = userUpdtBy;
	}
	public Date getUserCrtdDt() {
		return userCrtdDt;
	}
	public void setUserCrtdDt(Date userCrtdDt) {
		this.userCrtdDt = userCrtdDt;
	}
	public Date getUserUpdtDt() {
		return userUpdtDt;
	}
	public void setUserUpdtDt(Date userUpdtDt) {
		this.userUpdtDt = userUpdtDt;
	}
	public List<FMSUserRoleBean> getUserRoles() {
		return userRoles;
	}
	public void setUserRoles(List<FMSUserRoleBean> userRoles) {
		this.userRoles = userRoles;
	}
}
