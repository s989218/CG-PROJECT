package fms.bean;

import java.io.Serializable;

public class FMSUserRoleBean implements Serializable {
	private static final long serialVersionUID = -1639121618579225523L;
	
	private int roleId;
	private String roleName;
	private String defaultRole;
	private String roleActiveFlag;
	
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getDefaultRole() {
		return defaultRole;
	}
	public void setDefaultRole(String defaultRole) {
		this.defaultRole = defaultRole;
	}
	public String getRoleActiveFlag() {
		return roleActiveFlag;
	}
	public void setRoleActiveFlag(String roleActiveFlag) {
		this.roleActiveFlag = roleActiveFlag;
	}
}
