package fms.constants;

public class FMSVariableConstants {

	public static final String NULL_STRING = "";
	
	public static final String GE_INSPIRA_FONT = "GE Inspira";
	
	public static final String DEFAULT = "DEFAULT";
	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";
	public static final String STARTED = "STARTED";
	public static final String WARNING = "WARNING";
	public static final String UPDATED = "UPDATED";		
	public static final String SITENAME = "siteName";
	public static final String CUSTNAME = "custName";
	public static final String REGION = "region";
	public static final String COUNTRY = "country";
	public static final String SITE = "site";
	public static final String WORLDSITE = "worldSite";
	public static final String UNMAPPEDSITE = "unmappedSite";
	public static final String GEDUNSNAME = "geCustomerDunsName";
	public static final String SUBREGION = "subregion";
	public static final String PANDL = "pandL";
	public static final String OUNAME = "ouName";
	public static final String OGREGION = "ogRegion";
	public static final String ENDUSERCOUNTRYDISC = "endUserCountryDisc";
	public static final String MOTHERJOB = "motherJob";
	public static final String ENDUSERCUSTNAME = "enduserCustName";
	public static final String COSTINGPROJECT = "costingProject";
	public static final String ORDERTYPE = "orderType";
	public static final String WEEK = "week";
	public static final String MARKET = "market";
	public static final String SERIALNUM = "serialNum";
	public static final String SERVICELEVEL = "serviceLevel";
	public static final String MAINTPOLICY = "maintPolicy";
	public static final String CUSTOMERNAME = "customerName";
	public static final String UNITSTATUSDESC = "unitStatusDesc";
	public static final String SITECUSTCOUNTRY = "siteCustCountry";
	public static final String SERVRELATIONDESCONG = "servRelationDescOng";
	public static final String MARKETSEGMENTDESC = "marketSegmentDesc";
	public static final String EQUIPCODE = "equipCode";
	public static final String MAINTPOLICYCODE = "maintPolicyCode";
	public static final String SITECUSTNAME = "siteCustName";
	public static final String SITENAMEALIAS = "siteNameAlias";
	public static final String EQUIPMENTCODEFILTER = "equipmentCodeFilter";
	public static final String BUSINESS_SEG_FILTER = "businessSegmentFilter";
	public static final String TECHNOLOGY = "technology";
	public static final String POLICY = "policy";
	public static final String TOTAL = "total";
	public static final String SERVICES = "services";
	public static final String LEVEL = "level";
	public static final String VALUE = "value";
	public static final String OPTION = "option";
	public static final String EXPORT = "export";
	public static final String EXPORTALL = "exportAll";
	public static final String HRS = "hrs";
	public static final String MANPOWER = "manpower";
	public static final String REPAIRS = "repairs";
	public static final String PARTS = "parts";
	public static final String AGE = "age";
	public static final String AUX = "aux";
	public static final String POLICYAGGR = "policyAggr";
	public static final String IBODATA = "IBOData";
	public static final String IBOCOUNTRY = "IBOCountry";
	public static final String IBCOUNTRY = "IBCountry";
	public static final String IBDATA = "IBData";
	public static final String ORDERSDATA = "OrdersData";
	public static final String ORDERSCOUNTRY = "OrdersCountry";
	public static final String DATA = "data";
	public static final String PARTS_STATUS="parts_status";
	public static final String FINANCIALPARTSTATUS = "financial_parts_status";
	public static final String P_R_BY_O="p_r_by_o";
	public static final String CHARTTYPE = "chart_type";	
	public static final String KEYDEALS = "keydeals";
	public static final String RISKS="risks";
	public static final String OPPS="opps";
	public static final String PRODUCT ="product";
	public static final String BUSINESSSEGMENT ="businessSegment";
	
	public static final String DATE = "DATE";
	public static final String HEADER = "HEADER";
	public static final String INTEGER = "INTEGER";
	public static final String STRING = "STRING";
	public static final String FLOAT = "FLOAT";
	public static final String DOUBLE = "DOUBLE";
	public static final String CONTENTDISPOSITION = "Content-Disposition";
	public static final String COLORR = "red";
	public static final String COLORG = "green";
	public static final String COLORY = "yellow";
	
	public static final String DMDATA = "DMData";
	public static final String DMCOUNTRY = "DMCountry";
	public static final String REVREC = "RevRec";
	
	public static final String PROJECTMANAGER = "projectManager";
	public static final String PROJECTMANAGER_WITH_UNDERSCORE = "project_manager";
	
	public static final String OUTAGEDATA = "OutageData";
	public static final String OUTAGECOUNTRY = "OutageCountry";  
	
	public static final String SERVICEDATA = "serviceData";
	public static final String SERVICECOUNTRY = "serviceCountry";
	
	public static final String REGANDTECH ="regionAndTech";
	public static final String TOPCUSTOMER = "topCustomers";

	public static final String OEM_LOC = "oemLoc";

	public static final String SITE_CUST_DUNS_NAME = "siteCustDunsName";
	
	public static final String SITE_CUST_ALIAS = "siteCustAlias";
	
	public static final String SM_SEGMENT_MAPPING = "smSegmentMapping";

	public static final String PM_PRODUCT_MAPPING = "pmProductMapping";

	public static final String ME_TIER4 = "meTier4";

	public static final String ME_DM_TIER3 = "meDMTier3";
	
	public static final String TABLE = "Table";
	public static final String TABLEHEADERS = "TableHeaders";
	public static final String CHART = "Chart";
	
	public static final String VOP = "VOP";
	public static final String VPE = "VPE";
	public static final String TX = "TX";
	public static final String CS = "CS";
	public static final String INST = "INST";
	public static final String SC = "SC";
	public static final String TOT = "TOT";
	public static final String GAP= "GAP";
	public static final String OP = "OP";
	public static final String NAME = "name";
	public static final String SHOWINLEGEND = "showInLegend";
	public static final String COLOR = "color";
	public static final String ID = "id";
	public static final String OTHER = "OTHER";

	public static final String CE = "CE";
	public static final String PE = "PE";
	public static final String INS = "INS";
	public static final String TMS = "TMS";
	public static final String APAC = "APAC";
	public static final String AMERICAS = "AMERICAS";
	public static final String APANZ = "APANZ";
	public static final String CHINA = "CHINA";
	public static final String EUROPE = "EUROPE";
	public static final String ATM = "ATM";
	public static final String INDIA = "INDIA";
	public static final String LATAM = "LATAM";
	public static final String MENAT = "MENAT";
	public static final String NORTHAMERICA = "NORTHAMERICA"; 
	public static final String MET = "MET";
	public static final String NAM = "NAM";
	public static final String RCIS = "RCIS";
	public static final String SSA = "SSA";
	public static final String HQ = "HQ";
	public static final String RISK = "RISK";
	public static final String OPP = "OPP";
	public static final String BLANK = "BLANK";
	public static final String ACTUAL = "Actual";
	public static final String UNCONFIRMED = "Unconfirmed";
	
	public static final String FIELDSERVICES = "FIELD SERVICES";
	public static final String REPAIR = "REPAIRS";
	public static final String OTHERGELE = "OTHER GE LE";
	public static final String CT = "CT";
	public static final String COQ = "COQ";
	public static final String CONVTOGO = "CONVTOGO";
	public static final String STRETCH = "STRETCH";
	public static final String PART = "PARTS";
	
	public static final String BACKLOGPE = "backlog_pe";
	public static final String CWD = "cwd";
	public static final String BACKLOG = "BACKLOG";
	public static final String CONV = "CONV";
	
	public static final String PSTATUS = "p_status";
	public static final String CONCATENATE = "concatenate";
	
	public static final String DBERROR = "\"DATABASE ERROR\"";
	public static final String ERROR = "ERROR";
	public static final String ERRORMESSAGE = "Some issue was encountered, please check logs";
	
	public static final String ROW = "row_";
	public static final String ROW0 = "row_0";
	public static final String ROW1 = "row_1";
	public static final String ROW2 = "row_2";
	public static final String ROW3 = "row_3";
	public static final String ROW4 = "row_4";
	public static final String ROW5 = "row_5";
	public static final String ROW6 = "row_6";
	public static final String ROW7 = "row_7";
	public static final String ROW8 = "row_8";
	public static final String ROW9 = "row_9";
	
	public static final String COLOR1 = "#ffc700";
	public static final String COLOR2 = "#A6A6A6";
	public static final String COLOR3 = "#595959";
	public static final String COLOR4 = "#ffffff";
	
	public static final String CURRENT = "CURRENT";
	public static final String FUTURE = "FUTURE";
	public static final String AVERAGE = "AVERAGE";
	
	public static final String HISTORY = "HISTORY";
	public static final String SALESYRQTR = "sales_year_qtr";
	public static final String EXCEPTION = "Exception ";
	public static final String PRINTSTACKTRACE = "Print Stack Trace ";
	public static final String ACCOUNTTYPE = "accountType";
	public static final String DATABASEERROR = "DATABASE ERROR";
	public static final String TRUNCATE = "truncate success : ";
	
	public static final String DBEXCEPTION = " DB error, check for stackTrace : ";
	public static final Object ROLE_ID = "roleId";
	public static final String DTS_SEGMENT = "DTS";
	public static final String TMS_SEGMENT = "TMS";
	public static final String FORECASTED = "forecasted";
	public static final String ADDED = "added";
	public static final String REMOVED = "removed";
	public static final String NEWFORECASTED = "new_forecast";
	public static final String SUMCM = "sum_cm";
	public static final String SEQPARTSSTAUS = "seq_parts_status";
	public static final String CAPTION = "caption";
	public static final String TABLEDATA = "tableData";
	public static final String CHARTDATA = "chartData";
	public static final String BOXOLDDOGS = "boxOldDogs";
	public static final String CWDEXPIRED = "cwdExpired";
	public static final String PROMISEDATE = "promiseDate";
	public static final String DUMMYCODES = "dummyCodes";
	public static final String FINANCIALVIEW = "financialView";
	public static final String IPMRAWDATA = "ipmRawData";
	public static final String DAYRANGE = "day_range";
	public static final String TABLECOLUMNHEADERS = "tableColumnHeaders";
	public static final String SALEDATEYEARQTR = "sales_date_year_qtr";
	public static final String COPY = "COPY ";
	
	public static final String TECHNOLOGYDESCRIPTION = "technologyDescription";
	public static final String REGIONDESCRIPTION = "regionDescription";
	public static final String COUNTRYDESCRIPTION = "countryDescription";
	public static final String SITECUSTDESC = "siteCustomerDescription";
	public static final String GEDUNS = "geDunsName";
	public static final String SEGMENT = "segment";
	public static final String TIER3 = "tier3";
	public static final String SERIALNUMBER = "serialNumber";
	public static final String METRICS = "metrics";
	public static final String UNIT = "unit";
	public static final String IB = "IB";
	public static final String IBO = "IBO";
	public static final String ORDERS = "Orders";
	public static final String DM = "dm";
	public static final String OUTAGES = "Outages";
	public static final String SERVICEREQUESTTITLE = "Service Request";
	public static final String SERVICEREQUEST = "serviceRequest";
	public static final String IBIBO = "IB/IBO";
	
	public static final String DOLLARIB = "dollarByIB";
	public static final String FLEETCOVERAGE = "fleetCoverage";
	public static final String FLEETPEN = "fleetPenetration";
	public static final String FLEETPENF2F = "fleetPenF2F";
	public static final String CALORICINDEX = "caloricIndex";
	public static final String CONVERSIONINDEX = "conversionIndex";
	
	public static final String TOP25 = "top25";
	public static final String BOTTOM25 = "bottom25";
	public static final String TYPE = "type";
	public static final String REPORT = "report";
	public static final String PERIOD ="period";
	
	public static final String BOXOLDDOGSCAP = "BOX OLD DOGS";
	public static final String CWDEXPIREDCAP = "CWD EXPIRED";
	public static final String PROMISEDATECAP = "PROMISE DATE";
	public static final String DUMMYCODESCAP = "DUMMY CODES";
	
	public static final String COUNTRY_NAME = "countryName";
    public static final String SERVICE_TYPE = "serviceType";
    public static final String END_USER_NAME = "endUserName";

	public static final String IB_TECH_REG = "ibTechReg";

	public static final String ORDERS_TECH_REG = "ordersTechReg";
	
	public static final String DM_TECH_REG = "dmTechReg";
	public static final String OUTAGE_TECH_REG = "outageTechReg";
	public static final String SERVICE_TECH_REG = "serviceTechReg";
	
	public static final String PRIMARY_REGION= "primaryRegion";
	public static final String FORECAST_CATEGORY= "forecastCategory";
	public static final String BUSINESS_TIER_3= "businessTier3";
	public static final String PRIMARY_COUNTRY= "primaryCountry";
	public static final String C_QTR= "cQtr";
	public static final String ACCOUNT_NAME= "accountName";
	public static final String RISK_PATH= "riskPath";
	public static final String ACCOUNT_CLASS= "accountClass";
	
	public static final String YEAR = "year";
	public static final String QUARTER = "quarter";
	public static final String CUSTOMER_NAME= "customerName";
	public static final String EQUIPMENT = "equipment";
	public static final String LOCATION = "location";
	public static final String UNIT_STATUS= "unitStatus";
	public static final String SERVICE_REL_1 = "serviceRel";
	public static final String DUNS_NAME= "dunsName";
	public static final String ACC_MGR_EMAIL = "accMgrEmail";
	public static final String SERV_MGR_EMAIL= "serviceMgrEmail";
	public static final String MAINT_LVL_DESC = "maintLvlDesc";
	public static final String EVNT_STATUS_DESC = "eventStatusDesc";
	
	
	public static final String CASE_NUMBER= "case_number";
	public static final String OPENED = "opened";
	public static final String TYPE_OF_ISSUE = "current_type_of_issue";
	public static final String PROJECT_PHASE = "project_phase";
	public static final String STATE = "state";
	public static final String STAGE = "stage";
	public static final String OPPTY_EXTRN_ID = "opptyExternalId";
	public static final String ASSGND_GRP = "assigned_group";
	public static final String STATUS = "status";
	public static final String ENTRY_IN_CUR_STATUS= "entry_in_the_cur_status";
	public static final String JOB_TYPE = "job_type";
	public static final String CSTMR_NAME = "customer_name";
	public static final String MAC_TECHNOLOGY = "machine_technology_og";
	public static final String EVENT_YEAR = "event_year";
	public static final String EVENT_QUARTER = "event_quarter";	
	
	public static final String OVERALL = "OVERALL";
	public static final String INVOICE_NUMBER = "invoice_number";
	public static final String BOX_ID = "box_id";
	public static final String OPERATOR_EQUALS_VAL = " = ?";
	public static final String QMI="qmi";
	public static final String P_CONCATENATE = "p_concatenate";
	public static final String BOX_NUMBER = "box_number";
					
	public static final String CURRENT_YEAR_QUARTER_CONDITION = " WHERE year = (SELECT EXTRACT(year FROM current_timestamp - interval '3 month')) AND quarter = (SELECT CONCAT(EXTRACT( quarter FROM date_trunc('quarter', current_date)::date-1),'Q'))";
	public static final String OVERALL_YEAR_QUARTER_CONDITION = " WHERE year IS NULL AND quarter IS NULL";
	
	public static final String YEAR_QUARTER_RANGE_PEN_METRICS = ",(SELECT DISTINCT t1.year ||'-'|| t1.quarter as year_quarter_min FROM fms_metrics_sites t1 WHERE t1.year IS NOT NULL and t1.quarter IS NOT NULL ORDER BY year_quarter_min LIMIT 1) AS year_quarter_min,(SELECT DISTINCT t2.year ||'-'|| t2.quarter as year_quarter_max FROM fms_metrics_sites t2 WHERE t2.year IS NOT NULL and t2.quarter IS NOT NULL ORDER BY year_quarter_max DESC LIMIT 1) AS year_quarter_max";
	
	public static final String AVERAGE_BASED_ON_YEAR = "AVERAGE_BASED_ON_YEAR";
	public static final String ROUND_TO_2_PLACES = "ROUND(avg(tab.average),2)";
	public static final String ROUND_TO_0_PLACES = "ROUND(avg(tab.average))";
	public static final String BOTTOM_25 = "average limit 25";
	public static final String TOP_25 = "average DESC limit 25"; 
	public static final String BOTTOM_LIMIT_25 = "limit 25";
	public static final String TOP_LIMIT_25 = "DESC limit 25"; 
	public static final String EXPORT_SITE_LEVEL_AVG_YEAR =  "average DESC";
	public static final String EMPTY_STRING = "";
	public static final String AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION = "AND year >= 2017";
	public static final String YEAR_GREATER_THAN_2014 = "AND year > 2014";
	
	public static final String ORDERS_CSV_EXPORT = "OrderCsvData";
	public static final String REVENUE_CSV_EXPORT = "RevenueCsvData";
	public static final String GEDUNS_CSV_EXPORT = "GeDunsName";
	
	public static final String NO_REVENUE = "No Revenue";
	public static final String NO_ORDERS = "No Orders";
	
	public static final String DESC = "DESC";
	public static final String ASC = "ASC";
	public static final String YEAR_QTR = "yearQtrDescription";
	
	public static final String ACC_MGR = "accountManager";
	public static final String GE_DUNS = "geDuns";
	
	public static final String EXIST = "exist";
	public static final String DO_NOT_EXIST = "doNotExist";
	public static final String TILDE_SEPARATOR = "~";
	public static final String USER_COUNT_0 = "0";
	public static final String USER_COUNT_1 = "1";
	
	public static final String ADD_USER = "addUser";
	public static final String FIRST_NAME = "firstName";
	public static final String LAST_NAME = "lastName";
	public static final String EMAIL = "email";
	public static final String ACTIVE = "active";
	public static final String SSO_ID = "sso";
	public static final String TASK_NAME = "taskName";
	public static final String FILE_NAME = "fileName";
	public static final String INVALID_COUNT = "invalidCount";
	public static final String CREATED_BY = "createdBy";
	public static final String UPDATED_BY = "updatedBy";
	public static final String USER_ROLE = "role";
	public static final String USER_PRESENT = "User Exists Already with the SSO : ";
	public static final String USER_NOT_PRESENT = "User does not Exist with the SSO : ";
	public static final String ACTION = "action";
	public static final String DELETE_USER = "deleteUser";
	public static final String EDIT_USER = "editUser";
	
	public static final String F_NAME = "First Name";
	public static final String L_NAME = "Last Name";
	public static final String U_SSO = "SSO";
	public static final String U_EMAIL = "Email";
	public static final String ROLE = "Role";
	public static final String EXPORT_STATUS = "Status";
	public static final String EXPORT_ROLE_NAME = "Role Name";
	public static final String EXPORT_ROLE_NAME_DESC = "Role Name Desc";
	public static final String EXPORT_ACTIVE = "Active";
	
	public static final String ROLE_NAME = "roleName";
	public static final String ROLE_DESC = "roleNameDesc";
	public static final String ROLE_PRESENT_1 = "Rolename : ";
	public static final String ROLE_PRESENT_2 = " Already exists";
	public static final String ROLE_PRESENT_3 = "Role Id : ";
	public static final String ADD_ROLE = "addRole";
	public static final String DELETE_ROLE = "deleteRole";
	public static final String EDIT_ROLE = "editRole";
	
	public static final String EXPORT_USER_DETAILS_FILENAME = "All User Details";
	public static final String EXPORT_ROLE_DETAILS_FILENAME = "All Role Details";
	public static final String EXPORT_USER_DETAILS_TYPE_USER = "userData";
	public static final String EXPORT_USER_DETAILS_TYPE_ROLE = "rolesData";
	
	public static final String SERVICE_MANAGER_DETAILS = "serviceManagerDetails";
	public static final String ACCOUNT_MANAGER_DETAILS = "accountManagerDetails";
	public static final String USER_SSO ="userSSO";
	public static final String FILE_ID = "fileId";
	public static final String IN_PROGRESS = "In-Progress";
	
	public static final String CALORIC_INDEX = "caloric_index";
	public static final String DOLLAR_BY_IB = "dollar_by_ib";
	public static final String CONVERSION_INDEX= "conversion_index";
	public static final String PARTS_FLEET_PENETRATION = "parts_fleet_penetration";
	public static final String REPAIRS_FLEET_PENETRATION= "repairs_fleet_penetration";
	public static final String SVCS_FLEET_PENETRATION= "svcs_fleet_penetration";
	public static final String IBO_BY_REGION= "ibo_by_region";
	public static final String REV_DOLLAR_BY_REGION= "rev_dollar_by_region";
	public static final String IBO_BY_TECH = "ibo_by_tech";
	public static final String P_STATUS= "p_status";
	public static final String P_NEW_DATE= "p_new_date";
	public static final String BILLING= "BILLING";
	public static final String SHIPPED= "SHIPPED";
	public static final String SHIPPING= "SHIPPING";
	public static final String SALES= "SALES";
	public static final String AVERAGE_YEAR= "Average_Year";
	public static final String STATECOORDINATES= "StateCoordinates";
	public static final String SITEINFO= "siteInfo";
	public static final String IMPORT_COMPLETED = "Import Completed!";
	public static final String IMPORT_STARTED = "Import started...";
	public static final String CONFIRMED = "CONFIRMED";
	
	public static final String MANAGER_TYPE = "managerType";
	public static final String SERVICE_MANAGERS = "serviceManagers";
	public static final String ACCOUNT_MANAGERS = "accountManagers";
	public static final String SERVICE_MANAGERS_DROPDOWN = "COALESCE(fms_ibas_equipment.c_service_mgr_last||', '||fms_ibas_equipment.c_service_mgr_first||' <'||fms_ibas_equipment.c_service_mgr_email||'>','' )  ~* ?";
	public static final String ACCOUNT_MANAGERS_DROPDOWN = "COALESCE(fms_ibas_equipment.c_account_mgr_last||', '||fms_ibas_equipment.c_account_mgr_first||' <'||fms_ibas_equipment.c_account_mgr_email||'>','' )  ~* ?";
	
	public static final String IBO_VALUE = "ibo_value";
	public static final String FINANCIAL_VIEW = "Financial View";
	public static final String PMO_TREND = "PMO - Trend";
	public static final String IB_EXP = "IB";
	public static final String ORDERS_EXP = "orders";
	public static final String DM_EXP = "DM";
	public static final String OUTAGES_EXP = "outages";
	public static final String SERVICE_REQUEST_EXP = "serviceRequest";
	public static final String PARAM_SEPARATOR = " ~ ";
	public static final String USER_SYNC= "User Sync ";
	public static final String EVERYDAY_BACKUP = "Everyday Backup";
	
	public static final String C_PROD_EXC_PL_DTS = "DTS";
	public static final String C_PROD_EXC_PL_TMS = "TMS";
	public static final String C_PROD_EXC_PL__ALL = "ALL";
	public static final String BUSINESS_SEG = "businessSegment";
	
	public static final String PEN_METRICS_REG_YR_AVG_HIST_COND = " and year::text||quarter <> '20171Q' ";
	public static final String PEN_METRICS_REG_AVG_CALORIC_COND = " and caloric_index != -9999 ";
	public static final String PEN_METRICS_REG_AVG_CONVERSION_COND = " and conversion_index != -9999 ";
	
	public static final String CONVERSION = "Spotfire Conversion : ";
	public static final String DAILY_UPDATE = " || Daily Update : ";
	public static final String RETENTION = " || Retention : ";
	
	public static final String ME_MAPPING = " ME Mpng : ";
	public static final String ORDER_MAPPING = " || Order Mpng : ";
	public static final String FUZZY = " || Fuzzy : ";
	public static final String ALL_METRICS = " || All Metrics : ";
	public static final String TECH_COUNTRY_BREAK = " || Tech Cntry Brk : "; 
	public static final String SITES_BREAK = " || Sites Brk : ";
	public static final String SEGMENT_BREAK = " || Seg Brk : ";
	public static final String SITES_OVERALL = " || Sites OverAll : ";
	public static final String REGION_OVERALL = " || Reg OverAll : ";
	public static final String COUNTRY_OVERALL = " || Cntry OverAll : ";
	
	public static final String COMPLETED = "Completed";
	public static final String ORDERS_MAPPING_SL_ME_ARG1 ="Orders Mapping Done for ME";
	public static final String ORDERS_MAPPING_SL_ME_ARG2 ="storeMappingData~ME";
	public static final String ORDERS_MAPPING_SL_SK_ARG1 ="Orders Mapping Done for SK";
	public static final String ORDERS_MAPPING_SL_SK_ARG2 ="storeMappingData~SK";
	public static final String ORDERS_MAPPING_SL_PK_ARG1 ="Orders Mapping Done for PK";
	public static final String ORDERS_MAPPING_SL_PK_ARG2 ="storeMappingData~PK";
	
	public static final String TIME_PERIOD_TYPE ="timePeriodType";
	public static final String MARKET_INDUSTRY ="marketIndustry";
	public static final String LEGACY ="legacy";
	public static final String LATEST ="latest";
	public static final String MARKET_INDUSTRY_FEILD_1 ="and COALESCE(replace(c_market_industry_desc,'&',''),'') ~* '";
	public static final String MARKET_INDUSTRY_FEILD_2 ="'";
	public static final String UNDERSCORE_LEGACY ="_legacy";
	public static final String LIKE_OPEX ="LIKE UPPER('%Opex%')";
	public static final String ACCOUNT_MANAGER = "accountManager";
	public static final String REGION_NAME = "regionName";
	public static final String PARAM = "param";
	public static final String QTR_SYNC = "Quartely-Sync";
	
	public static final String IBO_TYPE ="iboType";
	public static final String FMS_MAPPING_FUNC_IBAS = "IBAS_IBO";
	public static final String FMS_MAPPING_FUNC_ORDERS = "ORDERS";
	public static final String FMS_MAPPING_FUNC_GEDUNS = "GE_DUNS";
	public static final String FMS_MAPPING_FUNC_SALES = "SALES";
	public static final String MAPPING_FUNC_CALL = "Mapping Started - InProgress";
	public static final String MAPPING_SUCCESS = "Mapping Completed Successfully !!";
	public static final String MAPPING_SERVICE_LOG = "Import Completed, Mapping Started";
	
	
	private FMSVariableConstants(){
		
	}
}