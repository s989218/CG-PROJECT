package fms.dao;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Types;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.poi.util.IOUtils;
import org.json.simple.JSONObject;
import org.postgresql.copy.CopyManager;
import org.postgresql.core.BaseConnection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import fms.bean.FMSAccMgrEmailDropdownBean;
import fms.bean.FMSAllMetricsDetailsVO;
import fms.bean.FMSChooseColumnDataDTO;
import fms.bean.FMSCountryNameDropdownBean;
import fms.bean.FMSCurrentYearDTO;
import fms.bean.FMSCustomerDropdownBean;
import fms.bean.FMSDMAccountClassDTO;
import fms.bean.FMSDMAccountNameDTO;
import fms.bean.FMSDMAccountTypeDTO;
import fms.bean.FMSDMBusinessTierDTO;
import fms.bean.FMSDMDataBean;
import fms.bean.FMSDMFilterDataBean;
import fms.bean.FMSDMForecastCategoryDTO;
import fms.bean.FMSDMMaintLvlDescDTO;
import fms.bean.FMSDMMetricsCustDataBean;
import fms.bean.FMSDMMetricsCustomerDTO;
import fms.bean.FMSDMMetricsDetailsDTO;
import fms.bean.FMSDMMetricsDetailsVO;
import fms.bean.FMSDMMetricsTechDTO;
import fms.bean.FMSDMMetricsTechDataBean;
import fms.bean.FMSDMPathDTO;
import fms.bean.FMSDMPrimaryCountryDTO;
import fms.bean.FMSDMPrimaryRegionDTO;
import fms.bean.FMSDMQtrDTO;
import fms.bean.FMSEndUserNameDropdownBean;
import fms.bean.FMSEquipCodeDropdownBean;
import fms.bean.FMSEquipmentCodeDropdownBean;
import fms.bean.FMSIBFilterDataBean;
import fms.bean.FMSIBMetricsCustDataBean;
import fms.bean.FMSIBMetricsDetailsVO;
import fms.bean.FMSIBMetricsDropdownsVO;
import fms.bean.FMSIBMetricsTechDataBean;
import fms.bean.FMSIBOMetricsCustDataBean;
import fms.bean.FMSIBOMetricsDetailsVO;
import fms.bean.FMSIBOMetricsTechDataBean;
import fms.bean.FMSIBOTypeDropdownBean;
import fms.bean.FMSIBRegionDataBean;
import fms.bean.FMSIBSearchResultsDataBean;
import fms.bean.FMSIBSerachResultsVO;
import fms.bean.FMSIBSerialNumDataBean;
import fms.bean.FMSIBSiteNameDataBean;
import fms.bean.FMSIbasDataBean;
import fms.bean.FMSInstalledBaseDataBean;
import fms.bean.FMSInstldBaseDropdownsVO;
import fms.bean.FMSMaintLvlStatusBean;
import fms.bean.FMSMaintenanceDataBean;
import fms.bean.FMSMarketSegmentDescDropdownBean;
import fms.bean.FMSOpptyExternalIdDTO;
import fms.bean.FMSOrderMappingExcelBean;
import fms.bean.FMSOrderRegionDropdownBean;
import fms.bean.FMSOrdersMetricsCustDataBean;
import fms.bean.FMSOrdersMetricsDataBean;
import fms.bean.FMSOrdersMetricsDetailsVO;
import fms.bean.FMSOrdersMetricsDropdownsVO;
import fms.bean.FMSOrdersMetricsTechDataBean;
import fms.bean.FMSOutLocationDTO;
import fms.bean.FMSOutageDataBean;
import fms.bean.FMSOutageDropdownDTO;
import fms.bean.FMSOutageFilterCustDTO;
import fms.bean.FMSOutageFilterDataDTO;
import fms.bean.FMSOutageFilterTechDTO;
import fms.bean.FMSOutageFilterVO;
import fms.bean.FMSOutageMetricsCustomerDTO;
import fms.bean.FMSOutageMetricsDetailsDTO;
import fms.bean.FMSOutageMetricsTechDTO;
import fms.bean.FMSRegionDropdownBean;
import fms.bean.FMSServRelDescOngDropdownBean;
import fms.bean.FMSServiceMgrEmailDropdownBean;
import fms.bean.FMSServiceReqDataBean;
import fms.bean.FMSServiceTypeDropdownBean;
import fms.bean.FMSSiteCustCountryDropdownBean;
import fms.bean.FMSSiteCustomerNameDropdownBean;
import fms.bean.FMSSiteDropdownBean;
import fms.bean.FMSSiteNameAliasDropdownBean;
import fms.bean.FMSSpotFireDataBean;
import fms.bean.FMSSrcNewSegmentDropdownBean;
import fms.bean.FMSStringDropdownBean;
import fms.bean.FMSTechnologyDropdownBean;
import fms.bean.FMSUnitStatusDesDropdownBean;
import fms.bean.FMSUserBean;
import fms.bean.FMSUserRoleBean;
import fms.constants.FMSQueryConstants;
import fms.constants.FMSVariableConstants;
import fms.impl.OauthAkanaHandler;
import fms.mapper.DMDataMapper;
import fms.mapper.ExportExcelMapperUserManagementMapper;
import fms.mapper.FMSAccMgrEmailDropdownMapper;
import fms.mapper.FMSChooseColumnDataMapper;
import fms.mapper.FMSCountryNameDropdownMapper;
import fms.mapper.FMSCurrentYearMapper;
import fms.mapper.FMSCustomerDropdownMapper;
import fms.mapper.FMSDMAccountClassMapper;
import fms.mapper.FMSDMAccountNameMapper;
import fms.mapper.FMSDMAccountTypeMapper;
import fms.mapper.FMSDMBusinessTierMapper;
import fms.mapper.FMSDMCustMetricsCountryMapper;
import fms.mapper.FMSDMCustomerMetricsMapper;
import fms.mapper.FMSDMForecastCategoryMapper;
import fms.mapper.FMSDMMaintLvlDescMapper;
import fms.mapper.FMSDMNewCustMetricsMapper;
import fms.mapper.FMSDMNewTechMetricsMapper;
import fms.mapper.FMSDMPathMapper;
import fms.mapper.FMSDMPrimaryCountryMapper;
import fms.mapper.FMSDMPrimaryRegionMapper;
import fms.mapper.FMSDMQtrMapper;
import fms.mapper.FMSDMTechMetricsCountryMapper;
import fms.mapper.FMSDMTechMetricsMapper;
import fms.mapper.FMSEndUserNameDropdownMapper;
import fms.mapper.FMSEquipCodeDropdownMapper;
import fms.mapper.FMSEquipmentCodeMapper;
import fms.mapper.FMSEventStatusDescMapper;
import fms.mapper.FMSIBCustMetricsCountryMapper;
import fms.mapper.FMSIBCustMetricsMapper;
import fms.mapper.FMSIBOCustMetricsCountryMapper;
import fms.mapper.FMSIBOCustMetricsMapper;
import fms.mapper.FMSIBOTechMetricsCountryMapper;
import fms.mapper.FMSIBOTechMetricsMapper;
import fms.mapper.FMSIBOTypeMapper;
import fms.mapper.FMSIBTechMetricsCountryMapper;
import fms.mapper.FMSIBTechMetricsMapper;
import fms.mapper.FMSMarketSegmentDropdownMapper;
import fms.mapper.FMSOpptyExternalIdMapper;
import fms.mapper.FMSOrderMetricsCustomerNameMapper;
import fms.mapper.FMSOrderRegionDropdownMapper;
import fms.mapper.FMSOrdersCustMetricsCountryMapper;
import fms.mapper.FMSOrdersCustMetricsMapper;
import fms.mapper.FMSOrdersTechMetricsCountryMapper;
import fms.mapper.FMSOrdersTechMetricsMapper;
import fms.mapper.FMSOutLocationMapper;
import fms.mapper.FMSOutageCustomerMetricsMapper;
import fms.mapper.FMSOutageFilterCustCountryMapper;
import fms.mapper.FMSOutageFilterCustRegMapper;
import fms.mapper.FMSOutageFilterTechCountryMapper;
import fms.mapper.FMSOutageFilterTechRegMapper;
import fms.mapper.FMSOutageTechMetricsMapper;
import fms.mapper.FMSRegionDropdownMapper;
import fms.mapper.FMSSerialInformationMapper;
import fms.mapper.FMSServRelDescDropdownMapper;
import fms.mapper.FMSServiceMgrEmailDropdownMapper;
import fms.mapper.FMSServiceTypeDropdownMapper;
import fms.mapper.FMSSiteCustCountryDropdownMapper;
import fms.mapper.FMSSiteCustomerNameMapper;
import fms.mapper.FMSSiteDropdownMapper;
import fms.mapper.FMSSiteNameAliasMapper;
import fms.mapper.FMSSrcNewSegmentDropdownMapper;
import fms.mapper.FMSStringDropdownMapper;
import fms.mapper.FMSTechnologyDropdownMapper;
import fms.mapper.FMSUnitStatusDropdownMapper;
import fms.mapper.FMSUserMapper;
import fms.mapper.FMSUserRoleMapper;
import fms.mapper.IbasDataMapper;
import fms.mapper.LatLongByRegMapper;
import fms.mapper.LatLongBySiteMapper;
import fms.mapper.MaintenanceMapperCls;
import fms.mapper.MiscRowMapper;
import fms.mapper.OutageDataMapper;
import fms.mapper.RegionLatLongMapper;
import fms.mapper.SerialNumLatLongMapper;
import fms.mapper.ServiceReqDataMapper;
import fms.mapper.SiteInfoInstalledUnitMapper;
import fms.mapper.SiteNameLatLongMapper;
import fms.utils.Utils;

@Repository
public class FMSDaoImpl implements IFMSDao {

	@Autowired
	protected JdbcTemplate jdbc;

	@Value("${spring.datasource.urls}")
	private String url;

	@Value("${spring.datasource.username}")
	private String user;

	@Value("${spring.datasource.password}")
	private String pass;

	@Autowired
	private OauthAkanaHandler akanaHandler;

	private final Logger log = Logger.getLogger(this.getClass());

	DecimalFormat decimalFormat = new DecimalFormat("0.00");

	@Override
	public List<FMSMaintenanceDataBean> getAllMaintenanceDao() {
		return jdbc.query(FMSQueryConstants.RETRIEVE_MAINTENANCE_DATA,  new MaintenanceMapperCls());
	}

	@Override
	public String updateMaintenanceDao(FMSMaintenanceDataBean maintDTO) {
		String response="";

		try {
			response = jdbc.queryForObject(FMSQueryConstants.UPDATE_MAINTENANCE_DATA,new Object[]{maintDTO.getPolicy(),Integer.parseInt(maintDTO.getHours()),maintDTO.getLevel(),Integer.parseInt(maintDTO.getAge()),Double.parseDouble(maintDTO.getParts()),Double.parseDouble(maintDTO.getRepairs()),Double.parseDouble(maintDTO.getServices()),Double.parseDouble(maintDTO.getManpower()),Double.parseDouble(maintDTO.getAux()),Double.parseDouble(maintDTO.getTotal())}, String.class);
		} catch (Exception e) {
			log.info(e);
		}
		return response;
	}

	@Override
	public String insertToMaintenanceDao(FMSMaintenanceDataBean maintDTO) {
		String response="";

		try {
			response = jdbc.queryForObject(FMSQueryConstants.INSERT_MAINTENANCE_DATA,new Object[]{maintDTO.getPolicy(),maintDTO.getPolicyAggr(),maintDTO.getLevel(),Integer.parseInt(maintDTO.getHours()),Integer.parseInt(maintDTO.getAge()), Double.parseDouble(maintDTO.getParts()),Double.parseDouble(maintDTO.getRepairs()),Double.parseDouble(maintDTO.getServices()),Double.parseDouble(maintDTO.getManpower()),Double.parseDouble(maintDTO.getAux()),Double.parseDouble(maintDTO.getTotal())}, String.class);
		} catch (Exception e) {
			log.info(e);
			return FMSVariableConstants.FAILURE;
		}
		return response;
	}

	@Override
	public List<FMSIbasDataBean> getIbasDao() {
		return jdbc.query(FMSQueryConstants.RETRIEVE_IBAS_DATA, new IbasDataMapper());
	}

	@Override
	public String deleteMaintenanceDao(List<String> finalData) {
		String response="";
		Map<String, Object> map = new HashMap<>();
		try{
			final Array stringsArray = jdbc.getDataSource().getConnection().createArrayOf("varchar", finalData.toArray());
			map = jdbc.queryForMap(FMSQueryConstants.DELETE_MAINTENANCE_DATA,stringsArray); 
			for (Map.Entry<String,Object> entry : map.entrySet()) {
				String key = entry.getKey();
				response =(String) map.get(key);
			}     
		}catch(Exception ex){
			log.info(ex);
			return FMSVariableConstants.FAILURE;
		}
		return response;
	}

	public FMSAllMetricsDetailsVO getAllMetricsDao(String businessSegment, Map<String, Object> data) {
		FMSAllMetricsDetailsVO metrcsData = new FMSAllMetricsDetailsVO();
		List<String> reportName =  Utils.getPenetrationMetricsReportNames();
		int size = reportName.size();
		Map<String, Object> historyResult = new HashMap<>();
		Map<String, Object> currentResult = new HashMap<>();
		Map<String, Object> averageResult = new HashMap<>();
		Map<String, Object> report = new HashMap<>();
		String referredTable = null;
		String marketIndustryField = null;
		/** if "LEGACY" else "LATEST" */
		if(Utils.nullCheck(data.get(FMSVariableConstants.TIME_PERIOD_TYPE)).equalsIgnoreCase(FMSVariableConstants.LEGACY)){
			referredTable = FMSVariableConstants.UNDERSCORE_LEGACY;
			businessSegment = FMSVariableConstants.DTS_SEGMENT;
			marketIndustryField = FMSVariableConstants.EMPTY_STRING;
		}else{
			referredTable = FMSVariableConstants.EMPTY_STRING;
			businessSegment = FMSVariableConstants.EMPTY_STRING;
			marketIndustryField = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
		}

		String currentMarketIndustry = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
		try {
			/** Yearly average history */
			for (int index = 0; index < size-2; index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index)) || 
						FMSVariableConstants.CONVERSION_INDEX.equalsIgnoreCase(reportName.get(index)))
					report.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_YEARLY_AVG_HISTORY_REGION,FMSVariableConstants.ROUND_TO_2_PLACES,
									reportName.get(index),referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,FMSVariableConstants.PEN_METRICS_REG_YR_AVG_HIST_COND),new Object[]{businessSegment}, new MiscRowMapper()));
				else if(FMSVariableConstants.PARTS_FLEET_PENETRATION.equalsIgnoreCase(reportName.get(index)) ||  
						FMSVariableConstants.REPAIRS_FLEET_PENETRATION.equalsIgnoreCase(reportName.get(index)) || 
						FMSVariableConstants.SVCS_FLEET_PENETRATION.equalsIgnoreCase(reportName.get(index)))
					report.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_YEARLY_AVG_HISTORY_REGION,FMSVariableConstants.ROUND_TO_0_PLACES,
									reportName.get(index),referredTable,FMSVariableConstants.YEAR_GREATER_THAN_2014,marketIndustryField,FMSVariableConstants.PEN_METRICS_REG_YR_AVG_HIST_COND),new Object[]{businessSegment}, new MiscRowMapper()));
				else
					report.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_YEARLY_AVG_HISTORY_REGION,FMSVariableConstants.ROUND_TO_0_PLACES,
									reportName.get(index),referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,FMSVariableConstants.PEN_METRICS_REG_YR_AVG_HIST_COND),new Object[]{businessSegment}, new MiscRowMapper()));
			}
			for (int index = size-2; index < size; index++) {
				report.put(reportName.get(index), 
						jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_YEARLY_AVG_HISTORY_TECH,reportName.get(index),referredTable,marketIndustryField),new Object[]{businessSegment}, new MiscRowMapper()));
			}

			/** History */
			for (int index = 0; index < size-2; index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					historyResult.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_REGION_HISTORY_DATA,2,0.00,reportName.get(index),
									referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField),new Object[]{businessSegment}, new MiscRowMapper()));
				}else if(FMSVariableConstants.PARTS_FLEET_PENETRATION.equalsIgnoreCase(reportName.get(index)) || 
						FMSVariableConstants.REPAIRS_FLEET_PENETRATION.equalsIgnoreCase(reportName.get(index)) || 
						FMSVariableConstants.SVCS_FLEET_PENETRATION.equalsIgnoreCase(reportName.get(index))){
					historyResult.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_REGION_HISTORY_DATA,0,0,reportName.get(index),
									referredTable,FMSVariableConstants.YEAR_GREATER_THAN_2014,marketIndustryField),new Object[]{businessSegment}, new MiscRowMapper()));
				} else {
					historyResult.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_REGION_HISTORY_DATA,0,0,reportName.get(index),
									referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField),new Object[]{businessSegment}, new MiscRowMapper()));
				}
			}
			for (int index = size-2; index < size; index++) {
				historyResult.put(reportName.get(index), 
						jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_TECH_HISTORY_DATA,0,0,
								reportName.get(index),referredTable,marketIndustryField),new Object[]{businessSegment}, new MiscRowMapper()));
			}

			/** Current */
			for (int index = 0; index < size-2; index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					currentResult.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_REGION_CURRENT_DATA,
									reportName.get(index),2,0.00,currentMarketIndustry),new Object[]{FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
				}else {
					currentResult.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_REGION_CURRENT_DATA,
									reportName.get(index), 0,0,currentMarketIndustry),new Object[]{FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
				}
			}
			for (int index = size-2; index < size; index++) {
				currentResult.put(reportName.get(index), 
						jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_TECH_CURRENT_DATA,
								reportName.get(index),0,0,currentMarketIndustry),new Object[]{FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
			}

			/** Average */
			for (int index = 0; index < size-2; index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					if(FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
						averageResult.put(reportName.get(index), 
								jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_REGION_AVERAGE_DATA,2,0.00,reportName.get(index),
										referredTable,FMSVariableConstants.PEN_METRICS_REG_AVG_CALORIC_COND,marketIndustryField),new Object[]{businessSegment}, new MiscRowMapper()));
					}else{
						averageResult.put(reportName.get(index), 
								jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_REGION_AVERAGE_DATA,2,0.00,reportName.get(index),
										referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField),new Object[]{businessSegment}, new MiscRowMapper()));}
				}else if(FMSVariableConstants.PARTS_FLEET_PENETRATION.equalsIgnoreCase(reportName.get(index)) ||  
						FMSVariableConstants.REPAIRS_FLEET_PENETRATION.equalsIgnoreCase(reportName.get(index)) || 
						FMSVariableConstants.SVCS_FLEET_PENETRATION.equalsIgnoreCase(reportName.get(index))){
					averageResult.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_REGION_AVERAGE_DATA,0,0,reportName.get(index),
									referredTable,FMSVariableConstants.YEAR_GREATER_THAN_2014,marketIndustryField),new Object[]{businessSegment}, new MiscRowMapper()));
				}else {
					if(FMSVariableConstants.CONVERSION_INDEX.equalsIgnoreCase(reportName.get(index))){
						averageResult.put(reportName.get(index), 
								jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_REGION_AVERAGE_DATA,0,0,reportName.get(index),
										referredTable,FMSVariableConstants.PEN_METRICS_REG_AVG_CONVERSION_COND,marketIndustryField),new Object[]{businessSegment}, new MiscRowMapper()));
					}else{
						averageResult.put(reportName.get(index), 
								jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_REGION_AVERAGE_DATA,0,0,reportName.get(index),
										referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField),new Object[]{businessSegment}, new MiscRowMapper()));}
				}
			}

			for (int index = size-2; index < size; index++) {
				averageResult.put(reportName.get(index), 
						jdbc.query(String.format(FMSQueryConstants.PEN_METRICS_TECH_AVERAGE_DATA,0,0,
								reportName.get(index),referredTable,marketIndustryField),new Object[]{businessSegment}, new MiscRowMapper()));
			}
		} catch (Exception e) {
			log.error(FMSVariableConstants.EXCEPTION + e.getMessage());
		}

		metrcsData.setAverageBasedOnYear(report);
		metrcsData.setHistoryData(historyResult);
		metrcsData.setCurrentData(currentResult);
		metrcsData.setAverageData(averageResult);

		return metrcsData;
	}

	@Override
	public List<FMSIbasDataBean> getIbasDataWithFilterDao(Map<String, Object> data) {
		String type = Utils.getValidation(data.get(FMSVariableConstants.TYPE));
		/**String businessSegment = Utils.getValidation(data.get(FMSVariableConstants.BUSINESS_SEG));*/
		String MarketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		if(type.equalsIgnoreCase(FMSVariableConstants.DEFAULT)){

			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.YEAR, -5);
			int year = cal.get(Calendar.YEAR);
			return jdbc.query(FMSQueryConstants.RETRIEVE_IBAS_DATA,new Object[]{year,FMSVariableConstants.EMPTY_STRING,MarketIndustry}, new IbasDataMapper());

		}else{
			return jdbc.query(FMSQueryConstants.RETRIEVE_IBAS_DATA_ORIGINAL,new Object[]{FMSVariableConstants.EMPTY_STRING,MarketIndustry}, new IbasDataMapper());

		}
	}

	@Override
	public List<FMSInstalledBaseDataBean> getLatLongByRegionDao(String businessSegment,Map<String, Object> data) {
		return jdbc.query(FMSQueryConstants.RETRIEVE_LATLONG_BY_REG_DATA,new Object[]{FMSVariableConstants.EMPTY_STRING,Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", ""),Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER))}, new LatLongByRegMapper());
	}

	@Override
	public List<FMSInstalledBaseDataBean> getLatLongBySiteDao(Map<String, Object> data) {
		String region = Utils.getValidation(data.get(FMSVariableConstants.REGION));

		String siteName = null;
		if(!Utils.getValidation(data.get(FMSVariableConstants.SITENAME)).equals(FMSVariableConstants.EMPTY_STRING)){
			siteName = Utils.getValidation(data.get(FMSVariableConstants.SITENAME));
		} 
		return jdbc.query(FMSQueryConstants.RETRIEVE_LATLONG_BY_SITE_DATA,new Object[]{region, siteName,FMSVariableConstants.EMPTY_STRING,Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", ""),Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER))}, new LatLongBySiteMapper());
	}

	@Override
	public List<FMSInstalledBaseDataBean> getSiteInfoAndInstalledUnitsDao(String region, String siteName, String businessSegment, String marketIndustry,String accountManager) {
		return jdbc.query(FMSQueryConstants.RETRIEVE_SITE_INFO_INSTALLED_UNITS_DATA.replace("###", siteName),new Object[]{region,businessSegment,marketIndustry,accountManager}, new SiteInfoInstalledUnitMapper());
	}

	@Override
	public List<FMSInstalledBaseDataBean> getSerialInfoDao(String region, String siteName, String serialNumber, String businessSegment, String marketIndustry,String accountManager) {
		return jdbc.query(FMSQueryConstants.RETRIEVE_SERIAL_INFO_DATA,new Object[]{region,siteName,serialNumber,businessSegment,marketIndustry,accountManager}, new FMSSerialInformationMapper());
	}


	public FMSInstldBaseDropdownsVO getInstldBaseDropdownsDao(String businessSegment,Map<String, Object> data) {

		FMSInstldBaseDropdownsVO dropdownData = new FMSInstldBaseDropdownsVO();
		businessSegment = FMSVariableConstants.EMPTY_STRING;
		String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		List<FMSRegionDropdownBean>  regionDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_REGION_DROPDOWN_DATA, new Object[]{businessSegment,accountManager,marketIndustry}, new FMSRegionDropdownMapper());
		List<FMSSiteDropdownBean>  siteDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_SITE_DROPDOWN_DATA, new Object[]{businessSegment,accountManager,marketIndustry}, new FMSSiteDropdownMapper());
		List<FMSTechnologyDropdownBean>  technologyDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_TECHNOLOGY_DROPDOWN_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSTechnologyDropdownMapper());
		List<FMSStringDropdownBean>  marketDDBean = jdbc.query(FMSQueryConstants.RETRIEVE_MARKET_DD_DATA, new Object[]{businessSegment,accountManager,marketIndustry}, new FMSStringDropdownMapper(FMSVariableConstants.MARKET));
		List<FMSStringDropdownBean>  installBaseSiteCustAliasDDBean = jdbc.query(FMSQueryConstants.RETRIEVE_SITE_CUST_ALIAS, new Object[]{businessSegment,accountManager,marketIndustry}, new FMSStringDropdownMapper(FMSVariableConstants.SITE_CUST_ALIAS));
		List<FMSStringDropdownBean>  installBaseOEMLocDDBean = jdbc.query(FMSQueryConstants.RETRIEVE_OEM_LOCATION_DROPDOWN_DATA, new Object[]{businessSegment,accountManager,marketIndustry},  new FMSStringDropdownMapper(FMSVariableConstants.OEM_LOC));
		List<FMSSiteCustomerNameDropdownBean> installBaseSiteCustNameDDBean = jdbc.query(FMSQueryConstants.RETRIEVE_SITE_CUSTOMER_NAME, new Object[]{businessSegment,accountManager,marketIndustry}, new FMSSiteCustomerNameMapper());
		List<FMSServRelDescOngDropdownBean>  installBaseServRelationDDBean = jdbc.query(FMSQueryConstants.RETRIEVE_SERVREL_DESC_DROPDOWN_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSServRelDescDropdownMapper());

		dropdownData.setRegionDropdownBean(regionDropdownBean);
		dropdownData.setSiteDropdownBean(siteDropdownBean);
		dropdownData.setTechnologyDropdownBean(technologyDropdownBean);
		dropdownData.setMarketDDBean(marketDDBean);
		dropdownData.setInstallBaseSiteCustAliasDDBean(installBaseSiteCustAliasDDBean);
		dropdownData.setInstallBaseOEMLocDDBean(installBaseOEMLocDDBean);
		dropdownData.setInstallBaseSiteCustNameDDBean(installBaseSiteCustNameDDBean);
		dropdownData.setInstallBaseServRelationDDBean(installBaseServRelationDDBean);
		dropdownData.setCountryDropdownBean(jdbc.query(FMSQueryConstants.INSTALLED_BASE_COUNTRY_DRPDWN, new Object[]{businessSegment,accountManager,marketIndustry}, new MiscRowMapper()));
		dropdownData.setAccountManagerDropdownBean(jdbc.query(FMSQueryConstants.INSTALLED_BASE_ACC_MGR_DRPDWN, new Object[]{businessSegment,accountManager,marketIndustry},  new MiscRowMapper()));
		dropdownData.setGeDunsNameDropdownBean(jdbc.query(FMSQueryConstants.INSTALLED_BASE_GE_DUNS_DRPDWN, new Object[]{businessSegment,accountManager,marketIndustry}, new MiscRowMapper()));

		return dropdownData;
	}

	@Override
	public FMSIBSerachResultsVO getIBSearchResultsDao(FMSIBSearchResultsDataBean iBSearchResultData) {

		FMSIBSerachResultsVO serachResultsVO = new FMSIBSerachResultsVO();
		Object[] params = new Object[14];
		params[0] = Utils.getValidation(iBSearchResultData.getSiteName()).replaceAll("[()]", "1");;
		params[1] = Utils.getValidation(iBSearchResultData.getInstallBaseSiteCustName()).replaceAll("[()]", "1");
		params[2] = Utils.getValidation(iBSearchResultData.getRegion());
		params[3] = Utils.getValidation(iBSearchResultData.getMarket());
		params[4] = Utils.getValidation(iBSearchResultData.getSerialNum());
		params[5] = Utils.getValidation(iBSearchResultData.getTechnology());
		params[6] = Utils.getValidation(iBSearchResultData.getInstallBaseSiteCustAliasDDBean()).replaceAll("[()]", "1");
		params[7] = Utils.getValidation(iBSearchResultData.getInstallBaseOEMLoc()).replaceAll("[()]", "1");
		params[8] = Utils.getValidation(iBSearchResultData.getInstallBaseSrvRelDescOG());
		params[9] = Utils.getValidation(iBSearchResultData.getCountry());
		params[10] = Utils.getValidation(iBSearchResultData.getAccountManager());
		params[11] = Utils.getValidation(iBSearchResultData.getGeDuns()).replaceAll("[()]", "1");
		/**params[12] = Utils.getValidation(iBSearchResultData.getBusinessSegment());*/
		params[12] = FMSVariableConstants.EMPTY_STRING;
		params[13] = Utils.getValidation(iBSearchResultData.getMarketIndustryIB()).replace("&", "");

		List<FMSIBRegionDataBean> regionData = jdbc.query(FMSQueryConstants.RETRIEVE_IB_SEARCH_RESULTS_REGION_DATA,params,  new RegionLatLongMapper());
		List<FMSIBSiteNameDataBean> siteNameData = jdbc.query(FMSQueryConstants.RETRIEVE_IB_SEARCH_RESULTS_SITE_DATA,params, new SiteNameLatLongMapper());
		List<FMSIBSerialNumDataBean> installBaseNoOfUnitsData = jdbc.query(FMSQueryConstants.RETRIEVE_IB_SEARCH_RESULTS_SERIAL_NUM_DATA,params, new SerialNumLatLongMapper());

		serachResultsVO.setRegionDataBean(regionData);
		serachResultsVO.setSiteNameDataBean(siteNameData);
		serachResultsVO.setInstallBaseNoOfUnitsData(installBaseNoOfUnitsData);

		return serachResultsVO;
	}

	@Override
	public FMSIBMetricsDetailsVO getIBMetricsDao(String businessSegment, Map<String,Object> data) {

		FMSIBMetricsDetailsVO resultsVO = new FMSIBMetricsDetailsVO();
		businessSegment = FMSVariableConstants.EMPTY_STRING;
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));
		List<FMSIBMetricsTechDataBean> technologyData = jdbc.query(FMSQueryConstants.RETRIEVE_IB_TECH_METRICS_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSIBTechMetricsMapper());
		List<FMSIBMetricsCustDataBean> custNameData = jdbc.query(FMSQueryConstants.RETRIEVE_IB_CUST_METRICS_DATA,new Object[]{businessSegment,accountManager,marketIndustry,businessSegment,accountManager,marketIndustry}, new FMSIBCustMetricsMapper());

		resultsVO.setTechnologyDataBean(technologyData);
		resultsVO.setCustNameDataBean(custNameData);

		return resultsVO;
	}

	/** IB / IBO level drop-downs of IBO metrics */

	public FMSIBMetricsDropdownsVO getIBMetricsDropdownsDao(String businessSegment,Map<String, Object> data) {

		FMSIBMetricsDropdownsVO dropdownData = new FMSIBMetricsDropdownsVO();
		businessSegment = FMSVariableConstants.EMPTY_STRING;
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));
		List<FMSRegionDropdownBean>  regionDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_REGION_DROPDOWN_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSRegionDropdownMapper());
		List<FMSTechnologyDropdownBean>  technologyDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_TECHNOLOGY_DROPDOWN_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSTechnologyDropdownMapper());
		List<FMSCustomerDropdownBean>  customerDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_CUSTOMER_DROPDOWN_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSCustomerDropdownMapper());
		List<FMSUnitStatusDesDropdownBean>  unitStatusDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_UNIT_STATUS_DROPDOWN_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSUnitStatusDropdownMapper());
		List<FMSSiteCustCountryDropdownBean>  siteCustCountryDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_SITE_CUST_COUNTRY_DROPDOWN_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSSiteCustCountryDropdownMapper());
		List<FMSServRelDescOngDropdownBean>  servRelationDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_SERVREL_DESC_DROPDOWN_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSServRelDescDropdownMapper());
		List<FMSMarketSegmentDescDropdownBean>  mrktSegmentDescDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_MARKET_SEGMENT_DROPDOWN_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSMarketSegmentDropdownMapper());
		List<FMSStringDropdownBean> oemLocationDDBean = jdbc.query(FMSQueryConstants.RETRIEVE_OEM_LOCATION_DROPDOWN_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSStringDropdownMapper(FMSVariableConstants.OEM_LOC));
		List<FMSStringDropdownBean>  siteCustDunsNameDDBean = jdbc.query(FMSQueryConstants.RETRIEVE_SITE_CUST_DUNS_NAME_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSStringDropdownMapper(FMSVariableConstants.SITE_CUST_DUNS_NAME));
		List<FMSSiteCustomerNameDropdownBean> siteCustomerNameDropdownBean=jdbc.query(FMSQueryConstants.RETRIEVE_SITE_CUSTOMER_NAME,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSSiteCustomerNameMapper());
		List<FMSSiteNameAliasDropdownBean> siteNameAliasDropdownBean=jdbc.query(FMSQueryConstants.RETRIEVE_SITE_NAME_ALIAS,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSSiteNameAliasMapper());
		List<FMSEquipmentCodeDropdownBean> equipmentCodeDropdown = jdbc.query(FMSQueryConstants.RETRIEVE_EQUIPCODE_DROPDOWN_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSEquipmentCodeMapper());
		List<FMSIBOTypeDropdownBean> iboTypeDropdown = jdbc.query(FMSQueryConstants.RETRIEVE_IBO_TYPE_DROPDOWN_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSIBOTypeMapper());

		dropdownData.setRegionDropdownBean(regionDropdownBean);
		dropdownData.setTechDropdownBean(technologyDropdownBean);
		dropdownData.setCustDropdownBean(customerDropdownBean);
		dropdownData.setUnitStatusDropdownBean(unitStatusDropdownBean);
		dropdownData.setSiteCustCountryDropdownBean(siteCustCountryDropdownBean);
		dropdownData.setServRelationDropdownBean(servRelationDropdownBean);
		dropdownData.setMarketSegmentDropdownBean(mrktSegmentDescDropdownBean);
		dropdownData.setOemLocationDDBean(oemLocationDDBean);
		dropdownData.setSiteCustDunsNameDDBean(siteCustDunsNameDDBean);
		dropdownData.setSiteCustomerNameDropdownBean(siteCustomerNameDropdownBean);
		dropdownData.setSiteNameAliasDropdownBean(siteNameAliasDropdownBean);
		dropdownData.setEquipmentCodeDropdown(equipmentCodeDropdown);
		dropdownData.setIboTypeDropdown(iboTypeDropdown);

		return dropdownData;
	}

	/** IB level of IBO metrics (Region level) */

	@Override
	public FMSIBMetricsDetailsVO getIBMetricsFilterDao(FMSIBFilterDataBean filterData) {

		FMSIBMetricsDetailsVO resultsVO = new FMSIBMetricsDetailsVO();	
		List<FMSIBMetricsTechDataBean> technologyData = jdbc.query(FMSQueryConstants.RETRIEVE_IB_TECH_METRICS_FILTER_DATA,new Object[]{Utils.getValidation(filterData.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getTechnology()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getUnitStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustCountry()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getServRelDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketSegment()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOemLoc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustDunsName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteNameAlias()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getEquipmentCodeFilter()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(filterData.getBusinessSegmentFilter()).replaceAll("[()]", "1")*/,Utils.getValidation(filterData.getAccountManagerFilter()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketIndustryIB()).replace("&", ""),Utils.getValidation(filterData.getIboType())}, new FMSIBTechMetricsMapper());
		List<FMSIBMetricsCustDataBean> custNameData = jdbc.query(FMSQueryConstants.RETRIEVE_IB_CUST_METRICS_FILTER_DATA,new Object[]{Utils.getValidation(filterData.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getTechnology()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getUnitStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustCountry()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getServRelDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketSegment()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOemLoc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustDunsName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteNameAlias()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getEquipmentCodeFilter()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(filterData.getBusinessSegmentFilter()).replaceAll("[()]", "1")*/,Utils.getValidation(filterData.getAccountManagerFilter()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketIndustryIB()).replace("&", ""),Utils.getValidation(filterData.getIboType()),Utils.getValidation(filterData.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getTechnology()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getUnitStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustCountry()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getServRelDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketSegment()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOemLoc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustDunsName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteNameAlias()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getEquipmentCodeFilter()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(filterData.getBusinessSegmentFilter()).replaceAll("[()]", "1")*/,Utils.getValidation(filterData.getAccountManagerFilter()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketIndustryIB()).replace("&", ""),Utils.getValidation(filterData.getIboType())}, new FMSIBCustMetricsMapper());
		resultsVO.setTechnologyDataBean(technologyData);
		resultsVO.setCustNameDataBean(custNameData);

		return resultsVO;
	}

	/** IB level of IBO metrics (country level) */

	@Override
	public FMSIBMetricsDetailsVO getIBFilterDataCountryDao(FMSIBFilterDataBean filterData) {

		FMSIBMetricsDetailsVO resultsVO = new FMSIBMetricsDetailsVO();
		List<FMSIBMetricsTechDataBean>  technologyData = jdbc.query(FMSQueryConstants.RETRIEVE_IB_TECH_FILTER_COUNTRY_DATA,new Object[]{Utils.getValidation(filterData.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getTechnology()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getUnitStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustCountry()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getServRelDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketSegment()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOemLoc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustDunsName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteNameAlias()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getEquipmentCodeFilter()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(filterData.getBusinessSegmentFilter()).replaceAll("[()]", "1")*/,Utils.getValidation(filterData.getAccountManagerFilter()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketIndustryIB()).replace("&", ""),Utils.getValidation(filterData.getIboType())}, new FMSIBTechMetricsCountryMapper());
		List<FMSIBMetricsCustDataBean> custNameData = jdbc.query(FMSQueryConstants.RETRIEVE_IB_CUST_FILTER_COUNTRY_DATA,new Object[]{Utils.getValidation(filterData.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getTechnology()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getUnitStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustCountry()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getServRelDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketSegment()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOemLoc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustDunsName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteNameAlias()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getEquipmentCodeFilter()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(filterData.getBusinessSegmentFilter()).replaceAll("[()]", "1")*/,Utils.getValidation(filterData.getAccountManagerFilter()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketIndustryIB()).replace("&", ""),Utils.getValidation(filterData.getIboType()),Utils.getValidation(filterData.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getTechnology()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getUnitStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustCountry()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getServRelDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketSegment()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOemLoc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustDunsName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteNameAlias()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getEquipmentCodeFilter()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(filterData.getBusinessSegmentFilter()).replaceAll("[()]", "1")*/,Utils.getValidation(filterData.getAccountManagerFilter()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketIndustryIB()).replace("&", ""),Utils.getValidation(filterData.getIboType())}, new FMSIBCustMetricsCountryMapper());
		resultsVO.setTechnologyDataBean(technologyData);
		resultsVO.setCustNameDataBean(custNameData);

		return resultsVO;
	}

	/** IBO level of IBO metrics (Region level) */

	@Override
	public FMSIBOMetricsDetailsVO getIBOMetricsFilterDao(FMSIBFilterDataBean filterData) {
		FMSIBOMetricsDetailsVO resultsVO = new FMSIBOMetricsDetailsVO();
		List<FMSIBOMetricsTechDataBean> technologyData = jdbc.query(FMSQueryConstants.RETRIEVE_IBOSTECH_METRICS_FILTER_DATA,new Object[]{Utils.getValidation(filterData.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getTechnology()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getUnitStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustCountry()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getServRelDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketSegment()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOemLoc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustDunsName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteNameAlias()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getEquipmentCodeFilter()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(filterData.getBusinessSegmentFilter()).replaceAll("[()]", "1")*/,Utils.getValidation(filterData.getAccountManagerFilter()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketIndustryIB()).replace("&", ""),Utils.getValidation(filterData.getIboType())}, new FMSIBOTechMetricsMapper());
		List<FMSIBOMetricsCustDataBean> custNameData = jdbc.query(FMSQueryConstants.RETRIEVE_IBOSCUST_METRICS_FILTER_DATA,new Object[]{Utils.getValidation(filterData.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getTechnology()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getUnitStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustCountry()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getServRelDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketSegment()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOemLoc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustDunsName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteNameAlias()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getEquipmentCodeFilter()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(filterData.getBusinessSegmentFilter()).replaceAll("[()]", "1")*/,Utils.getValidation(filterData.getAccountManagerFilter()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketIndustryIB()).replace("&", ""),Utils.getValidation(filterData.getIboType()),Utils.getValidation(filterData.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getTechnology()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getUnitStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustCountry()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getServRelDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketSegment()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOemLoc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustDunsName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteNameAlias()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getEquipmentCodeFilter()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(filterData.getBusinessSegmentFilter()).replaceAll("[()]", "1")*/,Utils.getValidation(filterData.getAccountManagerFilter()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketIndustryIB()).replace("&", ""),Utils.getValidation(filterData.getIboType())}, new FMSIBOCustMetricsMapper());
		resultsVO.setiBTechnologyDataBean(technologyData);
		resultsVO.setiBCustNameDataBean(custNameData);

		return resultsVO;
	}

	/** IBO level of IBO metrics (country level) */

	@Override
	public FMSIBOMetricsDetailsVO getIBOFilterDataCountry(FMSIBFilterDataBean filterData) {
		FMSIBOMetricsDetailsVO resultsVO = new FMSIBOMetricsDetailsVO();
		List<FMSIBOMetricsTechDataBean>  technologyData = jdbc.query(FMSQueryConstants.RETRIEVE_IBOSTECH_FILTER_COUNTRY_DATA,new Object[]{Utils.getValidation(filterData.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getTechnology()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getUnitStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustCountry()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getServRelDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketSegment()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOemLoc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustDunsName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteNameAlias()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getEquipmentCodeFilter()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(filterData.getBusinessSegmentFilter()).replaceAll("[()]", "1")*/,Utils.getValidation(filterData.getAccountManagerFilter()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketIndustryIB()).replace("&", ""),Utils.getValidation(filterData.getIboType())}, new FMSIBOTechMetricsCountryMapper());
		List<FMSIBOMetricsCustDataBean> custNameData = jdbc.query(FMSQueryConstants.RETRIEVE_IBOCUST_FILTER_COUNTRY_DATA,new Object[]{Utils.getValidation(filterData.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getTechnology()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getUnitStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustCountry()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getServRelDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketSegment()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOemLoc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustDunsName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteNameAlias()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getEquipmentCodeFilter()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(filterData.getBusinessSegmentFilter()).replaceAll("[()]", "1")*/,Utils.getValidation(filterData.getAccountManagerFilter()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketIndustryIB()).replace("&", ""),Utils.getValidation(filterData.getIboType()),Utils.getValidation(filterData.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getTechnology()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getUnitStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustCountry()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getServRelDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketSegment()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOemLoc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustDunsName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteCustName()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getSiteNameAlias()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getEquipmentCodeFilter()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(filterData.getBusinessSegmentFilter()).replaceAll("[()]", "1")*/,Utils.getValidation(filterData.getAccountManagerFilter()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getMarketIndustryIB()).replace("&", ""),Utils.getValidation(filterData.getIboType())}, new FMSIBOCustMetricsCountryMapper());
		resultsVO.setiBTechnologyDataBean(technologyData);
		resultsVO.setiBCustNameDataBean(custNameData);
		return resultsVO;
	}	

	@Override
	public FMSOrdersMetricsDetailsVO getOrdersMetricsDao(String businessSegment, Map<String, Object> data) {

		FMSOrdersMetricsDetailsVO resultsVO = new FMSOrdersMetricsDetailsVO();
		businessSegment = FMSVariableConstants.EMPTY_STRING;
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));
		List<FMSOrdersMetricsTechDataBean> technologyData = jdbc.query(FMSQueryConstants.RETRIEVE_ORDERS_TECH_METRICS_DATA,new Object[]{businessSegment,marketIndustry,accountManager}, new FMSOrdersTechMetricsMapper());
		List<FMSOrdersMetricsCustDataBean> custNameData = jdbc.query(FMSQueryConstants.RETRIEVE_ORDERS_CUST_METRICS_DATA,new Object[]{businessSegment,marketIndustry,accountManager,businessSegment,marketIndustry,accountManager}, new FMSOrdersCustMetricsMapper());

		resultsVO.setTechnologyDataBean(technologyData);
		resultsVO.setCustNameDataBean(custNameData);

		return resultsVO;
	}

	@Override
	public FMSOrdersMetricsDropdownsVO getOrdersMetricsDropdownsDao(String businessSegment,Map<String, Object> data) {

		FMSOrdersMetricsDropdownsVO dropdownData = new FMSOrdersMetricsDropdownsVO();
		businessSegment = FMSVariableConstants.EMPTY_STRING;
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));
		List<FMSCountryNameDropdownBean> countryNameDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_COUNTRY_NAME_DROPDOWN_DATA,new Object[]{businessSegment,marketIndustry,accountManager}, new FMSCountryNameDropdownMapper());
		List<FMSServiceTypeDropdownBean> serviceTypeDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_SERVICE_TYPE_DROPDOWN_DATA,new Object[]{businessSegment,marketIndustry,accountManager}, new FMSServiceTypeDropdownMapper());
		List<FMSEndUserNameDropdownBean> endUserNameDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_ENDUSER_NAME_DROPDOWN_DATA,new Object[]{businessSegment,marketIndustry,accountManager}, new FMSEndUserNameDropdownMapper());
		List<FMSOrderRegionDropdownBean>  regionDropdownBean = jdbc.query(FMSQueryConstants.RETRIEVE_ORDER_REGION_DROPDOWN_DATA,new Object[]{businessSegment,marketIndustry,accountManager}, new FMSOrderRegionDropdownMapper());
		List<FMSSiteCustomerNameDropdownBean> siteCustomerNameDropdownBean = jdbc.query(FMSQueryConstants.ORDER_METRICS_GE_DUNS_NAME,new Object[]{businessSegment,marketIndustry,accountManager}, new FMSOrderMetricsCustomerNameMapper());

		List<FMSStringDropdownBean> smSegmentMappingDDBean = jdbc.query(FMSQueryConstants.RETRIEVE_SM_SEGMENT_MAPPING_DD_DATA,new Object[]{businessSegment,marketIndustry,accountManager}, new FMSStringDropdownMapper(FMSVariableConstants.SM_SEGMENT_MAPPING));
		List<FMSStringDropdownBean> pmProductMappingDDBean = jdbc.query(FMSQueryConstants.RETRIEVE_PM_PRODUCT_MAPPING_DD_DATA,new Object[]{businessSegment,marketIndustry,accountManager}, new FMSStringDropdownMapper(FMSVariableConstants.PM_PRODUCT_MAPPING));
		List<FMSStringDropdownBean> meTier4DDBean = jdbc.query(FMSQueryConstants.RETRIEVE_ME_TIER4_DD_DATA,new Object[]{businessSegment,marketIndustry,accountManager}, new FMSStringDropdownMapper(FMSVariableConstants.ME_TIER4));
		List<FMSStringDropdownBean> meDMTier3DDBean = jdbc.query(FMSQueryConstants.RETRIEVE_ME_DM_TIER3_DD_DATA,new Object[]{businessSegment,marketIndustry,accountManager}, new FMSStringDropdownMapper(FMSVariableConstants.ME_DM_TIER3));

		List<Map<String, Object>> stateDropdownData = jdbc.query(FMSQueryConstants.ORDERS_STATE_DROPDOWN_DATA,new Object[]{businessSegment,marketIndustry,accountManager},new MiscRowMapper());

		dropdownData.setCountryNameDropdownData(countryNameDropdownBean);
		dropdownData.setServiceTypeDropdownData(serviceTypeDropdownBean);
		dropdownData.setEndUserNameDropdownData(endUserNameDropdownBean);
		dropdownData.setRegionDropdownBean(regionDropdownBean);
		dropdownData.setGeCustomerDunsName(siteCustomerNameDropdownBean);
		dropdownData.setSmSegmentMappingDDBean(smSegmentMappingDDBean);
		dropdownData.setPmProductMappingDDBean(pmProductMappingDDBean);
		dropdownData.setMeTier4DDBean(meTier4DDBean);
		dropdownData.setMeDMTier3DDBean(meDMTier3DDBean);
		dropdownData.setStateDropdownData(stateDropdownData);

		return dropdownData;
	}

	@Override
	public FMSOrdersMetricsDetailsVO getOrdersMetricsFilterDao(FMSOrdersMetricsDataBean ordersMetricsDataBean) {

		FMSOrdersMetricsDetailsVO resultsVO = new FMSOrdersMetricsDetailsVO();
		List<FMSOrdersMetricsTechDataBean> technologyData = jdbc.query(FMSQueryConstants.RETRIEVE_ORDERSTECH_METRICS_FILTER_DATA,new Object[]{Utils.getValidation(ordersMetricsDataBean.getSmSegmentMapping()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getPmProductMapping()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getMeTier4()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getCountryName()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getMeDMTier3()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getServiceType()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getEndUserName()).replaceAll("[()]", "1"), Utils.getValidation(ordersMetricsDataBean.getRegion()).replaceAll("[()]", "1"), Utils.getValidation(ordersMetricsDataBean.getGeDunsName()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getOrdersState()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(ordersMetricsDataBean.getOrdersBusinessSegment()).replaceAll("[()]", "1")*/,Utils.getValidation(ordersMetricsDataBean.getMarketIndustry()).replace("&", ""),Utils.getValidation(ordersMetricsDataBean.getAccountManager())}, new FMSOrdersTechMetricsMapper());
		List<FMSOrdersMetricsCustDataBean> custNameData = jdbc.query(FMSQueryConstants.RETRIEVE_ORDERSCUST_METRICS_FILTER_DATA,new Object[]{Utils.getValidation(ordersMetricsDataBean.getSmSegmentMapping()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getPmProductMapping()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getMeTier4()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getCountryName()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getMeDMTier3()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getServiceType()).replaceAll("[()]", "1"), Utils.getValidation(ordersMetricsDataBean.getEndUserName()).replaceAll("[()]", "1"), Utils.getValidation(ordersMetricsDataBean.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getGeDunsName()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getOrdersState()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(ordersMetricsDataBean.getOrdersBusinessSegment()).replaceAll("[()]", "1")*/,Utils.getValidation(ordersMetricsDataBean.getMarketIndustry()).replace("&", ""),Utils.getValidation(ordersMetricsDataBean.getAccountManager()),Utils.getValidation(ordersMetricsDataBean.getSmSegmentMapping()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getPmProductMapping()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getMeTier4()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getCountryName()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getMeDMTier3()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getServiceType()).replaceAll("[()]", "1"), Utils.getValidation(ordersMetricsDataBean.getEndUserName()).replaceAll("[()]", "1"), Utils.getValidation(ordersMetricsDataBean.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getGeDunsName()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getOrdersState()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(ordersMetricsDataBean.getOrdersBusinessSegment()).replaceAll("[()]", "1")*/,Utils.getValidation(ordersMetricsDataBean.getMarketIndustry()).replace("&", ""),Utils.getValidation(ordersMetricsDataBean.getAccountManager())}, new FMSOrdersCustMetricsMapper());
		resultsVO.setTechnologyDataBean(technologyData);
		resultsVO.setCustNameDataBean(custNameData);

		return resultsVO;
	}

	@Override
	public FMSOrdersMetricsDetailsVO getOrdersFilterDataCountryDao(FMSOrdersMetricsDataBean ordersMetricsDataBean) {

		FMSOrdersMetricsDetailsVO resultsVO = new FMSOrdersMetricsDetailsVO();

		List<FMSOrdersMetricsTechDataBean> technologyData = jdbc.query(FMSQueryConstants.RETRIEVE_ORDERSTECH_FILTER_COUNTRY_DATA,new Object[]{Utils.getValidation(ordersMetricsDataBean.getSmSegmentMapping()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getPmProductMapping()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getMeTier4()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getCountryName()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getMeDMTier3()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getServiceType()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getEndUserName()).replaceAll("[()]", "1"), Utils.getValidation(ordersMetricsDataBean.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getGeDunsName()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getOrdersState()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(ordersMetricsDataBean.getOrdersBusinessSegment()).replaceAll("[()]", "1")*/,Utils.getValidation(ordersMetricsDataBean.getMarketIndustry()).replace("&", ""),Utils.getValidation(ordersMetricsDataBean.getAccountManager())}, new FMSOrdersTechMetricsCountryMapper());
		List<FMSOrdersMetricsCustDataBean> custNameData = jdbc.query(FMSQueryConstants.RETRIEVE_ORDERSCUST_FILTER_COUNTRY_DATA,new Object[]{Utils.getValidation(ordersMetricsDataBean.getSmSegmentMapping()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getPmProductMapping()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getMeTier4()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getCountryName()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getMeDMTier3()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getServiceType()).replaceAll("[()]", "1"), Utils.getValidation(ordersMetricsDataBean.getEndUserName()).replaceAll("[()]", "1"), Utils.getValidation(ordersMetricsDataBean.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getGeDunsName()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getOrdersState()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(ordersMetricsDataBean.getOrdersBusinessSegment()).replaceAll("[()]", "1")*/,Utils.getValidation(ordersMetricsDataBean.getMarketIndustry()).replace("&", ""),Utils.getValidation(ordersMetricsDataBean.getAccountManager()),Utils.getValidation(ordersMetricsDataBean.getSmSegmentMapping()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getPmProductMapping()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getMeTier4()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getCountryName()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getMeDMTier3()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getServiceType()).replaceAll("[()]", "1"), Utils.getValidation(ordersMetricsDataBean.getEndUserName()).replaceAll("[()]", "1"), Utils.getValidation(ordersMetricsDataBean.getRegion()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getGeDunsName()).replaceAll("[()]", "1"),Utils.getValidation(ordersMetricsDataBean.getOrdersState()).replaceAll("[()]", "1"),FMSVariableConstants.EMPTY_STRING/**Utils.getValidation(ordersMetricsDataBean.getOrdersBusinessSegment()).replaceAll("[()]", "1")*/,Utils.getValidation(ordersMetricsDataBean.getMarketIndustry()).replace("&", ""),Utils.getValidation(ordersMetricsDataBean.getAccountManager())}, new FMSOrdersCustMetricsCountryMapper());
		resultsVO.setTechnologyDataBean(technologyData);
		resultsVO.setCustNameDataBean(custNameData);

		return resultsVO;
	}

	@Override
	public List<FMSCountryNameDropdownBean> getCountryDao(Map<String, Object> data) {
		Object[] params = new Object[4];
		params[0] = Utils.getValidation(data.get(FMSVariableConstants.REGION_NAME));
		/**params[1] =  Utils.getValidation(data.get(FMSVariableConstants.BUSINESS_SEG));*/
		params[1] = FMSVariableConstants.EMPTY_STRING;
		params[2] = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		params[3] =  Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));
		return jdbc.query(FMSQueryConstants.RETRIEVE_COUNTRY_NAME_DATA,params, new FMSCountryNameDropdownMapper());
	}

	@Override
	public List<FMSCountryNameDropdownBean> getOrderCountryDao(String regionName) {
		/**businessSegment = FMSVariableConstants.EMPTY_STRING;
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));*/
		return jdbc.query(FMSQueryConstants.RETRIEVE_ORDER_COUNTRY_NAME,new Object[]{regionName}, new FMSCountryNameDropdownMapper());
	}

	@Override
	public List<FMSCountryNameDropdownBean> getDMCountry(Map<String, Object> data) {
		List<FMSCountryNameDropdownBean> fmsCountryNameDropdownBean =null;
		String type = Utils.getValidation(data.get(FMSVariableConstants.TYPE));
		Object[] params = new Object[4];
		params[0] = Utils.getValidation(data.get(FMSVariableConstants.REGION_NAME));
		/**params[1] =  Utils.getValidation(data.get(FMSVariableConstants.BUSINESS_SEG));*/
		params[1] = FMSVariableConstants.EMPTY_STRING;
		params[2] = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		params[3] =  Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));
		if(FMSVariableConstants.DM.equalsIgnoreCase(type))
			fmsCountryNameDropdownBean=jdbc.query(FMSQueryConstants.RETRIEVE_DM_COUNTRY,params, new FMSCountryNameDropdownMapper());
		else if("outage".equalsIgnoreCase(type))
			fmsCountryNameDropdownBean=jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_COUNTRY,new Object[]{params[0].toString(),params[3].toString()}, new FMSCountryNameDropdownMapper());
		return fmsCountryNameDropdownBean;
	}

	@Override
	public FMSIBOMetricsDetailsVO getIBOMetricsDao(String businessSegment, Map<String, Object> data) {

		FMSIBOMetricsDetailsVO resultsVO = new FMSIBOMetricsDetailsVO();
		businessSegment = FMSVariableConstants.EMPTY_STRING;
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));
		List<FMSIBOMetricsTechDataBean> technologyData = jdbc.query(FMSQueryConstants.RETRIEVE_IBO_TECH_METRICS_DATA,new Object[]{businessSegment,accountManager,marketIndustry}, new FMSIBOTechMetricsMapper());
		List<FMSIBOMetricsCustDataBean> custNameData = jdbc.query(FMSQueryConstants.RETRIEVE_IBO_CUST_METRICS_DATA,new Object[]{businessSegment,accountManager,marketIndustry,businessSegment,accountManager,marketIndustry}, new FMSIBOCustMetricsMapper());

		resultsVO.setiBTechnologyDataBean(technologyData);
		resultsVO.setiBCustNameDataBean(custNameData);

		return resultsVO;
	}	

	@SuppressWarnings("unchecked")
	@Override
	public void getOracleData(){
		jdbc.execute(FMSQueryConstants.DELETE_EXISTING_ORACLE_DATA);
		java.util.Date date = new java.util.Date();
		log.info("Records deleted:" + date);
		log.info("Service Start Time:" + date);
		jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.IN_PROGRESS,"Service Start Time:" + date,"getOracleData~Service Start"});
		int ipmUniqueId=1; 
		List<String> monthList = Utils.getSpotFireMonthst();
		List<String> subRegions = new ArrayList<>(); 
		try{
			subRegions = akanaHandler.execute("getSpotFireSubRegions", HttpMethod.GET, null);
			/**
			 * subRegions = akanaHandler.execute("getDataLakeSpotFireSubRegions", HttpMethod.GET, null);
			 */
		} catch(Exception e) {
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleData~akanaHandler~getDataLakeSpotFireSubRegions"});
			log.info("Erors in SubRegions" + e);
		}	
		for(int index=0;index<subRegions.size();index++){
			String subRegion = Utils.getValidation(subRegions.get(index));
			for(int i=0;i<monthList.size();i++){
				String month = monthList.get(i);
				Map<String,String> postData = new HashMap<>();
				postData.put("subRegion", subRegion);
				postData.put("month", month);
				log.info("Featching data of SubRegion : " + subRegion + "  Month: " +month);
				List<Map<String, Object>> rows = null;
				try {
					rows = akanaHandler.execute("getSpotFireData", HttpMethod.POST, postData);
					/**
					 * rows = akanaHandler.execute("getDataLakeSpotFireData", HttpMethod.POST, postData);
					 */
				} catch (Exception e) {
					jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleData~akanaHandler~getDataLakeSpotFireData"+"Featching data of SubRegion : " + subRegion + "  Month: " +month});
					log.info("Erors in Post and get Data"+ e);
				}
				for(Map row:rows)
				{
					FMSSpotFireDataBean spotFireDataBean = new FMSSpotFireDataBean();

					spotFireDataBean.setActualCost((String)row.get("actualCost"));
					spotFireDataBean.setActualShipmentDate((String)row.get("actualShipmentDate"));
					spotFireDataBean.setActualShipmentQuarter((String)row.get("actualShipmentQuarter"));
					spotFireDataBean.setAgreementIddelProgeto((String)row.get("agreementIddelProgeto"));
					spotFireDataBean.setAgreementName((String)row.get("agreementName"));
					spotFireDataBean.setAmountReadyHP((String)row.get("amountReadyHP"));

					spotFireDataBean.setAmountReadySP((String)row.get("amountReadySP"));
					spotFireDataBean.setAmountShipped((String)row.get("amountShipped"));
					spotFireDataBean.setAmtInShipping((String)row.get("amtInShipping"));
					spotFireDataBean.setAmtNotReady((String)row.get("amtNotReady"));
					spotFireDataBean.setAreIncGlobops((String)row.get("areIncGlobops"));
					spotFireDataBean.setAwb((String)row.get("awb"));
					spotFireDataBean.setBaseline((String)row.get("baseline"));
					spotFireDataBean.setBasket((String)row.get("basket"));
					spotFireDataBean.setBookingMonth((String)row.get("bookingMonth"));
					spotFireDataBean.setBookingYear((String)row.get("bookingYear"));

					spotFireDataBean.setBoxNumber((String)row.get("boxNumber"));
					spotFireDataBean.setoUName((String)row.get("oUName"));
					spotFireDataBean.setBookingDate((String)row.get("bookingDate"));
					spotFireDataBean.setBoxClosureDate((String)row.get("boxClosureDate"));
					spotFireDataBean.setBucCode((String)row.get("bucCode"));
					spotFireDataBean.setBusinessSegment((String)row.get(FMSVariableConstants.BUSINESS_SEG));
					spotFireDataBean.setBuyerCustCode((String)row.get("buyerCustCode"));
					spotFireDataBean.setBuyerCustCountryDesc((String)row.get("buyerCustCountryDesc"));
					spotFireDataBean.setBuyerCustName((String)row.get("buyerCustName"));
					spotFireDataBean.setCmGlobalContract((String)row.get("cmGlobalContract"));

					spotFireDataBean.setCmPerSold((String)row.get("cmPerSold"));
					spotFireDataBean.setCmPercent((String)row.get("cmPercent"));
					spotFireDataBean.setContrPerShippAllwd((String)row.get("contrPerShippAllwd"));
					spotFireDataBean.setContractNumber((String)row.get("contractNumber"));
					spotFireDataBean.setCostingProject((String)row.get(FMSVariableConstants.COSTINGPROJECT));
					spotFireDataBean.setCsAgreementType((String)row.get("csAgreementType"));
					spotFireDataBean.setCsRegion((String)row.get("csRegion"));
					spotFireDataBean.setCsSubRegion((String)row.get("csSubRegion"));
					spotFireDataBean.setCustomerPOAmount((String)row.get("customerPOAmount"));
					spotFireDataBean.setCustomerPONumber((String)row.get("customerPONumber"));

					spotFireDataBean.setCwdQuarter((String)row.get("cwdQuarter"));
					spotFireDataBean.setCwdWeek((String)row.get("cwdWeek"));
					spotFireDataBean.setCwdYear((String)row.get("cwdYear"));
					spotFireDataBean.setDdtDate((String)row.get("ddtDate"));
					spotFireDataBean.setDdtNumber((String)row.get("ddtNumber"));
					spotFireDataBean.setDeliverableNum((String)row.get("deliverableNum"));
					spotFireDataBean.setDeliveryTerm((String)row.get("deliveryTerm"));
					spotFireDataBean.setDeliveryStatus((String)row.get("deliveryStatus"));
					spotFireDataBean.setDescreZoneClasse((String)row.get("descreZoneClasse"));
					spotFireDataBean.setDiscoutExtraPrice((String)row.get("discoutExtraPrice"));

					spotFireDataBean.setDolDiscountPrice((String)row.get("dolDiscountPrice"));
					spotFireDataBean.setDollarPrice((String)row.get("dollarPrice"));
					spotFireDataBean.setDpsRegion((String)row.get("dpsRegion"));
					spotFireDataBean.setDpsSubRegion((String)row.get("dpsSubRegion"));
					spotFireDataBean.setDwLoadDate((String)row.get("dwLoadDate"));
					spotFireDataBean.setDwUpdateDate((String)row.get("dwUpdateDate"));
					spotFireDataBean.setEarlyDeliveryAllowed((String)row.get("earlyDeliveryAllowed"));
					spotFireDataBean.setEndUserCountryDesc((String)row.get("endUserCountryDesc"));
					spotFireDataBean.setEndUserCountryCode((String)row.get("endUserCountryCode"));
					spotFireDataBean.setEndUserCustName((String)row.get("endUserCustName"));

					spotFireDataBean.setFxRate((String)row.get("fxRate"));
					spotFireDataBean.setG3Promised((String)row.get("g3Promised"));
					spotFireDataBean.setGratisSI((String)row.get("gratisSI"));
					spotFireDataBean.setGrossWeight((String)row.get("grossWeight"));
					spotFireDataBean.setHeight((String)row.get("height"));
					spotFireDataBean.setiC((String)row.get("iC"));
					spotFireDataBean.setIbasEventId((String)row.get("ibasEventId"));
					spotFireDataBean.setInvoiceAmount((String)row.get("invoiceAmount"));
					spotFireDataBean.setInvoiceDate((String)row.get("invoiceDate"));
					spotFireDataBean.setInvoiceNumber((String)row.get("invoiceNumber"));

					spotFireDataBean.setInvoiceStatus((String)row.get("invoiceStatus"));
					spotFireDataBean.setInvoiceStatusChangeDt((String)row.get("invoiceStatusChangeDt"));
					spotFireDataBean.setItemCode((String)row.get("itemCode"));
					spotFireDataBean.setItemDescription((String)row.get("itemDescription"));
					spotFireDataBean.setLegalEntityCode((String)row.get("legalEntityCode"));
					spotFireDataBean.setLegalEntityName((String)row.get("legalEntityName"));
					spotFireDataBean.setLength((String)row.get("length"));
					spotFireDataBean.setLineBilledAmt((String)row.get("lineBilledAmt"));
					spotFireDataBean.setLineId((String)row.get("lineId"));
					spotFireDataBean.setLineStatus((String)row.get("lineStatus"));

					spotFireDataBean.setLineTrueCost((String)row.get("lineTrueCost"));
					spotFireDataBean.setMarket((String)row.get("market"));
					spotFireDataBean.setMngmtEntity((String)row.get("mngmtEntity"));
					spotFireDataBean.setMngmtEntityDesc((String)row.get("mngmtEntityDesc"));
					spotFireDataBean.setMotherJob((String)row.get(FMSVariableConstants.MOTHERJOB));
					spotFireDataBean.setMoveOrder((String)row.get("moveOrder"));
					spotFireDataBean.setMsRegion((String)row.get("msRegion"));
					spotFireDataBean.setMultipleBox((String)row.get("multipleBox"));
					spotFireDataBean.setNetAmount((String)row.get("netAmount"));
					spotFireDataBean.setNetWeight((String)row.get("netWeight"));

					spotFireDataBean.setOrderType((String)row.get(FMSVariableConstants.ORDERTYPE));
					spotFireDataBean.setOrderedDate((String)row.get("orderedDate"));
					spotFireDataBean.setOrderedQuantity((String)row.get("orderedQuantity"));
					spotFireDataBean.setOtm((String)row.get("otm"));
					spotFireDataBean.setpAndL((String)row.get("pAndL"));
					spotFireDataBean.setPenalty((String)row.get("penalty"));
					spotFireDataBean.setPoCurrency((String)row.get("poCurrency"));
					spotFireDataBean.setPoIRLineNumber((String)row.get("poIRLineNumber"));
					spotFireDataBean.setPoNumber((String)row.get("poNumber"));
					spotFireDataBean.setPoPromiseDate((String)row.get("poPromiseDate"));

					spotFireDataBean.setProduct((String)row.get(FMSVariableConstants.PRODUCT));
					spotFireDataBean.setProductLine((String)row.get("productLine"));
					spotFireDataBean.setProjectManager((String)row.get(FMSVariableConstants.PROJECTMANAGER));
					spotFireDataBean.setProjectType((String)row.get("projectType"));
					spotFireDataBean.setPromiseDate((String)row.get("promiseDate"));
					spotFireDataBean.setRescheduleMonth((String)row.get("rescheduleMonth"));
					spotFireDataBean.setRescheduleQuarter((String)row.get("rescheduleQuarter"));
					spotFireDataBean.setRescheduleYear((String)row.get("rescheduleYear"));
					spotFireDataBean.setResidualPortSales((String)row.get("residualPortSales"));
					spotFireDataBean.setSalesForecastingDate((String)row.get("salesForecastingDate"));

					spotFireDataBean.setSalesForecastingMnth((String)row.get("salesForecastingMnth"));
					spotFireDataBean.setSalesForecastingQuarter((String)row.get("salesForecastingQuarter"));
					spotFireDataBean.setSalesForecastingYear((String)row.get("salesForecastingYear"));
					spotFireDataBean.setScheduleShipDate((String)row.get("scheduleShipDate"));
					spotFireDataBean.setSoCreationDate((String)row.get("soCreationDate"));
					spotFireDataBean.setSoCwd((String)row.get("soCwd"));
					spotFireDataBean.setSoLine((String)row.get("soLine"));
					spotFireDataBean.setSoStatus((String)row.get("soStatus"));
					spotFireDataBean.setSupplierId((String)row.get("supplierId"));
					spotFireDataBean.setSupplierName((String)row.get("supplierName"));

					spotFireDataBean.setSupplyNumber((String)row.get("supplyNumber"));
					spotFireDataBean.setSupplyType((String)row.get("supplyType"));
					spotFireDataBean.setTpRate((String)row.get("tpRate"));
					spotFireDataBean.setTransferPrice((String)row.get("transferPrice"));
					spotFireDataBean.setTtDate((String)row.get("ttDate"));
					spotFireDataBean.setUnitCost((String)row.get("unitCost"));
					spotFireDataBean.setUnitSellingPrice((String)row.get("unitSellingPrice"));
					spotFireDataBean.setUnitTrueCost((String)row.get("unitTrueCost"));
					spotFireDataBean.setUserItemDescription((String)row.get("userItemDescription"));
					spotFireDataBean.setVatAmount((String)row.get("vatAmount"));

					spotFireDataBean.setWidth((String)row.get("width"));
					spotFireDataBean.setProgress((String)row.get("progress"));
					spotFireDataBean.setSite((String)row.get("site"));
					spotFireDataBean.setEuroDiscountPrice((String)row.get("euroDiscountPrice"));
					spotFireDataBean.setEuroPrice((String)row.get("euroPrice"));
					spotFireDataBean.setInvoiceWeek((String)row.get("invoiceWeek"));
					spotFireDataBean.setInvoiceYear((String)row.get("invoiceYear"));
					spotFireDataBean.setMaxShippingDate((String)row.get("maxShippingDate"));
					spotFireDataBean.setOldBoxCategory((String)row.get("oldBoxCategory"));
					spotFireDataBean.setOldBoxDays((String)row.get("oldBoxDays"));

					spotFireDataBean.setPartsStatus((String)row.get("partsStatus"));
					spotFireDataBean.setPromiseDateMonth((String)row.get("promiseDateMonth"));
					spotFireDataBean.setPromiseDateYear((String)row.get("promiseDateYear"));
					spotFireDataBean.setTotalProInvoice((String)row.get("totalProInvoice"));
					spotFireDataBean.setFxRateEur((String)row.get("fxRateEur"));
					spotFireDataBean.setPrimaryKey((String)row.get("primaryKey"));
					spotFireDataBean.setSalesType((String)row.get("salesType"));
					spotFireDataBean.setLineType((String)row.get("lineType"));
					spotFireDataBean.setRtsDate((String)row.get("rtsDate"));
					spotFireDataBean.setTpPercentage((String)row.get("tpPercentage"));

					spotFireDataBean.setPoReleaseDate((String)row.get("poReleaseDate"));
					spotFireDataBean.setPorReleaseDate((String)row.get("porReleaseDate"));
					spotFireDataBean.setRegion((String)row.get(FMSVariableConstants.REGION));
					spotFireDataBean.setCustPOLineNum((String)row.get("custPOLineNum"));
					spotFireDataBean.setTtTime((String)row.get("ttTime"));
					spotFireDataBean.setLeadTime((String)row.get("leadTime"));
					spotFireDataBean.setLoadingProgress((String)row.get("loadingProgress"));
					spotFireDataBean.setSubRegion((String)row.get("subRegion"));
					spotFireDataBean.setShipSetName((String)row.get("shipSetName"));
					spotFireDataBean.setSalesDateBkp((String)row.get("salesDateBkp"));

					spotFireDataBean.setOgRegion((String)row.get("ogRegion"));
					spotFireDataBean.setMachineSN((String)row.get("machineSN"));
					spotFireDataBean.setTaskNumber((String)row.get("taskNumber"));
					spotFireDataBean.setAdvFlag((String)row.get("advFlag"));
					spotFireDataBean.setDiscountAmount((String)row.get("discountAmount"));
					spotFireDataBean.setReversalAmount((String)row.get("reversalAmount"));
					spotFireDataBean.setManager((String)row.get("manager"));
					spotFireDataBean.setStorage((String)row.get("storage"));

					spotFireDataBean.setCommitmentDate((String)row.get("commitmentDate"));
					spotFireDataBean.setDateStamp((String)row.get("dateStamp"));
					spotFireDataBean.setDwLoadDate((String)row.get("downloadDate"));
					spotFireDataBean.setDwUpdateDate((String)row.get("downloadUpdateDate"));
					spotFireDataBean.setLineNumber((String)row.get("lineNumber"));
					spotFireDataBean.setProjectManagerCommitment((String)row.get("projectManagerCommitment"));
					spotFireDataBean.setProjectNumber((String)row.get("projectNumber"));
					spotFireDataBean.setRemarks((String)row.get("remarks"));
					spotFireDataBean.setUserId((String)row.get("userId"));
					spotFireDataBean.setPrimaryId((String)row.get("primaryId"));
					spotFireDataBean.setSalesTqle((String)row.get("salesTqle"));
					spotFireDataBean.setCmTqle((String)row.get("cmTqle"));

					Object[] params = {ipmUniqueId,spotFireDataBean.getActualCost(),spotFireDataBean.getActualShipmentDate(),spotFireDataBean.getActualShipmentQuarter(),spotFireDataBean.getAgreementIddelProgeto(),spotFireDataBean.getAgreementName(),spotFireDataBean.getAmountReadyHP(),
							spotFireDataBean.getAmountReadySP(),spotFireDataBean.getAmountShipped(),spotFireDataBean.getAmtInShipping(),spotFireDataBean.getAmtNotReady(),spotFireDataBean.getAreIncGlobops(),spotFireDataBean.getAwb(),spotFireDataBean.getBaseline(),spotFireDataBean.getBasket(),spotFireDataBean.getBookingMonth(),spotFireDataBean.getBookingYear(),
							spotFireDataBean.getBoxNumber(),spotFireDataBean.getoUName(),spotFireDataBean.getBookingDate(),spotFireDataBean.getBoxClosureDate(),spotFireDataBean.getBucCode(),spotFireDataBean.getBusinessSegment(),spotFireDataBean.getBuyerCustCode(),spotFireDataBean.getBuyerCustCountryDesc(),spotFireDataBean.getBuyerCustName(),spotFireDataBean.getCmGlobalContract(),
							spotFireDataBean.getCmPerSold(),spotFireDataBean.getCmPercent(),spotFireDataBean.getContrPerShippAllwd(),spotFireDataBean.getContractNumber(),spotFireDataBean.getCostingProject(),spotFireDataBean.getCsAgreementType(),spotFireDataBean.getCsRegion(),spotFireDataBean.getCsSubRegion(),spotFireDataBean.getCustomerPOAmount(),spotFireDataBean.getCustomerPONumber(),
							spotFireDataBean.getCwdQuarter(),spotFireDataBean.getCwdWeek(),spotFireDataBean.getCwdYear(),spotFireDataBean.getDdtDate(),spotFireDataBean.getDdtNumber(),spotFireDataBean.getDeliverableNum(),spotFireDataBean.getDeliveryTerm(),spotFireDataBean.getDeliveryStatus(),spotFireDataBean.getDescreZoneClasse(),spotFireDataBean.getDiscoutExtraPrice(),
							spotFireDataBean.getDolDiscountPrice(),spotFireDataBean.getDollarPrice(),spotFireDataBean.getDpsRegion(),spotFireDataBean.getDpsSubRegion(),spotFireDataBean.getDwLoadDate(),spotFireDataBean.getDwUpdateDate(),spotFireDataBean.getEarlyDeliveryAllowed(),spotFireDataBean.getEndUserCountryDesc(),spotFireDataBean.getEndUserCountryCode(),spotFireDataBean.getEndUserCustName(),
							spotFireDataBean.getFxRate(),spotFireDataBean.getG3Promised(),spotFireDataBean.getGratisSI(),spotFireDataBean.getGrossWeight(),spotFireDataBean.getHeight(),spotFireDataBean.getiC(),spotFireDataBean.getIbasEventId(),spotFireDataBean.getInvoiceAmount(),spotFireDataBean.getInvoiceDate(),spotFireDataBean.getInvoiceNumber(),
							spotFireDataBean.getInvoiceStatus(),spotFireDataBean.getInvoiceStatusChangeDt(),spotFireDataBean.getItemCode(),spotFireDataBean.getItemDescription(),spotFireDataBean.getLegalEntityCode(),spotFireDataBean.getLegalEntityName(),spotFireDataBean.getLength(),spotFireDataBean.getLineBilledAmt(),spotFireDataBean.getLineId(),spotFireDataBean.getLineStatus(),
							spotFireDataBean.getLineTrueCost(),spotFireDataBean.getMarket(),spotFireDataBean.getMngmtEntity(),spotFireDataBean.getMngmtEntityDesc(),spotFireDataBean.getMotherJob(),spotFireDataBean.getMoveOrder(),spotFireDataBean.getMsRegion(),spotFireDataBean.getMultipleBox(),spotFireDataBean.getNetAmount(),spotFireDataBean.getNetWeight(),
							spotFireDataBean.getOrderType(),spotFireDataBean.getOrderedDate(),spotFireDataBean.getOrderedQuantity(),spotFireDataBean.getOtm(),spotFireDataBean.getpAndL(),spotFireDataBean.getPenalty(),spotFireDataBean.getPoCurrency(),spotFireDataBean.getPoIRLineNumber(),spotFireDataBean.getPoNumber(),spotFireDataBean.getPoPromiseDate(),
							spotFireDataBean.getProduct(),spotFireDataBean.getProductLine(),spotFireDataBean.getProjectManager(),spotFireDataBean.getProjectType(),spotFireDataBean.getPromiseDate(),spotFireDataBean.getRescheduleMonth(),spotFireDataBean.getRescheduleQuarter(),spotFireDataBean.getRescheduleYear(),spotFireDataBean.getResidualPortSales(),spotFireDataBean.getSalesForecastingDate(),
							spotFireDataBean.getSalesForecastingMnth(),spotFireDataBean.getSalesForecastingQuarter(),spotFireDataBean.getSalesForecastingYear(),spotFireDataBean.getScheduleShipDate(),spotFireDataBean.getSoCreationDate(),spotFireDataBean.getSoCwd(),spotFireDataBean.getSoLine(),spotFireDataBean.getSoStatus(),spotFireDataBean.getSupplierId(),spotFireDataBean.getSupplierName(),
							spotFireDataBean.getSupplyNumber(),spotFireDataBean.getSupplyType(),spotFireDataBean.getTpRate(),spotFireDataBean.getTransferPrice(),spotFireDataBean.getTtDate(),spotFireDataBean.getUnitCost(),spotFireDataBean.getUnitSellingPrice(),spotFireDataBean.getUnitTrueCost(),spotFireDataBean.getUserItemDescription(),spotFireDataBean.getVatAmount(),
							spotFireDataBean.getWidth(),spotFireDataBean.getProgress(),spotFireDataBean.getSite(),spotFireDataBean.getEuroDiscountPrice(),spotFireDataBean.getEuroPrice(),spotFireDataBean.getInvoiceWeek(),spotFireDataBean.getInvoiceYear(),spotFireDataBean.getMaxShippingDate(),spotFireDataBean.getOldBoxCategory(),spotFireDataBean.getOldBoxDays(),
							spotFireDataBean.getPartsStatus(),spotFireDataBean.getPromiseDateMonth(),spotFireDataBean.getPromiseDateYear(),spotFireDataBean.getTotalProInvoice(),spotFireDataBean.getFxRateEur(),spotFireDataBean.getPrimaryKey(),spotFireDataBean.getSalesType(),spotFireDataBean.getLineType(),spotFireDataBean.getRtsDate(),spotFireDataBean.getTpPercentage(),
							spotFireDataBean.getPoReleaseDate(),spotFireDataBean.getPorReleaseDate(),spotFireDataBean.getRegion(),spotFireDataBean.getCustPOLineNum(),spotFireDataBean.getTtTime(),spotFireDataBean.getLeadTime(),spotFireDataBean.getLoadingProgress(),spotFireDataBean.getSubRegion(),spotFireDataBean.getShipSetName(),spotFireDataBean.getSalesDateBkp(),
							spotFireDataBean.getOgRegion(),spotFireDataBean.getMachineSN(),spotFireDataBean.getTaskNumber(),spotFireDataBean.getAdvFlag(),spotFireDataBean.getDiscountAmount(),spotFireDataBean.getReversalAmount(),spotFireDataBean.getManager(),spotFireDataBean.getStorage(),
							spotFireDataBean.getCommitmentDate(),spotFireDataBean.getDateStamp(),spotFireDataBean.getDwLoadDate(),spotFireDataBean.getDwUpdateDate(),spotFireDataBean.getLineNumber(),spotFireDataBean.getProjectManagerCommitment(),spotFireDataBean.getProjectNumber(),spotFireDataBean.getRemarks(),spotFireDataBean.getUserId(),spotFireDataBean.getPrimaryId(),spotFireDataBean.getSalesTqle(),spotFireDataBean.getCmTqle()		
					};

					int[] types = {Types.NUMERIC,Types.NUMERIC,Types.DATE,Types.VARCHAR,Types.NUMERIC,Types.VARCHAR,Types.NUMERIC,
							Types.NUMERIC,Types.NUMERIC,Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
							Types.VARCHAR,Types.VARCHAR,Types.DATE,Types.DATE,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,
							Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.VARCHAR,
							Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.DATE,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,
							Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.DATE,Types.DATE,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
							Types.NUMERIC,Types.DATE,Types.VARCHAR,Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.DATE,Types.VARCHAR,
							Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,
							Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.NUMERIC,
							Types.VARCHAR,Types.DATE,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.DATE,
							Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.DATE,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.DATE,
							Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.DATE,Types.DATE,Types.DATE,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.VARCHAR,
							Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.NUMERIC,Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.NUMERIC,
							Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.DATE,Types.VARCHAR,Types.VARCHAR,
							Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.DATE,Types.NUMERIC,
							Types.DATE,Types.DATE,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
							Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,
							Types.DATE,Types.TIMESTAMP,Types.DATE,Types.DATE,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.NUMERIC,Types.NUMERIC
					};

					jdbc.update(FMSQueryConstants.INSERT_ORACLE_DATA, params,types);
					ipmUniqueId = ipmUniqueId+1;
				}

			}
		}
		java.util.Date serviceendtime = new java.util.Date();
		log.info("Service End Time:" + serviceendtime);
		jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Service End Time:" + serviceendtime,"getOracleData"});
		updateIPMLogicFields();

	}

	@Transactional
	@Override
	public void getOracleOBPData() {

		jdbc.execute(FMSQueryConstants.DELETE_OLD_OBP_DATA);
		List<Map<String, Object>> rows = akanaHandler.execute("getOBPData", HttpMethod.GET, null);
		for(Map<String, Object> row : rows){
			Object[] params = new Object[row.keySet().size()];
			List<String> keys = new ArrayList<>();
			for(String key:row.keySet()){
				keys.add(key);
			}
			for(int i=0;i<keys.size();i++) {
				String key = keys.get(i);
				params[i] = row.get(key);
			}
			jdbc.update(FMSQueryConstants.INSERT_OBP_DATA, params);
		}
	}

	@Override
	public void getOracleIBASData() {
		Map<String,Object> filterData = new HashMap<>();
		filterData.put(FMSVariableConstants.SSO_ID, FMSVariableConstants.QTR_SYNC);
		getOracleIBASDataDTS(filterData);
		/**getOracleIBASDataTMS(filterData);*/
	}



	@Override
	public void getOracleDMData() {
		log.info("getOracleDMData entered in DAO Impl");
		jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.IN_PROGRESS,"Data fetching Started for Deal Machines","getOracleDMData"});
		int delDMRow = jdbc.update(FMSQueryConstants.DELETE_OLD_DM_DATA);
		List<String> primaryRegion = new ArrayList<>();
		log.info("deleted rows : "+delDMRow);
		List<Map<String, Object>> rows = null;
		int ct = 1;
		try{
			primaryRegion = akanaHandler.execute("getDMPrimaryRegion", HttpMethod.GET, null);
			log.info("Data fetched from Oracle for getDMPrimaryRegion() : "+primaryRegion);
		} catch(Exception e) {
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleDMData~akanaHandler~getDMPrimaryRegion"});
			log.info("Erors in primaryRegion" + e);
		} 

		for(int index=0;index<primaryRegion.size();index++){
			log.info("Region  : "+Utils.getValidation(primaryRegion.get(index)));
			Map<String,String> postData = new HashMap<>();
			postData.put("region", Utils.getValidation(primaryRegion.get(index)));
			try{
				rows = akanaHandler.execute("getDMData", HttpMethod.POST, postData);
			}catch(Exception e){
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleDMData~akanaHandler~getDMData"});
				log.info("DM data akana handler error" + e.getStackTrace());
			}

			for(Map<String, Object> row : rows){
				Object[] params = new Object[row.keySet().size()];
				List<String> keys = new ArrayList<>();
				for(String key:row.keySet()){
					keys.add(key);
				}
				for(int i=0;i<keys.size();i++) {
					String key = keys.get(i);
					params[i] = row.get(key);
				}
				try {
					jdbc.update(FMSQueryConstants.INSERT_DM_DATA, params);
				} catch (Exception e) {
					jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleDMData~DataInsertion"});
					log.info("insertion error" +e);
				}
			}
		}
		String count = jdbc.queryForObject(FMSQueryConstants.DM_DATA_MAPPING,new Object[]{FMSVariableConstants.SUCCESS.toLowerCase()},String.class);
		log.info("before DM_FUZZY_FUNC");
		String msg = jdbc.queryForObject(FMSQueryConstants.DM_FUZZY_FUNC,String.class);
		log.info("after DM_FUZZY_FUNC");
		jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Data Insertion Successful & Mapping Done || "+count+FMSVariableConstants.PARAM_SEPARATOR+msg,"getOracleDMData"});
		log.info("mapping done for DM: "+count);	
	}

	@Transactional
	@Override
	public void getOracleOutageData() {
		List<String> demItemStatus = new ArrayList<>();
		jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.IN_PROGRESS,"Data fetching Started for Outage","getOracleOutageData"});
		jdbc.update(FMSQueryConstants.DELETE_OLD_OUTAGE_DATA);
		List<Map<String, Object>> rows=null;

		try{
			demItemStatus = akanaHandler.execute("getOutageDemItemStatus", HttpMethod.GET, null);
		} catch(Exception e) {
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleOutageData~akanaHandler~getOutageDemItemStatus"});
		} 

		for(int index=0;index<demItemStatus.size();index++){
			Map<String,String> postData = new HashMap<>();
			postData.put("Id", Utils.getValidation(demItemStatus.get(index)));
			try{
				rows = akanaHandler.execute("getOutageData", HttpMethod.POST, postData);
			}catch(Exception e){
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleOutageData~akanaHandler~getOutageData"});
			}
			for(Map<String, Object> row : rows){
				Object[] params = new Object[row.keySet().size()];
				List<String> keys = new ArrayList<>();
				for(String key:row.keySet()){
					keys.add(key);
				}
				for(int i=0;i<keys.size();i++) {
					String key = keys.get(i);
					params[i] = row.get(key);
				}
				try{
					jdbc.update(FMSQueryConstants.INSERT_OUTAGE_DATA, params);
				}catch(Exception e){
					jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleOutageData~DataInsertion"});
				}
			}

		}
		String info = jdbc.queryForObject(FMSQueryConstants.GENERATE_OUTAGE_EQUIPMENT_MAPPING,new Object[]{FMSVariableConstants.SUCCESS.toLowerCase()},String.class);
		jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Data Insertion Successful & Mapping Done || "+info,"getOracleOutageData"});
		log.info("mapping done : "+info);
	}


	@Override
	public Map<String, Object> getIPMPartsData(Map<String,Object> filterData) {

		Map<String, Object> ipmPartsDataList = new HashMap<>();
		String query;
		int roleId = Utils.getIntegerValidation(filterData.get(FMSVariableConstants.ROLE_ID));
		String projectManager = Utils.getValidation(filterData.get(FMSVariableConstants.PROJECTMANAGER));
		/**order by booking_date desc limit 300*/

		if(projectManager.isEmpty()){
			/**getting role specific IPM parts data*/ 
			if (roleId == 7 || roleId == 8)
				query= FMSQueryConstants.PARTS_DATA + " AND upper(new_p_and_l) = '" + FMSVariableConstants.DTS_SEGMENT + "'";
			else if (roleId == 5 || roleId == 6)
				query= FMSQueryConstants.PARTS_DATA + " AND upper(new_p_and_l) = '" + FMSVariableConstants.TMS_SEGMENT + "'";
			else
				query= FMSQueryConstants.PARTS_DATA ;

			query = query + " order by booking_date desc limit 300";

		} else{
			query= FMSQueryConstants.PARTS_DATA;
		}
		List<Map<String, Object>> partsColumnHeader = jdbc.query(FMSQueryConstants.PARTS_COLUMNS_HEADER, new MiscRowMapper());
		List<Map<String, Object>> partsData = jdbc.query(query,new Object[]{Utils.getValidation(filterData.get(FMSVariableConstants.PROJECTMANAGER))}, new MiscRowMapper());
		ipmPartsDataList.put("partsColumnHeader", partsColumnHeader);
		ipmPartsDataList.put("partsData" , partsData);
		return ipmPartsDataList;
	}

	@Override
	public List<Map<String, Object>> getOrderDataWithFilter(Map<String,Object> data) {
		String type = Utils.getValidation(data.get(FMSVariableConstants.TYPE));
		/**String businessSegment = Utils.getValidation(data.get(FMSVariableConstants.BUSINESS_SEG));*/
		String businessSegment =FMSVariableConstants.EMPTY_STRING;
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		if(type.equalsIgnoreCase(FMSVariableConstants.DEFAULT)){
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.YEAR, -5);
			int year = cal.get(Calendar.YEAR);
			return jdbc.query(FMSQueryConstants.RETRIEVE_ORDER_DATA,new Object[]{year,businessSegment,marketIndustry}, new MiscRowMapper());	
		}else{
			return jdbc.query(FMSQueryConstants.RETRIEVE_ORDER_DATA_ORIGINAL,new Object[]{businessSegment,marketIndustry}, new MiscRowMapper());
		}

	}

	@Override
	public Map<String,List<String>> getIPMDropdownData(Map<String,Object> filterData) {
		Object[] params = new Object[1];
		params[0] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));

		List<String> businessSegment = jdbc.queryForList(FMSQueryConstants.IPM_DROPDOWN_BUSINESS_SEGMENT, String.class);
		List<String> product = jdbc.queryForList(FMSQueryConstants.IPM_DROPDOWN_PRODUCT,params, String.class);
		List<String> ouname = jdbc.queryForList(FMSQueryConstants.IPM_DROPDOWN_OU_NAME, params, String.class);
		List<String> pandL = jdbc.queryForList(FMSQueryConstants.IPM_DROPDOWN_P_AND_L, params, String.class);
		List<String> ogregion = jdbc.queryForList(FMSQueryConstants.IPM_DROPDOWN_OG_REGION, params, String.class);
		List<String> region = jdbc.queryForList(FMSQueryConstants.IPM_DROPDOWN_REGION, params, String.class);		 
		List<String> subregion = jdbc.queryForList(FMSQueryConstants.IPM_DROPDOWN_SUBREGION, params, String.class);
		List<String> endUserCountryDisc = jdbc.queryForList(FMSQueryConstants.IPM_DROPDOWN_END_USER_COUNTRY_DISC,params, String.class);
		List<String> orderType = jdbc.queryForList(FMSQueryConstants.IPM_DROPDOWN_ORDER_TYPE,params, String.class);
		List<String> week = jdbc.queryForList(FMSQueryConstants.IPM_DROPDOWN_WEEK, String.class);
		List<String> revRec = jdbc.queryForList(FMSQueryConstants.PMO_DROPDOWN_REV_REC, String.class);
		String postQuery = FMSQueryConstants.IPM_PROJECT_MANAGER + " AND upper(new_p_and_l) = '" + Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG)) + "'";

		List<String> projectManager = jdbc.queryForList(postQuery, String.class);
		Map<String,List<String>> ipmDropdownData = new LinkedHashMap<>();

		ipmDropdownData.put(FMSVariableConstants.BUSINESSSEGMENT, businessSegment);
		ipmDropdownData.put(FMSVariableConstants.PRODUCT, product);
		ipmDropdownData.put(FMSVariableConstants.OUNAME, ouname);
		ipmDropdownData.put(FMSVariableConstants.PANDL, pandL);
		ipmDropdownData.put(FMSVariableConstants.OGREGION, ogregion);
		ipmDropdownData.put(FMSVariableConstants.REGION, region);
		ipmDropdownData.put(FMSVariableConstants.SUBREGION, subregion);
		ipmDropdownData.put(FMSVariableConstants.ENDUSERCOUNTRYDISC, endUserCountryDisc);
		ipmDropdownData.put(FMSVariableConstants.ORDERTYPE, orderType);
		ipmDropdownData.put(FMSVariableConstants.WEEK, week);
		ipmDropdownData.put(FMSVariableConstants.REVREC, revRec);
		ipmDropdownData.put(FMSVariableConstants.PROJECTMANAGER, projectManager);
		return ipmDropdownData;
	}

	@Override
	public Map<String, Object> getIPMData(Map<String,Object> filterData,String type) {
		String query = null;
		Map<String, Object> result = new LinkedHashMap<>();
		List<Map<String,Object>> resultPreWeek = new ArrayList<>();
		String header ="";
		String colHeader ="";
		String [] regions=null;
		try{
			Object[] params = new Object[24];
			params[0] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
			params[1] = Utils.getValidation(filterData.get(FMSVariableConstants.PANDL));
			params[2] = Utils.getValidation(filterData.get(FMSVariableConstants.PRODUCT));
			params[3] = Utils.getValidation(filterData.get(FMSVariableConstants.OUNAME));
			params[4] = Utils.getValidation(filterData.get(FMSVariableConstants.OGREGION));
			params[5] = Utils.getValidation(filterData.get(FMSVariableConstants.REGION));
			params[6] = Utils.getValidation(filterData.get(FMSVariableConstants.SUBREGION));
			params[7] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCOUNTRYDISC));
			params[8] = Utils.getValidation(filterData.get(FMSVariableConstants.MOTHERJOB));
			params[9] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCUSTNAME));
			params[10] =Utils.getValidation(filterData.get(FMSVariableConstants.COSTINGPROJECT));
			params[11] =Utils.getValidation(filterData.get(FMSVariableConstants.ORDERTYPE));
			params[12] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
			params[13] = Utils.getValidation(filterData.get(FMSVariableConstants.PANDL));
			params[14] = Utils.getValidation(filterData.get(FMSVariableConstants.PRODUCT));
			params[15] = Utils.getValidation(filterData.get(FMSVariableConstants.OUNAME));
			params[16] = Utils.getValidation(filterData.get(FMSVariableConstants.OGREGION));
			params[17] = Utils.getValidation(filterData.get(FMSVariableConstants.REGION));
			params[18] = Utils.getValidation(filterData.get(FMSVariableConstants.SUBREGION));
			params[19] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCOUNTRYDISC));
			params[20] = Utils.getValidation(filterData.get(FMSVariableConstants.MOTHERJOB));
			params[21] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCUSTNAME));
			params[22] =Utils.getValidation(filterData.get(FMSVariableConstants.COSTINGPROJECT));
			params[23] =Utils.getValidation(filterData.get(FMSVariableConstants.ORDERTYPE));

			Date d = new Date();
			Calendar cal = Calendar. getInstance();
			cal.setFirstDayOfWeek(Calendar.MONDAY);
			cal.setTime(d);
			cal.setMinimalDaysInFirstWeek(7);
			int week = cal.get(Calendar.WEEK_OF_YEAR);

			if(week == Utils.nullCheckInt(filterData.get("week")) || Utils.nullCheckInt(filterData.get("week")) == 0){
				if(type.equals(FMSVariableConstants.KEYDEALS)){
					query = FMSQueryConstants.IPM_KEYS_DEALS;
					header = "keyDealsData";
					colHeader = "keyDealsHeaders";
				}else if(type.equals(FMSVariableConstants.RISKS)){
					query = FMSQueryConstants.IPM_RISKS;
					header = "risksDealsData";
					colHeader = "risksDealsHeaders";
				}else if(type.equals(FMSVariableConstants.OPPS)){
					query = FMSQueryConstants.IPM_OPPS;
					header = "oppsDealsData";
					colHeader = "oppsDealsHeaders";
				}
				result.put(header,jdbc.query(query,params,new MiscRowMapper()));
				result.put(colHeader,jdbc.query(FMSQueryConstants.RETRIVE_PMO_HEADER,new MiscRowMapper()));
			}else{
				Object[] paramsHistory = new Object[3];
				if(type.equals(FMSVariableConstants.KEYDEALS)){
					header = "keyDealsData";
					colHeader = "keyDealsHeaders";
					paramsHistory[0] = Utils.getValidation(filterData.get(FMSVariableConstants.WEEK));
					paramsHistory[1] = "KEY_DEALS";
					paramsHistory[2] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
				}else if(type.equals(FMSVariableConstants.RISKS)){
					header = "risksDealsData";
					colHeader = "risksDealsHeaders";
					paramsHistory[0] = Utils.getValidation(filterData.get(FMSVariableConstants.WEEK));
					paramsHistory[1] = "RISK";
					paramsHistory[2] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
				}else if(type.equals(FMSVariableConstants.OPPS)){
					header = "oppsDealsData";
					colHeader = "oppsDealsHeaders";
					paramsHistory[0] = Utils.getValidation(filterData.get(FMSVariableConstants.WEEK));
					paramsHistory[1] = "OPPS";
					paramsHistory[2] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
				}
				resultPreWeek = jdbc.query(FMSQueryConstants.FW_HISTORY,paramsHistory,new MiscRowMapper());
				if(resultPreWeek.isEmpty()){

					if("DTS".equalsIgnoreCase(Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG)))){
						regions = new String [] {"APANZ","China","Europe","India","Latin America","MENAT","North America","Russia & CIS","Sub Saharan Africa"};
					}else {
						regions = new String [] {"APAC","ATM","Europe","LATAM","MET","MENAT","North America","SSA"};
					} 
					if(type.equals(FMSVariableConstants.KEYDEALS)){
						for(int i=0;i<regions.length;i++){
							Map<String,Object> row = new HashMap<>();
							row.put("final_region",regions[i]);
							row.put("p_sum_cm",null);
							row.put(FMSVariableConstants.CONCATENATE,null);
							row.put("p_and_l",null);
							row.put("product",null);
							row.put("enduser_cust_name",null);
							row.put("p_cm_dollar_by_1000",null);
							row.put(FMSVariableConstants.P_STATUS,null);
							row.put("p_wb_comment",null);
							row.put("p_note",null);
							row.put("p_due_date",null);
							row.put("p_trend",null);
							row.put(FMSVariableConstants.P_R_BY_O,null);
							row.put("p_keydeals",null);
							row.put(FMSVariableConstants.P_NEW_DATE,null);
							row.put("p_exp_fw_revrec_firts_pl",null);
							row.put("p_exp_fw_revrec",null);
							row.put("p_flow_or_no_flow",null);
							row.put("p_sum_sales",null);
							row.put("p_financial_basket",null);
							row.put("p_operational_basket",null);
							row.put("p_status_aging",null);
							row.put("row_id",null);
							resultPreWeek.add(row);
						}
					}

				}

				result.put(header,resultPreWeek);
				result.put(colHeader,jdbc.query(FMSQueryConstants.RETRIVE_PMO_HEADER,new MiscRowMapper()));
			}

		}catch(Exception e){
			log.info(e.getMessage());
		}
		return result;
	}


	@Override
	public List<Map<String, Object>> getOrderExportData() {
		return jdbc.query(FMSQueryConstants.RETRIEVE_ORDER_DATA_ORIGINAL, new MiscRowMapper());
	}

	@Override
	public String updateIPMParts(Map<String, Object> data) {
		String response;
		String trendQuery = "";
		Date newDate = null;
		String keys;
		String values;
		int newDateYearQuarter = 0;
		int saleDateYearQuarter;
		int currentDateMonth = Calendar.getInstance().get( Calendar.MONTH ) + 1;
		int currentDateQuarter = currentDateMonth % 3 == 0?  (currentDateMonth / 3): (currentDateMonth/ 3)+1;		
		int currentDateYear = Calendar.getInstance().get( Calendar.YEAR);
		int currentDateYearQuarter = Integer.valueOf(currentDateYear + "" +currentDateQuarter);
		SimpleDateFormat monthDayYear = new SimpleDateFormat("MM-dd-yyyy");
		try {
			if(data.get(FMSVariableConstants.P_NEW_DATE)!=null){
				newDate = monthDayYear.parse((String) data.get(FMSVariableConstants.P_NEW_DATE));
				Calendar newDateCalender = Calendar.getInstance();
				newDateCalender.setTime(newDate);
				int newDateMonth = newDateCalender.get(Calendar.MONTH) + 1;
				int newDateQuarter = newDateMonth % 3 == 0?  (newDateMonth / 3): ( newDateMonth / 3)+1;	
				int newDateYear = newDateCalender.get(Calendar.YEAR);
				newDateYearQuarter =Integer.valueOf(newDateYear + "" + newDateQuarter);
			}
		} catch (ParseException e1) {
			log.error(e1);
		}

		if(data.get(FMSVariableConstants.SALEDATEYEARQTR)!=null){
			saleDateYearQuarter = Integer.valueOf(Utils.getValidation(data.get(FMSVariableConstants.SALEDATEYEARQTR)).replace("-", ""));
		}else{
			saleDateYearQuarter = Utils.getIntegerValidation(data.get(FMSVariableConstants.SALEDATEYEARQTR));
		}

		try {
			Object[] params = new Object[11];
			params[0] = data.get(FMSVariableConstants.P_R_BY_O);
			params[1] = data.get("p_wb_comment");
			params[2] = newDate;
			params[3] = data.get("p_due_date");
			params[4] = data.get("p_note");
			params[5] = data.get("p_exp_fw_revrec_firts_pl");
			params[6] = data.get("p_exp_fw_revrec");
			params[7] = data.get("p_keydeals");		
			params[8] = data.get(FMSVariableConstants.P_STATUS);

			String forecastStatusValue = null;
			if(saleDateYearQuarter == currentDateYearQuarter  && newDateYearQuarter > currentDateYearQuarter) {
				forecastStatusValue = "R";
			} else if(saleDateYearQuarter > currentDateYearQuarter && newDateYearQuarter == currentDateYearQuarter)  {
				forecastStatusValue = "A";
			} else if(saleDateYearQuarter > currentDateYearQuarter  && newDateYearQuarter > currentDateYearQuarter){
				forecastStatusValue = "R";
			}

			if(FMSVariableConstants.BILLING.equalsIgnoreCase(Utils.getValidation(data.get(FMSVariableConstants.PARTS_STATUS))) || FMSVariableConstants.SHIPPING.equalsIgnoreCase(Utils.getValidation(data.get(FMSVariableConstants.PARTS_STATUS))) || FMSVariableConstants.SHIPPED.equalsIgnoreCase(Utils.getValidation(data.get(FMSVariableConstants.PARTS_STATUS)))){
				keys = FMSVariableConstants.BOX_NUMBER;
				values = Utils.getValidation(data.get(FMSVariableConstants.BOX_NUMBER));
			} else if(FMSVariableConstants.SALES.equalsIgnoreCase(Utils.getValidation(data.get(FMSVariableConstants.PARTS_STATUS)))) {
				keys = FMSVariableConstants.INVOICE_NUMBER;
				values = Utils.getValidation(data.get(FMSVariableConstants.INVOICE_NUMBER));
			}else {
				keys = "p_concatenate";
				values = Utils.getValidation(data.get(FMSVariableConstants.CONCATENATE));
			}
			params[9] = forecastStatusValue;
			params[10] = values;
			String prByO = null;
			String status = null;
			try {
				prByO =jdbc.queryForObject(FMSQueryConstants.IPM_PARTS_PRBYO,new Object[]{Utils.getValidation(data.get(FMSVariableConstants.CONCATENATE))},String.class);
				status = jdbc.queryForObject(FMSQueryConstants.IPM_PARTS_STATUS,new Object[]{Utils.getValidation(data.get(FMSVariableConstants.CONCATENATE))},String.class);
			}catch(Exception e){
				log.error(e.getMessage());
			}


			if("RISK".equalsIgnoreCase(prByO)){
				if("OPPS".equalsIgnoreCase(Utils.getValidation(data.get(FMSVariableConstants.P_R_BY_O))) || "".equalsIgnoreCase(Utils.getValidation(data.get(FMSVariableConstants.P_R_BY_O))) || data.get(FMSVariableConstants.P_R_BY_O)==null){
					trendQuery = "Update fms_ipm_parts_edit_fields SET p_trend = 'GOOD' FROM fms_ipm_master WHERE p_concatenate = concatenate and " + keys + "= ?";
				}else{
					if(Utils.getValidation(data.get(FMSVariableConstants.P_STATUS)).equalsIgnoreCase(status) || "".equalsIgnoreCase(status) || status==null ){
						trendQuery = "Update fms_ipm_parts_edit_fields SET p_trend = 'FLAT' FROM fms_ipm_master WHERE p_concatenate = concatenate and " + keys + "= ?";
					}else if("Low".equalsIgnoreCase(Utils.getValidation(data.get(FMSVariableConstants.P_STATUS)))){
						trendQuery = "Update fms_ipm_parts_edit_fields SET p_trend = 'GOOD' FROM fms_ipm_master WHERE p_concatenate = concatenate and UPPER(p_status) <> 'LOW' and " + keys + "= ?";
					}else if("High".equalsIgnoreCase(Utils.getValidation(data.get(FMSVariableConstants.P_STATUS)))){
						trendQuery = "Update fms_ipm_parts_edit_fields SET p_trend = 'BAD' FROM fms_ipm_master WHERE p_concatenate = concatenate and UPPER(p_status) <> 'HIGH'  and " + keys + "= ?";
					}else if("Medium".equalsIgnoreCase(Utils.getValidation(data.get(FMSVariableConstants.P_STATUS)))){
						if("Low".equalsIgnoreCase(status)){
							trendQuery = "Update fms_ipm_parts_edit_fields SET p_trend = 'BAD' FROM fms_ipm_master WHERE p_concatenate = concatenate and " + keys + "= ?";
						}  else if("High".equalsIgnoreCase(status)){
							trendQuery = "Update fms_ipm_parts_edit_fields SET p_trend = 'GOOD' FROM fms_ipm_master WHERE p_concatenate = concatenate and " + keys + "= ?";
						}
					}
				}
			}else if("OPPS".equalsIgnoreCase(prByO) || "".equalsIgnoreCase(prByO) || prByO==null){
				if("RISK".equalsIgnoreCase(Utils.getValidation(data.get(FMSVariableConstants.P_R_BY_O)))){
					trendQuery = "Update fms_ipm_parts_edit_fields SET p_trend = 'BAD' FROM fms_ipm_master WHERE p_concatenate = concatenate and " + keys + "= ?";
				}else{
					if(Utils.getValidation(data.get(FMSVariableConstants.P_STATUS)).equalsIgnoreCase(status)|| "".equalsIgnoreCase(status) || status==null ){
						trendQuery = "Update fms_ipm_parts_edit_fields SET p_trend = 'FLAT' FROM fms_ipm_master WHERE p_concatenate = concatenate and " + keys + "= ?";
					}else if("Low".equalsIgnoreCase(Utils.getValidation(data.get(FMSVariableConstants.P_STATUS)))){

						trendQuery = "Update fms_ipm_parts_edit_fields SET p_trend = 'BAD' FROM fms_ipm_master WHERE p_concatenate = concatenate and UPPER(p_status) <> 'LOW' and " + keys + "= ?";
					}else if("High".equalsIgnoreCase(Utils.getValidation(data.get(FMSVariableConstants.P_STATUS)))){
						trendQuery = "Update fms_ipm_parts_edit_fields SET p_trend = 'GOOD' FROM fms_ipm_master WHERE p_concatenate = concatenate and UPPER(p_status) <> 'HIGH'  and " + keys + "= ?";
					}else if("Medium".equalsIgnoreCase(Utils.getValidation(data.get(FMSVariableConstants.P_STATUS)))){
						if("Low".equalsIgnoreCase(status)){
							trendQuery = "Update fms_ipm_parts_edit_fields SET p_trend = 'GOOD' FROM fms_ipm_master WHERE p_concatenate = concatenate and " + keys + "= ?";
						}  else if("High".equalsIgnoreCase(status)){
							trendQuery = "Update fms_ipm_parts_edit_fields SET p_trend = 'BAD' FROM fms_ipm_master WHERE p_concatenate = concatenate and "+ keys + "= ?";
						}
					}
				}
			}
			jdbc.update(trendQuery,new Object[]{values});
			jdbc.update(FMSQueryConstants.IMP_PARTS_UPDATE + keys + "= ?", params);
			response = FMSVariableConstants.UPDATED;
		}catch(Exception e) {
			log.error(e.getMessage());
			response = FMSVariableConstants.FAILURE;
		}
		return response;

	}

	@Override
	public List<Map<String, Object>> getIPMPartsExcelDropdown() {
		return jdbc.query(FMSQueryConstants.PARTS_COLUMNS_HEADER, new MiscRowMapper());
	}

	@Override
	public List<Map<String, Object>> getIPMDataEntryData(Map<String,Object> filterData) {
		Object[] params  = new Object[2];
		params[0] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));

		if("".equals(Utils.getValidation(filterData.get(FMSVariableConstants.WEEK)))){
			Date d = new Date();
			Calendar cal = Calendar. getInstance();
			cal.setFirstDayOfWeek(Calendar.MONDAY);
			cal.setTime(d);
			cal.setMinimalDaysInFirstWeek(7);
			params[1] = String.valueOf(cal.get(Calendar.WEEK_OF_YEAR));
		} else {
			params[1] = Utils.getValidation(filterData.get(FMSVariableConstants.WEEK));
		}
		return jdbc.query(FMSQueryConstants.IPM_DATA_ENTRY, params, new MiscRowMapper());
	}


	@Override
	public String updateIPMDataEntryData(
			Map<String, Map<String, Object>> updatedData) {
		String response = "";
		try {
			for (Entry<String, Map<String, Object>> entry : updatedData
					.entrySet()) {
				Object[] params = new Object[23];
				params[0] = Utils.getNumericValidation(entry.getValue().get("op_val"));
				params[1] = Utils.getNumericValidation(entry.getValue().get("ce_val"));
				params[2] = Utils.getNumericValidation(entry.getValue().get("pe_val"));
				params[3] = Utils.getNumericValidation(entry.getValue().get("risk_val"));
				params[4] = Utils.getNumericValidation(entry.getValue().get("opp_val"));
				params[5] = Utils.getNumericValidation(entry.getValue().get("tx_ce_val"));
				params[6] = Utils.getNumericValidation(entry.getValue().get("cs_ce_val"));
				params[7] = Utils.getNumericValidation(entry.getValue().get("ins_ce_val"));
				params[8] = Utils.getNumericValidation(entry.getValue().get("tx_op_val"));
				params[9] = Utils.getNumericValidation(entry.getValue().get("cs_op_val"));
				params[10] = Utils.getNumericValidation(entry.getValue().get("ins_op_val"));
				params[11] = Utils.getNumericValidation(entry.getValue().get("cwd_val"));
				params[12] = Utils.getNumericValidation(entry.getValue().get("actuals_val"));
				params[13] = Utils.getNumericValidation(entry.getValue().get("unconfirmed_val"));
				params[14] = Utils.getNumericValidation(entry.getValue().get("tx_pe_val"));
				params[15] = Utils.getNumericValidation(entry.getValue().get("cs_pe_val"));
				params[16] = Utils.getNumericValidation(entry.getValue().get("ins_pe_val"));
				params[17] = Utils.getNumericValidation(entry.getValue().get("tx_pe_backlog"));
				params[18] = Utils.getNumericValidation(entry.getValue().get("cs_pe_backlog"));
				params[19] = Utils.getNumericValidation(entry.getValue().get("ins_pe_backlog"));
				params[20] = Utils.getValidation(entry.getKey());
				params[21] = Utils.getValidation(entry.getValue().get("business_unit"));
				params[22] = Utils.getValidation(entry.getValue().get("week"));
				jdbc.update(FMSQueryConstants.IPM_DATA_ENTRY_UPDATE, params);
				response = FMSVariableConstants.SUCCESS;
			}
		} catch (Exception e) {
			log.error(e);
			return FMSVariableConstants.FAILURE;
		}

		return response;
	}

	@Override
	public Map<String,Object> walkByBusinessData(Map<String, Object> filterData) {
		String data = "";
		double opTot;
		double ceTot;
		double gap;
		Object[] params = new Object[13];	
		params[0] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
		params[1] = Utils.getValidation(filterData.get(FMSVariableConstants.PANDL));
		params[2] = Utils.getValidation(filterData.get(FMSVariableConstants.PRODUCT));
		params[3] = Utils.getValidation(filterData.get(FMSVariableConstants.OUNAME));
		params[4] = Utils.getValidation(filterData.get(FMSVariableConstants.OGREGION));
		params[5] = Utils.getValidation(filterData.get(FMSVariableConstants.REGION));
		params[6] = Utils.getValidation(filterData.get(FMSVariableConstants.SUBREGION));
		params[7] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCOUNTRYDISC));
		params[8] = Utils.getValidation(filterData.get(FMSVariableConstants.MOTHERJOB));
		params[9] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCUSTNAME));
		params[10] =Utils.getValidation(filterData.get(FMSVariableConstants.COSTINGPROJECT));
		params[11] =Utils.getValidation(filterData.get(FMSVariableConstants.ORDERTYPE));
		params[12] =Utils.getValidation(filterData.get(FMSVariableConstants.WEEK));

		try{
			data = jdbc.queryForObject(FMSQueryConstants.WALK_BY_BUSINESS,params,String.class);
		} catch(Exception e){
			log.info(FMSVariableConstants.ERRORMESSAGE+e.getMessage());
		}
		Map<String,Object> completeData = new HashMap<>();
		String[] first = data.split("\\(");
		String[] second = first[1].split("\\)");

		if(FMSVariableConstants.DBERROR.equalsIgnoreCase(second[0].split(",")[0])){
			completeData.put(FMSVariableConstants.ERROR, FMSVariableConstants.ERRORMESSAGE);
		}else{

			String[] tableChart = second[0].split(",");

			//Walk By Business table
			String table = tableChart[0];
			List<Map<String,Object>> mainMap = new ArrayList<>();
			String[] rows =table.split("~");



			ceTot = Double.parseDouble(rows[0].split(";")[5]);
			opTot = Double.parseDouble(rows[4].split(";")[5]);
			gap= opTot-ceTot;

			Map<String,Object> vopMap = new LinkedHashMap<>(); //ce-op
			vopMap.put(FMSVariableConstants.HEADER,FMSVariableConstants.VOP);
			vopMap.put(FMSVariableConstants.TX, decimalFormat.format(Float.parseFloat(rows[0].split(";")[1])-Float.parseFloat(rows[4].split(";")[1])));
			vopMap.put(FMSVariableConstants.CS, decimalFormat.format(Float.parseFloat(rows[0].split(";")[2])-Float.parseFloat(rows[4].split(";")[2])));
			vopMap.put(FMSVariableConstants.INST, decimalFormat.format(Float.parseFloat(rows[0].split(";")[3])-Float.parseFloat(rows[4].split(";")[3])));
			vopMap.put(FMSVariableConstants.SC, decimalFormat.format(Float.parseFloat(rows[0].split(";")[4])-Float.parseFloat(rows[4].split(";")[4])));
			vopMap.put(FMSVariableConstants.TOT, decimalFormat.format(0));
			vopMap.put(FMSVariableConstants.GAP, decimalFormat.format(0));
			vopMap.put(FMSVariableConstants.OP, decimalFormat.format(0));


			Map<String,Object> vpeMap = new LinkedHashMap<>(); //ce-pe
			vpeMap.put(FMSVariableConstants.HEADER,FMSVariableConstants.VPE);
			vpeMap.put(FMSVariableConstants.TX, decimalFormat.format(Float.parseFloat(rows[0].split(";")[1])-Float.parseFloat(rows[1].split(";")[1])));
			vpeMap.put(FMSVariableConstants.CS, decimalFormat.format(Float.parseFloat(rows[0].split(";")[2])-Float.parseFloat(rows[1].split(";")[2])));
			vpeMap.put(FMSVariableConstants.INST,decimalFormat.format(Float.parseFloat(rows[0].split(";")[3])-Float.parseFloat(rows[1].split(";")[3])));
			vpeMap.put(FMSVariableConstants.SC, decimalFormat.format(Float.parseFloat(rows[0].split(";")[4])-Float.parseFloat(rows[1].split(";")[4])));
			vpeMap.put(FMSVariableConstants.TOT,decimalFormat.format(0));
			vpeMap.put(FMSVariableConstants.GAP, decimalFormat.format(0));
			vpeMap.put(FMSVariableConstants.OP, decimalFormat.format(0));


			for(int i=0;i<rows.length;i++){
				String[] row = rows[i].split(";");			 

				Map<String,Object> map = new LinkedHashMap<>();



				if("ce".equalsIgnoreCase(row[0])){
					map.put(FMSVariableConstants.HEADER, row[0]);
					map.put(FMSVariableConstants.TX,decimalFormat.format(Float.parseFloat(row[1])));
					map.put(FMSVariableConstants.CS, decimalFormat.format(Float.parseFloat(row[2])));
					map.put(FMSVariableConstants.INST, decimalFormat.format(Float.parseFloat(row[3])));
					map.put(FMSVariableConstants.SC, decimalFormat.format(Float.parseFloat(row[4])));
					map.put(FMSVariableConstants.TOT, decimalFormat.format(Float.parseFloat(row[5])));
					map.put(FMSVariableConstants.GAP,decimalFormat.format(gap));
					map.put(FMSVariableConstants.OP,decimalFormat.format(opTot));

					mainMap.add(map);

				}
				else if("pe".equalsIgnoreCase(row[0])){
					map.put(FMSVariableConstants.HEADER, row[0]);
					map.put(FMSVariableConstants.TX, decimalFormat.format(Float.parseFloat(row[1])));
					map.put(FMSVariableConstants.CS, decimalFormat.format(Float.parseFloat(row[2])));
					map.put(FMSVariableConstants.INST,decimalFormat.format(Float.parseFloat(row[3])));
					map.put(FMSVariableConstants.SC, decimalFormat.format(Float.parseFloat(row[4])));
					map.put(FMSVariableConstants.TOT,decimalFormat.format(Float.parseFloat(row[5])));
					map.put(FMSVariableConstants.GAP,decimalFormat.format(0));
					map.put(FMSVariableConstants.OP,decimalFormat.format(0));

					mainMap.add(map);
					mainMap.add(vpeMap);

				}
				else if("op".equalsIgnoreCase(row[0])){
					map.put(FMSVariableConstants.HEADER, row[0]);
					map.put(FMSVariableConstants.TX, decimalFormat.format(Float.parseFloat(row[1])));
					map.put(FMSVariableConstants.CS, decimalFormat.format(Float.parseFloat(row[2])));
					map.put(FMSVariableConstants.INST,decimalFormat.format(Float.parseFloat(row[3])));
					map.put(FMSVariableConstants.SC, decimalFormat.format(Float.parseFloat(row[4])));
					map.put(FMSVariableConstants.TOT,decimalFormat.format(0));
					map.put(FMSVariableConstants.GAP,decimalFormat.format(0));
					map.put(FMSVariableConstants.OP, decimalFormat.format(Float.parseFloat(row[5])));

					mainMap.add(map);
					mainMap.add(vopMap);	
				}
				else{
					map.put(FMSVariableConstants.HEADER, row[0]);
					map.put(FMSVariableConstants.TX, decimalFormat.format(Float.parseFloat(row[1])));
					map.put(FMSVariableConstants.CS, decimalFormat.format(Float.parseFloat(row[2])));
					map.put(FMSVariableConstants.INST,decimalFormat.format(Float.parseFloat(row[3])));
					map.put(FMSVariableConstants.SC, decimalFormat.format(Float.parseFloat(row[4])));
					map.put(FMSVariableConstants.TOT,decimalFormat.format(Float.parseFloat(row[5])));
					map.put(FMSVariableConstants.GAP,decimalFormat.format(0));
					map.put(FMSVariableConstants.OP,decimalFormat.format(0));

					mainMap.add(map);
				}



			}
			//Walk By Business Chart
			String chart = tableChart[1];
			String[] chartRows =chart.split("~");
			List<Map<String,Object>> chartMain = new ArrayList<>();
			Map<String,Object> chartMap = new HashMap<>();
			for(int k=0;k<chartRows.length;k++){
				List<Float> fldata = new ArrayList<>();
				String[] initialData = chartRows[k].split(";");
				for(int p=0;p<initialData.length;p++){
					fldata.add(Float.parseFloat(initialData[p]));
				}
				chartMap.put(FMSVariableConstants.ROW+k,fldata);
			}
			for(String key : chartMap.keySet()){

				if(FMSVariableConstants.ROW0.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, "OPP");
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW0));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, "#D9D9D9");
					chartRow.put(FMSVariableConstants.ID, 1);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW1.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, "RISK");
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW1));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR1);
					chartRow.put(FMSVariableConstants.ID, 2);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW2.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, "SOLID");
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW2));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR2);
					chartRow.put(FMSVariableConstants.ID, 3);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW3.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, "TOTAL");
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW3));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR3);
					chartRow.put(FMSVariableConstants.ID, 4);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW4.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, "GAP");
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW4));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR1);
					chartRow.put(FMSVariableConstants.ID, 5);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW5.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, "BLANK");
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW5));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, false);
					chartRow.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR4);
					chartRow.put(FMSVariableConstants.ID, 6);
					chartMain.add(chartRow);
				}
			}

			completeData.put(FMSVariableConstants.TABLE, mainMap);
			completeData.put(FMSVariableConstants.TABLEHEADERS, new String[]{FMSVariableConstants.TX,FMSVariableConstants.CS,FMSVariableConstants.INST,FMSVariableConstants.SC,FMSVariableConstants.TOT,FMSVariableConstants.GAP,FMSVariableConstants.OP});
			completeData.put(FMSVariableConstants.CHART, chartMain);
		}
		return completeData;
	}

	@Override
	public Map<String, Object> walkByRegionData(Map<String, Object> filterData) {
		String data = "";
		double rcisCe;
		Object[] params = new Object[13];
		params[0] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
		params[1] = Utils.getValidation(filterData.get(FMSVariableConstants.PANDL));
		params[2] = Utils.getValidation(filterData.get(FMSVariableConstants.PRODUCT));
		params[3] = Utils.getValidation(filterData.get(FMSVariableConstants.OUNAME));
		params[4] = Utils.getValidation(filterData.get(FMSVariableConstants.OGREGION));
		params[5] = Utils.getValidation(filterData.get(FMSVariableConstants.REGION));
		params[6] = Utils.getValidation(filterData.get(FMSVariableConstants.SUBREGION));
		params[7] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCOUNTRYDISC));
		params[8] = Utils.getValidation(filterData.get(FMSVariableConstants.MOTHERJOB));
		params[9] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCUSTNAME));
		params[10] =Utils.getValidation(filterData.get(FMSVariableConstants.COSTINGPROJECT));
		params[11] =Utils.getValidation(filterData.get(FMSVariableConstants.ORDERTYPE));
		params[12] =Utils.getValidation(filterData.get(FMSVariableConstants.WEEK));
		try{
			data = jdbc.queryForObject(FMSQueryConstants.WALK_BY_REGION,params,String.class);
		} catch(Exception e){
			log.info("Exception mesage : "+e.getMessage());
		}
		Map<String,Object> completeData = new HashMap<>();

		String[] first = data.split("\\(");
		String[] second = first[1].split("\\)");

		if(FMSVariableConstants.DBERROR.equalsIgnoreCase(second[0].split(",")[0])){
			completeData.put(FMSVariableConstants.ERROR, FMSVariableConstants.ERRORMESSAGE);
		}else{
			String[] tableChart = second[0].split(",");

			//Walk By Region table
			String table = tableChart[0];
			//Tx;Cs;Ins;Other;PE;OP

			List<Map<String,Object>> mainTable = new ArrayList<>();
			String[] rows =table.split("~");
			double totalTx = Double.parseDouble(rows[0].split(";")[1])+Double.parseDouble(rows[0].split(";")[2])+Double.parseDouble(rows[0].split(";")[3])
					+Double.parseDouble(rows[0].split(";")[4])+Double.parseDouble(rows[0].split(";")[5])+Double.parseDouble(rows[0].split(";")[6])
					+Double.parseDouble(rows[0].split(";")[7])+Double.parseDouble(rows[0].split(";")[8])+Double.parseDouble(rows[0].split(";")[9])
					+Double.parseDouble(rows[0].split(";")[10])+Double.parseDouble(rows[0].split(";")[11]);

			double totalCs = Double.parseDouble(rows[1].split(";")[1])+Double.parseDouble(rows[1].split(";")[2])+Double.parseDouble(rows[1].split(";")[3])
					+Double.parseDouble(rows[1].split(";")[4])+Double.parseDouble(rows[1].split(";")[5])+Double.parseDouble(rows[1].split(";")[6])
					+Double.parseDouble(rows[1].split(";")[7])+Double.parseDouble(rows[1].split(";")[8])+Double.parseDouble(rows[1].split(";")[9])
					+Double.parseDouble(rows[1].split(";")[10])+Double.parseDouble(rows[1].split(";")[11]);

			double totalIns = Double.parseDouble(rows[2].split(";")[1])+Double.parseDouble(rows[2].split(";")[2])+Double.parseDouble(rows[2].split(";")[3])
					+Double.parseDouble(rows[2].split(";")[4])+Double.parseDouble(rows[2].split(";")[5])+Double.parseDouble(rows[2].split(";")[6])
					+Double.parseDouble(rows[2].split(";")[7])+Double.parseDouble(rows[2].split(";")[8])+Double.parseDouble(rows[2].split(";")[9])
					+Double.parseDouble(rows[2].split(";")[10])+Double.parseDouble(rows[2].split(";")[11]);

			double totalOthers = Double.parseDouble(rows[3].split(";")[1])+Double.parseDouble(rows[3].split(";")[2])+Double.parseDouble(rows[3].split(";")[3])
					+Double.parseDouble(rows[3].split(";")[4])+Double.parseDouble(rows[3].split(";")[5])+Double.parseDouble(rows[3].split(";")[6])
					+Double.parseDouble(rows[3].split(";")[7])+Double.parseDouble(rows[3].split(";")[8])+Double.parseDouble(rows[3].split(";")[9])
					+Double.parseDouble(rows[3].split(";")[10])+Double.parseDouble(rows[3].split(";")[11]);

			double totalOp = Double.parseDouble(rows[0].split(";")[16])+Double.parseDouble(rows[1].split(";")[16])+Double.parseDouble(rows[2].split(";")[16])+Double.parseDouble(rows[3].split(";")[16]);


			double totalce = totalTx+totalCs+totalIns+totalOthers;


			double apanzCe = Double.parseDouble(rows[0].split(";")[1])+Double.parseDouble(rows[1].split(";")[1])+Double.parseDouble(rows[2].split(";")[1])+Double.parseDouble(rows[3].split(";")[1]);
			double chinaCe = Double.parseDouble(rows[0].split(";")[2])+Double.parseDouble(rows[1].split(";")[2])+Double.parseDouble(rows[2].split(";")[2])+Double.parseDouble(rows[3].split(";")[2]);
			double europeCe = Double.parseDouble(rows[0].split(";")[3])+Double.parseDouble(rows[1].split(";")[3])+Double.parseDouble(rows[2].split(";")[3])+Double.parseDouble(rows[3].split(";")[3]);
			double indiaCe = Double.parseDouble(rows[0].split(";")[4])+Double.parseDouble(rows[1].split(";")[4])+Double.parseDouble(rows[2].split(";")[4])+Double.parseDouble(rows[3].split(";")[4]);
			double latamCe = Double.parseDouble(rows[0].split(";")[5])+Double.parseDouble(rows[1].split(";")[5])+Double.parseDouble(rows[2].split(";")[5])+Double.parseDouble(rows[3].split(";")[5]);
			double menatCe = Double.parseDouble(rows[0].split(";")[6])+Double.parseDouble(rows[1].split(";")[6])+Double.parseDouble(rows[2].split(";")[6])+Double.parseDouble(rows[3].split(";")[6]);
			double namCe = Double.parseDouble(rows[0].split(";")[7])+Double.parseDouble(rows[1].split(";")[7])+Double.parseDouble(rows[2].split(";")[7])+Double.parseDouble(rows[3].split(";")[7]);
			rcisCe = Double.parseDouble(rows[0].split(";")[8])+Double.parseDouble(rows[1].split(";")[8])+Double.parseDouble(rows[2].split(";")[8])+Double.parseDouble(rows[3].split(";")[8]);
			double ssaCe = Double.parseDouble(rows[0].split(";")[9])+Double.parseDouble(rows[1].split(";")[9])+Double.parseDouble(rows[2].split(";")[9])+Double.parseDouble(rows[3].split(";")[9]);
			double sc = Double.parseDouble(rows[0].split(";")[10])+Double.parseDouble(rows[1].split(";")[10])+Double.parseDouble(rows[2].split(";")[10])+Double.parseDouble(rows[3].split(";")[10]);
			double hqCe = Double.parseDouble(rows[0].split(";")[11])+Double.parseDouble(rows[1].split(";")[11])+Double.parseDouble(rows[2].split(";")[11])+Double.parseDouble(rows[3].split(";")[11]);
			double riskCe = Double.parseDouble(rows[0].split(";")[12])+Double.parseDouble(rows[1].split(";")[12])+Double.parseDouble(rows[2].split(";")[12])+Double.parseDouble(rows[3].split(";")[12]);
			double oppCe = Double.parseDouble(rows[0].split(";")[13])+Double.parseDouble(rows[1].split(";")[13])+Double.parseDouble(rows[2].split(";")[13])+Double.parseDouble(rows[3].split(";")[13]);

			Map<String,Object> ceMap = new LinkedHashMap<>(); //tx+cs+ins+other

			ceMap.put(FMSVariableConstants.HEADER,FMSVariableConstants.CE);
			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				ceMap.put(FMSVariableConstants.APAC, decimalFormat.format(apanzCe));
				ceMap.put(FMSVariableConstants.AMERICAS, decimalFormat.format(chinaCe));
			}else{
				ceMap.put(FMSVariableConstants.APANZ, decimalFormat.format(apanzCe));
				ceMap.put(FMSVariableConstants.CHINA, decimalFormat.format(chinaCe));
			}
			ceMap.put(FMSVariableConstants.EUROPE, decimalFormat.format(europeCe));
			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				ceMap.put(FMSVariableConstants.ATM, decimalFormat.format(indiaCe));
			}else{
				ceMap.put(FMSVariableConstants.INDIA, decimalFormat.format(indiaCe));
			}
			ceMap.put(FMSVariableConstants.LATAM, decimalFormat.format(latamCe));
			ceMap.put(FMSVariableConstants.MENAT, decimalFormat.format(menatCe));

			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				ceMap.put(FMSVariableConstants.NORTHAMERICA, decimalFormat.format(namCe));
				ceMap.put(FMSVariableConstants.MET, decimalFormat.format(rcisCe));
			} else{
				ceMap.put(FMSVariableConstants.NAM, decimalFormat.format(namCe));
				ceMap.put(FMSVariableConstants.RCIS, decimalFormat.format(rcisCe));
			}
			ceMap.put(FMSVariableConstants.SSA, decimalFormat.format(ssaCe));
			ceMap.put(FMSVariableConstants.SC, decimalFormat.format(sc));
			ceMap.put(FMSVariableConstants.HQ, decimalFormat.format(hqCe));
			ceMap.put(FMSVariableConstants.RISK, decimalFormat.format(riskCe));
			ceMap.put(FMSVariableConstants.OPP, decimalFormat.format(oppCe));
			ceMap.put(FMSVariableConstants.TOT, decimalFormat.format(totalce));
			ceMap.put(FMSVariableConstants.GAP, decimalFormat.format(totalOp-totalce));
			ceMap.put(FMSVariableConstants.OP, decimalFormat.format(totalOp));

			Map<String,Object> vpeMap = new LinkedHashMap<>(); //ce-pe
			vpeMap.put(FMSVariableConstants.HEADER,FMSVariableConstants.VPE);
			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				vpeMap.put(FMSVariableConstants.APAC, decimalFormat.format(apanzCe-Double.parseDouble(rows[4].split(";")[1])));
				vpeMap.put(FMSVariableConstants.AMERICAS, decimalFormat.format(chinaCe-Double.parseDouble(rows[4].split(";")[2])));
			}else{
				vpeMap.put(FMSVariableConstants.APANZ, decimalFormat.format(apanzCe-Double.parseDouble(rows[4].split(";")[1])));
				vpeMap.put(FMSVariableConstants.CHINA, decimalFormat.format(chinaCe-Double.parseDouble(rows[4].split(";")[2])));
			}
			vpeMap.put(FMSVariableConstants.EUROPE, decimalFormat.format(europeCe-Double.parseDouble(rows[4].split(";")[3])));
			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				vpeMap.put(FMSVariableConstants.ATM, decimalFormat.format(indiaCe-Double.parseDouble(rows[4].split(";")[4])));
			}else{
				vpeMap.put(FMSVariableConstants.INDIA, decimalFormat.format(indiaCe-Double.parseDouble(rows[4].split(";")[4])));
			}
			vpeMap.put(FMSVariableConstants.LATAM, decimalFormat.format(latamCe-Double.parseDouble(rows[4].split(";")[5])));
			vpeMap.put(FMSVariableConstants.MENAT, decimalFormat.format(menatCe-Double.parseDouble(rows[4].split(";")[6])));

			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				vpeMap.put(FMSVariableConstants.NORTHAMERICA, decimalFormat.format(namCe-Double.parseDouble(rows[4].split(";")[7])));
				vpeMap.put(FMSVariableConstants.MET, decimalFormat.format(rcisCe-Double.parseDouble(rows[4].split(";")[8])));
			} else{
				vpeMap.put(FMSVariableConstants.NAM, decimalFormat.format(namCe-Double.parseDouble(rows[4].split(";")[7])));
				vpeMap.put(FMSVariableConstants.RCIS, decimalFormat.format(rcisCe-Double.parseDouble(rows[4].split(";")[8])));
			}

			vpeMap.put(FMSVariableConstants.SSA, decimalFormat.format(ssaCe-Double.parseDouble(rows[4].split(";")[9])));
			vpeMap.put(FMSVariableConstants.SC, decimalFormat.format(sc-Double.parseDouble(rows[4].split(";")[10])));
			vpeMap.put(FMSVariableConstants.HQ, decimalFormat.format(hqCe-Double.parseDouble(rows[4].split(";")[11])));
			vpeMap.put(FMSVariableConstants.RISK, decimalFormat.format(riskCe-Double.parseDouble(rows[4].split(";")[12])));
			vpeMap.put(FMSVariableConstants.OPP, decimalFormat.format(oppCe-Double.parseDouble(rows[4].split(";")[13])));
			vpeMap.put(FMSVariableConstants.TOT, decimalFormat.format(totalce-Double.parseDouble(rows[4].split(";")[14])));
			vpeMap.put(FMSVariableConstants.GAP, decimalFormat.format(((totalOp-totalce)-Double.parseDouble(rows[4].split(";")[15]))));
			vpeMap.put(FMSVariableConstants.OP, decimalFormat.format(totalOp-Double.parseDouble(rows[4].split(";")[16])));


			Map<String,Object> vopMap = new LinkedHashMap<>(); //ce-op
			vopMap.put(FMSVariableConstants.HEADER,FMSVariableConstants.VOP);
			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				vopMap.put(FMSVariableConstants.APAC, decimalFormat.format(apanzCe-Double.parseDouble(rows[5].split(";")[1])));
				vopMap.put(FMSVariableConstants.AMERICAS, decimalFormat.format(chinaCe-Double.parseDouble(rows[5].split(";")[2])));
			}else{
				vopMap.put(FMSVariableConstants.APANZ, decimalFormat.format(apanzCe-Double.parseDouble(rows[5].split(";")[1])));
				vopMap.put(FMSVariableConstants.CHINA, decimalFormat.format(chinaCe-Double.parseDouble(rows[5].split(";")[2])));
			}
			vopMap.put(FMSVariableConstants.EUROPE, decimalFormat.format(europeCe-Double.parseDouble(rows[5].split(";")[3])));
			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				vopMap.put(FMSVariableConstants.ATM, decimalFormat.format(indiaCe-Double.parseDouble(rows[5].split(";")[4])));
			}else{
				vopMap.put(FMSVariableConstants.INDIA, decimalFormat.format(indiaCe-Double.parseDouble(rows[5].split(";")[4])));
			}
			vopMap.put(FMSVariableConstants.LATAM, decimalFormat.format(latamCe-Double.parseDouble(rows[5].split(";")[5])));
			vopMap.put(FMSVariableConstants.MENAT, decimalFormat.format(menatCe-Double.parseDouble(rows[5].split(";")[6])));

			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				vopMap.put(FMSVariableConstants.NORTHAMERICA, decimalFormat.format(namCe-Double.parseDouble(rows[5].split(";")[7])));
				vopMap.put(FMSVariableConstants.MET, decimalFormat.format(rcisCe-Double.parseDouble(rows[5].split(";")[8])));
			} else{
				vopMap.put(FMSVariableConstants.NAM, decimalFormat.format(namCe-Double.parseDouble(rows[5].split(";")[7])));
				vopMap.put(FMSVariableConstants.RCIS, decimalFormat.format(rcisCe-Double.parseDouble(rows[5].split(";")[8])));
			}

			vopMap.put(FMSVariableConstants.SSA, decimalFormat.format(ssaCe-Double.parseDouble(rows[5].split(";")[9])));
			vopMap.put(FMSVariableConstants.SC, decimalFormat.format(sc-Double.parseDouble(rows[5].split(";")[10])));
			vopMap.put(FMSVariableConstants.HQ, decimalFormat.format(hqCe-Double.parseDouble(rows[5].split(";")[11])));
			vopMap.put(FMSVariableConstants.RISK, decimalFormat.format(0));
			vopMap.put(FMSVariableConstants.OPP, decimalFormat.format(0));
			vopMap.put(FMSVariableConstants.TOT, decimalFormat.format(0));
			vopMap.put(FMSVariableConstants.GAP, decimalFormat.format(0));
			vopMap.put(FMSVariableConstants.OP, decimalFormat.format(totalce-totalOp));


			for(int i=0;i<rows.length;i++){
				String[] row = rows[i].split(";");		

				if(FMSVariableConstants.PE.equalsIgnoreCase(row[0])){
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER,row[0]);
					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.APAC, decimalFormat.format(Double.parseDouble(row[1])));
						map.put(FMSVariableConstants.AMERICAS, decimalFormat.format(Double.parseDouble(row[2])));
					}else{
						map.put(FMSVariableConstants.APANZ, decimalFormat.format(Double.parseDouble(row[1])));
						map.put(FMSVariableConstants.CHINA, decimalFormat.format(Double.parseDouble(row[2])));
					}
					map.put(FMSVariableConstants.EUROPE, decimalFormat.format(Double.parseDouble(row[3])));
					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.ATM, decimalFormat.format(Double.parseDouble(row[4])));
					}else{
						map.put(FMSVariableConstants.INDIA, decimalFormat.format(Double.parseDouble(row[4])));
					}
					map.put(FMSVariableConstants.LATAM, decimalFormat.format(Double.parseDouble(row[5])));
					map.put(FMSVariableConstants.MENAT, decimalFormat.format(Double.parseDouble(row[6])));

					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.NORTHAMERICA, decimalFormat.format(Double.parseDouble(row[7])));
						map.put(FMSVariableConstants.MET, decimalFormat.format(Double.parseDouble(row[8])));
					} else{
						map.put(FMSVariableConstants.NAM, decimalFormat.format(Double.parseDouble(row[7])));
						map.put(FMSVariableConstants.RCIS, decimalFormat.format(Double.parseDouble(row[8])));
					}

					map.put(FMSVariableConstants.SSA, decimalFormat.format(Double.parseDouble(row[9])));
					map.put(FMSVariableConstants.SC, decimalFormat.format(Double.parseDouble(row[10])));
					map.put(FMSVariableConstants.HQ, decimalFormat.format(Double.parseDouble(row[11])));
					map.put(FMSVariableConstants.RISK, decimalFormat.format(Double.parseDouble(row[12])));
					map.put(FMSVariableConstants.OPP, decimalFormat.format(Double.parseDouble(row[13])));
					map.put(FMSVariableConstants.TOT, decimalFormat.format(Double.parseDouble(row[14])));
					map.put(FMSVariableConstants.GAP, decimalFormat.format(Double.parseDouble(row[15])));
					map.put(FMSVariableConstants.OP, decimalFormat.format(Double.parseDouble(row[16])));

					mainTable.add(ceMap);
					mainTable.add(map);

				}else if(FMSVariableConstants.OP.equalsIgnoreCase(row[0])){
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER, row[0]);
					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.APAC, decimalFormat.format(Double.parseDouble(row[1])));
						map.put(FMSVariableConstants.AMERICAS, decimalFormat.format(Double.parseDouble(row[2])));
					}else{
						map.put(FMSVariableConstants.APANZ, decimalFormat.format(Double.parseDouble(row[1])));
						map.put(FMSVariableConstants.CHINA, decimalFormat.format(Double.parseDouble(row[2])));
					}
					map.put(FMSVariableConstants.EUROPE, decimalFormat.format(Double.parseDouble(row[3])));
					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.ATM, decimalFormat.format(Double.parseDouble(row[4])));
					}else{
						map.put(FMSVariableConstants.INDIA, decimalFormat.format(Double.parseDouble(row[4])));
					}
					map.put(FMSVariableConstants.LATAM, decimalFormat.format(Double.parseDouble(row[5])));
					map.put(FMSVariableConstants.MENAT, decimalFormat.format(Double.parseDouble(row[6])));

					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.NORTHAMERICA, decimalFormat.format(Double.parseDouble(row[7])));
						map.put(FMSVariableConstants.MET, decimalFormat.format(Double.parseDouble(row[8])));
					} else{
						map.put(FMSVariableConstants.NAM, decimalFormat.format(Double.parseDouble(row[7])));
						map.put(FMSVariableConstants.RCIS, decimalFormat.format(Double.parseDouble(row[8])));
					}
					map.put(FMSVariableConstants.SSA, decimalFormat.format(Double.parseDouble(row[9])));
					map.put(FMSVariableConstants.SC, decimalFormat.format(Double.parseDouble(row[10])));
					map.put(FMSVariableConstants.HQ, decimalFormat.format(Double.parseDouble(row[11])));
					map.put(FMSVariableConstants.RISK, decimalFormat.format(0));
					map.put(FMSVariableConstants.OPP, decimalFormat.format(0));
					map.put(FMSVariableConstants.TOT, decimalFormat.format(0));
					map.put(FMSVariableConstants.GAP, decimalFormat.format(0));
					map.put(FMSVariableConstants.OP, decimalFormat.format(totalOp));

					mainTable.add(vpeMap);				
					mainTable.add(map);
					mainTable.add(vopMap);				

				}else{
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER, row[0]);
					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.APAC, decimalFormat.format(Double.parseDouble(row[1])));
						map.put(FMSVariableConstants.AMERICAS, decimalFormat.format(Double.parseDouble(row[2])));
					}else{
						map.put(FMSVariableConstants.APANZ, decimalFormat.format(Double.parseDouble(row[1])));
						map.put(FMSVariableConstants.CHINA, decimalFormat.format(Double.parseDouble(row[2])));
					}
					map.put(FMSVariableConstants.EUROPE, decimalFormat.format(Double.parseDouble(row[3])));
					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.ATM, decimalFormat.format(Double.parseDouble(row[4])));
					}else{
						map.put(FMSVariableConstants.INDIA, decimalFormat.format(Double.parseDouble(row[4])));
					}
					map.put(FMSVariableConstants.LATAM, decimalFormat.format(Double.parseDouble(row[5])));
					map.put(FMSVariableConstants.MENAT, decimalFormat.format(Double.parseDouble(row[6])));

					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.NORTHAMERICA, decimalFormat.format(Double.parseDouble(row[7])));
						map.put(FMSVariableConstants.MET, decimalFormat.format(Double.parseDouble(row[8])));
					}else{
						map.put(FMSVariableConstants.NAM, decimalFormat.format(Double.parseDouble(row[7])));
						map.put(FMSVariableConstants.RCIS, decimalFormat.format(Double.parseDouble(row[8])));
					}

					map.put(FMSVariableConstants.SSA, decimalFormat.format(Double.parseDouble(row[9])));
					map.put(FMSVariableConstants.SC, decimalFormat.format(Double.parseDouble(row[10])));
					map.put(FMSVariableConstants.HQ, decimalFormat.format(Double.parseDouble(row[11])));
					map.put(FMSVariableConstants.RISK, decimalFormat.format(Double.parseDouble(row[12])));
					map.put(FMSVariableConstants.OPP, decimalFormat.format(Double.parseDouble(row[13])));
					if(FMSVariableConstants.TX.equalsIgnoreCase(row[0])||FMSVariableConstants.CS.equalsIgnoreCase(row[0])||FMSVariableConstants.INS.equalsIgnoreCase(row[0])){
						Double tot = Double.parseDouble(row[1])+Double.parseDouble(row[2])+Double.parseDouble(row[3])+Double.parseDouble(row[4])
								+Double.parseDouble(row[5])+Double.parseDouble(row[6])+Double.parseDouble(row[7])+Double.parseDouble(row[8])
								+Double.parseDouble(row[9])+Double.parseDouble(row[10])+Double.parseDouble(row[11]);
						map.put(FMSVariableConstants.TOT, decimalFormat.format(tot));
						map.put(FMSVariableConstants.GAP, decimalFormat.format(Double.parseDouble(row[16])-tot));
						map.put(FMSVariableConstants.OP, decimalFormat.format(Double.parseDouble(row[16])));
					}else{
						map.put(FMSVariableConstants.TOT,decimalFormat.format(Double.parseDouble(row[10])));
						map.put(FMSVariableConstants.GAP, decimalFormat.format(Double.parseDouble(row[16])-Double.parseDouble(row[10])));
						map.put(FMSVariableConstants.OP, decimalFormat.format(Double.parseDouble(row[16])));
					}

					mainTable.add(map);
				}
			}



			//Walk By Region Chart
			String chart = tableChart[1];
			String[] chartRows =chart.split("~");
			List<Map<String,Object>> chartMain = new ArrayList<>();
			Map<String,Object> chartMap = new HashMap<>();

			for(int k=0;k<chartRows.length;k++){
				List<Float> fldata = new ArrayList<>();
				String[] initialData = chartRows[k].split(";");
				for(int p=0;p<initialData.length;p++){
					fldata.add(Float.parseFloat(initialData[p]));
				}

				chartMap.put(FMSVariableConstants.ROW+k,fldata);
			}
			for(String key : chartMap.keySet()){

				if(FMSVariableConstants.ROW0.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, FMSVariableConstants.OPP);
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW0));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, "#D9D9D9");
					chartRow.put(FMSVariableConstants.ID, 1);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW1.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, FMSVariableConstants.RISK);
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW1));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR1);
					chartRow.put(FMSVariableConstants.ID, 2);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW2.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, FMSVariableConstants.HQ);
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW2));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, "#FFC000");
					chartRow.put(FMSVariableConstants.ID, 3);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW3.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, FMSVariableConstants.INST);
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW3));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, "#5B9BD5");
					chartRow.put(FMSVariableConstants.ID, 4);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW4.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, FMSVariableConstants.CS);
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW4));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, "#92D050");
					chartRow.put(FMSVariableConstants.ID, 5);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW5.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, FMSVariableConstants.TX);
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW5));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, "#ED7D31");
					chartRow.put(FMSVariableConstants.ID, 6);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW6.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, "TOTAL");
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW6));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR3);
					chartRow.put(FMSVariableConstants.ID, 7);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW7.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, FMSVariableConstants.GAP);
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW7));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR1);
					chartRow.put(FMSVariableConstants.ID, 8);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW8.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, FMSVariableConstants.OTHER);
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW8));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, true);
					chartRow.put(FMSVariableConstants.COLOR, "#FAA460");
					chartRow.put(FMSVariableConstants.ID, 9);
					chartMain.add(chartRow);
				}else if(FMSVariableConstants.ROW9.equalsIgnoreCase(key)){
					Map<String,Object> chartRow = new LinkedHashMap<>();
					chartRow.put(FMSVariableConstants.NAME, FMSVariableConstants.BLANK);
					chartRow.put(FMSVariableConstants.DATA, chartMap.get(FMSVariableConstants.ROW9));
					chartRow.put(FMSVariableConstants.SHOWINLEGEND, false);
					chartRow.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR4);
					chartRow.put(FMSVariableConstants.ID, 10);
					chartMain.add(chartRow);
				}
			}

			completeData.put(FMSVariableConstants.TABLE, mainTable);
			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				completeData.put(FMSVariableConstants.TABLEHEADERS, new String[]{FMSVariableConstants.APAC,FMSVariableConstants.AMERICAS,FMSVariableConstants.EUROPE,FMSVariableConstants.ATM,FMSVariableConstants.LATAM,FMSVariableConstants.MENAT,FMSVariableConstants.NORTHAMERICA,FMSVariableConstants.MET,FMSVariableConstants.SSA,FMSVariableConstants.SC,FMSVariableConstants.HQ,FMSVariableConstants.RISK,FMSVariableConstants.OPP,FMSVariableConstants.TOT,FMSVariableConstants.GAP,FMSVariableConstants.OP});
			}else{
				completeData.put(FMSVariableConstants.TABLEHEADERS, new String[]{FMSVariableConstants.APANZ,FMSVariableConstants.CHINA,FMSVariableConstants.EUROPE,FMSVariableConstants.INDIA,FMSVariableConstants.LATAM,FMSVariableConstants.MENAT,FMSVariableConstants.NAM,FMSVariableConstants.RCIS,FMSVariableConstants.SSA,FMSVariableConstants.SC,FMSVariableConstants.HQ,FMSVariableConstants.RISK,FMSVariableConstants.OPP,FMSVariableConstants.TOT,FMSVariableConstants.GAP,FMSVariableConstants.OP});
			}
			completeData.put(FMSVariableConstants.CHART, chartMain);
		}
		return completeData;

	}

	@Override
	public String updateIPMLogicFields() {	
		java.util.Date serviceendtime = new java.util.Date();
		log.info("Conversion Started:" + serviceendtime);
		jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.IN_PROGRESS,"Conversion Started:" + serviceendtime,"updateIPMLogicFields"});
		String response="";
		try {
			response = jdbc.queryForObject(FMSQueryConstants.UPDATE_IPM_LOGIC_FIELDS,new Object[]{}, String.class);
			String dailyUpdate = jdbc.queryForObject(FMSQueryConstants.UPDATE_IPM_DATA_ENTRY_DAILY_UPDATE,new Object[]{}, String.class);
			String weeklyRetention = jdbc.queryForObject(FMSQueryConstants.UPDATE_IPM_WEEK_RETENTION,new Object[]{}, String.class);
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.IN_PROGRESS,FMSVariableConstants.CONVERSION.concat(response).concat(FMSVariableConstants.DAILY_UPDATE).concat(dailyUpdate).concat(FMSVariableConstants.RETENTION).concat(weeklyRetention),"updateIPMLogicFields~DB Functions"});
		} catch (Exception e) {
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"updateIPMLogicFields~QueryError"});
			response = FMSVariableConstants.FAILURE;
			log.info(e);
		}
		java.util.Date conversionEndime = new java.util.Date();
		jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Conversion End:" + conversionEndime,"updateIPMLogicFields"});
		log.info("Conversion End:" + conversionEndime);
		return response;
	}

	@Override
	public Map<String, Object> projectController(Map<String, Object> filterData) {
		String data = "";
		String mapHeader = "";
		Object[] params = new Object[13];
		params[0] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
		params[1] = Utils.getValidation(filterData.get(FMSVariableConstants.PANDL));
		params[2] = Utils.getValidation(filterData.get(FMSVariableConstants.PRODUCT));
		params[3] = Utils.getValidation(filterData.get(FMSVariableConstants.OUNAME));
		params[4] = Utils.getValidation(filterData.get(FMSVariableConstants.OGREGION));
		params[5] = Utils.getValidation(filterData.get(FMSVariableConstants.REGION));
		params[6] = Utils.getValidation(filterData.get(FMSVariableConstants.SUBREGION));
		params[7] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCOUNTRYDISC));
		params[8] = Utils.getValidation(filterData.get(FMSVariableConstants.MOTHERJOB));
		params[9] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCUSTNAME));
		params[10] =Utils.getValidation(filterData.get(FMSVariableConstants.COSTINGPROJECT));
		params[11] =Utils.getValidation(filterData.get(FMSVariableConstants.ORDERTYPE));
		params[12] =Utils.getValidation(filterData.get(FMSVariableConstants.WEEK));

		if(((String) filterData.get(FMSVariableConstants.PANDL)).equalsIgnoreCase(FMSVariableConstants.TX)){
			mapHeader = FMSVariableConstants.TX;
		}else if(((String) filterData.get(FMSVariableConstants.PANDL)).equalsIgnoreCase(FMSVariableConstants.CS)){
			mapHeader = FMSVariableConstants.CS;
		}else if(((String) filterData.get(FMSVariableConstants.PANDL)).equalsIgnoreCase(FMSVariableConstants.INST)){
			mapHeader = FMSVariableConstants.INST;
		}
		try{
			data = jdbc.queryForObject(FMSQueryConstants.PROJECT_CONTROLLER,params,String.class);
		} catch(Exception e){
			log.info(FMSVariableConstants.ERRORMESSAGE+e.getMessage());
		}
		Map<String,Object> completeData = new LinkedHashMap<>();

		String[] first = data.split("\\(");
		String[] second = first[1].split("\\)");

		if(FMSVariableConstants.DBERROR.equalsIgnoreCase(second[0].split(",")[0])){
			completeData.put(FMSVariableConstants.ERROR, FMSVariableConstants.ERRORMESSAGE);
		}else{
			String[] tableChart = second[0].split(",");
			//Project controller table
			String table = tableChart[0];
			List<Map<String,Object>> mainTable = new ArrayList<>();
			String[] rows =table.split("~");

			double ceTot = Double.parseDouble(rows[0].split(";")[1])+Double.parseDouble(rows[0].split(";")[2])+Double.parseDouble(rows[0].split(";")[3])
					+Double.parseDouble(rows[0].split(";")[4])+Double.parseDouble(rows[0].split(";")[5])+Double.parseDouble(rows[0].split(";")[6])
					+Double.parseDouble(rows[0].split(";")[7])+Double.parseDouble(rows[0].split(";")[8])+Double.parseDouble(rows[0].split(";")[9])
					+Double.parseDouble(rows[0].split(";")[10]);
			double peTot = Double.parseDouble(rows[1].split(";")[1])+Double.parseDouble(rows[1].split(";")[2])+Double.parseDouble(rows[1].split(";")[3])
					+Double.parseDouble(rows[1].split(";")[4])+Double.parseDouble(rows[1].split(";")[5])+Double.parseDouble(rows[1].split(";")[6])
					+Double.parseDouble(rows[1].split(";")[7])+Double.parseDouble(rows[1].split(";")[8])+Double.parseDouble(rows[1].split(";")[9])
					+Double.parseDouble(rows[1].split(";")[10]);
			double op =Double.parseDouble(rows[2].split(";")[1])+Double.parseDouble(rows[2].split(";")[2])+Double.parseDouble(rows[2].split(";")[3])
					+Double.parseDouble(rows[2].split(";")[4])+Double.parseDouble(rows[2].split(";")[5])+Double.parseDouble(rows[2].split(";")[6])
					+Double.parseDouble(rows[2].split(";")[7])+Double.parseDouble(rows[2].split(";")[8])+Double.parseDouble(rows[2].split(";")[9])
					+Double.parseDouble(rows[2].split(";")[10]);

			Map<String,Object> vpeMap = new LinkedHashMap<>(); //ce-pe
			vpeMap.put(FMSVariableConstants.HEADER,FMSVariableConstants.VPE);

			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				vpeMap.put(FMSVariableConstants.APAC, decimalFormat.format((Double.parseDouble(rows[0].split(";")[1]))-Double.parseDouble(rows[1].split(";")[1])));
				vpeMap.put(FMSVariableConstants.AMERICAS, decimalFormat.format((Double.parseDouble(rows[0].split(";")[2]))-Double.parseDouble(rows[1].split(";")[2])));
			} else{
				vpeMap.put(FMSVariableConstants.APANZ, decimalFormat.format((Double.parseDouble(rows[0].split(";")[1]))-Double.parseDouble(rows[1].split(";")[1])));
				vpeMap.put(FMSVariableConstants.CHINA, decimalFormat.format((Double.parseDouble(rows[0].split(";")[2]))-Double.parseDouble(rows[1].split(";")[2])));	
			}

			vpeMap.put(FMSVariableConstants.EUROPE, decimalFormat.format((Double.parseDouble(rows[0].split(";")[3]))-Double.parseDouble(rows[1].split(";")[3])));
			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				vpeMap.put(FMSVariableConstants.ATM, decimalFormat.format((Double.parseDouble(rows[0].split(";")[4]))-Double.parseDouble(rows[1].split(";")[4])));
			}else{
				vpeMap.put(FMSVariableConstants.INDIA, decimalFormat.format((Double.parseDouble(rows[0].split(";")[4]))-Double.parseDouble(rows[1].split(";")[4])));
			}
			vpeMap.put(FMSVariableConstants.LATAM, decimalFormat.format((Double.parseDouble(rows[0].split(";")[5]))-Double.parseDouble(rows[1].split(";")[5])));
			vpeMap.put(FMSVariableConstants.MENAT, decimalFormat.format((Double.parseDouble(rows[0].split(";")[6]))-Double.parseDouble(rows[1].split(";")[6])));

			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				vpeMap.put(FMSVariableConstants.NORTHAMERICA, decimalFormat.format((Double.parseDouble(rows[0].split(";")[7]))-Double.parseDouble(rows[1].split(";")[7])));
				vpeMap.put(FMSVariableConstants.MET, decimalFormat.format((Double.parseDouble(rows[0].split(";")[8]))-Double.parseDouble(rows[1].split(";")[8])));
			}else{
				vpeMap.put(FMSVariableConstants.NAM, decimalFormat.format((Double.parseDouble(rows[0].split(";")[7]))-Double.parseDouble(rows[1].split(";")[7])));
				vpeMap.put(FMSVariableConstants.RCIS, decimalFormat.format((Double.parseDouble(rows[0].split(";")[8]))-Double.parseDouble(rows[1].split(";")[8])));
			}

			vpeMap.put(FMSVariableConstants.SSA, decimalFormat.format((Double.parseDouble(rows[0].split(";")[9]))-Double.parseDouble(rows[1].split(";")[9])));
			vpeMap.put(FMSVariableConstants.HQ, decimalFormat.format((Double.parseDouble(rows[0].split(";")[10]))-Double.parseDouble(rows[1].split(";")[10])));
			vpeMap.put(FMSVariableConstants.RISK, decimalFormat.format((Double.parseDouble(rows[0].split(";")[11]))-Double.parseDouble(rows[1].split(";")[11])));
			vpeMap.put(FMSVariableConstants.OPP, decimalFormat.format((Double.parseDouble(rows[0].split(";")[12]))-Double.parseDouble(rows[1].split(";")[12])));
			vpeMap.put(FMSVariableConstants.TOT, decimalFormat.format(ceTot-peTot));
			vpeMap.put(FMSVariableConstants.OP,decimalFormat.format(0));

			Map<String,Object> vopMap = new LinkedHashMap<>(); //ce-op
			vopMap.put(FMSVariableConstants.HEADER,FMSVariableConstants.VOP);
			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				vopMap.put(FMSVariableConstants.APAC, decimalFormat.format((Double.parseDouble(rows[0].split(";")[1]))-Double.parseDouble(rows[2].split(";")[1])));
				vopMap.put(FMSVariableConstants.AMERICAS, decimalFormat.format((Double.parseDouble(rows[0].split(";")[2]))-Double.parseDouble(rows[2].split(";")[2])));
			}else{
				vopMap.put(FMSVariableConstants.APANZ, decimalFormat.format((Double.parseDouble(rows[0].split(";")[1]))-Double.parseDouble(rows[2].split(";")[1])));
				vopMap.put(FMSVariableConstants.CHINA, decimalFormat.format((Double.parseDouble(rows[0].split(";")[2]))-Double.parseDouble(rows[2].split(";")[2])));
			}
			vopMap.put(FMSVariableConstants.EUROPE,decimalFormat.format( (Double.parseDouble(rows[0].split(";")[3]))-Double.parseDouble(rows[2].split(";")[3])));
			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				vopMap.put(FMSVariableConstants.ATM, decimalFormat.format((Double.parseDouble(rows[0].split(";")[4]))-Double.parseDouble(rows[2].split(";")[4])));
			}else{
				vopMap.put(FMSVariableConstants.INDIA, decimalFormat.format((Double.parseDouble(rows[0].split(";")[4]))-Double.parseDouble(rows[2].split(";")[4])));
			}
			vopMap.put(FMSVariableConstants.LATAM, decimalFormat.format((Double.parseDouble(rows[0].split(";")[5]))-Double.parseDouble(rows[2].split(";")[5])));
			vopMap.put(FMSVariableConstants.MENAT, decimalFormat.format((Double.parseDouble(rows[0].split(";")[6]))-Double.parseDouble(rows[2].split(";")[6])));


			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				vopMap.put(FMSVariableConstants.NORTHAMERICA, decimalFormat.format((Double.parseDouble(rows[0].split(";")[7]))-Double.parseDouble(rows[2].split(";")[7])));
				vopMap.put(FMSVariableConstants.MET, decimalFormat.format((Double.parseDouble(rows[0].split(";")[8]))-Double.parseDouble(rows[2].split(";")[8])));
			}else{
				vopMap.put(FMSVariableConstants.NAM, decimalFormat.format((Double.parseDouble(rows[0].split(";")[7]))-Double.parseDouble(rows[2].split(";")[7])));
				vopMap.put(FMSVariableConstants.RCIS, decimalFormat.format((Double.parseDouble(rows[0].split(";")[8]))-Double.parseDouble(rows[2].split(";")[8])));
			}
			vopMap.put(FMSVariableConstants.SSA, decimalFormat.format((Double.parseDouble(rows[0].split(";")[9]))-Double.parseDouble(rows[2].split(";")[9])));
			vopMap.put(FMSVariableConstants.HQ, decimalFormat.format((Double.parseDouble(rows[0].split(";")[10]))-Double.parseDouble(rows[2].split(";")[10])));
			vopMap.put(FMSVariableConstants.RISK,decimalFormat.format( 0));
			vopMap.put(FMSVariableConstants.OPP, decimalFormat.format(0));
			vopMap.put(FMSVariableConstants.TOT, decimalFormat.format(0));
			vopMap.put(FMSVariableConstants.OP,decimalFormat.format(op-ceTot));


			for(int i=0;i<rows.length;i++){
				String[] row = rows[i].split(";");		

				if(FMSVariableConstants.CE.equalsIgnoreCase(row[0])){
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER, row[0]);
					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.APAC, decimalFormat.format(Double.parseDouble(row[1])));
						map.put(FMSVariableConstants.AMERICAS, decimalFormat.format(Double.parseDouble(row[2])));
					}else{
						map.put(FMSVariableConstants.APANZ, decimalFormat.format(Double.parseDouble(row[1])));
						map.put(FMSVariableConstants.CHINA, decimalFormat.format(Double.parseDouble(row[2])));
					}
					map.put(FMSVariableConstants.EUROPE, decimalFormat.format(Double.parseDouble(row[3])));
					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.ATM, decimalFormat.format(Double.parseDouble(row[4])));
					}else{
						map.put(FMSVariableConstants.INDIA, decimalFormat.format(Double.parseDouble(row[4])));
					}
					map.put(FMSVariableConstants.LATAM, decimalFormat.format(Double.parseDouble(row[5])));
					map.put(FMSVariableConstants.MENAT,decimalFormat.format( Double.parseDouble(row[6])));

					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.NORTHAMERICA, decimalFormat.format(Double.parseDouble(row[7])));
						map.put(FMSVariableConstants.MET, decimalFormat.format(Double.parseDouble(row[8])));
					}else{
						map.put(FMSVariableConstants.NAM, decimalFormat.format(Double.parseDouble(row[7])));
						map.put(FMSVariableConstants.RCIS, decimalFormat.format(Double.parseDouble(row[8])));
					}

					map.put(FMSVariableConstants.SSA, decimalFormat.format(Double.parseDouble(row[9])));
					map.put(FMSVariableConstants.HQ, decimalFormat.format(Double.parseDouble(row[10])));
					map.put(FMSVariableConstants.RISK, decimalFormat.format(Double.parseDouble(row[11])));
					map.put(FMSVariableConstants.OPP, decimalFormat.format(Double.parseDouble(row[12])));
					map.put(FMSVariableConstants.TOT, decimalFormat.format(ceTot));
					map.put(FMSVariableConstants.OP, decimalFormat.format(0));
					mainTable.add(map);
				}else if(FMSVariableConstants.PE.equalsIgnoreCase(row[0])){
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER, row[0]);
					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.APAC, decimalFormat.format(Double.parseDouble(row[1])));
						map.put(FMSVariableConstants.AMERICAS, decimalFormat.format(Double.parseDouble(row[2])));
					}else{
						map.put(FMSVariableConstants.APANZ, decimalFormat.format(Double.parseDouble(row[1])));
						map.put(FMSVariableConstants.CHINA, decimalFormat.format(Double.parseDouble(row[2])));
					}
					map.put(FMSVariableConstants.EUROPE, decimalFormat.format(Double.parseDouble(row[3])));
					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.ATM, decimalFormat.format(Double.parseDouble(row[4])));
					}else{
						map.put(FMSVariableConstants.INDIA, decimalFormat.format(Double.parseDouble(row[4])));
					}
					map.put(FMSVariableConstants.LATAM, decimalFormat.format(Double.parseDouble(row[5])));
					map.put(FMSVariableConstants.MENAT, decimalFormat.format(Double.parseDouble(row[6])));


					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.NORTHAMERICA, decimalFormat.format(Double.parseDouble(row[7])));
						map.put(FMSVariableConstants.MET, decimalFormat.format(Double.parseDouble(row[8])));
					}else {
						map.put(FMSVariableConstants.NAM, decimalFormat.format(Double.parseDouble(row[7])));
						map.put(FMSVariableConstants.RCIS, decimalFormat.format(Double.parseDouble(row[8])));
					}

					map.put(FMSVariableConstants.SSA, decimalFormat.format(Double.parseDouble(row[9])));
					map.put(FMSVariableConstants.HQ, decimalFormat.format(Double.parseDouble(row[10])));
					map.put(FMSVariableConstants.RISK, decimalFormat.format(Double.parseDouble(row[11])));
					map.put(FMSVariableConstants.OPP, decimalFormat.format(Double.parseDouble(row[12])));
					map.put(FMSVariableConstants.TOT,decimalFormat.format( peTot));
					map.put(FMSVariableConstants.OP, decimalFormat.format(0));
					mainTable.add(map);
					mainTable.add(vpeMap);
				}else if(FMSVariableConstants.OP.equalsIgnoreCase(row[0])){
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER, row[0]);
					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.APAC, decimalFormat.format(Double.parseDouble(row[1])));
						map.put(FMSVariableConstants.AMERICAS, decimalFormat.format(Double.parseDouble(row[2])));
					} else{
						map.put(FMSVariableConstants.APANZ, decimalFormat.format(Double.parseDouble(row[1])));
						map.put(FMSVariableConstants.CHINA, decimalFormat.format(Double.parseDouble(row[2])));
					}
					map.put(FMSVariableConstants.EUROPE, decimalFormat.format(Double.parseDouble(row[3])));
					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.ATM, decimalFormat.format(Double.parseDouble(row[4])));
					}else{
						map.put(FMSVariableConstants.INDIA, decimalFormat.format(Double.parseDouble(row[4])));
					}
					map.put(FMSVariableConstants.LATAM, decimalFormat.format(Double.parseDouble(row[5])));
					map.put(FMSVariableConstants.MENAT, decimalFormat.format(Double.parseDouble(row[6])));

					if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
						map.put(FMSVariableConstants.NORTHAMERICA, decimalFormat.format(Double.parseDouble(row[7])));
						map.put(FMSVariableConstants.MET, decimalFormat.format(Double.parseDouble(row[8])));
					}else{
						map.put(FMSVariableConstants.NAM, decimalFormat.format(Double.parseDouble(row[7])));
						map.put(FMSVariableConstants.RCIS, decimalFormat.format(Double.parseDouble(row[8])));
					}

					map.put(FMSVariableConstants.SSA, decimalFormat.format(Double.parseDouble(row[9])));
					map.put(FMSVariableConstants.HQ, decimalFormat.format(Double.parseDouble(row[10])));
					map.put(FMSVariableConstants.RISK, decimalFormat.format(0));
					map.put(FMSVariableConstants.OPP, decimalFormat.format(0));
					map.put(FMSVariableConstants.TOT,decimalFormat.format(0));
					map.put(FMSVariableConstants.OP, decimalFormat.format(op));
					mainTable.add(map);
					mainTable.add(vopMap);
				}


			}

			//Project Controller Chart
			String chart = tableChart[1];
			String[] chartRows =chart.split("~");

			String[] blankRows =chartRows[0].split(";");
			List<Float> blankValues = new ArrayList<>();

			for(int i=0;i<blankRows.length;i++){
				blankValues.add(Float.parseFloat(blankRows[i]));
			}

			String[] chartValues =chartRows[1].split(";");
			List<Float> txValues = new ArrayList<>();
			List<Float> hqValues = new ArrayList<>();
			List<Float> riskValues = new ArrayList<>();
			List<Float> oppValues = new ArrayList<>();
			List<Float> totValues = new ArrayList<>();
			List<Float> opValues = new ArrayList<>();

			for(int i=0;i<9;i++){
				txValues.add(Float.parseFloat(chartValues[i]));
				hqValues.add((float) 0);
				riskValues.add((float) 0);
				oppValues.add((float) 0);
				totValues.add((float) 0);
				opValues.add((float) 0);
			}


			hqValues.add(Float.parseFloat(chartValues[9]));
			riskValues.add((float) 0);
			oppValues.add((float) 0);
			totValues.add((float) 0);
			opValues.add((float) 0);
			txValues.add((float) 0);

			riskValues.add(Float.parseFloat(chartValues[10]));
			hqValues.add((float) 0);
			oppValues.add((float) 0);
			totValues.add((float) 0);
			opValues.add((float) 0);
			txValues.add((float) 0);

			oppValues.add(Float.parseFloat(chartValues[11]));
			hqValues.add((float) 0);
			riskValues.add((float) 0);
			totValues.add((float) 0);
			opValues.add((float) 0);
			txValues.add((float) 0);

			totValues.add((float) ceTot);
			hqValues.add((float) 0);
			riskValues.add((float) 0);
			oppValues.add((float) 0);
			opValues.add((float) 0);
			txValues.add((float) 0);

			opValues.add((float) op);
			hqValues.add((float) 0);
			riskValues.add((float) 0);
			oppValues.add((float) 0);
			totValues.add((float) 0);
			txValues.add((float) 0);

			List<Map<String,Object>> chartMain = new ArrayList<>();

			Map<String,Object> chartRowTX = new LinkedHashMap<>();
			chartRowTX.put(FMSVariableConstants.NAME, mapHeader);
			chartRowTX.put(FMSVariableConstants.DATA, txValues);
			chartRowTX.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowTX.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR2);
			chartRowTX.put(FMSVariableConstants.ID, 1);
			chartMain.add(chartRowTX);

			Map<String,Object> chartRowHQ = new LinkedHashMap<>();
			chartRowHQ.put(FMSVariableConstants.NAME, FMSVariableConstants.HQ);
			chartRowHQ.put(FMSVariableConstants.DATA, hqValues);
			chartRowHQ.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowHQ.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR1);
			chartRowHQ.put(FMSVariableConstants.ID, 2);
			chartMain.add(chartRowHQ);

			Map<String,Object> chartRowRISK = new LinkedHashMap<>();
			chartRowRISK.put(FMSVariableConstants.NAME, FMSVariableConstants.RISK);
			chartRowRISK.put(FMSVariableConstants.DATA, riskValues);
			chartRowRISK.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowRISK.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR1);
			chartRowRISK.put(FMSVariableConstants.ID, 3);
			chartMain.add(chartRowRISK);

			Map<String,Object> chartRowOPP = new LinkedHashMap<>();
			chartRowOPP.put(FMSVariableConstants.NAME, FMSVariableConstants.OPP);
			chartRowOPP.put(FMSVariableConstants.DATA, oppValues);
			chartRowOPP.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowOPP.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR2);
			chartRowOPP.put(FMSVariableConstants.ID, 4);
			chartMain.add(chartRowOPP);

			Map<String,Object> chartRowTOT = new LinkedHashMap<>();
			chartRowTOT.put(FMSVariableConstants.NAME, FMSVariableConstants.TOT);
			chartRowTOT.put(FMSVariableConstants.DATA, totValues);
			chartRowTOT.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowTOT.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR2);	
			chartRowTOT.put(FMSVariableConstants.ID, 5);
			chartMain.add(chartRowTOT);

			Map<String,Object> chartRowOP = new LinkedHashMap<>();
			chartRowOP.put(FMSVariableConstants.NAME, FMSVariableConstants.OP);
			chartRowOP.put(FMSVariableConstants.DATA, opValues);
			chartRowOP.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowOP.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR3);
			chartRowOP.put(FMSVariableConstants.ID, 6);
			chartMain.add(chartRowOP);

			Map<String,Object> chartRowBLANK = new LinkedHashMap<>();
			chartRowBLANK.put(FMSVariableConstants.NAME, FMSVariableConstants.BLANK);
			chartRowBLANK.put(FMSVariableConstants.DATA, blankValues);
			chartRowBLANK.put(FMSVariableConstants.SHOWINLEGEND, false);
			chartRowBLANK.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR4);
			chartRowBLANK.put(FMSVariableConstants.ID, 7);
			chartMain.add(chartRowBLANK);

			completeData.put(FMSVariableConstants.TABLE, mainTable);
			if(params[0].equals(FMSVariableConstants.TMS) ||params[0]==FMSVariableConstants.TMS){
				completeData.put(FMSVariableConstants.TABLEHEADERS, new String[]{FMSVariableConstants.APAC,FMSVariableConstants.AMERICAS,FMSVariableConstants.EUROPE,FMSVariableConstants.ATM,FMSVariableConstants.LATAM,FMSVariableConstants.MENAT,FMSVariableConstants.NORTHAMERICA,FMSVariableConstants.MET,FMSVariableConstants.SSA,FMSVariableConstants.HQ,FMSVariableConstants.RISK,FMSVariableConstants.OPP,FMSVariableConstants.TOT,FMSVariableConstants.OP});
			}else{
				completeData.put(FMSVariableConstants.TABLEHEADERS, new String[]{FMSVariableConstants.APANZ,FMSVariableConstants.CHINA,FMSVariableConstants.EUROPE,FMSVariableConstants.INDIA,FMSVariableConstants.LATAM,FMSVariableConstants.MENAT,FMSVariableConstants.NAM,FMSVariableConstants.RCIS,FMSVariableConstants.SSA,FMSVariableConstants.HQ,FMSVariableConstants.RISK,FMSVariableConstants.OPP,FMSVariableConstants.TOT,FMSVariableConstants.OP});
			}
			completeData.put(FMSVariableConstants.CHART, chartMain);
			completeData.put(FMSVariableConstants.ACTUAL, Double.parseDouble(decimalFormat.format(Double.parseDouble(tableChart[2]))));
			completeData.put(FMSVariableConstants.UNCONFIRMED, Double.parseDouble(decimalFormat.format(Double.parseDouble(tableChart[3]))));
		}
		return completeData;
	}

	@Override
	public Map<String, Object> walkByProduct(Map<String, Object> filterData) {
		String data = "";
		String mapHeader = "";
		Object[] params = new Object[13];
		params[0] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
		params[1] = Utils.getValidation(filterData.get(FMSVariableConstants.PANDL));
		params[2] = Utils.getValidation(filterData.get(FMSVariableConstants.PRODUCT));
		params[3] = Utils.getValidation(filterData.get(FMSVariableConstants.OUNAME));
		params[4] = Utils.getValidation(filterData.get(FMSVariableConstants.OGREGION));
		params[5] = Utils.getValidation(filterData.get(FMSVariableConstants.REGION));
		params[6] = Utils.getValidation(filterData.get(FMSVariableConstants.SUBREGION));
		params[7] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCOUNTRYDISC));
		params[8] = Utils.getValidation(filterData.get(FMSVariableConstants.MOTHERJOB));
		params[9] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCUSTNAME));
		params[10] =Utils.getValidation(filterData.get(FMSVariableConstants.COSTINGPROJECT));
		params[11] =Utils.getValidation(filterData.get(FMSVariableConstants.ORDERTYPE));
		params[12] =Utils.getValidation(filterData.get(FMSVariableConstants.WEEK));
		try{
			data = jdbc.queryForObject(FMSQueryConstants.WALK_BY_PRODUCT,params,String.class);
		} catch(Exception e){
			log.info(FMSVariableConstants.ERRORMESSAGE+e.getMessage());
		}
		Map<String,Object> completeData = new LinkedHashMap<>();

		if(((String) filterData.get(FMSVariableConstants.PANDL)).equalsIgnoreCase(FMSVariableConstants.TX)){
			mapHeader = FMSVariableConstants.TX;
		}else if(((String) filterData.get(FMSVariableConstants.PANDL)).equalsIgnoreCase(FMSVariableConstants.CS)){
			mapHeader = FMSVariableConstants.CS;
		}else if(((String) filterData.get(FMSVariableConstants.PANDL)).equalsIgnoreCase(FMSVariableConstants.INST)){
			mapHeader = FMSVariableConstants.INST;
		}

		String[] first = data.split("\\(");
		String[] second = first[1].split("\\)");

		if(FMSVariableConstants.DBERROR.equalsIgnoreCase(second[0].split(",")[0])){
			completeData.put(FMSVariableConstants.ERROR,  FMSVariableConstants.ERRORMESSAGE);
		}else{
			String[] tableChart = second[0].split(",");
			//Walk by product table
			String table = tableChart[0];
			List<Map<String,Object>> mainTable = new ArrayList<>();
			String[] rows =table.split("~");

			double ceTot = Double.parseDouble(rows[0].split(";")[1])+Double.parseDouble(rows[0].split(";")[2])+Double.parseDouble(rows[0].split(";")[3])
					+Double.parseDouble(rows[0].split(";")[4])+Double.parseDouble(rows[0].split(";")[5])+Double.parseDouble(rows[0].split(";")[6])
					+Double.parseDouble(rows[0].split(";")[7])+Double.parseDouble(rows[0].split(";")[8])+Double.parseDouble(rows[0].split(";")[9]);

			double peTot = Double.parseDouble(rows[1].split(";")[1])+Double.parseDouble(rows[1].split(";")[2])+Double.parseDouble(rows[1].split(";")[3])
					+Double.parseDouble(rows[1].split(";")[4])+Double.parseDouble(rows[1].split(";")[5])+Double.parseDouble(rows[1].split(";")[6])
					+Double.parseDouble(rows[1].split(";")[7])+Double.parseDouble(rows[1].split(";")[8])+Double.parseDouble(rows[1].split(";")[9]);

			double backlogTot =Double.parseDouble(rows[2].split(";")[1])+Double.parseDouble(rows[2].split(";")[2])+Double.parseDouble(rows[2].split(";")[3])
					+Double.parseDouble(rows[2].split(";")[4])+Double.parseDouble(rows[2].split(";")[5])+Double.parseDouble(rows[2].split(";")[6])
					+Double.parseDouble(rows[2].split(";")[7])+Double.parseDouble(rows[2].split(";")[8])+Double.parseDouble(rows[2].split(";")[9]);

			Map<String,Object> vpeMap = new LinkedHashMap<>(); //ce-pe
			vpeMap.put(FMSVariableConstants.HEADER,FMSVariableConstants.VPE);
			vpeMap.put(FMSVariableConstants.PART, decimalFormat.format((Double.parseDouble(rows[0].split(";")[1]))-Double.parseDouble(rows[1].split(";")[1])));
			vpeMap.put(FMSVariableConstants.FIELDSERVICES, decimalFormat.format((Double.parseDouble(rows[0].split(";")[2]))-Double.parseDouble(rows[1].split(";")[2])));
			vpeMap.put(FMSVariableConstants.REPAIR, decimalFormat.format((Double.parseDouble(rows[0].split(";")[3]))-Double.parseDouble(rows[1].split(";")[3])));
			vpeMap.put(FMSVariableConstants.OTHERGELE, decimalFormat.format((Double.parseDouble(rows[0].split(";")[4]))-Double.parseDouble(rows[1].split(";")[4])));
			vpeMap.put(FMSVariableConstants.CT, decimalFormat.format((Double.parseDouble(rows[0].split(";")[5]))-Double.parseDouble(rows[1].split(";")[5])));
			vpeMap.put(FMSVariableConstants.HQ, decimalFormat.format((Double.parseDouble(rows[0].split(";")[6]))-Double.parseDouble(rows[1].split(";")[6])));
			vpeMap.put(FMSVariableConstants.COQ, decimalFormat.format((Double.parseDouble(rows[0].split(";")[7]))-Double.parseDouble(rows[1].split(";")[7])));
			vpeMap.put(FMSVariableConstants.CONVTOGO, decimalFormat.format((Double.parseDouble(rows[0].split(";")[8]))-Double.parseDouble(rows[1].split(";")[8])));
			vpeMap.put(FMSVariableConstants.STRETCH, decimalFormat.format((Double.parseDouble(rows[0].split(";")[9]))-Double.parseDouble(rows[1].split(";")[9])));
			vpeMap.put(FMSVariableConstants.RISK, decimalFormat.format((Double.parseDouble(rows[0].split(";")[10]))-Double.parseDouble(rows[1].split(";")[10])));
			vpeMap.put(FMSVariableConstants.OPP, decimalFormat.format((Double.parseDouble(rows[0].split(";")[11]))-Double.parseDouble(rows[1].split(";")[11])));
			vpeMap.put(FMSVariableConstants.TOT, decimalFormat.format(ceTot-peTot));
			vpeMap.put(FMSVariableConstants.OP, decimalFormat.format(0));

			for(int i=0;i<rows.length;i++){
				String[] row = rows[i].split(";");		

				if(FMSVariableConstants.CE.equalsIgnoreCase(row[0])){
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER, row[0]);
					map.put(FMSVariableConstants.PART, decimalFormat.format(Double.parseDouble(row[1])));
					map.put(FMSVariableConstants.FIELDSERVICES, decimalFormat.format(Double.parseDouble(row[2])));
					map.put(FMSVariableConstants.REPAIR, decimalFormat.format(Double.parseDouble(row[3])));
					map.put(FMSVariableConstants.OTHERGELE, decimalFormat.format(Double.parseDouble(row[4])));
					map.put(FMSVariableConstants.CT, decimalFormat.format(Double.parseDouble(row[5])));
					map.put(FMSVariableConstants.HQ,decimalFormat.format( Double.parseDouble(row[6])));
					map.put(FMSVariableConstants.COQ, decimalFormat.format(Double.parseDouble(row[7])));
					map.put(FMSVariableConstants.CONVTOGO, decimalFormat.format(Double.parseDouble(row[8])));
					map.put(FMSVariableConstants.STRETCH, decimalFormat.format(Double.parseDouble(row[9])));
					map.put(FMSVariableConstants.RISK, decimalFormat.format(Double.parseDouble(row[10])));
					map.put(FMSVariableConstants.OPP, decimalFormat.format(Double.parseDouble(row[11])));
					map.put(FMSVariableConstants.TOT, decimalFormat.format(ceTot));
					map.put(FMSVariableConstants.OP, decimalFormat.format(0));
					mainTable.add(map);
				}else if(FMSVariableConstants.PE.equalsIgnoreCase(row[0])){
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER, row[0]);
					map.put(FMSVariableConstants.PART, decimalFormat.format(Double.parseDouble(row[1])));
					map.put(FMSVariableConstants.FIELDSERVICES, decimalFormat.format(Double.parseDouble(row[2])));
					map.put(FMSVariableConstants.REPAIR, decimalFormat.format(Double.parseDouble(row[3])));
					map.put(FMSVariableConstants.OTHERGELE, decimalFormat.format(Double.parseDouble(row[4])));
					map.put(FMSVariableConstants.CT, decimalFormat.format(Double.parseDouble(row[5])));
					map.put(FMSVariableConstants.HQ, decimalFormat.format(Double.parseDouble(row[6])));
					map.put(FMSVariableConstants.COQ, decimalFormat.format(Double.parseDouble(row[7])));
					map.put(FMSVariableConstants.CONVTOGO, decimalFormat.format(Double.parseDouble(row[8])));
					map.put(FMSVariableConstants.STRETCH, decimalFormat.format(Double.parseDouble(row[9])));
					map.put(FMSVariableConstants.RISK, decimalFormat.format(Double.parseDouble(row[10])));
					map.put(FMSVariableConstants.OPP, decimalFormat.format(Double.parseDouble(row[11])));
					map.put(FMSVariableConstants.TOT, decimalFormat.format(peTot));
					map.put(FMSVariableConstants.OP,decimalFormat.format( 0));
					mainTable.add(map);
					mainTable.add(vpeMap);
				}else if(FMSVariableConstants.BACKLOGPE.equalsIgnoreCase(row[0])){
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER, row[0]);
					map.put(FMSVariableConstants.PART, decimalFormat.format(Double.parseDouble(row[1])));
					map.put(FMSVariableConstants.FIELDSERVICES, decimalFormat.format(Double.parseDouble(row[2])));
					map.put(FMSVariableConstants.REPAIR, decimalFormat.format(Double.parseDouble(row[3])));
					map.put(FMSVariableConstants.OTHERGELE, decimalFormat.format(Double.parseDouble(row[4])));
					map.put(FMSVariableConstants.CT, decimalFormat.format(Double.parseDouble(row[5])));
					map.put(FMSVariableConstants.HQ, decimalFormat.format(Double.parseDouble(row[6])));
					map.put(FMSVariableConstants.COQ, decimalFormat.format(Double.parseDouble(row[7])));
					map.put(FMSVariableConstants.CONVTOGO, decimalFormat.format(Double.parseDouble(row[8])));
					map.put(FMSVariableConstants.STRETCH, decimalFormat.format(Double.parseDouble(row[9])));
					map.put(FMSVariableConstants.RISK, decimalFormat.format(0));
					map.put(FMSVariableConstants.OPP, decimalFormat.format(0));
					map.put(FMSVariableConstants.TOT, decimalFormat.format( backlogTot));
					map.put(FMSVariableConstants.OP,decimalFormat.format(0));
					mainTable.add(map);
				}else if(FMSVariableConstants.CWD.equalsIgnoreCase(row[0])){
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER, row[0]);
					map.put(FMSVariableConstants.PART, null);
					map.put(FMSVariableConstants.FIELDSERVICES, null);
					map.put(FMSVariableConstants.REPAIR, null);
					map.put(FMSVariableConstants.OTHERGELE, null);
					map.put(FMSVariableConstants.CT, null);
					map.put(FMSVariableConstants.HQ, null);
					map.put(FMSVariableConstants.COQ, null);
					map.put(FMSVariableConstants.CONVTOGO, null);
					map.put(FMSVariableConstants.STRETCH, null);
					map.put(FMSVariableConstants.RISK, null);
					map.put(FMSVariableConstants.OPP, null);
					map.put(FMSVariableConstants.TOT, null);
					map.put(FMSVariableConstants.OP,null);
					mainTable.add(map);
				}

			}

			//Walk by Product Chart
			String chart = tableChart[1];
			String[] chartRows =chart.split("~");

			String[] blankRows =chartRows[0].split(";");
			List<Float> blankValues = new ArrayList<>();

			for(int i=0;i<blankRows.length;i++){
				blankValues.add(Float.parseFloat(blankRows[i]));
			}

			String[] chartValues =chartRows[1].split(";");

			List<Float> txValues = new ArrayList<>();
			List<Float> hqValues = new ArrayList<>();
			List<Float> coqValues = new ArrayList<>();
			List<Float> convToGoValues = new ArrayList<>();
			List<Float> stretch = new ArrayList<>();
			List<Float> riskValues = new ArrayList<>();
			List<Float> oppValues = new ArrayList<>();
			List<Float> totValues = new ArrayList<>();
			List<Float> opValues = new ArrayList<>(); 


			for(int i=0;i<5;i++){
				txValues.add(Float.parseFloat(chartValues[i]));
				hqValues.add((float) 0);
				coqValues.add((float) 0);
				convToGoValues.add((float) 0);
				stretch.add((float) 0);
				riskValues.add((float) 0);
				oppValues.add((float) 0);
				totValues.add((float) 0);
				opValues.add((float) 0);
			}
			txValues.add((float) 0);
			hqValues.add(Float.parseFloat(chartValues[5]));
			coqValues.add((float) 0);
			convToGoValues.add((float) 0);
			stretch.add((float) 0);
			riskValues.add((float) 0);
			oppValues.add((float) 0);
			totValues.add((float) 0);
			opValues.add((float) 0);

			txValues.add((float) 0);
			hqValues.add((float) 0);
			coqValues.add(Float.parseFloat(chartValues[6]));
			convToGoValues.add((float) 0);
			stretch.add((float) 0);
			riskValues.add((float) 0);
			oppValues.add((float) 0);
			totValues.add((float) 0);
			opValues.add((float) 0);

			txValues.add((float) 0);
			hqValues.add((float) 0);
			coqValues.add((float) 0);
			convToGoValues.add(Float.parseFloat(chartValues[7]));
			stretch.add((float) 0);
			riskValues.add((float) 0);
			oppValues.add((float) 0);
			totValues.add((float) 0);
			opValues.add((float) 0);

			txValues.add((float) 0);
			hqValues.add((float) 0);
			coqValues.add((float) 0);
			convToGoValues.add((float) 0);
			stretch.add(Float.parseFloat(chartValues[8]));
			riskValues.add((float) 0);
			oppValues.add((float) 0);
			totValues.add((float) 0);
			opValues.add((float) 0);

			txValues.add((float) 0);
			hqValues.add((float) 0);
			coqValues.add((float) 0);
			convToGoValues.add((float) 0);
			stretch.add((float) 0);
			riskValues.add(Float.parseFloat(chartValues[9]));
			oppValues.add((float) 0);
			totValues.add((float) 0);
			opValues.add((float) 0);

			txValues.add((float) 0);
			hqValues.add((float) 0);
			coqValues.add((float) 0);
			convToGoValues.add((float) 0);
			stretch.add((float) 0);
			riskValues.add((float) 0);
			oppValues.add(Float.parseFloat(chartValues[10]));
			totValues.add((float) 0);
			opValues.add((float) 0);

			txValues.add((float) 0);
			hqValues.add((float) 0);
			coqValues.add((float) 0);
			convToGoValues.add((float) 0);
			stretch.add((float) 0);
			riskValues.add((float) 0);
			oppValues.add((float) 0);
			totValues.add(Math.abs((float) ceTot));
			opValues.add((float) 0);

			txValues.add((float) 0);
			hqValues.add((float) 0);
			coqValues.add((float) 0);
			convToGoValues.add((float) 0);
			stretch.add((float) 0);
			riskValues.add((float) 0);
			oppValues.add((float) 0);
			totValues.add((float) 0);
			opValues.add(Float.parseFloat(chartValues[12]));

			List<Map<String,Object>> chartMain = new ArrayList<>();
			//txValues,hqValues,coqValues,convToGoValues,stretch,riskValues,oppValues,totValues,opValues

			Map<String,Object> chartRowTX = new LinkedHashMap<>();
			chartRowTX.put(FMSVariableConstants.NAME, mapHeader);
			chartRowTX.put(FMSVariableConstants.DATA, txValues);
			chartRowTX.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowTX.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR2);
			chartRowTX.put(FMSVariableConstants.ID, 1);
			chartMain.add(chartRowTX);

			Map<String,Object> chartRowHQ = new LinkedHashMap<>();
			chartRowHQ.put(FMSVariableConstants.NAME, FMSVariableConstants.HQ);
			chartRowHQ.put(FMSVariableConstants.DATA, hqValues);
			chartRowHQ.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowHQ.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR1);
			chartRowHQ.put(FMSVariableConstants.ID, 2);
			chartMain.add(chartRowHQ);

			Map<String,Object> chartRowCOQ = new LinkedHashMap<>();
			chartRowCOQ.put(FMSVariableConstants.NAME, FMSVariableConstants.COQ);
			chartRowCOQ.put(FMSVariableConstants.DATA, coqValues);
			chartRowCOQ.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowCOQ.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR1);
			chartRowCOQ.put(FMSVariableConstants.ID, 3);
			chartMain.add(chartRowCOQ);

			Map<String,Object> chartRowCONVTOGO = new LinkedHashMap<>();
			chartRowCONVTOGO.put(FMSVariableConstants.NAME, FMSVariableConstants.CONVTOGO);
			chartRowCONVTOGO.put(FMSVariableConstants.DATA, convToGoValues);
			chartRowCONVTOGO.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowCONVTOGO.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR2);
			chartRowCONVTOGO.put(FMSVariableConstants.ID, 4);
			chartMain.add(chartRowCONVTOGO);

			Map<String,Object> chartRowSTRETCH = new LinkedHashMap<>();
			chartRowSTRETCH.put(FMSVariableConstants.NAME, FMSVariableConstants.STRETCH);
			chartRowSTRETCH.put(FMSVariableConstants.DATA, stretch);
			chartRowSTRETCH.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowSTRETCH.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR2);
			chartRowSTRETCH.put(FMSVariableConstants.ID, 5);
			chartMain.add(chartRowSTRETCH);

			Map<String,Object> chartRowRisk = new LinkedHashMap<>();
			chartRowRisk.put(FMSVariableConstants.NAME, FMSVariableConstants.RISK);
			chartRowRisk.put(FMSVariableConstants.DATA, riskValues);
			chartRowRisk.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowRisk.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR1);
			chartRowRisk.put(FMSVariableConstants.ID, 6);
			chartMain.add(chartRowRisk);

			Map<String,Object> chartRowOPP = new LinkedHashMap<>();
			chartRowOPP.put(FMSVariableConstants.NAME, FMSVariableConstants.OPP);
			chartRowOPP.put(FMSVariableConstants.DATA, oppValues);
			chartRowOPP.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowOPP.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR2);
			chartRowOPP.put(FMSVariableConstants.ID, 7);
			chartMain.add(chartRowOPP);

			Map<String,Object> chartRowTOT = new LinkedHashMap<>();
			chartRowTOT.put(FMSVariableConstants.NAME, FMSVariableConstants.TOT);
			chartRowTOT.put(FMSVariableConstants.DATA, totValues);
			chartRowTOT.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowTOT.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR2);
			chartRowTOT.put(FMSVariableConstants.ID, 8);
			chartMain.add(chartRowTOT);

			Map<String,Object> chartRowOP = new LinkedHashMap<>();
			chartRowOP.put(FMSVariableConstants.NAME, FMSVariableConstants.OP);
			chartRowOP.put(FMSVariableConstants.DATA, opValues);
			chartRowOP.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowOP.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR3);
			chartRowOP.put(FMSVariableConstants.ID, 9);
			chartMain.add(chartRowOP);

			Map<String,Object> chartRowBLANK = new LinkedHashMap<>();
			chartRowBLANK.put(FMSVariableConstants.NAME, FMSVariableConstants.BLANK);
			chartRowBLANK.put(FMSVariableConstants.DATA, blankValues);
			chartRowBLANK.put(FMSVariableConstants.SHOWINLEGEND, false);
			chartRowBLANK.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR4);
			chartRowBLANK.put(FMSVariableConstants.ID, 10);
			chartMain.add(chartRowBLANK);

			completeData.put(FMSVariableConstants.TABLE, mainTable);
			completeData.put(FMSVariableConstants.TABLEHEADERS, new String[]{FMSVariableConstants.PART,FMSVariableConstants.FIELDSERVICES,FMSVariableConstants.REPAIR,FMSVariableConstants.OTHERGELE,FMSVariableConstants.CT,FMSVariableConstants.HQ,FMSVariableConstants.COQ,FMSVariableConstants.CONVTOGO,FMSVariableConstants.STRETCH,FMSVariableConstants.RISK,FMSVariableConstants.OPP,FMSVariableConstants.TOT,FMSVariableConstants.OP});
			completeData.put(FMSVariableConstants.CHART, chartMain);
			completeData.put(FMSVariableConstants.ACTUAL, null);
			completeData.put(FMSVariableConstants.UNCONFIRMED, null);
		}

		return completeData;
	}

	/*##### FMS Enhancement services ######*/

	@Override
	public Map<String, Object> getQuarterYear() {
		Map<String, Object> resultMap = new HashMap<>();
		String equipmentQuery = FMSQueryConstants.IBAS_QUARTER_YEAR;
		String orderQuery = FMSQueryConstants.ORDER_QUARTER_YEAR;
		try {
			resultMap.put("EquipmentYearQuarter",jdbc.queryForMap(equipmentQuery));
			resultMap.put("OrderYearQuarter",jdbc.queryForMap(orderQuery));
		} catch (Exception e) {
			log.error("Error :  -- " + e.getStackTrace());
			log.error("Error in getQuarterYear :"+e.getMessage());
			resultMap.put(FMSVariableConstants.ERROR, e.getMessage());
		}
		return resultMap;
	}

	@Override
	public List<String> getIPMPartsDropdownData(Map<String, Object> filterData) {

		Object[] params = new Object[13];	
		params[0] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
		params[1] = Utils.getValidation(filterData.get(FMSVariableConstants.PANDL));
		params[2] = Utils.getValidation(filterData.get(FMSVariableConstants.PRODUCT));
		params[3] = Utils.getValidation(filterData.get(FMSVariableConstants.OUNAME));
		params[4] = Utils.getValidation(filterData.get(FMSVariableConstants.OGREGION));
		params[5] = Utils.getValidation(filterData.get(FMSVariableConstants.REGION));
		params[6] = Utils.getValidation(filterData.get(FMSVariableConstants.SUBREGION));
		params[7] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCOUNTRYDISC));
		params[8] = Utils.getValidation(filterData.get(FMSVariableConstants.MOTHERJOB));
		params[9] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCUSTNAME));
		params[10] =Utils.getValidation(filterData.get(FMSVariableConstants.COSTINGPROJECT));
		params[11] =Utils.getValidation(filterData.get(FMSVariableConstants.ORDERTYPE));
		params[12] = Utils.getValidation(filterData.get(FMSVariableConstants.PARTS_STATUS));

		int roleId = Utils.getIntegerValidation(filterData.get(FMSVariableConstants.ROLE_ID));

		String postQuery;
		if(FMSVariableConstants.CURRENT.equals(Utils.getValidation(filterData.get(FMSVariableConstants.SALESYRQTR)))){
			postQuery = FMSQueryConstants.IPM_PARTS_PROJECT_MANAGER + " AND (fim.sales_date_year_qtr in (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) or fed.p_forecast_status = 'A' ) and (fed.p_forecast_status <> 'R' or fed.p_forecast_status is null) AND project_manager IS NOT NULL";
		} else if("FUTURE".equals(Utils.getValidation(filterData.get(FMSVariableConstants.SALESYRQTR)))) {
			postQuery = FMSQueryConstants.IPM_PARTS_PROJECT_MANAGER +" AND (fim.sales_date_year_qtr in(((extract(year from now()+ (interval '3 month'))||'-'||extract(quarter from current_timestamp+ (interval '3 month')))), ((extract(year from now()+ (interval '6 month'))||'-'||extract(quarter from current_timestamp+ (interval '6 month')))), ((extract(year from now()+ (interval '9 month'))||'-'||extract(quarter from current_timestamp+ (interval '9 month')))), ((extract(year from now()+ (interval '12 month'))||'-'||extract(quarter from current_timestamp+ (interval '12 month'))))) or fed.p_forecast_status = 'R') and (fed.p_forecast_status <> 'A' or fed.p_forecast_status is null) AND project_manager IS NOT NULL";

		}else {
			postQuery = FMSQueryConstants.IPM_PARTS_PROJECT_MANAGER + " AND project_manager IS NOT NULL";
		}

		// getting role specific project managers for DTS/TMS
		if (roleId == 7 || roleId == 8)
			postQuery = postQuery + " AND upper(new_p_and_l) = '" + FMSVariableConstants.DTS_SEGMENT + "'";
		else if (roleId == 5 || roleId == 6)
			postQuery = postQuery + " AND upper(new_p_and_l) = '" + FMSVariableConstants.TMS_SEGMENT + "'";
		return jdbc.queryForList(postQuery,params, String.class);
	}

	@Override
	public Map<String, Object> walkByFinance(Map<String, Object> filterData) {
		String data = "";
		Object[] params = new Object[13];
		params[0] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
		params[1] = Utils.getValidation(filterData.get(FMSVariableConstants.PANDL));
		params[2] = Utils.getValidation(filterData.get(FMSVariableConstants.PRODUCT));
		params[3] = Utils.getValidation(filterData.get(FMSVariableConstants.OUNAME));
		params[4] = Utils.getValidation(filterData.get(FMSVariableConstants.OGREGION));
		params[5] = Utils.getValidation(filterData.get(FMSVariableConstants.REGION));
		params[6] = Utils.getValidation(filterData.get(FMSVariableConstants.SUBREGION));
		params[7] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCOUNTRYDISC));
		params[8] = Utils.getValidation(filterData.get(FMSVariableConstants.MOTHERJOB));
		params[9] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCUSTNAME));
		params[10] =Utils.getValidation(filterData.get(FMSVariableConstants.COSTINGPROJECT));
		params[11] =Utils.getValidation(filterData.get(FMSVariableConstants.ORDERTYPE));
		params[12] =Utils.getValidation(filterData.get(FMSVariableConstants.WEEK));
		try{
			data = jdbc.queryForObject(FMSQueryConstants.WALK_BY_FINANCE,params,String.class);
		} catch(Exception e){
			log.info(FMSVariableConstants.ERRORMESSAGE +e.getMessage());
		}
		Map<String,Object> completeData = new LinkedHashMap<>();

		String[] first = data.split("\\(");
		String[] second = first[1].split("\\)");

		if(FMSVariableConstants.DBERROR.equalsIgnoreCase(second[0].split(",")[0])){
			completeData.put(FMSVariableConstants.ERROR,  FMSVariableConstants.ERRORMESSAGE);
		}else{
			String[] tableChart = second[0].split(",");
			//Walk by Finance table
			String table = tableChart[0];
			List<Map<String,Object>> mainTable = new ArrayList<>();
			String[] rows =table.split("~");

			double ceTot = Double.parseDouble(rows[0].split(";")[1])+Double.parseDouble(rows[0].split(";")[2])+Double.parseDouble(rows[0].split(";")[3])
					+Double.parseDouble(rows[0].split(";")[4])+Double.parseDouble(rows[0].split(";")[5]);

			double peTot = Double.parseDouble(rows[1].split(";")[1])+Double.parseDouble(rows[1].split(";")[2])+Double.parseDouble(rows[1].split(";")[3])
					+Double.parseDouble(rows[1].split(";")[4])+Double.parseDouble(rows[1].split(";")[5]);

			double backlogTot =Double.parseDouble(rows[2].split(";")[1])+Double.parseDouble(rows[2].split(";")[2])+Double.parseDouble(rows[2].split(";")[3])
					+Double.parseDouble(rows[2].split(";")[4])+Double.parseDouble(rows[2].split(";")[5]);

			Map<String,Object> vpeMap = new LinkedHashMap<>(); //ce-pe
			vpeMap.put(FMSVariableConstants.HEADER,FMSVariableConstants.VPE);
			vpeMap.put(FMSVariableConstants.BACKLOG, decimalFormat.format((Double.parseDouble(rows[0].split(";")[1]))-Double.parseDouble(rows[1].split(";")[1])));
			vpeMap.put(FMSVariableConstants.CONV, decimalFormat.format((Double.parseDouble(rows[0].split(";")[2]))-Double.parseDouble(rows[1].split(";")[2])));
			vpeMap.put(FMSVariableConstants.CONVTOGO, decimalFormat.format((Double.parseDouble(rows[0].split(";")[3]))-Double.parseDouble(rows[1].split(";")[3])));
			vpeMap.put(FMSVariableConstants.HQ, decimalFormat.format((Double.parseDouble(rows[0].split(";")[4]))-Double.parseDouble(rows[1].split(";")[4])));
			vpeMap.put(FMSVariableConstants.STRETCH, decimalFormat.format((Double.parseDouble(rows[0].split(";")[5]))-Double.parseDouble(rows[1].split(";")[5])));
			vpeMap.put(FMSVariableConstants.RISK, decimalFormat.format((Double.parseDouble(rows[0].split(";")[6]))-Double.parseDouble(rows[1].split(";")[6])));
			vpeMap.put(FMSVariableConstants.OPP, decimalFormat.format((Double.parseDouble(rows[0].split(";")[7]))-Double.parseDouble(rows[1].split(";")[7])));
			vpeMap.put(FMSVariableConstants.TOT, decimalFormat.format(ceTot-peTot));
			vpeMap.put(FMSVariableConstants.OP, decimalFormat.format(0));

			for(int i=0;i<rows.length;i++){
				String[] row = rows[i].split(";");		

				if(FMSVariableConstants.CE.equalsIgnoreCase(row[0])){
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER, row[0]);
					map.put(FMSVariableConstants.BACKLOG, decimalFormat.format(Double.parseDouble(row[1])));
					map.put(FMSVariableConstants.CONV, decimalFormat.format(Double.parseDouble(row[2])));
					map.put(FMSVariableConstants.CONVTOGO, decimalFormat.format(Double.parseDouble(row[3])));
					map.put(FMSVariableConstants.HQ, decimalFormat.format(Double.parseDouble(row[4])));
					map.put(FMSVariableConstants.STRETCH, decimalFormat.format(Double.parseDouble(row[5])));
					map.put(FMSVariableConstants.RISK, decimalFormat.format(Double.parseDouble(row[6])));
					map.put(FMSVariableConstants.OPP, decimalFormat.format(Double.parseDouble(row[7])));
					map.put(FMSVariableConstants.TOT, decimalFormat.format( ceTot));
					map.put(FMSVariableConstants.OP,decimalFormat.format(0));
					mainTable.add(map);
				}else if(FMSVariableConstants.PE.equalsIgnoreCase(row[0])){
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER, row[0]);
					map.put(FMSVariableConstants.BACKLOG, decimalFormat.format(Double.parseDouble(row[1])));
					map.put(FMSVariableConstants.CONV, decimalFormat.format(Double.parseDouble(row[2])));
					map.put(FMSVariableConstants.CONVTOGO, decimalFormat.format(Double.parseDouble(row[3])));
					map.put(FMSVariableConstants.HQ, decimalFormat.format(Double.parseDouble(row[4])));
					map.put(FMSVariableConstants.STRETCH, decimalFormat.format(Double.parseDouble(row[5])));
					map.put(FMSVariableConstants.RISK, decimalFormat.format(Double.parseDouble(row[6])));
					map.put(FMSVariableConstants.OPP, decimalFormat.format(Double.parseDouble(row[7])));
					map.put(FMSVariableConstants.TOT, decimalFormat.format( peTot));
					map.put(FMSVariableConstants.OP,decimalFormat.format(0));
					mainTable.add(map);
					mainTable.add(vpeMap);
				}else if(FMSVariableConstants.BACKLOGPE.equalsIgnoreCase(row[0])){
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER, row[0]);
					map.put(FMSVariableConstants.BACKLOG, decimalFormat.format(Double.parseDouble(row[1])));
					map.put(FMSVariableConstants.CONV, decimalFormat.format(Double.parseDouble(row[2])));
					map.put(FMSVariableConstants.CONVTOGO, decimalFormat.format(Double.parseDouble(row[3])));
					map.put(FMSVariableConstants.HQ, decimalFormat.format(Double.parseDouble(row[4])));
					map.put(FMSVariableConstants.STRETCH, decimalFormat.format(Double.parseDouble(row[5])));
					map.put(FMSVariableConstants.RISK, decimalFormat.format(0));
					map.put(FMSVariableConstants.OPP, decimalFormat.format(0));
					map.put(FMSVariableConstants.TOT, decimalFormat.format( 0));
					map.put(FMSVariableConstants.OP,decimalFormat.format(backlogTot));
					mainTable.add(map);
				}else if(FMSVariableConstants.CWD.equalsIgnoreCase(row[0])){
					Map<String,Object> map = new LinkedHashMap<>();
					map.put(FMSVariableConstants.HEADER, row[0]);
					map.put(FMSVariableConstants.BACKLOG, decimalFormat.format(Double.parseDouble(row[1])));
					map.put(FMSVariableConstants.CONV, null);
					map.put(FMSVariableConstants.CONVTOGO, null);
					map.put(FMSVariableConstants.HQ, null);
					map.put(FMSVariableConstants.STRETCH, null);
					map.put(FMSVariableConstants.RISK, null);
					map.put(FMSVariableConstants.OPP, null);
					map.put(FMSVariableConstants.TOT, null);
					map.put(FMSVariableConstants.OP,null);
					mainTable.add(map);
				}

			}

			//Walk by Finance Chart
			String chart = tableChart[1];
			String[] chartRows =chart.split("~");

			String[] blankRows =chartRows[0].split(";");
			List<Float> blankValues = new ArrayList<>();

			for(int i=0;i<blankRows.length;i++){
				blankValues.add(Float.parseFloat(blankRows[i]));
			}

			String[] chartValues =chartRows[1].split(";");

			List<Float> txValues = new ArrayList<>();
			List<Float> hqValues = new ArrayList<>();
			List<Float> stretch = new ArrayList<>();
			List<Float> riskValues = new ArrayList<>();
			List<Float> oppValues = new ArrayList<>();
			List<Float> totValues = new ArrayList<>();
			List<Float> opValues = new ArrayList<>(); 


			for(int i=0;i<3;i++){
				txValues.add(Float.parseFloat(chartValues[i]));
				hqValues.add((float) 0);
				stretch.add((float) 0);
				riskValues.add((float) 0);
				oppValues.add((float) 0);
				totValues.add((float) 0);
				opValues.add((float) 0);
			}
			txValues.add((float) 0);
			hqValues.add(Float.parseFloat(chartValues[3]));
			stretch.add((float) 0);
			riskValues.add((float) 0);
			oppValues.add((float) 0);
			totValues.add((float) 0);
			opValues.add((float) 0);

			txValues.add((float) 0);
			hqValues.add((float) 0);
			stretch.add(Float.parseFloat(chartValues[4]));
			riskValues.add((float) 0);
			oppValues.add((float) 0);
			totValues.add((float) 0);
			opValues.add((float) 0);

			txValues.add((float) 0);
			hqValues.add((float) 0);
			stretch.add((float) 0);
			riskValues.add(Float.parseFloat(chartValues[5]));
			oppValues.add((float) 0);
			totValues.add((float) 0);
			opValues.add((float) 0);

			txValues.add((float) 0);
			hqValues.add((float) 0);
			stretch.add((float) 0);
			riskValues.add((float) 0);
			oppValues.add(Float.parseFloat(chartValues[6]));
			totValues.add((float) 0);
			opValues.add((float) 0);

			txValues.add((float) 0);
			hqValues.add((float) 0);
			stretch.add((float) 0);
			riskValues.add((float) 0);
			oppValues.add((float) 0);
			totValues.add(Math.abs((float) ceTot));
			opValues.add((float) 0);

			txValues.add((float) 0);
			hqValues.add((float) 0);
			stretch.add((float) 0);
			riskValues.add((float) 0);
			oppValues.add((float) 0);
			totValues.add((float) 0);
			opValues.add(Float.parseFloat(chartValues[8]));

			List<Map<String,Object>> chartMain = new ArrayList<>();

			Map<String,Object> chartRowTX = new LinkedHashMap<>();
			chartRowTX.put(FMSVariableConstants.NAME, FMSVariableConstants.TX);
			chartRowTX.put(FMSVariableConstants.DATA, txValues);
			chartRowTX.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowTX.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR2);
			chartRowTX.put(FMSVariableConstants.ID, 1);
			chartMain.add(chartRowTX);

			Map<String,Object> chartRowHQ = new LinkedHashMap<>();
			chartRowHQ.put(FMSVariableConstants.NAME, FMSVariableConstants.HQ);
			chartRowHQ.put(FMSVariableConstants.DATA, hqValues);
			chartRowHQ.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowHQ.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR1);
			chartRowHQ.put(FMSVariableConstants.ID, 2);
			chartMain.add(chartRowHQ);

			Map<String,Object> chartRowSTRETCH = new LinkedHashMap<>();
			chartRowSTRETCH.put(FMSVariableConstants.NAME, FMSVariableConstants.STRETCH);
			chartRowSTRETCH.put(FMSVariableConstants.DATA, stretch);
			chartRowSTRETCH.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowSTRETCH.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR2);
			chartRowSTRETCH.put(FMSVariableConstants.ID, 3);
			chartMain.add(chartRowSTRETCH);

			Map<String,Object> chartRowRisk = new LinkedHashMap<>();
			chartRowRisk.put(FMSVariableConstants.NAME, FMSVariableConstants.RISK);
			chartRowRisk.put(FMSVariableConstants.DATA, riskValues);
			chartRowRisk.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowRisk.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR1);
			chartRowRisk.put(FMSVariableConstants.ID, 4);
			chartMain.add(chartRowRisk);

			Map<String,Object> chartRowOPP = new LinkedHashMap<>();
			chartRowOPP.put(FMSVariableConstants.NAME, FMSVariableConstants.OPP);
			chartRowOPP.put(FMSVariableConstants.DATA, oppValues);
			chartRowOPP.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowOPP.put(FMSVariableConstants.COLOR, "#A6A6A6");
			chartRowOPP.put(FMSVariableConstants.ID, 5);
			chartMain.add(chartRowOPP);

			Map<String,Object> chartRowTOT = new LinkedHashMap<>();
			chartRowTOT.put(FMSVariableConstants.NAME, FMSVariableConstants.TOT);
			chartRowTOT.put(FMSVariableConstants.DATA, totValues);
			chartRowTOT.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowTOT.put(FMSVariableConstants.COLOR, "#A6A6A6");
			chartRowTOT.put(FMSVariableConstants.ID, 6);
			chartMain.add(chartRowTOT);

			Map<String,Object> chartRowOP = new LinkedHashMap<>();
			chartRowOP.put(FMSVariableConstants.NAME, FMSVariableConstants.OP);
			chartRowOP.put(FMSVariableConstants.DATA, opValues);
			chartRowOP.put(FMSVariableConstants.SHOWINLEGEND, true);
			chartRowOP.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR3);
			chartRowOP.put(FMSVariableConstants.ID, 7);
			chartMain.add(chartRowOP);

			Map<String,Object> chartRowBLANK = new LinkedHashMap<>();
			chartRowBLANK.put(FMSVariableConstants.NAME, FMSVariableConstants.BLANK);
			chartRowBLANK.put(FMSVariableConstants.DATA, blankValues);
			chartRowBLANK.put(FMSVariableConstants.SHOWINLEGEND, false);
			chartRowBLANK.put(FMSVariableConstants.COLOR, FMSVariableConstants.COLOR4);
			chartRowBLANK.put(FMSVariableConstants.ID, 8);
			chartMain.add(chartRowBLANK);

			completeData.put(FMSVariableConstants.TABLE, mainTable);
			completeData.put(FMSVariableConstants.TABLEHEADERS, new String[]{FMSVariableConstants.BACKLOG,FMSVariableConstants.CONV,FMSVariableConstants.CONVTOGO,FMSVariableConstants.HQ,FMSVariableConstants.STRETCH,FMSVariableConstants.RISK,FMSVariableConstants.OPP,FMSVariableConstants.TOT,FMSVariableConstants.OP});
			completeData.put(FMSVariableConstants.CHART, chartMain);
			completeData.put(FMSVariableConstants.ACTUAL, Double.parseDouble(decimalFormat.format(Double.parseDouble(tableChart[2]))));
			completeData.put(FMSVariableConstants.UNCONFIRMED, Double.parseDouble(decimalFormat.format(Double.parseDouble(tableChart[3]))));
		}

		return completeData;
	}

	@Override
	public synchronized String importCSVToTable(InputStream inputStream, String fileName, String userSSO) {
		String response = FMSVariableConstants.SUCCESS;
		Connection con = null;
		int inValidCount;
		int validCount;

		Map<String, Object> insertHistoryData = new HashMap<>();
		insertHistoryData.put(FMSVariableConstants.SSO_ID, userSSO);
		insertHistoryData.put(FMSVariableConstants.TASK_NAME, "IPM Parts Import");
		insertHistoryData.put(FMSVariableConstants.FILE_NAME, fileName);
		insertHistoryData.put(FMSVariableConstants.STATUS, FMSVariableConstants.IN_PROGRESS);
		int insertId = insertToImportHistory(insertHistoryData);

		Object[] data = new Object[1];
		data[0] =userSSO; 
		try {
			con = DriverManager.getConnection(url,user,pass);
			CopyManager copyManager = new CopyManager((BaseConnection) con);
			jdbc.update(FMSQueryConstants.PARTS_DELETE_DATA, data);
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.IN_PROGRESS,"Parts data deleted","importCSVToTable Started"});
			StringBuilder sql = new StringBuilder();
			sql.append(FMSVariableConstants.COPY);
			sql.append("fms_ipm_csv_parts_import(concatenate,line_id,p_flow_or_no_flow,p_note,p_due_date,p_wb_comment,p_r_by_o,p_status,p_keydeals,p_new_date,p_exp_fw_revrec_firts_pl,p_exp_fw_revrec,p_sum_sales,p_sum_cm,p_cm_dollar_by_1000,p_financial_basket,p_operational_basket,p_status_aging,new_p_and_l,p_and_l,ou_name,product,og_region,region,mother_job,costing_project,booking_date,booking_date_year_mnth,project_manager,enduser_cust_name,end_user_country_disc,buyer_cust_name,customer_po_number,cm_global_contract,contr_par_ship_allwd,early_delivery_allowed,delivery_term,so_line,item_code,item_description,ordered_quantity,po_promise_date,so_cwd,sales_date,basket,line_sales_forecast_dollar,line_cm_forecast_dollar,line_sales_actual_dollar,line_cm_actual_dollar,i_c,tp_rate,unit_cost,unit_true_cost,line_true_cost,transfer_price,actual_cost,box_number,box_closure_date,actual_shipment_date,invoice_number,invoice_status_change_date,parts_status,p_trend)");
			sql.append(" FROM STDIN WITH (");
			sql.append(" FORMAT CSV ");
			sql.append(", DELIMITER ','");
			sql.append(", NULL ''");
			sql.append(", HEADER TRUE");
			sql.append(", QUOTE '\"'");
			sql.append(", ESCAPE '\"' ");
			sql.append(", ENCODING 'UTF8'");	      
			sql.append(")");

			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Import started!:","importCSVToTable"});
			copyManager.copyIn(sql.toString(), inputStream );
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Import Completed!:","importCSVToTable"});
			jdbc.update(FMSQueryConstants.PARTS_UPDATE_SSOID, data);
			if(jdbc.queryForObject(FMSQueryConstants.PARTS_VALIDATION, data, String.class).equals(FMSVariableConstants.SUCCESS)){
				validCount = jdbc.queryForObject(FMSQueryConstants.PARTS_VALID_COUNT,data, Integer.class);
				inValidCount = jdbc.queryForObject(FMSQueryConstants.PARTS_INVALID_COUNT, data, Integer.class);
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Total no of valid count:" + validCount,"importCSVToTable"});
				Set boxId = new HashSet<String>();
				Set invoiceId = new HashSet<String>();

				if(validCount > 0){
					for (int i = 0 ; i< validCount; i+=500 ){
						StringBuilder concateID = new StringBuilder();
						List<Map<String, Object>> partsImportData = jdbc.query(FMSQueryConstants.PARTS_UPDATE_DATA, data, new MiscRowMapper());
						for (Map<String, Object> partsImportMapData : partsImportData) {
							if((partsImportMapData.get(FMSVariableConstants.PARTS_STATUS) != null) && !boxId.contains(partsImportMapData.get(FMSVariableConstants.BOX_NUMBER)) && (partsImportMapData.get(FMSVariableConstants.PARTS_STATUS).equals(FMSVariableConstants.BILLING) || partsImportMapData.get(FMSVariableConstants.PARTS_STATUS).equals(FMSVariableConstants.SHIPPING) || partsImportMapData.get(FMSVariableConstants.PARTS_STATUS).equals(FMSVariableConstants.SHIPPED))) {
								boxId.add(partsImportMapData.get(FMSVariableConstants.BOX_NUMBER));
								updateIPMParts(partsImportMapData);
							}else if((partsImportMapData.get(FMSVariableConstants.PARTS_STATUS) != null) && !invoiceId.contains(partsImportMapData.get(FMSVariableConstants.INVOICE_NUMBER)) && (partsImportMapData.get(FMSVariableConstants.PARTS_STATUS).equals(FMSVariableConstants.SALES))){
								invoiceId.add(partsImportMapData.get(FMSVariableConstants.INVOICE_NUMBER));
								updateIPMParts(partsImportMapData);
							}
							if((partsImportMapData.get(FMSVariableConstants.PARTS_STATUS) == null) || !partsImportMapData.get(FMSVariableConstants.PARTS_STATUS).equals(FMSVariableConstants.BILLING) && !partsImportMapData.get(FMSVariableConstants.PARTS_STATUS).equals(FMSVariableConstants.SHIPPING) && !partsImportMapData.get(FMSVariableConstants.PARTS_STATUS).equals(FMSVariableConstants.SHIPPED) && !partsImportMapData.get(FMSVariableConstants.PARTS_STATUS).equals(FMSVariableConstants.SALES)) {
								updateIPMParts(partsImportMapData);
							}
							concateID.append("'").append(partsImportMapData.get(FMSVariableConstants.CONCATENATE)).append("'").append(",");

						}
						if (concateID.length() > 0) {
							concateID.setLength(concateID.length() - 1);
						}

						jdbc.update(FMSQueryConstants.PARTS_UPDATION_COMPLETED_ROW + concateID +")");
					}
					jdbc.update(FMSQueryConstants.PARTS_IPM_EDIT_FIELDS_UPDATE_QUERY, data);
				}
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Records updated!:","importCSVToTable"});
				updateImportHistory(FMSVariableConstants.SUCCESS, inValidCount, insertId);
			}
		}catch(Exception e){
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"importCSVToTable"});
			updateImportHistory(FMSVariableConstants.FAILURE, 0, insertId);
			response = FMSVariableConstants.FAILURE;
		} finally{
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					log.error(FMSVariableConstants.DBEXCEPTION+ e.getStackTrace());
				}
			}
		}
		return response;
	}

	public void exportCSVFromTable(HttpServletResponse responses,Map<String,Object> filterData) {
		String manager = Utils.getValidation(filterData.get(FMSVariableConstants.PROJECTMANAGER));
		String sqlQuery = FMSQueryConstants.PARTS_DATA_EXPT + manager + "'";
		exportCSVData(responses, sqlQuery, "IPM-Parts-Data");
	}

	@Override
	public FMSDMMetricsDetailsDTO getDMMetricsData(String businessSegment, Map<String, Object> data) {
		FMSDMMetricsDetailsDTO result = new FMSDMMetricsDetailsDTO();
		businessSegment = FMSVariableConstants.EMPTY_STRING;
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));
		List<FMSDMMetricsTechDTO> technologyDetails = jdbc.query(FMSQueryConstants.RETRIEVE_DM_REGION_METRICS_DATA,new Object[]{businessSegment,marketIndustry,accountManager}, new FMSDMTechMetricsMapper());
		List<FMSDMMetricsCustomerDTO> topCustomer = jdbc.query(FMSQueryConstants.RETRIEVE_DM_CUST_METRICS_DATA,new Object[]{businessSegment,marketIndustry,accountManager},new FMSDMCustomerMetricsMapper());
		result.setTechnologyDetails(technologyDetails);
		result.setTopCustomer(topCustomer);

		return result;
	}

	@Override
	public Map<String, Object> getDMMetricsDropdown(String businessSegment, Map<String, Object> data) {
		Map<String, Object> resultMap = new HashMap<>();
		businessSegment = FMSVariableConstants.EMPTY_STRING;
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));
		try {
			List<FMSDMForecastCategoryDTO> filter1 = jdbc.query(FMSQueryConstants.RETRIEVE_DM_DROPDOWN_FORECAST_CATEGORY,new Object[]{businessSegment,marketIndustry,accountManager}, new FMSDMForecastCategoryMapper());
			List<FMSDMBusinessTierDTO> filter2 = jdbc.query(FMSQueryConstants.RETRIEVE_DM_DROPDOWN_BUSINESS_TIER_3,new Object[]{businessSegment,marketIndustry,accountManager}, new FMSDMBusinessTierMapper());
			List<FMSDMPrimaryCountryDTO> filter3 = jdbc.query(FMSQueryConstants.RETRIEVE_DM_DROPDOWN_PRIMARY_COUNTRY,new Object[]{businessSegment,marketIndustry,accountManager},new FMSDMPrimaryCountryMapper());
			List<FMSDMPrimaryRegionDTO> filter4 = jdbc.query(FMSQueryConstants.RETRIEVE_DM_DROPDOWN_PRIMARY_REGION,new Object[]{businessSegment,marketIndustry,accountManager},new FMSDMPrimaryRegionMapper());
			List<FMSDMQtrDTO> filter5 = jdbc.query(FMSQueryConstants.RETRIEVE_DM_DROPDOWN_CONVERTIBLE_THIS_QTR,new Object[]{businessSegment,marketIndustry,accountManager},new FMSDMQtrMapper());
			List<FMSDMAccountNameDTO> filter6 = jdbc.query(FMSQueryConstants.RETRIEVE_DM_DROPDOWN_END_USER_ACCOUNT_NAME,new Object[]{businessSegment,marketIndustry,accountManager},new FMSDMAccountNameMapper());
			List<FMSDMPathDTO> filter7 = jdbc.query(FMSQueryConstants.RETRIEVE_DM_DROPDOWN_DEAL_RISK_PATH,new Object[]{businessSegment,marketIndustry,accountManager},new FMSDMPathMapper());
			List<FMSDMAccountClassDTO> filter8 = jdbc.query(FMSQueryConstants.RETRIEVE_DM_DROPDOWN_GLOBAL_ACCOUNT_CLASS,new Object[]{businessSegment,marketIndustry,accountManager},new FMSDMAccountClassMapper());
			List<FMSDMAccountTypeDTO> filter9 = jdbc.query(FMSQueryConstants.RETRIEVE_DM_DROPDOWN_GLOBAL_ACCOUNT_TYPE,new Object[]{businessSegment,marketIndustry,accountManager},new FMSDMAccountTypeMapper());
			List<FMSCurrentYearDTO> filter10 = jdbc.query(FMSQueryConstants.RETRIEVE_DM_DROPDOWN_CURRENT_YEAR_QTR,new Object[]{businessSegment,marketIndustry,accountManager},new FMSCurrentYearMapper());
			List<FMSOpptyExternalIdDTO> filter12 = jdbc.query(FMSQueryConstants.RETRIEVE_DM_DROPDOWN_OPPTY_EXTERNAL_ID,new Object[]{businessSegment,marketIndustry,accountManager},new FMSOpptyExternalIdMapper());

			resultMap.put("filter1",filter1);
			resultMap.put("filter2",filter2);
			resultMap.put("filter3",filter3);
			resultMap.put("filter4",filter4);
			resultMap.put("filter5",filter5);
			resultMap.put("filter6",filter6);
			resultMap.put("filter7",filter7);
			resultMap.put("filter8",filter8);
			resultMap.put("filter9",filter9);
			resultMap.put("filter10", filter10);
			resultMap.put("filter11", jdbc.query(FMSQueryConstants.RETRIEVE_DM_DROPDOWN_OPPTY_SALES_STAGE,new Object[]{businessSegment,marketIndustry,accountManager}, new MiscRowMapper()));
			resultMap.put("filter12", filter12);
		} catch (Exception e) {
			log.error("Error in getDMMetricsDropdown :"+e.getMessage());
			resultMap.put(FMSVariableConstants.ERROR, e.getMessage());
		}
		return resultMap;
	}

	@Override
	public String storeMappingData(List<Map<String,List<FMSOrderMappingExcelBean>>> mappingDataListQ, String mappingParam){
		String data="";
		List<FMSOrderMappingExcelBean> mapListMEDAO = null;
		List<FMSOrderMappingExcelBean> mapListSKDAO =null; 
		List<FMSOrderMappingExcelBean> mapListPKDAO = null;
		for(int i=0;i<mappingDataListQ.size();i++){
			Map<String,List<FMSOrderMappingExcelBean>> a = mappingDataListQ.get(i);
			if(a.containsKey("ME Mapping")){
				mapListMEDAO=a.get("ME Mapping");
			}/**else if(a.containsKey("Segment Mapping")){
				mapListSKDAO=a.get("Segment Mapping");
			}*/else if(a.containsKey("Product Mapping")){
				mapListPKDAO=a.get("Product Mapping");
			}
		}
		jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.STARTED,"Orders Mapping Started for : " + mappingParam,"storeMappingData Start"});
		if("ALL".equalsIgnoreCase(mappingParam)){
			int delMEMapping = jdbc.update(FMSQueryConstants.DELETE_ME_MAPPING_DATA);
			log.info(FMSVariableConstants.TRUNCATE+delMEMapping);
			/**int delSKMapping = jdbc.update(FMSQueryConstants.DELETE_SK_MAPPING_DATA);
			log.info(FMSVariableConstants.TRUNCATE+delSKMapping);*/
			int delPKMapping = jdbc.update(FMSQueryConstants.DELETE_PK_MAPPING_DATA);
			log.info(FMSVariableConstants.TRUNCATE+delPKMapping);

			try {
				if(null !=mapListMEDAO && mapListMEDAO.size()>0)
				{

					for (FMSOrderMappingExcelBean orderMappingDTO : mapListMEDAO) { 	
						Object[] params = new Object[8];
						params[0] = orderMappingDTO.getMmCmgmtEntityCode();
						params[1] = orderMappingDTO.getMmMappingInclSCCorrections();
						params[2] = orderMappingDTO.getMmPandL();
						params[3] = orderMappingDTO.getMmSVCEQ();
						params[4] = orderMappingDTO.getMmTierThree();
						params[5] = orderMappingDTO.getMmDMTierThree();
						params[6] = orderMappingDTO.getMmTierFour();
						params[7] = orderMappingDTO.getMmUsage();

						jdbc.update(FMSQueryConstants.INSERT_ME_MAPPING_DATA,params);
					}
					jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.COMPLETED,FMSVariableConstants.ORDERS_MAPPING_SL_ME_ARG1,FMSVariableConstants.ORDERS_MAPPING_SL_ME_ARG2});
				}
			} catch (Exception e) {
				log.error(FMSVariableConstants.DATABASEERROR, e);
			}

			/**try {
				if(null !=mapListSKDAO && mapListSKDAO.size()>0)
				{

					for (FMSOrderMappingExcelBean orderMappingDTO : mapListSKDAO) { 	
						Object[] params = new Object[2];
						params[0] = orderMappingDTO.getSkCSrcNewSegment();
						params[1] = orderMappingDTO.getSkSegmentMapping();
						jdbc.update(FMSQueryConstants.INSERT_SK_MAPPING_DATA,params);
					}
					jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.COMPLETED,FMSVariableConstants.ORDERS_MAPPING_SL_SK_ARG1,FMSVariableConstants.ORDERS_MAPPING_SL_SK_ARG2});
				}
			} catch (Exception e) {
				log.error(FMSVariableConstants.DATABASEERROR, e);
			}*/

			try {
				if(null !=mapListPKDAO && mapListPKDAO.size()>0)
				{

					for (FMSOrderMappingExcelBean orderMappingDTO : mapListPKDAO) { 	
						Object[] params = new Object[2];
						params[0] = orderMappingDTO.getPkCProductTypeDesc();
						params[1] = orderMappingDTO.getPkProductMapping();
						jdbc.update(FMSQueryConstants.INSERT_PK_MAPPING_DATA,params);
					}
					jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.COMPLETED,FMSVariableConstants.ORDERS_MAPPING_SL_PK_ARG1,FMSVariableConstants.ORDERS_MAPPING_SL_PK_ARG2});
				}
			} catch (Exception e) {
				log.error(FMSVariableConstants.DATABASEERROR, e);
			}
		}
		else if("ME".equalsIgnoreCase(mappingParam)){
			int delMEMapping = jdbc.update(FMSQueryConstants.DELETE_ME_MAPPING_DATA);
			log.info(FMSVariableConstants.TRUNCATE+delMEMapping);

			try {
				if(null !=mapListMEDAO && mapListMEDAO.size()>0){

					for (FMSOrderMappingExcelBean orderMappingDTO : mapListMEDAO) { 	
						Object[] params = new Object[8];
						params[0] = orderMappingDTO.getMmCmgmtEntityCode();
						params[1] = orderMappingDTO.getMmMappingInclSCCorrections();
						params[2] = orderMappingDTO.getMmPandL();
						params[3] = orderMappingDTO.getMmSVCEQ();
						params[4] = orderMappingDTO.getMmTierThree();
						params[5] = orderMappingDTO.getMmDMTierThree();
						params[6] = orderMappingDTO.getMmTierFour();
						params[7] = orderMappingDTO.getMmUsage();

						jdbc.update(FMSQueryConstants.INSERT_ME_MAPPING_DATA,params);
					}
					jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.COMPLETED,FMSVariableConstants.ORDERS_MAPPING_SL_ME_ARG1,FMSVariableConstants.ORDERS_MAPPING_SL_ME_ARG2});
				}} catch (Exception e) {
					log.error(FMSVariableConstants.DATABASEERROR, e);
				}
		}
		/**else if("SK".equalsIgnoreCase(mappingParam)){
			int delMEMapping = jdbc.update(FMSQueryConstants.DELETE_SK_MAPPING_DATA);
			log.info(FMSVariableConstants.TRUNCATE+delMEMapping);
			try {
				if(null !=mapListSKDAO && mapListSKDAO.size()>0)
				{
					for (FMSOrderMappingExcelBean orderMappingDTO : mapListSKDAO) { 	
						Object[] params = new Object[2];
						params[0] = orderMappingDTO.getSkCSrcNewSegment();
						params[1] = orderMappingDTO.getSkSegmentMapping();
						jdbc.update(FMSQueryConstants.INSERT_SK_MAPPING_DATA,params);
					}
					jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.COMPLETED,FMSVariableConstants.ORDERS_MAPPING_SL_SK_ARG1,FMSVariableConstants.ORDERS_MAPPING_SL_SK_ARG2});
				}
			} catch (Exception e) {
				log.error(FMSVariableConstants.DATABASEERROR, e);
			}
		}*/
		else if("PK".equalsIgnoreCase(mappingParam)){
			int delMEMapping = jdbc.update(FMSQueryConstants.DELETE_PK_MAPPING_DATA);
			log.info(FMSVariableConstants.TRUNCATE+delMEMapping);

			try {
				if(null !=mapListPKDAO && mapListPKDAO.size()>0)
				{

					for (FMSOrderMappingExcelBean orderMappingDTO : mapListPKDAO) { 	
						Object[] params = new Object[2];
						params[0] = orderMappingDTO.getPkCProductTypeDesc();
						params[1] = orderMappingDTO.getPkProductMapping();
						jdbc.update(FMSQueryConstants.INSERT_PK_MAPPING_DATA,params);
					}
					jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.COMPLETED,FMSVariableConstants.ORDERS_MAPPING_SL_PK_ARG1,FMSVariableConstants.ORDERS_MAPPING_SL_PK_ARG2});
				}
			} catch (Exception e) {
				log.error(FMSVariableConstants.DATABASEERROR, e);
			}
		}

		else{
			log.error(FMSVariableConstants.DATABASEERROR);
		}

		try{
			data = jdbc.queryForObject(FMSQueryConstants.ME_MAPPING_FUNC,new Object[]{mappingParam},String.class);
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.COMPLETED,"Orders Mapping Done for : "+mappingParam,"storeMappingData"});
		} catch(Exception e){
			log.info(FMSVariableConstants.ERRORMESSAGE+e.getMessage());
		}

		if (FMSVariableConstants.SUCCESS.equalsIgnoreCase(data)){
			return FMSVariableConstants.SUCCESS;
		}else{
			return FMSVariableConstants.FAILURE;
		}		

	}

	@Override
	public List<FMSDMDataBean> getDMData(Map<String, Object> data) {
		String type = Utils.getValidation(data.get(FMSVariableConstants.TYPE));
		/**String businessSegment = Utils.getValidation(data.get(FMSVariableConstants.BUSINESS_SEG));*/
		String businessSegment =FMSVariableConstants.EMPTY_STRING;
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		if(type.equalsIgnoreCase(FMSVariableConstants.DEFAULT)){

			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.YEAR, -5);

			return jdbc.query(FMSQueryConstants.RETRIEVE_DM_DATA,new Object[]{businessSegment,marketIndustry}, new DMDataMapper());

		}else{
			return jdbc.query(FMSQueryConstants.RETRIEVE_DM_DATA_ORIGINAL,new Object[]{businessSegment,marketIndustry}, new DMDataMapper());
		}
	}


	@Override
	public List<FMSServiceReqDataBean> getServiceReqData(String data) {

		if(data.equalsIgnoreCase(FMSVariableConstants.DEFAULT)){

			return jdbc.query(FMSQueryConstants.RETRIEVE_SERVICE_REQ_DATA, new ServiceReqDataMapper());

		}else{
			return jdbc.query(FMSQueryConstants.RETRIEVE_SERVICE_REQ_DATA_ORIGINAL,new Object[]{}, new ServiceReqDataMapper());
		}
	}


	@Override
	public Map<String, Object> getPMOChartData(Map<String, Object> filterData) {
		Object[] params = new Object[13];	
		params[0] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
		params[1] = Utils.getValidation(filterData.get(FMSVariableConstants.PANDL));
		params[2] = Utils.getValidation(filterData.get(FMSVariableConstants.PRODUCT));
		params[3] = Utils.getValidation(filterData.get(FMSVariableConstants.OUNAME));
		params[4] = Utils.getValidation(filterData.get(FMSVariableConstants.OGREGION));
		params[5] = Utils.getValidation(filterData.get(FMSVariableConstants.REGION));
		params[6] = Utils.getValidation(filterData.get(FMSVariableConstants.SUBREGION));
		params[7] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCOUNTRYDISC)).replaceAll("'", " ");
		params[8] = Utils.getValidation(filterData.get(FMSVariableConstants.MOTHERJOB));
		params[9] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCUSTNAME));
		params[10] =Utils.getValidation(filterData.get(FMSVariableConstants.COSTINGPROJECT));
		params[11] =Utils.getValidation(filterData.get(FMSVariableConstants.ORDERTYPE));
		params[12] =  Utils.getValidation(filterData.get(FMSVariableConstants.PROJECTMANAGER));

		Map<String,Object> tableFinal = new HashMap<>();
		String tableData =jdbc.queryForObject(FMSQueryConstants.PMO_TABLE_DATA,params,String.class);
		tableData = tableData.replaceAll("\\(", "");
		tableData = tableData.replaceAll("\\)", "");
		String[] tableChart = tableData.split(",");
		List<Map<String,Object>> financialChartFinal = new ArrayList<>();;
		Date d = new Date();
		Calendar cal = Calendar. getInstance();
		cal.setFirstDayOfWeek(Calendar.MONDAY);
		cal.setTime(d);
		cal.setMinimalDaysInFirstWeek(7);
		int week = cal.get(Calendar.WEEK_OF_YEAR);
		Map<String,Object> finalResult = new HashMap<>();
		if(week ==  Utils.nullCheckInt((filterData.get(FMSVariableConstants.WEEK))) || Utils.nullCheckInt(filterData.get("week")) == 0){
			for(int j=1;j<=2;j++){
				List<Map<String,Object>> table = new ArrayList<>();
				String[] rows = tableChart[j].split("~");
				for(int i=0;i<rows.length;i++){
					String[] row = rows[i].split(";");
					Map<String,Object> tableRow = new HashMap<>(); 
					tableRow.put(FMSVariableConstants.PARTS_STATUS, row[0]);
					tableRow.put(FMSVariableConstants.FORECASTED, row[1]);
					tableRow.put(FMSVariableConstants.ADDED, row[2]);
					tableRow.put(FMSVariableConstants.REMOVED, row[3]);
					tableRow.put(FMSVariableConstants.NEWFORECASTED, row[4]);
					table.add(tableRow);
				}
				if(j==1){
					tableFinal.put(FMSVariableConstants.CURRENT, table);
				} else if(j==2){
					tableFinal.put(FMSVariableConstants.FUTURE, table);
				}
			}
			String[] chartMain =  tableChart[0].split("~");
			List<Map<String,Object>> chartFinal = new ArrayList<>();
			for(int k=0;k<chartMain.length;k++){
				String[] row = chartMain[k].split(";");
				Map<String,Object> chartRow = new HashMap<>(); 
				chartRow.put(FMSVariableConstants.PARTS_STATUS, row[0]);
				chartRow.put(FMSVariableConstants.SUMCM, row[1]);
				chartRow.put(FMSVariableConstants.SEQPARTSSTAUS, row[2]);
				chartRow.put(FMSVariableConstants.SALESYRQTR, row[3]);
				chartFinal.add(chartRow);
			}

			if(!"\"\"".equalsIgnoreCase(tableChart[3])){
				String[] finnancialChartMain =  tableChart[3].replaceAll("\"", "").split("~");
				for(int k=0;k<finnancialChartMain.length;k++){
					String[] row = finnancialChartMain[k].split(";");
					Map<String,Object> chartRow = new HashMap<>();
					if(k==0){
						chartRow = new HashMap<>();
						chartRow.put(FMSVariableConstants.SUMCM, "0.00");
						chartRow.put(FMSVariableConstants.WEEK, "OLD");
						chartRow.put(FMSVariableConstants.CAPTION, FMSVariableConstants.CONFIRMED);
						financialChartFinal.add(chartRow);
						chartRow = new HashMap<>();
						chartRow.put(FMSVariableConstants.SUMCM, row[1]);
						chartRow.put(FMSVariableConstants.WEEK, "OLD");
						chartRow.put(FMSVariableConstants.CAPTION, row[4]);
						financialChartFinal.add(chartRow);
						chartRow = new HashMap<>();
						chartRow.put(FMSVariableConstants.SUMCM, "0.00");
						chartRow.put(FMSVariableConstants.WEEK, "OLD");
						chartRow.put(FMSVariableConstants.CAPTION, "FORECASTED");
						financialChartFinal.add(chartRow);
					} else {
						chartRow.put(FMSVariableConstants.SUMCM, row[1]);
						chartRow.put(FMSVariableConstants.WEEK, row[2]);
						chartRow.put(FMSVariableConstants.CAPTION, row[4]);
						financialChartFinal.add(chartRow);
					}

				}
			}
			finalResult.put(FMSVariableConstants.TABLEDATA, tableFinal);
			finalResult.put(FMSVariableConstants.CHARTDATA, chartFinal);
			finalResult.put(FMSVariableConstants.BOXOLDDOGS, jdbc.query(FMSQueryConstants.RETRIEVE_PMO_BOX_OLD_DOGS_DATA , params, new MiscRowMapper()));
			finalResult.put(FMSVariableConstants.CWDEXPIRED, jdbc.query(FMSQueryConstants.RETRIEVE_PMO_CWD_EXPIRED_DATA , params, new MiscRowMapper()));
			finalResult.put(FMSVariableConstants.PROMISEDATE, jdbc.query(FMSQueryConstants.RETRIEVE_PMO_PROMISE_DATE_DATA , params, new MiscRowMapper()));
			finalResult.put(FMSVariableConstants.DUMMYCODES, jdbc.query(FMSQueryConstants.RETRIEVE_PMO_DUMMY_CODES_DATA , params, new MiscRowMapper()));
			finalResult.put(FMSVariableConstants.FINANCIALVIEW, financialChartFinal);
		}else{
			Object[] historyParams = new Object[2];	
			historyParams[0] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
			historyParams[1] = Utils.getValidation(filterData.get(FMSVariableConstants.WEEK));

			tableFinal.put(FMSVariableConstants.CURRENT, jdbc.query(FMSQueryConstants.RETRIVE_PMO_CURRENT_DATA_FW_HISTORY,historyParams,new MiscRowMapper()));
			tableFinal.put(FMSVariableConstants.FUTURE, jdbc.query(FMSQueryConstants.RETRIVE_PMO_FUTURE_DATA_FW_HISTORY,historyParams,new MiscRowMapper()));
			finalResult.put(FMSVariableConstants.TABLEDATA, tableFinal);
			finalResult.put(FMSVariableConstants.CHARTDATA, jdbc.query(FMSQueryConstants.RETRIVE_PMO_CHART_DATA_FW_HISTORY,historyParams,new MiscRowMapper()));
			finalResult.put(FMSVariableConstants.BOXOLDDOGS, jdbc.query(FMSQueryConstants.RETRIEVE_PMO_BOX_OLD_DOGS_DATA_HISTORY , historyParams, new MiscRowMapper()));
			finalResult.put(FMSVariableConstants.CWDEXPIRED, jdbc.query(FMSQueryConstants.RETRIEVE_PMO_CWD_EXPIRED_DATA_HISTORY , historyParams, new MiscRowMapper()));
			finalResult.put(FMSVariableConstants.PROMISEDATE, jdbc.query(FMSQueryConstants.RETRIEVE_PMO_PROMISE_DATE_DATA_HISTORY , historyParams, new MiscRowMapper()));
			finalResult.put(FMSVariableConstants.DUMMYCODES, jdbc.query(FMSQueryConstants.RETRIEVE_PMO_DUMMY_CODES_DATA_HISTORY , historyParams, new MiscRowMapper()));
			finalResult.put(FMSVariableConstants.FINANCIALVIEW, jdbc.query(FMSQueryConstants.RETRIVE_PMO_FINANCIAL_VIEW_HISTORY , historyParams, new MiscRowMapper()));
		}	
		return finalResult;
	}



	@Override
	public FMSDMMetricsDetailsVO getDMMetricsFilterDao(FMSDMFilterDataBean filterData) {
		FMSDMMetricsDetailsVO resultsVO = new FMSDMMetricsDetailsVO();	
		try{
			Object[] data = new Object[16];
			data[0] = Utils.getValidation(filterData.getFdYear()).replaceAll("[()]", "1");
			data[1] = Utils.getValidation(filterData.getFdQuarter()).replaceAll("[()]", "1");
			data[2] = Utils.getValidation(filterData.getFdPrimaryRegion()).replaceAll("[()]", "1");
			data[3] = Utils.getValidation(filterData.getFdForecastCategory()).replaceAll("[()]", "1");
			data[4] = Utils.getValidation(filterData.getFdBusinessTier3()).replaceAll("[()]", "1");
			data[5] = Utils.getValidation(filterData.getFdPrimaryCountry()).replaceAll("[()]", "1");
			data[6] = Utils.getValidation(filterData.getFdcQtr()).replaceAll("[()]", "1");
			data[7] = Utils.getValidation(filterData.getFdAccountName()).replaceAll("[()]", "1");
			data[8] = Utils.getValidation(filterData.getFdRiskPath()).replaceAll("[()]", "1");
			data[9] = Utils.getValidation(filterData.getFdAccountClass()).replaceAll("[()]", "1");
			data[10] = Utils.getValidation(filterData.getFdAccountType()).replaceAll("[()]", "1");
			data[11] = Utils.getValidation(filterData.getFdopptyExternalId()).replaceAll("[()]", "1");
			data[12] = Utils.getValidation(filterData.getOpptySalesStage()).replaceAll("[()]", "1");
			data[13] = /**Utils.getValidation(filterData.getBusinessSegment()).replaceAll("[()]", "1")*/FMSVariableConstants.EMPTY_STRING;
			data[14] = Utils.getValidation(filterData.getDmMarketIndustry()).replace("&", "");
			data[15] = Utils.getValidation(filterData.getDmAccountManager());
			List<FMSDMMetricsTechDataBean> technologyData = jdbc.query(FMSQueryConstants.RETRIEVE_DM_TECH_METRICS_FILTER_DATA,data, new FMSDMNewTechMetricsMapper());
			List<FMSDMMetricsCustDataBean> custNameData = jdbc.query(FMSQueryConstants.RETRIEVE_DM_CUST_METRICS_FILTER_DATA,data, new FMSDMNewCustMetricsMapper());

			resultsVO.setTechnologyDataBean(technologyData); 
			resultsVO.setCustNameDataBean(custNameData);
		}catch (Exception e){
			log.info(FMSVariableConstants.ERRORMESSAGE+e.getMessage());
		}
		return resultsVO;
	}

	@Override
	public FMSDMMetricsDetailsVO getDMFilterDataCountryDao(FMSDMFilterDataBean filterData) {
		FMSDMMetricsDetailsVO resultsVO = new FMSDMMetricsDetailsVO();

		Object[] data = new Object[16];
		data[0] = Utils.getValidation(filterData.getFdYear()).replaceAll("[()]", "1");
		data[1] = Utils.getValidation(filterData.getFdQuarter()).replaceAll("[()]", "1");
		data[2] = Utils.getValidation(filterData.getFdPrimaryRegion()).replaceAll("[()]", "1");
		data[3] = Utils.getValidation(filterData.getFdForecastCategory()).replaceAll("[()]", "1");
		data[4] = Utils.getValidation(filterData.getFdBusinessTier3()).replaceAll("[()]", "1");
		data[5] = Utils.getValidation(filterData.getFdPrimaryCountry()).replaceAll("[()]", "1");
		data[6] = Utils.getValidation(filterData.getFdcQtr()).replaceAll("[()]", "1");
		data[7] = Utils.getValidation(filterData.getFdAccountName()).replaceAll("[()]", "1");
		data[8] = Utils.getValidation(filterData.getFdRiskPath()).replaceAll("[()]", "1");
		data[9] = Utils.getValidation(filterData.getFdAccountClass()).replaceAll("[()]", "1");
		data[10] = Utils.getValidation(filterData.getFdAccountType()).replaceAll("[()]", "1");
		data[11] = Utils.getValidation(filterData.getFdopptyExternalId()).replaceAll("[()]", "1");
		data[12] = Utils.getValidation(filterData.getOpptySalesStage()).replaceAll("[()]", "1");
		data[13] = /**Utils.getValidation(filterData.getBusinessSegment()).replaceAll("[()]", "1")*/FMSVariableConstants.EMPTY_STRING;
		data[14] = Utils.getValidation(filterData.getDmMarketIndustry()).replace("&", "");
		data[15] = Utils.getValidation(filterData.getDmAccountManager());
		List<FMSDMMetricsTechDataBean>  technologyData = jdbc.query(FMSQueryConstants.RETRIEVE_DM_TECH_FILTER_COUNTRY_DATA,data, new FMSDMTechMetricsCountryMapper());
		List<FMSDMMetricsCustDataBean> custNameData = jdbc.query(FMSQueryConstants.RETRIEVE_DM_CUST_FILTER_COUNTRY_DATA,data, new FMSDMCustMetricsCountryMapper());

		resultsVO.setTechnologyDataBean(technologyData);
		resultsVO.setCustNameDataBean(custNameData);

		return resultsVO;
	}


	@Override
	public Map<String, Object> getPMOChartDetailsData(Map<String, Object> filterData) {
		Object[] params = null;
		String params0 = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
		String params1 = Utils.getValidation(filterData.get(FMSVariableConstants.PANDL));
		String params2 = Utils.getValidation(filterData.get(FMSVariableConstants.PRODUCT));
		String params3 = Utils.getValidation(filterData.get(FMSVariableConstants.OUNAME));
		String params4 = Utils.getValidation(filterData.get(FMSVariableConstants.OGREGION));
		String params5 = Utils.getValidation(filterData.get(FMSVariableConstants.REGION));
		String params6 = Utils.getValidation(filterData.get(FMSVariableConstants.SUBREGION));
		String params7 = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCOUNTRYDISC));
		String params8 = Utils.getValidation(filterData.get(FMSVariableConstants.MOTHERJOB));
		String params9 = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCUSTNAME));
		String params10 = Utils.getValidation(filterData.get(FMSVariableConstants.COSTINGPROJECT));
		String params11 = Utils.getValidation(filterData.get(FMSVariableConstants.ORDERTYPE));
		String params12 = Utils.getValidation(filterData.get(FMSVariableConstants.PROJECTMANAGER));
		String params13 = Utils.getValidation(filterData.get(FMSVariableConstants.PARTS_STATUS));
		String params14 = Utils.getValidation(filterData.get(FMSVariableConstants.DAYRANGE));
		String params15 = Utils.getValidation(filterData.get(FMSVariableConstants.SALESYRQTR));
		String params16 = Utils.getValidation(filterData.get(FMSVariableConstants.FINANCIALPARTSTATUS));

		String query = "";
		Map<String, Object> pmoChartDetailsData = new HashMap<>();
		String chartType = Utils.getValidation(filterData.get(FMSVariableConstants.CHARTTYPE));
		boolean status = false;
		if("".equals(chartType) || chartType.isEmpty() || FMSVariableConstants.FINANCIAL_VIEW.equalsIgnoreCase(chartType)){
			String part_status = Utils.getValidation(filterData.get(FMSVariableConstants.PARTS_STATUS)).replace("FW", "");
			String  sales_qtr = Utils.getValidation(filterData.get(FMSVariableConstants.SALESYRQTR));
			if("OLD".equalsIgnoreCase(part_status)) {
				params = new Object[14];
				params[0] = params0;
				params[1] = params1;
				params[2] = params2;
				params[3] = params3;
				params[4] = params4;
				params[5] = params5;
				params[6] = params6;
				params[7] = params7;
				params[8] = params8;
				params[9] = params9;
				params[10] = params10;
				params[11] = params11;
				params[12] = params12;
				params[13] = params16;
				query = FMSQueryConstants.RETRIEVE_FINANCIAL_VIEW_OLD_DETAILS;
				status= true;
			} else if (FMSVariableConstants.CONFIRMED.equalsIgnoreCase(sales_qtr)) {
				params = new Object[15];
				params[0] = params0;
				params[1] = params1;
				params[2] = params2;
				params[3] = params3;
				params[4] = params4;
				params[5] = params5;
				params[6] = params6;
				params[7] = params7;
				params[8] = params8;
				params[9] = params9;
				params[10] = params10;
				params[11] = params11;
				params[12] = params12;
				params[13] = params16;
				params[14] = Integer.parseInt(part_status);
				query = FMSQueryConstants.RETRIEVE_FINANCIAL_VIEW_CONFIRMED_DETAILS;
				status= true;
			} else if ("UNCONFIRMED".equalsIgnoreCase(sales_qtr)) {
				params = new Object[28];
				params[0] = params0;
				params[1] = params1;
				params[2] = params2;
				params[3] = params3;
				params[4] = params4;
				params[5] = params5;
				params[6] = params6;
				params[7] = params7;
				params[8] = params8;
				params[9] = params9;
				params[10] = params10;
				params[11] = params11;
				params[12] = params12;
				params[13] = params16;
				params[14] = Integer.parseInt(part_status);
				params[15] = params0;
				params[16] = params12;
				params[17] = params16;
				params[18] = params2;
				params[19] = params3;
				params[20] = params4;
				params[21] = params5;
				params[22] = params6;
				params[23] = params7;
				params[24] = params8;
				params[25] = params9;
				params[26] = params10;
				params[27] = params11;

				query = FMSQueryConstants.RETRIEVE_FINANCIAL_VIEW_UNCONFIRMED_DETAILS;
				status= true;
			} else if ("FORECASTED".equalsIgnoreCase(sales_qtr)){
				params = new Object[15];
				params[0] = params0;
				params[1] = params1;
				params[2] = params2;
				params[3] = params3;
				params[4] = params4;
				params[5] = params5;
				params[6] = params6;
				params[7] = params7;
				params[8] = params8;
				params[9] = params9;
				params[10] = params10;
				params[11] = params11;
				params[12] = params12;
				params[13] = params16;
				params[14] = Integer.parseInt(part_status);;
				query = FMSQueryConstants.RETRIEVE_FINANCIAL_VIEW_FORECASTED_DETAILS;
				status= true;
			}

		} else if("".equals(chartType) || chartType.isEmpty() || chartType.equalsIgnoreCase("PMO - Trend")){
			params = new Object[14];
			params[0] = params0;
			params[1] = params1;
			params[2] = params2;
			params[3] = params3;
			params[4] = params4;
			params[5] = params5;
			params[6] = params6;
			params[7] = params7;
			params[8] = params8;
			params[9] = params9;
			params[10] = params10;
			params[11] = params11;
			params[12] = params12;
			params[13] = params13;
			if(FMSVariableConstants.CURRENT.equals(Utils.getValidation(filterData.get(FMSVariableConstants.SALESYRQTR)))){
				query = FMSQueryConstants.RETRIVE_PMO_DATA + " AND COALESCE(fed.p_r_by_o,'NULL_PRBYO')~* '"+ Utils.getValidation(filterData.get(FMSVariableConstants.P_R_BY_O))  +"' AND (fim.sales_date_year_qtr in (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) or fed.p_forecast_status = 'A' ) and (fed.p_forecast_status <> 'R' or fed.p_forecast_status is null) order by fed.p_cm_dollar_by_1000 DESC"; 
			} else {
				query = FMSQueryConstants.RETRIVE_PMO_DATA + " AND COALESCE(fed.p_r_by_o,'NULL_PRBYO')~* '"+ Utils.getValidation(filterData.get(FMSVariableConstants.P_R_BY_O))  +"' AND (fim.sales_date_year_qtr in(((extract(year from now()+ (interval '3 month'))||'-'||extract(quarter from current_timestamp+ (interval '3 month')))), ((extract(year from now()+ (interval '6 month'))||'-'||extract(quarter from current_timestamp+ (interval '6 month')))), ((extract(year from now()+ (interval '9 month'))||'-'||extract(quarter from current_timestamp+ (interval '9 month')))), ((extract(year from now()+ (interval '12 month'))||'-'||extract(quarter from current_timestamp+ (interval '12 month'))))) or fed.p_forecast_status = 'R') and (fed.p_forecast_status <> 'A' or fed.p_forecast_status is null) order by fed.p_cm_dollar_by_1000 DESC";
			}
		} else {
			params = new Object[15];
			params[0] = params0;
			params[1] = params1;
			params[2] = params2;
			params[3] = params3;
			params[4] = params4;
			params[5] = params5;
			params[6] = params6;
			params[7] = params7;
			params[8] = params8;
			params[9] = params9;
			params[10] = params10;
			params[11] = params11;
			params[12] = params12;
			params[13] = params14;
			params[14] = params15;

			if(FMSVariableConstants.BOXOLDDOGSCAP.equalsIgnoreCase(chartType)){
				query = FMSQueryConstants.RETRIEVE_PMO_BOX_OLD_DOGS_DETAILS_DATA;
			} else if (FMSVariableConstants.CWDEXPIREDCAP.equalsIgnoreCase(chartType)){
				query = FMSQueryConstants.RETRIEVE_PMO_CWD_EXPIRED_DETAILS_DATA;
			} else if(FMSVariableConstants.PROMISEDATECAP.equalsIgnoreCase(chartType)) {
				query = FMSQueryConstants.RETRIEVE_PMO_PROMISE_DATE_DETAILS_DATA;
			} else if(FMSVariableConstants.DUMMYCODESCAP.equalsIgnoreCase(chartType)) {
				query = FMSQueryConstants.RETRIEVE_PMO_DUMMY_CODES_DETAILS_DATA;
			}
		}

		if("".equals(Utils.getValidation(filterData.get(FMSVariableConstants.PROJECTMANAGER)))){
			query = query + " LIMIT 300";
		}
		List<Map<String, Object>> pmoData = jdbc.query(query,params, new MiscRowMapper());
		Set<Object> projectManager = new HashSet<>();
		Set<Object> partStatus = new HashSet<>();
		for (Map<String, Object> map : pmoData) {
			projectManager.add(map.get(FMSVariableConstants.PROJECTMANAGER_WITH_UNDERSCORE));
			if(status){
				partStatus.add(map.get(FMSVariableConstants.PARTS_STATUS));
			}
		}
		pmoChartDetailsData.put(FMSVariableConstants.TABLECOLUMNHEADERS, jdbc.query(FMSQueryConstants.RETRIVE_PMO_HEADER, new MiscRowMapper()));
		pmoChartDetailsData.put(FMSVariableConstants.TABLEDATA , pmoData);
		pmoChartDetailsData.put(FMSVariableConstants.PROJECTMANAGER , projectManager);
		pmoChartDetailsData.put(FMSVariableConstants.PARTS_STATUS , partStatus);

		return pmoChartDetailsData;

	}

	public void exportCSVFromMaster(HttpServletResponse responses) {
		String sqlQuery = FMSQueryConstants.MASTER_EXPT;
		exportCSVData(responses, sqlQuery, "IPM-Master-Data");
	}


	@Override
	public FMSOutageMetricsDetailsDTO getOutageMetricsData(Map<String, Object> data) {
		FMSOutageMetricsDetailsDTO result = new FMSOutageMetricsDetailsDTO();
		List<FMSOutageMetricsTechDTO> technologyDetails = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_TECH_METRICS_DATA,new Object[]{Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR))}, new FMSOutageTechMetricsMapper());
		List<FMSOutageMetricsCustomerDTO> topCustomer = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_CUST_METRICS_DATA,new Object[]{Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR)),Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR))}, new FMSOutageCustomerMetricsMapper());
		result.setTechnologyDetails(technologyDetails);
		result.setTopCustomer(topCustomer);

		return result;
	}

	@Override
	public List<FMSOutageDataBean> getOutageData(Map<String, Object> data) {
		String type = Utils.getValidation(data.get(FMSVariableConstants.TYPE));
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		if(type.equalsIgnoreCase(FMSVariableConstants.DEFAULT)){

			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.YEAR, -5);

			return jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DATA,new Object[]{marketIndustry}, new OutageDataMapper());

		}else{
			return jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DATA_ORIGINAL,new Object[]{marketIndustry}, new OutageDataMapper());
		}
	}


	@Override
	public FMSOutageDropdownDTO getOutageDropdown(Map<String, Object> data) {

		FMSOutageDropdownDTO outageDropdownData = new FMSOutageDropdownDTO();
		String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));
		List<FMSSiteCustomerNameDropdownBean> outageCustName = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_CUSTOMER_NAME,new Object[]{accountManager}, new FMSSiteCustomerNameMapper());
		List<FMSTechnologyDropdownBean> outageTechnology = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_TECHNOLOGY,new Object[]{accountManager}, new FMSTechnologyDropdownMapper());
		List<FMSEquipCodeDropdownBean> outageEquip = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_EQUIPMENT,new Object[]{accountManager}, new FMSEquipCodeDropdownMapper());
		List<FMSOutLocationDTO> outageLocation = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_OEM_LOCATION,new Object[]{accountManager}, new FMSOutLocationMapper());
		List<FMSUnitStatusDesDropdownBean> outageUnitStatus = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_UNIT_STATUS,new Object[]{accountManager}, new FMSUnitStatusDropdownMapper());
		List<FMSSrcNewSegmentDropdownBean> outageSegment = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_MARKET_SEGMENT,new Object[]{accountManager}, new FMSSrcNewSegmentDropdownMapper());
		List<FMSServRelDescOngDropdownBean> outageRelation = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_SERVICE_RELATION,new Object[]{accountManager}, new FMSServRelDescDropdownMapper());
		List<FMSRegionDropdownBean> outageRegion = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_SALES_REGION,new Object[]{accountManager}, new FMSRegionDropdownMapper());
		List<FMSCurrentYearDTO> outageYearQtr = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_YEAR_QTR,new Object[]{accountManager},new FMSCurrentYearMapper());
		List<FMSCountryNameDropdownBean> outageCountry = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_COUNTRY,new Object[]{accountManager}, new FMSCountryNameDropdownMapper());
		List<FMSCustomerDropdownBean> outageDunsName= jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_DUNS_NAME,new Object[]{accountManager}, new FMSCustomerDropdownMapper());
		List<FMSAccMgrEmailDropdownBean> outageaccMgrEmail= jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_ACCOUNT_MGR_EMAIL,new Object[]{accountManager}, new FMSAccMgrEmailDropdownMapper());
		List<FMSServiceMgrEmailDropdownBean> outageserviceMgrEmail= jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_SERVICE_MGR_EMAIL,new Object[]{accountManager}, new FMSServiceMgrEmailDropdownMapper());
		List<FMSDMMaintLvlDescDTO> maintLvlDescDTO= jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_MAINT_LVL_DESC,new Object[]{accountManager}, new FMSDMMaintLvlDescMapper());
		List<FMSMaintLvlStatusBean> maintLvlStatus= jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_DROPDOWN_EVENT_STATUS,new Object[]{accountManager}, new FMSEventStatusDescMapper());

		outageDropdownData.setOutageCustName(outageCustName); 
		outageDropdownData.setOutageTechnology(outageTechnology);
		outageDropdownData.setOutageEquip(outageEquip);
		outageDropdownData.setOutageLocation(outageLocation);
		outageDropdownData.setOutageUnitStatus(outageUnitStatus);
		outageDropdownData.setOutageSegment(outageSegment);
		outageDropdownData.setOutageRelation(outageRelation);
		outageDropdownData.setOutageRegion(outageRegion);
		outageDropdownData.setOutageYearQtr(outageYearQtr);
		outageDropdownData.setOutageCountry(outageCountry);
		outageDropdownData.setOutageDunsName(outageDunsName);
		outageDropdownData.setOutageaccMgrEmail(outageaccMgrEmail);
		outageDropdownData.setOutageserviceMgrEmail(outageserviceMgrEmail);
		outageDropdownData.setMaintLvlDescDTO(maintLvlDescDTO);
		outageDropdownData.setMaintLvlStatus(maintLvlStatus);
		return outageDropdownData;
	}

	@Override
	public FMSOutageFilterVO getOutageFilterDataRegion(FMSOutageFilterDataDTO filterData) {
		FMSOutageFilterVO resultsVO = new FMSOutageFilterVO();	

		List<FMSOutageFilterTechDTO> technologyData = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_TECH_METRICS_FILTER_DATA,new Object[]{Utils.getValidation(filterData.getOutageYear()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageQuarter()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageCustomerName()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageTechnology()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageEquipment()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageLocation()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageUnitStatus()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageSegment()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageServiceRel()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageRegion()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageCountry()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageDunsName()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageAccMgrEmail()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageServiceMgrEmail()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageMaintLvlDesc()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageEvntStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOutageAccountManager())}, new FMSOutageFilterTechRegMapper());
		List<FMSOutageFilterCustDTO> custNameData = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_CUST_METRICS_FILTER_DATA,new Object[]{Utils.getValidation(filterData.getOutageYear()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageQuarter()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageCustomerName()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageTechnology()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageEquipment()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageLocation()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageUnitStatus()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageSegment()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageServiceRel()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageRegion()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageCountry()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageDunsName()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageAccMgrEmail()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageServiceMgrEmail()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageMaintLvlDesc()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageEvntStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOutageAccountManager()), Utils.getValidation(filterData.getOutageYear()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageQuarter()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageCustomerName()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageTechnology()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageEquipment()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageLocation()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageUnitStatus()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageSegment()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageServiceRel()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageRegion()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageCountry()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageDunsName()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageAccMgrEmail()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageServiceMgrEmail()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageMaintLvlDesc()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageEvntStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOutageAccountManager())}, new FMSOutageFilterCustRegMapper());

		resultsVO.setOutageTechnologies(technologyData);
		resultsVO.setOutageCustomers(custNameData);
		return resultsVO;
	}

	@Override
	public FMSOutageFilterVO getOutageFilterDataCountry(FMSOutageFilterDataDTO filterData) {
		FMSOutageFilterVO resultsVO = new FMSOutageFilterVO();	
		List<FMSOutageFilterTechDTO> technologyData = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_TECH_FILTER_COUNTRY_DATA,new Object[]{Utils.getValidation(filterData.getOutageYear()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageQuarter()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageCustomerName()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageTechnology()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageEquipment()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageLocation()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageUnitStatus()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageSegment()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageServiceRel()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageRegion()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageCountry()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageDunsName()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageAccMgrEmail()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageServiceMgrEmail()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageMaintLvlDesc()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageEvntStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOutageAccountManager())}, new FMSOutageFilterTechCountryMapper());
		List<FMSOutageFilterCustDTO> custNameData = jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_CUST_METRICS_COUNTRY_DATA,new Object[]{Utils.getValidation(filterData.getOutageYear()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageQuarter()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageCustomerName()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageTechnology()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageEquipment()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageLocation()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageUnitStatus()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageSegment()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageServiceRel()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageRegion()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageCountry()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageDunsName()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageAccMgrEmail()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageServiceMgrEmail()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageMaintLvlDesc()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageEvntStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOutageAccountManager()), Utils.getValidation(filterData.getOutageYear()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageQuarter()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageCustomerName()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageTechnology()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageEquipment()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageLocation()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageUnitStatus()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageSegment()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageServiceRel()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageRegion()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageCountry()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageDunsName()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageAccMgrEmail()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageServiceMgrEmail()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageMaintLvlDesc()).replaceAll("[()]", "1"), Utils.getValidation(filterData.getOutageEvntStatusDesc()).replaceAll("[()]", "1"),Utils.getValidation(filterData.getOutageAccountManager())}, new FMSOutageFilterCustCountryMapper());

		resultsVO.setOutageTechnologies(technologyData);
		resultsVO.setOutageCustomers(custNameData);
		return resultsVO;
	}

	@Override
	public void exportPMODrilDownData(HttpServletResponse responses, Map<String, Object> filterData) {
		try {
			String postQuery = "";
			String params0 = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
			String params1 = Utils.getValidation(filterData.get(FMSVariableConstants.PANDL));
			String params2 = Utils.getValidation(filterData.get(FMSVariableConstants.PRODUCT));
			String params3 = Utils.getValidation(filterData.get(FMSVariableConstants.OUNAME));
			String params4 = Utils.getValidation(filterData.get(FMSVariableConstants.OGREGION));
			String params5 = Utils.getValidation(filterData.get(FMSVariableConstants.REGION));
			String params6 = Utils.getValidation(filterData.get(FMSVariableConstants.SUBREGION));
			String params7 = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCOUNTRYDISC));
			String params8 = Utils.getValidation(filterData.get(FMSVariableConstants.MOTHERJOB));
			String params9 = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCUSTNAME));
			String params10 = Utils.getValidation(filterData.get(FMSVariableConstants.COSTINGPROJECT));
			String params11 = Utils.getValidation(filterData.get(FMSVariableConstants.ORDERTYPE));
			String params12 = Utils.getValidation(filterData.get(FMSVariableConstants.PROJECTMANAGER));
			String params13 = Utils.getValidation(filterData.get(FMSVariableConstants.PARTS_STATUS));
			String params14 = Utils.getValidation(filterData.get(FMSVariableConstants.DAYRANGE));
			String params15 = Utils.getValidation(filterData.get(FMSVariableConstants.SALESYRQTR));
			String params16 = Utils.getValidation(filterData.get(FMSVariableConstants.FINANCIALPARTSTATUS));

			String chartType = Utils.getValidation(filterData.get(FMSVariableConstants.CHARTTYPE));
			String  sales_qtr = Utils.getValidation(filterData.get(FMSVariableConstants.SALESYRQTR));

			String commonWhereQuery=" WHERE COALESCE(fim.new_p_and_l,'') ~*'"+ params0 + "' AND COALESCE(fim.p_and_l,'') ~* '"+ params1 + "' AND COALESCE(fim.product,'') ~* '"+ params2 + "' AND COALESCE(fim.ou_name,'') ~* '"+ params3 + "' AND COALESCE(fim.og_region,'') ~* '"+ params4 + "' AND COALESCE(fim.region,'') ~* '"+ params5 + "' AND COALESCE(fim.subregion,'') ~* '"+ params6 + "' AND COALESCE(fim.end_user_country_disc,'') ~* '" + params7 + "' AND COALESCE(fim.mother_job,'') ~* '"+ params8 + "' AND COALESCE(fim.enduser_cust_name,'') ~* '"+ params9 + "' AND COALESCE(fim.costing_project,'') ~* '"+ params10 + "' AND COALESCE(fim.order_type,'') ~* '"+ params11 + "' AND COALESCE(fim.project_manager,'')~* '"+ params12 + "'";

			if("".equals(chartType) || chartType.isEmpty() || FMSVariableConstants.FINANCIAL_VIEW.equalsIgnoreCase(chartType)){
				String part_status = params13.replace("FW", "");
				if("OLD".equalsIgnoreCase(part_status)) {
					postQuery = FMSQueryConstants.EXPORT_PMO_DATA + " where new_p_and_l ='" + params0 + "' AND UPPER(invoice_status) = 'U' AND fim.sales_date_year_qtr < (extract(Year from current_timestamp)||'-'||extract (quarter from current_timestamp))";
				} else if (FMSVariableConstants.CONFIRMED.equalsIgnoreCase(sales_qtr)) {
					postQuery = FMSQueryConstants.EXPORT_PMO_DATA + commonWhereQuery  + " AND COALESCE(fim.parts_status,'BLANK')~* '"+ params16 + "'" + " AND UPPER(invoice_status) = 'C' AND Extract(week from COALESCE(pef.p_new_date, sales_date)) <=" + Integer.parseInt(part_status) + " AND Extract(year from COALESCE(pef.p_new_date, sales_date)) = Extract(year from current_timestamp)";
				} else if ("UNCONFIRMED".equalsIgnoreCase(sales_qtr)) {
					postQuery = FMSQueryConstants.EXPORT_PMO_DATA + commonWhereQuery + " AND COALESCE(fim.parts_status,'BLANK')~* '"+ params16 + "'" + "AND UPPER(invoice_status) = 'U' AND Extract(year from COALESCE(fed.p_new_date, sales_date)) = Extract(year from current_timestamp) AND Extract(week from COALESCE(fed.p_new_date, sales_date)) <=" + Integer.parseInt(part_status) + " UNION " + FMSQueryConstants.EXPORT_PMO_DATA + " where new_p_and_l ='" + params0 + "' AND UPPER(invoice_status) = 'U' AND fim.sales_date_year_qtr < (extract(Year from current_timestamp)||'-'||extract (quarter from current_timestamp)) AND COALESCE(fim.project_manager,'') ~* '"+ params12 + "'";
				} else if ("FORECASTED".equalsIgnoreCase(sales_qtr)){
					postQuery = FMSQueryConstants.EXPORT_PMO_DATA + commonWhereQuery + " AND COALESCE(fim.parts_status,'BLANK')~* '"+ params16 + "'" + "AND Extract(week from COALESCE(fed.p_new_date, sales_date)) <=" + Integer.parseInt(part_status) + " AND Extract(year from COALESCE(fed.p_new_date, sales_date)) = Extract(year from current_timestamp)";
				}

			} else if("".equals(chartType) || chartType.isEmpty() || FMSVariableConstants.PMO_TREND.equalsIgnoreCase(chartType)){
				postQuery= commonWhereQuery +   " AND COALESCE(fim.parts_status,'BLANK')~* '"+ params13 + "'";
				if(FMSVariableConstants.CURRENT.equals(Utils.getValidation(filterData.get(FMSVariableConstants.SALESYRQTR)))){
					postQuery = postQuery + " AND (fim.sales_date_year_qtr in (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) or fed.p_forecast_status = 'A' ) and (fed.p_forecast_status <> 'R' or fed.p_forecast_status is null)";
				} else {
					postQuery = postQuery + " AND (fim.sales_date_year_qtr in(((extract(year from now()+ (interval '3 month'))||'-'||extract(quarter from current_timestamp+ (interval '3 month')))), ((extract(year from now()+ (interval '6 month'))||'-'||extract(quarter from current_timestamp+ (interval '6 month')))), ((extract(year from now()+ (interval '9 month'))||'-'||extract(quarter from current_timestamp+ (interval '9 month')))), ((extract(year from now()+ (interval '12 month'))||'-'||extract(quarter from current_timestamp+ (interval '12 month'))))) or fed.p_forecast_status = 'R') and (fed.p_forecast_status <> 'A' or fed.p_forecast_status is null)";
				}
				postQuery = FMSQueryConstants.EXPORT_PMO_DATA + postQuery;

			}	else {
				if(FMSVariableConstants.BOXOLDDOGSCAP.equalsIgnoreCase(chartType)){
					postQuery = FMSQueryConstants.EXPORT_PMO_DATA.replaceAll("from fms_ipm_master fim left outer join fms_ipm_parts_edit_fields fed on fim.concatenate = fed.p_concatenate", "") + " from ( Select case when days >= 0 and days <= 30 then '0-30 days' when days >= 31 and days <= 60 then '31-60 days' when days >= 61 and days <= 90 then '61-90 days' when days >90 then '90 days' end as day_range,* from ( SELECT new_p_and_l,p_and_l,ou_name,project_manager,product, og_region,region,mother_job,costing_project,booking_date,booking_date_year_mnth,end_user_country_disc,buyer_cust_name,customer_po_number, cm_global_contract , contr_par_ship_allwd,  early_delivery_allowed, delivery_term, so_line, ordered_quantity,so_cwd, sales_date,basket,line_sales_forecast_dollar,line_cm_forecast_dollar,line_sales_actual_dollar, line_cm_actual_dollar,i_c, tp_rate, unit_cost,unit_true_cost,line_true_cost, transfer_price, actual_cost,box_closure_date,actual_shipment_date, invoice_status_change_date,  concatenate,line_id,item_description, po_promise_date, p_cm_dollar_by_1000, p_r_by_o, p_status, p_trend, p_note,p_due_date, box_number,enduser_cust_name,invoice_number,p_wb_comment,p_new_date,p_flow_or_no_flow, p_exp_fw_revrec_firts_pl, p_exp_fw_revrec, p_sum_sales, p_keydeals,p_financial_basket, p_operational_basket, p_sum_cm,p_status_aging,item_code, sales_date_year_qtr ,(case when sales_date_year_qtr = (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) then 'GREEN' else 'GREY' end) as b_tool, fim.parts_status, (extract(days from now() - fim.box_closure_date)) as days,(case when (fim.sales_date_year_qtr in (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) or fed.p_forecast_status = 'A' ) and (fed.p_forecast_status <> 'R' or fed.p_forecast_status is null) then 'CURRENT' else 'FUTURE' end) as sales_year_qtr from fms_ipm_master fim join fms_ipm_parts_edit_fields fed on fim.concatenate = fed.p_concatenate"
							+ commonWhereQuery
							+ "  AND fim.sales_date_year_qtr in (((extract(year from now())||'-'||extract(quarter from current_timestamp))), ((extract(year from now() + (interval '3 month'))||'-'||extract(quarter from current_timestamp + (interval '3 month')))), ((extract(year from now() + (interval '6 month'))||'-'||extract(quarter from current_timestamp + (interval '6 month')))), ((extract(year from now() + (interval '9 month'))||'-'||extract(quarter from current_timestamp + (interval '9 month')))), ((extract(year from now() + (interval '12 month'))||'-'||extract(quarter from current_timestamp + (interval '12 month'))))) AND UPPER(parts_status) = 'SHIPPING' AND fim.box_closure_date IS NOT NULL ) inner1 )inner2  WHERE day_range = '" + params14  + "' and sales_year_qtr ='" + params15 + "'" ; 

				} else if (FMSVariableConstants.CWDEXPIREDCAP.equalsIgnoreCase(chartType)){
					postQuery = FMSQueryConstants.EXPORT_PMO_DATA.replaceAll("from fms_ipm_master fim left outer join fms_ipm_parts_edit_fields fed on fim.concatenate = fed.p_concatenate", "") + " from ( Select case when days >= 0 and days <= 10 then '0-10 days' when days >= 11 and days <= 20 then '11-20 days' when days >= 21 and days <= 30 then '21-30 days' when days >30 then '30 days' end as day_range, * from ( SELECT parts_status,extract(days from now() - fim.so_cwd) as days,item_description,new_p_and_l,p_and_l,ou_name,project_manager,product, og_region,region,mother_job,costing_project,booking_date,booking_date_year_mnth,end_user_country_disc,buyer_cust_name,customer_po_number, cm_global_contract , contr_par_ship_allwd,  early_delivery_allowed, delivery_term, so_line, ordered_quantity,so_cwd, sales_date,basket,line_sales_forecast_dollar,line_cm_forecast_dollar,line_sales_actual_dollar, line_cm_actual_dollar,i_c, tp_rate, unit_cost,unit_true_cost,line_true_cost, transfer_price, actual_cost,box_closure_date,actual_shipment_date, invoice_status_change_date,  concatenate,line_id,po_promise_date, p_cm_dollar_by_1000, p_r_by_o, p_status, p_trend, p_note,p_due_date, box_number,enduser_cust_name,invoice_number,p_wb_comment,p_new_date,p_flow_or_no_flow, p_exp_fw_revrec_firts_pl, p_exp_fw_revrec, p_sum_sales, p_keydeals,p_financial_basket, p_operational_basket, p_sum_cm,p_status_aging,item_code, sales_date_year_qtr ,(case when sales_date_year_qtr = (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) then 'GREEN' else 'GREY' end) as b_tool, (case when (fim.sales_date_year_qtr in (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) or fed.p_forecast_status = 'A' ) and (fed.p_forecast_status <> 'R' or fed.p_forecast_status is null) then 'CURRENT' else 'FUTURE' end) as sales_year_qtr from fms_ipm_master fim join fms_ipm_parts_edit_fields fed on fim.concatenate = fed.p_concatenate"
							+ commonWhereQuery
							+ "  AND fim.sales_date_year_qtr in (((extract(year from now())||'-'||extract(quarter from current_timestamp))), ((extract(year from now() + (interval '3 month'))||'-'||extract(quarter from current_timestamp + (interval '3 month')))), ((extract(year from now() + (interval '6 month'))||'-'||extract(quarter from current_timestamp + (interval '6 month')))), ((extract(year from now() + (interval '9 month'))||'-'||extract(quarter from current_timestamp + (interval '9 month')))), ((extract(year from now() + (interval '12 month'))||'-'||extract(quarter from current_timestamp + (interval '12 month'))))) AND UPPER(parts_status) = 'INCOMING' AND fim.so_cwd IS NOT NULL AND extract(days from now() - fim.so_cwd) > 0 ) inner1 )inner2 WHERE day_range = '" + params14  + "' and sales_year_qtr ='" + params15 + "'" ; 

				} else if(FMSVariableConstants.PROMISEDATECAP.equalsIgnoreCase(chartType)) {
					postQuery = FMSQueryConstants.EXPORT_PMO_DATA.replaceAll("from fms_ipm_master fim left outer join fms_ipm_parts_edit_fields fed on fim.concatenate = fed.p_concatenate", "") + " from ( Select case when days >= 0 and days <= 10 then '0-10 days' when days >= 11 and days <= 20 then '11-20 days' when days >= 21 and days <= 30 then '21-30 days' when days >30 then '30 days' end as day_range,* from ( SELECT parts_status,extract(days from fim.promise_date - Now()) as days,item_description,new_p_and_l,p_and_l,ou_name,project_manager,product, og_region,region,mother_job,costing_project,booking_date,booking_date_year_mnth,end_user_country_disc,buyer_cust_name,customer_po_number, cm_global_contract , contr_par_ship_allwd,  early_delivery_allowed, delivery_term, so_line, ordered_quantity,so_cwd, sales_date,basket,line_sales_forecast_dollar,line_cm_forecast_dollar,line_sales_actual_dollar, line_cm_actual_dollar,i_c, tp_rate, unit_cost,unit_true_cost,line_true_cost, transfer_price, actual_cost,box_closure_date,actual_shipment_date, invoice_status_change_date,  concatenate,line_id,po_promise_date, p_cm_dollar_by_1000, p_r_by_o, p_status, p_trend, p_note,p_due_date, box_number,enduser_cust_name,invoice_number,p_wb_comment,p_new_date,p_flow_or_no_flow, p_exp_fw_revrec_firts_pl, p_exp_fw_revrec, p_sum_sales, p_keydeals,p_financial_basket, p_operational_basket, p_sum_cm,p_status_aging,item_code, sales_date_year_qtr ,(case when fim.sales_date_year_qtr = (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) then 'GREEN' else 'GREY' end) as b_tool, (case when (fim.sales_date_year_qtr in (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) or fed.p_forecast_status = 'A' ) and (fed.p_forecast_status <> 'R' or fed.p_forecast_status is null) then 'CURRENT' else 'FUTURE' end) as sales_year_qtr from fms_ipm_master fim join fms_ipm_parts_edit_fields fed on fim.concatenate = fed.p_concatenate"
							+ commonWhereQuery
							+ "  AND fim.sales_date_year_qtr in (((extract(year from now())||'-'||extract(quarter from current_timestamp))) , ((extract(year from now() + (interval '3 month'))||'-'||extract(quarter from current_timestamp + (interval '3 month')))), ((extract(year from now() + (interval '6 month'))||'-'||extract(quarter from current_timestamp + (interval '6 month')))), ((extract(year from now() + (interval '9 month'))||'-'||extract(quarter from current_timestamp + (interval '9 month')))), ((extract(year from now() + (interval '12 month'))||'-'||extract(quarter from current_timestamp + (interval '12 month')))) ) AND UPPER(parts_status) = 'INCOMING' AND fim.promise_date IS NOT NULL AND extract(days from fim.promise_date - Now()) > 0) inner1 )inner2 where day_range = '" + params14  + "' and sales_year_qtr ='" + params15 + "'" ; 

				} else if(FMSVariableConstants.DUMMYCODESCAP.equalsIgnoreCase(chartType)) {
					postQuery = FMSQueryConstants.EXPORT_PMO_DATA.replaceAll("from fms_ipm_master fim left outer join fms_ipm_parts_edit_fields fed on fim.concatenate = fed.p_concatenate", "") + " from (SELECT  parts_status,new_p_and_l,p_and_l,ou_name,project_manager,product, og_region,region,mother_job,costing_project,booking_date,booking_date_year_mnth,end_user_country_disc,buyer_cust_name,customer_po_number, cm_global_contract , contr_par_ship_allwd,  early_delivery_allowed, delivery_term, so_line, ordered_quantity,so_cwd, sales_date,basket,line_sales_forecast_dollar,line_cm_forecast_dollar,line_sales_actual_dollar, line_cm_actual_dollar,i_c, tp_rate, unit_cost,unit_true_cost,line_true_cost, transfer_price, actual_cost,box_closure_date,actual_shipment_date, invoice_status_change_date,  concatenate,line_id,po_promise_date, p_cm_dollar_by_1000, p_r_by_o, p_status, p_trend, p_note,p_due_date, box_number,enduser_cust_name,invoice_number,p_wb_comment,p_new_date,p_flow_or_no_flow, p_exp_fw_revrec_firts_pl, p_exp_fw_revrec, p_sum_sales, p_keydeals,p_financial_basket, p_operational_basket, p_sum_cm,p_status_aging,item_code, sales_date_year_qtr ,(case when sales_date_year_qtr = (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) then 'GREEN' else 'GREY' end) as b_tool, UPPER(item_description) as item_description, (case when (fim.sales_date_year_qtr in (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) or fed.p_forecast_status = 'A' ) and (fed.p_forecast_status <> 'R' or fed.p_forecast_status is null) then 'CURRENT' else 'FUTURE' end) as sales_year_qtr, 'DUMMY CODES' as type from fms_ipm_master fim join fms_ipm_parts_edit_fields fed on fim.concatenate = fed.p_concatenate"
							+ commonWhereQuery
							+ " AND fim.sales_date_year_qtr in (((extract(year from now())||'-'||extract(quarter from current_timestamp))), ((extract(year from now() + (interval '3 month'))||'-'||extract(quarter from current_timestamp + (interval '3 month')))), ((extract(year from now() + (interval '6 month'))||'-'||extract(quarter from current_timestamp + (interval '6 month')))), ((extract(year from now() + (interval '9 month'))||'-'||extract(quarter from current_timestamp + (interval '9 month')))), ((extract(year from now() + (interval '12 month'))||'-'||extract(quarter from current_timestamp + (interval '12 month'))))) AND UPPER(item_description) in ('ITEM TO BE DEFINED', 'CODE TO BE CREATED', 'ORDER ACKNOWLEDGEMENT', 'OTHER') AND UPPER(parts_status) = 'INCOMING') innerQuery where item_description = '" + params14  + "' and sales_year_qtr ='" + params15 + "'" ; 

				}
			}

			exportCSVData(responses, postQuery,  chartType + "-" + sales_qtr );
		}catch(Exception e){
			log.info(e);
		}
	}



	@Transactional
	@Override
	public void getOracleServiceRequestData(){
		List<String> machineTechnology = new ArrayList<>();
		jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.IN_PROGRESS,"Data fetching Started for SR","getOracleServiceRequestData"});
		int delRow = jdbc.update(FMSQueryConstants.TRUNCATE_ORACLE_SERVICE_REQ_DATA);
		log.info("Oracle data of service request cleared. "+delRow);
		List<Map<String, String>> rows=null;
		try{
			machineTechnology = akanaHandler.execute("getServiceRequestMacTech", HttpMethod.GET, null);
		} catch(Exception e) {
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleServiceRequestData~akanaHandler~getServiceRequestMacTech"});
			log.info("Erors in getServiceRequestMacTech" + e);
		}      
		for(int index=0;index<machineTechnology.size();index++){
			log.info("machineTechnology index  : "+Utils.getValidation(machineTechnology.get(index)));
			Map<String,String> postData = new HashMap<>();
			postData.put("machineTech", Utils.getValidation(machineTechnology.get(index)));
			try{
				rows = akanaHandler.execute("getServiceRequestdata", HttpMethod.POST, postData);
			}catch(Exception e){
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleServiceRequestData~akanaHandler~getServiceRequestdata"});
				log.error("getServiceRequestdata data akana handler error" + e.getStackTrace());
			}
			for(Map<String, String> row : rows){
				Object[] params = new Object[row.keySet().size()];
				List<String> keys = new ArrayList<>();
				for(String key:row.keySet()){
					keys.add(key);
				}
				for(int i=0;i<keys.size();i++) {
					String key = keys.get(i);
					params[i] = row.get(key);
				}

				try{
					jdbc.update(FMSQueryConstants.INSERT_SERVICE_REQUEST_DATA, params);
				}catch(Exception e){
					jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleServiceRequestData~DataInsertion"});
				}
			}
		}
		String info = jdbc.queryForObject(FMSQueryConstants.SERVICE_REQ_MAPPING,new Object[]{FMSVariableConstants.SUCCESS.toLowerCase()},String.class);
		jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Data Insertion Successful & Mapping Done ","getOracleServiceRequestData"});
		log.info("Mapping successful : "+info);
	}

	@Override
	public Map<String, Object> getServiceReqMetricsFilterData(Map<String, Object> data) {
		Map<String,Object> resultMap = new HashMap<>();
		try {
			int count = 0;

			Object[] params = new Object[26];
			params[0] = Utils.getValidation(data.get(FMSVariableConstants.CASE_NUMBER)).replaceAll("[()]", "1");
			params[1] = Utils.getValidation(data.get(FMSVariableConstants.OPENED)).replaceAll("[()]", "1");
			params[2] = Utils.getValidation(data.get(FMSVariableConstants.TYPE_OF_ISSUE)).replaceAll("[()]", "1");
			params[3] = Utils.getValidation(data.get(FMSVariableConstants.PROJECT_PHASE)).replaceAll("[()]", "1");
			params[4] = Utils.getValidation(data.get(FMSVariableConstants.STATE)).replaceAll("[()]", "1");
			params[5] = Utils.getValidation(data.get(FMSVariableConstants.ASSGND_GRP)).replaceAll("[()]", "1");
			params[6] = Utils.getValidation(data.get(FMSVariableConstants.STATUS)).replaceAll("[()]", "1");
			params[7] = Utils.getValidation(data.get(FMSVariableConstants.ENTRY_IN_CUR_STATUS)).replaceAll("[()]", "1");
			params[8] = Utils.getValidation(data.get(FMSVariableConstants.JOB_TYPE)).replaceAll("[()]", "1");
			params[9] = Utils.getValidation(data.get(FMSVariableConstants.CSTMR_NAME)).replaceAll("[()]", "1");
			params[10] = Utils.getValidation(data.get(FMSVariableConstants.MAC_TECHNOLOGY)).replaceAll("[()]", "1");
			params[11] = Utils.getValidation(data.get(FMSVariableConstants.EVENT_YEAR)).replaceAll("[()]", "1");
			params[12] = Utils.getValidation(data.get(FMSVariableConstants.EVENT_QUARTER)).replaceAll("[()]", "1");	
			params[13] = Utils.getValidation(data.get(FMSVariableConstants.CASE_NUMBER)).replaceAll("[()]", "1");
			params[14] = Utils.getValidation(data.get(FMSVariableConstants.OPENED)).replaceAll("[()]", "1");
			params[15] = Utils.getValidation(data.get(FMSVariableConstants.TYPE_OF_ISSUE)).replaceAll("[()]", "1");
			params[16] = Utils.getValidation(data.get(FMSVariableConstants.PROJECT_PHASE)).replaceAll("[()]", "1");
			params[17] = Utils.getValidation(data.get(FMSVariableConstants.STATE)).replaceAll("[()]", "1");
			params[18] = Utils.getValidation(data.get(FMSVariableConstants.ASSGND_GRP)).replaceAll("[()]", "1");
			params[19] = Utils.getValidation(data.get(FMSVariableConstants.STATUS)).replaceAll("[()]", "1");
			params[20] = Utils.getValidation(data.get(FMSVariableConstants.ENTRY_IN_CUR_STATUS)).replaceAll("[()]", "1");
			params[21] = Utils.getValidation(data.get(FMSVariableConstants.JOB_TYPE)).replaceAll("[()]", "1");
			params[22] = Utils.getValidation(data.get(FMSVariableConstants.CSTMR_NAME)).replaceAll("[()]", "1");
			params[23] = Utils.getValidation(data.get(FMSVariableConstants.MAC_TECHNOLOGY)).replaceAll("[()]", "1");
			params[24] = Utils.getValidation(data.get(FMSVariableConstants.EVENT_YEAR)).replaceAll("[()]", "1");
			params[25] = Utils.getValidation(data.get(FMSVariableConstants.EVENT_QUARTER)).replaceAll("[()]", "1");

			int paramLength = params.length;
			for(int index=0;index<paramLength;index++){
				if(params[index].equals(FMSVariableConstants.EMPTY_STRING)){
					count++;
				}
			}

			resultMap.put("Technology", jdbc.query(FMSQueryConstants.SERVICE_REQ_METRICS_TECH,new Object[]{Utils.getValidation(data.get(FMSVariableConstants.CASE_NUMBER)).replaceAll("[()]", "1"), Utils.getValidation(data.get(FMSVariableConstants.OPENED)).replaceAll("[()]", "1"), Utils.getValidation(data.get(FMSVariableConstants.TYPE_OF_ISSUE)).replaceAll("[()]", "1"), Utils.getValidation(data.get(FMSVariableConstants.PROJECT_PHASE)).replaceAll("[()]", "1"), Utils.getValidation(data.get(FMSVariableConstants.STATE)).replaceAll("[()]", "1"), Utils.getValidation(data.get(FMSVariableConstants.ASSGND_GRP)).replaceAll("[()]", "1"), Utils.getValidation(data.get(FMSVariableConstants.STATUS)).replaceAll("[()]", "1"), Utils.getValidation(data.get(FMSVariableConstants.ENTRY_IN_CUR_STATUS)).replaceAll("[()]", "1"), Utils.getValidation(data.get(FMSVariableConstants.JOB_TYPE)).replaceAll("[()]", "1"), Utils.getValidation(data.get(FMSVariableConstants.CSTMR_NAME)).replaceAll("[()]", "1"), Utils.getValidation(data.get(FMSVariableConstants.MAC_TECHNOLOGY)).replaceAll("[()]", "1"), Utils.getValidation(data.get(FMSVariableConstants.EVENT_YEAR)).replaceAll("[()]", "1"), Utils.getValidation(data.get(FMSVariableConstants.EVENT_QUARTER)).replaceAll("[()]", "1")/*,Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR)).replaceAll("[()]", "1")*/}, new MiscRowMapper()));
			if(count==paramLength){
				resultMap.put("TopCustomers", jdbc.query(FMSQueryConstants.SERVICE_REQ_METRICS_TOPCUSTOMERS_DEFAULT,params, new MiscRowMapper()));
			}else{
				resultMap.put("TopCustomers", jdbc.query(FMSQueryConstants.SERVICE_REQ_METRICS_TOPCUSTOMERS,params, new MiscRowMapper()));
			}
		} catch (Exception e) {
			log.info(FMSVariableConstants.DBEXCEPTION+e);
			log.error(FMSVariableConstants.DBEXCEPTION+ e.getStackTrace());
		}
		return resultMap;
	}

	@Override
	public Map<String, Object> getServiceRequestDropdown() {
		Map<String, Object> serviceRequestDropdown = new HashMap<>();
		try{
			serviceRequestDropdown.put("ServiceRequestCaseNum",jdbc.query(FMSQueryConstants.SERVICE_REQUEST_DROPDOWN_CASE_NUM, new MiscRowMapper()));
			serviceRequestDropdown.put("ServiceRequestOpened",jdbc.query(FMSQueryConstants.SERVICE_REQUEST_DROPDOWN_OPENED, new MiscRowMapper()));
			serviceRequestDropdown.put("ServiceRequestIssue",jdbc.query(FMSQueryConstants.SERVICE_REQUEST_DROPDOWN_ISSUE, new MiscRowMapper()));
			serviceRequestDropdown.put("ServiceRequestProjectPhase",jdbc.query(FMSQueryConstants.SERVICE_REQUEST_DROPDOWN_PROJECT_PHASE, new MiscRowMapper()));
			serviceRequestDropdown.put("ServiceRequestState",jdbc.query(FMSQueryConstants.SERVICE_REQUEST_DROPDOWN_STATE, new MiscRowMapper()));
			serviceRequestDropdown.put("ServiceRequestGroup",jdbc.query(FMSQueryConstants.SERVICE_REQUEST_DROPDOWN_GROUP, new MiscRowMapper()));
			serviceRequestDropdown.put("ServiceRequestStatus",jdbc.query(FMSQueryConstants.SERVICE_REQUEST_DROPDOWN_STATUS, new MiscRowMapper()));
			serviceRequestDropdown.put("ServiceRequestCurStatus",jdbc.query(FMSQueryConstants.SERVICE_REQUEST_DROPDOWN_ENTRY_CUR_STATUS, new MiscRowMapper()));
			serviceRequestDropdown.put("ServiceRequestJob",jdbc.query(FMSQueryConstants.SERVICE_REQUEST_DROPDOWN_JOB, new MiscRowMapper()));
			serviceRequestDropdown.put("ServiceRequestCustomerName",jdbc.query(FMSQueryConstants.SERVICE_REQUEST_DROPDOWN_CUST_NAME, new MiscRowMapper()));
			serviceRequestDropdown.put("ServiceRequestMachineTechnology",jdbc.query(FMSQueryConstants.SERVICE_REQUEST_DROPDOWN_MACHINE_TECH, new MiscRowMapper()));
			serviceRequestDropdown.put("ServiceRequestYearQtr",jdbc.query(FMSQueryConstants.SERVICE_REQUEST_DROPDOWN_YEAR_QTR, new MiscRowMapper()));
		}catch(Exception e){
			log.info(FMSVariableConstants.DBEXCEPTION+e);
			log.error(FMSVariableConstants.DBEXCEPTION+ e.getStackTrace());
		}
		return serviceRequestDropdown;
	}

	@Override
	public Map<String, Object> getServiceRequestMetricsData(Map<String, Object> data) {
		Map<String, Object> serviceRequestmetricsData = new HashMap<>();
		try{
			serviceRequestmetricsData.put("ServiceRequestTechMetricsData", jdbc.query(FMSQueryConstants.RETRIEVE_SERV_REQ_TECH_DASH,/**new Object[]{Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR))},*/ new MiscRowMapper()));
			serviceRequestmetricsData.put("ServiceRequestCustMetricsData", jdbc.query(FMSQueryConstants.RETRIEVE_SERV_REQ_CUST_DASH,/**new Object[]{Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR))},*/ new MiscRowMapper()));
		}catch(Exception e){
			log.info(FMSVariableConstants.DBEXCEPTION+e);
			log.error(FMSVariableConstants.DBEXCEPTION+ e.getStackTrace());
		}
		return serviceRequestmetricsData;
	}

	@Override
	public List<FMSUserBean> authorizeUser(String userId) {
		List<FMSUserBean> userInfo = null;
		try {
			userInfo = jdbc.query(FMSQueryConstants.AUTHORIZE_USER, new Object[]{userId}, new FMSUserMapper());
		} catch (Exception e) {
			log.info(FMSVariableConstants.DBEXCEPTION+e); 
			log.error(FMSVariableConstants.DBEXCEPTION+ e.getStackTrace());
		}
		return userInfo;
	}

	@Override
	public Map<String, Object> getCombinedAnalysisDropdownData(Map<String, Object> data) {

		/**String businessSegment  = Utils.getValidation(data.get(FMSVariableConstants.BUSINESSSEGMENT));*/
		String businessSegment = FMSVariableConstants.EMPTY_STRING;
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR)).replaceAll("[()]", "1");

		Map<String, Object> result = new HashMap<>();
		try{
			result.put(FMSVariableConstants.TECHNOLOGYDESCRIPTION, jdbc.queryForList(FMSQueryConstants.COMBINED_ANALYSIS_DROPDOWN_TECH_DESC,new Object[]{businessSegment,marketIndustry,businessSegment,marketIndustry}, String.class));
			result.put(FMSVariableConstants.REGIONDESCRIPTION, jdbc.queryForList(FMSQueryConstants.COMBINED_ANALYSIS_DROPDOWN_REGION_DESC,new Object[]{businessSegment,marketIndustry,businessSegment,marketIndustry,businessSegment,marketIndustry}, String.class));
			result.put(FMSVariableConstants.COUNTRYDESCRIPTION, jdbc.queryForList(FMSQueryConstants.COMBINED_ANALYSIS_DROPDOWN_COUNTRY_DESC,new Object[]{businessSegment,marketIndustry,businessSegment,marketIndustry,businessSegment,marketIndustry}, String.class));
			result.put(FMSVariableConstants.SITECUSTDESC, jdbc.queryForList(FMSQueryConstants.COMBINED_ANALYSIS_DROPDOWN_SITE_CUSTOMER_DESC,new Object[]{businessSegment,marketIndustry,businessSegment,marketIndustry,businessSegment,marketIndustry}, String.class));
			result.put(FMSVariableConstants.SEGMENT, jdbc.queryForList(FMSQueryConstants.COMBINED_ANALYSIS_DROPDOWN_SEGMENT_DESC,new Object[]{businessSegment,marketIndustry,businessSegment,marketIndustry,businessSegment,marketIndustry}, String.class));
			result.put(FMSVariableConstants.TIER3, jdbc.queryForList(FMSQueryConstants.COMBINED_ANALYSIS_DROPDOWN_TIER3_DESC,new Object[]{businessSegment,marketIndustry,businessSegment,marketIndustry}, String.class));
			result.put(FMSVariableConstants.GEDUNS, jdbc.queryForList(FMSQueryConstants.COMBINED_ANALYSIS_DROPDOWN_GE_DUNS_NAME_DESC,new Object[]{businessSegment,marketIndustry,businessSegment,marketIndustry,businessSegment,marketIndustry}, String.class));
			result.put(FMSVariableConstants.YEAR_QTR, jdbc.queryForList(FMSQueryConstants.COMBINED_ANALYSIS_DROPDOWN_YEAR_QTR,new Object[]{businessSegment,marketIndustry,businessSegment,marketIndustry,businessSegment,marketIndustry}, String.class));		
		}catch(Exception e){
			log.info(FMSVariableConstants.DBEXCEPTION+e);
			log.error(FMSVariableConstants.DBEXCEPTION+ e.getStackTrace());
		}
		return result;
	}

	@Override
	public Map<String, Object> getCombinedAnalysisMetrics(Map<String, Object> data) {

		List<Map<String,Object>> resultChart = new ArrayList<>();
		List<Map<String,Object>> resultTable = new ArrayList<>();
		Map<String, Object> IB = new LinkedHashMap<>();
		Map<String, Object> IBO = new LinkedHashMap<>();
		Map<String, Object> orders = new LinkedHashMap<>();
		Map<String, Object> dm = new LinkedHashMap<>();
		Map<String, Object> outages = new LinkedHashMap<>();
		Map<String, Object> serviceRequest = new LinkedHashMap<>();
		Map<String, Object> tableIBO = new LinkedHashMap<>();
		Map<String, Object> tableOrders = new LinkedHashMap<>();
		Map<String, Object> tableDm = new LinkedHashMap<>();
		Map<String, Object> tableOutages = new LinkedHashMap<>();
		Map<String, Object> tableServiceRequest = new LinkedHashMap<>();
		List<Map<String, Object>> metricsUnit = new ArrayList<>();

		/**String businessSegment  = Utils.getValidation(data.get(FMSVariableConstants.BUSINESSSEGMENT));*/
		String businessSegment  = FMSVariableConstants.EMPTY_STRING;
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR)).replaceAll("[()]", "1");
		Map<String,Object> finalData = new LinkedHashMap<>();

		String yearQtrVal = "";
		try{
			metricsUnit = jdbc.query(FMSQueryConstants.COMBINED_ANALYSIS_METRICS_UNITS,new MiscRowMapper());

			if(Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION)).isEmpty() && Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).isEmpty() && Utils.getValidation(data.get(FMSVariableConstants.SEGMENT)).isEmpty()
					&&  Utils.getValidation(data.get(FMSVariableConstants.SERIALNUMBER)).isEmpty() && Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION)).isEmpty() && Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION)).isEmpty()
					&&  Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).isEmpty() &&  Utils.getValidation(data.get(FMSVariableConstants.TIER3)).isEmpty() &&  Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)).isEmpty()){

				for(Map<String,Object> row : metricsUnit){
					if(((String) row.get(FMSVariableConstants.METRICS)).equalsIgnoreCase(FMSVariableConstants.IB)){
						IB.put(FMSVariableConstants.NAME, Utils.getValidation(row.get(FMSVariableConstants.METRICS)));
						IB.put(FMSVariableConstants.UNIT, Utils.getValidation(row.get(FMSVariableConstants.UNIT)));
						IB.put(FMSVariableConstants.TOTAL, jdbc.queryForObject(FMSQueryConstants.IB_METRICS_CHARTS_TOTAL_ONLOAD,new Object[]{businessSegment,marketIndustry, accountManager}, String.class));
						tableIBO.put(FMSVariableConstants.METRICS, FMSVariableConstants.IBIBO);
						tableIBO.put(FMSVariableConstants.DATA, new ArrayList<>());
						resultTable.add(tableIBO);
						resultChart.add(IB);
					}else if(((String) row.get(FMSVariableConstants.METRICS)).equalsIgnoreCase(FMSVariableConstants.IBO)){
						IBO.put(FMSVariableConstants.NAME, Utils.getValidation(row.get(FMSVariableConstants.METRICS)) + " (Current Year)");
						IBO.put(FMSVariableConstants.UNIT, Utils.getValidation(row.get(FMSVariableConstants.UNIT)));
						IBO.put(FMSVariableConstants.TOTAL, jdbc.queryForObject(FMSQueryConstants.IBO_METRICS_CHARTS_TOTAL_ONLOAD,new Object[]{businessSegment,marketIndustry , accountManager},String.class));
						resultChart.add(IBO);
					}else if(((String) row.get(FMSVariableConstants.METRICS)).equalsIgnoreCase(FMSVariableConstants.ORDERS)){
						orders.put(FMSVariableConstants.NAME, Utils.getValidation(row.get(FMSVariableConstants.METRICS)));
						orders.put(FMSVariableConstants.UNIT, Utils.getValidation(row.get(FMSVariableConstants.UNIT)));
						orders.put(FMSVariableConstants.TOTAL, jdbc.queryForObject(FMSQueryConstants.ORDERS_METRICS_CHARTS_TOTAL_ONLOAD,new Object[]{businessSegment,marketIndustry , accountManager},String.class));
						tableOrders.put(FMSVariableConstants.METRICS, FMSVariableConstants.ORDERS);
						tableOrders.put(FMSVariableConstants.DATA, new ArrayList<>());
						resultTable.add(tableOrders);
						resultChart.add(orders);
					}else if(((String) row.get(FMSVariableConstants.METRICS)).equalsIgnoreCase(FMSVariableConstants.DM)){
						dm.put(FMSVariableConstants.NAME, Utils.getValidation(row.get(FMSVariableConstants.METRICS)));
						dm.put(FMSVariableConstants.UNIT, Utils.getValidation(row.get(FMSVariableConstants.UNIT)));
						dm.put(FMSVariableConstants.TOTAL, jdbc.queryForObject(FMSQueryConstants.DM_METRICS_CHARTS_TOTAL_ONLOAD,new Object[]{businessSegment,marketIndustry , accountManager},String.class));
						tableDm.put(FMSVariableConstants.METRICS, FMSVariableConstants.DM);
						tableDm.put(FMSVariableConstants.DATA, new ArrayList<>());
						resultTable.add(tableDm);
						resultChart.add(dm);
					}else if(((String) row.get(FMSVariableConstants.METRICS)).equalsIgnoreCase(FMSVariableConstants.OUTAGES)){
						outages.put(FMSVariableConstants.NAME, Utils.getValidation(row.get(FMSVariableConstants.METRICS)));
						outages.put(FMSVariableConstants.UNIT, Utils.getValidation(row.get(FMSVariableConstants.UNIT)));
						outages.put(FMSVariableConstants.TOTAL, jdbc.queryForObject(FMSQueryConstants.OUTAGES_METRICS_CHARTS_TOTAL_ONLOAD,new Object[]{accountManager},String.class));
						tableOutages.put(FMSVariableConstants.METRICS, FMSVariableConstants.OUTAGES);
						tableOutages.put(FMSVariableConstants.DATA, new ArrayList<>());
						resultTable.add(tableOutages);
						resultChart.add(outages);
					}else if(((String) row.get(FMSVariableConstants.METRICS)).equalsIgnoreCase(FMSVariableConstants.SERVICEREQUESTTITLE)){
						serviceRequest.put(FMSVariableConstants.NAME, Utils.getValidation(row.get(FMSVariableConstants.METRICS)));
						serviceRequest.put(FMSVariableConstants.UNIT, Utils.getValidation(row.get(FMSVariableConstants.UNIT)));
						if(businessSegment.equalsIgnoreCase(FMSVariableConstants.C_PROD_EXC_PL_DTS))
							serviceRequest.put(FMSVariableConstants.TOTAL, jdbc.queryForObject(FMSQueryConstants.SERVICES_METRICS_CHARTS_TOTAL_ONLOAD,String.class));
						else
							serviceRequest.put(FMSVariableConstants.TOTAL, 0);
						tableServiceRequest.put(FMSVariableConstants.METRICS, FMSVariableConstants.SERVICEREQUESTTITLE);
						tableServiceRequest.put(FMSVariableConstants.DATA, new ArrayList<>());
						resultTable.add(tableServiceRequest);
						resultChart.add(serviceRequest);
					}
				}
			}else{

				for(Map<String,Object> row : metricsUnit){

					if(((String) row.get(FMSVariableConstants.METRICS)).equalsIgnoreCase(FMSVariableConstants.IB)){

						Object[] params = new Object[10];
						params[0] = Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION));
						params[1] = Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).replaceAll("[()]", "1");
						params[2] = Utils.getValidation(data.get(FMSVariableConstants.SEGMENT)).replaceAll("[()]", "1");
						params[3] = Utils.getValidation(data.get(FMSVariableConstants.SERIALNUMBER));
						params[4] = Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION));
						params[5] = Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION));
						params[6] = Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).replaceAll("[()]", "1");
						params[7] = businessSegment;
						params[8] = marketIndustry;
						params[9] = accountManager;

						IB.put(FMSVariableConstants.NAME, Utils.getValidation(row.get(FMSVariableConstants.METRICS)));
						IB.put(FMSVariableConstants.UNIT, Utils.getValidation(row.get(FMSVariableConstants.UNIT)));
						if(!Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.SEGMENT)).isEmpty()
								||!Utils.getValidation(data.get(FMSVariableConstants.SERIALNUMBER)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION)).isEmpty()
								||!Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)).isEmpty()
								||!Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR)).isEmpty()){
							IB.put(FMSVariableConstants.TOTAL, jdbc.queryForObject(FMSQueryConstants.IB_METRICS_CHARTS_TOTAL,params,String.class));
							if(!data.isEmpty()){
								tableIBO.put(FMSVariableConstants.METRICS, FMSVariableConstants.IBIBO);
								tableIBO.put(FMSVariableConstants.DATA, jdbc.query(FMSQueryConstants.IB_METRICS_TABLE_CA,params,new MiscRowMapper()));
								resultTable.add(tableIBO);
							}
						}else{
							IB.put(FMSVariableConstants.TOTAL,"0");	
							if(!data.isEmpty()){
								tableIBO.put(FMSVariableConstants.METRICS, FMSVariableConstants.IBIBO);
								tableIBO.put(FMSVariableConstants.DATA, new ArrayList<>());
								resultTable.add(tableIBO);
							}
						}
						resultChart.add(IB);
					}else if(((String) row.get(FMSVariableConstants.METRICS)).equalsIgnoreCase(FMSVariableConstants.IBO)){

						Object[] params = new Object[10];
						params[0] = Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION));
						params[1] = Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).replaceAll("[()]", "1");
						params[2] = Utils.getValidation(data.get(FMSVariableConstants.SEGMENT)).replaceAll("[()]", "1");
						params[3] = Utils.getValidation(data.get(FMSVariableConstants.SERIALNUMBER));
						params[4] = Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION));
						params[5] = Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION));
						params[6] = Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).replaceAll("[()]", "1");
						params[7] = businessSegment;
						params[8] = marketIndustry;
						params[9] = accountManager;

						IBO.put(FMSVariableConstants.NAME, Utils.getValidation(row.get(FMSVariableConstants.METRICS)) + " (Current Year)");
						IBO.put(FMSVariableConstants.UNIT, Utils.getValidation(row.get(FMSVariableConstants.UNIT)));
						if(!Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.SEGMENT)).isEmpty()
								||!Utils.getValidation(data.get(FMSVariableConstants.SERIALNUMBER)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION)).isEmpty()
								||!Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)).isEmpty()
								||!Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR)).isEmpty()){

							IBO.put(FMSVariableConstants.TOTAL, jdbc.queryForObject(FMSQueryConstants.IBO_METRICS_CHARTS_TOTAL,params,String.class));
						}else{
							IBO.put(FMSVariableConstants.TOTAL, "0");
						}
						resultChart.add(IBO);
					}else if(((String) row.get(FMSVariableConstants.METRICS)).equalsIgnoreCase(FMSVariableConstants.ORDERS)){

						Object[] params = new Object[11];
						params[0] = Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION));
						params[1] = Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).replaceAll("[()]", "1");
						params[2] = Utils.getValidation(data.get(FMSVariableConstants.SEGMENT)).replaceAll("[()]", "1");
						params[3] = Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION));
						params[4] = Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION));
						params[5] = Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).replaceAll("[()]", "1");
						params[6] = Utils.getValidation(data.get(FMSVariableConstants.TIER3)).replace("&", "");
						params[7] = Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR));
						params[8] = businessSegment;
						params[9] = marketIndustry;
						params[10] = accountManager;

						orders.put(FMSVariableConstants.NAME, Utils.getValidation(row.get(FMSVariableConstants.METRICS)));
						orders.put(FMSVariableConstants.UNIT, Utils.getValidation(row.get(FMSVariableConstants.UNIT)));
						if(!Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.SEGMENT)).isEmpty()
								||!Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION)).isEmpty()
								||!Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).isEmpty()||!Utils.getValidation(data.get(FMSVariableConstants.TIER3)).isEmpty()||!Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)).isEmpty()
								||!Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR)).isEmpty()){
							if( Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)) == ""){
								/**YEAR QUARTER IS NOT SELECTED SO CURRENT YEAR QUARTER TAKEN INTO CONSIDERATION*/
								yearQtrVal = jdbc.queryForObject(FMSQueryConstants.LAST_YEAR_QUARTER,String.class);
								params[7] = yearQtrVal;
							}
							orders.put(FMSVariableConstants.TOTAL, jdbc.queryForObject(FMSQueryConstants.ORDERS_METRICS_CHARTS_TOTAL,params,String.class));
							if(!data.isEmpty()){
								tableOrders.put(FMSVariableConstants.METRICS, FMSVariableConstants.ORDERS);
								tableOrders.put(FMSVariableConstants.DATA, jdbc.query(FMSQueryConstants.ORDERS_METRICS_TABLE_CA,params,new MiscRowMapper()));
								resultTable.add(tableOrders);
							}
						}else{
							orders.put(FMSVariableConstants.TOTAL, "0");
							if(!data.isEmpty()){
								tableOrders.put(FMSVariableConstants.METRICS, FMSVariableConstants.ORDERS);
								tableOrders.put(FMSVariableConstants.DATA, new ArrayList<>());
								resultTable.add(tableOrders);
							}
						}
						resultChart.add(orders);
					}else if(((String) row.get(FMSVariableConstants.METRICS)).equalsIgnoreCase(FMSVariableConstants.DM)){

						Object[] params = new Object[12];
						params[0] = Utils.getValidation(data.get(FMSVariableConstants.SEGMENT)).replaceAll("[()]", "1");
						params[1] = Utils.getValidation(data.get(FMSVariableConstants.SERIALNUMBER));
						params[2] = Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION));
						params[3] = Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION));
						params[4] = Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).replaceAll("[()]", "1");
						params[5] = Utils.getValidation(data.get(FMSVariableConstants.TIER3)).replace("&", "");
						params[6] = Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).replaceAll("[()]", "1");
						params[7] = Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION));
						params[8] = Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR));
						params[9] = businessSegment;
						params[10] = marketIndustry;
						params[11] = accountManager;

						dm.put(FMSVariableConstants.NAME, Utils.getValidation(row.get(FMSVariableConstants.METRICS)));
						dm.put(FMSVariableConstants.UNIT, Utils.getValidation(row.get(FMSVariableConstants.UNIT)));
						if(!Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.SEGMENT)).isEmpty()
								|| !Utils.getValidation(data.get(FMSVariableConstants.SERIALNUMBER)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION)).isEmpty()
								|| !Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).isEmpty() || !Utils.getValidation(data.get(FMSVariableConstants.TIER3)).isEmpty() || !Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)).isEmpty()
								|| !Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR)).isEmpty()){
							if(Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)) == ""){
								/**YEAR QUARTER IS NOT SELECTED SO CURRENT YEAR QUARTER TAKEN INTO CONSIDERATION*/
								yearQtrVal = jdbc.queryForObject(FMSQueryConstants.CURRENT_YEAR_QUARTER,String.class);
								params[8] = yearQtrVal;
							}
							dm.put(FMSVariableConstants.TOTAL, jdbc.queryForObject(FMSQueryConstants.DM_METRICS_CHARTS_TOTAL,params,String.class));
							if(!data.isEmpty()){
								tableDm.put(FMSVariableConstants.METRICS, FMSVariableConstants.DM);
								tableDm.put(FMSVariableConstants.DATA, jdbc.query(FMSQueryConstants.DM_METRICS_TABLE_CA,params,new MiscRowMapper()));
								resultTable.add(tableDm);
							}
						}else{
							dm.put(FMSVariableConstants.TOTAL, "0");
							if(!data.isEmpty()){
								tableDm.put(FMSVariableConstants.METRICS, FMSVariableConstants.DM);
								tableDm.put(FMSVariableConstants.DATA, new ArrayList<>());
								resultTable.add(tableDm);
							}
						}
						resultChart.add(dm);
					}else if(((String) row.get(FMSVariableConstants.METRICS)).equalsIgnoreCase(FMSVariableConstants.OUTAGES)){

						Object[] params = new Object[9];
						params[0] = Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION));
						params[1] = Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).replaceAll("[()]", "1");
						params[2] = Utils.getValidation(data.get(FMSVariableConstants.SEGMENT)).replaceAll("[()]", "1");
						params[3] = Utils.getValidation(data.get(FMSVariableConstants.SERIALNUMBER));
						params[4] = Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION));
						params[5] = Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION));
						params[6] = Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).replaceAll("[()]", "1");
						params[7] = Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR));
						params[8] = accountManager;


						outages.put(FMSVariableConstants.NAME, Utils.getValidation(row.get(FMSVariableConstants.METRICS)));
						outages.put(FMSVariableConstants.UNIT, Utils.getValidation(row.get(FMSVariableConstants.UNIT)));
						if(!Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.SEGMENT)).isEmpty()
								||!Utils.getValidation(data.get(FMSVariableConstants.SERIALNUMBER)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION)).isEmpty()
								|| !Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).isEmpty() || !Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)).isEmpty()
								|| !Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR)).isEmpty()){
							if(Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)) == ""){
								/**YEAR QUARTER IS NOT SELECTED SO CURRENT YEAR QUARTER TAKEN INTO CONSIDERATION*/
								yearQtrVal = jdbc.queryForObject(FMSQueryConstants.CURRENT_YEAR_QUARTER,String.class);
								params[7] = yearQtrVal;
							}
							outages.put(FMSVariableConstants.TOTAL, jdbc.queryForObject(FMSQueryConstants.OUTAGES_METRICS_CHARTS_TOTAL,params,String.class));
							if(!data.isEmpty()){
								tableOutages.put(FMSVariableConstants.METRICS, FMSVariableConstants.OUTAGES);
								tableOutages.put(FMSVariableConstants.DATA, jdbc.query(FMSQueryConstants.OUTAGES_METRICS_TABLE_CA,params,new MiscRowMapper()));
								resultTable.add(tableOutages);
							}
							resultChart.add(outages);
						}else{
							outages.put(FMSVariableConstants.TOTAL, "0");
							if(!data.isEmpty()){
								tableOutages.put(FMSVariableConstants.METRICS, FMSVariableConstants.OUTAGES);
								tableOutages.put(FMSVariableConstants.DATA, new ArrayList<>());
								resultTable.add(tableOutages);
							}
							resultChart.add(outages);
						}

					}else if(((String) row.get(FMSVariableConstants.METRICS)).equalsIgnoreCase(FMSVariableConstants.SERVICEREQUESTTITLE)){

						Object[] params = new Object[4];
						params[0] = Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION));
						params[1] = Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).replaceAll("[()]", "1");
						params[2] = Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).replaceAll("[()]", "1");
						params[3] = Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR));
						serviceRequest.put(FMSVariableConstants.NAME, Utils.getValidation(row.get(FMSVariableConstants.METRICS)));
						serviceRequest.put(FMSVariableConstants.UNIT, Utils.getValidation(row.get(FMSVariableConstants.UNIT)));

						if(!Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).isEmpty() 
								||!Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)).isEmpty()){
							/**if(Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)) == ""){
							 //YEAR QUARTER IS NOT SELECTED SO CURRENT YEAR QUARTER TAKEN INTO CONSIDERATION
								yearQtrVal = jdbc.queryForObject(FMSQueryConstants.CURRENT_YEAR_QUARTER,String.class);
								params[3] = yearQtrVal;
							}
							 **/
							if(businessSegment.equalsIgnoreCase("DTS"))
								serviceRequest.put(FMSVariableConstants.TOTAL, jdbc.queryForObject(FMSQueryConstants.SERVICES_METRICS_CHARTS_TOTAL,params,String.class));
							else
								serviceRequest.put(FMSVariableConstants.TOTAL, 0);
							if(!data.isEmpty()){
								if(businessSegment.equalsIgnoreCase("DTS")){
									tableServiceRequest.put(FMSVariableConstants.METRICS, "service request");
									tableServiceRequest.put(FMSVariableConstants.DATA, jdbc.query(FMSQueryConstants.SERVICE_REQUEST_TABLE_CA,params,new MiscRowMapper()));
									resultTable.add(tableServiceRequest);
								}else{
									tableServiceRequest.put(FMSVariableConstants.METRICS, "service request");
									tableServiceRequest.put(FMSVariableConstants.DATA, jdbc.query(FMSQueryConstants.SERVICE_REQUEST_TABLE_CA.concat(" AND 1 = 2 "),params,new MiscRowMapper()));
									resultTable.add(tableServiceRequest);
								}
							}
						}else{
							serviceRequest.put(FMSVariableConstants.TOTAL, "0");
							if(!data.isEmpty()){
								tableServiceRequest.put(FMSVariableConstants.METRICS, "service request");
								tableServiceRequest.put(FMSVariableConstants.DATA, new ArrayList<>());
								resultTable.add(tableServiceRequest);
							}
						}
						resultChart.add(serviceRequest);
					}

				}
			}
			finalData.put("chart", resultChart);
			finalData.put("table", resultTable);

		}catch(Exception e){
			log.info(FMSVariableConstants.DBEXCEPTION+e);
			log.error(FMSVariableConstants.DBEXCEPTION+ e.getMessage());
		}
		return finalData;
	}

	@Override
	public List<Map<String, Object>> exportCombinedAnalytics(Map<String, Object> data, String metrics) {

		List<Map<String,Object>> result = new ArrayList<>();
		String yearQtrVal = "";
		/**String businessSegment  = Utils.getValidation(data.get(FMSVariableConstants.BUSINESSSEGMENT));*/
		String businessSegment  = FMSVariableConstants.EMPTY_STRING;
		String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACC_MGR)).replaceAll("[()]", "1");
		try{

			if(metrics.equalsIgnoreCase(FMSVariableConstants.IB)){
				Object[] params = new Object[10];
				params[0] = Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION));
				params[1] = Utils.getValidation(data.get(FMSVariableConstants.GEDUNS));
				params[2] = Utils.getValidation(data.get(FMSVariableConstants.SEGMENT));
				params[3] = Utils.getValidation(data.get(FMSVariableConstants.SERIALNUMBER));
				params[4] = Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION));
				params[5] = Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION));
				params[6] = Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC));
				params[7] = businessSegment;
				params[8] = marketIndustry;
				params[9] = accountManager;
				result = jdbc.query(FMSQueryConstants.IB_METRICS_TABLE_CA,params,new MiscRowMapper());
			}else if(metrics.equalsIgnoreCase(FMSVariableConstants.ORDERS)){
				Object[] params = new Object[11];
				params[0] = Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION));
				params[1] = Utils.getValidation(data.get(FMSVariableConstants.GEDUNS));
				params[2] = Utils.getValidation(data.get(FMSVariableConstants.SEGMENT));
				params[3] = Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION));
				params[4] = Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION));
				params[5] = Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC));
				params[6] = Utils.getValidation(data.get(FMSVariableConstants.TIER3)).replace("&", "");
				params[7] = Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR));
				params[8] = businessSegment;
				params[9] = marketIndustry;
				params[10] = accountManager;
				if(Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)) == ""){
					/**YEAR QUARTER IS NOT SELECTED SO CURRENT YEAR QUARTER TAKEN INTO CONSIDERATION*/
					yearQtrVal = jdbc.queryForObject(FMSQueryConstants.LAST_YEAR_QUARTER,String.class);
					params[7] = yearQtrVal;
				}
				if(!Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.SEGMENT)).isEmpty()
						||!Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION)).isEmpty()
						||!Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).isEmpty()||!Utils.getValidation(data.get(FMSVariableConstants.TIER3)).isEmpty()||!Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)).isEmpty()){
					result = jdbc.query(FMSQueryConstants.ORDERS_METRICS_TABLE_CA,params,new MiscRowMapper());
				} 
			}else if(metrics.equalsIgnoreCase(FMSVariableConstants.DM)){
				Object[] params = new Object[12];
				params[0] = Utils.getValidation(data.get(FMSVariableConstants.SEGMENT));
				params[1] = Utils.getValidation(data.get(FMSVariableConstants.SERIALNUMBER));
				params[2] = Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION));
				params[3] = Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION));
				params[4] = Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC));
				params[5] = Utils.getValidation(data.get(FMSVariableConstants.TIER3)).replace("&", "");
				params[6] = Utils.getValidation(data.get(FMSVariableConstants.GEDUNS));
				params[7] = Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION));
				params[8] = Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR));
				params[9] = businessSegment;
				params[10] = marketIndustry;
				params[11] = accountManager;
				if(Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)) == ""){
					/**YEAR QUARTER IS NOT SELECTED SO CURRENT YEAR QUARTER TAKEN INTO CONSIDERATION*/
					yearQtrVal = jdbc.queryForObject(FMSQueryConstants.CURRENT_YEAR_QUARTER,String.class);
					params[8] = yearQtrVal;
				}
				result = jdbc.query(FMSQueryConstants.DM_METRICS_TABLE_CA,params,new MiscRowMapper());
			}else if(metrics.equalsIgnoreCase(FMSVariableConstants.OUTAGES)){
				Object[] params = new Object[9];
				params[0] = Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION));
				params[1] = Utils.getValidation(data.get(FMSVariableConstants.GEDUNS));
				params[2] = Utils.getValidation(data.get(FMSVariableConstants.SEGMENT));
				params[3] = Utils.getValidation(data.get(FMSVariableConstants.SERIALNUMBER));
				params[4] = Utils.getValidation(data.get(FMSVariableConstants.REGIONDESCRIPTION));
				params[5] = Utils.getValidation(data.get(FMSVariableConstants.COUNTRYDESCRIPTION));
				params[6] = Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC));
				params[7] = Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR));
				params[8] = accountManager;
				if(Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)) == ""){
					/**YEAR QUARTER IS NOT SELECTED SO CURRENT YEAR QUARTER TAKEN INTO CONSIDERATION*/
					yearQtrVal = jdbc.queryForObject(FMSQueryConstants.CURRENT_YEAR_QUARTER,String.class);
					params[7] = yearQtrVal;
				}
				result = jdbc.query(FMSQueryConstants.OUTAGES_METRICS_TABLE_CA,params,new MiscRowMapper());
			}else if(metrics.equalsIgnoreCase("serviceRequest")){
				Object[] params = new Object[4];
				params[0] = Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION));
				params[1] = Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC));
				params[2] = Utils.getValidation(data.get(FMSVariableConstants.GEDUNS));
				params[3] = Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR));
				if(!Utils.getValidation(data.get(FMSVariableConstants.TECHNOLOGYDESCRIPTION)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.SITECUSTDESC)).isEmpty() 
						||!Utils.getValidation(data.get(FMSVariableConstants.GEDUNS)).isEmpty() ||!Utils.getValidation(data.get(FMSVariableConstants.YEAR_QTR)).isEmpty()){
					if(businessSegment.equalsIgnoreCase("DTS"))
						result = jdbc.query(FMSQueryConstants.SERVICE_REQUEST_TABLE_CA,params,new MiscRowMapper());
					else
						result = jdbc.query(FMSQueryConstants.SERVICE_REQUEST_TABLE_CA.concat(" AND 1 = 2 "),params,new MiscRowMapper());
				}
			}
		}catch(Exception e){
			log.info(FMSVariableConstants.DBEXCEPTION+e);
		}
		return result;
	}


	public synchronized String importCSVToOrder(InputStream inputStream, String fileName, String userSSO, String businessSegment, String marketIndustry) {
		/**String businessSegToggle = businessSegment;
		if(businessSegment.trim().equalsIgnoreCase("DP&S") || businessSegment.trim().equalsIgnoreCase("DTS"))
			businessSegment = "DP&S";*/
		String response=FMSVariableConstants.FAILURE;
		String serviceLogMessage = null;
		String serviceLog = null;
		Connection con = null;
		Map<String, Object> insertOrdersHistoryData = new HashMap<>();
		insertOrdersHistoryData.put(FMSVariableConstants.SSO_ID, userSSO);
		insertOrdersHistoryData.put(FMSVariableConstants.TASK_NAME, "Orders Import"/**.concat(businessSegToggle)*/);
		insertOrdersHistoryData.put(FMSVariableConstants.FILE_NAME, fileName);
		insertOrdersHistoryData.put(FMSVariableConstants.STATUS, FMSVariableConstants.IN_PROGRESS);
		int insertedId = insertToImportHistory(insertOrdersHistoryData);
		try {
			con = DriverManager.getConnection(url,user,pass);
			CopyManager copyManager = new CopyManager((BaseConnection) con);
			log.info("Import Started!");
			jdbc.execute(FMSQueryConstants.DROP_ORDERS_TEMP);
			jdbc.execute(FMSQueryConstants.FMS_SERVICE_ORDERS_PM_TEMP);
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.IN_PROGRESS,"Created Orders Temp Table","importCSVToOrder Started"});
			StringBuilder sql = new StringBuilder();
			sql.append(FMSVariableConstants.COPY);
			/**sql.append("fms_service_orders_pm_temp(n_ord_rec_id,c_source_system,n_category_id,c_src_category,c_category_cod,c_category_desc,c_source_name,c_source_icon,c_source_tip,f_src_allow_delete,f_src_allow_edit,n_status_id,n_status_id_replaced,c_status_name,c_status_icon,c_status_tip,n_1st_ord_status_id,d_book_date_src,c_src_book_owner_sso,c_book_owner_sso,c_book_owner_name,f_submitted,d_submit_date,c_submit_by_sso,c_submit_by_name,f_duplicated,f_deleted,f_intercompany,n_book_year,n_book_quarter,n_book_month,c_book_year_month,c_src_legal_entity,n_legal_entity_id,c_legal_entity_code,c_legal_entity_desc,f_update_product,c_src_mgmt_entity,n_mgmt_entity_id,c_mgmt_entity_code,c_mgmt_entity_desc,c_src_profit_loss,n_profit_loss_id,c_profit_loss_code,c_profit_loss_desc,f_contract_type_allowed,f_cm_amount_allowed,c_src_service_type,n_service_type_id,c_service_type_code,c_service_type_desc,n_segment_type_id,c_segment_type_code,c_segment_type_desc,c_src_product_type,n_product_type_id,c_product_type_code,c_product_type_desc,c_project,c_project_parent_no,c_contract_no,c_order_no,c_opportunity_id,c_sales_order_no,c_cust_order_no,c_src_currency_cod,c_currency_cod,n_src_order_val,n_order_value,d_fx_rate_date,n_fx_rate_eur,n_order_val_eur,n_fx_rate_usd,n_order_val_usd,n_order_val_op_rate,n_op_rate,n_src_cm_perc,n_cm_perc,n_cm_perc_as_sold,n_cm_amount_usd,n_cm_amount_eur,n_cm_eur,n_cm_usd,n_cm_op_rate,c_buyer_duns_code,c_buyer_np_code,c_buyer_name,c_end_user_duns_code,c_end_user_np_code,c_end_user_name,c_country_code,c_country_name,f_state_required,c_state_code,c_state_name,c_gs_region_code,c_gs_region_name,c_og_region_code,c_og_region_name,c_gge_region_code,c_gge_region_name,c_ggo_region_code,c_ggo_region_name,c_sal_region_code,c_sal_region_name,c_csa_region_code,c_csa_region_name,c_dts_region_code,c_dts_region_name,c_last_update_by,c_last_update_name,d_last_update_date,t_comment,c_create_by,d_create_date,c_source_module,n_ord_src_row_num,n_ord_source_sub_row_num,n_ord_parent_rec_id,f_parent_rec,d_delivery_date,d_order_date,c_agent_code,c_freight_terms_code,c_buyer_country_cod,c_buyer_country_name,n_org_id,c_contract_type,f_initial_stock_tx,c_src_market,c_market,c_src_new_og_pl,c_new_og_pl,c_src_new_segment,c_new_segment,n_ord_source_id,c_assignment_code,c_train_config,n_num_units,c_segment,c_tier2_cod_from_mgmt,c_project_name,c_plant,n_book_week,c_country_desc_user,c_src_tier3,c_tier3,c_tier3_cod_from_mgmt,c_tier_1_p_l,c_tier_2_p_l,c_tier_3_p_l,c_tier_4_p_l,c_tier2_region_code,c_tier2_region_name,c_orders_view,me_mapping_incl_sc_corrections,me_p_and_l,me_svc_or_eq,me_tier_3,me_dm_tier_3,me_tier_4,me_usage,pm_product_mapping,sm_segment_mapping,e_site_cust_name)");*/
			sql.append("fms_service_orders_pm_temp(n_ord_rec_id,c_source_system,d_book_date_src,c_book_owner_sso,c_book_owner_name,d_submit_date,c_submit_by_sso,c_submit_by_name,n_book_year,n_book_quarter,n_book_month,c_src_legal_entity,c_src_mgmt_entity,c_segment_type_code,n_tier_3,n_service_type,c_product_type_desc,c_project,c_project_parent_no,n_src_ref_no,c_contract_no,c_opportunity_id,c_cust_order_no,c_src_currency_cod,n_src_order_val,n_fx_rate_eur,n_order_val_eur,n_fx_rate_usd,n_order_val_usd,n_order_val_op_rate,n_cm_perc_as_sold,n_cm_eur,n_cm_usd,n_cm_op_rate,c_buyer_duns_code,c_buyer_np_code,c_buyer_name,c_buyer_country_name,c_end_user_duns_code,c_end_user_np_code,c_end_user_name,c_country_code,c_country_name,c_state_code,c_state_name,n_tms_region,c_og_region_name,c_ggo_region_name,c_gge_region_name,c_csa_region_name,c_dts_region_name,n_core_arev,c_category_desc,c_last_update_by,c_last_update_name,d_last_update_date,d_delivery_date,d_order_date,c_agent_code,c_freight_terms_code,c_contract_type,f_initial_stock_tx,c_tier2_cod_from_mgmt,c_market,c_src_new_og_pl,c_mgmt_entity_code,n_assignment,n_train_config,n_num_units_new,n_segment_nu,c_project_name,c_plant,c_orders_view,n_book_week,n_change_order,n_svc_or_eq,n_comments,c_tier3_cod_from_mgmt,n_me_tier_2,c_tier_3_p_l,c_tier_4_p_l,me_mapping_incl_sc_corrections,me_p_and_l,me_svc_or_eq,me_tier_3,me_dm_tier_3,me_tier_4,me_usage,pm_product_mapping,sm_segment_mapping,ge_duns_name,e_site_cust_name,match_per)");
			sql.append(" FROM STDIN WITH (");
			sql.append(" FORMAT CSV ");
			sql.append(", DELIMITER ','");
			sql.append(", NULL ''");
			sql.append(", HEADER TRUE");
			sql.append(", QUOTE '\"'");
			sql.append(", ESCAPE '\"' ");
			sql.append(", ENCODING 'UTF8'");
			sql.append(")");
			copyManager.copyIn(sql.toString(), inputStream );
			log.info(FMSVariableConstants.IMPORT_COMPLETED);
			jdbc.execute(FMSQueryConstants.TRUNCATE_ORDERS_TABLE /**+ " and upper(trim(n_me_tier_2))='"+businessSegToggle +"'"*/);
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.IN_PROGRESS,"Import Completed & Orders Temp Table Truncated","importCSVToOrder In-Progress"});
			jdbc.execute("update fms_service_orders_pm_temp set e_site_cust_name = NULL");
			/**if(businessSegment.equalsIgnoreCase("DP&S")){
				jdbc.execute("update fms_service_orders_pm_temp set n_me_tier_2='DTS' where n_me_tier_2='DP&S'");
			}*/

			/**jdbc.execute("delete from fms_service_orders_pm_temp where upper(trim(n_me_tier_2)) !='"+businessSegToggle +"'");*/ 
			jdbc.execute(FMSQueryConstants.INSERT_ORDERS_TEMP_TO_ORDERS);
			jdbc.execute(FMSQueryConstants.DROP_ORDERS_TEMP);

			jdbc.update("update fms_service_orders_pm set (n_cm_usd ,n_cm_amount_usd ,n_cm_amount_eur ,"
					+ "n_cm_eur ,n_fx_rate_usd ,n_order_val_usd ,n_src_order_val ,n_order_val_eur)"
					+ "=(regexp_replace(n_cm_usd,'[,()]', '','g'),regexp_replace(n_cm_amount_usd,'[,()]', '','g'),"
					+ "regexp_replace(n_cm_amount_eur,'[,()]', '','g'),regexp_replace(n_cm_eur,'[,()]', '','g'),"
					+ "regexp_replace(n_fx_rate_usd,'[,()]', '','g'),regexp_replace(n_order_val_usd,'[,()]', '','g'),"
					+ "regexp_replace(n_src_order_val,'[,()]', '','g'),regexp_replace(n_order_val_eur,'[,()]', '','g'));");
			/**
			 * General Mapping included *
			String meMapping = jdbc.queryForObject(FMSQueryConstants.ALL_ORDERS_MAPPING_FUNC, String.class);
			log.info("ALL_ORDERS_MAPPING_FUNC UPDATED");
			String orderMapping = jdbc.queryForObject(FMSQueryConstants.ORDERS_DUNS_MAPPING_FUNC, String.class);
			log.info("ORDERS_DUNS_MAPPING_FUNC UPDATED");
			String fuzzy = jdbc.queryForObject(FMSQueryConstants.UPDATE_FUZZY_MATCH, String.class);
			log.info("UPDATE_FUZZY_MATCH UPDATED");
			String allMetrics = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS, String.class);
			log.info("UPDATE_ALL_PEN_METRICS UPDATED");
			String techCountryBreak = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_COUNTRY_TECH_SPLIT, String.class);
			log.info("UPDATE_ALL_PEN_METRICS_COUNTRY_TECH_SPLIT UPDATED");
			String sitesBreak = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_SITES_SPLIT, String.class);
			log.info("UPDATE_ALL_PEN_METRICS_SITES_SPLIT UPDATED");
			String segBreak = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_SEGMENT_SPLIT, String.class);
			log.info("UPDATE_ALL_PEN_METRICS_SEGMENT_SPLIT UPDATED");
			String sitesOverall = jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_SITES_SPLIT, String.class);
			log.info("UPDATE_OVERALL_SITES_SPLIT UPDATED");
			String regionOverall = jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_REGIONS_SPLIT, String.class);
			log.info("UPDATE_OVERALL_REGIONS_SPLIT UPDATED");
			String countryOverall = jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_COUNTRIES_SPLIT, String.class);
			log.info("UPDATE_OVERALL_COUNTRIES_SPLIT UPDATED");
			serviceLogMessage = FMSVariableConstants.ME_MAPPING.concat(meMapping).concat(FMSVariableConstants.ORDER_MAPPING).concat(orderMapping).concat(FMSVariableConstants.FUZZY).concat(fuzzy).concat(FMSVariableConstants.ALL_METRICS).concat(allMetrics).concat(FMSVariableConstants.TECH_COUNTRY_BREAK).concat(techCountryBreak).concat(FMSVariableConstants.SITES_BREAK).concat(sitesBreak).concat(FMSVariableConstants.SEGMENT_BREAK).concat(segBreak).concat(FMSVariableConstants.SITES_OVERALL).concat(sitesOverall).concat(FMSVariableConstants.REGION_OVERALL).concat(regionOverall).concat(FMSVariableConstants.COUNTRY_OVERALL).concat(countryOverall);
			serviceLog = serviceLogMessage.replace("1", FMSVariableConstants.SUCCESS);*/
			log.info(FMSVariableConstants.MAPPING_FUNC_CALL);
			serviceLog = jdbc.queryForObject(FMSQueryConstants.GENERAL_FMS_MAPPING_FUNC, new Object[]{FMSVariableConstants.FMS_MAPPING_FUNC_ORDERS}, String.class);
			log.info(FMSVariableConstants.MAPPING_SUCCESS + serviceLog);

			updateImportHistory(FMSVariableConstants.SUCCESS, 0, insertedId);
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,serviceLog,"importCSVToOrder Import/Query Execution Completed"});
			response = FMSVariableConstants.SUCCESS;
			return response;

		}catch(Exception e){
			log.error(FMSVariableConstants.ERROR+ e.getMessage());
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"importCSVToOrder"});
			updateImportHistory(FMSVariableConstants.FAILURE, 0, insertedId);
			jdbc.execute(FMSQueryConstants.DROP_ORDERS_TEMP);
		}finally{
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					log.error(FMSVariableConstants.DBEXCEPTION+ e.getStackTrace());
				}
			}
		}
		return response;
	}

	@Override
	public List<FMSUserRoleBean> getUserRoles(String userId) {
		List<FMSUserRoleBean> userRoles = null;
		try {
			userRoles = jdbc.query(FMSQueryConstants.GET_USER_ROLES, new Object[]{userId}, new FMSUserRoleMapper());
		} catch (Exception e) {
			log.info(FMSVariableConstants.DBEXCEPTION+e);
			log.error(FMSVariableConstants.DBEXCEPTION+ e.getStackTrace());
		}
		return userRoles;
	}

	@Override
	public Map<String, Object> getChooseColumns() {
		Map<String, Object> resultMap = new HashMap<>();
		try {
			List<FMSChooseColumnDataDTO> equipmentColumns=jdbc.query(FMSQueryConstants.CHOOSE_COLUMNS_EQUIPMENT, new FMSChooseColumnDataMapper());
			List<FMSChooseColumnDataDTO> ordersColumns=jdbc.query(FMSQueryConstants.CHOOSE_COLUMNS_ORDERS, new FMSChooseColumnDataMapper());
			List<FMSChooseColumnDataDTO> dmColumns=jdbc.query(FMSQueryConstants.CHOOSE_COLUMNS_DM, new FMSChooseColumnDataMapper());
			List<FMSChooseColumnDataDTO> outageColumns=jdbc.query(FMSQueryConstants.CHOOSE_COLUMNS_OUTAGE, new FMSChooseColumnDataMapper());
			List<FMSChooseColumnDataDTO> serviceReqColumns=jdbc.query(FMSQueryConstants.CHOOSE_COLUMNS_SERVICEREQ, new FMSChooseColumnDataMapper());

			resultMap.put("EquipmentColumns",equipmentColumns);
			resultMap.put("OrdersColumns",ordersColumns);
			resultMap.put("DMColumns",dmColumns);
			resultMap.put("OutageColumns",outageColumns);
			resultMap.put("ServiceReqColumns",serviceReqColumns);

		} catch (Exception e) {
			log.error("Error in printStackTrace getChooseColumns() -- " + e.getStackTrace());
			log.error("Error in getChosenColumns :"+e.getMessage());
			resultMap.put(FMSVariableConstants.ERROR, e.getMessage());
		}
		return resultMap;
	}


	@Override
	public String importCSVToCustMapping(InputStream inputStream) {
		String response="";
		Connection con = null;
		try {
			con = DriverManager.getConnection(url,user,pass);
			CopyManager copyManager = new CopyManager((BaseConnection) con);
			jdbc.execute(FMSQueryConstants.TRUNCATE_GE_CUST_MAPPING);
			StringBuilder sql = new StringBuilder();
			sql.append(FMSVariableConstants.COPY);
			sql.append("fms_ge_cust_mapping_csv_import(gib_serial_number, oem_serial_number, ge_global_duns, ge_duns_name)");
			sql.append(" FROM STDIN WITH (");
			sql.append(" FORMAT CSV ");
			sql.append(", DELIMITER ','");
			sql.append(", NULL ''");
			sql.append(", HEADER TRUE");
			sql.append(", QUOTE '\"'");
			sql.append(", ESCAPE '\"' ");
			sql.append(", ENCODING 'WIN1257'");    
			sql.append(")");
			log.info(FMSVariableConstants.IMPORT_STARTED);
			copyManager.copyIn(sql.toString(), inputStream );
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.IN_PROGRESS,FMSVariableConstants.MAPPING_SERVICE_LOG,"importCSVToCustMapping"});
			log.info(FMSVariableConstants.IMPORT_COMPLETED);
			log.info("Records updation started...");
			jdbc.update(FMSQueryConstants.UPDATE_OLD_GE_DUNS_NAMES);
			jdbc.update(FMSQueryConstants.INSERT_NEW_GE_DUNS_NAMES);
			/**
			 * Generalized Mapping Function Included * 
			jdbc.queryForObject(FMSQueryConstants.ORDERS_DUNS_MAPPING_FUNC, String.class);
			jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_SITES_SPLIT, String.class);
			log.info("UPDATE_ALL_PEN_METRICS_SITES_SPLIT UPDATED");
			jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_SITES_SPLIT, String.class);
			log.info("UPDATE_OVERALL_SITES_SPLIT UPDATED");*/
			String serviceLog = jdbc.queryForObject(FMSQueryConstants.GENERAL_FMS_MAPPING_FUNC, new Object[]{FMSVariableConstants.FMS_MAPPING_FUNC_GEDUNS}, String.class);
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,serviceLog,"importCSVToCustMapping Mapping Completed"});
			response = FMSVariableConstants.SUCCESS;

			log.info("Records updated!" + serviceLog);
		}catch(Exception e){
			response = FMSVariableConstants.FAILURE;
		}finally{
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					log.error(FMSVariableConstants.DBEXCEPTION+ e.getStackTrace());
				}
			}
		}
		return response;
	}

	/**@Override
	public Map<String, Object> getGeneralisedChooseColumnDetails() {
		Map<String, Object> resultMap = new HashMap<>();
		List<String> tableName = jdbc.queryForList(FMSQueryConstants.TABLE_NAME_FOR_CHOOSE_COLUMNS, String.class);
		try{
			for(int index=0;index<tableName.size();index++){
				resultMap.put(tableName.get(index), jdbc.query(FMSQueryConstants.GENERALISED_CHOOSE_COLUMNS_QUERY,new Object[]{tableName.get(index)}, new FMSChooseColumnDataMapper()));
			}
		}catch(Exception e){
			log.error(FMSVariableConstants.ERROR+e.getMessage());
		}
		return resultMap;
	}*/

	public void downloadFile(HttpServletResponse responses, Map<String,Object> data){
		String postQuery="";
		String fileName = "";
		if(Utils.getValidation(data.get(FMSVariableConstants.TYPE)).equalsIgnoreCase(FMSVariableConstants.ORDERS_CSV_EXPORT)){
			if(Utils.getValidation(data.get(FMSVariableConstants.YEAR)).isEmpty()){
				postQuery = FMSQueryConstants.ORDER_CSV_DATA + FMSVariableConstants.CURRENT_YEAR_QUARTER_CONDITION + "and COALESCE(n_me_tier_2,'') ~* '' ".concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_1).concat(Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
				/**postQuery = FMSQueryConstants.ORDER_CSV_DATA + "where n_book_year=2017 and n_book_quarter = 3";*/
			} else{
				postQuery = FMSQueryConstants.ORDER_CSV_DATA + " WHERE year = " + Utils.getValidation(data.get(FMSVariableConstants.YEAR)) + "::NUMERIC and COALESCE(n_me_tier_2,'') ~* '' ".concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_1).concat(Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
			}
		} else if(Utils.getValidation(data.get(FMSVariableConstants.TYPE)).equalsIgnoreCase(FMSVariableConstants.REVENUE_CSV_EXPORT)){
			postQuery = FMSQueryConstants.REVENUE_CSV_DATA + " where COALESCE(business_segment,'') ~* '' ".concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_1).concat(Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
		} else if(Utils.getValidation(data.get(FMSVariableConstants.TYPE)).equalsIgnoreCase(FMSVariableConstants.GEDUNS_CSV_EXPORT)) {
			postQuery = FMSQueryConstants.GE_DUN_NAME;
		}

		if(Utils.getValidation(data.get(FMSVariableConstants.YEAR)).isEmpty()){
			fileName =  Utils.getValidation(data.get(FMSVariableConstants.TYPE)) + ".csv";
		}else{
			fileName =  Utils.getValidation(data.get(FMSVariableConstants.TYPE)) + "_" + Utils.getValidation(data.get(FMSVariableConstants.YEAR)) + ".csv";
		}

		exportCSVData(responses, postQuery, fileName);


	}

	@Override
	public List<Map<String, Object>> downloadExcelFile(String mappingParam) {

		String query = null;

		if("MeMapping".equalsIgnoreCase(mappingParam)){
			query =FMSQueryConstants.SERVICE_ORDERS_ME_MAPPING;
		}else if("ProductMapping".equalsIgnoreCase(mappingParam)){
			query =FMSQueryConstants.SERVICE_ORDERS_PRODUCT_MAPPING;
		}else if("SegmentMapping".equalsIgnoreCase(mappingParam)){
			query =FMSQueryConstants.SERVICE_ORDERS_SEGMENT_MAPPING;
		}
		return jdbc.query(query,new MiscRowMapper());
	}

	@Override
	public Map<String, Object> getAllMetricsCountryTechData(String type,Map<String,Object> filters) {

		String businessSegment = Utils.getValidation(filters.get(FMSVariableConstants.BUSINESS_SEG));
		Map<String,Object> result = new HashMap<>();
		Map<String,Object> metricsDataCurrent = new HashMap<>();
		Map<String,Object> metricsDataHistory = new HashMap<>();
		Map<String,Object> metricsDataHistoryAverage = new HashMap<>();
		Map<String,Object> metricsAverageYear = new HashMap<>();
		String referredTable = null;
		String marketIndustryField = null;
		/** if "LEGACY" else "LATEST" */
		if(Utils.nullCheck(filters.get(FMSVariableConstants.TIME_PERIOD_TYPE)).equalsIgnoreCase(FMSVariableConstants.LEGACY)){
			referredTable = FMSVariableConstants.UNDERSCORE_LEGACY;
			businessSegment = FMSVariableConstants.DTS_SEGMENT;
			marketIndustryField = FMSVariableConstants.EMPTY_STRING;
		}else{
			referredTable = FMSVariableConstants.EMPTY_STRING;
			businessSegment = FMSVariableConstants.EMPTY_STRING;
			marketIndustryField = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
		}
		String currentMarketIndustry = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
		String currentReferredTable = FMSVariableConstants.EMPTY_STRING;
		if("country".equalsIgnoreCase(type)){
			Object[] paramsCountry = new Object[9];
			paramsCountry[0] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
			paramsCountry[1] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramsCountry[2] = FMSVariableConstants.EMPTY_STRING;
			paramsCountry[3] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
			paramsCountry[4] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramsCountry[5] = FMSVariableConstants.EMPTY_STRING;
			paramsCountry[6] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
			paramsCountry[7] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramsCountry[8] = FMSVariableConstants.EMPTY_STRING;

			Object[] paramHistCountry = new Object[7];
			paramHistCountry[0] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramHistCountry[1] = businessSegment;
			paramHistCountry[2] = businessSegment;
			paramHistCountry[3] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramHistCountry[4] = businessSegment;
			paramHistCountry[5] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramHistCountry[6] = businessSegment;

			Object[] paramAvgCountry = new Object[4];
			paramAvgCountry[0] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramAvgCountry[1] = businessSegment;
			paramAvgCountry[2] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramAvgCountry[3] = businessSegment;

			Object[] paramAvgCountryYear = new Object[8];
			paramAvgCountryYear[0] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramAvgCountryYear[1] = businessSegment;
			paramAvgCountryYear[2] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramAvgCountryYear[3] = businessSegment;
			paramAvgCountryYear[4] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramAvgCountryYear[5] = businessSegment;
			paramAvgCountryYear[6] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramAvgCountryYear[7] = businessSegment;

			Object[] paramsConvCountry = new Object[6];
			paramsConvCountry[0] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
			paramsConvCountry[1] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramsConvCountry[2] = FMSVariableConstants.EMPTY_STRING;
			paramsConvCountry[3] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
			paramsConvCountry[4] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramsConvCountry[5] = FMSVariableConstants.EMPTY_STRING;

			/**
			 * to get average based on the year that includes all 4 quarters **/
			List<String> reportName = Utils.getPenetrationMetricsCountryReportNames();
			reportName.add(FMSVariableConstants.PARTS_FLEET_PENETRATION);
			reportName.add(FMSVariableConstants.REPAIRS_FLEET_PENETRATION);
			reportName.add(FMSVariableConstants.SVCS_FLEET_PENETRATION);
			int size = reportName.size();
			/** Average based on Year */
			for (int i = 0; i < size; i++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(i))){ 
					metricsAverageYear.put(reportName.get(i), 
							jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_COUNTRY,FMSVariableConstants.ROUND_TO_2_PLACES,
									referredTable,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
									reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(i),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION), paramAvgCountryYear, new MiscRowMapper()));
				} else if(FMSVariableConstants.DOLLAR_BY_IB.equalsIgnoreCase(reportName.get(i))){
					metricsAverageYear.put(reportName.get(i), 
							jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_COUNTRY,FMSVariableConstants.ROUND_TO_0_PLACES,
									referredTable,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
									reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION), paramAvgCountryYear, new MiscRowMapper()));
				}
				else{
					if (FMSVariableConstants.CONVERSION_INDEX.equalsIgnoreCase(reportName.get(i)))
						metricsAverageYear.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_COUNTRY,FMSVariableConstants.ROUND_TO_0_PLACES,
										referredTable,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
										reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION), paramAvgCountryYear, new MiscRowMapper()));
					else
						metricsAverageYear.put(reportName.get(i),
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_COUNTRY,FMSVariableConstants.ROUND_TO_0_PLACES,
										referredTable,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(i),
										referredTable,marketIndustryField,FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),
										referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING), paramAvgCountryYear, new MiscRowMapper()));
				}
			}

			/** History */
			for (int i = 0; i < size; i++) {
				if (FMSVariableConstants.CONVERSION_INDEX.equalsIgnoreCase(reportName.get(i))) {
					metricsDataHistory.put(reportName.get(i), 
							jdbc.query(String.format(FMSQueryConstants.COUNTRY_LEVEL_PENETRATION_METRICS_HISTORY,0, FMSVariableConstants.NO_REVENUE,
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
									marketIndustryField,reportName.get(i),referredTable,marketIndustryField,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION), paramHistCountry, new MiscRowMapper()));
				}else{
					if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(i))){
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.COUNTRY_LEVEL_PENETRATION_METRICS_HISTORY,2, FMSVariableConstants.NO_ORDERS,
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
										marketIndustryField,reportName.get(i),referredTable,marketIndustryField,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION), paramHistCountry, new MiscRowMapper()));
					} else if(FMSVariableConstants.DOLLAR_BY_IB.equalsIgnoreCase(reportName.get(i))){
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.COUNTRY_LEVEL_PENETRATION_METRICS_HISTORY,0, FMSVariableConstants.NO_REVENUE,
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
										marketIndustryField,reportName.get(i),referredTable,marketIndustryField,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION), paramHistCountry, new MiscRowMapper()));
					}else{
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.COUNTRY_LEVEL_PENETRATION_METRICS_HISTORY,0, FMSVariableConstants.NO_ORDERS,
										referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,
										marketIndustryField,reportName.get(i),referredTable,marketIndustryField,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING), paramHistCountry, new MiscRowMapper()));
					}
				}
			}

			/** Average */
			for (int i = 0; i < size; i++) {
				if (FMSVariableConstants.CONVERSION_INDEX.equalsIgnoreCase(reportName.get(i))){
					metricsDataHistoryAverage.put(reportName.get(i), 
							jdbc.query(String.format(FMSQueryConstants.COUNTRY_LEVEL_PENETRATION_METRICS_AVERAGE,0,0,reportName.get(i),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(i),0,0, reportName.get(i),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(i)), paramAvgCountry, new MiscRowMapper()));
				}else if(FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(i))){
					metricsDataHistoryAverage.put(reportName.get(i), 
							jdbc.query(String.format(FMSQueryConstants.COUNTRY_LEVEL_PENETRATION_METRICS_AVERAGE,2,0.00,reportName.get(i),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(i),2,0.00, reportName.get(i),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(i)), paramAvgCountry, new MiscRowMapper()));
				} else if(FMSVariableConstants.DOLLAR_BY_IB.equalsIgnoreCase(reportName.get(i))){
					metricsDataHistoryAverage.put(reportName.get(i), 
							jdbc.query(String.format(FMSQueryConstants.COUNTRY_LEVEL_PENETRATION_METRICS_AVERAGE,0,0,reportName.get(i),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(i),0,0, reportName.get(i),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(i)), paramAvgCountry, new MiscRowMapper()));
				}else{
					metricsDataHistoryAverage.put(reportName.get(i), 
							jdbc.query(String.format(FMSQueryConstants.COUNTRY_LEVEL_PENETRATION_METRICS_AVERAGE,0,0,reportName.get(i),
									referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(i), 0,0,reportName.get(i),
									referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(i)), paramAvgCountry, new MiscRowMapper()));
				}
			}

			/** Current */
			metricsDataCurrent.put(reportName.get(3), jdbc.query(String.format(FMSQueryConstants.DOLLAR_BY_IB_COUNTRY_PENETRAION_METRICS_CURRENT,currentReferredTable,currentReferredTable,currentMarketIndustry,currentReferredTable,currentMarketIndustry,currentReferredTable),paramsCountry,new MiscRowMapper()));
			metricsDataCurrent.put(reportName.get(0), jdbc.query(String.format(FMSQueryConstants.FLEET_COVERAGE_COUNTRY_PENETRAION_METRICS_CURRENT,currentReferredTable,currentReferredTable,currentMarketIndustry,currentReferredTable,currentReferredTable),paramsCountry,new MiscRowMapper()));
			metricsDataCurrent.put(reportName.get(1), jdbc.query(String.format(FMSQueryConstants.FLEET_PEN_COUNTRY_PENETRAION_METRICS_CURRENT,currentReferredTable,currentReferredTable,currentMarketIndustry,currentReferredTable,FMSVariableConstants.LIKE_OPEX,currentReferredTable),paramsCountry,new MiscRowMapper()));
			metricsDataCurrent.put(reportName.get(2), jdbc.query(String.format(FMSQueryConstants.FLEET_PEN_F2F_COUNTRY_PENETRATION_METRICS_CURRENT,currentReferredTable,currentReferredTable,currentMarketIndustry,currentReferredTable,FMSVariableConstants.LIKE_OPEX,currentReferredTable),paramsCountry,new MiscRowMapper()));
			metricsDataCurrent.put(reportName.get(4), jdbc.query(String.format(FMSQueryConstants.CALORIC_INDEX_COUNTRY_PENETRATION_METRICS_CURRENT,currentReferredTable,currentReferredTable,currentMarketIndustry,currentReferredTable,currentReferredTable),paramsCountry,new MiscRowMapper()));
			metricsDataCurrent.put(reportName.get(5), jdbc.query(String.format(FMSQueryConstants.CONVERSION_INDEX_COUNTRY_PENETRATION_METRICS_CURRENT,currentReferredTable,currentReferredTable,currentMarketIndustry,currentReferredTable,currentReferredTable),paramsConvCountry,new MiscRowMapper()));
			metricsDataCurrent.put(reportName.get(6), jdbc.query(String.format(FMSQueryConstants.PARTS_FLEET_PEN_COUNTRY_PENETRAION_METRICS_CURRENT,currentReferredTable,currentReferredTable,currentMarketIndustry,currentReferredTable,FMSVariableConstants.LIKE_OPEX,currentReferredTable),paramsCountry,new MiscRowMapper()));
			metricsDataCurrent.put(reportName.get(7), jdbc.query(String.format(FMSQueryConstants.REPAIRS_FLEET_PEN_COUNTRY_PENETRAION_METRICS_CURRENT,currentReferredTable,currentReferredTable,currentMarketIndustry,currentReferredTable,FMSVariableConstants.LIKE_OPEX,currentReferredTable),paramsCountry,new MiscRowMapper()));
			metricsDataCurrent.put(reportName.get(8), jdbc.query(String.format(FMSQueryConstants.SVCS_FLEET_PEN_COUNTRY_PENETRAION_METRICS_CURRENT,currentReferredTable,currentReferredTable,currentMarketIndustry,currentReferredTable,FMSVariableConstants.LIKE_OPEX,currentReferredTable),paramsCountry,new MiscRowMapper()));

			result.put(FMSVariableConstants.CURRENT, metricsDataCurrent);
			result.put(FMSVariableConstants.HISTORY, metricsDataHistory);
			result.put(FMSVariableConstants.AVERAGE, metricsDataHistoryAverage);
			result.put(FMSVariableConstants.AVERAGE_BASED_ON_YEAR, metricsAverageYear);


		}else if("technology".equalsIgnoreCase(type)){

			String paramCountry = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
			String paramRegion = Utils.getValidation(filters.get(FMSVariableConstants.REGION));

			Object[] paramsTech = new Object[6];
			paramsTech[0] = "^"+Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY))+"$";
			paramsTech[1] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramsTech[2] = businessSegment;
			paramsTech[3] = "^"+Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY))+"$";
			paramsTech[4] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramsTech[5] = businessSegment;

			Object[] paramsTechRegion = new Object[4];
			paramsTechRegion[0] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramsTechRegion[1] = businessSegment;
			paramsTechRegion[2] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			paramsTechRegion[3] = businessSegment;

			/**
			 * to get average based on the year that includes all 4 quarters **/
			List<String> reportName = Utils.getPenetrationMetricsTechnologyReportNames();
			reportName.add(FMSVariableConstants.PARTS_FLEET_PENETRATION);
			reportName.add(FMSVariableConstants.REPAIRS_FLEET_PENETRATION);
			reportName.add(FMSVariableConstants.SVCS_FLEET_PENETRATION);
			int size = reportName.size();
			/** Average based on Year */
			for (int i = 0; i < size; i++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(i))){ 
					if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion == null)){
						metricsAverageYear.put(reportName.get(i),
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_TECHNOLOGY_GLOBAL,
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION),new Object[]{businessSegment,businessSegment}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (!paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion != null)){
						metricsAverageYear.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_TECHNOLOGY_REGION,
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION), paramsTechRegion, new MiscRowMapper()));
					}else{
						metricsAverageYear.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_TECHNOLOGY,
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION), paramsTech, new MiscRowMapper()));}}
				else{
					if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion == null)){
						metricsAverageYear.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_TECHNOLOGY_GLOBAL,
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING),new Object[]{businessSegment,businessSegment},  new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (!paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion != null)){
						metricsAverageYear.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_TECHNOLOGY_REGION,
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING), paramsTechRegion, new MiscRowMapper()));
					}else{
						metricsAverageYear.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_TECHNOLOGY,
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING), paramsTech, new MiscRowMapper()));}}
			}

			/** Current */
			for (int i = 0; i < size; i++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(i))){ 
					if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion == null)){
						metricsDataCurrent.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_CURRENT_GLOBAL,2, 
										reportName.get(i),2,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i),reportName.get(i),2,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i)),new Object[]{FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (!paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion != null)){
						metricsDataCurrent.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_CURRENT_REGION,2, 
										reportName.get(i),2,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i),reportName.get(i),2,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i)), new Object[]{Utils.getValidation(filters.get(FMSVariableConstants.REGION)),FMSVariableConstants.EMPTY_STRING, Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
					}else{
						metricsDataCurrent.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_CURRENT,2, 
										reportName.get(i),2,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i),reportName.get(i),2,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i)), new Object[]{"^"+Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY))+"$", Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING, "^"+Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY))+"$", Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));}
				} else{
					if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion == null)){
						metricsDataCurrent.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_CURRENT_GLOBAL,0, 
										reportName.get(i),0,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i),reportName.get(i),0,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i)),new Object[]{FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (!paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion != null)){
						metricsDataCurrent.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_CURRENT_REGION,0, 
										reportName.get(i),0,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i),reportName.get(i),0,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i)), new Object[]{ Utils.getValidation(filters.get(FMSVariableConstants.REGION)),FMSVariableConstants.EMPTY_STRING, Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
					}else{
						metricsDataCurrent.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_CURRENT,0, 
										reportName.get(i),0,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i),reportName.get(i),0,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i)), new Object[]{"^"+Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY))+"$", Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING, "^"+Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY))+"$", Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));}
				}
			}

			/** History */
			for (int i = 0; i < size; i++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(i))){
					if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion == null)){
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_HISTORY_GLOBAL,2,reportName.get(i), 2,
										referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,reportName.get(i), reportName.get(i), 2, 
										referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,reportName.get(i)),new Object[]{businessSegment,businessSegment}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (!paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion != null)){
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_HISTORY_REGION,2,reportName.get(i), 2,
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(i), reportName.get(i), 2, 
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(i)), paramsTechRegion, new MiscRowMapper()));
					}else{
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_HISTORY,2,reportName.get(i), 2,
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(i), reportName.get(i), 2, 
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(i)), paramsTech, new MiscRowMapper()));
					}
				} else{
					if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion == null)){
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_HISTORY_GLOBAL,0,reportName.get(i), 0, 
										referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,reportName.get(i), reportName.get(i), 0, 
										referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,reportName.get(i)),new Object[]{businessSegment,businessSegment}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (!paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion != null)){
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_HISTORY_REGION,0,reportName.get(i), 0, 
										referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(i), reportName.get(i), 0, 
										referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(i)), paramsTechRegion, new MiscRowMapper()));
					}else{
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_HISTORY,0,reportName.get(i), 0, 
										referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(i), reportName.get(i), 0, 
										referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(i)), paramsTech, new MiscRowMapper()));}
				}
			}

			/** Average */
			for (int i = 0; i < size; i++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(i))){ 
					if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion == null)){
						metricsDataHistoryAverage.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_AVERAGE_GLOBAL,
										FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(i),referredTable, FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
										marketIndustryField,reportName.get(i),FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(i),
										referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,reportName.get(i)),new Object[]{businessSegment,businessSegment}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (!paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion != null)){
						metricsDataHistoryAverage.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_AVERAGE_REGION,
										FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(i),referredTable,marketIndustryField, FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
										reportName.get(i),FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(i),
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(i)), paramsTechRegion, new MiscRowMapper()));
					}else{
						metricsDataHistoryAverage.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_AVERAGE,
										FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(i),referredTable,marketIndustryField, FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, 
										reportName.get(i),FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(i),
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(i)), paramsTech, new MiscRowMapper()));}
				}else{
					if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion == null)){
						metricsDataHistoryAverage.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_AVERAGE_GLOBAL,
										FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(i),referredTable, FMSVariableConstants.EMPTY_STRING, 
										marketIndustryField,reportName.get(i),FMSVariableConstants.ROUND_TO_0_PLACES, 0, reportName.get(i),
										referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,reportName.get(i)),new Object[]{businessSegment,businessSegment}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) 
							&& (!paramRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramRegion != null)){
						metricsDataHistoryAverage.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_AVERAGE_REGION,
										FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(i),referredTable,marketIndustryField, FMSVariableConstants.EMPTY_STRING, 
										reportName.get(i),FMSVariableConstants.ROUND_TO_0_PLACES, 0, reportName.get(i),
										referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(i)), paramsTechRegion, new MiscRowMapper()));
					}else{
						metricsDataHistoryAverage.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.TECHNOLOGY_LEVEL_PENETRATION_METRICS_AVERAGE,
										FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(i),referredTable,marketIndustryField, FMSVariableConstants.EMPTY_STRING, 
										reportName.get(i),FMSVariableConstants.ROUND_TO_0_PLACES, 0, reportName.get(i),
										referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(i)), paramsTech, new MiscRowMapper()));}
				}
			}

			result.put(FMSVariableConstants.CURRENT, metricsDataCurrent);
			result.put(FMSVariableConstants.HISTORY, metricsDataHistory);
			result.put(FMSVariableConstants.AVERAGE, metricsDataHistoryAverage);
			result.put(FMSVariableConstants.AVERAGE_BASED_ON_YEAR, metricsAverageYear);
		}

		return result;
	}

	@Override
	public Map<String, Object> getPenMetricsSegmentData(String type, Map<String, Object> filters) {

		Map<String,Object> result = new HashMap<>();
		Map<String,Object> metricsDataCurrent = new HashMap<>();
		Map<String,Object> metricsDataHistory = new HashMap<>();
		Map<String,Object> metricsDataHistoryAverage = new HashMap<>();
		Map<String,Object> metricsAverageYear = new HashMap<>();

		if(FMSVariableConstants.SEGMENT.equalsIgnoreCase(type)){

			String paramCountry = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
			String paramsRegion = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			String businessSegment = Utils.getValidation(filters.get(FMSVariableConstants.BUSINESS_SEG));
			String referredTable = null;
			String marketIndustryField = null;
			/** if "LEGACY" else "LATEST" */
			if(Utils.nullCheck(filters.get(FMSVariableConstants.TIME_PERIOD_TYPE)).equalsIgnoreCase(FMSVariableConstants.LEGACY)){
				referredTable = FMSVariableConstants.UNDERSCORE_LEGACY;
				businessSegment = FMSVariableConstants.DTS_SEGMENT;
				marketIndustryField = FMSVariableConstants.EMPTY_STRING;
			}else{
				referredTable = FMSVariableConstants.EMPTY_STRING;
				businessSegment = FMSVariableConstants.EMPTY_STRING;
				marketIndustryField = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
			}
			String currentMarketIndustry = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
			String currentReferredTable = FMSVariableConstants.EMPTY_STRING;
			/**
			 * to get average based on the year that includes all 4 quarters **/
			List<String> reportName = Utils.getPenetrationMetricsTechnologyReportNames();

			int size = reportName.size();
			/** Average based on Year */
			for (int i = 0; i < size; i++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(i))){
					if((paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion == null) && 
							(paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null)){
						metricsAverageYear.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_SEGMENT_GLOBAL,
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION),
										new Object[]{businessSegment, businessSegment}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) && 
							(!paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion != null)){
						metricsAverageYear.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_SEGMENT_REGION,
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION), 
										new Object[]{paramsRegion,businessSegment,paramsRegion,businessSegment}, new MiscRowMapper()));
					}else{
						metricsAverageYear.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_SEGMENT_COUNTRY,
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION), 
										new Object[]{paramCountry,paramsRegion,businessSegment,paramCountry,paramsRegion,businessSegment}, new MiscRowMapper()));
					}
				} else{
					if((paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion == null) && 
							(paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null)){
						metricsAverageYear.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_SEGMENT_GLOBAL,
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING), 
										new Object[]{businessSegment,businessSegment}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) && 
							(!paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion != null)){
						metricsAverageYear.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_SEGMENT_REGION,
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING), 
										new Object[]{paramsRegion,businessSegment,paramsRegion,businessSegment}, new MiscRowMapper()));
					}else{
						metricsAverageYear.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_SEGMENT_COUNTRY,
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING), 
										new Object[]{paramCountry,paramsRegion,businessSegment,paramCountry,paramsRegion,businessSegment}, new MiscRowMapper()));
					}
				}
			}

			/** Current */
			for (int i = 0; i < size; i++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(i))){ 
					if((paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion == null) && 
							(paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null)){
						metricsDataCurrent.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_CURRENT_GLOBAL,2, reportName.get(i),2,
										currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i),reportName.get(i),2,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i)),
										new Object[]{FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) && 
							(!paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion != null)){
						metricsDataCurrent.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_CURRENT_REGION,2, reportName.get(i),2,
										currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i),reportName.get(i),2,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i)), 
										new Object[]{paramsRegion,FMSVariableConstants.EMPTY_STRING,paramsRegion,FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
					}else{
						metricsDataCurrent.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_CURRENT_COUNTRY,2, reportName.get(i),2,
										currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i),reportName.get(i),2,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i)), 
										new Object[]{paramCountry,paramsRegion,FMSVariableConstants.EMPTY_STRING,paramCountry,paramsRegion,FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
					}
				} else{
					if((paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion == null) && 
							(paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null)){
						metricsDataCurrent.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_CURRENT_GLOBAL,0, reportName.get(i),0,
										currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i),reportName.get(i),0,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i)),
										new Object[]{FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) && 
							(!paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion != null)){
						metricsDataCurrent.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_CURRENT_REGION,0, reportName.get(i),0,
										currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i),reportName.get(i),0,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i)), 
										new Object[]{paramsRegion,FMSVariableConstants.EMPTY_STRING,paramsRegion,FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
					}else{
						metricsDataCurrent.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_CURRENT_COUNTRY,0, reportName.get(i),0,
										currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i),reportName.get(i),0,currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(i)), 
										new Object[]{paramCountry,paramsRegion,FMSVariableConstants.EMPTY_STRING,paramCountry,paramsRegion,FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
					}
				}
			}

			/** History */
			for (int i = 0; i < size; i++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(i))){
					if((paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion == null) && 
							(paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null)){
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_HISTORY_GLOBAL,2,reportName.get(i), 2,
										referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,reportName.get(i), reportName.get(i), 2, 
										referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,reportName.get(i)),
										new Object[]{businessSegment,businessSegment}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) && 
							(!paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion != null)){
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_HISTORY_REGION,2,reportName.get(i), 2,
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(i), reportName.get(i), 2, 
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(i)), 
										new Object[]{paramsRegion,businessSegment,paramsRegion,businessSegment}, new MiscRowMapper()));
					}else{
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_HISTORY_COUNTRY,2,reportName.get(i), 2,
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(i), reportName.get(i), 2, 
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(i)), 
										new Object[]{paramCountry,paramsRegion,businessSegment,paramCountry,paramsRegion,businessSegment}, new MiscRowMapper()));
					}
				} else{
					if((paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion == null) && 
							(paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null)){
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_HISTORY_GLOBAL,0,reportName.get(i), 0, 
										referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,reportName.get(i), reportName.get(i), 0,referredTable,FMSVariableConstants.EMPTY_STRING, 
										marketIndustryField,reportName.get(i)),
										new Object[]{businessSegment,businessSegment}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) && 
							(!paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion != null)){
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_HISTORY_REGION,0,reportName.get(i), 0, 
										referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(i), reportName.get(i), 0,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, 
										reportName.get(i)), new Object[]{paramsRegion,businessSegment,paramsRegion,businessSegment}, new MiscRowMapper()));
					}else{
						metricsDataHistory.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_HISTORY_COUNTRY,0,reportName.get(i), 0, 
										referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(i), reportName.get(i), 0,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, 
										reportName.get(i)), new Object[]{paramCountry,paramsRegion,businessSegment,paramCountry,paramsRegion,businessSegment}, new MiscRowMapper()));
					}
				}
			}

			/** Average */
			for (int i = 0; i < size; i++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(i))){ 
					if((paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion == null) && 
							(paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null)){
						metricsDataHistoryAverage.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_AVERAGE_GLOBAL,
										FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(i),referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField, 
										reportName.get(i),FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(i),referredTable,
										FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,reportName.get(i)),
										new Object[]{businessSegment,businessSegment}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) && 
							(!paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion != null)){
						metricsDataHistoryAverage.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_AVERAGE_REGION,
										FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, 
										reportName.get(i),FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(i),
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(i)), 
										new Object[]{paramsRegion,businessSegment,paramsRegion,businessSegment}, new MiscRowMapper()));
					}else{
						metricsDataHistoryAverage.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_AVERAGE_COUNTRY,
										FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, 
										reportName.get(i),FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(i),
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(i)), 
										new Object[]{paramCountry,paramsRegion,businessSegment,paramCountry,paramsRegion,businessSegment}, new MiscRowMapper()));}
				}else{
					if((paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion == null) && 
							(paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null)){
						metricsDataHistoryAverage.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_AVERAGE_GLOBAL,
										FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(i),referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,reportName.get(i),
										FMSVariableConstants.ROUND_TO_0_PLACES, 0, reportName.get(i),referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,reportName.get(i)), 
										new Object[]{businessSegment,businessSegment}, new MiscRowMapper()));
					}else if((paramCountry.equals(FMSVariableConstants.EMPTY_STRING) || paramCountry == null) && 
							(!paramsRegion.equals(FMSVariableConstants.EMPTY_STRING) || paramsRegion != null)){
						metricsDataHistoryAverage.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_AVERAGE_REGION,
										FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(i),
										FMSVariableConstants.ROUND_TO_0_PLACES, 0, reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(i)), 
										new Object[]{paramsRegion,businessSegment,paramsRegion,businessSegment}, new MiscRowMapper()));
					}else{
						metricsDataHistoryAverage.put(reportName.get(i), 
								jdbc.query(String.format(FMSQueryConstants.SEGMENT_LEVEL_PENETRATION_METRICS_AVERAGE_COUNTRY,
										FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(i),
										FMSVariableConstants.ROUND_TO_0_PLACES, 0, reportName.get(i),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(i)), 
										new Object[]{paramCountry,paramsRegion,businessSegment,paramCountry,paramsRegion,businessSegment}, new MiscRowMapper()));
					}
				}
			}

			result.put(FMSVariableConstants.CURRENT, metricsDataCurrent);
			result.put(FMSVariableConstants.HISTORY, metricsDataHistory);
			result.put(FMSVariableConstants.AVERAGE, metricsDataHistoryAverage);
			result.put(FMSVariableConstants.AVERAGE_BASED_ON_YEAR, metricsAverageYear);
		}

		return result;
	}

	@Override
	public List<String> getPenetratinMetricsCountryDropdown(String businessSegment, Map<String,Object> filters) {

		businessSegment = FMSVariableConstants.EMPTY_STRING;
		Object[] param = new Object[3];
		param[0] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
		param[1] = businessSegment;
		param[2] = Utils.getValidation(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		return jdbc.queryForList(FMSQueryConstants.PENETRATION_METRICS_COUTRY_DROPDOWN,param,String.class);
	}

	@Override
	public List<String> getPenetratinMetricsRegionDropdown(Map<String,Object> filters) {
		String marketInd = Utils.getValidation(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		return jdbc.queryForList(FMSQueryConstants.PENETRATION_METRICS_REGION_DROPDOWN,String.class);
	}

	@Override
	public List<String> getAllMetricsCountrySiteDropdown(String businessSegment,Map<String,Object> filters) {

		businessSegment = FMSVariableConstants.EMPTY_STRING;
		Object[] param = new Object[3];
		param[0] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
		param[1] = businessSegment;
		param[2] = Utils.getValidation(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		if(Utils.getValidation(filters.get(FMSVariableConstants.STATE)) != null &&
				Utils.getValidation(filters.get(FMSVariableConstants.STATE)).equalsIgnoreCase(Utils.getValidation(FMSVariableConstants.SITE))){
			return jdbc.queryForList(FMSQueryConstants.COUNTRY_DROPDOWN_SITE_LEVEL,param, String.class);
		}else if(Utils.getValidation(filters.get(FMSVariableConstants.STATE)) != null  && 
				Utils.getValidation(filters.get(FMSVariableConstants.STATE)).equalsIgnoreCase(Utils.getValidation(FMSVariableConstants.SEGMENT))){
			return jdbc.queryForList(FMSQueryConstants.COUNTRY_DROPDOWN_SEGMENT_LEVEL,param, String.class);
		}else{
			return null;
		}
	}

	@Override
	public Map<String, Object> getAllMetricsCountrySiteData(Map<String, Object> filters) {

		String businessSegment = Utils.getValidation(filters.get(FMSVariableConstants.BUSINESS_SEG));

		Map<String,Object> result = new HashMap<>();
		Map<String,Object> metricsDataCurrent = new HashMap<>();
		Map<String,Object> metricsDataAverage = new HashMap<>();
		Map<String,Object> metricsDataHistory = new HashMap<>();
		List<String> reportName = Utils.getPenetrationMetricsTechnologyReportNames();
		String referredTable = null;
		String marketIndustryField = null;
		/** if "LEGACY" else "LATEST" */
		if(Utils.nullCheck(filters.get(FMSVariableConstants.TIME_PERIOD_TYPE)).equalsIgnoreCase(FMSVariableConstants.LEGACY)){
			referredTable = FMSVariableConstants.UNDERSCORE_LEGACY;
			businessSegment = FMSVariableConstants.DTS_SEGMENT;
			marketIndustryField = FMSVariableConstants.EMPTY_STRING;
		}else{
			referredTable = FMSVariableConstants.EMPTY_STRING;
			businessSegment = FMSVariableConstants.EMPTY_STRING;
			marketIndustryField = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
		}
		String currentMarketIndustry = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
		String currentReferredTable = FMSVariableConstants.EMPTY_STRING;

		Object[] params = new Object[6];
		params[0] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
		params[1] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
		params[2] = businessSegment;
		params[3] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
		params[4] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
		params[5] = businessSegment;

		Object[] paramsHistory = new Object[15];
		paramsHistory[0] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
		paramsHistory[1] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
		paramsHistory[2] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
		paramsHistory[3] = businessSegment;
		paramsHistory[4] = businessSegment;
		paramsHistory[5] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
		paramsHistory[6] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
		paramsHistory[7] = businessSegment;
		paramsHistory[8] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
		paramsHistory[9] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
		paramsHistory[10] = businessSegment;
		paramsHistory[11] = businessSegment;
		paramsHistory[12] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
		paramsHistory[13] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
		paramsHistory[14] = businessSegment;

		if(Utils.getValidation(filters.get(FMSVariableConstants.TYPE)).equalsIgnoreCase(FMSVariableConstants.TOP25)){
			/** Current */
			for (int index = 0; index < reportName.size(); index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					metricsDataCurrent.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_CURRENT, 2,0.00, reportName.get(index),
									currentReferredTable,currentMarketIndustry,reportName.get(index),reportName.get(index),FMSVariableConstants.TOP_LIMIT_25,reportName.get(index),currentReferredTable,currentMarketIndustry,reportName.get(index)),
									new Object[]{Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY)), Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING, Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY)), Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
				} else {
					metricsDataCurrent.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_CURRENT, 0,0, reportName.get(index),
									currentReferredTable,currentMarketIndustry,reportName.get(index),reportName.get(index),FMSVariableConstants.TOP_LIMIT_25,reportName.get(index),currentReferredTable,currentMarketIndustry,reportName.get(index)),
									new Object[]{Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY)), Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING, Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY)), Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
				}
			}
			/** History */
			for (int index = 0; index < reportName.size(); index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					metricsDataHistory.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_HISTORY, 2,0.00,reportName.get(index),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(index),FMSVariableConstants.TOP_LIMIT_25,
									referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,reportName.get(index),reportName.get(index),referredTable,marketIndustryField,reportName.get(index),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION),paramsHistory, new MiscRowMapper()));
				} else {
					metricsDataHistory.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_HISTORY, 0,0, reportName.get(index),
									referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(index),FMSVariableConstants.TOP_LIMIT_25,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,
									reportName.get(index),reportName.get(index),referredTable,marketIndustryField,reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,
									referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING),paramsHistory, new MiscRowMapper()));
				}
			}
			/** Average */
			for (int index = 0; index < reportName.size(); index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					metricsDataAverage.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_AVERAGE, FMSVariableConstants.ROUND_TO_2_PLACES, 0.00, 
									reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(index), 
									FMSVariableConstants.TOP_LIMIT_25,FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(index),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(index)),params, new MiscRowMapper()));
				} else {
					metricsDataAverage.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_AVERAGE, FMSVariableConstants.ROUND_TO_0_PLACES, 0, 
									reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(index), FMSVariableConstants.TOP_LIMIT_25,
									FMSVariableConstants.ROUND_TO_0_PLACES, 0, reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(index) ),
									params, new MiscRowMapper()));
				}
			}

		}else if(Utils.getValidation(filters.get(FMSVariableConstants.TYPE)).equalsIgnoreCase(FMSVariableConstants.BOTTOM25)){
			/** Current */
			for (int index = 0; index < reportName.size(); index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					metricsDataCurrent.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_CURRENT, 2,0.00, reportName.get(index),
									currentReferredTable,currentMarketIndustry,reportName.get(index),reportName.get(index),FMSVariableConstants.BOTTOM_LIMIT_25,reportName.get(index),currentReferredTable,currentMarketIndustry,reportName.get(index)),
									new Object[]{Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY)), Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING, Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY)), Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
				} else {
					metricsDataCurrent.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_CURRENT, 0,0, reportName.get(index),
									currentReferredTable,currentMarketIndustry,reportName.get(index),reportName.get(index),FMSVariableConstants.BOTTOM_LIMIT_25,reportName.get(index),currentReferredTable,currentMarketIndustry,reportName.get(index)),
									new Object[]{Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY)), Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING, Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY)), Utils.getValidation(filters.get(FMSVariableConstants.REGION)), FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
				}
			}
			/** History */
			for (int index = 0; index < reportName.size(); index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					metricsDataHistory.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_HISTORY, 2,0.00, reportName.get(index),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(index),FMSVariableConstants.BOTTOM_LIMIT_25,
									referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,reportName.get(index),reportName.get(index),referredTable,marketIndustryField,reportName.get(index),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,referredTable,marketIndustryField,
									FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION),paramsHistory, new MiscRowMapper()));
				} else {
					metricsDataHistory.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_HISTORY, 0,0, reportName.get(index),
									referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING ,reportName.get(index),FMSVariableConstants.BOTTOM_LIMIT_25,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,
									reportName.get(index),reportName.get(index),referredTable,marketIndustryField,reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,referredTable,marketIndustryField,
									FMSVariableConstants.EMPTY_STRING),paramsHistory, new MiscRowMapper()));
				}
			}
			/** Average */
			for (int index = 0; index < reportName.size(); index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					metricsDataAverage.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_AVERAGE, FMSVariableConstants.ROUND_TO_2_PLACES,0.00, 
									reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(index), FMSVariableConstants.BOTTOM_LIMIT_25,
									FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
									reportName.get(index)),params, new MiscRowMapper()));
				} else {
					metricsDataAverage.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_AVERAGE, FMSVariableConstants.ROUND_TO_0_PLACES,0, 
									reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(index), FMSVariableConstants.BOTTOM_LIMIT_25,
									FMSVariableConstants.ROUND_TO_0_PLACES, 0, reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(index) ),
									params, new MiscRowMapper()));
				}
			}
		}

		/**
		 * Average Calculation based on the Year   
		 ***/
		Map<String,Object> averageCalculationOnYear = new HashMap<>();
		Object[] averageBasedOnYear = new Object[12];

		averageBasedOnYear[0] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
		averageBasedOnYear[1] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
		averageBasedOnYear[2] = businessSegment;
		averageBasedOnYear[3] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
		averageBasedOnYear[4] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
		averageBasedOnYear[5] = businessSegment;
		averageBasedOnYear[6] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
		averageBasedOnYear[7] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
		averageBasedOnYear[8] = businessSegment;
		averageBasedOnYear[9] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
		averageBasedOnYear[10] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
		averageBasedOnYear[11] = businessSegment;

		try {
			if(Utils.getValidation(filters.get(FMSVariableConstants.TYPE)).equalsIgnoreCase(FMSVariableConstants.TOP25)){
				for (int index = 0; index < reportName.size(); index++) {
					if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))) 
						averageCalculationOnYear.put(reportName.get(index), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_SITES, 
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(index),referredTable,marketIndustryField,reportName.get(index),FMSVariableConstants.TOP_25,
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(index),
										referredTable,marketIndustryField,reportName.get(index),FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(index),
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION),averageBasedOnYear, new MiscRowMapper()));
					else
						averageCalculationOnYear.put(reportName.get(index), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_SITES, 
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(index),referredTable,marketIndustryField,reportName.get(index),FMSVariableConstants.TOP_25,
										referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(index),referredTable,marketIndustryField,reportName.get(index),
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING),averageBasedOnYear, 
										new MiscRowMapper()));
				}

			}else if(Utils.getValidation(filters.get(FMSVariableConstants.TYPE)).equalsIgnoreCase(FMSVariableConstants.BOTTOM25)){
				for (int index = 0; index < reportName.size(); index++) {
					if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))) 
						averageCalculationOnYear.put(reportName.get(index), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_SITES, 
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(index),referredTable,marketIndustryField,reportName.get(index),FMSVariableConstants.BOTTOM_25,
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(index),
										referredTable,marketIndustryField,reportName.get(index),FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(index),referredTable,marketIndustryField,
										FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION),averageBasedOnYear, new MiscRowMapper()));
					else
						averageCalculationOnYear.put(reportName.get(index), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_SITES, 
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(index),referredTable,marketIndustryField,reportName.get(index),FMSVariableConstants.BOTTOM_25,referredTable,marketIndustryField,
										FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(index),referredTable,marketIndustryField,reportName.get(index),
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING),
										averageBasedOnYear, new MiscRowMapper()));
				}
			}
		} catch (Exception e) {
			log.error(FMSVariableConstants.EXCEPTION + e.getStackTrace());
		}
		log.info("Average Calculation based on the Year Successfull for Sites level!!!!");
		result.put(FMSVariableConstants.AVERAGE_BASED_ON_YEAR, averageCalculationOnYear);
		/**
		 * End of Average Calculation based on the Year
		 **/
		result.put(FMSVariableConstants.CURRENT, metricsDataCurrent);
		result.put(FMSVariableConstants.AVERAGE, metricsDataAverage);
		result.put(FMSVariableConstants.HISTORY, metricsDataHistory);


		return result;
	}

	@Override
	public Map<String, Object> penetrationExportExcelData(Map<String, Object> filters) {

		String businessSegment = Utils.getValidation(filters.get(FMSVariableConstants.BUSINESS_SEG));
		String referredTable = null;
		String marketIndustryField = null;
		/** if "LEGACY" else "LATEST" */
		if(Utils.nullCheck(filters.get(FMSVariableConstants.TIME_PERIOD_TYPE)).equalsIgnoreCase(FMSVariableConstants.LEGACY)){
			referredTable = FMSVariableConstants.UNDERSCORE_LEGACY;
			businessSegment = FMSVariableConstants.DTS_SEGMENT;
			marketIndustryField = FMSVariableConstants.EMPTY_STRING;
		}else{
			referredTable = FMSVariableConstants.EMPTY_STRING;
			businessSegment = FMSVariableConstants.EMPTY_STRING;
			marketIndustryField = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
		}
		String currentMarketIndustry = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
		String currentReferredTable = FMSVariableConstants.EMPTY_STRING;
		String query = null;
		String avgQuery = null;
		Map<String,Object> result =new HashMap<>();
		String country = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
		String region = Utils.getValidation(filters.get(FMSVariableConstants.REGION));

		List<String> reportName = Utils.getPenetrationMetricsTechnologyReportNames();
		String columnName = null;

		if(Utils.getValidation(filters.get(FMSVariableConstants.PERIOD)).equalsIgnoreCase(FMSVariableConstants.CURRENT)){
			switch(Utils.getValidation(filters.get(FMSVariableConstants.REPORT))){
			case FMSVariableConstants.FLEETCOVERAGE:
				query = String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_CURRENT_EXPT,0, reportName.get(0),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(0),reportName.get(0),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(0));
				break;
			case FMSVariableConstants.FLEETPEN:
				query = String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_CURRENT_EXPT,0, reportName.get(1),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(1),reportName.get(1),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(1));
				break;
			case FMSVariableConstants.FLEETPENF2F:
				query = String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_CURRENT_EXPT,0, reportName.get(2),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(2),reportName.get(2),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(2));
				break;
			case FMSVariableConstants.CALORICINDEX:
				query = String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_CURRENT_EXPT,2, reportName.get(3),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(3),reportName.get(3),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(3));
				break;
			}
		}else if(Utils.getValidation(filters.get(FMSVariableConstants.PERIOD)).equalsIgnoreCase(FMSVariableConstants.HISTORY)){
			switch(Utils.getValidation(filters.get(FMSVariableConstants.REPORT))){
			case FMSVariableConstants.FLEETCOVERAGE:
				query = String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_HISTORY,0,0, reportName.get(0),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(0),FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,reportName.get(0),reportName.get(0),referredTable,marketIndustryField,reportName.get(0),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING);
				break;
			case FMSVariableConstants.FLEETPEN:
				query =String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_HISTORY,0,0, reportName.get(1),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(1),FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,reportName.get(1),reportName.get(1),referredTable,marketIndustryField,reportName.get(1),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING); 
				break;
			case FMSVariableConstants.FLEETPENF2F:
				query = String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_HISTORY,0,0, reportName.get(2),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(2),FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,reportName.get(2),reportName.get(2),referredTable,marketIndustryField,reportName.get(2),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING);
				break;
			case FMSVariableConstants.CALORICINDEX:
				query = String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_HISTORY,2,0.00, reportName.get(3),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(3),FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,reportName.get(3),reportName.get(3),referredTable,marketIndustryField,reportName.get(3),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION);
				break;
			}
			switch(Utils.getValidation(filters.get(FMSVariableConstants.REPORT))){
			case FMSVariableConstants.FLEETCOVERAGE:
				avgQuery = String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_AVERAGE, FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(0),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(0), FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(0),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(0) );
				columnName = reportName.get(0);
				break;
			case FMSVariableConstants.FLEETPEN:
				avgQuery = String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_AVERAGE,FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(1),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(1), FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(1),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(1));
				columnName = reportName.get(1);
				break;
			case FMSVariableConstants.FLEETPENF2F:
				avgQuery = String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_AVERAGE,FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(2),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(2), FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(2),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(2));
				columnName = reportName.get(2);
				break;
			case FMSVariableConstants.CALORICINDEX:
				avgQuery = String.format(FMSQueryConstants.SITE_LEVEL_PENETRATION_METRICS_AVERAGE,FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(3),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(3),FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(3),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(3));
				columnName = reportName.get(3);
				break;
			}

			Object[] averageBasedOnYear = new Object[12];

			averageBasedOnYear[0] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
			averageBasedOnYear[1] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			averageBasedOnYear[2] = businessSegment;
			averageBasedOnYear[3] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
			averageBasedOnYear[4] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			averageBasedOnYear[5] = businessSegment;
			averageBasedOnYear[6] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
			averageBasedOnYear[7] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			averageBasedOnYear[8] = businessSegment;
			averageBasedOnYear[9] = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
			averageBasedOnYear[10] = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
			averageBasedOnYear[11] = businessSegment;

			try {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(columnName))
					result.put(FMSVariableConstants.AVERAGE_YEAR, jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_SITES, FMSVariableConstants.ROUND_TO_2_PLACES,columnName,referredTable,marketIndustryField,columnName,FMSVariableConstants.EXPORT_SITE_LEVEL_AVG_YEAR,referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,FMSVariableConstants.ROUND_TO_2_PLACES,columnName,referredTable,marketIndustryField,columnName,FMSVariableConstants.ROUND_TO_2_PLACES,columnName,referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION),averageBasedOnYear, new MiscRowMapper()));
				else
					result.put(FMSVariableConstants.AVERAGE_YEAR, jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_SITES, FMSVariableConstants.ROUND_TO_0_PLACES,columnName,referredTable,marketIndustryField,columnName,FMSVariableConstants.EXPORT_SITE_LEVEL_AVG_YEAR,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.ROUND_TO_0_PLACES,columnName,referredTable,marketIndustryField,columnName,FMSVariableConstants.ROUND_TO_0_PLACES,columnName,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING),averageBasedOnYear, new MiscRowMapper()));
			} catch (Exception e) {
				log.error(FMSVariableConstants.EXCEPTION + e.getStackTrace());
			}
		}

		if (Utils.getValidation(filters.get(FMSVariableConstants.PERIOD)).equalsIgnoreCase(FMSVariableConstants.CURRENT)){
			result.put("Current", jdbc.query(query, new Object[]{country,region,FMSVariableConstants.EMPTY_STRING,country,region,FMSVariableConstants.EMPTY_STRING},new MiscRowMapper()));
		}else if(Utils.getValidation(filters.get(FMSVariableConstants.PERIOD)).equalsIgnoreCase(FMSVariableConstants.HISTORY)){
			result.put("History", jdbc.query(query,new Object[]{country,country,region,businessSegment,businessSegment,country,region,businessSegment,country,region,businessSegment,businessSegment,country,region,businessSegment},new MiscRowMapper()));
			result.put("Average", jdbc.query(avgQuery,new Object[]{country,region,businessSegment,country,region,businessSegment},new MiscRowMapper()));
		}
		return result;
	}

	@Override
	public Map<String, Object> penetrationDashboard(String businessSegment,Map<String, Object> filters) {

		/**
		 * COLORS: [GREEN:PERFORMING, YELLOW:UNPERFORMING, RED:UNMAPPED SITES]
		 * FILTERS: PENETRATION DASHBOARD
1. ON DEFAULT PAGE LOAD (ALL THE REGIONS APPEAR ON SCREEN)
	-- REPORT(report) : FLEETCOVERAGE(fleetCoverage)/FLEETPEN(fleetPenetration)
2. ON CLICK ON UNPERFORMING REGION COUNT (THE UNERPORMING REGIONS APPEAR ON SCREEN)
	-- REPORT(report) : FLEETCOVERAGE(fleetCoverage)/FLEETPEN(fleetPenetration)
	-- STATE(state) : REGION(region)
3. ON CLICK OF A PARTICULAR REGION FROM THE MAP (THE COUNTRIES OF THE REGION APPEAR ON SCREEN)
	-- REPORT(report) : FLEETCOVERAGE(fleetCoverage)/FLEETPEN(fleetPenetration)
	-- LEVEL(level) : REGION(region)
	-- REGION(region) : NAME OF THE SELECTED REGION FROM THE MAP
4. ON CLICK ON UNPERFORMING COUNTRY COUNT (THE UNPERFORMING COUNTRIES APPEAR ON SCREEN)
	-- REPORT(report) : FLEETCOVERAGE(fleetCoverage)/FLEETPEN(fleetPenetration)
	-- STATE(state) : COUNTRY(country)
5. ON CLICK OF A PARTICULAR COUNTRY FROM THE MAP (THE SITES OF THAT PARTICULAR COUNTRY APPEAR ON SCREEN)
	-- REPORT(report) : FLEETCOVERAGE(fleetCoverage)/FLEETPEN(fleetPenetration)
	-- LEVEL(level) : COUNTRY(country)
	-- COUNTRY(country) : NAME OF THE SELECTED COUNTRY FROM THE MAP
6. ON CLICK ON UNPERFORMING SITE COUNT (THE UNPERFORMING SITES APPEAR ON SCREEN)
	-- REPORT(report) : FLEETCOVERAGE(fleetCoverage)/FLEETPEN(fleetPenetration)
	-- STATE(state) : SITE(site)
7. ON CLICK OF A PARTICULAR SITE FROM THE MAP (LIST VIEW OF ALL THE SITES OF THE COUNTRY IT BELONGS TO)
	-- REPORT(report) : FLEETCOVERAGE(fleetCoverage)/FLEETPEN(fleetPenetration)
	-- LEVEL(level) : SITE(site)
	-- COUNTRY(country) : NAME OF THE COUNTRY WHERE THE SITE BELONGS FROM THE MAP
8. ON CLICK OF A SITE FROM THE MAP WHERE ALL THE SITES ARE UNPERFORMING 
			  (THE SCENARIO WE GET AFTER CLICKING ON UNPERFORMING SITE COUNT)
			  (LIST VIEW OF ALL THE SITES UNPERFORMING THROUGHOUT THE WORLD)
	-- REPORT(report) : FLEETCOVERAGE(fleetCoverage)/FLEETPEN(fleetPenetration)
	-- LEVEL(level) : WORLDSITE(worldSite)
9. ON CLICK ON UNMAPPED SITE COUNT (LIST VIEW OF ALL THE SITES WHICH ARE UNMAPPED)
	-- REPORT(report) : FLEETCOVERAGE(fleetCoverage)/FLEETPEN(fleetPenetration)
	-- STATE(state) : UNMAPPEDSITE(unmappedSite)
		 *## -- OPTION(option) : EXPORT(export) (IF REQUIRED TO EXPORT, WHAT APPEARS ON SCREEN)
		 *		OPTION(option) : EXPORTALL(exportAll) (EXPORT ALL SITES ALL OVER THE WORLD)
		 *		QUARTER(quarter) : CURRENT(CURRENT) (CURRENT QUARTER DATA) [ANY THING OTHER THAN CURRENT IS OVER ALL] MANADATORY FILTER
		 *		BUSINESSSEGMENT(businessSegment) : 'TMS'/'DTS' MANADATORY FILTER
		 *	(HOWEVER UI MUST SEND SAME FILTERS OTHER THAN OPTION TO SERVICE SIDE FOR EXPORT)
		 **/

		businessSegment = "";

		Map<String,Object> result = new HashMap<>();
		String reports = null;
		String region = null;
		String country = null;
		String marketIndustryField = Utils.getValidation(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		Integer value = Utils.getIntegerValidation(filters.get(FMSVariableConstants.VALUE));

		switch(Utils.getValidation(filters.get(FMSVariableConstants.REPORT))){
		case FMSVariableConstants.FLEETCOVERAGE:
			reports = "fleet_coverage";
			break;
		case FMSVariableConstants.FLEETPEN:
			reports = "fleet_penetration";
			break;
		case FMSVariableConstants.FLEETPENF2F:
			reports = "fleet_pen_f2f";
			break;
		case FMSVariableConstants.CALORICINDEX:
			reports = FMSVariableConstants.CALORIC_INDEX;
			break;
		}

		if(Utils.getValidation(filters.get(FMSVariableConstants.QUARTER)).equalsIgnoreCase(FMSVariableConstants.CURRENT)){
			result.put("IBOByReg",jdbc.query(FMSQueryConstants.RETRIEVE_IBOBYREG_CURRENT_METRICS_DATA,new Object[]{businessSegment,marketIndustryField}, new MiscRowMapper()));
			result.put("UnperformingRegCount",jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORMING_REGION_COUNT, reports,reports),new Object[]{value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			result.put("UnperformingCountryCount",jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORMING_COUNTRY_COUNT,reports,reports),new Object[]{value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			result.put("UnperformingSitesCount",jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORMING_SITE_COUNT,reports,reports),new Object[]{value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			result.put("UnmappedSitesCount",jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNMAPPED_SITE_COUNT,reports),new Object[]{businessSegment,marketIndustryField}, new MiscRowMapper()));
			if(Utils.getValidation(filters.get(FMSVariableConstants.STATE)).equals(FMSVariableConstants.REGION)){
				/**ON CLICK ON UNPERFORMING REGION COUNT*/
				result.put(FMSVariableConstants.STATECOORDINATES, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_REGION_COORDINATES_EXPT, reports,reports,reports,reports),new Object[]{businessSegment,marketIndustryField,value,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_REGION_COORDINATES, reports,reports,reports,reports,reports,reports),new Object[]{value,businessSegment,marketIndustryField,value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.LEVEL)).equals(FMSVariableConstants.REGION)){
				/**ON CLICK OF A PARTICULAR REGION FROM THE MAP*/
				region = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
				result.put(FMSVariableConstants.STATECOORDINATES, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_COUNTRY_COORDINATES_BY_REGION_EXPT, reports,reports,reports),new Object[]{businessSegment,marketIndustryField,region,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_COUNTRY_COORDINATES_BY_REGION, reports,reports,reports,reports,reports),new Object[]{value,businessSegment,marketIndustryField,region,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.STATE)).equals(FMSVariableConstants.COUNTRY)){
				/**ON CLICK ON UNPERFORMING COUNTRY COUNT*/
				result.put(FMSVariableConstants.STATECOORDINATES, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_COUNTRY_COORDINATES_EXPT, reports,reports,reports,reports),new Object[]{businessSegment,marketIndustryField,value,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_COUNTRY_COORDINATES, reports,reports,reports,reports,reports,reports),new Object[]{value,businessSegment,marketIndustryField,value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.LEVEL)).equals(FMSVariableConstants.COUNTRY)){
				/**ON CLICK OF A PARTICULAR COUNTRY FROM THE MAP*/
				country = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
				result.put(FMSVariableConstants.STATECOORDINATES, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_SITE_COORDINATES_BY_COUNTRY_EXPT, reports,reports,reports),new Object[]{businessSegment,marketIndustryField,country,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_SITE_COORDINATES_BY_COUNTRY, reports,reports,reports,reports,reports),new Object[]{value,businessSegment,marketIndustryField,country,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.STATE)).equals(FMSVariableConstants.SITE)){
				/**ON CLICK ON UNPERFORMING SITE COUNT*/
				result.put(FMSVariableConstants.STATECOORDINATES, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_SITE_COORDINATES_EXPT, reports,reports,reports,reports),new Object[]{businessSegment,marketIndustryField,value,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_SITE_COORDINATES, reports,reports,reports,reports,reports,reports),new Object[]{value,businessSegment,marketIndustryField,value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.LEVEL)).equals(FMSVariableConstants.SITE)){
				/**ON CLICK OF A PARTICULAR SITE FROM THE MAP*/
				country = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
				result.put(FMSVariableConstants.SITEINFO, jdbc.query(String.format(Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						FMSQueryConstants.PEN_DASHBOARD_SITES_BY_COUNTRY:FMSQueryConstants.PEN_DASHBOARD_SITES_BY_COUNTRY, reports,reports,reports),
						new Object[]{country,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.STATE)).equals(FMSVariableConstants.UNMAPPEDSITE)){
				/**ON CLICK ON UNMAPPED SITE COUNT*/
				result.put(FMSVariableConstants.SITEINFO, jdbc.query(String.format(Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						FMSQueryConstants.PEN_DASHBOARD_UNMAPPED_SITE:FMSQueryConstants.PEN_DASHBOARD_UNMAPPED_SITE, reports),new Object[]{businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.LEVEL)).equals(FMSVariableConstants.WORLDSITE)){
				/**ON CLICK OF A SITE FROM THE MAP WHERE ALL THE SITES ARE UNPERFORMING 
				 * (THE SCENARIO WE GET AFTER CLICKING ON UNPERFORMING SITE COUNT)*/
				result.put(FMSVariableConstants.SITEINFO, jdbc.query(String.format(Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_WORLD_SITE:FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_WORLD_SITE, reports, reports, reports, reports)
						,new Object[]{value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORTALL)){
				/**Export All*/
				result.put(FMSVariableConstants.SITEINFO, jdbc.query(String.format(
						FMSQueryConstants.PEN_DASHBOARD_EXPORT_ALL.concat(FMSVariableConstants.CURRENT_YEAR_QUARTER_CONDITION).
						concat(" AND site_name IS NOT NULL AND COALESCE(business_segment ,'') ~* '").concat(businessSegment).concat("' AND COALESCE(replace(c_market_industry_desc,'&',''),'') ~* '").concat(marketIndustryField).concat("' ORDER BY ibo_value DESC"), reports, reports)
						, new MiscRowMapper()));
			}else{
				/**ON DEFAULT PAGE LOAD*/
				result.put(FMSVariableConstants.STATECOORDINATES, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_REGION_COORDINATES_EXPT, reports,reports,reports),new Object[]{businessSegment,marketIndustryField,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_REGION_COORDINATES, reports,reports,reports,reports,reports),new Object[]{value,businessSegment,marketIndustryField,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}
		}else{
			result.put("IBOByReg",jdbc.query(FMSQueryConstants.RETRIEVE_IBOBYREG_METRICS_DATA_OVERALL,new Object[]{businessSegment,marketIndustryField}, new MiscRowMapper()));
			result.put("UnperformingRegCount",jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORMING_REGION_COUNT_OVERALL, reports,reports),new Object[]{value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			result.put("UnperformingCountryCount",jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORMING_COUNTRY_COUNT_OVERALL,reports,reports),new Object[]{value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			result.put("UnperformingSitesCount",jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORMING_SITE_COUNT_OVERALL,reports,reports),new Object[]{value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			result.put("UnmappedSitesCount",jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNMAPPED_SITE_COUNT_OVERALL,reports),new Object[]{businessSegment,marketIndustryField}, new MiscRowMapper()));
			if(Utils.getValidation(filters.get(FMSVariableConstants.STATE)).equals(FMSVariableConstants.REGION)){
				/**ON CLICK ON UNPERFORMING REGION COUNT*/
				result.put(FMSVariableConstants.STATECOORDINATES, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_REGION_COORDINATES_EXPT_OVERALL, reports,reports,reports,reports),new Object[]{value,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_REGION_COORDINATES_OVERALL, reports,reports,reports,reports,reports,reports),new Object[]{value,businessSegment,marketIndustryField,value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.LEVEL)).equals(FMSVariableConstants.REGION)){
				/**ON CLICK OF A PARTICULAR REGION FROM THE MAP*/
				region = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
				result.put(FMSVariableConstants.STATECOORDINATES, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_COUNTRY_COORDINATES_BY_REGION_EXPT_OVERALL, reports,reports,reports),new Object[]{businessSegment,marketIndustryField,region,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_COUNTRY_COORDINATES_BY_REGION_OVERALL, reports,reports,reports,reports,reports),new Object[]{value,businessSegment,marketIndustryField,region,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.STATE)).equals(FMSVariableConstants.COUNTRY)){
				/**ON CLICK ON UNPERFORMING COUNTRY COUNT*/
				result.put(FMSVariableConstants.STATECOORDINATES, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_COUNTRY_COORDINATES_EXPT_OVERALL, reports,reports,reports,reports),new Object[]{businessSegment,marketIndustryField,value,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_COUNTRY_COORDINATES_OVERALL, reports,reports,reports,reports,reports,reports),new Object[]{value,businessSegment,marketIndustryField,value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.LEVEL)).equals(FMSVariableConstants.COUNTRY)){
				/**ON CLICK OF A PARTICULAR COUNTRY FROM THE MAP*/
				country = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
				result.put(FMSVariableConstants.STATECOORDINATES, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_SITE_COORDINATES_BY_COUNTRY_EXPT_OVERALL, reports,reports,reports),new Object[]{businessSegment,marketIndustryField,country,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_SITE_COORDINATES_BY_COUNTRY_OVERALL, reports,reports,reports,reports,reports),new Object[]{value,businessSegment,marketIndustryField,country,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.STATE)).equals(FMSVariableConstants.SITE)){
				/**ON CLICK ON UNPERFORMING SITE COUNT*/
				result.put(FMSVariableConstants.STATECOORDINATES, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_SITE_COORDINATES_EXPT_OVERALL, reports,reports,reports,reports),new Object[]{businessSegment,marketIndustryField,value,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_SITE_COORDINATES_OVERALL, reports,reports,reports,reports,reports,reports),new Object[]{value,businessSegment,marketIndustryField,value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.LEVEL)).equals(FMSVariableConstants.SITE)){
				/**ON CLICK OF A PARTICULAR SITE FROM THE MAP*/
				country = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
				result.put(FMSVariableConstants.SITEINFO, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_SITES_BY_COUNTRY_OVERALL, reports,reports,FMSVariableConstants.EMPTY_STRING,reports),new Object[]{country,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_SITES_BY_COUNTRY_OVERALL, reports,reports,FMSVariableConstants.YEAR_QUARTER_RANGE_PEN_METRICS,reports),new Object[]{country,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.STATE)).equals(FMSVariableConstants.UNMAPPEDSITE)){
				/**ON CLICK ON UNMAPPED SITE COUNT*/
				result.put(FMSVariableConstants.SITEINFO, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNMAPPED_SITE_OVERALL, FMSVariableConstants.EMPTY_STRING,reports),new Object[]{businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNMAPPED_SITE_OVERALL, FMSVariableConstants.YEAR_QUARTER_RANGE_PEN_METRICS,reports),new Object[]{businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.LEVEL)).equals(FMSVariableConstants.WORLDSITE)){
				/**ON CLICK OF A SITE FROM THE MAP WHERE ALL THE SITES ARE UNPERFORMING 
				 * (THE SCENARIO WE GET AFTER CLICKING ON UNPERFORMING SITE COUNT)*/
				result.put(FMSVariableConstants.SITEINFO, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_WORLD_SITE_OVERALL,reports, reports,FMSVariableConstants.EMPTY_STRING,reports,reports),new Object[]{value,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_UNPERFORM_WORLD_SITE_OVERALL, reports,reports,FMSVariableConstants.YEAR_QUARTER_RANGE_PEN_METRICS,reports,reports),new Object[]{value,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORTALL)){
				/**Export All*/
				result.put(FMSVariableConstants.SITEINFO, jdbc.query(String.format(
						FMSQueryConstants.PEN_DASHBOARD_EXPORT_ALL.concat(FMSVariableConstants.OVERALL_YEAR_QUARTER_CONDITION).
						concat(" AND site_name IS NOT NULL AND COALESCE(business_segment ,'') ~* '").concat(businessSegment).concat("' AND COALESCE(replace(c_market_industry_desc,'&',''),'') ~* '").concat(marketIndustryField).concat("' ORDER BY ibo_value DESC"), reports, reports)
						, new MiscRowMapper()));
			}else{
				/**ON DEFAULT PAGE LOAD*/
				result.put(FMSVariableConstants.STATECOORDINATES, Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORT)?
						jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_REGION_COORDINATES_EXPT_OVERALL, reports,reports,reports),new Object[]{businessSegment,marketIndustryField,businessSegment,marketIndustryField}, new MiscRowMapper()):
							jdbc.query(String.format(FMSQueryConstants.PEN_DASHBOARD_REGION_COORDINATES_OVERALL, reports,reports,reports,reports,reports),new Object[]{value,businessSegment,marketIndustryField,businessSegment,marketIndustryField}, new MiscRowMapper()));
			}
		}
		return result;
	}

	@Override
	public Map<String, Object> getRawDataIBOPage(String page, JSONObject jsonObj) {
		Map<String, Object> result = new HashMap<>();
		try {
			Page value = Page.valueOf(page);
			log.info("inside dao impl of getRawDataIBOPage");
			String yearQtr = Utils.nullCheck(jsonObj.get("year"));
			String years = "";
			String quarters = "" ;

			if(!yearQtr.isEmpty() && yearQtr !=""){
				String[] yearQtrSep = yearQtr.split("\\|");
				Set<String> year = new HashSet<String>();
				Set<String> qtr = new HashSet<String>();
				for(int i=0; i < yearQtrSep.length; i++){
					year.add(yearQtrSep[i].split("\\-")[0]+"$");
					qtr.add("^"+yearQtrSep[i].split("\\-")[1]);
				}
				years = String.join("|", year);
				quarters = String.join("|", qtr);
			}

			switch(value) {
			case ibTechReg:
				log.info("inside dao impl of getRawDataIBOPage for ibTechReg report");
				Object[] ibParams = new Object[16]; 
				if (!jsonObj.isEmpty()) {
					ibParams[0]=Utils.getValidation(jsonObj.get(FMSVariableConstants.REGION)).replaceAll("[()]", "1");
					ibParams[1]=Utils.getValidation(jsonObj.get(FMSVariableConstants.TECHNOLOGY)).replaceAll("[()]", "1");
					ibParams[2]=Utils.getValidation(jsonObj.get(FMSVariableConstants.CUSTOMERNAME)).replaceAll("[()]", "1"); 
					ibParams[3]=Utils.getValidation(jsonObj.get(FMSVariableConstants.UNITSTATUSDESC)).replaceAll("[()]", "1");
					ibParams[4]=Utils.getValidation(jsonObj.get(FMSVariableConstants.SITECUSTCOUNTRY)).replaceAll("[()]", "1");
					ibParams[5]=Utils.getValidation(jsonObj.get(FMSVariableConstants.SERVRELATIONDESCONG)).replaceAll("[()]", "1");
					ibParams[6]=Utils.getValidation(jsonObj.get(FMSVariableConstants.MARKETSEGMENTDESC)).replaceAll("[()]", "1");
					ibParams[7]=Utils.getValidation(jsonObj.get(FMSVariableConstants.OEM_LOC)).replaceAll("[()]", "1");
					ibParams[8]=Utils.getValidation(jsonObj.get(FMSVariableConstants.SITE_CUST_DUNS_NAME)).replaceAll("[()]", "1");
					ibParams[9]=Utils.getValidation(jsonObj.get(FMSVariableConstants.SITECUSTNAME)).replaceAll("[()]", "1");
					ibParams[10]=Utils.getValidation(jsonObj.get(FMSVariableConstants.SITENAMEALIAS)).replaceAll("[()]", "1");
					ibParams[11]=Utils.getValidation(jsonObj.get(FMSVariableConstants.EQUIPMENTCODEFILTER)).replaceAll("[()]", "1");
					ibParams[12]=/**Utils.getValidation(jsonObj.get(FMSVariableConstants.BUSINESSSEGMENT)).replaceAll("[()]", "1")*/FMSVariableConstants.EMPTY_STRING;
					ibParams[13]=Utils.getValidation(jsonObj.get(FMSVariableConstants.ACC_MGR)).replaceAll("[()]", "1");
					ibParams[14]=Utils.getValidation(jsonObj.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
					ibParams[15]=Utils.getValidation(jsonObj.get(FMSVariableConstants.IBO_TYPE));
				}
				try {
					result.put("IBTechRawData", jdbc.query(FMSQueryConstants.RETRIEVE_IB_TECH_METRICS_FILTER_RAW_DATA,ibParams, new MiscRowMapper()));
					result.put("IBColumnHeaders", jdbc.query(FMSQueryConstants.RETRIEVE_IB_TECH_COLUMN_HEADERS, new MiscRowMapper()));
				} catch (Exception e) {
					log.error(FMSVariableConstants.ERROR+e.getMessage());
				}
				break;

			case ordersTechReg:
				log.info("inside dao impl of getRawDataIBOPage for ordersTechReg report");
				Object[] ordersParams = new Object[13]; 
				if (!jsonObj.isEmpty()) {
					ordersParams[0]=Utils.getValidation(jsonObj.get(FMSVariableConstants.COUNTRY_NAME)).replaceAll("[()]", "1");
					ordersParams[1]=Utils.getValidation(jsonObj.get(FMSVariableConstants.SERVICE_TYPE)).replaceAll("[()]", "1");
					ordersParams[2]=Utils.getValidation(jsonObj.get(FMSVariableConstants.END_USER_NAME)).replaceAll("[()]", "1"); 
					ordersParams[3]=Utils.getValidation(jsonObj.get(FMSVariableConstants.REGION)).replaceAll("[()]", "1");
					ordersParams[4]=Utils.getValidation(jsonObj.get(FMSVariableConstants.GEDUNSNAME)).replaceAll("[()]", "1");
					ordersParams[5]=Utils.getValidation(jsonObj.get(FMSVariableConstants.SM_SEGMENT_MAPPING)).replaceAll("[()]", "1");
					ordersParams[6]=Utils.getValidation(jsonObj.get(FMSVariableConstants.PM_PRODUCT_MAPPING)).replaceAll("[()]", "1");
					ordersParams[7]=Utils.getValidation(jsonObj.get(FMSVariableConstants.ME_TIER4)).replaceAll("[()]", "1");
					ordersParams[8]=Utils.getValidation(jsonObj.get(FMSVariableConstants.ME_DM_TIER3)).replaceAll("[()]", "1");
					ordersParams[9]=Utils.getValidation(jsonObj.get(FMSVariableConstants.STATE)).replaceAll("[()]", "1");
					ordersParams[10]=/**Utils.getValidation(jsonObj.get(FMSVariableConstants.BUSINESS_SEG)).replaceAll("[()]", "1")*/FMSVariableConstants.EMPTY_STRING;
					ordersParams[11]=Utils.getValidation(jsonObj.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
					ordersParams[12]=Utils.getValidation(jsonObj.get(FMSVariableConstants.ACC_MGR));
				}
				try {
					result.put("OrdersTechRawData", jdbc.query(FMSQueryConstants.RETRIEVE_ORDERS_TECH_METRICS_FILTER_RAW_DATA,ordersParams, new MiscRowMapper()));
					result.put("OrdersColumnHeaders", jdbc.query(FMSQueryConstants.RETRIEVE_ORDERS_TECH_COLUMN_HEADERS, new MiscRowMapper()));
				} catch (Exception e) {
					log.error(FMSVariableConstants.ERROR+e.getMessage());
				}      
				break;

			case dmTechReg:
				log.info("inside dao impl of getRawDataIBOPage for dmTechReg report");
				Object[] dmParams = new Object[16]; 
				if (!jsonObj.isEmpty()) {
					dmParams[0]= years;
					dmParams[1]= quarters ;
					dmParams[2]=Utils.getValidation(jsonObj.get(FMSVariableConstants.PRIMARY_REGION)).replaceAll("[()]", "1");
					dmParams[3]=Utils.getValidation(jsonObj.get(FMSVariableConstants.FORECAST_CATEGORY)).replaceAll("[()]", "1");
					dmParams[4]=Utils.getValidation(jsonObj.get(FMSVariableConstants.BUSINESS_TIER_3)).replaceAll("[()]", "1"); 
					dmParams[5]=Utils.getValidation(jsonObj.get(FMSVariableConstants.PRIMARY_COUNTRY)).replaceAll("[()]", "1");
					dmParams[6]=Utils.getValidation(jsonObj.get(FMSVariableConstants.C_QTR)).replaceAll("[()]", "1");
					dmParams[7]=Utils.getValidation(jsonObj.get(FMSVariableConstants.ACCOUNT_NAME)).replaceAll("[()]", "1");
					dmParams[8]=Utils.getValidation(jsonObj.get(FMSVariableConstants.RISK_PATH)).replaceAll("[()]", "1");
					dmParams[9]=Utils.getValidation(jsonObj.get(FMSVariableConstants.ACCOUNT_CLASS)).replaceAll("[()]", "1");
					dmParams[10]=Utils.getValidation(jsonObj.get(FMSVariableConstants.ACCOUNTTYPE)).replaceAll("[()]", "1");
					dmParams[11]=Utils.getValidation(jsonObj.get(FMSVariableConstants.STAGE)).replaceAll("[()]", "1");
					dmParams[12]=Utils.getValidation(jsonObj.get(FMSVariableConstants.OPPTY_EXTRN_ID)).replaceAll("[()]", "1");
					dmParams[13]=/**Utils.getValidation(jsonObj.get(FMSVariableConstants.BUSINESS_SEG)).replaceAll("[()]", "1")*/FMSVariableConstants.EMPTY_STRING;
					dmParams[14]=Utils.getValidation(jsonObj.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
					dmParams[15]=Utils.getValidation(jsonObj.get(FMSVariableConstants.ACC_MGR));
				}
				try {
					result.put("DMTechRawData", jdbc.query(FMSQueryConstants.RETRIEVE_DM_TECH_TECH_METRICS_FILTER_RAW_DATA,dmParams, new MiscRowMapper()));
					result.put("DMColumnHeaders", jdbc.query(FMSQueryConstants.RETRIEVE_DM_TECH_TECH_COLUMN_HEADERS, new MiscRowMapper()));
				} catch (Exception e) {
					log.error(FMSVariableConstants.ERROR+e.getMessage());
				}	
				break;

			case outageTechReg:
				log.info("inside dao impl of getRawDataIBOPage for outageTechReg report");
				Object[] outageParams = new Object[17]; 
				if (!jsonObj.isEmpty()) {
					outageParams[0]= years;
					outageParams[1]= quarters;
					outageParams[2]=Utils.getValidation(jsonObj.get(FMSVariableConstants.CUSTOMER_NAME)).replaceAll("[()]", "1"); 
					outageParams[3]=Utils.getValidation(jsonObj.get(FMSVariableConstants.TECHNOLOGY)).replaceAll("[()]", "1");
					outageParams[4]=Utils.getValidation(jsonObj.get(FMSVariableConstants.EQUIPMENT)).replaceAll("[()]", "1");
					outageParams[5]=Utils.getValidation(jsonObj.get(FMSVariableConstants.LOCATION)).replaceAll("[()]", "1");
					outageParams[6]=Utils.getValidation(jsonObj.get(FMSVariableConstants.UNIT_STATUS)).replaceAll("[()]", "1");
					outageParams[7]=Utils.getValidation(jsonObj.get(FMSVariableConstants.SEGMENT)).replaceAll("[()]", "1");
					outageParams[8]=Utils.getValidation(jsonObj.get(FMSVariableConstants.SERVICE_REL_1)).replaceAll("[()]", "1");
					outageParams[9]=Utils.getValidation(jsonObj.get(FMSVariableConstants.REGION)).replaceAll("[()]", "1");
					outageParams[10]=Utils.getValidation(jsonObj.get(FMSVariableConstants.COUNTRY)).replaceAll("[()]", "1");
					outageParams[11]=Utils.getValidation(jsonObj.get(FMSVariableConstants.DUNS_NAME)).replaceAll("[()]", "1");
					outageParams[12]=Utils.getValidation(jsonObj.get(FMSVariableConstants.ACC_MGR_EMAIL)).replaceAll("[()]", "1");
					outageParams[13]=Utils.getValidation(jsonObj.get(FMSVariableConstants.SERV_MGR_EMAIL)).replaceAll("[()]", "1");
					outageParams[14]=Utils.getValidation(jsonObj.get(FMSVariableConstants.MAINT_LVL_DESC)).replaceAll("[()]", "1");
					outageParams[15]=Utils.getValidation(jsonObj.get(FMSVariableConstants.EVNT_STATUS_DESC)).replaceAll("[()]", "1");
					outageParams[16]=Utils.getValidation(jsonObj.get(FMSVariableConstants.ACC_MGR));
				}
				try {
					result.put("OutageTechRawData", jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_TECH_METRICS_FILTER_RAW_DATA,outageParams, new MiscRowMapper()));
					result.put("OutageColumnHeaders", jdbc.query(FMSQueryConstants.RETRIEVE_OUTAGE_TECH_COLUMN_HEADERS, new MiscRowMapper()));
				} catch (Exception e) {
					log.error(FMSVariableConstants.ERROR+e.getMessage());
				}	
				break;

			case serviceTechReg:
				log.info("inside dao impl of getRawDataIBOPage for serviceTechReg report");
				Object[] serviceParams = new Object[13]; 
				if (!jsonObj.isEmpty()) {
					serviceParams[0]=Utils.getValidation(jsonObj.get(FMSVariableConstants.CASE_NUMBER)).replaceAll("[()]", "1");
					serviceParams[1]=Utils.getValidation(jsonObj.get(FMSVariableConstants.OPENED)).replaceAll("[()]", "1");
					serviceParams[2]=Utils.getValidation(jsonObj.get(FMSVariableConstants.TYPE_OF_ISSUE)).replaceAll("[()]", "1"); 
					serviceParams[3]=Utils.getValidation(jsonObj.get(FMSVariableConstants.PROJECT_PHASE)).replaceAll("[()]", "1");
					serviceParams[4]=Utils.getValidation(jsonObj.get(FMSVariableConstants.STATE)).replaceAll("[()]", "1");
					serviceParams[5]=Utils.getValidation(jsonObj.get(FMSVariableConstants.ASSGND_GRP)).replaceAll("[()]", "1");
					serviceParams[6]=Utils.getValidation(jsonObj.get(FMSVariableConstants.STATUS)).replaceAll("[()]", "1");
					serviceParams[7]=Utils.getValidation(jsonObj.get(FMSVariableConstants.ENTRY_IN_CUR_STATUS)).replaceAll("[()]", "1");
					serviceParams[8]=Utils.getValidation(jsonObj.get(FMSVariableConstants.JOB_TYPE)).replaceAll("[()]", "1");
					serviceParams[9]=Utils.getValidation(jsonObj.get(FMSVariableConstants.CSTMR_NAME)).replaceAll("[()]", "1");
					serviceParams[10]=Utils.getValidation(jsonObj.get(FMSVariableConstants.MAC_TECHNOLOGY)).replaceAll("[()]", "1");
					serviceParams[11]=years;
					serviceParams[12]=quarters;
				}
				try {
					result.put("ServiceTechRawData", jdbc.query(FMSQueryConstants.RETRIEVE_SERVICE_TECH_METRICS_FILTER_RAW_DATA,serviceParams, new MiscRowMapper()));
					result.put("ServiceColumnHeaders", jdbc.query(FMSQueryConstants.RETRIEVE_SERVICE_TECH_COLUMN_HEADERS, new MiscRowMapper()));
				} catch (Exception e) {
					log.error(FMSVariableConstants.ERROR+e.getMessage());
				}	
				break;
			}
		}
		catch(Exception e){
			log.info(e);
		}
		return result;
	}

	@Override
	public List<String> getRawDataHeadersList(String exportSheet) {
		log.info("inside dao impl of getRawDataHeadersList for "+ exportSheet);
		List<String> headers = new ArrayList<>();
		try {
			Page value = Page.valueOf(exportSheet);
			switch(value) {
			case ibTechReg:
				headers = jdbc.queryForList(FMSQueryConstants.RETRIEVE_IB_TECH_HEADERS_LIST, String.class);
				break;

			case ordersTechReg:
				headers = jdbc.queryForList(FMSQueryConstants.RETRIEVE_ORDERS_TECH_HEADERS_LIST, String.class);
				break;

			case dmTechReg:
				headers = jdbc.queryForList(FMSQueryConstants.RETRIEVE_DM_TECH_HEADERS_LIST, String.class);
				break;

			case outageTechReg:
				headers = jdbc.queryForList(FMSQueryConstants.RETRIEVE_OUTAGE_TECH_HEADERS_LIST, String.class);
				break;

			case serviceTechReg:
				headers = jdbc.queryForList(FMSQueryConstants.RETRIEVE_SERVICE_TECH_HEADERS_LIST, String.class);
				break;
			}

		} catch (Exception e) {
			log.error(FMSVariableConstants.ERROR+e.getMessage());
			log.error(FMSVariableConstants.ERROR + e.getStackTrace());
		}
		return headers;

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Map<String, Object>> exportRawDataMetrics(JSONObject jsonObj, String page) {
		log.info("inside dao impl of exportRawDataMetrics for "+ page);
		List<Map<String, Object>> list = new ArrayList<>();
		Map<String, Object> err = new HashMap<>();
		Map<String, Object> data = new LinkedHashMap<>();
		try {
			Page value = Page.valueOf(page);
			data = getRawDataIBOPage(page,jsonObj);

			switch(value) {
			case ibTechReg:
				list = (List<Map<String, Object>>) data.get("IBTechRawData");
				break;

			case ordersTechReg:
				list = (List<Map<String, Object>>) data.get("OrdersTechRawData");
				break;

			case dmTechReg:
				list = (List<Map<String, Object>>) data.get("DMTechRawData");
				break;

			case outageTechReg:
				list = (List<Map<String, Object>>) data.get("OutageTechRawData");
				break;

			case serviceTechReg:
				list = (List<Map<String, Object>>) data.get("ServiceTechRawData");
				break;
			}

		} catch (Exception e) {
			log.error(FMSVariableConstants.ERROR+e.getMessage());
			log.error(FMSVariableConstants.ERROR + e.getStackTrace());
			err.put(FMSVariableConstants.ERROR,FMSVariableConstants.FAILURE);
			list.add(err);
		}
		return list;

	}

	@Override
	public List<String> getPenetrationMetricsGEDunsNameDropdown(String businessSegment,Map<String,Object> filters) {
		String marketIndustryField = Utils.getValidation(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		return jdbc.queryForList(FMSQueryConstants.PENETRATION_METRICS_GEDUNSNAME_DROPDOWN,new Object[]{FMSVariableConstants.EMPTY_STRING,marketIndustryField}, String.class);
	}

	@Override
	public Map<String, Object> getAllMetricsGEDunsNameData(	Map<String, Object> filters) {

		String businessSegment = Utils.getValidation(filters.get(FMSVariableConstants.BUSINESS_SEG));

		Map<String,Object> metricsDataCurrent = new HashMap<>();
		Map<String,Object> metricsDataAverage = new HashMap<>();
		Map<String,Object> metricsDataHistory = new HashMap<>();
		Map<String,Object> result = new HashMap<>();
		List<String> reportName = Utils.getPenetrationMetricsTechnologyReportNames();
		String referredTable = null;
		String marketIndustryField = null;
		/** if "LEGACY" else "LATEST" */
		if(Utils.nullCheck(filters.get(FMSVariableConstants.TIME_PERIOD_TYPE)).equalsIgnoreCase(FMSVariableConstants.LEGACY)){
			referredTable = FMSVariableConstants.UNDERSCORE_LEGACY;
			businessSegment = FMSVariableConstants.DTS_SEGMENT;
			marketIndustryField = FMSVariableConstants.EMPTY_STRING;
		}else{
			referredTable = FMSVariableConstants.EMPTY_STRING;
			businessSegment = FMSVariableConstants.EMPTY_STRING;
			marketIndustryField = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
		}
		String currentMarketIndustry = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
		String currentReferredTable = FMSVariableConstants.EMPTY_STRING;

		String geDunsName = Utils.getValidation(filters.get("geDunsname"));
		Object[] params = new Object[4];
		params[0] = geDunsName;
		params[1] = businessSegment;
		params[2] = geDunsName;
		params[3] = businessSegment;

		Object[] paramsHistory = new Object[10];
		paramsHistory[0] = geDunsName;
		paramsHistory[1] = businessSegment;
		paramsHistory[2] = businessSegment;
		paramsHistory[3] = geDunsName;
		paramsHistory[4] = businessSegment;
		paramsHistory[5] = geDunsName;
		paramsHistory[6] = businessSegment;
		paramsHistory[7] = businessSegment;
		paramsHistory[8] = geDunsName;
		paramsHistory[9] = businessSegment;

		if(Utils.getValidation(filters.get(FMSVariableConstants.TYPE)).equalsIgnoreCase(FMSVariableConstants.TOP25)){

			/** Current */
			for (int index = 0; index < reportName.size(); index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					metricsDataCurrent.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_CURRENT,2,0.00,reportName.get(index),
									currentReferredTable,currentMarketIndustry,reportName.get(index),reportName.get(index), FMSVariableConstants.TOP_LIMIT_25, reportName.get(index),currentReferredTable,currentMarketIndustry,reportName.get(index), 
									FMSVariableConstants.DESC ),new Object[]{geDunsName, FMSVariableConstants.EMPTY_STRING, geDunsName, FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
				} else {
					metricsDataCurrent.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_CURRENT,0,0,reportName.get(index),
									currentReferredTable,currentMarketIndustry,reportName.get(index),reportName.get(index), FMSVariableConstants.TOP_LIMIT_25, reportName.get(index),currentReferredTable,currentMarketIndustry,reportName.get(index), 
									FMSVariableConstants.DESC ),new Object[]{geDunsName, FMSVariableConstants.EMPTY_STRING, geDunsName, FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
				}
			}
			/** Current */

			/** History */
			for (int index = 0; index < reportName.size(); index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					metricsDataHistory.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_HISTORY, 2,0.00,reportName.get(index),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(index),FMSVariableConstants.TOP_LIMIT_25, 
									referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,reportName.get(index),reportName.get(index),
									referredTable,marketIndustryField,reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,
									referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION),
									paramsHistory, new MiscRowMapper()));
				} else {
					metricsDataHistory.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_HISTORY, 0,0,reportName.get(index),
									referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(index),FMSVariableConstants.TOP_LIMIT_25,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField, 
									reportName.get(index),reportName.get(index),referredTable,marketIndustryField,reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,
									referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING),paramsHistory, new MiscRowMapper()));
				}
			}
			/** History */

			/** Average */
			for (int index = 0; index < reportName.size(); index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					metricsDataAverage.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_AVERAGE, 2,0.00,FMSVariableConstants.ROUND_TO_2_PLACES, 
									0.00, reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(index),
									FMSVariableConstants.TOP_LIMIT_25, FMSVariableConstants.ROUND_TO_2_PLACES, 0.00, reportName.get(index),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(index)),params, new MiscRowMapper()));
				} else {
					metricsDataAverage.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_AVERAGE, 0,0, FMSVariableConstants.ROUND_TO_0_PLACES,
									0, reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(index),FMSVariableConstants.TOP_LIMIT_25, 
									FMSVariableConstants.ROUND_TO_0_PLACES,0,reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(index)),
									params, new MiscRowMapper()));
				}
			}
			/** Average */

		}else if(Utils.getValidation(filters.get(FMSVariableConstants.TYPE)).equalsIgnoreCase(FMSVariableConstants.BOTTOM25)){

			/** Current */
			for (int index = 0; index < reportName.size(); index++) {

				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					metricsDataCurrent.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_CURRENT,2,0.00, reportName.get(index),
									currentReferredTable,currentMarketIndustry,reportName.get(index),reportName.get(index), FMSVariableConstants.BOTTOM_LIMIT_25, reportName.get(index),currentReferredTable,currentMarketIndustry,reportName.get(index), 
									FMSVariableConstants.ASC ),new Object[]{geDunsName, FMSVariableConstants.EMPTY_STRING, geDunsName, FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
				}else {
					metricsDataCurrent.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_CURRENT,0,0, reportName.get(index),
									currentReferredTable,currentMarketIndustry,reportName.get(index),reportName.get(index), FMSVariableConstants.BOTTOM_LIMIT_25, reportName.get(index),currentReferredTable,currentMarketIndustry,reportName.get(index), 
									FMSVariableConstants.ASC ),new Object[]{geDunsName, FMSVariableConstants.EMPTY_STRING, geDunsName, FMSVariableConstants.EMPTY_STRING}, new MiscRowMapper()));
				}
			}
			/** Current */

			/** History */
			for (int index = 0; index < reportName.size(); index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					metricsDataHistory.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_HISTORY, 2,0.00, reportName.get(index),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(index),FMSVariableConstants.BOTTOM_LIMIT_25,
									referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,reportName.get(index),reportName.get(index),referredTable,marketIndustryField,reportName.get(index),
									referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,referredTable,marketIndustryField,
									FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION),paramsHistory, new MiscRowMapper()));
				} else {
					metricsDataHistory.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_HISTORY, 0,0,reportName.get(index),
									referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(index),FMSVariableConstants.BOTTOM_LIMIT_25,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,
									reportName.get(index),reportName.get(index),referredTable,marketIndustryField,reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,
									referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING),paramsHistory, new MiscRowMapper()));
				}
			}
			/** History */

			/** Average */
			for (int index = 0; index < reportName.size(); index++) {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))){
					metricsDataAverage.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_AVERAGE,2, 0.00, FMSVariableConstants.ROUND_TO_2_PLACES,
									0.00, reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(index),
									FMSVariableConstants.BOTTOM_LIMIT_25, FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(index),referredTable,marketIndustryField,
									FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(index)),params, new MiscRowMapper()));
				} else {
					metricsDataAverage.put(reportName.get(index), 
							jdbc.query(String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_AVERAGE,0,0,  
									FMSVariableConstants.ROUND_TO_0_PLACES,0,  reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(index),
									FMSVariableConstants.BOTTOM_LIMIT_25, FMSVariableConstants.ROUND_TO_0_PLACES, 0, reportName.get(index),referredTable,marketIndustryField,
									FMSVariableConstants.EMPTY_STRING,reportName.get(index)),params, new MiscRowMapper()));
				}
			}
			/** Average */
		}

		/**
		 * Year based average for ge duns 
		 **/
		Map<String,Object> averageCalculationOnYear = new HashMap<>();

		try {
			if(Utils.getValidation(filters.get(FMSVariableConstants.TYPE)).equalsIgnoreCase(FMSVariableConstants.TOP25)){
				for (int index = 0; index < reportName.size(); index++) {
					if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))) 
						averageCalculationOnYear.put(reportName.get(index), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_GE_DUNS, 
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(index),referredTable,marketIndustryField,reportName.get(index),FMSVariableConstants.TOP_25,
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(index),
										referredTable,marketIndustryField,reportName.get(index),FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(index),
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION),
										new Object[]{geDunsName,businessSegment,geDunsName,businessSegment,geDunsName,businessSegment,geDunsName,businessSegment}, new MiscRowMapper()));
					else
						averageCalculationOnYear.put(reportName.get(index), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_GE_DUNS, 
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(index),referredTable,marketIndustryField,reportName.get(index),FMSVariableConstants.TOP_25,
										referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(index),referredTable,marketIndustryField,reportName.get(index),
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING),
										new Object[]{geDunsName,businessSegment,geDunsName,businessSegment,geDunsName,businessSegment,geDunsName,businessSegment}, new MiscRowMapper()));
				}
			}else if(Utils.getValidation(filters.get(FMSVariableConstants.TYPE)).equalsIgnoreCase(FMSVariableConstants.BOTTOM25)){
				for (int index = 0; index < reportName.size(); index++) {
					if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(reportName.get(index))) 
						averageCalculationOnYear.put(reportName.get(index), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_GE_DUNS, 
										FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(index),referredTable,marketIndustryField,reportName.get(index),FMSVariableConstants.BOTTOM_25,
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,FMSVariableConstants.ROUND_TO_2_PLACES,
										reportName.get(index),referredTable,marketIndustryField,reportName.get(index),FMSVariableConstants.ROUND_TO_2_PLACES,reportName.get(index),
										referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION),
										new Object[]{geDunsName,businessSegment,geDunsName,businessSegment,geDunsName,businessSegment,geDunsName,businessSegment}, new MiscRowMapper()));
					else
						averageCalculationOnYear.put(reportName.get(index), 
								jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_GE_DUNS, 
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(index),referredTable,marketIndustryField,reportName.get(index),FMSVariableConstants.BOTTOM_25,
										referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(index),referredTable,marketIndustryField,reportName.get(index),
										FMSVariableConstants.ROUND_TO_0_PLACES,reportName.get(index),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING),
										new Object[]{geDunsName,businessSegment,geDunsName,businessSegment,geDunsName,businessSegment,geDunsName,businessSegment}, new MiscRowMapper()));
				}
			}
		} catch (Exception e) {
			log.error(FMSVariableConstants.EXCEPTION + e.getStackTrace());
		}
		log.info("Average Calculation based on the Year GE DUNS Successfull !!!!");

		result.put(FMSVariableConstants.CURRENT, metricsDataCurrent);
		result.put(FMSVariableConstants.AVERAGE, metricsDataAverage);
		result.put(FMSVariableConstants.HISTORY, metricsDataHistory);
		result.put(FMSVariableConstants.AVERAGE_BASED_ON_YEAR, averageCalculationOnYear);
		return result;
	}

	@Override
	public Map<String, Object> penetrationGEDunsExportExcelData(Map<String, Object> filters) {

		String businessSegment = Utils.getValidation(filters.get(FMSVariableConstants.BUSINESS_SEG));
		String referredTable = null;
		String marketIndustryField = null;
		/** if "LEGACY" else "LATEST" */
		if(Utils.nullCheck(filters.get(FMSVariableConstants.TIME_PERIOD_TYPE)).equalsIgnoreCase(FMSVariableConstants.LEGACY)){
			referredTable = FMSVariableConstants.UNDERSCORE_LEGACY;
			businessSegment = FMSVariableConstants.DTS_SEGMENT;
			marketIndustryField = FMSVariableConstants.EMPTY_STRING;
		}else{
			referredTable = FMSVariableConstants.EMPTY_STRING;
			businessSegment = FMSVariableConstants.EMPTY_STRING;
			marketIndustryField = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
		}
		String currentMarketIndustry = FMSVariableConstants.MARKET_INDUSTRY_FEILD_1.concat(Utils.nullCheck(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")).concat(FMSVariableConstants.MARKET_INDUSTRY_FEILD_2);
		String currentReferredTable = FMSVariableConstants.EMPTY_STRING;

		String query = null;
		String avgQuery = null;
		Map<String,Object> result =new HashMap<>();
		String geDunsName = Utils.getValidation(filters.get(FMSVariableConstants.GEDUNS));
		List<String> reportName = Utils.getPenetrationMetricsTechnologyReportNames();
		String columnName = null;

		if(Utils.getValidation(filters.get(FMSVariableConstants.PERIOD)).equalsIgnoreCase(FMSVariableConstants.CURRENT)){
			switch(Utils.getValidation(filters.get(FMSVariableConstants.REPORT))){
			case FMSVariableConstants.FLEETCOVERAGE:
				query = String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_CURRENT_EXPT,0,0, reportName.get(0),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(0),reportName.get(0),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(0));
				break;
			case FMSVariableConstants.FLEETPEN:
				query = String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_CURRENT_EXPT,0,0, reportName.get(1),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(1),reportName.get(1),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(1));
				break;
			case FMSVariableConstants.FLEETPENF2F:
				query = String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_CURRENT_EXPT,0, 0,reportName.get(2),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(2),reportName.get(2),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(2));
				break;
			case FMSVariableConstants.CALORICINDEX:
				query = String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_CURRENT_EXPT,2,0.00, reportName.get(3),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(3),reportName.get(3),currentReferredTable,currentReferredTable,currentMarketIndustry,reportName.get(3));
				break;
			}
		}else if(Utils.getValidation(filters.get(FMSVariableConstants.PERIOD)).equalsIgnoreCase(FMSVariableConstants.HISTORY)){
			switch(Utils.getValidation(filters.get(FMSVariableConstants.REPORT))){
			case FMSVariableConstants.FLEETCOVERAGE:
				query = String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_HISTORY,0,0, reportName.get(0),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(0),FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,reportName.get(0),reportName.get(0),referredTable,marketIndustryField,reportName.get(0),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING);
				break;
			case FMSVariableConstants.FLEETPEN:
				query = String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_HISTORY,0,0, reportName.get(1),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(1),FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,reportName.get(1),reportName.get(1),referredTable,marketIndustryField,reportName.get(1),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING);
				break;
			case FMSVariableConstants.FLEETPENF2F:
				query = String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_HISTORY,0,0, reportName.get(2),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(2),FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,reportName.get(2),reportName.get(2),referredTable,marketIndustryField,reportName.get(2),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.EMPTY_STRING,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING);
				break;
			case FMSVariableConstants.CALORICINDEX:
				query = String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_HISTORY,2,0.00, reportName.get(3),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(3),FMSVariableConstants.EMPTY_STRING,referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,reportName.get(3),reportName.get(3),referredTable,marketIndustryField,reportName.get(3),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,referredTable,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,marketIndustryField,referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION);
				break;
			}
			switch(Utils.getValidation(filters.get(FMSVariableConstants.REPORT))){
			case FMSVariableConstants.FLEETCOVERAGE:
				avgQuery = String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_AVERAGE,0,0,FMSVariableConstants.ROUND_TO_0_PLACES, 0,reportName.get(0),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(0),FMSVariableConstants.EMPTY_STRING, FMSVariableConstants.ROUND_TO_0_PLACES, 0,reportName.get(0),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(0));
				columnName = reportName.get(0);
				break;
			case FMSVariableConstants.FLEETPEN:
				avgQuery = String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_AVERAGE,0,0,FMSVariableConstants.ROUND_TO_0_PLACES, 0,reportName.get(1),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(1),FMSVariableConstants.EMPTY_STRING, FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(1),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(1));
				columnName = reportName.get(1);
				break;
			case FMSVariableConstants.FLEETPENF2F:
				avgQuery = String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_AVERAGE,0,0,FMSVariableConstants.ROUND_TO_0_PLACES,0, reportName.get(2),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING, reportName.get(2),FMSVariableConstants.EMPTY_STRING, FMSVariableConstants.ROUND_TO_0_PLACES, 0,reportName.get(2),referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,reportName.get(2));
				columnName = reportName.get(2);
				break;
			case FMSVariableConstants.CALORICINDEX:
				avgQuery = String.format(FMSQueryConstants.GEDUNS_LEVEL_PENETRATION_METRICS_AVERAGE,2,0.00,FMSVariableConstants.ROUND_TO_2_PLACES,0.00, reportName.get(3),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION, reportName.get(3),FMSVariableConstants.EMPTY_STRING, FMSVariableConstants.ROUND_TO_2_PLACES, 0.00,reportName.get(3),referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,reportName.get(3));
				columnName = reportName.get(3);
				break;
			}

			try {
				if (FMSVariableConstants.CALORIC_INDEX.equalsIgnoreCase(columnName))
					result.put(FMSVariableConstants.AVERAGE_YEAR, jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_GE_DUNS, FMSVariableConstants.ROUND_TO_2_PLACES,columnName,referredTable,marketIndustryField,columnName,FMSVariableConstants.EXPORT_SITE_LEVEL_AVG_YEAR,referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION,FMSVariableConstants.ROUND_TO_2_PLACES,columnName,referredTable,marketIndustryField,columnName,FMSVariableConstants.ROUND_TO_2_PLACES,columnName,referredTable,marketIndustryField,FMSVariableConstants.AVERAGE_BASED_ON_YEAR_CALORIC_CONDITION),new Object[]{geDunsName,businessSegment,geDunsName,businessSegment,geDunsName,businessSegment,geDunsName,businessSegment}, new MiscRowMapper()));
				else
					result.put(FMSVariableConstants.AVERAGE_YEAR, jdbc.query(String.format(FMSQueryConstants.PENETRATION_METRICS_YEAR_BASED_AVERAGE_FOR_GE_DUNS, FMSVariableConstants.ROUND_TO_0_PLACES,columnName,referredTable,marketIndustryField,columnName,FMSVariableConstants.EXPORT_SITE_LEVEL_AVG_YEAR,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.ROUND_TO_0_PLACES,columnName,referredTable,marketIndustryField,columnName,FMSVariableConstants.ROUND_TO_0_PLACES,columnName,referredTable,marketIndustryField,FMSVariableConstants.EMPTY_STRING),new Object[]{geDunsName,businessSegment,geDunsName,businessSegment,geDunsName,businessSegment,geDunsName,businessSegment}, new MiscRowMapper()));
			} catch (Exception e) {
				log.error(FMSVariableConstants.EXCEPTION + e.getStackTrace());
			}
		}
		if (Utils.getValidation(filters.get(FMSVariableConstants.PERIOD)).equalsIgnoreCase(FMSVariableConstants.CURRENT)){
			result.put("Current", jdbc.query(query, new Object[]{geDunsName,FMSVariableConstants.EMPTY_STRING,geDunsName,FMSVariableConstants.EMPTY_STRING},new MiscRowMapper()));
		}else if(Utils.getValidation(filters.get(FMSVariableConstants.PERIOD)).equalsIgnoreCase(FMSVariableConstants.HISTORY)){
			result.put("History", jdbc.query(query,new Object[]{geDunsName,businessSegment,businessSegment,geDunsName,businessSegment,geDunsName,businessSegment,businessSegment,geDunsName,businessSegment},new MiscRowMapper()));
			result.put("Average", jdbc.query(avgQuery,new Object[]{geDunsName,businessSegment,geDunsName,businessSegment},new MiscRowMapper()));
		}
		return result;
	}

	@Override
	public String importCSVToSalesData(InputStream inputStream, String businessSegment, String marketIndustryDesc) {
		String response = "";
		Connection con;
		String marketIndustry = Utils.getValidation(marketIndustryDesc);
		try {
			con = DriverManager.getConnection(url,user,pass);
			CopyManager copyManager = new CopyManager((BaseConnection) con);
			jdbc.execute(FMSQueryConstants.DROP_SALES_TEMP_DATA);
			jdbc.execute(FMSQueryConstants.CREATE_SALES_TEMP_TABLE);
			StringBuilder sql = new StringBuilder();
			sql.append(FMSVariableConstants.COPY);
			sql.append("fms_sales_n_cm_pm_temp (ong_region, sales_amt_at_op_rate, cm_amt_at_op_rate, identifier, region, c_market_industry_desc)");
			sql.append(" FROM STDIN WITH (");
			sql.append(" FORMAT CSV ");
			sql.append(", DELIMITER ','");
			sql.append(", NULL ''");
			sql.append(", HEADER TRUE");
			sql.append(", QUOTE '\"'");
			sql.append(", ESCAPE '\"' ");
			sql.append(", ENCODING 'WIN1257'");   
			sql.append(")");
			log.info(FMSVariableConstants.IMPORT_STARTED);
			copyManager.copyIn(sql.toString(), inputStream );
			log.info(FMSVariableConstants.IMPORT_COMPLETED);
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.IN_PROGRESS,FMSVariableConstants.MAPPING_SERVICE_LOG,"importCSVToSalesData"});
			log.info("Records updation started...");
			if(!marketIndustry.equalsIgnoreCase(FMSVariableConstants.EMPTY_STRING) || !marketIndustry.isEmpty()){
				jdbc.update("delete from fms_sales_n_cm_pm_temp where COALESCE(c_market_industry_desc,'') !~* '" + marketIndustry + "'");
			}			
			jdbc.update(FMSQueryConstants.UPDATE_SALES_YR_QTR_REGID);
			jdbc.execute(FMSQueryConstants.TRUNCATE_SALES_DATA);
			jdbc.update(FMSQueryConstants.UPDATE_SALES_DATA_FROM_TEMP);

			/**
			 * Generalized Mapping Function Included *
			jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS, String.class);
			log.info("UPDATE_ALL_PEN_METRICS UPDATED");
			jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_COUNTRY_TECH_SPLIT, String.class);
			log.info("UPDATE_ALL_PEN_METRICS_COUNTRY_TECH_SPLIT UPDATED");
			jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_REGIONS_SPLIT, String.class);
			log.info("UPDATE_OVERALL_REGIONS_SPLIT UPDATED");
			jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_COUNTRIES_SPLIT, String.class);
			log.info("UPDATE_OVERALL_COUNTRIES_SPLIT UPDATED");*/
			String serviceLog = jdbc.queryForObject(FMSQueryConstants.GENERAL_FMS_MAPPING_FUNC, new Object[]{FMSVariableConstants.FMS_MAPPING_FUNC_SALES}, String.class);
			jdbc.execute(FMSQueryConstants.DROP_SALES_TEMP_DATA);
			response = FMSVariableConstants.SUCCESS;
			log.info("Records updated!"+serviceLog);
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,serviceLog,"importCSVToSalesData Mapping Completed"});

		} catch (Exception e) {
			response = FMSVariableConstants.FAILURE;
			log.info(e);
		}
		return response;
	}

	@Override
	public Map<String, Object> getPenMetricsTopSitesByRegion(Map<String, Object> filters) {

		List<Map<String,Object>> ordersML = new ArrayList<>();
		List<Map<String,Object>> iboML = new ArrayList<>();
		List<Map<String,Object>> penetrationML = new ArrayList<>();
		List<Map<String,Object>> dmML = new ArrayList<>();
		List<Map<String,Object>> outageML = new ArrayList<>();
		Map<String,Object> result = new HashMap<>();
		Map<String,Object> chartList = new HashMap<>();

		String businessSegment = Utils.getValidation(filters.get(FMSVariableConstants.BUSINESS_SEG));
		businessSegment = "";
		String marketIndustryField = Utils.getValidation(filters.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");

		String region = Utils.getValidation(filters.get(FMSVariableConstants.REGION));
		String country = Utils.getValidation(filters.get(FMSVariableConstants.COUNTRY));
		String serviceManagerDetails = Utils.getValidation(filters.get(FMSVariableConstants.SERVICE_MANAGER_DETAILS));
		String accountManagerDetails = Utils.getValidation(filters.get(FMSVariableConstants.ACCOUNT_MANAGER_DETAILS));
		List<Map<String,Object>> data = jdbc.query(FMSQueryConstants.PEN_METRICS_TOP_SITES,
				new Object[]{
				region,country,businessSegment,marketIndustryField,serviceManagerDetails,accountManagerDetails,
				region,country,businessSegment,marketIndustryField,serviceManagerDetails,accountManagerDetails
				,businessSegment,marketIndustryField,
				region,country,businessSegment,marketIndustryField,serviceManagerDetails,accountManagerDetails
				,businessSegment,marketIndustryField,
				region,country,businessSegment,marketIndustryField,serviceManagerDetails,accountManagerDetails
				,businessSegment,marketIndustryField,
				region,country,businessSegment,marketIndustryField,serviceManagerDetails,accountManagerDetails,
				region,country,businessSegment,marketIndustryField,serviceManagerDetails,accountManagerDetails},
				new MiscRowMapper());
		for(Map<String,Object> row : data){

			Map<String,Object> orders1 = new HashMap<>();
			Map<String,Object> ibo1 = new HashMap<>();
			Map<String,Object> penetration1 = new HashMap<>();
			Map<String,Object> dm1 = new HashMap<>();
			Map<String,Object> outage = new HashMap<>();

			orders1.put(FMSVariableConstants.SITE, Utils.getValidation((row.get(FMSVariableConstants.SITE))));
			if("No Orders".equalsIgnoreCase(Utils.getValidation((row.get("overall_orders"))))){
				orders1.put("val", "0.00");
			}else{
				orders1.put("val", Utils.getValidation((row.get("overall_orders"))));
			}
			ibo1.put(FMSVariableConstants.SITE, Utils.getValidation((row.get(FMSVariableConstants.SITE))));
			ibo1.put("val", Utils.getValidation((row.get("ibo_overall"))));

			penetration1.put(FMSVariableConstants.SITE, Utils.getValidation((row.get(FMSVariableConstants.SITE))));
			if("No Orders".equalsIgnoreCase(Utils.getValidation((row.get("overall_penetration"))))){
				penetration1.put("val", "0.00");	
			}else{
				penetration1.put("val", Utils.getValidation((row.get("overall_penetration"))));
			}

			dm1.put(FMSVariableConstants.SITE, Utils.getValidation((row.get(FMSVariableConstants.SITE))));
			dm1.put("val", Utils.getValidation((row.get("oppty_sum"))));

			outage.put(FMSVariableConstants.SITE, Utils.getValidation((row.get(FMSVariableConstants.SITE))));
			outage.put("val", Utils.getValidation((row.get("outage_count"))));


			ordersML.add(orders1);
			iboML.add(ibo1);
			penetrationML.add(penetration1);
			dmML.add(dm1);
			outageML.add(outage);
		}

		chartList.put("ordersChart", ordersML);
		chartList.put("iboChart", iboML);
		chartList.put("penetrationChart", penetrationML);
		chartList.put("dmChart", dmML);
		chartList.put("outageChart", outageML);

		result.put("table", data);
		result.put("chart", chartList);
		result.put("year_quarter_range", jdbc.queryForObject(FMSQueryConstants.PENETRATION_METRICS_YEAR_QUARTER_RANGE_TOP_SITES,
				new Object[]{businessSegment,marketIndustryField,businessSegment,marketIndustryField
				,businessSegment,marketIndustryField,businessSegment,marketIndustryField
				,businessSegment,marketIndustryField,businessSegment,marketIndustryField}, new MiscRowMapper()));
		/**result.put("serviceManagerDropdown", jdbc.queryForList(FMSQueryConstants.GET_SERVICE_MANAGER_DETAILS_DROPDOWN,new Object[]{region,country} ,String.class));*/

		return result;
	}

	@Override
	public List<Map<String, Object>> fetchPostgreRegionData() {
		log.info("Inside FMSDaoImpl of fetchPostgreRegionData()");
		return jdbc.query(FMSQueryConstants.FETCH_POSTGRE_REGION_DATA, new MiscRowMapper());
	}

	@Override
	public Map<String, Object> getIPMRawData(Map<String, Object> filterData) {
		Object[] params = new Object[13];	
		params[0] = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
		params[1] = Utils.getValidation(filterData.get(FMSVariableConstants.PANDL));
		params[2] = Utils.getValidation(filterData.get(FMSVariableConstants.PRODUCT));
		params[3] = Utils.getValidation(filterData.get(FMSVariableConstants.OUNAME));
		params[4] = Utils.getValidation(filterData.get(FMSVariableConstants.OGREGION));
		params[5] = Utils.getValidation(filterData.get(FMSVariableConstants.REGION));
		params[6] = Utils.getValidation(filterData.get(FMSVariableConstants.SUBREGION));
		params[7] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCOUNTRYDISC)).replaceAll("'", " ");
		params[8] = Utils.getValidation(filterData.get(FMSVariableConstants.MOTHERJOB));
		params[9] = Utils.getValidation(filterData.get(FMSVariableConstants.ENDUSERCUSTNAME));
		params[10] = Utils.getValidation(filterData.get(FMSVariableConstants.COSTINGPROJECT));
		params[11] = Utils.getValidation(filterData.get(FMSVariableConstants.ORDERTYPE));
		params[12] =  Utils.getValidation(filterData.get(FMSVariableConstants.PROJECTMANAGER));

		Map<String,Object> finalResult = new HashMap<>();

		if(Utils.getValidation(filterData.get(FMSVariableConstants.OPTION)).equalsIgnoreCase(FMSVariableConstants.EXPORT)){
			finalResult.put(FMSVariableConstants.IPMRAWDATA, jdbc.query(FMSQueryConstants.FETCH_IPM_RAW_DATA_EXPT , params, new MiscRowMapper()));
		}else{
			finalResult.put(FMSVariableConstants.IPMRAWDATA, jdbc.query(FMSQueryConstants.FETCH_IPM_RAW_DATA , params, new MiscRowMapper()));
		}
		return finalResult;
	}

	@Override
	public String updateIPMPartsQmi(Map<String, Object> filterData) {
		log.info("inside DAO impl updateIPMPartsQmi()");
		String result = null;
		try {
			if (!filterData.isEmpty()) {
				String partsStatus = Utils.getValidation(filterData.get(FMSVariableConstants.PARTS_STATUS));
				String key;
				String value;

				if(FMSVariableConstants.BILLING.equalsIgnoreCase(partsStatus) || FMSVariableConstants.SHIPPING.equalsIgnoreCase(partsStatus) || FMSVariableConstants.SHIPPED.equalsIgnoreCase(partsStatus)){
					key = FMSVariableConstants.BOX_NUMBER;
					value = Utils.getValidation(filterData.get(FMSVariableConstants.BOX_ID));
				} else if(FMSVariableConstants.SALES.equalsIgnoreCase(partsStatus)) {
					key = FMSVariableConstants.INVOICE_NUMBER;
					value = Utils.getValidation(filterData.get(FMSVariableConstants.INVOICE_NUMBER));
				}else {
					key = FMSVariableConstants.P_CONCATENATE;
					value = Utils.getValidation(filterData.get(FMSVariableConstants.CONCATENATE));
				}
				Object[] param = new Object[2];
				param[0] = Utils.getValidationForBoolean(filterData.get(FMSVariableConstants.QMI));
				param[1] = value;
				try {
					log.info("before query call");
					jdbc.update(FMSQueryConstants.UPDATE_SELECTED_QMI_ROWS + key + FMSVariableConstants.OPERATOR_EQUALS_VAL,param);
					log.info("after query call");
				} catch (Exception e) {
					log.error(FMSVariableConstants.EXCEPTION + e.getStackTrace());
					result = FMSVariableConstants.FAILURE;
				}
				result = FMSVariableConstants.SUCCESS;
			}
		} catch (Exception e) {
			log.error(FMSVariableConstants.EXCEPTION + e.getStackTrace());
			result = FMSVariableConstants.FAILURE;
		}

		return result;
	}

	@Override
	public List<String> getOrdersYears() {
		return jdbc.queryForList(FMSQueryConstants.ORDERS_YEARS_DROPDOWN_LIST, String.class);
	}

	public String checkUserExistence(String sso){
		log.info("inside checkUserExistence of DAOImpl");
		String result = null;
		try {
			String value = jdbc.queryForObject(FMSQueryConstants.CHECK_FOR_USER_EXISTENCE, new Object[]{sso}, String.class);
			result = FMSVariableConstants.SUCCESS.concat(FMSVariableConstants.TILDE_SEPARATOR).concat(value);
		} catch (Exception e) {
			log.error(FMSVariableConstants.DATABASEERROR + e.getMessage());
			result = FMSVariableConstants.FAILURE.concat(FMSVariableConstants.TILDE_SEPARATOR).concat(FMSVariableConstants.DBERROR);
		}
		return result;
	}

	@Override
	public String manageUsers(Map<String, Object> userData) {
		log.info("inside manageUsers of DAOImpl");
		String result = null;
		String checkUserExixtence = null;
		int userAdded = 0;
		Object[] addUser = new Object[8];
		addUser[0] = Utils.getValidation(userData.get(FMSVariableConstants.SSO_ID));
		addUser[1] = Utils.getValidation(userData.get(FMSVariableConstants.FIRST_NAME));
		addUser[2] = Utils.getValidation(userData.get(FMSVariableConstants.LAST_NAME));
		addUser[3] = Utils.getValidation(userData.get(FMSVariableConstants.EMAIL));
		addUser[4] = Utils.getValidation(userData.get(FMSVariableConstants.ACTIVE));
		addUser[5] = Utils.getValidation(userData.get(FMSVariableConstants.CREATED_BY));
		addUser[6] = Utils.getValidation(userData.get(FMSVariableConstants.UPDATED_BY));
		addUser[7] = Utils.getIntegerValidation(userData.get(FMSVariableConstants.USER_ROLE));
		checkUserExixtence = checkUserExistence(addUser[0].toString());
		String[] checkUser = checkUserExixtence.split(FMSVariableConstants.TILDE_SEPARATOR);

		if(FMSVariableConstants.ADD_USER.equalsIgnoreCase(Utils.getValidation(userData.get(FMSVariableConstants.ACTION)))){
			try {
				if(FMSVariableConstants.SUCCESS.equalsIgnoreCase(checkUser[0]) && FMSVariableConstants.USER_COUNT_1.equalsIgnoreCase(checkUser[1]))
					result = FMSVariableConstants.USER_PRESENT.concat(addUser[0].toString());	
				else if (FMSVariableConstants.SUCCESS.equalsIgnoreCase(checkUser[0]) && FMSVariableConstants.USER_COUNT_0.equalsIgnoreCase(checkUser[1])){
					String userAddedStatus = jdbc.queryForObject(FMSQueryConstants.ADD_FMS_USER_FUNCTION, addUser,String.class);
					if (userAddedStatus.equalsIgnoreCase(FMSVariableConstants.SUCCESS))
						result = FMSVariableConstants.SUCCESS;
					else
						result = FMSVariableConstants.FAILURE;
				}
			} catch (Exception e) {
				log.error(FMSVariableConstants.DATABASEERROR+e.getMessage());
				result = FMSVariableConstants.FAILURE;
			}
		}	if(FMSVariableConstants.DELETE_USER.equalsIgnoreCase(Utils.getValidation(userData.get(FMSVariableConstants.ACTION)))){
			try {
				jdbc.update(FMSQueryConstants.DELETE_FMS_USER_ROLE, new Object[]{Utils.getValidation(userData.get(FMSVariableConstants.SSO_ID))});
				userAdded =	jdbc.update(FMSQueryConstants.DELETE_FMS_USER, new Object[]{Utils.getValidation(userData.get(FMSVariableConstants.SSO_ID))});
				if (userAdded>0)
					result = FMSVariableConstants.SUCCESS;
			} catch (Exception e) {
				log.error(FMSVariableConstants.DATABASEERROR+e.getMessage());
				result = FMSVariableConstants.FAILURE;
			}
		}	if(FMSVariableConstants.EDIT_USER.equalsIgnoreCase(Utils.getValidation(userData.get(FMSVariableConstants.ACTION)))){
			try {
				String userAddedStatus = jdbc.queryForObject(FMSQueryConstants.EDIT_FMS_USER_FUNCTION, addUser,String.class);
				if (userAddedStatus.equalsIgnoreCase(FMSVariableConstants.SUCCESS))
					result = FMSVariableConstants.SUCCESS;
			} catch (Exception e) {
				log.error(FMSVariableConstants.DATABASEERROR+e.getMessage());
				result = FMSVariableConstants.FAILURE;
			}
		}
		return result;
	}

	@Override
	public Map<String, Object> getParticularUserDetails(String sso) {
		log.info("inside getParticularUserDetails of DAOImpl");
		Map<String, Object> result = new HashMap<>();
		result.put("UserDetails", jdbc.query(FMSQueryConstants.GET_PARTICULAR_USER_DETAILS, new Object[]{sso}, new MiscRowMapper()));
		return result;
	}

	@Override
	public Map<String, Object> getUserManagementDetails() {
		Map<String, Object> result = new HashMap<>();
		result.put("UserDetails",jdbc.query(FMSQueryConstants.ALL_USER , new MiscRowMapper()));
		result.put("RoleDetails", jdbc.query(FMSQueryConstants.ALL_ROLE_DETAILS, new MiscRowMapper()));
		return result;
	}

	@Override
	public List<Map<String, Object>> exportUserManagementData(String exportType) {
		log.info("inside exportUserManagementData of DAOImpl");
		List<Map<String, Object>> result = null;
		if(FMSVariableConstants.EXPORT_USER_DETAILS_TYPE_USER.equalsIgnoreCase(exportType)){
			result =  jdbc.query(FMSQueryConstants.EXPORT_ALL_USER_DETAILS, new ExportExcelMapperUserManagementMapper());
		} else if(FMSVariableConstants.EXPORT_USER_DETAILS_TYPE_ROLE.equalsIgnoreCase(exportType)){
			result =  jdbc.query(FMSQueryConstants.EXPORT_ALL_ROLE_DETAILS, new ExportExcelMapperUserManagementMapper());
		}
		return result;
	}

	public String checkRoleExistence(String roleName){
		log.info("inside checkRoleExistence of DAOImpl");
		String result = null;
		try {
			String value = jdbc.queryForObject(FMSQueryConstants.CHECK_FOR_ROLE_EXISTENCE, new Object[]{roleName}, String.class);
			result = FMSVariableConstants.SUCCESS.concat(FMSVariableConstants.TILDE_SEPARATOR).concat(value);
		} catch (Exception e) {
			log.error(FMSVariableConstants.DATABASEERROR + e.getMessage());
			result = FMSVariableConstants.FAILURE.concat(FMSVariableConstants.TILDE_SEPARATOR).concat(FMSVariableConstants.DBERROR);
		}
		return result;
	}

	@Override
	public String manageRoles(Map<String, Object> rolesData) {
		log.info("inside manageRoles of DAOImpl");
		String result = null;
		String checkRoleExistence = null;
		int roleAdded = 0;
		Object[] addRole = new Object[5];
		addRole[0] = Utils.getValidation(rolesData.get(FMSVariableConstants.ROLE_NAME));
		addRole[1] = Utils.getValidation(rolesData.get(FMSVariableConstants.ROLE_DESC));
		addRole[2] = Utils.getValidation(rolesData.get(FMSVariableConstants.ACTIVE));
		addRole[3] = Utils.getValidation(rolesData.get(FMSVariableConstants.CREATED_BY));
		addRole[4] = Utils.getValidation(rolesData.get(FMSVariableConstants.UPDATED_BY));

		checkRoleExistence = checkRoleExistence(addRole[0].toString());
		String[] checkRole = checkRoleExistence.split(FMSVariableConstants.TILDE_SEPARATOR);

		if(FMSVariableConstants.ADD_ROLE.equalsIgnoreCase(Utils.getValidation(rolesData.get(FMSVariableConstants.ACTION)))){
			try {
				if(FMSVariableConstants.SUCCESS.equalsIgnoreCase(checkRole[0]) && FMSVariableConstants.USER_COUNT_1.equalsIgnoreCase(checkRole[1])){
					result = FMSVariableConstants.ROLE_PRESENT_1.concat("\"").concat(addRole[0].toString()).concat("\"").concat(FMSVariableConstants.ROLE_PRESENT_2);	
				}else if (FMSVariableConstants.SUCCESS.equalsIgnoreCase(checkRole[0]) && FMSVariableConstants.USER_COUNT_0.equalsIgnoreCase(checkRole[1])){
					roleAdded = jdbc.update(FMSQueryConstants.ADD_FMS_NEW_ROLE, addRole);
					if (roleAdded>0)
						result = FMSVariableConstants.SUCCESS;
					else
						result = FMSVariableConstants.FAILURE;
				}
			} catch (Exception e) {
				log.error(FMSVariableConstants.DATABASEERROR+e.getMessage());
				int sampleCount = jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"manageRoles~AddRole"});
				if(sampleCount==1)
					result = FMSVariableConstants.FAILURE;
				log.error(FMSVariableConstants.DATABASEERROR+e.getMessage());
			}
		} else if(FMSVariableConstants.DELETE_ROLE.equalsIgnoreCase(Utils.getValidation(rolesData.get(FMSVariableConstants.ACTION)))){
			try {
				jdbc.update(FMSQueryConstants.DELETE_FMS_USER_ROLE_NAME, addRole[0]);
				roleAdded =	jdbc.update(FMSQueryConstants.DELETE_FMS_NEW_ROLE,addRole[0]);
				if (roleAdded>0)
					result = FMSVariableConstants.SUCCESS;
			} catch (Exception e) {
				log.error(FMSVariableConstants.DATABASEERROR+e.getMessage());
				result = FMSVariableConstants.FAILURE;
			}
		} else if(FMSVariableConstants.EDIT_ROLE.equalsIgnoreCase(Utils.getValidation(rolesData.get(FMSVariableConstants.ACTION)))){
			try {
				String editRole = jdbc.queryForObject(FMSQueryConstants.EDIT_FMS_USER_ROLE_DETAILS, new Object[]{Utils.getValidation(rolesData.get(FMSVariableConstants.ROLE_NAME)),Utils.getValidation(rolesData.get(FMSVariableConstants.ROLE_DESC)),Utils.getValidation(rolesData.get(FMSVariableConstants.ACTIVE)),Utils.getValidation(rolesData.get(FMSVariableConstants.UPDATED_BY)),Utils.getIntegerValidation(rolesData.get(FMSVariableConstants.ROLE_ID))}, String.class);
				if (editRole.equalsIgnoreCase(FMSVariableConstants.SUCCESS))
					result = FMSVariableConstants.SUCCESS;
				else
					result = FMSVariableConstants.FAILURE;
			} catch (Exception e) {
				log.error(FMSVariableConstants.DATABASEERROR+e.getMessage());
				result = FMSVariableConstants.FAILURE;
			}
		}
		return result;
	}

	@Override
	public Map<String,Object> getUserDetailsBasedOnRole(int roleId) {
		log.info("inside getUserDetailsBasedOnRole of DAOImpl");
		Map<String,Object> result = new HashMap<>();
		try {
			result.put("userDetailsBasedOnRole", jdbc.query(FMSQueryConstants.USER_DETAILS_BASED_ON_ROLE, new Object[]{roleId}, new MiscRowMapper()));
		} catch (Exception e) {
			log.error(FMSVariableConstants.DATABASEERROR+e.getMessage());
			result.put(FMSVariableConstants.FAILURE, FMSVariableConstants.DBEXCEPTION);
		}
		return result;
	}

	/** 
	 * This Service will take the backUp of the database for previous 7 days
	 **/
	@Transactional
	@Override
	public void backUpService(String getDate) {
		log.info("backUpService() in DAOImpl");
		try {
			String[] date = getDate.split(FMSVariableConstants.TILDE_SEPARATOR);
			log.info("deleting the old data for DM, Outage, Service Request & IBAS");
			jdbc.update(FMSQueryConstants.DELETE_DM_BACKUP_DATA,date[0]);
			jdbc.update(FMSQueryConstants.DELETE_OUTAGE_BACKUP_DATA,date[0]);
			jdbc.update(FMSQueryConstants.DELETE_SERVICE_REQUEST_BACKUP_DATA,date[0]);
			jdbc.update(FMSQueryConstants.DELETE_IBAS_BACKUP_DATA,date[0]);
			log.info("data deleted Successfully for DM, Outage, Service Request & IBAS");

			log.info("Inserting Data into DM BackUp table");
			jdbc.update(FMSQueryConstants.INSERT_DM_BACKUP_DATA,date[1]);
			log.info("Data inserted successfully into DM BackUp table");

			log.info("Inserting Data into Outage BackUp table");
			jdbc.update(FMSQueryConstants.INSERT_OUTAGE_BACKUP_DATA,date[1]);
			log.info("Data inserted successfully into Outage BackUp table");

			log.info("Inserting Data into Service Request BackUp table");
			jdbc.update(FMSQueryConstants.INSERT_SERVICE_REQUEST_BACKUP_DATA,date[1]);
			log.info("Data inserted successfully into Service Request BackUp table");

			log.info("Inserting Data into IBAS BackUp table");
			jdbc.update(FMSQueryConstants.INSERT_IBAS_BACKUP_DATA,FMSVariableConstants.EVERYDAY_BACKUP);
			log.info("Data inserted successfully into IBAS BackUp table");

		} catch (Exception e) {
			log.error(FMSVariableConstants.DATABASEERROR+e.getMessage());
		}
	}

	@Override
	public void exportInvalidIPMData(HttpServletResponse responses,	Map<String, Object> filterData) {
		String manager = Utils.getValidation(filterData.get(FMSVariableConstants.PROJECTMANAGER));
		String ssoId =  Utils.getValidation(filterData.get(FMSVariableConstants.SSO_ID));
		String sqlQuery = FMSQueryConstants.PARTS_INVALID_EXPT +manager+"' and sso_id='" + ssoId+"'";
		exportCSVData(responses, sqlQuery, "IpmInvalidPartsData");
	}

	@Override
	public List<Map<String, Object>> getImportStatusHistory(Map<String, Object> filterData) {
		return jdbc.query(FMSQueryConstants.RETRIEVE_IMPORT_STATUS_HISTORY,new Object[] {Utils.getValidation(filterData.get(FMSVariableConstants.SSO_ID)), Utils.getValidation(filterData.get(FMSVariableConstants.TASK_NAME))}, new MiscRowMapper());
	}

	public Integer insertToImportHistory(Map<String, Object> filterData){
		Integer id = null;
		try {
			Object[] params = new Object[5];
			params[0] = Utils.getValidation(filterData.get(FMSVariableConstants.SSO_ID));
			params[1] = Utils.getValidation(filterData.get(FMSVariableConstants.TASK_NAME));
			params[2] = Utils.getValidation(filterData.get(FMSVariableConstants.FILE_NAME));
			params[3] = Utils.getValidation(filterData.get(FMSVariableConstants.STATUS));
			params[4] = Utils.getIntegerValidation(filterData.get(FMSVariableConstants.INVALID_COUNT));
			id = jdbc.queryForObject(FMSQueryConstants.INSERT_TO_IMPORT_STATUS_HISTORY,params, Integer.class);
		} catch (Exception e) {
			log.info(FMSVariableConstants.EXCEPTION+ e.getStackTrace());
		}
		return id;

	}

	public void updateImportHistory(String status, int invalidCount, int id) {
		jdbc.update(FMSQueryConstants.UPDATE_IMPORT_STATUS_HISTORY, new Object[] {status, invalidCount, id});
	}

	@Override
	public void getOracleIBASData(Map<String,Object> filterData) {
		String type = Utils.getValidation(filterData.get(FMSVariableConstants.BUSINESS_SEG));
		if(FMSVariableConstants.C_PROD_EXC_PL_DTS.equalsIgnoreCase(type) || FMSVariableConstants.C_PROD_EXC_PL__ALL.equalsIgnoreCase(type)){
			java.util.Date startTimeDTS = new java.util.Date();
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.STARTED,"data fetch Start time for 'DTS' ~ "+ startTimeDTS, "getOracleIBASDataDTS Method"});
			getOracleIBASDataDTS(filterData);
			java.util.Date endTimeDTS = new java.util.Date();
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"data fetch Complete time for 'DTS' ~ "+ endTimeDTS, "getOracleIBASDataDTS Method"});
		}
		if(FMSVariableConstants.C_PROD_EXC_PL_TMS.equalsIgnoreCase(type) || FMSVariableConstants.C_PROD_EXC_PL__ALL.equalsIgnoreCase(type)){
			java.util.Date startTimeTMS = new java.util.Date();
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.STARTED,"data fetch Start time for 'TMS' ~ "+ startTimeTMS, "getOracleIBASDataTMS Method"});
			getOracleIBASDataTMS(filterData);
			java.util.Date endTimeTMS = new java.util.Date();
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"data fetch Complete time for 'TMS' ~ "+ endTimeTMS, "getOracleIBASDataTMS Method"});
		}
	}

	public synchronized int getOracleIBASDataTask(String sso, String type){
		jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{"In Progress","Data featching started.", "Call to getOracleIBASData"+type});
		Map<String, Object> insertHistoryData = new HashMap<>();
		int  insertedRecordID = 0;
		int originalRecords = 0;
		int backUpRecords = 0;
		int cnt = 1;
		if(sso != null){
			insertHistoryData.put(FMSVariableConstants.SSO_ID, sso);
			insertHistoryData.put(FMSVariableConstants.TASK_NAME, "getIBasData"/**+type*/);
			insertHistoryData.put(FMSVariableConstants.FILE_NAME, "-");
			insertHistoryData.put(FMSVariableConstants.STATUS, FMSVariableConstants.IN_PROGRESS);
			insertedRecordID = insertToImportHistory(insertHistoryData);
		}

		try {
			log.info(type+" Data BackUp invoked");
			originalRecords=jdbc.queryForObject(FMSQueryConstants.IBAS_DATA_COUNT,new Object[]{FMSVariableConstants.EMPTY_STRING},Integer.class);
			backUpRecords =	jdbc.queryForObject(FMSQueryConstants.INSERT_IBAS_BACKUP_DATA_USER_SYNC,new Object[]{FMSVariableConstants.USER_SYNC.concat(type),FMSVariableConstants.EMPTY_STRING,FMSVariableConstants.USER_SYNC.concat(type)}, Integer.class);
			log.info(type+" Data BackUp Completed ibasOriginalRecords : "+originalRecords+" , ibasBackUpRecords : "+backUpRecords);
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Back up Completed for ".concat(type).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(sso), "BackUp through User Sync"});
		} catch (Exception e) {
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleIBASDataTask~IBAS Data BackUp ~ "+type});
			log.info(FMSVariableConstants.EXCEPTION+ e.getMessage());
		}
		List<String> ibasRegions = new ArrayList<>();
		/**
		 * Atleast 1 backup will be taken per day by below if Condition ~ as record count is fetched based on date
		 * */
		if(backUpRecords==originalRecords){
			/**jdbc.update(FMSQueryConstants.DELETE_OLD_IBAS_DATA,new Object[]{type});*/
			jdbc.update(FMSQueryConstants.DROP_INDEX_IBAS);
			jdbc.update(FMSQueryConstants.DELETE_OLD_IBAS_DATA);
			log.info("IBAS table truncated");
			List<Map<String, String>> rows=null;
			Map<String, Object> fetchTime = new HashMap<>();
			try{
				log.info("call to getIBASRegions");
				ibasRegions = akanaHandler.execute("getIBASRegions", HttpMethod.POST, type);
				for(int index=0;index<ibasRegions.size();index++){
					fetchTime.put(ibasRegions.get(index), new java.util.Date());
					log.info("regions index  : "+Utils.getValidation(ibasRegions.get(index)));
					Map<String,String> postData = new HashMap<>();
					postData.put("region", Utils.getValidation(ibasRegions.get(index)));
					postData.put("cProdExcPl", type);
					try{
						rows = akanaHandler.execute("getIBASData", HttpMethod.POST, postData);
					}catch(Exception e){
						jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleIBASDataDTS~akanaHandler~getIBASData"+type});
						log.info("IBAS data akana handler error" + e.getStackTrace());
					}
					for(Map<String, String> row : rows){
						Object[] params = new Object[row.keySet().size()];
						List<String> keys = new ArrayList<>();
						for(String key:row.keySet()){
							keys.add(key);
						}
						for(int i=0;i<keys.size();i++) {
							String key = keys.get(i);
							params[i] = row.get(key);
						}
						try{
							jdbc.update(FMSQueryConstants.INSERT_IBAS_DATA, params);
						}catch(Exception e){
							jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleIBASData".concat(type).concat(" ~DataInsertion")});
						}
					} 
				}
				jdbc.update(FMSQueryConstants.CREATE_INDEX_IBAS);	
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Data featching completed.", "getOracleIBASData Method"});
			}catch (Exception e){
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleIBASData".concat(type.toUpperCase())});
				updateImportHistory(FMSVariableConstants.FAILURE, 0, insertedRecordID);
			}
		}else{
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,"IBAS Data not Synchronized","getOracleIBASDataDTS not executed"});
			updateImportHistory(FMSVariableConstants.FAILURE, 0, insertedRecordID);
		}
		return insertedRecordID;
	}


	public synchronized void getOracleIBASDataDTS(Map<String,Object> filterData) {
		log.info("inside getOracleIBASDataDTS() of DaoImpl");
		int insertedRecordID = 0;
		String serviceLogMessage = null;
		String serviceLog = null;
		try{
			insertedRecordID = getOracleIBASDataTask(Utils.getValidation(filterData.get(FMSVariableConstants.SSO_ID)),FMSVariableConstants.C_PROD_EXC_PL_DTS);
			String status =	jdbc.queryForObject(FMSQueryConstants.GET_IMPORT_TASK_STATUS, new Object[]{insertedRecordID}, String.class);
			if(status.equalsIgnoreCase(FMSVariableConstants.FAILURE)){
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,"Error in getOracleIBASDataTask()","getOracleIBASDataDTS~Insertion Error"});
				updateImportHistory(FMSVariableConstants.FAILURE, 0, insertedRecordID);
			}else{
				/**
				 * Generalized Mapping Function Included * 
				String updateIbas = jdbc.queryForObject(FMSQueryConstants.CALL_TO_UPDATE_IBAS_EQUIP_DATA,new Object[]{null},String.class);
				String yrQtr = jdbc.queryForObject(FMSQueryConstants.CALL_TO_UPDATE_IBAS_EQUIP_REG_YR_QTR,new Object[]{},String.class);
				String meMapping = jdbc.queryForObject(FMSQueryConstants.ALL_ORDERS_MAPPING_FUNC, String.class);
				log.info("ALL_ORDERS_MAPPING_FUNC UPDATED");
				String orderMapping = jdbc.queryForObject(FMSQueryConstants.ORDERS_DUNS_MAPPING_FUNC, String.class);
				log.info("ORDERS_DUNS_MAPPING_FUNC UPDATED");
				String fuzzy = jdbc.queryForObject(FMSQueryConstants.UPDATE_FUZZY_MATCH, String.class);
				log.info("UPDATE_FUZZY_MATCH UPDATED");
				String penMetrics = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS, String.class);
				String pmCountrySplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_COUNTRY_TECH_SPLIT, String.class);
				String pmSiteSplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_SITES_SPLIT, String.class);
				String pmSegmentSplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_SEGMENT_SPLIT, String.class);
				String oSiteSplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_SITES_SPLIT, String.class);
				String oRegionSplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_REGIONS_SPLIT, String.class);
				String oCountrySplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_COUNTRIES_SPLIT, String.class);
				String proceduralResult = updateIbas.concat(FMSVariableConstants.PARAM_SEPARATOR).concat(yrQtr).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(penMetrics).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(pmCountrySplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(pmSiteSplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(pmSegmentSplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(oSiteSplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(oRegionSplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(oCountrySplit);
				String serviceLogMsg = proceduralResult.replace("SUCCESS", "1");
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Data Mapping Done || "+serviceLogMsg,"getOracleIBASDataDTS~Methods"});
				serviceLogMessage = FMSVariableConstants.ME_MAPPING.concat(meMapping).concat(FMSVariableConstants.ORDER_MAPPING).concat(orderMapping).concat(FMSVariableConstants.FUZZY).concat(fuzzy).concat(FMSVariableConstants.ALL_METRICS);
				serviceLog = serviceLogMessage.replace("1", FMSVariableConstants.SUCCESS);*/
				log.info(FMSVariableConstants.MAPPING_FUNC_CALL);
				serviceLog = jdbc.queryForObject(FMSQueryConstants.GENERAL_FMS_MAPPING_FUNC, new Object[]{FMSVariableConstants.FMS_MAPPING_FUNC_IBAS}, String.class);
				log.info(FMSVariableConstants.MAPPING_SUCCESS + serviceLog);
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,serviceLog,"IBAS Sync~Orders Mapping Completed"});
				/**Orders mapping functions
				 * from IBAS completed */

				updateImportHistory(FMSVariableConstants.SUCCESS, 0, insertedRecordID);
			}
		} catch(Exception e) {
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleIBASDataDTS~Mapping Error"});
			updateImportHistory(FMSVariableConstants.FAILURE, 0, insertedRecordID);
		}
	}

	public synchronized void getOracleIBASDataTMS(Map<String,Object> filterData) {
		log.info("inside getOracleIBASDataTMS() of DaoImpl");
		int insertedRecordID = 0;
		try{
			insertedRecordID = getOracleIBASDataTask(Utils.getValidation(filterData.get(FMSVariableConstants.SSO_ID)),FMSVariableConstants.C_PROD_EXC_PL_TMS);
			String status =	jdbc.queryForObject(FMSQueryConstants.GET_IMPORT_TASK_STATUS, new Object[]{insertedRecordID}, String.class);
			if(status.equalsIgnoreCase(FMSVariableConstants.FAILURE)){
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,"Error in getOracleIBASDataTask()","getOracleIBASDataTMS~Insertion Error"});
				updateImportHistory(FMSVariableConstants.FAILURE, 0, insertedRecordID);
			}else{
				/**
				 * Generalized Mapping Function to be Included *
				 **/
				String updateIbas = jdbc.queryForObject(FMSQueryConstants.CALL_TO_UPDATE_IBAS_EQUIP_DATA,new Object[]{null},String.class);
				String yrQtr = jdbc.queryForObject(FMSQueryConstants.CALL_TO_UPDATE_IBAS_EQUIP_REG_YR_QTR,new Object[]{},String.class);
				String penMetrics = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS, String.class);
				String pmCountrySplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_COUNTRY_TECH_SPLIT, String.class);
				String pmSiteSplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_SITES_SPLIT, String.class);
				String pmSegmentSplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_SEGMENT_SPLIT, String.class);
				String oSiteSplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_SITES_SPLIT, String.class);
				String oRegionSplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_REGIONS_SPLIT, String.class);
				String oCountrySplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_COUNTRIES_SPLIT, String.class);
				/**String serviceLogMsg = FMSVariableConstants.IBAS_PROC_1.concat(updateIbas).concat(FMSVariableConstants.IBAS_PROC_2).concat(yrQtr).concat(FMSVariableConstants.IBAS_PROC_3).concat(penMetrics).concat(FMSVariableConstants.IBAS_PROC_4).concat(pmCountrySplit).concat(FMSVariableConstants.IBAS_PROC_5).concat(pmSiteSplit).concat(FMSVariableConstants.IBAS_PROC_6).concat(pmSegmentSplit).concat(FMSVariableConstants.IBAS_PROC_7).concat(oSiteSplit).concat(FMSVariableConstants.IBAS_PROC_8).concat(oRegionSplit).concat(FMSVariableConstants.IBAS_PROC_9).concat(oCountrySplit);*/
				String proceduralResult = updateIbas.concat(FMSVariableConstants.PARAM_SEPARATOR).concat(yrQtr).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(penMetrics).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(pmCountrySplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(pmSiteSplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(pmSegmentSplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(oSiteSplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(oRegionSplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(oCountrySplit);
				String serviceLogMsg = proceduralResult.replace("SUCCESS", "1");
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Data Mapping Done || "+serviceLogMsg,"getOracleIBASDataTMS~Methods"});
				updateImportHistory(FMSVariableConstants.SUCCESS, 0, insertedRecordID);
			}
		} catch(Exception e) {
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"getOracleIBASDataTMS~Mapping Error"});
			updateImportHistory(FMSVariableConstants.FAILURE, 0, insertedRecordID);
		}
	}


	@Override
	public String uploadDocuments(InputStream inputStream, String fileName,String fileDescription,String userSSO,String fileAccess) {
		int roleID = 0;
		String response = FMSVariableConstants.FAILURE;
		try {
			if(userSSO !="") {
				List<FMSUserRoleBean> userRoles = getUserRoles(userSSO);
				for (FMSUserRoleBean fmsUserRoleBean : userRoles) {
					roleID = fmsUserRoleBean.getRoleId();
				}	
			}
			if(fileAccess !="" && !fileAccess.isEmpty()){
				Object[] params = {fileDescription,fileName, IOUtils.toByteArray(inputStream),userSSO, roleID};
				int[] types = {Types.VARCHAR, Types.VARCHAR, Types.BINARY, Types.VARCHAR, Types.VARCHAR};
				int id = jdbc.queryForObject(FMSQueryConstants.INSERT_DOCUMENT_QUERY, params, types, Integer.class);
				String[] fileAccessArr = fileAccess.split(",");
				List<Object[]> inputList = new ArrayList<Object[]>();
				for (String roleId : fileAccessArr) {
					Object[] tmp = {id, Integer.valueOf(roleId)};
					inputList.add(tmp);
				}
				jdbc.batchUpdate("insert into fms_documents_role(doc_id,role_id) values(?,?)", inputList);
				response = FMSVariableConstants.SUCCESS;
			}
		}catch(Exception e) {
			response = FMSVariableConstants.FAILURE;
		}
		return response;
	}

	@Override
	public void downloadDocuments(HttpServletResponse responses, Map<String, Object> data) {
		try {
			if(Utils.getIntegerValidation(data.get(FMSVariableConstants.ID)) != 0){
				Map<String, Object> fileData = jdbc.queryForMap(FMSQueryConstants.SELECT_DOCUMENT_QUERY, new Object[] {Utils.getIntegerValidation(data.get(FMSVariableConstants.ID))});
				String filename = fileData.get("filename").toString();
				byte[] bytes = (byte[]) fileData.get("content");
				responses.setHeader(FMSVariableConstants.CONTENTDISPOSITION, "attachment; filename="+filename);
				responses.getOutputStream().write(bytes);
				responses.flushBuffer();
			}
		}catch(Exception e){}
	}

	@Override
	public List<Map<String, Object>> getAllDocuments(Map<String,Object> data) {
		if(Utils.getValidation(data.get(FMSVariableConstants.USER_SSO)) !="") {
			List<FMSUserRoleBean> userRoles = getUserRoles(Utils.getValidation(data.get(FMSVariableConstants.USER_SSO)));
			int roleID = 0;
			for (FMSUserRoleBean fmsUserRoleBean : userRoles) {
				roleID = fmsUserRoleBean.getRoleId();
			}
			if(roleID != 0){
				if(roleID == 1){
					return  jdbc.query(FMSQueryConstants.SELECT_ALL_DOCUMENTS + " group by d.id order by d.id desc", new MiscRowMapper());
				} else if(roleID == 2){
					return  jdbc.query(FMSQueryConstants.SELECT_ALL_DOCUMENTS + " where drole.role_id=9 or drole.role_id in(select role_id from fms_roles where role_name like '%FMS%' ) group by d.id order by d.id desc", new MiscRowMapper());
				} else if(roleID == 4){
					return  jdbc.query(FMSQueryConstants.SELECT_ALL_DOCUMENTS + " where drole.role_id=9 or drole.role_id in(select role_id from fms_roles where role_name like '%IPM%' ) group by d.id order by d.id desc", new MiscRowMapper());
				} else {
					return  jdbc.query(FMSQueryConstants.SELECT_ALL_DOCUMENTS + " where drole.role_id=9 or drole.role_id in(" +roleID +") group by d.id order by d.id desc", new MiscRowMapper());
				}
			}
		}
		return null;
	}


	@Override
	public Map<String, Object> getAllRoles(Map<String,Object> data) {
		if(Utils.getValidation(data.get(FMSVariableConstants.USER_SSO)) !="") {
			List<FMSUserRoleBean> userRoles = getUserRoles(Utils.getValidation(data.get(FMSVariableConstants.USER_SSO)));
			int roleID = 0;
			for (FMSUserRoleBean fmsUserRoleBean : userRoles) {
				roleID = fmsUserRoleBean.getRoleId();
			}
			if(roleID != 0){
				Map<String, Object> result = new HashMap<>(); 
				if(roleID == 1){
					result.put("AllRoles", jdbc.query("select role_id,role_name from fms_roles order by role_name asc", new MiscRowMapper()));
				} else if(roleID == 2){
					result.put("AllRoles", jdbc.query("select role_id,role_name from fms_roles where role_name like '%FMS%' or role_id=9 order by role_name ASC", new MiscRowMapper()));
				} else if(roleID == 4){
					result.put("AllRoles", jdbc.query("select role_id,role_name from fms_roles where role_name like '%IPM%' or role_id=9 order by role_name ASC", new MiscRowMapper()));
				} 
				return result;
			}
		}
		return null;
	}

	@Override
	public String deleteDocument(Map<String, Object> data) {
		String response = FMSVariableConstants.FAILURE;
		if(Utils.getValidation(data.get(FMSVariableConstants.USER_SSO)) !="" && Utils.getValidation(data.get(FMSVariableConstants.FILE_ID)) !="") {
			List<FMSUserRoleBean> userRoles = getUserRoles(Utils.getValidation(data.get(FMSVariableConstants.USER_SSO)));
			int roleID = 0;
			for (FMSUserRoleBean fmsUserRoleBean : userRoles) {
				roleID = fmsUserRoleBean.getRoleId();
			}
			int result = jdbc.update("delete from fms_documents where id = ? and file_delete_access=?", new Object[]{Utils.getIntegerValidation(data.get(FMSVariableConstants.FILE_ID)),String.valueOf(roleID)});
			if(result > 0){
				jdbc.update("delete from fms_documents_role where doc_id = ?", new Object[]{Utils.getIntegerValidation(data.get(FMSVariableConstants.FILE_ID))});
				response = FMSVariableConstants.SUCCESS;
			} else {
				response = FMSVariableConstants.WARNING;
			}
		}
		return response;
	}

	@Override
	public String checkAkanaCallLocally() {
		log.info("Inside checkAkanaCallLocally() of DaoImpl");
		String message = null;
		List<String> akanaMessage = null;
		try {
			akanaMessage = akanaHandler.execute("checkAkanaCallLocally", HttpMethod.GET, null);
			message = akanaMessage.get(0).concat(akanaMessage.get(1)).concat(akanaMessage.get(2));
		} catch (Exception e) {
			message = FMSVariableConstants.FAILURE;
		}
		return message;
	}

	@Override
	public Map<String, Object> getManagersForTopSites(String businessSegment,Map<String, Object> params) {
		log.info("Inside getManagersForTopSites() of DaoImpl");
		businessSegment = FMSVariableConstants.EMPTY_STRING;
		String region = Utils.getValidation(params.get(FMSVariableConstants.REGION));
		String country = Utils.getValidation(params.get(FMSVariableConstants.COUNTRY));
		String marketIndustry =  Utils.getValidation(params.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		Map<String, Object> result = new HashMap<>();
		String managerType = Utils.getValidation(params.get(FMSVariableConstants.MANAGER_TYPE));
		if(FMSVariableConstants.SERVICE_MANAGERS.equalsIgnoreCase(managerType)){
			result.put("serviceManagerDropdown", jdbc.queryForList(FMSQueryConstants.GET_SERVICE_MANAGER_DETAILS_DROPDOWN,new Object[]{region,country,businessSegment,marketIndustry} ,String.class));
		} else if (FMSVariableConstants.ACCOUNT_MANAGERS.equalsIgnoreCase(managerType)){
			result.put("accountManagerDropdown", jdbc.queryForList(FMSQueryConstants.GET_ACCOUNT_MANAGER_DETAILS_DROPDOWN,new Object[]{region,country,businessSegment,marketIndustry} ,String.class));
		}
		return result;
	}

	@Override
	public Map<String, Object> getAccountManagers(String businessSegment,Map<String,Object> data) {
		Map<String, Object> result = new HashMap<>();
		result.put("accountManagerDetails",jdbc.query(FMSQueryConstants.GET_ACCOUNT_MANAGER_DETAILS, new Object[]{/**FMSVariableConstants.EMPTY_STRING,Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "")*/}, new MiscRowMapper()));
		return result;
	}

	@Override
	public Map<String, Object> getMarketIndustryDescDropdown(Map<String, Object> data) {
		Map<String, Object> result = new HashMap<>();
		result.put("marketIndustryValues", jdbc.query(FMSQueryConstants.GET_MARKET_INDUSTRY_DROPDOWN, new MiscRowMapper()));
		return result;
	}

	@Override
	public String importIBOData(InputStream inputStream, String fileName, String userSSO) {
		String response = "";
		Connection con;
		Map<String, Object> insertHistoryData = new HashMap<>();
		insertHistoryData.put(FMSVariableConstants.SSO_ID, userSSO);
		insertHistoryData.put(FMSVariableConstants.TASK_NAME, "FMS IBO IMPORT");
		insertHistoryData.put(FMSVariableConstants.FILE_NAME, fileName);
		insertHistoryData.put(FMSVariableConstants.STATUS, FMSVariableConstants.IN_PROGRESS);
		int insertedId = insertToImportHistory(insertHistoryData);
		String serviceLogMessage = null;
		String serviceLog = null;
		try {
			con = DriverManager.getConnection(url,user,pass);
			CopyManager copyManager = new CopyManager((BaseConnection) con);
			jdbc.execute(FMSQueryConstants.DROP_FMS_IBO_TEMP_DATA);
			jdbc.execute(FMSQueryConstants.CREATE_FMS_IBO_TEMP_DATA_TABLE);
			StringBuilder sql = new StringBuilder();
			sql.append(FMSVariableConstants.COPY);
			sql.append("fms_ibo_temp (region ,country ,gib_serial_number ,technology_aggregated ,equipment ,model ,global_custumer ,site_customer ,site_customer_duns ,site_name ,buying_year_vs_event_year ,event_id ,event_type_cod ,event_status ,event_date_new,category ,source_code ,maint_policy_cod ,maint_policy_desc ,service_factor ,service_factor_mode ,svc_rel_aggregated ,c_prod_exc_pl ,tps_segment ,tps_primary_industry ,tps_sub_industry ,special_cases ,sum_of_value_k_dollar ,value_normalized)");
			sql.append(" FROM STDIN WITH (");
			sql.append(" FORMAT CSV ");
			sql.append(", DELIMITER ','");
			sql.append(", NULL ''");
			sql.append(", HEADER TRUE");
			sql.append(", QUOTE '\"'");
			sql.append(", ESCAPE '\"' ");
			sql.append(", ENCODING 'WIN1257'");   
			sql.append(")");

			log.info(FMSVariableConstants.IMPORT_STARTED);
			copyManager.copyIn(sql.toString(), inputStream );

			int fmsIboTotalCount = jdbc.queryForObject(FMSQueryConstants.FMS_IBO_COUNT , Integer.class);
			if(fmsIboTotalCount > 0){
				jdbc.execute(FMSQueryConstants.TRUNCATE_FMS_IBO_BACKUP_DATA);
				jdbc.execute(FMSQueryConstants.INSERT_FMS_IBO_BACKUP_DATA);
				log.info("import completed !!");
				jdbc.update(FMSQueryConstants.DROP_INDEX_IBO);
				jdbc.execute(FMSQueryConstants.TRUNCATE_FMS_IBO_DATA);
			}

			try {
				jdbc.execute(FMSQueryConstants.INSERT_FMS_IBO_TEMP_TO_FMS_IBO);
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.IN_PROGRESS,FMSVariableConstants.MAPPING_SERVICE_LOG,"importIBOData"});

				/**
				 * Generalized Mapping Function included *
				String updateIbas = jdbc.queryForObject(FMSQueryConstants.CALL_TO_UPDATE_IBAS_EQUIP_DATA,new Object[]{null},String.class);
				String yrQtr = jdbc.queryForObject(FMSQueryConstants.CALL_TO_UPDATE_IBAS_EQUIP_REG_YR_QTR,new Object[]{},String.class);
				String meMapping = jdbc.queryForObject(FMSQueryConstants.ALL_ORDERS_MAPPING_FUNC, String.class);
				log.info("ALL_ORDERS_MAPPING_FUNC UPDATED");
				String orderMapping = jdbc.queryForObject(FMSQueryConstants.ORDERS_DUNS_MAPPING_FUNC, String.class);
				log.info("ORDERS_DUNS_MAPPING_FUNC UPDATED");
				String fuzzy = jdbc.queryForObject(FMSQueryConstants.UPDATE_FUZZY_MATCH, String.class);
				log.info("UPDATE_FUZZY_MATCH UPDATED");
				String penMetrics = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS, String.class);
				String pmCountrySplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_COUNTRY_TECH_SPLIT, String.class);
				String pmSiteSplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_SITES_SPLIT, String.class);
				String pmSegmentSplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_ALL_PEN_METRICS_SEGMENT_SPLIT, String.class);
				String oSiteSplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_SITES_SPLIT, String.class);
				String oRegionSplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_REGIONS_SPLIT, String.class);
				String oCountrySplit = jdbc.queryForObject(FMSQueryConstants.UPDATE_OVERALL_COUNTRIES_SPLIT, String.class);
				String proceduralResult = updateIbas.concat(FMSVariableConstants.PARAM_SEPARATOR).concat(yrQtr).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(penMetrics).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(pmCountrySplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(pmSiteSplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(pmSegmentSplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(oSiteSplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(oRegionSplit).concat(FMSVariableConstants.PARAM_SEPARATOR).concat(oCountrySplit);
				String serviceLogMsg = proceduralResult.replace("SUCCESS", "1");
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,"Data Mapping Done || "+serviceLogMsg,"importIBOData~Methods"});
				serviceLogMessage = FMSVariableConstants.ME_MAPPING.concat(meMapping).concat(FMSVariableConstants.ORDER_MAPPING).concat(orderMapping).concat(FMSVariableConstants.FUZZY).concat(fuzzy).concat(FMSVariableConstants.ALL_METRICS);
				serviceLog = serviceLogMessage.replace("1", FMSVariableConstants.SUCCESS);
				log.info("All query executed!!" + serviceLog);*/
				jdbc.update(FMSQueryConstants.CREATE_INDEX_IBO);
				log.info(FMSVariableConstants.MAPPING_FUNC_CALL);
				serviceLog = jdbc.queryForObject(FMSQueryConstants.GENERAL_FMS_MAPPING_FUNC, new Object[]{FMSVariableConstants.FMS_MAPPING_FUNC_IBAS}, String.class);
				log.info(FMSVariableConstants.MAPPING_SUCCESS + serviceLog);
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.SUCCESS,serviceLog,"importIBOData Mapping Completed"});
				updateImportHistory(FMSVariableConstants.SUCCESS, 0, insertedId);
			}catch(Exception e){
				int tempCount = jdbc.queryForObject(FMSQueryConstants.FMS_IBO_TEMP_DATA_COUNT , Integer.class);
				int fms_ibo_count = jdbc.queryForObject(FMSQueryConstants.FMS_IBO_DATA_COUNT , Integer.class);

				if(tempCount !=fms_ibo_count){
					jdbc.execute(FMSQueryConstants.TRUNCATE_FMS_IBO_DATA);
					jdbc.execute(FMSQueryConstants.REVERT_FMS_IBAS_DATA);
				}
				jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"importIBOData"});
				updateImportHistory(FMSVariableConstants.FAILURE, 0, insertedId);
			}
			jdbc.execute(FMSQueryConstants.DROP_FMS_IBO_TEMP); /** Dropping the table ibo_temp*/
			response = FMSVariableConstants.SUCCESS;
		} catch (Exception e) {
			jdbc.update(FMSQueryConstants.SERVICE_LOGS, new Object[]{FMSVariableConstants.FAILURE,e.getMessage(),"importIBOData"});
			response = FMSVariableConstants.FAILURE;
			updateImportHistory(FMSVariableConstants.FAILURE, 0, insertedId);
		}
		return response;

	}

	public void exportEquipmentData(HttpServletResponse responses,Map<String,Object> filterData) {
		String type = Utils.getValidation(filterData.get(FMSVariableConstants.TYPE));
		String equipmentQuery ;
		/**String businessSegment = Utils.getValidation(data.get(FMSVariableConstants.BUSINESS_SEG));*/
		String MarketIndustry = Utils.getValidation(filterData.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
		if(type.equalsIgnoreCase(FMSVariableConstants.DEFAULT)){
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.YEAR, -5);
			int year = cal.get(Calendar.YEAR);
			equipmentQuery = String.format(FMSQueryConstants.RETRIEVE_IBAS_CSV_DATA,year,FMSVariableConstants.EMPTY_STRING,MarketIndustry);
		}else{
			equipmentQuery = String.format(FMSQueryConstants.RETRIEVE_IBAS_CSV_DATA_ORIGINAL, FMSVariableConstants.EMPTY_STRING,MarketIndustry);

		}
		exportCSVData(responses, equipmentQuery, "Equipment-Data");
	}


	public void exportCSVData(HttpServletResponse responses, String sqlQuery, String fileName) {
		Connection con = null;
		try {
			con = DriverManager.getConnection(url,user,pass);
			CopyManager copyManager = new CopyManager((BaseConnection) con);
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			StringBuilder sql = new StringBuilder();
			sql.append(FMSVariableConstants.COPY);
			sql.append("(" + sqlQuery + ")");
			sql.append(" TO STDOUT WITH (");
			sql.append(" FORMAT CSV ");
			sql.append(", DELIMITER ','");
			sql.append(", NULL ''");
			sql.append(", HEADER TRUE");
			sql.append(", QUOTE '\"'");
			sql.append(", ESCAPE '\"' ");
			sql.append(", ENCODING 'UTF8'");	      
			sql.append(")");
			copyManager.copyOut(sql.toString(), out);
			byte[] bytes = out.toByteArray();
			responses.setHeader(FMSVariableConstants.CONTENTDISPOSITION, "attachment; filename=" + fileName + ".csv");
			responses.getOutputStream().write(bytes);
			responses.flushBuffer();
		}catch(Exception e){
			log.info(e);
		} finally{
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					log.error(FMSVariableConstants.DBEXCEPTION+ e.getStackTrace());
				}
			}
		}
	}

}

