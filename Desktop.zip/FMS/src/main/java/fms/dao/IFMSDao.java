package fms.dao;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;

import fms.bean.FMSAllMetricsDetailsVO;
import fms.bean.FMSCountryNameDropdownBean;
import fms.bean.FMSDMDataBean;
import fms.bean.FMSDMFilterDataBean;
import fms.bean.FMSDMMetricsDetailsDTO;
import fms.bean.FMSDMMetricsDetailsVO;
import fms.bean.FMSIBFilterDataBean;
import fms.bean.FMSIBMetricsDetailsVO;
import fms.bean.FMSIBMetricsDropdownsVO;
import fms.bean.FMSIBOMetricsDetailsVO;
import fms.bean.FMSIBSearchResultsDataBean;
import fms.bean.FMSIBSerachResultsVO;
import fms.bean.FMSIbasDataBean;
import fms.bean.FMSInstalledBaseDataBean;
import fms.bean.FMSInstldBaseDropdownsVO;
import fms.bean.FMSMaintenanceDataBean;
import fms.bean.FMSOrderMappingExcelBean;
import fms.bean.FMSOrdersMetricsDataBean;
import fms.bean.FMSOrdersMetricsDetailsVO;
import fms.bean.FMSOrdersMetricsDropdownsVO;
import fms.bean.FMSOutageDataBean;
import fms.bean.FMSOutageDropdownDTO;
import fms.bean.FMSOutageFilterDataDTO;
import fms.bean.FMSOutageFilterVO;
import fms.bean.FMSOutageMetricsDetailsDTO;
import fms.bean.FMSServiceReqDataBean;
import fms.bean.FMSUserBean;
import fms.bean.FMSUserRoleBean;


public interface IFMSDao {

	public List<FMSMaintenanceDataBean> getAllMaintenanceDao();

	public String updateMaintenanceDao(FMSMaintenanceDataBean maintDTO);

	public String insertToMaintenanceDao(FMSMaintenanceDataBean maintDTO);

	public String  deleteMaintenanceDao(List<String> finalData);

	public List<FMSIbasDataBean> getIbasDao();
	
	public List<FMSIbasDataBean> getIbasDataWithFilterDao(Map<String, Object> data);

	public FMSAllMetricsDetailsVO getAllMetricsDao(String businessSegment, Map<String, Object> data);

	public List<FMSInstalledBaseDataBean> getLatLongByRegionDao(String businessSegment,Map<String, Object> data);

	public List<FMSInstalledBaseDataBean> getLatLongBySiteDao(Map<String, Object> data);

	public List<FMSInstalledBaseDataBean> getSiteInfoAndInstalledUnitsDao(String region, String siteName, String businessSegment, String marketIndustry,String accountManager);

	public List<FMSInstalledBaseDataBean> getSerialInfoDao(String region, String siteName, String serialNumber, String businessSegment, String marketIndustry,String accountManager);

	public FMSInstldBaseDropdownsVO getInstldBaseDropdownsDao(String businessSegment,Map<String, Object> data);

	public FMSIBSerachResultsVO getIBSearchResultsDao(FMSIBSearchResultsDataBean iBSearchResultData);

	public FMSIBMetricsDetailsVO getIBMetricsDao(String businessSegment, Map<String,Object> data);

	public FMSIBMetricsDropdownsVO getIBMetricsDropdownsDao(String businessSegment,Map<String, Object> data);

	public FMSIBMetricsDetailsVO getIBMetricsFilterDao(FMSIBFilterDataBean filterData);

	public FMSIBMetricsDetailsVO getIBFilterDataCountryDao(FMSIBFilterDataBean filterData);
	
	public FMSOrdersMetricsDetailsVO getOrdersMetricsDao(String businessSegment, Map<String, Object> data);

	public FMSOrdersMetricsDropdownsVO getOrdersMetricsDropdownsDao(String businessSegment,Map<String, Object> data);

	public FMSOrdersMetricsDetailsVO getOrdersMetricsFilterDao(FMSOrdersMetricsDataBean ordersMetricsDataBean);

	public FMSOrdersMetricsDetailsVO getOrdersFilterDataCountryDao(FMSOrdersMetricsDataBean ordersMetricsDataBean);

	public List<FMSCountryNameDropdownBean> getCountryDao(Map<String, Object> data);

	public List<FMSCountryNameDropdownBean> getOrderCountryDao(String regionName); 

	public FMSIBOMetricsDetailsVO getIBOMetricsDao(String businessSegment, Map<String, Object> data);

	public FMSIBOMetricsDetailsVO getIBOMetricsFilterDao(FMSIBFilterDataBean filterData);

	public FMSIBOMetricsDetailsVO getIBOFilterDataCountry(FMSIBFilterDataBean filterData);

	public void getOracleData();

	public void getOracleOBPData();

	public void getOracleIBASData(Map<String,Object> filterData);
	
	public void getOracleIBASData();

	public void getOracleDMData();

	public void getOracleOutageData();

	public Map<String, Object> getIPMPartsData(Map<String,Object> filterData);
	
	public List<Map<String, Object>> getOrderDataWithFilter(Map<String,Object> data);

	public Map<String,List<String>> getIPMDropdownData(Map<String,Object> filterData);

	public Map<String, Object> getIPMData(Map<String,Object> filterData,String type);

	public List<Map<String,Object>> getOrderExportData();

	public String updateIPMParts(Map<String, Object> data);

	public List<Map<String,Object>> getIPMPartsExcelDropdown();

	public List<Map<String,Object>> getIPMDataEntryData(Map<String,Object> filterData);

	public String updateIPMDataEntryData(Map<String, Map<String, Object>> updatedData);

	public Map<String,Object> walkByBusinessData(Map<String,Object> filterData);

	public Map<String,Object> walkByRegionData(Map<String,Object> filterData);

	public String updateIPMLogicFields();

	public Map<String,Object> projectController(Map<String,Object> filterData);

	public Map<String,Object> walkByProduct(Map<String,Object> filterData);

	public Map<String,Object> getQuarterYear();

	public List<String> getIPMPartsDropdownData(Map<String, Object> filterData);

	public Map<String,Object> walkByFinance(Map<String,Object> filterData);

	public String importCSVToTable(InputStream inputStream, String fileName, String userSSO);

	public void exportCSVFromTable(HttpServletResponse responses,Map<String,Object> filterData);

	public void exportCSVFromMaster(HttpServletResponse responses);

	/** FMS Enhancement new services*/

	public FMSDMMetricsDetailsDTO getDMMetricsData(String businessSegment, Map<String, Object> data);

	public Map<String,Object> getDMMetricsDropdown(String businessSegment,Map<String, Object> data);

	public List<FMSCountryNameDropdownBean> getDMCountry(Map<String, Object> data);

	public String storeMappingData(List<Map<String,List<FMSOrderMappingExcelBean>>> mappingDataList,String mappingParam);

	public List<FMSDMDataBean> getDMData(Map<String,Object> data);

	public List<FMSServiceReqDataBean> getServiceReqData(String data);

	public Map<String, Object> getPMOChartData(Map<String,Object> filterData);

	public Map<String, Object> getPMOChartDetailsData(Map<String,Object> filterData);

	public Map<String,Object> getChooseColumns();

	public FMSDMMetricsDetailsVO getDMMetricsFilterDao(FMSDMFilterDataBean filterData);

	public FMSDMMetricsDetailsVO getDMFilterDataCountryDao(FMSDMFilterDataBean filterData);

	public FMSOutageMetricsDetailsDTO getOutageMetricsData(Map<String, Object> data);

	public List<FMSOutageDataBean> getOutageData(Map<String, Object> data);

	public void exportPMODrilDownData(HttpServletResponse responses,Map<String,Object> filterData);

	public FMSOutageDropdownDTO getOutageDropdown(Map<String, Object> data);

	public FMSOutageFilterVO getOutageFilterDataRegion(FMSOutageFilterDataDTO filterData);

	public FMSOutageFilterVO getOutageFilterDataCountry(FMSOutageFilterDataDTO filterData);

	public void getOracleServiceRequestData();

	public Map<String, Object> getServiceReqMetricsFilterData(Map<String,Object> data);

	public Map<String, Object> getServiceRequestMetricsData(Map<String, Object> data);

	public Map<String, Object> getServiceRequestDropdown();

	public Map<String, Object> getCombinedAnalysisDropdownData(Map<String, Object> data);

	public String importCSVToOrder(InputStream inputStream, String fileName, String userSSO, String businessSegment, String marketIndustry);

	public Map<String, Object> getCombinedAnalysisMetrics(Map<String, Object> data);

	public List<Map<String,Object>> exportCombinedAnalytics(Map<String, Object> data,String metrics);

	public List<FMSUserBean> authorizeUser(String userId);

	public String importCSVToCustMapping(InputStream inputStream);

	public String importCSVToSalesData(InputStream inputStream, String businessSegment,String marketIndustry);

	public List<FMSUserRoleBean> getUserRoles(String userId);

	public void downloadFile(HttpServletResponse responses, Map<String,Object> data);

	public List<Map<String, Object>> downloadExcelFile(String mappingParam);

	public Map<String, Object> getAllMetricsCountryTechData(String type,Map<String,Object> filters);
	
	public Map<String, Object> getPenMetricsSegmentData(String type,Map<String,Object> filters);

	public List<String> getPenetratinMetricsCountryDropdown(String businessSegment,Map<String,Object> filters);

	public List<String>  getPenetratinMetricsRegionDropdown(Map<String,Object> filters);

	public Map<String, Object> getAllMetricsCountrySiteData(Map<String,Object> filters);

	public List<String> getAllMetricsCountrySiteDropdown(String businessSegment,Map<String,Object> filters);

	public Map<String, Object> penetrationExportExcelData(Map<String,Object> filters);

	public Map<String, Object> penetrationDashboard(String businessSegment,Map<String,Object> filters);

	public enum Page {
		ibTechReg, ordersTechReg, dmTechReg, outageTechReg, serviceTechReg;
	}

	public Map<String, Object> getRawDataIBOPage(String page, JSONObject jsonObj);

	public List<String> getRawDataHeadersList(String exportSheet);

	public List<Map<String,Object>> exportRawDataMetrics(JSONObject jsonObj,String page);

	public Map<String, Object> getAllMetricsGEDunsNameData(Map<String,Object> filters);

	public List<String> getPenetrationMetricsGEDunsNameDropdown(String businessSegment,Map<String,Object> filters);

	public Map<String, Object> penetrationGEDunsExportExcelData(Map<String,Object> filters);

	public Map<String, Object> getPenMetricsTopSitesByRegion(Map<String,Object> filters);

	public List<Map<String, Object>> fetchPostgreRegionData();

	public Map<String, Object> getIPMRawData(Map<String,Object> filterData);

	public String updateIPMPartsQmi(Map<String, Object> filterData);

	public List<String> getOrdersYears();

	public String manageUsers(Map<String, Object> userData);

	public Map<String, Object> getParticularUserDetails(String sso);
	
	public Map<String, Object> getUserManagementDetails();

	public List<Map<String, Object>> exportUserManagementData(String exportType);

	public String manageRoles(Map<String, Object> rolesData);

	public Map<String,Object> getUserDetailsBasedOnRole(int roleId);

	public void backUpService(String date);
	
	public void exportInvalidIPMData(HttpServletResponse responses,Map<String,Object> filterData);
	
	public List<Map<String,Object>> getImportStatusHistory(@RequestBody Map<String,Object> filterData);
	
	public String uploadDocuments(InputStream inputStream, String fileName,String fileDescription, String userSSO, String fileAccess);
	
	public void downloadDocuments(HttpServletResponse responses, Map<String,Object> data);
	
	public List<Map<String,Object>> getAllDocuments(Map<String,Object> data);
	
	public Map<String,Object> getAllRoles(Map<String,Object> data);
	
	public String deleteDocument(Map<String,Object> data);

	public String checkAkanaCallLocally();

	public Map<String, Object> getManagersForTopSites(String businessSegment,Map<String, Object> params);

	public Map<String, Object> getAccountManagers(String businessSegment,Map<String,Object> data);

	public Map<String, Object> getMarketIndustryDescDropdown(Map<String, Object> data);
	
	public String importIBOData(InputStream inputStream,String fileName, String userSSO);
	
	public void exportEquipmentData(HttpServletResponse responses,Map<String,Object> filterData);
}
