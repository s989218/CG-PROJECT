package fms.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import fms.bean.FMSAllMetricsDetailsVO;
import fms.bean.FMSCountryNameDropdownBean;
import fms.bean.FMSDMDataBean;
import fms.bean.FMSDMFilterDataBean;
import fms.bean.FMSDMMetricsDetailsDTO;
import fms.bean.FMSIBFilterDataBean;
import fms.bean.FMSIBMetricsDetailsVO;
import fms.bean.FMSIBMetricsDropdownsVO;
import fms.bean.FMSIBOMetricsDetailsVO;
import fms.bean.FMSIBSearchResultsDataBean;
import fms.bean.FMSIBSerachResultsVO;
import fms.bean.FMSIbasDataBean;
import fms.bean.FMSInstalledBaseDataBean;
import fms.bean.FMSInstldBaseDropdownsVO;
import fms.bean.FMSMaintenanceDataBean;
import fms.bean.FMSOrdersMetricsDataBean;
import fms.bean.FMSOrdersMetricsDetailsVO;
import fms.bean.FMSOrdersMetricsDropdownsVO;
import fms.bean.FMSOutageDataBean;
import fms.bean.FMSOutageDropdownDTO;
import fms.bean.FMSOutageFilterDataDTO;
import fms.bean.FMSOutageMetricsDetailsDTO;
import fms.bean.FMSServiceReqDataBean;
import fms.bean.FMSUserBean;
import fms.constants.FMSVariableConstants;
import fms.service.IFMSService;
import fms.utils.Utils;


@Controller
@RequestMapping("/fms")
public class FMSController {


	@Autowired
	private IFMSService objService;

	private final Logger log = Logger.getLogger(this.getClass());


	@RequestMapping(method=RequestMethod.GET)
	@ResponseBody public String greet() {
		StringBuilder sb = new StringBuilder("<b>Welcome</b> <br>");
		return sb.toString();
	}

	@RequestMapping(method=RequestMethod.GET,value="getAllMaintenanceData")
	@ResponseBody public List<FMSMaintenanceDataBean> getAllMaintenanceData() {
		return objService.getAllMaintenanceData();  
	}

	public FMSMaintenanceDataBean dataRead(JSONObject jObj1){
		FMSMaintenanceDataBean maintDTO = new FMSMaintenanceDataBean();
		maintDTO.setId("0");
		maintDTO.setPolicy(Utils.getValidation(jObj1.get(FMSVariableConstants.POLICY)));
		maintDTO.setPolicyAggr(Utils.getValidation(jObj1.get(FMSVariableConstants.POLICYAGGR)));
		maintDTO.setLevel(Utils.getValidation(jObj1.get(FMSVariableConstants.LEVEL)));
		maintDTO.setHours(Utils.getValidation(jObj1.get(FMSVariableConstants.HRS)));
		maintDTO.setAge(Utils.getValidation(jObj1.get(FMSVariableConstants.AGE)));
		maintDTO.setParts(Utils.getValidation(jObj1.get(FMSVariableConstants.PARTS)));
		maintDTO.setRepairs(Utils.getValidation(jObj1.get(FMSVariableConstants.REPAIRS)));
		maintDTO.setServices(Utils.getValidation(jObj1.get(FMSVariableConstants.SERVICES)));
		maintDTO.setManpower(Utils.getValidation(jObj1.get(FMSVariableConstants.MANPOWER)));
		maintDTO.setAux(Utils.getValidation(jObj1.get(FMSVariableConstants.AUX)));
		maintDTO.setTotal(Utils.getValidation(jObj1.get(FMSVariableConstants.TOTAL)));
		return maintDTO;
	}

	@RequestMapping(method=RequestMethod.POST, value="updateMaintenanaceData", consumes="application/json", produces="text/plain") 
	@ResponseBody public String updateMaintenanceData(@RequestBody String data){

		try
		{
			JSONParser parse = new JSONParser();
			JSONObject jObj = (JSONObject) parse.parse(data);
			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);
			JSONObject jObj1 = (JSONObject)jArr.get(0); 

			FMSMaintenanceDataBean maintDTO = dataRead(jObj1);
			return objService.updateMaintenanceData(maintDTO);
		}
		catch(Exception e){
			log.info(e);
			return FMSVariableConstants.FAILURE;
		}
	}


	@RequestMapping(method=RequestMethod.POST,value="insertToMaintenanceData", consumes="application/json", produces="text/plain")
	@ResponseBody public String insertToMaintenanceData(@RequestBody String data){

		try
		{
			JSONParser parse = new JSONParser();
			JSONObject jObj = (JSONObject) parse.parse(data);
			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);
			JSONObject jObj1 = (JSONObject)jArr.get(0); 

			FMSMaintenanceDataBean maintDTO = dataRead(jObj1);
			return objService.insertToMaintenanceData(maintDTO);
		}
		catch(Exception e){
			log.info(e);
			return FMSVariableConstants.FAILURE;
		}
	}

	@RequestMapping(method=RequestMethod.POST, value="deleteFromMaintenanceData", consumes="application/json", produces="text/plain")
	@ResponseBody public String  deleteMaintenanceData(@RequestBody String data){

		ArrayList<String> al=new ArrayList<>();
		JSONParser parse = new JSONParser();
		try {
			JSONObject jObj = (JSONObject) parse.parse(data);
			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);

			for (int i = 0; i < jArr.size(); i++) {
				al.add(jArr.get(i).toString());
			}


		} catch (ParseException e) {
			log.info(e);
			return FMSVariableConstants.FAILURE;
		}

		return objService.deleteMaintenanceData(al);
	}

	public CellStyle setStyle(SXSSFWorkbook wb, String type){
		CellStyle style = wb.createCellStyle();

		if(FMSVariableConstants.DATE.equalsIgnoreCase(type))
		{
			CreationHelper createHelper = wb.getCreationHelper();
			style.setDataFormat(createHelper.createDataFormat().getFormat("yyyy-MM-dd"));
		}else if(FMSVariableConstants.COLORR.equalsIgnoreCase(type)){
			style.setFillForegroundColor(IndexedColors.RED.getIndex());
			style.setFillPattern(CellStyle.SOLID_FOREGROUND); 
		}else if(FMSVariableConstants.COLORG.equalsIgnoreCase(type)){
			style.setFillForegroundColor(IndexedColors.GREEN.getIndex());
			style.setFillPattern(CellStyle.SOLID_FOREGROUND); 
		}else if(FMSVariableConstants.COLORY.equalsIgnoreCase(type)){
			style.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
			style.setFillPattern(CellStyle.SOLID_FOREGROUND); 
		}

		style.setAlignment(CellStyle.ALIGN_LEFT);

		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderTop(CellStyle.BORDER_THIN);

		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setTopBorderColor(IndexedColors.BLACK.getIndex());

		return style;
	}

	public Font setFont(SXSSFWorkbook wb, String type){

		Font font = wb.createFont();
		font.setFontHeightInPoints((short) 10);
		font.setFontName(FMSVariableConstants.GE_INSPIRA_FONT);
		font.setItalic(false);

		if(FMSVariableConstants.HEADER.equalsIgnoreCase(type))
		{
			font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		}
		return font;
	}

	public Cell cellSet(String type, CellStyle dateStyle, CellStyle dataStyle, Row row, int cellNo, Object input){
		int cellN = cellNo;
		Cell dataC = row.createCell(cellN);

		if(FMSVariableConstants.INTEGER.equalsIgnoreCase(type)){
			dataC.setCellStyle(dataStyle);
			if(input!=null){
				dataC.setCellValue((int)input);
			}
			else
			{
				dataC.setCellValue("");
			}
		}
		else if(FMSVariableConstants.FLOAT.equalsIgnoreCase(type)){
			dataC.setCellStyle(dataStyle);
			if(input!=null){
				dataC.setCellValue((float)input);
			}
			else
			{
				dataC.setCellValue("");
			}
		}
		else if(FMSVariableConstants.DATE.equalsIgnoreCase(type)){
			dataC.setCellStyle(dateStyle);
			if(input!=null){
				dataC.setCellValue((String)input);
			}
			else
			{
				dataC.setCellValue("");
			}
		}
		else if(FMSVariableConstants.DOUBLE.equalsIgnoreCase(type)){
			dataC.setCellStyle(dataStyle);
			if(input!=null){
				dataC.setCellValue((double)input);
			}
			else
			{
				dataC.setCellValue("");
			}
		}
		else
		{
			dataC.setCellStyle(dataStyle);
			dataC.setCellValue((String)input);
		}
		return dataC;
	}

	@RequestMapping(method=RequestMethod.POST,value="exportEquipmentData",consumes="application/json")
	@ResponseBody public void exportEquipmentData(HttpServletResponse response,@RequestBody Map<String, Object> data) throws IOException, ParseException {
		objService.exportEquipmentData(response, data);
	}

	@RequestMapping(method=RequestMethod.POST,value="exportMaintenanceData",consumes="application/json")
	@ResponseBody public void exportMaintenanceData(HttpServletResponse response) throws IOException, ParseException {	

		List<FMSMaintenanceDataBean> listMaintData = objService.getAllMaintenanceData();
		SXSSFWorkbook workbook = new SXSSFWorkbook(100);
		Sheet sheet = workbook.createSheet("Maintenance Data");


		Font headerFont = setFont(workbook,FMSVariableConstants.HEADER);
		Font dataFont = setFont(workbook,FMSVariableConstants.DATA);

		CellStyle headerStyle = setStyle(workbook, FMSVariableConstants.HEADER);
		CellStyle dataStyle = setStyle(workbook, FMSVariableConstants.DATA);


		Row row = sheet.createRow(0);
		int cellNo = 0;
		List<String> headerList = new ArrayList<>();

		headerList.add("Id");
		headerList.add("Policy");
		headerList.add("Policy Aggr");
		headerList.add("Level");
		headerList.add("Hours");
		headerList.add("Age");
		headerList.add("Parts");
		headerList.add("Repairs");
		headerList.add("Services");
		headerList.add("Manpower");
		headerList.add("Aux");
		headerList.add("Total");

		for (String header : headerList) {
			Cell cell = row.createCell(cellNo);
			headerStyle.setFont(headerFont);
			cell.setCellStyle(headerStyle);
			cell.setCellValue(header);
			cellNo++;
		}

		int rowNo = 1;
		for(FMSMaintenanceDataBean maintDto: listMaintData)
		{

			row = sheet.createRow(rowNo++);
			dataStyle.setFont(dataFont);
			cellNo = 0;
			dataStyle.setFont(dataFont);

			Cell dataCell;

			dataCell = row.createCell(cellNo++);
			dataCell.setCellStyle(dataStyle);
			dataCell.setCellValue((maintDto.getId() == null) ? "" : maintDto.getId());

			dataCell = row.createCell(cellNo++);
			dataCell.setCellStyle(dataStyle);
			dataCell.setCellValue(maintDto.getPolicy());

			dataCell = row.createCell(cellNo++);
			dataCell.setCellStyle(dataStyle);
			dataCell.setCellValue(maintDto.getPolicyAggr());

			dataCell = row.createCell(cellNo++);
			dataCell.setCellStyle(dataStyle);
			dataCell.setCellValue(maintDto.getLevel());

			dataCell = row.createCell(cellNo++);
			dataCell.setCellStyle(dataStyle);
			dataCell.setCellValue(maintDto.getHours());

			dataCell = row.createCell(cellNo++);
			dataCell.setCellStyle(dataStyle);
			dataCell.setCellValue((maintDto.getAge() == null) ? "" : maintDto.getAge());

			dataCell = row.createCell(cellNo++);
			dataCell.setCellStyle(dataStyle);
			dataCell.setCellValue(maintDto.getParts());

			dataCell = row.createCell(cellNo++);
			dataCell.setCellStyle(dataStyle);
			dataCell.setCellValue(maintDto.getRepairs());

			dataCell = row.createCell(cellNo++);
			dataCell.setCellStyle(dataStyle);
			dataCell.setCellValue(maintDto.getServices());

			dataCell = row.createCell(cellNo++);
			dataCell.setCellStyle(dataStyle);
			dataCell.setCellValue(maintDto.getManpower());

			dataCell = row.createCell(cellNo++);
			dataCell.setCellStyle(dataStyle);
			dataCell.setCellValue(maintDto.getAux());

			dataCell = row.createCell(cellNo);
			dataCell.setCellStyle(dataStyle);
			dataCell.setCellValue(maintDto.getTotal());

		}	

		try
		{
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			workbook.write(baos);
			baos.close();
			byte[] bytes = baos.toByteArray();
			response.setHeader(FMSVariableConstants.CONTENTDISPOSITION, "attachment; filename=Maintenance Data.xlsx");
			response.getOutputStream().write(bytes);
			response.flushBuffer();
		}
		catch (IOException e) {
			log.info(e);
		}
	}

	@RequestMapping(method=RequestMethod.GET, value="getIbasData")
	@ResponseBody public List<FMSIbasDataBean>  getIbasData(){
		return objService.getIbasData();
	}

	@RequestMapping(method=RequestMethod.POST, value="getIbasDataWithFilter", consumes="application/json")
	@ResponseBody public List<FMSIbasDataBean>  getIbasDataWithFilter(@RequestBody Map<String, Object> data){
		List<FMSIbasDataBean> response = new ArrayList<>();
			response=objService.getIbasDataWithFilter(data);
				return response;

	}

	@RequestMapping(method=RequestMethod.POST, value="getAllMetricsData/{businessSegment}")
	@ResponseBody public FMSAllMetricsDetailsVO  getAllMetricsData(@PathVariable("businessSegment") String businessSegment, @RequestBody Map<String, Object> data){
		return objService.getAllMetricsData(businessSegment,data);
	}

	@RequestMapping(method=RequestMethod.POST, value="getLatLongByRegion/{businessSegment}")
	@ResponseBody public List<FMSInstalledBaseDataBean>  getLatLongByRegion(@PathVariable("businessSegment") String businessSegment,@RequestBody Map<String, Object> data){
		return objService.getLatLongByRegion(businessSegment,data);
	}

	@RequestMapping(method=RequestMethod.POST, value="getLatLongBySite", consumes="application/json",produces="application/json")
	@ResponseBody public List<FMSInstalledBaseDataBean>  getLatLongBySite(@RequestBody Map<String, Object> data){
		List<FMSInstalledBaseDataBean> response = new ArrayList<>();
		try{
			response=objService.getLatLongBySite(data);
		}catch(Exception e){
			log.info(e);
		}
		return response;

	}


	@RequestMapping(method=RequestMethod.POST, value="getSiteInfoAndInstalledUnits", consumes="application/json")
	@ResponseBody public List<FMSInstalledBaseDataBean>  getSiteInfoAndInstalledUnits(@RequestBody Map<String, Object> data){
		List<FMSInstalledBaseDataBean> response = new ArrayList<>();
		try{
			
			String region = Utils.getValidation(data.get(FMSVariableConstants.REGION));
			String siteName = Utils.getValidation(data.get(FMSVariableConstants.SITENAME));
			String businessSegment = FMSVariableConstants.EMPTY_STRING;
			String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
			String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));
			
			response=objService.getSiteInfoAndInstalledUnits(region, siteName,businessSegment,marketIndustry,accountManager);
		}catch(Exception e){
			log.info(e);
		}
		return response;

	}

	@RequestMapping(method=RequestMethod.POST, value="getSerialInfoData", consumes="application/json")
	@ResponseBody public List<FMSInstalledBaseDataBean>  getSerialInfoData(@RequestBody Map<String, Object> data){
		List<FMSInstalledBaseDataBean> response = new ArrayList<>();

		try{
			String region = Utils.getValidation(data.get(FMSVariableConstants.REGION));
			String siteName = Utils.getValidation(data.get(FMSVariableConstants.SITENAME));
			String serialNumber = Utils.getValidation(data.get(FMSVariableConstants.SERIALNUMBER));
			String businessSegment = FMSVariableConstants.EMPTY_STRING;
			String marketIndustry = Utils.getValidation(data.get(FMSVariableConstants.MARKET_INDUSTRY)).replace("&", "");
			String accountManager = Utils.getValidation(data.get(FMSVariableConstants.ACCOUNT_MANAGER));
			response=objService.getSerialInfoData(region,siteName,serialNumber,businessSegment,marketIndustry,accountManager);
		}catch(Exception e){
			log.info(e);
		}
		return response;

	}

	@RequestMapping(method=RequestMethod.POST, value="getInstldBaseDropdownsData/{businessSegment}")
	@ResponseBody public FMSInstldBaseDropdownsVO  getInstldBaseDropdownsData(@PathVariable("businessSegment") String businessSegment, @RequestBody Map<String, Object> data){
		return objService.getInstldBaseDropdownsData(businessSegment,data);
	}

	@RequestMapping(method=RequestMethod.POST, value="getIBSearchResultsData", consumes="application/json")
	@ResponseBody public FMSIBSerachResultsVO  getIBSearchResultsData(@RequestBody Map<String, Object> data){

		FMSIBSearchResultsDataBean iBSearchResultData = new FMSIBSearchResultsDataBean();
		try
		{	
			iBSearchResultData.setSiteName((String) data.get(FMSVariableConstants.SITENAME));
			iBSearchResultData.setInstallBaseSiteCustName((String) data.get(FMSVariableConstants.SITECUSTNAME));
			iBSearchResultData.setRegion((String) data.get(FMSVariableConstants.REGION));
			iBSearchResultData.setMarket((String) data.get(FMSVariableConstants.MARKET));
			iBSearchResultData.setSerialNum((String) data.get(FMSVariableConstants.SERIALNUM));
			iBSearchResultData.setTechnology((String) data.get(FMSVariableConstants.TECHNOLOGY));
			iBSearchResultData.setInstallBaseSiteCustAliasDDBean((String) data.get(FMSVariableConstants.SITE_CUST_ALIAS));
			iBSearchResultData.setInstallBaseOEMLoc((String) data.get(FMSVariableConstants.OEM_LOC));
			iBSearchResultData.setInstallBaseSrvRelDescOG((String) data.get(FMSVariableConstants.SERVRELATIONDESCONG));
			iBSearchResultData.setCountry((String) data.get(FMSVariableConstants.COUNTRY));
			iBSearchResultData.setGeDuns((String) data.get(FMSVariableConstants.GE_DUNS));
			iBSearchResultData.setAccountManager((String) data.get(FMSVariableConstants.ACC_MGR));
			iBSearchResultData.setBusinessSegment((String) data.get(FMSVariableConstants.BUSINESS_SEG)); 
			iBSearchResultData.setMarketIndustryIB((String) data.get(FMSVariableConstants.MARKET_INDUSTRY));
		}
		catch(Exception e){
			log.info(e);
		}
		return objService.getIBSearchResultsData(iBSearchResultData);
	}

	@RequestMapping(method=RequestMethod.POST, value="getIBMetricsData/{businessSegment}")
	@ResponseBody public FMSIBMetricsDetailsVO  getIBMetricsData(@PathVariable("businessSegment") String businessSegment, @RequestBody Map<String,Object> data){
		return objService.getIBMetricsData(businessSegment,data);
	}

	/*
	 * This webservice return IB metrics data for drop down fields.
	 *  
	 */
	@RequestMapping(method=RequestMethod.POST, value="getIBMetricsDropdownsData/{businessSegment}")
	@ResponseBody public FMSIBMetricsDropdownsVO  getIBMetricsDropdownsData(@PathVariable("businessSegment") String businessSegment,@RequestBody Map<String, Object> data){
		return objService.getIBMetricsDropdownsData(businessSegment,data);
	}

	/*
	 * This webservice return metrics data.
	 * 
	 */
	@RequestMapping(method=RequestMethod.POST, value="getMetricsData/{ServiceType}", consumes="application/json")
	@ResponseBody public Object   getIBMetricsFilterData(@PathVariable("ServiceType") String type, @RequestBody String data){

		FMSIBFilterDataBean filterData = new FMSIBFilterDataBean();
		try
		{
			
			JSONParser parse = new JSONParser();
			JSONObject jObj = (JSONObject) parse.parse(data);
			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);
			JSONObject jObj1 = (JSONObject)jArr.get(0); 
			filterData.setRegion(Utils.nullCheck(jObj1.get(FMSVariableConstants.REGION)));
			filterData.setTechnology(Utils.nullCheck(jObj1.get(FMSVariableConstants.TECHNOLOGY)));
			filterData.setCustName(Utils.nullCheck(jObj1.get(FMSVariableConstants.CUSTOMERNAME)));
			filterData.setUnitStatusDesc(Utils.nullCheck(jObj1.get(FMSVariableConstants.UNITSTATUSDESC)));
			filterData.setSiteCustCountry(Utils.nullCheck(jObj1.get(FMSVariableConstants.SITECUSTCOUNTRY)));
			filterData.setServRelDesc(Utils.nullCheck(jObj1.get(FMSVariableConstants.SERVRELATIONDESCONG)));
			filterData.setMarketSegment(Utils.nullCheck(jObj1.get(FMSVariableConstants.MARKETSEGMENTDESC)));
			filterData.setOemLoc(Utils.nullCheck(jObj1.get(FMSVariableConstants.OEM_LOC)));
			filterData.setSiteCustDunsName(Utils.nullCheck(jObj1.get(FMSVariableConstants.SITE_CUST_DUNS_NAME)));
			filterData.setSiteCustName(Utils.nullCheck(jObj1.get(FMSVariableConstants.SITECUSTNAME)));
			filterData.setSiteNameAlias(Utils.nullCheck(jObj1.get(FMSVariableConstants.SITENAMEALIAS)));
			filterData.setEquipmentCodeFilter(Utils.nullCheck(jObj1.get(FMSVariableConstants.EQUIPMENTCODEFILTER)));
			filterData.setBusinessSegmentFilter(Utils.nullCheck(jObj1.get(FMSVariableConstants.BUSINESS_SEG)));
			filterData.setAccountManagerFilter(Utils.nullCheck(jObj1.get(FMSVariableConstants.ACC_MGR)));
			filterData.setMarketIndustryIB(Utils.nullCheck(jObj1.get(FMSVariableConstants.MARKET_INDUSTRY)));
			filterData.setIboType(Utils.nullCheck(jObj1.get(FMSVariableConstants.IBO_TYPE)));
			if (type.equals(FMSVariableConstants.IBODATA)) {
				return objService.getIBOMetricsFilterData(filterData);
			} else if (type.equals(FMSVariableConstants.IBDATA)) {
				return objService.getIBMetricsFilterData(filterData);
			} else if (type.equals(FMSVariableConstants.IBOCOUNTRY)) {
				return objService.getIBOFilterDataCountry(filterData);
			} else if (type.equals(FMSVariableConstants.IBCOUNTRY)) {
				return objService.getIBFilterDataCountry(filterData);
			}
		}
		catch(Exception e){
			log.info(e);
		}

		return null;
	}

	@RequestMapping(method=RequestMethod.POST, value="getOrdersMetricsData/{businessSegment}")
	@ResponseBody public FMSOrdersMetricsDetailsVO  getOrdersMetricsData(@PathVariable("businessSegment") String businessSegment, @RequestBody Map<String, Object> data){
		return objService.getOrdersMetricsData(businessSegment,data);
	}

	/*
	 * This webservice return order metrics data for drop down fields.
	 *  
	 */
	@RequestMapping(method=RequestMethod.POST, value="getOrdersMetricsDropdownsData/{businessSegment}")
	@ResponseBody public FMSOrdersMetricsDropdownsVO  getOrdersMetricsDropdownsData(@PathVariable("businessSegment") String businessSegment,@RequestBody Map<String, Object> data){
		return objService.getOrdersMetricsDropdownsData(businessSegment,data);  		
	}

	/*
	 * This webservice return order filter data based on search criteria.
	 *  
	 */
	@RequestMapping(method=RequestMethod.POST, value="getOrdersMetricsFilterData/{ServiceType}", consumes="application/json")
	@ResponseBody public FMSOrdersMetricsDetailsVO  getOrdersMetricsFilterData(@PathVariable("ServiceType") String type, @RequestBody String data){

		FMSOrdersMetricsDataBean ordersMetricsDataBean = new FMSOrdersMetricsDataBean();
		try
		{
			JSONParser parse = new JSONParser();
			JSONObject jObj = (JSONObject) parse.parse(data);
			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);
			JSONObject jObj1 = (JSONObject)jArr.get(0); 
			ordersMetricsDataBean.setCountryName(Utils.nullCheck(jObj1.get("countryName")));
			ordersMetricsDataBean.setServiceType(Utils.nullCheck(jObj1.get("serviceType")));
			ordersMetricsDataBean.setEndUserName(Utils.nullCheck(jObj1.get("endUserName")));
			ordersMetricsDataBean.setRegion(Utils.nullCheck(jObj1.get(FMSVariableConstants.REGION)));
			ordersMetricsDataBean.setGeDunsName(Utils.nullCheck(jObj1.get(FMSVariableConstants.GEDUNSNAME)));
			ordersMetricsDataBean.setSmSegmentMapping(Utils.nullCheck(jObj1.get(FMSVariableConstants.SM_SEGMENT_MAPPING)));
			ordersMetricsDataBean.setPmProductMapping(Utils.nullCheck(jObj1.get(FMSVariableConstants.PM_PRODUCT_MAPPING)));
			ordersMetricsDataBean.setMeTier4(Utils.nullCheck(jObj1.get(FMSVariableConstants.ME_TIER4)));
			ordersMetricsDataBean.setMeDMTier3(Utils.nullCheck(jObj1.get(FMSVariableConstants.ME_DM_TIER3)));
			ordersMetricsDataBean.setOrdersState(Utils.nullCheck(jObj1.get(FMSVariableConstants.STATE)));
			ordersMetricsDataBean.setOrdersBusinessSegment(Utils.nullCheck(jObj1.get(FMSVariableConstants.BUSINESS_SEG)));
			ordersMetricsDataBean.setAccountManager(Utils.nullCheck(jObj1.get(FMSVariableConstants.ACC_MGR)));
			ordersMetricsDataBean.setMarketIndustry(Utils.nullCheck(jObj1.get(FMSVariableConstants.MARKET_INDUSTRY)));
			
			if(type.equals(FMSVariableConstants.ORDERSDATA)) {
				return objService.getOrdersMetricsFilterData(ordersMetricsDataBean);
			} else if(type.equals(FMSVariableConstants.ORDERSCOUNTRY)){
				return objService.getOrdersFilterDataCountry(ordersMetricsDataBean);
			}		

		}
		catch(Exception e){
			log.info(e);
		}

		return objService.getOrdersMetricsFilterData(ordersMetricsDataBean);

	}

	/*
	 * This webservice return list of country name based on regionId
	 *  
	 */
	@RequestMapping(method=RequestMethod.POST, value="getCountryData")
	@ResponseBody public List<FMSCountryNameDropdownBean>  getCountryData(@RequestBody Map<String, Object> data){
		return objService.getCountryData(data);
	}

	/*
	 * This webservice return IBO Metrics data
	 *  
	 */
	@RequestMapping(method=RequestMethod.POST, value="getIBOMetricsData/{businessSegment}")
	@ResponseBody public FMSIBOMetricsDetailsVO  getIBOMetricsData(@PathVariable("businessSegment") String businessSegment, @RequestBody Map<String, Object> data){
		return objService.getIBOMetricsData(businessSegment,data);
	}

	/*
	 * This webservice return IBO metrics data for drop down fields.
	 *  
	 */
	@RequestMapping(method=RequestMethod.POST, value="getIBOMetricsDropdownsData/{businessSegment}")
	@ResponseBody public FMSIBMetricsDropdownsVO  getIBOMetricsDropdownsData(@PathVariable("businessSegment") String businessSegment,@RequestBody Map<String, Object> data){
		return objService.getIBMetricsDropdownsData(businessSegment,data);
	} 

	/*
	 * This web service is a Batch Job and will delete the data daily and will get the data from SpotFire Oracle DB and will insert into the FMS DB 
	 */
	@RequestMapping(method=RequestMethod.GET, value="getOracleData")
	@ResponseBody public void  getOracleData(){
		objService.getOracleData();
	}

	/*
	 * This web service is a Batch Job and will delete data daily and will get OBP data from Oracle DB and will insert into FMS DB 
	 */
	@RequestMapping(method=RequestMethod.GET, value="getOracleOBPData")
	@ResponseBody public void  getOracleOBPData(){
		objService.getOracleOBPData();
	}

	/*
	 * This web service is a Batch Job and will delete data daily and will get IBAS data from Oracle DB and will insert into FMS DB
	 */
	@RequestMapping(method=RequestMethod.POST, value="getOracleIBASData")
	@ResponseBody public void  getOracleIBASData(@RequestBody Map<String,Object> filterData){
		log.info("inside getOracleIBASData() cntrllr");
		objService.getOracleIBASData(filterData);
	}

	/*
	 * This web service is a Batch Job and will delete data daily and will get DM data from Oracle DB and will insert into FMS DB 
	 */
	@RequestMapping(method=RequestMethod.GET, value="getOracleDMData")
	@ResponseBody public void  getOracleDMData(){
		objService.getOracleDMData();
	}

	/*
	 * This web service is a Batch Job and will delete data daily and will get Outage data from Oracle DB and will insert into FMS DB 
	 */
	@RequestMapping(method=RequestMethod.GET, value="getOracleOutageData")
	@ResponseBody public void  getOracleOutageData(){
		objService.getOracleOutageData();
	}

	@RequestMapping(method=RequestMethod.GET, value="checkmail")
	@ResponseBody public String  checkMail(){
		Utils.sendSummaryComplEmail();
		return "HIIII";
	}

	/*
	 * This webservice return IPM parts column name and data
	 *  
	 */  
	@RequestMapping(method=RequestMethod.POST, value="getIPMPartsData")
	@ResponseBody public Map<String, Object>  getIPMPartsData(@RequestBody Map<String,Object> filterData){
		return objService.getIPMPartsData(filterData);
	}


	/*
	 * This webservice return order data table records.
	 */
		
	@RequestMapping(method=RequestMethod.POST, value="getOrderDataWithFilter", consumes="application/json")
	@ResponseBody public List<Map<String, Object>> getOrderDataWithFilter(@RequestBody Map<String, Object> data){
		return objService.getOrderDataWithFilter(data);
	}

	/*
	 * This service will download excel for order data.
	 *CURRENTLY NOT IN USE. NEED TO DELETE
	 */
	@RequestMapping(method=RequestMethod.POST,value="exportOrderData",consumes="application/json")
	@ResponseBody public void exportOrderData(HttpServletResponse response) throws IOException, ParseException {

		List<Map<String,Object>> partsData= objService.getOrderExportData();
		SXSSFWorkbook workbook = new SXSSFWorkbook(100);
		Sheet sheet = workbook.createSheet("Order Data");

		List<String> headerList = new ArrayList<>();
		Font headerFont = setFont(workbook,FMSVariableConstants.HEADER);
		Font dataFont = setFont(workbook,FMSVariableConstants.DATA);
		CellStyle headerStyle = setStyle(workbook, FMSVariableConstants.HEADER);
		CellStyle dateStyle = setStyle(workbook,FMSVariableConstants.DATE);
		CellStyle dataStyle = setStyle(workbook, FMSVariableConstants.DATA);


		Row row = sheet.createRow(0);
		int cellNo = 0;
		for(String key:partsData.get(0).keySet()){
			headerList.add(key);
		}
		for (String header : headerList) {
			Cell cell = row.createCell(cellNo);
			headerStyle.setFont(headerFont);
			cell.setCellValue(header);
			cell.setCellStyle(headerStyle);
			cellNo++;
		}
		int currRow = 0;
		for(Map<String,Object> record: partsData){
			dataStyle.setFont(dataFont);
			dataStyle.setFont(dataFont);
			currRow++;
			row = sheet.createRow(currRow);
			cellNo = 0;
			for (Iterator<Entry<String, Object>> iterator = record.entrySet()
					.iterator(); iterator.hasNext();) {
				Entry<String, Object> entry = iterator.next();
				cellSet(FMSVariableConstants.STRING,dateStyle,dataStyle,row,cellNo++,Utils.getValidation(entry.getValue()));
			}
		}
		Utils.downloadFile("Order-Data.xlsx", workbook, response);
	}

	/*
	 * Provide dropdown data for ipm 
	 */
	@RequestMapping(method=RequestMethod.POST, value="getIPMDropdownData")
	@ResponseBody public Map<String,List<String>>  getIPMDropdownData(@RequestBody Map<String,Object> filterData){
		return objService.getIPMDropdownData(filterData);
	}


	/*
	 * Retrieve IPM Key Deal/Risk/Opps data 
	 */
	@RequestMapping(method=RequestMethod.POST, value="getIPMData/{ServiceType}")
	@ResponseBody public Map<String, Object>  getIPMData(@PathVariable("ServiceType") String type,@RequestBody Map<String,Object> filterData){
		return objService.getIPMData(filterData,type);
	}

	/*
	 * This service will download excel for IPM data.
	 */
	@RequestMapping(method=RequestMethod.POST,value="exportIPMData/{ServiceType}")
	@ResponseBody public void exportIPMData(@PathVariable("ServiceType") String type,@RequestBody Map<String,Object> filterData,HttpServletResponse response) throws IOException, ParseException {

		String fileName=null;
		String headerData=null;
		List<Map<String,Object>> ipmData = null;
		if(("keydeals").equals(type)){
			fileName = "Key-Deals Data.xlsx";
			headerData = "keyDealsData";
		}else if("risks".equals(type)){
			fileName = "Risks Data.xlsx";
			headerData = "risksDealsData";
		}else if("opps".equals(type)){
			fileName = "Opp Data.xlsx";
			headerData = "oppsDealsData";
		}
		ipmData= (List<Map<String, Object>>) objService.getIPMData(filterData,type).get(headerData);
		SXSSFWorkbook workbook = new SXSSFWorkbook(100);
		Sheet sheet = workbook.createSheet("IPM Data");
		int currRow = 0;
		List<String> headerList;

		Font headerFont = setFont(workbook,FMSVariableConstants.HEADER);
		Font dataFont = setFont(workbook,FMSVariableConstants.DATA);
		CellStyle headerStyle = setStyle(workbook, FMSVariableConstants.HEADER);
		CellStyle dateStyle = setStyle(workbook,FMSVariableConstants.DATE);
		CellStyle dataStyle = setStyle(workbook, FMSVariableConstants.DATA);
		Row row = sheet.createRow(0);
		int cellNo = 0;

		headerList = Utils.getIPMsHeadersList();

		if("risks".equalsIgnoreCase(type) || "opps".equalsIgnoreCase(type)){
			headerList.remove("R/O");
		}

		for (String header : headerList) {
			Cell cell = row.createCell(cellNo);
			headerStyle.setFont(headerFont);
			cell.setCellValue(header);
			cell.setCellStyle(headerStyle);
			cellNo++;
		}

		for(Map<String,Object> record: ipmData){
			currRow++;
			dataStyle.setFont(dataFont);
			cellNo = 0;
			dataStyle.setFont(dataFont);
			row = sheet.createRow(currRow);
			if("risks".equalsIgnoreCase(type) || "opps".equalsIgnoreCase(type)){
				record.remove("p_r_by_o");
			}
			record.remove("row_id");
			record.remove("p_keydeals");
			record.remove("p_new_date");
			record.remove("p_exp_fw_revrec_firts_pl");
			record.remove("p_exp_fw_revrec");
			record.remove("p_flow_or_no_flow");
			record.remove("p_sum_sales");
			record.remove("p_financial_basket");
			record.remove("p_operational_basket");
			record.remove("p_status_aging");
			record.remove("box_number");
			record.remove("invoice_number");
			record.remove("parts_status");

			for (Iterator<Entry<String, Object>> iterator = record.entrySet()
					.iterator(); iterator.hasNext();) {
				Entry<String, Object> entry = iterator.next();
				cellSet(FMSVariableConstants.STRING,dateStyle,dataStyle,row,cellNo++,Utils.getValidation(entry.getValue()));
			}
		}
		Utils.downloadFile(fileName, workbook, response);
	}	

	/**
	 * 
	 * IPM Data Entry get data based on business segment.
	 */

	@RequestMapping(method=RequestMethod.POST, value="getIPMDataEntryData")
	@ResponseBody public Map<String, Map<String, Object>>  getIPMDataEntryData(@RequestBody Map<String,Object> filterData){
		return objService.getIPMDataEntryData(filterData);
	}

	/**
	 * 
	 * IPM Data Entry table update.
	 */


	@RequestMapping(method=RequestMethod.POST, value="updateIPMDataEntryData", produces="text/plain")
	@ResponseBody public String updateIPMDataEntryData(@RequestBody Map<String, Map<String, Object>> updatedData){
		return objService.updateIPMDataEntryData(updatedData);
	}

	/**
	 * 
	 * IPM Data Entry walk by bussiness
	 */

	@RequestMapping(method=RequestMethod.POST, value="walkByBusinessData",consumes="application/json")
	@ResponseBody public Map<String,Object>  walkByBusinessData(@RequestBody Map<String,Object> filterData){
		return objService.walkByBusinessData(filterData);
	}

	/**
	 * 
	 * IPM Data Entry walk by region
	 */

	@RequestMapping(method=RequestMethod.POST, value="walkByRegionData",consumes="application/json")
	@ResponseBody public Map<String,Object>  walkByRegionData(@RequestBody Map<String,Object> filterData){
		return objService.walkByBusinessRegion(filterData);
	}

	/**
	 * 
	 *IPM Parts data insert if not exist else update.
	 */

	@RequestMapping(method=RequestMethod.POST, value="updateIPMParts",consumes="application/json", produces="text/plain")
	@ResponseBody public String  updateIPMParts(@RequestBody Map<String,Object> filterData){
		return objService.updateIPMParts(filterData);
	}

	@RequestMapping(method=RequestMethod.GET, value="updateIPMLogicFields") 
	@ResponseBody public String updateIPMLogicFields(){
		return objService.updateIPMLogicFields();
	}

	/**
	 * 
	 * IPM Data Entry walk by product
	 */

	@RequestMapping(method=RequestMethod.POST, value="walkByProduct")
	@ResponseBody public Map<String,Object>  walkByProduct(@RequestBody Map<String,Object> filterData){
		return objService.walkByProduct(filterData);
	}

	/**
	 * 
	 * IPM Data Entry walk by Finance
	 */

	@RequestMapping(method=RequestMethod.POST, value="walkByFinance")
	@ResponseBody public Map<String,Object>  walkByFinance(@RequestBody Map<String,Object> filterData){
		return objService.walkByFinance(filterData);
	}

	/**
	 * 
	 * IPM Data Entry project controller
	 */

	@RequestMapping(method=RequestMethod.POST, value="projectController")
	@ResponseBody public Map<String,Object>  projectController(@RequestBody Map<String,Object> filterData){
		return objService.projectController(filterData);
	}

	@RequestMapping(method=RequestMethod.GET, value="getQuarterYear")
	@ResponseBody public Map<String,Object>  getQuarterYear(){
		return objService.getQuarterYear();
	}

	/*
	 * Provide dropdown data for ipm parts
	 */
	@RequestMapping(method=RequestMethod.POST, value="getIPMPartsDropdownData")
	@ResponseBody public List<String>  getIPMPartsDropdownData(@RequestBody Map<String, Object> filterData){
		return objService.getIPMPartsDropdownData(filterData);
	}


	@RequestMapping(value = "/importCSVToTable", headers = "Content-Type= multipart/form-data",method = RequestMethod.POST, produces="text/plain")
	@Consumes("multipart/form-data")
	@ResponseBody public String importCSVToTable(@RequestParam("file") MultipartFile file, @RequestParam("userSSO") String userSSO) throws IOException{
		return objService.importCSVToTable(file.getInputStream(), file.getOriginalFilename(), userSSO);
	}

	@RequestMapping(value = "/exportCSVFromTable",consumes="application/json",method = RequestMethod.POST)
	@ResponseBody public void exportCSVFromTable(@RequestBody Map<String,Object> filterData,HttpServletResponse responses) throws IOException{
		objService.exportCSVFromTable(responses,filterData);
	}

	@RequestMapping(value = "/exportCSVFromMaster",consumes="application/json", method = RequestMethod.POST)
	@ResponseBody public void exportCSVFromMaster(HttpServletResponse responses) throws IOException{
		objService.exportCSVFromMaster(responses);
	}


	@RequestMapping(method=RequestMethod.POST, value="getDMMetricsData/{businessSegment}")
	@ResponseBody public FMSDMMetricsDetailsDTO  getDMMetricsData(@PathVariable("businessSegment") String businessSegment, @RequestBody Map<String, Object> data){
		return objService.getDMMetricsData(businessSegment,data);
	}

	@RequestMapping(method=RequestMethod.POST, value="getDMMetricsDropdown/{businessSegment}")
	@ResponseBody public Map<String,Object>  getDMMetricsDropdown(@PathVariable("businessSegment") String businessSegment, @RequestBody Map<String, Object> data){
		return objService.getDMMetricsDropdown(businessSegment,data);
	}

/**	@RequestMapping(method=RequestMethod.POST, value="getDMMetricsFilterData/{ServiceType}", consumes="application/json")
	@ResponseBody public FMSDMMetricsDetailsDTO  getDMMetricsFilterData(@PathVariable("ServiceType") String type, @RequestBody String data){

		//		FMSDMMetricsDetailsDTO result = null;
		//		FMSDMMetricsDataBean dmMetricsDataBean = new FMSDMMetricsDataBean();
		//		try
		//		{
		//			JSONParser parse = new JSONParser();
		//			JSONObject jObj = (JSONObject) parse.parse(data);
		//			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);
		//			JSONObject jObj1 = (JSONObject)jArr.get(0); 
		//			dmMetricsDataBean.setDmPrimaryRegion(Utils.nullCheck(jObj1.get("primaryRegion")));
		//			dmMetricsDataBean.setDmForecastCategory(Utils.nullCheck(jObj1.get("forecastCategory")));
		//			dmMetricsDataBean.setDmBusinessTier3(Utils.nullCheck(jObj1.get("businessTier3")));
		//			dmMetricsDataBean.setDmPrimaryCountry(Utils.nullCheck(jObj1.get("primaryCountry")));
		//			dmMetricsDataBean.setDmcQtr(Utils.nullCheck(jObj1.get("cQtr")));
		//			dmMetricsDataBean.setDmAccountName(Utils.nullCheck(jObj1.get("accountName")));
		//			dmMetricsDataBean.setDmRiskPath(Utils.nullCheck(jObj1.get("riskPath")));
		//			dmMetricsDataBean.setDmAccountClass(Utils.nullCheck(jObj1.get("accountClass")));
		//			dmMetricsDataBean.setDmAccountType(Utils.nullCheck(jObj1.get(FMSVariableConstants.ACCOUNTTYPE)));
		//			result= objService.getDMMetricsFilterData(dmMetricsDataBean,type);
		//
		//		}catch(Exception e){
		//			log.info(FMSVariableConstants.EXCEPTION+e);
		//			log.error(FMSVariableConstants.PRINTSTACKTRACE + e.getStackTrace());
		//		}

		return null;
	}*/

	@RequestMapping(method=RequestMethod.POST, value="getDMCountry")
	@Consumes({"application/json"})
	@ResponseBody public List<FMSCountryNameDropdownBean>  getDMCountry(@RequestBody Map<String, Object> data ){
		/*String regionName="";
		String param="";
		String businessSegment = "";
		try
		{
			JSONParser parse = new JSONParser();
			JSONObject jObj = (JSONObject) parse.parse(data);
			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);
			JSONObject jObj1 = (JSONObject)jArr.get(0); 
			regionName=Utils.nullCheck(params.get("regionName"));
			param=Utils.nullCheck(params.get("param"));
			businessSegment=Utils.nullCheck(params.get("businessSegment"));

		}catch(Exception e){
			log.info("exception in getDMCountry().."+e);
		}*/
		return objService.getDMCountry(data);
	}

	/*
	 * Excel upload for Order Mapping
	 */
	@RequestMapping(value = "/orderMappingExcelUpload", headers = "Content-Type= multipart/form-data",method = RequestMethod.POST, produces="text/plain")
	@Consumes({"multipart/form-data","application/json"})
	@ResponseBody public String orderMappingExcelUpload(@RequestParam("file") MultipartFile file,@RequestParam("mappingParam") String mappingParam, @RequestParam("userSSO") String userSSO, @RequestParam("businessSegment") String businessSegment, @RequestParam("marketIndustry") String marketIndustry) throws IOException {
		String status = null;
		if (file != null) {
			try {
				if(mappingParam.equalsIgnoreCase("OrderCsvData")){
					status = objService.importCSVToOrder(file.getInputStream(),file.getOriginalFilename(), userSSO, businessSegment,marketIndustry);
				} else if(mappingParam.equalsIgnoreCase("RevenueUpdate")) {
					status =  objService.importCSVToSalesData(file.getInputStream(), businessSegment,marketIndustry);
				} else {
					status =  objService.mappingXlsToDao(file.getInputStream(),mappingParam);
				}
			} catch (Exception e) {}
		}
		return status;

	}	

	
	@RequestMapping(method=RequestMethod.POST, value="getDMData", consumes="application/json")
	@ResponseBody public List<FMSDMDataBean>  getDMData(@RequestBody Map<String, Object> data){
		return objService.getDMData(data);
	}


	@RequestMapping(method=RequestMethod.POST, value="getServiceReqData", consumes="application/json")
	@ResponseBody public List<FMSServiceReqDataBean>  getServiceReqData(@RequestBody String data){
		List<FMSServiceReqDataBean> response = new ArrayList<>();	    	
		JSONParser parse = new JSONParser();
		JSONObject jObj;
		try {
			jObj = (JSONObject) parse.parse(data);

			String input = jObj.get("data").toString();
			log.info(input);
			response=objService.getServiceReqData(input);
		} catch (ParseException e) {
			log.info(FMSVariableConstants.EXCEPTION+e);
			log.error(FMSVariableConstants.PRINTSTACKTRACE + e.getStackTrace());
		}

		return response;

	}


	@RequestMapping(method=RequestMethod.POST,value="exportDMData",consumes="application/json")
	@ResponseBody public void exportDMData(HttpServletResponse response,@RequestBody Map<String, Object> data) throws IOException, ParseException {

		List<FMSDMDataBean> dmDataLst = objService.getDMData(data);

		SXSSFWorkbook workbook = new SXSSFWorkbook(100);
		Sheet sheet = workbook.createSheet("DM Data");

		Font headerFont = setFont(workbook,FMSVariableConstants.HEADER);
		Font dataFont = setFont(workbook,FMSVariableConstants.DATA);

		CellStyle headerStyle = setStyle(workbook, FMSVariableConstants.HEADER);
		CellStyle dateStyle = setStyle(workbook,FMSVariableConstants.DATE);
		CellStyle dataStyle = setStyle(workbook, FMSVariableConstants.DATA);


		Row row = sheet.createRow(0);
		int cellNo = 0;
		List<String> headerList = Utils.getDMDataHeaderList();

		for (String header : headerList) {
			Cell cell = row.createCell(cellNo);
			headerStyle.setFont(headerFont);
			cell.setCellStyle(headerStyle);
			cell.setCellValue(header);
			cellNo++;
		}

		int rowNo = 1;

		for(FMSDMDataBean dmData: dmDataLst)
		{
			row = sheet.createRow(rowNo++);
			dataStyle.setFont(dataFont);
			cellNo = 0;
			dataStyle.setFont(dataFont);	

			cellSet(FMSVariableConstants.STRING,dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getOpptyId()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getProjectNumber()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getPrimarySalesName()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getPrimaryRegion()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getPrimaryCountry()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getForecastCategory()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getBusinessTier3()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getEndUserAccountName()));
			cellSet(FMSVariableConstants.INTEGER, dateStyle, dataStyle, row, cellNo++,Utils.getIntegerValidation(dmData.getExpectedOrderYear()));
			cellSet(FMSVariableConstants.INTEGER, dateStyle, dataStyle, row, cellNo++,Utils.getIntegerValidation(dmData.getExpectedOrderQuarter()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getOpptySalesStage()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getRecordTypeId()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getOpptyNo()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getOpptyName()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getLastSalesStageChanged()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getExpectedOrderDate()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getPrimaryIndustry()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getProjectName()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getConvertibleThisQtr()));
			cellSet(FMSVariableConstants.INTEGER, dateStyle, dataStyle, row, cellNo++,Utils.getIntegerValidation(dmData.getOpptyAmountUsd()));
			cellSet(FMSVariableConstants.INTEGER, dateStyle, dataStyle, row, cellNo++,Utils.getIntegerValidation(dmData.getOpptyCmUsd()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getPrimarySalesId()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getIsComopsNeeded()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getCommAccountName()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getEndUserAccountDuns()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getDealRiskPath()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getDealRiskLevel()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getDealQuoteType()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getRfqReceivedDate()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getBidDueDate()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getExpectedDeliveryDate()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getBidSentDate()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getDispPrimaryReason()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getGlobalAccountClass()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getGlobalAccountType()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getRepBusinessTier3()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getRepBusinessTier4()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getRepBizAbbrTier4()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getProjectFlowType()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getCreatedByName()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getCreatedDate()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getStaleDealIndicator()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getDealBudgetaryType()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(dmData.getDealUnsolicitedType()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo,Utils.getValidation(dmData.getOpptyExternalId()));

		}	

		try
		{
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbook.write(bos);
			bos.close();
			byte[] bytes = bos.toByteArray();
			response.setHeader(FMSVariableConstants.CONTENTDISPOSITION ,"attachment; filename=DM Data.xlsx");
			response.getOutputStream().write(bytes);
			response.flushBuffer();
		}
		catch(IOException e)
		{
			log.info(FMSVariableConstants.EXCEPTION+e);
			log.error(FMSVariableConstants.PRINTSTACKTRACE + e.getStackTrace());
		}

	}

	/*
	 * Retrieve PMO Chart Data 
	 */
	@RequestMapping(method=RequestMethod.POST, value="getPMOChartData")
	@ResponseBody public Map<String, Object>  getPMOChartData(@RequestBody Map<String,Object> filterData){
		return objService.getPMOChartData(filterData);
	}

	/*
	 * Retrieve PMO Chart details data 
	 */	   
	@RequestMapping(method=RequestMethod.POST, value="getPMOChartDetailsData")
	@ResponseBody public Map<String, Object>  getPMOChartDetailsData(@RequestBody Map<String,Object> filterData){
		return objService.getPMOChartDetailsData(filterData);
	}

	/*
	 * Export PMO Drill down data
	 */
	@RequestMapping(value = "/exportPMODrilDownData",consumes="application/json", method = RequestMethod.POST)
	@ResponseBody public void exportPMODrilDownData(@RequestBody Map<String,Object> filterData,HttpServletResponse responses) throws IOException{
		objService.exportPMODrilDownData(responses, filterData);
	}

	@RequestMapping(method=RequestMethod.GET, value="getChooseColumns")
	@ResponseBody public Map<String,Object> getChooseColumns(){
		return objService.getChooseColumns();
	} 

	@RequestMapping(method=RequestMethod.POST, value="getDMNewMetricsFilterData/{ServiceType}", consumes="application/json")
	@ResponseBody public Object getDMNewMetricsFilterData(@PathVariable("ServiceType") String type, @RequestBody String data){

		FMSDMFilterDataBean filterData = new FMSDMFilterDataBean();
		try
		{
			JSONParser parse = new JSONParser();
			JSONObject jObj = (JSONObject) parse.parse(data);
			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);
			JSONObject jObj1 = (JSONObject)jArr.get(0); 

			String yearQtr = Utils.nullCheck(jObj1.get(FMSVariableConstants.YEAR));
			if(!yearQtr.isEmpty() && yearQtr !=""){
				String yearQtrSep[] = yearQtr.split("\\|");
				Set<String> year = new HashSet<String>();
				Set<String> qtr = new HashSet<String>();
				for(int i=0; i < yearQtrSep.length; i++){
					year.add(yearQtrSep[i].split("\\-")[0]+"$");
					qtr.add("^"+yearQtrSep[i].split("\\-")[1]);
				}
				filterData.setFdYear(String.join("|", year));
				filterData.setFdQuarter(String.join("|", qtr));
			}

			filterData.setFdPrimaryRegion(Utils.nullCheck(jObj1.get("primaryRegion")));
			filterData.setFdForecastCategory(Utils.nullCheck(jObj1.get("forecastCategory")));
			filterData.setFdBusinessTier3(Utils.nullCheck(jObj1.get("businessTier3")));
			filterData.setFdPrimaryCountry(Utils.nullCheck(jObj1.get("primaryCountry")));
			filterData.setFdcQtr(Utils.nullCheck(jObj1.get("cQtr")));
			filterData.setFdAccountName(Utils.nullCheck(jObj1.get("accountName")));
			filterData.setFdRiskPath(Utils.nullCheck(jObj1.get("riskPath")));
			filterData.setFdAccountClass(Utils.nullCheck(jObj1.get("accountClass")));
			filterData.setFdAccountType(Utils.nullCheck(jObj1.get(FMSVariableConstants.ACCOUNTTYPE)));
			filterData.setOpptySalesStage(Utils.nullCheck(jObj1.get("stage")));
			filterData.setFdopptyExternalId(Utils.nullCheck(jObj1.get("opptyExternalId")));
			filterData.setBusinessSegment(Utils.nullCheck(jObj1.get(FMSVariableConstants.BUSINESS_SEG)));
			filterData.setDmAccountManager(Utils.nullCheck(jObj1.get(FMSVariableConstants.ACC_MGR)));
			filterData.setDmMarketIndustry(Utils.nullCheck(jObj1.get(FMSVariableConstants.MARKET_INDUSTRY)));

			if (type.equalsIgnoreCase(FMSVariableConstants.DMDATA)) {
				return objService.getDMMetricsFilterData(filterData);
			} else if (type.equalsIgnoreCase(FMSVariableConstants.DMCOUNTRY)) {
				return objService.getDMFilterDataCountry(filterData);
			}
		}
		catch(Exception e){
			log.info(FMSVariableConstants.EXCEPTION+e);
			log.error(FMSVariableConstants.PRINTSTACKTRACE + e.getStackTrace());
		}
		return null;
	}


	@RequestMapping(method=RequestMethod.POST, value="getOutageMetricsData")
	@ResponseBody public FMSOutageMetricsDetailsDTO  getOutageMetricsData(@RequestBody Map<String, Object> data){
		return objService.getOutageMetricsData(data);
	}


	@RequestMapping(method=RequestMethod.POST, value="getOutageData", consumes="application/json")
	@ResponseBody public List<FMSOutageDataBean>  getOutageData(@RequestBody Map<String, Object> data){
		return objService.getOutageData(data);
		}

	@RequestMapping(method=RequestMethod.POST, value="getOutageDropdown")
	@ResponseBody public FMSOutageDropdownDTO  getOutageDropdown(@RequestBody Map<String, Object> data){
		return objService.getOutageDropdown(data);
	}

	@RequestMapping(method=RequestMethod.POST, value="getOutageMetricsFilterData/{ServiceType}", consumes="application/json")
	@ResponseBody public Object getOutageMetricsFilterData(@PathVariable("ServiceType") String type, @RequestBody String data){

		FMSOutageFilterDataDTO filterData = new FMSOutageFilterDataDTO();
		try
		{
			JSONParser parse = new JSONParser();
			JSONObject jObj = (JSONObject) parse.parse(data);
			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);
			JSONObject jObj1 = (JSONObject)jArr.get(0); 

			String yearQtr = Utils.nullCheck(jObj1.get(FMSVariableConstants.YEAR));
			if(!yearQtr.isEmpty() && yearQtr !=""){
				String yearQtrSep[] = yearQtr.split("\\|");
				Set<String> year = new HashSet<String>();
				Set<String> qtr = new HashSet<String>();
				for(int i=0; i < yearQtrSep.length; i++){
					year.add(yearQtrSep[i].split("\\-")[0]+"$");
					qtr.add("^"+yearQtrSep[i].split("\\-")[1]);
				}
				filterData.setOutageYear(String.join("|", year));
				filterData.setOutageQuarter(String.join("|", qtr));
			}
			filterData.setOutageCustomerName(Utils.nullCheck(jObj1.get("customerName")));
			filterData.setOutageTechnology(Utils.nullCheck(jObj1.get("technology")));
			filterData.setOutageEquipment(Utils.nullCheck(jObj1.get("equipment")));
			filterData.setOutageLocation(Utils.nullCheck(jObj1.get("location")));
			filterData.setOutageUnitStatus(Utils.nullCheck(jObj1.get("unitStatus")));
			filterData.setOutageSegment(Utils.nullCheck(jObj1.get("segment")));
			filterData.setOutageServiceRel(Utils.nullCheck(jObj1.get("serviceRel")));
			filterData.setOutageRegion(Utils.nullCheck(jObj1.get("region")));
			filterData.setOutageCountry(Utils.nullCheck(jObj1.get("country")));
			filterData.setOutageDunsName(Utils.nullCheck(jObj1.get("dunsName")));  
			filterData.setOutageAccMgrEmail(Utils.nullCheck(jObj1.get("accMgrEmail")));
			filterData.setOutageServiceMgrEmail(Utils.nullCheck(jObj1.get("serviceMgrEmail")));
			filterData.setOutageMaintLvlDesc(Utils.nullCheck(jObj1.get("maintLvlDesc")));
			filterData.setOutageEvntStatusDesc(Utils.nullCheck(jObj1.get("eventStatusDesc")));
			filterData.setOutageAccountManager(Utils.nullCheck(jObj1.get(FMSVariableConstants.ACC_MGR)));
			if (type.equalsIgnoreCase(FMSVariableConstants.OUTAGEDATA)) {
				return objService.getOutageFilterDataRegion(filterData);
			} else if (type.equalsIgnoreCase(FMSVariableConstants.OUTAGECOUNTRY)) {
				return objService.getOutageFilterDataCountry(filterData);
			}
		}
		catch(Exception e){
			log.info(FMSVariableConstants.EXCEPTION+e);
			log.error("Error message in getOutageMetricsFilterData " + e.getStackTrace());
		}
		return null;
	}

	@RequestMapping(method=RequestMethod.POST,value="exportOutageData",consumes="application/json")
	@ResponseBody public void exportOutageData(HttpServletResponse response,@RequestBody Map<String, Object> data) throws IOException, ParseException {

		List<FMSOutageDataBean> outageDataLst = objService.getOutageData(data);

		SXSSFWorkbook workbook = new SXSSFWorkbook(100);
		Sheet sheet = workbook.createSheet("Outage Data");

		Font headerFont = setFont(workbook,FMSVariableConstants.HEADER);
		Font dataFont = setFont(workbook,FMSVariableConstants.DATA);

		CellStyle headerStyle = setStyle(workbook, FMSVariableConstants.HEADER);
		CellStyle dateStyle = setStyle(workbook,FMSVariableConstants.DATE);
		CellStyle dataStyle = setStyle(workbook, FMSVariableConstants.DATA);


		Row row = sheet.createRow(0);
		int cellNo = 0;
		List<String> headerList = Utils.getOutageDataHeaderList();

		for (String header : headerList) {
			Cell cell = row.createCell(cellNo);
			headerStyle.setFont(headerFont);
			cell.setCellStyle(headerStyle);
			cell.setCellValue(header);
			cellNo++;
		}

		int rowNo = 1;

		for(FMSOutageDataBean outageData: outageDataLst)
		{
			row = sheet.createRow(rowNo++);
			dataStyle.setFont(dataFont);
			cellNo = 0;
			dataStyle.setFont(dataFont);	

			cellSet(FMSVariableConstants.INTEGER,dateStyle, dataStyle, row, cellNo++,Utils.getIntegerValidation (outageData.getnEventId()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcGibSerialNumber()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcServiceMgrEmail()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getdEventDate()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcOgSalesRegion()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcSiteCustomerCountry()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcUnitStatusDesc()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcServiceRelationDescOg()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcTechnologyDescOg()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcEquipmentDesc()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcMarketSegmentDesc()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcSiteCustomerName()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcOemLocationDesc()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getGeDunsName()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getEventYear()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getEventQuarter()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getCeventStatus()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcMaintLvlDesc()));
			cellSet(FMSVariableConstants.INTEGER, dateStyle, dataStyle, row, cellNo++,Utils.getIntegerValidation(outageData.getnMaintPolicyCyc()));
			cellSet(FMSVariableConstants.INTEGER, dateStyle, dataStyle, row, cellNo++,Utils.getIntegerValidation(outageData.getnMaintLevelSeq()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.gettEventNotes()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcDemSvcsStatus()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcUsrIns()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row,cellNo++,Utils.getValidation(outageData.getdIns()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcEventDemStatusParts()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcEventDemStatusSvcs()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getCeventDemStatusRepairs()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getfUnsolicedStatusFlag()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getdEstServiceStartDate()));
			cellSet(FMSVariableConstants.DOUBLE, dateStyle, dataStyle, row, cellNo++,Utils.getNumericValidation(outageData.getnEstServHoursCount()));
			cellSet(FMSVariableConstants.INTEGER, dateStyle, dataStyle, row, cellNo++,Utils.getIntegerValidation(outageData.getnMaintYear()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcCustLoyaltyDescParts()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcCustBehaviorDescParts()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcSiteCustomerDuns()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcSiteNameAlias()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcSiteCustomerCity()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcTechnologyDesc()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcEngProjectRef()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getdUnitShipDate()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getdUnitCodDate()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcAccountMgrEmail()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(outageData.getcMainLvlCod()));

		}	

		try
		{
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbook.write(bos);
			bos.close();
			byte[] bytes = bos.toByteArray();
			response.setHeader(FMSVariableConstants.CONTENTDISPOSITION ,"attachment; filename=Outage Data.xlsx");
			response.getOutputStream().write(bytes);
			response.flushBuffer();
		}
		catch(IOException e)
		{
			log.info(FMSVariableConstants.EXCEPTION+e);
			log.error(FMSVariableConstants.PRINTSTACKTRACE + e.getStackTrace());
		}

	}


	@RequestMapping(method=RequestMethod.POST,value="exportServiceReqData",consumes="application/json")
	@ResponseBody public void exportServiceReqData(HttpServletResponse response,@RequestBody String data) throws IOException, ParseException {

		List<FMSServiceReqDataBean> serviceReqDataLst = objService.getServiceReqData(data);

		SXSSFWorkbook workbook = new SXSSFWorkbook(100);
		Sheet sheet = workbook.createSheet("Service Request Data");

		Font headerFont = setFont(workbook,FMSVariableConstants.HEADER);
		Font dataFont = setFont(workbook,FMSVariableConstants.DATA);

		CellStyle headerStyle = setStyle(workbook, FMSVariableConstants.HEADER);
		CellStyle dateStyle = setStyle(workbook,FMSVariableConstants.DATE);
		CellStyle dataStyle = setStyle(workbook, FMSVariableConstants.DATA);


		Row row = sheet.createRow(0);
		int cellNo = 0;
		List<String> headerList = Utils.getServiceReqDataHeaderList();

		for (String header : headerList) {
			Cell cell = row.createCell(cellNo);
			headerStyle.setFont(headerFont);
			cell.setCellStyle(headerStyle);
			cell.setCellValue(header);
			cellNo++;
		}

		int rowNo = 1;

		for(FMSServiceReqDataBean serviceReqData: serviceReqDataLst)
		{
			row = sheet.createRow(rowNo++);
			dataStyle.setFont(dataFont);
			cellNo = 0;
			dataStyle.setFont(dataFont);	

			cellSet(FMSVariableConstants.STRING,dateStyle, dataStyle, row, cellNo++,Utils.getValidation (serviceReqData.getCaseNo()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getCurrentTypeofIssue()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getAssignedGroup()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getState()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getOpened()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getProjectPhase()));	
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getStatus()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getJobType()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getCustomerName()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getMachineTechOg()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getsEventYear()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getsEventQuarter()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getOriginalTypeofIssue()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getIssueEventDate()));	
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getCustAddReq()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row,cellNo++,Utils.getValidation(serviceReqData.getSuggByRedFlgReview()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getRcaReqByCust()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getEhsImpact()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getCategory()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getCurStaLastinActDate()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getEntryInCurStatus()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getAsRunningLastInDate()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getAsRunningLastOutDate()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getTechSoluType()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getSwTeamNeeded()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getJobTypeDetails()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getBusiness()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getExpectedResolDate()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getMachineType()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getMachineTechnology()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getControlPanelType()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getCod()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getCostingProjectCharged()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getProjectManager()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getInstaManagerCoordinator()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getProblemDesc()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getCin()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getAssignedFun()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getActVsSupMateSol()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getSupplierNameMateSol()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getSolDesc()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getAsRunningNeeded()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getMateNeeded()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getSupplierResp()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getWfcaTimeInvalid()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getWfcaTimeInSol()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getWfcaTimeInFulfSp()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getWfcaTimeInImple()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getWfcaTimeInAsBuilt()));
			cellSet(FMSVariableConstants.STRING, dateStyle, dataStyle, row, cellNo++,Utils.getValidation(serviceReqData.getWfcaTimeInExpertAss()));
		}	

		try
		{
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbook.write(bos);
			bos.close();
			byte[] bytes = bos.toByteArray();
			response.setHeader(FMSVariableConstants.CONTENTDISPOSITION ,"attachment; filename=ServiceRequest Data.xlsx");
			response.getOutputStream().write(bytes);
			response.flushBuffer();
		}
		catch(IOException e)
		{
			log.info(FMSVariableConstants.EXCEPTION+e);
			log.error(FMSVariableConstants.PRINTSTACKTRACE + e.getStackTrace());
		}

	}

	@RequestMapping(method=RequestMethod.GET, value="getOracleServiceRequestData")
	@ResponseBody public void  getOracleServiceRequestData(){
		log.info("inside FMSController of getOracleServiceRequestData()");
		objService.getOracleServiceRequestData();
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(method=RequestMethod.POST, value="getServiceReqMetricsFilterData", consumes="application/json")
	@ResponseBody public Map<String,Object> getServiceReqMetricsFilterData(@RequestBody String data){
		Map<String,Object> result = new HashMap<>();
		try{
			JSONParser parse = new JSONParser();
			JSONObject jObj = (JSONObject) parse.parse(data);
			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);
			JSONObject jObj1 = (JSONObject)jArr.get(0);

			Map<String,Object> filterData = new HashMap<>();

			String yearQtr = Utils.nullCheck(jObj1.get(FMSVariableConstants.YEAR));
			if(!yearQtr.isEmpty() && yearQtr !=""){
				String yearQtrSep[] = yearQtr.split("\\|");
				Set<String> year = new HashSet<String>();
				Set<String> qtr = new HashSet<String>();
				for(int i=0; i < yearQtrSep.length; i++){
					year.add(yearQtrSep[i].split("\\-")[0]+"$");
					qtr.add("^"+yearQtrSep[i].split("\\-")[1]);
				}
				filterData.put("event_year",String.join("|", year));
				filterData.put("event_quarter", String.join("|", qtr));
			}

			filterData.put("case_number", Utils.nullCheck(jObj1.get("case_number")));
			filterData.put("opened", Utils.nullCheck(jObj1.get("opened")));
			filterData.put("current_type_of_issue", Utils.nullCheck(jObj1.get("current_type_of_issue")));
			filterData.put("project_phase", Utils.nullCheck(jObj1.get("project_phase")));
			filterData.put("state", Utils.nullCheck(jObj1.get("state")));
			filterData.put("assigned_group", Utils.nullCheck(jObj1.get("assigned_group")));
			filterData.put("status", Utils.nullCheck(jObj1.get("status")));
			filterData.put("entry_in_the_cur_status", Utils.nullCheck(jObj1.get("entry_in_the_cur_status")));
			filterData.put("job_type", Utils.nullCheck(jObj1.get("job_type")));
			filterData.put("customer_name", Utils.nullCheck(jObj1.get("customer_name")));
			filterData.put("machine_technology_og", Utils.nullCheck(jObj1.get("machine_technology_og")));
			filterData.put(FMSVariableConstants.ACC_MGR, Utils.nullCheck(jObj1.get(FMSVariableConstants.ACC_MGR)));
			result =  objService.getServiceReqMetricsFilterData(filterData);
		} catch(Exception e){
			log.info("Exception in getServiceReqMetricsFilterData() :"+e.getMessage() );
			result.put("exceptionMessage", e.getMessage());
		}
		return result;
	}

	@RequestMapping(method=RequestMethod.POST, value="getServiceRequestMetricsData")
	@ResponseBody public Map<String, Object>  getServiceRequestMetricsData(/**@RequestBody Map<String, Object> data*/){
		Map<String, Object> data = new HashMap<>();
		return objService.getServiceRequestMetricsData(data);
	}

	@RequestMapping(method=RequestMethod.POST, value="getServiceRequestDropdown")
	@ResponseBody public Map<String, Object>  getServiceRequestDropdown(){
		return objService.getServiceRequestDropdown();
	}

	@RequestMapping(method=RequestMethod.POST, value="authorizeUser", consumes="application/json")
	@ResponseBody public List<FMSUserBean>  authorizeUser (@RequestBody String data){
		JSONParser parse = new JSONParser();
		List<FMSUserBean> userInfo = null;
		JSONObject jObj;
		try {
			jObj = (JSONObject) parse.parse(data);
			String userId = jObj.get(FMSVariableConstants.DATA).toString();
			userInfo = objService.authorizeUser(userId);
		} catch (ParseException e) {
			log.info(e);
		}
		return userInfo;
	}

	@RequestMapping(method=RequestMethod.POST, value="getCombinedAnalysisDropdownData")
	@ResponseBody public Map<String,Object>  getCombinedAnalysisDropdownData(@RequestBody Map<String,Object> data){
		return objService.getCombinedAnalysisDropdownData(data); 
	}

	@RequestMapping(method=RequestMethod.POST, value="getCombinedAnalysisMetrics")
	@ResponseBody public Map<String, Object>  getCombinedAnalysisMetrics(@RequestBody String data){
		Map<String, Object> result = new HashMap<>();
		try{
			JSONParser parse = new JSONParser();
			JSONObject jObj = (JSONObject) parse.parse(data);
			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);
			JSONObject jObj1 = (JSONObject)jArr.get(0);

			Map<String,Object> filterData = new HashMap<>();
			if(!jObj1.isEmpty()){
				filterData.put("technologyDescription", Utils.nullCheck(jObj1.get("technologyDescription")));
				filterData.put("regionDescription", Utils.nullCheck(jObj1.get("regionDescription")));
				filterData.put("countryDescription", Utils.nullCheck(jObj1.get("countryDescription")));
				filterData.put("siteCustomerDescription", Utils.nullCheck(jObj1.get("siteCustomerDescription")));
				filterData.put("geDunsName", Utils.nullCheck(jObj1.get("geDunsName")));
				filterData.put("segment", Utils.nullCheck(jObj1.get("segment")));
				filterData.put("tier3", Utils.nullCheck(jObj1.get("tier3")));
				filterData.put("serialNumber", Utils.nullCheck(jObj1.get("serialNumber")));
				filterData.put(FMSVariableConstants.YEAR_QTR, Utils.nullCheck(jObj1.get(FMSVariableConstants.YEAR_QTR)));
				filterData.put(FMSVariableConstants.BUSINESS_SEG, Utils.nullCheck(jObj1.get(FMSVariableConstants.BUSINESS_SEG)));
				filterData.put(FMSVariableConstants.MARKET_INDUSTRY, Utils.nullCheck(jObj1.get(FMSVariableConstants.MARKET_INDUSTRY)));
				filterData.put(FMSVariableConstants.ACC_MGR, Utils.nullCheck(jObj1.get(FMSVariableConstants.ACC_MGR)));
				
			}
			result = objService.getCombinedAnalysisMetrics(filterData);

		} catch(Exception e){
			log.info("Exception in getCombinedAnalysisMetrics() : "+e.getStackTrace());
		}

		return result; 
	}

	@RequestMapping(method=RequestMethod.POST, value="exportCombinedAnalytics/{metrics}")
	@ResponseBody public void  exportCombinedAnalytics(@PathVariable("metrics") String metrics
			,HttpServletResponse response,@RequestBody String data) throws ParseException{
		Map<String,Object> filterData = new HashMap<>();
		try{
			JSONParser parse = new JSONParser();
			JSONObject jObj = (JSONObject) parse.parse(data);
			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);
			JSONObject jObj1 = (JSONObject)jArr.get(0);

			filterData.put("technologyDescription", Utils.nullCheck(jObj1.get("technologyDescription")));
			filterData.put("regionDescription", Utils.nullCheck(jObj1.get("regionDescription")));
			filterData.put("countryDescription", Utils.nullCheck(jObj1.get("countryDescription")));
			filterData.put("siteCustomerDescription", Utils.nullCheck(jObj1.get("siteCustomerDescription")));
			filterData.put("geDunsName", Utils.nullCheck(jObj1.get("geDunsName")));
			filterData.put("segment", Utils.nullCheck(jObj1.get("segment")));
			filterData.put("tier3", Utils.nullCheck(jObj1.get("tier3")));
			filterData.put("serialNumber", Utils.nullCheck(jObj1.get("serialNumber")));
			filterData.put(FMSVariableConstants.YEAR_QTR, Utils.nullCheck(jObj1.get(FMSVariableConstants.YEAR_QTR)));
			filterData.put(FMSVariableConstants.BUSINESS_SEG, Utils.nullCheck(jObj1.get(FMSVariableConstants.BUSINESS_SEG)));
			filterData.put(FMSVariableConstants.MARKET_INDUSTRY, Utils.nullCheck(jObj1.get(FMSVariableConstants.MARKET_INDUSTRY)));
			filterData.put(FMSVariableConstants.ACC_MGR, Utils.nullCheck(jObj1.get(FMSVariableConstants.ACC_MGR)));
			
			List<Map<String,Object>> tableData = objService.exportCombinedAnalytics(filterData,metrics);
			List<String> headerList = null;
			String fileName = "";

			if(metrics.equalsIgnoreCase(FMSVariableConstants.IB_EXP)){
				fileName = "IB/IBO data.xlsx";
				headerList = Utils.getIBHeadersList();
			}else if(metrics.equalsIgnoreCase(FMSVariableConstants.ORDERS_EXP)){
				fileName = "Orders data.xlsx";
				headerList = Utils.getOrdersHeadersList();
			}else if(metrics.equalsIgnoreCase(FMSVariableConstants.DM_EXP)){
				fileName = "DM data.xlsx";
				headerList = Utils.getDMHeadersList();
			}else if(metrics.equalsIgnoreCase(FMSVariableConstants.OUTAGES_EXP)){
				fileName = "Outages data.xlsx";
				headerList = Utils.getOutagesHeadersList();
			}else if(metrics.equalsIgnoreCase(FMSVariableConstants.SERVICE_REQUEST_EXP)){
				fileName = "Service Request data.xlsx";
				headerList = Utils.getServiceRequestHeadersList();
			}
			SXSSFWorkbook workbook = new SXSSFWorkbook(100);
			Sheet sheet = workbook.createSheet("Combined Analytics Data");
			int currRow = 0;

			Font headerFont = setFont(workbook,FMSVariableConstants.HEADER);
			Font dataFont = setFont(workbook,FMSVariableConstants.DATA);
			CellStyle headerStyle = setStyle(workbook, FMSVariableConstants.HEADER);
			CellStyle dateStyle = setStyle(workbook,FMSVariableConstants.DATE);
			CellStyle dataStyle = setStyle(workbook, FMSVariableConstants.DATA);
			Row row = sheet.createRow(0);
			int cellNo = 0;

			for (String header : headerList) {
				Cell cell = row.createCell(cellNo);
				headerStyle.setFont(headerFont);
				cell.setCellValue(header);
				cell.setCellStyle(headerStyle);
				cellNo++;
			}

			for(Map<String,Object> record: tableData){
				currRow++;
				dataStyle.setFont(dataFont);
				cellNo = 0;
				dataStyle.setFont(dataFont);
				row = sheet.createRow(currRow);
				for (Iterator<Entry<String, Object>> iterator = record.entrySet().iterator(); iterator.hasNext();) {
					Entry<String, Object> entry = iterator.next();
					cellSet(FMSVariableConstants.STRING,dateStyle,dataStyle,row,cellNo++,Utils.getValidation(entry.getValue()));
				}
			}
			Utils.downloadFile(fileName, workbook, response);

		}catch(Exception e){
			log.info("Excepetion in export Combined Analysis :" + e.getMessage());
		}
	}      

	/**
	 * GE Duns - GE Duns from GIB will be mapped automatically every quarter 
	 * (automated file load like Orders mapping keys) 
	 * on uploading the .csv file of customer mapping, the existing duns name get updated
	 *  for the gib_serial_number, new ones gets added
	 * */

	@RequestMapping(value = "/importCSV", headers = "Content-Type= multipart/form-data", method = RequestMethod.POST)
	@Consumes("multipart/form-data")
	@ResponseBody public String importCSV(@RequestParam("file") MultipartFile file, @RequestParam("mappingParam") String mappingParam) throws IOException{
		String status = null;
		if(mappingParam.equalsIgnoreCase("GeDunsName")){
			status =  objService.importCSVToCustMapping(file.getInputStream());
		} 
		return status;
	}

	/**
	 * Export Template file with latest data
	 */
	@RequestMapping(value = "/downloadFile",consumes="application/json", method = RequestMethod.POST)
	@ResponseBody public void downloadFile(@RequestBody Map<String,Object> data,HttpServletResponse responses) throws IOException{
		objService.downloadFile(responses, data);
	}

	@RequestMapping(method=RequestMethod.POST, value="downloadExcelFile")
	@ResponseBody public void  exportTemplates(@RequestBody String mappingParam,HttpServletResponse response) throws ParseException{
		if(!"All".equalsIgnoreCase(mappingParam)){
			List<Map<String,Object>> result = objService.downloadExcelFile(mappingParam);

			String fileName = "";
			List<String> headerList = null;

			if(mappingParam.equalsIgnoreCase("MeMapping")){
				fileName = "ME Mapping.xlsx";
				headerList = Utils.getMEMappingList();
			}else if(mappingParam.equalsIgnoreCase("ProductMapping")){
				fileName = "Product Mapping.xlsx";
				headerList = Utils.getProductMappingList();
			}else if(mappingParam.equalsIgnoreCase("SegmentMapping")){
				fileName = "Segment Mapping.xlsx";
				headerList = Utils.getSegmentMappingList();
			}

			SXSSFWorkbook workbook = new SXSSFWorkbook(100);
			Sheet sheet = workbook.createSheet(fileName.replace(".xlsx", ""));
			int currRow = 0;

			Font headerFont = setFont(workbook,FMSVariableConstants.HEADER);
			Font dataFont = setFont(workbook,FMSVariableConstants.DATA);
			CellStyle headerStyle = setStyle(workbook, FMSVariableConstants.HEADER);
			CellStyle dateStyle = setStyle(workbook,FMSVariableConstants.DATE);
			CellStyle dataStyle = setStyle(workbook, FMSVariableConstants.DATA);
			Row row = sheet.createRow(0);
			int cellNo = 0;

			for (String header : headerList) {
				Cell cell = row.createCell(cellNo);
				headerStyle.setFont(headerFont);
				cell.setCellValue(header);
				cell.setCellStyle(headerStyle);
				cellNo++;
			}

			for(Map<String,Object> record: result){
				currRow++;
				dataStyle.setFont(dataFont);
				cellNo = 0;
				dataStyle.setFont(dataFont);
				row = sheet.createRow(currRow);
				for (Iterator<Entry<String, Object>> iterator = record.entrySet().iterator(); iterator.hasNext();) {
					Entry<String, Object> entry = iterator.next();
					cellSet(FMSVariableConstants.STRING,dateStyle,dataStyle,row,cellNo++,Utils.getValidation(entry.getValue()));
				}
			}
			Utils.downloadFile(fileName, workbook, response);
		}else{

			String fileName = "All Mappings.xlsx";

			List<Map<String,Object>> MEMapping = objService.downloadExcelFile("MeMapping");
			List<Map<String,Object>> productMapping = objService.downloadExcelFile("ProductMapping");
			List<Map<String,Object>> segmentMapping = objService.downloadExcelFile("SegmentMapping");

			SXSSFWorkbook workbook = new SXSSFWorkbook(100);
			int currRowME = 0;
			int currRowProduct = 0;
			int currRowSegment = 0;
			Sheet sheetME = workbook.createSheet("ME Mapping");
			Sheet sheetProduct = workbook.createSheet("Product Mapping");
			Sheet sheetSegment = workbook.createSheet("Segment Mapping");

			Font headerFont = setFont(workbook,FMSVariableConstants.HEADER);
			Font dataFont = setFont(workbook,FMSVariableConstants.DATA);
			CellStyle headerStyle = setStyle(workbook, FMSVariableConstants.HEADER);
			CellStyle dateStyle = setStyle(workbook,FMSVariableConstants.DATE);
			CellStyle dataStyle = setStyle(workbook, FMSVariableConstants.DATA);

			Row rowME = sheetME.createRow(0);
			int cellNoME = 0;
			Row rowProduct = sheetProduct.createRow(0);
			int cellNoProduct = 0;
			Row rowSegment = sheetSegment.createRow(0);
			int cellNoSegment = 0;

			for (String headerME : Utils.getMEMappingList()) {
				Cell cell = rowME.createCell(cellNoME);
				headerStyle.setFont(headerFont);
				cell.setCellValue(headerME);
				cell.setCellStyle(headerStyle);
				cellNoME++;
			}
			for (String headerProduct : Utils.getProductMappingList()) {
				Cell cell = rowProduct.createCell(cellNoProduct);
				headerStyle.setFont(headerFont);
				cell.setCellValue(headerProduct);
				cell.setCellStyle(headerStyle);
				cellNoProduct++;
			}
			for (String headerSegment : Utils.getSegmentMappingList()) {
				Cell cell = rowSegment.createCell(cellNoSegment);
				headerStyle.setFont(headerFont);
				cell.setCellValue(headerSegment);
				cell.setCellStyle(headerStyle);
				cellNoSegment++;
			}

			for(Map<String,Object> record: MEMapping){
				currRowME++;
				dataStyle.setFont(dataFont);
				cellNoME = 0;
				dataStyle.setFont(dataFont);
				rowME = sheetME.createRow(currRowME);
				for (Iterator<Entry<String, Object>> iterator = record.entrySet().iterator(); iterator.hasNext();) {
					Entry<String, Object> entry = iterator.next();
					cellSet(FMSVariableConstants.STRING,dateStyle,dataStyle,rowME,cellNoME++,Utils.getValidation(entry.getValue()));
				}
			}

			for(Map<String,Object> record: productMapping){
				currRowProduct++;
				dataStyle.setFont(dataFont);
				cellNoProduct = 0;
				dataStyle.setFont(dataFont);
				rowProduct = sheetProduct.createRow(currRowProduct);
				for (Iterator<Entry<String, Object>> iterator = record.entrySet().iterator(); iterator.hasNext();) {
					Entry<String, Object> entry = iterator.next();
					cellSet(FMSVariableConstants.STRING,dateStyle,dataStyle,rowProduct,cellNoProduct++,Utils.getValidation(entry.getValue()));
				}
			}

			for(Map<String,Object> record: segmentMapping){
				currRowSegment++;
				dataStyle.setFont(dataFont);
				cellNoSegment = 0;
				dataStyle.setFont(dataFont);
				rowSegment = sheetSegment.createRow(currRowSegment);
				for (Iterator<Entry<String, Object>> iterator = record.entrySet().iterator(); iterator.hasNext();) {
					Entry<String, Object> entry = iterator.next();
					cellSet(FMSVariableConstants.STRING,dateStyle,dataStyle,rowSegment,cellNoSegment++,Utils.getValidation(entry.getValue()));
				}
			}

			Utils.downloadFile(fileName, workbook, response);
		}
	}
	/**
	 * Fetch Penetration Region dropdown
	 * */
	@RequestMapping(method=RequestMethod.GET, value="getPenetratinMetricsRegionDropdown")
	@ResponseBody public List<String>  getPenetratinMetricsRegionDropdown(){
		Map<String,Object> filters = new HashMap<>();
		return objService.getPenetratinMetricsRegionDropdown(filters);
	}
	/**
	 * Fetch Penetration Country dropdown
	 * */
	@RequestMapping(method=RequestMethod.POST, value="getPenetratinMetricsCountryDropdown/{businessSegment}")
	@ResponseBody public List<String>  getPenetratinMetricsCountryDropdown(@PathVariable ("businessSegment") String businessSegment,@RequestBody Map<String,Object> filters){
		return objService.getPenetratinMetricsCountryDropdown(businessSegment,filters);
	}
	/**
	 * Penetration Metrics Country/technology level
	 * */
	@RequestMapping(method=RequestMethod.POST, value="getAllMetricsCountryTechData/{type}")
	@ResponseBody public Map<String, Object>  getAllMetricsCountryTechData(@PathVariable("type") String type,@RequestBody Map<String,Object> filters){
		return objService.getAllMetricsCountryTechData(type,filters);
	}
	/**
	 * Penetration Metrics Site level
	 * */
	@RequestMapping(method=RequestMethod.POST, value="getAllMetricsCountrySiteData")
	@ResponseBody public Map<String, Object>  getAllMetricsCountrySiteData(@RequestBody Map<String,Object> filters){
		return objService.getAllMetricsCountrySiteData(filters);
	}

	/**
	 * Penetration Metrics Site level country dropdown
	 * */
	@RequestMapping(method=RequestMethod.POST, value="getAllMetricsCountrySiteDropdown/{businessSegment}")
	@ResponseBody public List<String>  getAllMetricsCountrySiteDropdown(@PathVariable("businessSegment") String businessSegment,@RequestBody Map<String,Object> filters){
		return objService.getAllMetricsCountrySiteDropdown(businessSegment,filters);
	}

	/**
	 * Penetration Metrics Site level export data
	 * */
	@RequestMapping(method=RequestMethod.POST, value="penetrationExportExcelData")
	@ResponseBody public Map<String,Object>  penetrationExportExcelData(@RequestBody Map<String,Object> filters,HttpServletResponse response){
		return objService.penetrationExportExcelData(filters);

	}
	/**
	 * Penetration Metrics Segment level
	 * */
	@RequestMapping(method=RequestMethod.POST, value="getPenMetricsSegmentData/{type}")
	@ResponseBody public Map<String, Object>  getPenMetricsSegmentData(@PathVariable("type") String type,@RequestBody Map<String,Object> filters){
		return objService.getPenMetricsSegmentData(type,filters);
	}

	/**
	 * Functionality to fetch data related to Alert(Penetration) dashboard 
	 * */
	@RequestMapping(method=RequestMethod.POST, value="penetrationDashboard/{businessSegment}")
	@ResponseBody public Map<String,Object>  penetrationDashboard(@PathVariable("businessSegment") String businessSegment,@RequestBody Map<String,Object> filters,HttpServletResponse response){
		return objService.penetrationDashboard(businessSegment,filters);

	}

	/**
	 * Penetration dashboard Export 
	 * */
	@RequestMapping(method=RequestMethod.POST, value="exportPenetrationDashboard/{businessSegment}")
	@ResponseBody public void  ExportPenetrationDashboard(@PathVariable("businessSegment") String businessSegment,
			@RequestBody Map<String,Object> filters,HttpServletResponse response){

		/**filters.put(FMSVariableConstants.OPTION, FMSVariableConstants.EXPORT);*/
		List<Map<String,Object>> data = new ArrayList<>();
		if(Utils.getValidation(filters.get(FMSVariableConstants.LEVEL)).equals(FMSVariableConstants.SITE)
				|| Utils.getValidation(filters.get(FMSVariableConstants.STATE)).equals(FMSVariableConstants.UNMAPPEDSITE)
				||Utils.getValidation(filters.get(FMSVariableConstants.LEVEL)).equals(FMSVariableConstants.WORLDSITE)
				||Utils.getValidation(filters.get(FMSVariableConstants.OPTION)).equals(FMSVariableConstants.EXPORTALL)){
			data = (List<Map<String, Object>>) objService.penetrationDashboard(businessSegment,filters).get("siteInfo");
		}else{
			data = (List<Map<String, Object>>) objService.penetrationDashboard(businessSegment,filters).get("StateCoordinates");
		}
		String fileName = "";
		String fileTitle = "";

		Integer unPreformMark = Utils.getIntegerValidation(filters.get(FMSVariableConstants.VALUE));
		String periodStatus = null;
		if(Utils.getValidation(filters.get(FMSVariableConstants.QUARTER)).equalsIgnoreCase(FMSVariableConstants.CURRENT)){
			periodStatus = FMSVariableConstants.CURRENT;
		}else{
			periodStatus = FMSVariableConstants.OVERALL;
		}

		switch(Utils.getValidation(filters.get(FMSVariableConstants.REPORT))){
		case FMSVariableConstants.FLEETCOVERAGE:
			fileName = "fleet coverage.xlsx";
			fileTitle = "FLEET COVERAGE";
			break;
		case FMSVariableConstants.FLEETPEN:
			fileName = "fleet penetration.xlsx";
			fileTitle = "FLEET PENETRATION";
			break;
		case FMSVariableConstants.FLEETPENF2F:
			fileName = "fleet pen f2f.xlsx";
			fileTitle = "FLEET PEN F2F";
			break;
		case FMSVariableConstants.CALORICINDEX:
			fileName = "caloric index.xlsx";
			fileTitle = "CALORIC INDEX";
			break;
		}

		SXSSFWorkbook workbook = new SXSSFWorkbook(100);
		Sheet sheet = workbook.createSheet(fileName.replace(".xlsx", ""));
		Sheet sheetLegend = workbook.createSheet("Legend");
		Row rowLegend = sheetLegend.createRow(0);
		Cell cellDataLegend = rowLegend.createCell(0);
		cellDataLegend.setCellValue("COLOR");
		cellDataLegend = rowLegend.createCell(1);
		cellDataLegend.setCellValue("DESCRIPTION");
		rowLegend = sheetLegend.createRow(1);
		cellDataLegend = rowLegend.createCell(0);
		cellDataLegend.setCellValue("ORANGE");
		cellDataLegend = rowLegend.createCell(1);
		cellDataLegend.setCellValue("UNDER PERFORMING REGION/COUNTRY/SITE (FLEET_PENETRATION/FLEET_COVERAGE BELOW " +unPreformMark+"%) ");
		rowLegend = sheetLegend.createRow(2);
		cellDataLegend = rowLegend.createCell(0);
		cellDataLegend.setCellValue("GREEN");
		cellDataLegend = rowLegend.createCell(1);
		cellDataLegend.setCellValue("PERFORMING REGION/COUNTRY/SITE (FLEET_PENETRATION/FLEET_COVERAGE ABOVE " +unPreformMark+"%)  ");
		rowLegend = sheetLegend.createRow(3);
		cellDataLegend = rowLegend.createCell(0);
		cellDataLegend.setCellValue("RED");
		cellDataLegend = rowLegend.createCell(1);
		cellDataLegend.setCellValue("UNMAPPED REGION/COUNTRY/SITE (NOT MAPPED TO ITS CORRESPONDING ORDERS) ");

		int currRow = 1;

		CellStyle style = workbook.createCellStyle();
		style.setAlignment(CellStyle.ALIGN_LEFT);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setTopBorderColor(IndexedColors.BLACK.getIndex());

		Font font = workbook.createFont();
		font.setFontHeightInPoints((short) 11);
		font.setFontName(FMSVariableConstants.GE_INSPIRA_FONT);
		font.setItalic(false);

		Row row = sheet.createRow(0);
		Cell cellTitle = row.createCell(0);
		cellTitle.setCellValue(fileTitle+" < "+unPreformMark+"% ("+periodStatus+")");

		row = sheet.createRow(1);
		int cellNo = 0;


		for (String header : data.get(0).keySet()) {
			Cell cell = row.createCell(cellNo);
			font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			style.setFont(font);
			if(header.equalsIgnoreCase("fleet_coverage") || header.equalsIgnoreCase("fleet_penetration") || header.equalsIgnoreCase("caloric_index") || header.equalsIgnoreCase("fleet_pen_f2f")){
				cell.setCellValue(header.replace("_", " ").toUpperCase() + " (%)");
			}else if(header.equalsIgnoreCase(FMSVariableConstants.IBO_VALUE)){
				/**cell.setCellValue(header.concat(" ($K)").replace("_", " ").toUpperCase());*/
				cell.setCellValue(header.replace("_", " ").toUpperCase());
			}else{
				cell.setCellValue(header.replace("_", " ").toUpperCase());
			}
			cell.setCellStyle(style);
			cellNo++;
		}

		for(Map<String,Object> record: data){
			currRow++;

			font.setBoldweight(XSSFFont.BOLDWEIGHT_NORMAL);
			style.setFont(font);
			cellNo = 0;
			row = sheet.createRow(currRow);

			CellStyle styleNew = workbook.createCellStyle();
			styleNew.setAlignment(CellStyle.ALIGN_LEFT);
			styleNew.setBorderBottom(CellStyle.BORDER_THIN);
			styleNew.setBorderLeft(CellStyle.BORDER_THIN);
			styleNew.setBorderRight(CellStyle.BORDER_THIN);
			styleNew.setBorderTop(CellStyle.BORDER_THIN);
			styleNew.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			styleNew.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			styleNew.setRightBorderColor(IndexedColors.BLACK.getIndex());
			styleNew.setTopBorderColor(IndexedColors.BLACK.getIndex());

			Font fontNew = workbook.createFont();
			fontNew.setFontHeightInPoints((short) 10);
			fontNew.setFontName(FMSVariableConstants.GE_INSPIRA_FONT);
			fontNew.setItalic(false);

			String value = null;
			if(record.containsKey("fleet_coverage")){
				value = Utils.getValidation(record.get("fleet_coverage"));
			}else if(record.containsKey("fleet_penetration")){
				value = Utils.getValidation(record.get("fleet_penetration"));
			}else if(record.containsKey("caloric_index")){
				value = Utils.getValidation(record.get("caloric_index"));
			}else if(record.containsKey("fleet_pen_f2f")){
				value = Utils.getValidation(record.get("fleet_pen_f2f"));
			}



			if(record.containsKey("fleet_coverage") || record.containsKey("fleet_penetration") || record.containsKey("caloric_index") || record.containsKey("fleet_pen_f2f")){
				if(!("NO ORDERS").equalsIgnoreCase(value) && (Double.parseDouble(value)>=unPreformMark)){
					fontNew.setColor(IndexedColors.GREEN.getIndex());
					styleNew.setFont(fontNew);

				}else if(!("NO ORDERS").equalsIgnoreCase(value) && (Double.parseDouble(value)<unPreformMark)){
					fontNew.setColor(IndexedColors.ORANGE.getIndex());
					styleNew.setFont(fontNew);

				}else if(("NO ORDERS").equalsIgnoreCase(value) || ("").equalsIgnoreCase(value)){
					fontNew.setColor(IndexedColors.RED.getIndex());
					styleNew.setFont(fontNew);
				}
			}else{
				fontNew.setColor(IndexedColors.RED.getIndex());
				styleNew.setFont(fontNew);
			}

			for (Iterator<Entry<String, Object>> iterator = record.entrySet().iterator(); iterator.hasNext();) {
				Entry<String, Object> entry = iterator.next();
				Cell cellData = row.createCell(cellNo);
				cellData.setCellStyle(styleNew);
				if((entry.getKey().equalsIgnoreCase("fleet_coverage")||entry.getKey().equalsIgnoreCase("fleet_penetration")) && (!entry.getValue().toString().equalsIgnoreCase("NO ORDERS"))){
					cellData.setCellValue(Utils.getValidation(entry.getValue()));
				}else{
					cellData.setCellValue(Utils.getValidation(entry.getValue()));
				}
				cellNo++;
			}
		}
		Utils.downloadFile(fileName, workbook, response);

	}



	/***
	 * 
	 * Functionality to fetch the raw data
	 * ***/
	@RequestMapping(method=RequestMethod.POST, value="getRawDataIBOPage/{Page}", consumes="application/json")
	@ResponseBody public Map<String,Object>   getRawDataIBOPage(@PathVariable("Page") String page, @RequestBody String data){
		try
		{
			JSONParser parse = new JSONParser();
			JSONObject jObj = (JSONObject) parse.parse(data);
			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);
			JSONObject jObj1 = (JSONObject)jArr.get(0); 
			return objService.getRawDataIBOPage(page,jObj1);
		}
		catch(Exception e){
			log.info(e);
		}
		return null;
	}

	/***
	 * 
	 * Export functionality for raw data for IBO Metrics page
	 * 
	 * ***/

	private enum Page {
		ibTechReg, ordersTechReg, IBOTechReg, dmTechReg, outageTechReg, serviceTechReg;
	}

	@RequestMapping(method=RequestMethod.POST, value="exportRawDataMetrics/{page}/{fileName}")
	@ResponseBody public void  exportRawDataMetrics(@PathVariable("page") String page, @PathVariable("fileName") String fileName,HttpServletResponse response,@RequestBody String data) throws ParseException{
		try {
			Page value = Page.valueOf(page);
			JSONParser parse = new JSONParser();
			JSONObject jObj = (JSONObject) parse.parse(data);
			JSONArray jArr = (JSONArray)jObj.get(FMSVariableConstants.DATA);
			JSONObject jsonObj = (JSONObject)jArr.get(0);
			List<Map<String,Object>> tableData = objService.exportRawDataMetrics(jsonObj,page);
			List<String> headerList = null;
			switch(value) {
			case ibTechReg:
				fileName = fileName + ".xlsx";
				headerList = objService.getRawDataHeadersList(FMSVariableConstants.IB_TECH_REG);
				break;
			case IBOTechReg:
				fileName = fileName + ".xlsx";
				headerList = objService.getRawDataHeadersList(FMSVariableConstants.IB_TECH_REG);
				break;
			case ordersTechReg:
				fileName = fileName + ".xlsx";
				headerList = objService.getRawDataHeadersList(FMSVariableConstants.ORDERS_TECH_REG);
				break;
			case dmTechReg:
				fileName = fileName + ".xlsx";
				headerList = objService.getRawDataHeadersList(FMSVariableConstants.DM_TECH_REG);
				break;
			case outageTechReg:
				fileName = fileName + ".xlsx";
				headerList = objService.getRawDataHeadersList(FMSVariableConstants.OUTAGE_TECH_REG);
				break;
			case serviceTechReg:
				fileName = fileName + ".xlsx";
				headerList = objService.getRawDataHeadersList(FMSVariableConstants.SERVICE_TECH_REG);
				break;
			}

			SXSSFWorkbook workbook = new SXSSFWorkbook(100);
			Sheet sheet = workbook.createSheet("Raw Data");
			int currRow = 0;

			Font headerFont = setFont(workbook,FMSVariableConstants.HEADER);
			Font dataFont = setFont(workbook,FMSVariableConstants.DATA);
			CellStyle headerStyle = setStyle(workbook, FMSVariableConstants.HEADER);
			CellStyle dateStyle = setStyle(workbook,FMSVariableConstants.DATE);
			CellStyle dataStyle = setStyle(workbook, FMSVariableConstants.DATA);
			Row row = sheet.createRow(0);
			int cellNo = 0;

			for (String header : headerList) {
				Cell cell = row.createCell(cellNo);
				headerStyle.setFont(headerFont);
				cell.setCellValue(header);
				cell.setCellStyle(headerStyle);
				cellNo++;
			}

			for(Map<String,Object> record: tableData){
				currRow++;
				dataStyle.setFont(dataFont);
				cellNo = 0;
				dataStyle.setFont(dataFont);
				row = sheet.createRow(currRow);
				for (Iterator<Entry<String, Object>> iterator = record.entrySet().iterator(); iterator.hasNext();) {
					Entry<String, Object> entry = iterator.next();
					cellSet(FMSVariableConstants.STRING,dateStyle,dataStyle,row,cellNo++,Utils.getValidation(entry.getValue()));
				}
			}
			Utils.downloadFile(fileName, workbook, response);

		} catch(Exception e){
			log.info("Excepetion in export Raw Data :" + e.getMessage());
		}
	}


	/**
	 * Penetration Metrics GE Duns level dropdown
	 * */
	@RequestMapping(method=RequestMethod.POST, value="getPenetrationMetricsGEDunsNameDropdown/{businessSegment}")
	@ResponseBody public List<String> getPenetrationMetricsGEDunsNameDropdown(@PathVariable("businessSegment") String businessSegment,@RequestBody Map<String,Object> filters){
		return objService.getPenetrationMetricsGEDunsNameDropdown(businessSegment,filters);
	}

	/**
	 * Penetration Metrics GE Duns level
	 * */
	@RequestMapping(method=RequestMethod.POST, value="getAllMetricsGEDunsNameData")
	@ResponseBody public Map<String, Object>  getAllMetricsGEDunsNameData(@RequestBody Map<String,Object> filters){
		return objService.getAllMetricsGEDunsNameData(filters);
	}

	/**
	 * Penetration Metrics GE Duns level export data
	 * */
	@RequestMapping(method=RequestMethod.POST, value="penetrationGEDunsExportExcelData")
	@ResponseBody public Map<String,Object>  penetrationGEDunsExportExcelData(@RequestBody Map<String,Object> filters){
		return objService.penetrationGEDunsExportExcelData(filters);

	}

	/**
	 * Penetration Metrics Top Sites
	 * */
	@RequestMapping(method=RequestMethod.POST, value="getPenMetricsTopSitesByRegion")
	@ResponseBody public Map<String, Object>  getPenMetricsTopSitesByRegion(@RequestBody Map<String,Object> filters){
		return objService.getPenMetricsTopSitesByRegion(filters);
	}

	/**
	 * Insert the data into Oracle from Postgresql
	 * **/
	@RequestMapping(method=RequestMethod.GET,value="fetchPostgreRegionData")
	@ResponseBody public List<Map<String, Object>> fetchPostgreRegionData() {
		log.info("fetchPostgreRegionData() in FMSController");
		return objService.fetchPostgreRegionData();
	}
	/**
	 * Retrieve IPM Raw data
	 * */
	@RequestMapping(method=RequestMethod.POST, value="getIPMRawData")
	@ResponseBody public Map<String, Object>  getIPMRawData(@RequestBody Map<String,Object> filterData){
		return objService.getIPMRawData(filterData);
	}

	/**
	 * IPM Raw data Export 
	 * */
	@RequestMapping(method=RequestMethod.POST, value="exportIPMRawData")
	@ResponseBody public void exportIPMRawData(@RequestBody Map<String,Object> filterData,HttpServletResponse response){

		filterData.put(FMSVariableConstants.OPTION, FMSVariableConstants.EXPORT);
		List<Map<String,Object>> data = new ArrayList<>();
		data = (List<Map<String, Object>>) objService.getIPMRawData(filterData).get(FMSVariableConstants.IPMRAWDATA);


		SXSSFWorkbook workbook = new SXSSFWorkbook(100);
		Sheet sheet = workbook.createSheet("IPMRAW_DATA.xlsx");

		int currRow = 0;

		CellStyle style = workbook.createCellStyle();
		style.setAlignment(CellStyle.ALIGN_LEFT);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setTopBorderColor(IndexedColors.BLACK.getIndex());

		Font font = workbook.createFont();
		font.setFontHeightInPoints((short) 11);
		font.setFontName(FMSVariableConstants.GE_INSPIRA_FONT);
		font.setItalic(false);

		Row row = sheet.createRow(0);
		int cellNo = 0;

		if(data.size()> 0){
			for (String header : data.get(0).keySet()) {
				Cell cell = row.createCell(cellNo);
				font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				style.setFont(font);
				cell.setCellValue(header.replace("_", " ").toUpperCase());
				cell.setCellStyle(style);
				cellNo++;
			}

			for(Map<String,Object> record: data){
				currRow++;

				font.setBoldweight(XSSFFont.BOLDWEIGHT_NORMAL);
				style.setFont(font);
				cellNo = 0;
				row = sheet.createRow(currRow);

				CellStyle styleNew = workbook.createCellStyle();
				styleNew.setAlignment(CellStyle.ALIGN_LEFT);
				styleNew.setBorderBottom(CellStyle.BORDER_THIN);
				styleNew.setBorderLeft(CellStyle.BORDER_THIN);
				styleNew.setBorderRight(CellStyle.BORDER_THIN);
				styleNew.setBorderTop(CellStyle.BORDER_THIN);
				styleNew.setBottomBorderColor(IndexedColors.BLACK.getIndex());
				styleNew.setLeftBorderColor(IndexedColors.BLACK.getIndex());
				styleNew.setRightBorderColor(IndexedColors.BLACK.getIndex());
				styleNew.setTopBorderColor(IndexedColors.BLACK.getIndex());

				Font fontNew = workbook.createFont();
				fontNew.setFontHeightInPoints((short) 10);
				fontNew.setFontName(FMSVariableConstants.GE_INSPIRA_FONT);
				fontNew.setItalic(false);

				for (Iterator<Entry<String, Object>> iterator = record.entrySet().iterator(); iterator.hasNext();) {
					Entry<String, Object> entry = iterator.next();
					Cell cellData = row.createCell(cellNo);
					cellData.setCellStyle(styleNew);
					cellData.setCellValue(Utils.getValidation(entry.getValue()));
					cellNo++;
				}
			}
		}
		Utils.downloadFile("IPMRAW_DATA.xlsx", workbook, response);

	}

	@RequestMapping(method=RequestMethod.POST, value="updateIPMPartsQmi",consumes="application/json", produces="text/plain")
	@ResponseBody public String  updateIPMPartsQmi(@RequestBody Map<String,Object> filterData){
		log.info("updateIPMPartsQmi() in FMSController");
		return objService.updateIPMPartsQmi(filterData);
	}

	//TO EXPORT THE YEQAR WISE ORDERS DATA, WE NEED THE LIST OF AVAILABLE YEARS
	@RequestMapping(method=RequestMethod.GET,value="getOrdersYears")
	@ResponseBody public List<String> getOrdersYears() {
		return objService.getOrdersYears();  
	}

	@RequestMapping(method=RequestMethod.POST, value="manageUsers",consumes="application/json", produces="text/plain")
	@ResponseBody public String  manageUsers(@RequestBody Map<String,Object> userData){
		log.info("manageUsers() in FMSController");
		return objService.manageUsers(userData);
	}

	@RequestMapping(method=RequestMethod.GET, value="getParticularUserDetails/{sso}")
	@ResponseBody public Map<String,Object>  getParticularUserDetails(@PathVariable("sso") String sso){
		log.info("getParticularUserDetails() in FMSController");
		return objService.getParticularUserDetails(sso);
	}
	
	@RequestMapping(method=RequestMethod.GET, value="getUserManagementDetails")
	@ResponseBody public Map<String, Object>  getUserManagementDetails (){
			return objService.getUserManagementDetails();
	}
	
	@RequestMapping(method=RequestMethod.POST, value="exportUserManagementData/{exportType}")
	@ResponseBody public void  exportUserManagementData(HttpServletResponse response,@PathVariable("exportType") String exportType) throws ParseException{
		try {

			List<Map<String,Object>> tableData = objService.exportUserManagementData(exportType);
			List<String> headerList = new ArrayList<>();
			SXSSFWorkbook workbook = new SXSSFWorkbook(100);
			Sheet sheet = null;
			int currRow = 0;
			String fileName = null;
			if(FMSVariableConstants.EXPORT_USER_DETAILS_TYPE_USER.equalsIgnoreCase(exportType)){
				headerList.add(FMSVariableConstants.F_NAME);
				headerList.add(FMSVariableConstants.L_NAME);
				headerList.add(FMSVariableConstants.U_SSO);
				headerList.add(FMSVariableConstants.U_EMAIL);
				headerList.add(FMSVariableConstants.ROLE);
				headerList.add(FMSVariableConstants.EXPORT_STATUS);
				sheet = workbook.createSheet(FMSVariableConstants.EXPORT_USER_DETAILS_FILENAME);
				fileName = FMSVariableConstants.EXPORT_USER_DETAILS_FILENAME;
			}
			else if(FMSVariableConstants.EXPORT_USER_DETAILS_TYPE_ROLE.equalsIgnoreCase(exportType)){
				headerList.add(FMSVariableConstants.EXPORT_ROLE_NAME);
				headerList.add(FMSVariableConstants.EXPORT_ROLE_NAME_DESC);
				headerList.add(FMSVariableConstants.EXPORT_STATUS);
				sheet = workbook.createSheet(FMSVariableConstants.EXPORT_ROLE_DETAILS_FILENAME);
				fileName = FMSVariableConstants.EXPORT_ROLE_DETAILS_FILENAME;
			}else{
				sheet = workbook.createSheet(FMSVariableConstants.EXPORT_ROLE_DETAILS_FILENAME);
				fileName = FMSVariableConstants.EXPORT_ROLE_DETAILS_FILENAME;
			}

			Font headerFont = setFont(workbook,FMSVariableConstants.HEADER);
			Font dataFont = setFont(workbook,FMSVariableConstants.DATA);
			CellStyle headerStyle = setStyle(workbook, FMSVariableConstants.HEADER);
			CellStyle dateStyle = setStyle(workbook,FMSVariableConstants.DATE);
			CellStyle dataStyle = setStyle(workbook, FMSVariableConstants.DATA);
			Row row = sheet.createRow(0);
			int cellNo = 0;

			for (String header : headerList) {
				Cell cell = row.createCell(cellNo);
				headerStyle.setFont(headerFont);
				cell.setCellValue(header);
				cell.setCellStyle(headerStyle);
				cellNo++;
			}

			for(Map<String,Object> record: tableData){
				currRow++;
				dataStyle.setFont(dataFont);
				cellNo = 0;
				dataStyle.setFont(dataFont);
				row = sheet.createRow(currRow);
				for (Iterator<Entry<String, Object>> iterator = record.entrySet().iterator(); iterator.hasNext();) {
					Entry<String, Object> entry = iterator.next();
					cellSet(FMSVariableConstants.STRING,dateStyle,dataStyle,row,cellNo++,Utils.getValidation(entry.getValue()));
				}
			}
			Utils.downloadFile(fileName.concat(".xlsx"), workbook, response);

		} catch(Exception e){
			log.info("Excepetion in export All User Details :" + e.getMessage());
		}
	}
	
	@RequestMapping(method=RequestMethod.POST, value="manageRoles",consumes="application/json", produces="text/plain")
	@ResponseBody public String  manageRoles(@RequestBody Map<String,Object> rolesData){
		log.info("manageRoles() in FMSController");
		return objService.manageRoles(rolesData);
	}
	
	@RequestMapping(method=RequestMethod.GET, value="getUserDetailsBasedOnRole/{roleId}", produces="application/json")
	@ResponseBody public Map<String,Object>  getUserDetailsBasedOnRole(@PathVariable("roleId") int roleId){
		log.info("getUserDetailsBasedOnRole() in FMSController");
		return objService.getUserDetailsBasedOnRole(roleId);
	}
	
	@RequestMapping(method=RequestMethod.GET, value="backUpService")
	@ResponseBody public void  backUpService(){
		log.info("inside FMSController of backUpService()");
		objService.backUpService();
	}
	
	@RequestMapping(value = "/exportInvalidIPMData",consumes="application/json",method = RequestMethod.POST)
	@ResponseBody public void exportInvalidIPMData(@RequestBody Map<String,Object> filterData,HttpServletResponse responses) throws IOException{
		objService.exportInvalidIPMData(responses,filterData);
	}
		
	@RequestMapping(method= RequestMethod.POST, value= "getImportStatusHistory")
	@ResponseBody public List<Map<String,Object>> getImportStatusHistory(@RequestBody Map<String,Object> filterData){
		return objService.getImportStatusHistory(filterData);
	}
	
	@RequestMapping(value = "/uploadDocuments", headers = "Content-Type= multipart/form-data",method = RequestMethod.POST)
	@Consumes("multipart/form-data")
	@ResponseBody public String uploadDocuments(@RequestParam("file") MultipartFile file, @RequestParam("fileDescription") String fileDescription, @RequestParam("userSSO") String userSSO, @RequestParam("fileAccess") String fileAccess) throws IOException{
		return objService.uploadDocuments(file.getInputStream(), file.getOriginalFilename(),fileDescription, userSSO, fileAccess);
	}
	
	/*
	 * Download help documents file
	*/
	@RequestMapping(value = "/downloadDocuments",consumes="application/json", method = RequestMethod.POST)
	@ResponseBody public void downloadDocuments(@RequestBody Map<String,Object> data,HttpServletResponse responses) throws IOException{
		objService.downloadDocuments(responses, data);
	}
	
	/*
	 * This will return all documents list.
	 */
	@RequestMapping(method=RequestMethod.POST, value="getAllDocuments", consumes="application/json")
	@ResponseBody public List<Map<String, Object>>  getAllDocuments(@RequestBody Map<String,Object> data){
		return objService.getAllDocuments(data);
	}
	
	/**
	 * This will return role list.
	 */
	@RequestMapping(method=RequestMethod.POST, value="getAllRoles", consumes="application/json")
	@ResponseBody public Map<String, Object>  getAllRoles(@RequestBody Map<String,Object> data){
		return objService.getAllRoles(data);
	}
	
	/*
	 * This will delete file from documents list.
	 */
	@RequestMapping(method=RequestMethod.POST, value="deleteDocument", consumes="application/json", produces="text/plain")
	@ResponseBody public String  deleteDocument(@RequestBody Map<String,Object> data){
		return objService.deleteDocument(data);
	}
	
	@RequestMapping(method=RequestMethod.GET, value= "checkAkanaCallLocally")
	@ResponseBody public String checkAkanaCallLocally() {
		return objService.checkAkanaCallLocally();
	}
	
	@RequestMapping(method=RequestMethod.POST, value="getManagersForTopSites/{businessSegment}", consumes="application/json")
	@ResponseBody public Map<String, Object>  getManagersForTopSites(@PathVariable("businessSegment") String businessSegment,@RequestBody Map<String,Object> params){
		return objService.getManagersForTopSites(businessSegment,params);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="getAccountManagers/{businessSegment}")
	@ResponseBody public Map<String, Object>  getAccountManagers(@PathVariable("businessSegment") String businessSegment,@RequestBody Map<String,Object> data){
		return objService.getAccountManagers(businessSegment,data);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="getMarketIndustryDescDropdown")
	@ResponseBody public Map<String, Object>  getMarketIndustryDescDropdown(@RequestBody Map<String,Object> data){
		return objService.getMarketIndustryDescDropdown(data);
	}
	
	@RequestMapping(value = "/importIBOData", headers = "Content-Type= multipart/form-data", method = RequestMethod.POST)
	@Consumes("multipart/form-data")
	@ResponseBody public void importIBOData(@RequestParam("file") MultipartFile file,@RequestParam("userSSO") String userSSO) throws IOException{
		objService.importIBOData(file.getInputStream(),file.getOriginalFilename() ,userSSO);
	}
}
