package fms.impl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import fms.utils.Utils;

@Component
public class OauthAkanaHandler {
	
	@Value("${fmsApi.resourceUri}")
	private String fmsAkanaServiceUrl;
	
	@Value("${fmsApi.accessTokenUri}")
	private String fmsApiAccessTokenUri;
	
	@Value("${fmsApi.clientId}")
	private String fmsApiClientId;
	
	@Value("${fmsApi.clientSecret}")
	private String fmsApiClientSecret;

/**	@Value("${fmsApi.scope}")
	private String fmsApiScope;	
*/	
	
	public List  execute(String url,HttpMethod method, Object obj){
/**		ClientCredentialsResourceDetails resourceDetails = new ClientCredentialsResourceDetails();
        resourceDetails.setAccessTokenUri(fmsApiAccessTokenUri);
        resourceDetails.setClientId(fmsApiClientId);
        resourceDetails.setClientSecret(fmsApiClientSecret);
        resourceDetails.setScope(Arrays.asList(fmsApiScope));
        resourceDetails.setId(fmsApiClientId);
        resourceDetails.setClientAuthenticationScheme(AuthenticationScheme.header);
        ClientCredentialsAccessTokenProvider provider = new ClientCredentialsAccessTokenProvider();
        OAuth2AccessToken accessToken = provider.obtainAccessToken(resourceDetails, new DefaultAccessTokenRequest());
        OAuth2RestTemplate restTemplate = new OAuth2RestTemplate(resourceDetails, new DefaultOAuth2ClientContext(accessToken));*/
        
		RestTemplate restTemplate = new RestTemplate(); 
    	HttpHeaders headers = new HttpHeaders();
    	headers.setContentType(MediaType.APPLICATION_JSON);

    	org.springframework.http.HttpEntity<String> entity = new org.springframework.http.HttpEntity<String>(Utils.jsonConverter(obj) ,headers);
    	final ResponseEntity<List> greeting=restTemplate.exchange(fmsAkanaServiceUrl + url, method, entity, List.class);
        return greeting.getBody();
        
	}

}
