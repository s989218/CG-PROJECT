package fms.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RemoteSearchAPIConfig {

	@Value("${fmsApi.accessTokenUri}")
	private String fmsApiAccessTokenUri;
	@Value("${fmsApi.clientId}")
	private String fmsApiClientId;
	@Value("${fmsApi.clientSecret}")
	private String fmsApiClientSecret;
	
	
	@Bean
	public RestTemplate fmsApiRestTemplate() {
		return new RestTemplate();		
	}
	
}
