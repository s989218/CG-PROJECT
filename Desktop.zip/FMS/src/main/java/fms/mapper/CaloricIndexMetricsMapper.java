package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSMetricsDataBean;

public class CaloricIndexMetricsMapper implements RowMapper<FMSMetricsDataBean> {

	@Override
	public FMSMetricsDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSMetricsDataBean metricsDataDto = new FMSMetricsDataBean();
		
		metricsDataDto.setMetricsDataRegion(rs.getString("region"));
		metricsDataDto.setMetricsDataYear(rs.getString("year"));
		metricsDataDto.setMetricsDataQuarter(rs.getString("quarter"));
		String caloricIndexValue = rs.getString("caloric_index_value");
		if(caloricIndexValue != null){
			metricsDataDto.setCaloricIndexValue(Float.valueOf(rs.getString("caloric_index_value")));
		}		
		return metricsDataDto;
	}


}

