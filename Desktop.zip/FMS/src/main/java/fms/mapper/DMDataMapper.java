package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSDMDataBean;

public class DMDataMapper implements RowMapper<FMSDMDataBean> {

	@Override
	public FMSDMDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSDMDataBean dmDataDto = new FMSDMDataBean();
		
		dmDataDto.setOpptyId(rs.getString("OPPTY_ID"));
		dmDataDto.setRecordTypeId(rs.getString("RECORDTYPE_ID"));
		dmDataDto.setOpptyNo(rs.getString("OPPTY_NUMBER"));
		dmDataDto.setOpptyName(rs.getString("OPPTY_NAME"));
		dmDataDto.setOpptySalesStage(rs.getString("OPPTY_SALES_STAGE"));
		dmDataDto.setLastSalesStageChanged(rs.getString("LAST_SALES_STAGE_CHANGED"));
		dmDataDto.setForecastCategory(rs.getString("FORECAST_CATEGORY"));
		dmDataDto.setExpectedOrderDate(rs.getString("EXPECTED_ORDER_DATE"));
		dmDataDto.setExpectedOrderYear(rs.getInt("EXPECTED_ORDER_YEAR"));
		dmDataDto.setExpectedOrderQuarter(rs.getInt("EXPECTED_ORDER_QUARTER"));
		dmDataDto.setBusinessTier3(rs.getString("BUSINESS_TIER_3"));
		dmDataDto.setPrimaryCountry(rs.getString("PRIMARY_COUNTRY"));
		dmDataDto.setPrimaryRegion(rs.getString("PRIMARY_REGION"));
		dmDataDto.setProjectNumber(rs.getString("PROJECT_NUMBER"));
		dmDataDto.setProjectName(rs.getString("PROJECT_NAME"));
		dmDataDto.setConvertibleThisQtr(rs.getString("CONVERTIBLE_THIS_QTR"));
		dmDataDto.setPrimaryIndustry(rs.getString("PRIMARY_INDUSTRY"));
		dmDataDto.setOpptyAmountUsd(rs.getInt("OPPTY_AMOUNT_USD"));
		dmDataDto.setOpptyCmUsd(rs.getInt("OPPTY_CM_USD"));
		dmDataDto.setPrimarySalesId(rs.getString("PRIMARY_SALES_ID"));
		dmDataDto.setPrimarySalesName(rs.getString("PRIMARY_SALES_NAME"));
		dmDataDto.setIsComopsNeeded(rs.getString("IS_COMOPS_NEEDED"));
		dmDataDto.setCommAccountName(rs.getString("COMM_ACCOUNT_NAME"));
		dmDataDto.setEndUserAccountName(rs.getString("END_USER_ACCOUNT_NAME"));
		dmDataDto.setEndUserAccountDuns(rs.getString("END_USER_ACCOUNT_DUNS"));
		dmDataDto.setDealRiskPath(rs.getString("DEAL_RISK_PATH"));
		dmDataDto.setDealRiskLevel(rs.getString("DEAL_RISK_LEVEL"));
		dmDataDto.setDealQuoteType(rs.getString("DEAL_QUOTE_TYPE"));
		dmDataDto.setRfqReceivedDate(rs.getString("RFQ_RECEIVED_DATE"));
		dmDataDto.setBidDueDate(rs.getString("BID_DUE_DATE"));
		dmDataDto.setExpectedDeliveryDate(rs.getString("EXPECTED_DELIVERY_DATE"));
		dmDataDto.setBidSentDate(rs.getString("BID_SENT_DATE"));
		dmDataDto.setDispPrimaryReason(rs.getString("DISP_PRIMARY_REASON"));
		dmDataDto.setGlobalAccountClass(rs.getString("GLOBAL_ACCOUNT_CLASS"));
		dmDataDto.setGlobalAccountType(rs.getString("GLOBAL_ACCOUNT_TYPE"));
		dmDataDto.setRepBusinessTier3(rs.getString("REP_BUSINESS_TIER_3"));
		dmDataDto.setRepBusinessTier4(rs.getString("REP_BUSINESS_TIER_4"));
		dmDataDto.setRepBizAbbrTier4(rs.getString("REP_BIZ_ABBR_TIER_4"));
		dmDataDto.setProjectFlowType(rs.getString("PROJECT_FLOW_TYPE"));
		dmDataDto.setCreatedByName(rs.getString("CREATED_BY_NAME"));
		dmDataDto.setCreatedDate(rs.getString("CREATED_DATE"));
		dmDataDto.setStaleDealIndicator(rs.getString("STALE_DEAL_INDICATOR"));
		dmDataDto.setDealBudgetaryType(rs.getString("DEAL_BUDGETARY_TYPE"));
		dmDataDto.setDealUnsolicitedType(rs.getString("DEAL_UNSOLICITED_TYPE"));
		dmDataDto.setOpptyExternalId(rs.getString("OPPTY_EXTERNAL_ID"));
		return dmDataDto;
	}


}

