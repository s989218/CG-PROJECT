package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSMetricsDataBean;

public class DollerByIBMetricsMapper implements RowMapper<FMSMetricsDataBean> {

	@Override
	public FMSMetricsDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSMetricsDataBean metricsDataDto = new FMSMetricsDataBean();
		
		metricsDataDto.setMetricsDataRegion(rs.getString("region"));
		metricsDataDto.setMetricsDataYear(rs.getString("year"));
		metricsDataDto.setMetricsDataQuarter(rs.getString("quarter"));
		String dollerByIBValue = rs.getString("dollar_by_ib_value");
		if(dollerByIBValue != null){
			metricsDataDto.setDollarByIBValue(Float.valueOf(rs.getString("dollar_by_ib_value")));
		}		
		return metricsDataDto;
	}


}

