package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSAccMgrEmailDropdownBean;


public class FMSAccMgrEmailDropdownMapper implements RowMapper<FMSAccMgrEmailDropdownBean> {

	@Override
	public FMSAccMgrEmailDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSAccMgrEmailDropdownBean accMgrEmailDropdownDto = new FMSAccMgrEmailDropdownBean();
		
		accMgrEmailDropdownDto.setcAccountMgrEmail(rs.getString("c_account_mgr_email"));
			
		return accMgrEmailDropdownDto;
	}


}

