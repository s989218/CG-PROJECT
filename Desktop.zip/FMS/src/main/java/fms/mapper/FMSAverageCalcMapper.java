package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSAverageCalcDTO;

public class FMSAverageCalcMapper implements RowMapper<FMSAverageCalcDTO>{
	@Override
	public FMSAverageCalcDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSAverageCalcDTO data = new FMSAverageCalcDTO();
		data.setRegion(rs.getString("region"));
		String avg = rs.getString("average");
		if(avg != null){
			data.setAverage(avg);
		}	
		return data;
	}
}
