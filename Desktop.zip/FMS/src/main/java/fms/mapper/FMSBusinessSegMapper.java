package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSBusinessSegDropdownBean;

public class FMSBusinessSegMapper implements RowMapper<FMSBusinessSegDropdownBean> {
	
	@Override
	public FMSBusinessSegDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSBusinessSegDropdownBean dropdownDto = new FMSBusinessSegDropdownBean();
		dropdownDto.setBusinessSegmentFilter(rs.getString("business_segment"));
		return dropdownDto;
	}

}

