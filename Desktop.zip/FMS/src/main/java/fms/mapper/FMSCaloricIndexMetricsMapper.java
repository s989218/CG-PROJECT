package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSCaloricIndexDataBean;

public class FMSCaloricIndexMetricsMapper implements RowMapper<FMSCaloricIndexDataBean> {

	@Override
	public FMSCaloricIndexDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSCaloricIndexDataBean metricsDataDto = new FMSCaloricIndexDataBean();
		
		metricsDataDto.setCalIndexDataRegion(rs.getString("region"));
		metricsDataDto.setCalIndexDataYear(rs.getString("year"));
		metricsDataDto.setCalIndexDataQuarter(rs.getString("quarter"));
		String caloricindex = rs.getString("caloric_index");
		if(caloricindex != null){
			metricsDataDto.setCaloricIndexValue(caloricindex);
		}		
		return metricsDataDto;
	}


}

