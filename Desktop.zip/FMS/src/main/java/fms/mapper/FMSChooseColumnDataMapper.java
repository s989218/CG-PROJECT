package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSChooseColumnDataDTO;



public class FMSChooseColumnDataMapper implements RowMapper<FMSChooseColumnDataDTO>{
	@Override
	public FMSChooseColumnDataDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSChooseColumnDataDTO col = new FMSChooseColumnDataDTO();
		col.setTableName(rs.getString("table_name"));
		col.setColumnName(rs.getString("column_name"));
		col.setDisplayName(rs.getString("display_name"));
		col.setActive(rs.getString("active_status"));
		col.setDisplayOrder(rs.getInt("display_order"));
		col.setChecked(rs.getInt("default_checked"));
		
		return col;
	}
}