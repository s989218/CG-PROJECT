package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSConversionIndexDataBean;

public class FMSConversionIndexMetricsMapper implements RowMapper<FMSConversionIndexDataBean> {

	@Override
	public FMSConversionIndexDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSConversionIndexDataBean metricsDataDto = new FMSConversionIndexDataBean();
		
		metricsDataDto.setConversionIndexRegion(rs.getString("region"));
		metricsDataDto.setConversionIndexYear(rs.getString("year"));
		metricsDataDto.setConversionIndexQuarter(rs.getString("quarter"));
		String conversionIndex = rs.getString("conversion_index");
		if(conversionIndex != null){
			metricsDataDto.setConversionIndexValue(conversionIndex);
		}		
		return metricsDataDto;
	}


}

