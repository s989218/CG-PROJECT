package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSCurrentQuarterDTO;


public class FMSCurrentQuarterMapper implements RowMapper<FMSCurrentQuarterDTO>{
	@Override
	public FMSCurrentQuarterDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSCurrentQuarterDTO data = new FMSCurrentQuarterDTO();
		data.setCurrentQuarter(rs.getString("current_quarter"));
		return data;
	}
}
