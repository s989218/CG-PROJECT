package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSCurrentYearDTO;


public class FMSCurrentYearMapper implements RowMapper<FMSCurrentYearDTO>{
	@Override
	public FMSCurrentYearDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSCurrentYearDTO data = new FMSCurrentYearDTO();
		data.setYearQtr(rs.getString("year_qtr"));
		return data;
	}
}
