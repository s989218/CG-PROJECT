package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSCustomerDropdownBean;


public class FMSCustomerDropdownMapper implements RowMapper<FMSCustomerDropdownBean> {

	@Override
	public FMSCustomerDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSCustomerDropdownBean customerDropdownDto = new FMSCustomerDropdownBean();
		
		customerDropdownDto.setCustomerName(rs.getString("cust_name"));
			
		return customerDropdownDto;
	}


}

