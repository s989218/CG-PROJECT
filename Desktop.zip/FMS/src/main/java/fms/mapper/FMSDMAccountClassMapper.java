package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSDMAccountClassDTO;

public class FMSDMAccountClassMapper implements RowMapper<FMSDMAccountClassDTO>{
	@Override
	public FMSDMAccountClassDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSDMAccountClassDTO data = new FMSDMAccountClassDTO();
		data.setAccountClass(rs.getString("global_account_class"));
		return data;
	}

}
