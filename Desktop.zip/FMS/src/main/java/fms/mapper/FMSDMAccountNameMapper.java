package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSDMAccountNameDTO;

public class FMSDMAccountNameMapper implements RowMapper<FMSDMAccountNameDTO>{
	@Override
	public FMSDMAccountNameDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSDMAccountNameDTO data = new FMSDMAccountNameDTO();
		data.setAccountName(rs.getString("end_user_account_name"));
		return data;
	}

}
