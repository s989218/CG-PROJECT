package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSDMAccountTypeDTO;

public class FMSDMAccountTypeMapper implements RowMapper<FMSDMAccountTypeDTO>{
	@Override
	public FMSDMAccountTypeDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSDMAccountTypeDTO data = new FMSDMAccountTypeDTO();
		data.setAccountType(rs.getString("global_account_type"));
				return data;
	}
}
