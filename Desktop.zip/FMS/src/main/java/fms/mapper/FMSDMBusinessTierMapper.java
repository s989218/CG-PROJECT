package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSDMBusinessTierDTO;

public class FMSDMBusinessTierMapper implements RowMapper<FMSDMBusinessTierDTO>{
	@Override
	public FMSDMBusinessTierDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSDMBusinessTierDTO data = new FMSDMBusinessTierDTO();
		data.setBusinessTier(rs.getString("business_tier_3"));
		return data;
	}

}
