package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSDMMetricsCustDataBean;

public class FMSDMCustMetricsCountryMapper implements RowMapper<FMSDMMetricsCustDataBean> {

	@Override
	public FMSDMMetricsCustDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSDMMetricsCustDataBean dmCntryDto = new FMSDMMetricsCustDataBean();
		
		dmCntryDto.setDcCountry(rs.getString("country"));
		dmCntryDto.setDcRegion(rs.getString("region"));
		dmCntryDto.setDcUserAccountName(rs.getString("end_user_account_name"));
		dmCntryDto.setDcCustomerCount(rs.getInt("cust_count"));
		dmCntryDto.setDcRegionId(rs.getInt("region_id"));
			
	return dmCntryDto;
	}
}

