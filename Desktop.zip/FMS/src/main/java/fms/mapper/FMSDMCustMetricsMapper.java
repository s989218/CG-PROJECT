package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSDMMetricsCustomerDTO;

public class FMSDMCustMetricsMapper implements RowMapper<FMSDMMetricsCustomerDTO>{
	@Override
	public FMSDMMetricsCustomerDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSDMMetricsCustomerDTO dmData = new FMSDMMetricsCustomerDTO();
		dmData.setDmcRegion(rs.getString("region"));
		dmData.setDmcUserAccountName(rs.getString("end_user_account_name"));
		dmData.setDmcCustomerCount(rs.getInt("cust_count"));
		dmData.setDmcRegionId(rs.getInt("region_id"));
		dmData.setDmcColorCode(rs.getString("color_code"));
		return dmData;
	}
}
