package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSDMForecastCategoryDTO;

public class FMSDMForecastCategoryMapper implements RowMapper<FMSDMForecastCategoryDTO>{
	@Override
	public FMSDMForecastCategoryDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSDMForecastCategoryDTO data = new FMSDMForecastCategoryDTO();
		data.setForecastCategory(rs.getString("forecast_category"));
		return data;
	}


}
