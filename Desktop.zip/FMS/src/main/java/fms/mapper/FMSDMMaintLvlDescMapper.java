package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSDMMaintLvlDescDTO;

public class FMSDMMaintLvlDescMapper implements RowMapper<FMSDMMaintLvlDescDTO>{

	@Override
	public FMSDMMaintLvlDescDTO mapRow(ResultSet rs, int row) throws SQLException {
		FMSDMMaintLvlDescDTO maintLvlDescDTO = new FMSDMMaintLvlDescDTO();
		maintLvlDescDTO.setDmMaintLvlDesc(rs.getString("maint_level_desc"));
		return maintLvlDescDTO;
	}

}
