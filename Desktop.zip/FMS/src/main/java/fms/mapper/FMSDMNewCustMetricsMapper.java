package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSDMMetricsCustDataBean;

public class FMSDMNewCustMetricsMapper implements RowMapper<FMSDMMetricsCustDataBean> {

	@Override
	public FMSDMMetricsCustDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSDMMetricsCustDataBean dmDataDto = new FMSDMMetricsCustDataBean();
				
		dmDataDto.setDcRegion(rs.getString("region"));
		dmDataDto.setDcUserAccountName(rs.getString("end_user_account_name"));
		dmDataDto.setDcCustomerCount(rs.getInt("dm_amt"));
		dmDataDto.setDcRegionId(rs.getInt("region_id"));
				
	return dmDataDto;
	}


}

