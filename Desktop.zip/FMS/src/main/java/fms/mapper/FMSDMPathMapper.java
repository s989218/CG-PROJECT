package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSDMPathDTO;

public class FMSDMPathMapper implements RowMapper<FMSDMPathDTO>{
	@Override
	public FMSDMPathDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSDMPathDTO data = new FMSDMPathDTO();
		data.setPath(rs.getString("deal_risk_path"));
		return data;
	}
}
