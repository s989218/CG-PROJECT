package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSDMPrimaryCountryDTO;

public class FMSDMPrimaryCountryMapper implements RowMapper<FMSDMPrimaryCountryDTO>{
	@Override
	public FMSDMPrimaryCountryDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSDMPrimaryCountryDTO data = new FMSDMPrimaryCountryDTO();
		data.setPrimaryCountry(rs.getString("primary_country"));
		return data;
	}

}
