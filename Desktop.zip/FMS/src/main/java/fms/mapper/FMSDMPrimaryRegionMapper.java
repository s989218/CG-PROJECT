package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSDMPrimaryRegionDTO;

public class FMSDMPrimaryRegionMapper implements RowMapper<FMSDMPrimaryRegionDTO>{
	@Override
	public FMSDMPrimaryRegionDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSDMPrimaryRegionDTO data = new FMSDMPrimaryRegionDTO();
		data.setPrimaryRegion(rs.getString("primary_region"));
		return data;
	}

}
