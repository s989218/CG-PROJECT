package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSDMQtrDTO;

public class FMSDMQtrMapper implements RowMapper<FMSDMQtrDTO>{
	@Override
	public FMSDMQtrDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSDMQtrDTO data = new FMSDMQtrDTO();
		data.setQtr(rs.getString("convertible_this_qtr"));
		return data;
	}

}
