package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSDMMetricsTechDataBean;

public class FMSDMTechMetricsCountryMapper implements RowMapper<FMSDMMetricsTechDataBean> {

	@Override
	public FMSDMMetricsTechDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSDMMetricsTechDataBean dmDataDto = new FMSDMMetricsTechDataBean();
		
		dmDataDto.setDmTechRegion(rs.getString("region"));
		dmDataDto.setDmTechOpptyType(rs.getString("oppty_type"));
		dmDataDto.setDmTechDmAmount(rs.getInt("cust_count"));
		dmDataDto.setDmTechRegionId(rs.getInt("region_id"));
		dmDataDto.setDmTechColorCode(rs.getString("color_code"));
		dmDataDto.setDmTechCountry(rs.getString("country"));
		
		
	return dmDataDto;
	}
}

