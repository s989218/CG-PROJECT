package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSDMMetricsTechDTO;

public class FMSDMTechMetricsMapper implements RowMapper<FMSDMMetricsTechDTO>{
	@Override
	public FMSDMMetricsTechDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSDMMetricsTechDTO dmData = new FMSDMMetricsTechDTO();
		dmData.setdTechRegion(rs.getString("region"));
		dmData.setdTechOpptyType(rs.getString("oppty_type"));
		dmData.setdTechDmAmount(rs.getInt("dm_amt"));
		dmData.setdTechColorCode(rs.getString("color_code"));
		return dmData;	
	}
}
