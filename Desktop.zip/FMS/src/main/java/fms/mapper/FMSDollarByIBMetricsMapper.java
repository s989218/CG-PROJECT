package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSDollarByIBDataBean;

public class FMSDollarByIBMetricsMapper implements RowMapper<FMSDollarByIBDataBean> {

	@Override
	public FMSDollarByIBDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSDollarByIBDataBean metricsDataDto = new FMSDollarByIBDataBean();
		
		metricsDataDto.setDollarByIBRegion(rs.getString("region"));
		metricsDataDto.setDollarByIBYear(rs.getString("year"));
		metricsDataDto.setDollarByIBQuarter(rs.getString("quarter"));
		String dollarByIBVal = rs.getString("dollar_by_ib");
		if(dollarByIBVal != null){
			metricsDataDto.setDollarByIBValue(dollarByIBVal);
		}		
		return metricsDataDto;
	}


}

