package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSEndUserNameDropdownBean;


public class FMSEndUserNameDropdownMapper implements RowMapper<FMSEndUserNameDropdownBean> {

	@Override
	public FMSEndUserNameDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSEndUserNameDropdownBean dropdownDto = new FMSEndUserNameDropdownBean();
		
		dropdownDto.setEndUserName(rs.getString("end_user_name"));
			
		return dropdownDto;
	}


}

