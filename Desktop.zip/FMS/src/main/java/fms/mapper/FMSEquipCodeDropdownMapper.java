package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSEquipCodeDropdownBean;


public class FMSEquipCodeDropdownMapper implements RowMapper<FMSEquipCodeDropdownBean> {

	@Override
	public FMSEquipCodeDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSEquipCodeDropdownBean dropdownDto = new FMSEquipCodeDropdownBean();
		
		dropdownDto.setEquipCode(rs.getString("c_equipment_code"));
			
		return dropdownDto;
	}


}

