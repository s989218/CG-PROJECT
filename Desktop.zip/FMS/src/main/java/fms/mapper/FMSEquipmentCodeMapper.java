package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSEquipmentCodeDropdownBean;


public class FMSEquipmentCodeMapper implements RowMapper<FMSEquipmentCodeDropdownBean> {
	
	@Override
	public FMSEquipmentCodeDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSEquipmentCodeDropdownBean dropdownDto = new FMSEquipmentCodeDropdownBean();
		dropdownDto.setEquipmentCodeFilter(rs.getString("c_equipment_code"));
		return dropdownDto;
	}

}
