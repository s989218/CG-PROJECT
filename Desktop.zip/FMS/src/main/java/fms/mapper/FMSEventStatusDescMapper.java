package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSMaintLvlStatusBean;

public class FMSEventStatusDescMapper implements RowMapper<FMSMaintLvlStatusBean>{

	@Override
	public FMSMaintLvlStatusBean mapRow(ResultSet rs, int row) throws SQLException {
		FMSMaintLvlStatusBean data = new FMSMaintLvlStatusBean();
		data.setoEventStatusDesc(rs.getString("c_event_status_desc"));
		return data;
	}

}
