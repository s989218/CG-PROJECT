package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSFltPenetartionF2FDataBean;

public class FMSFleetPenF2FMetricsMapper implements RowMapper<FMSFltPenetartionF2FDataBean> {

	@Override
	public FMSFltPenetartionF2FDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSFltPenetartionF2FDataBean metricsDataDto = new FMSFltPenetartionF2FDataBean();
		
		metricsDataDto.setFltPenFFRegion(rs.getString("region"));
		metricsDataDto.setYear(rs.getString("year"));
		metricsDataDto.setQuarter(rs.getString("quarter"));
		String fltPenF2FValue = rs.getString("fleet_pen_f2f");
		if(fltPenF2FValue != null){
			metricsDataDto.setFleetPenF2FValue(fltPenF2FValue);
		}		
		return metricsDataDto;
	}


}

