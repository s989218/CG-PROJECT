package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSIBASQuarterYearDTO;

public class FMSIBASQuarterYearMapper implements RowMapper<FMSIBASQuarterYearDTO> {

	@Override
	public FMSIBASQuarterYearDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIBASQuarterYearDTO quarterYearDTO = new FMSIBASQuarterYearDTO();
		quarterYearDTO.setYear(rs.getInt("year"));
		quarterYearDTO.setQuarter(rs.getString("quarter"));
				
		return quarterYearDTO;
	}

}

