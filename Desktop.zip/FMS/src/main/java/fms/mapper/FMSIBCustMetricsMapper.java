package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSIBMetricsCustDataBean;

public class FMSIBCustMetricsMapper implements RowMapper<FMSIBMetricsCustDataBean> {

	@Override
	public FMSIBMetricsCustDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIBMetricsCustDataBean ibDataDto = new FMSIBMetricsCustDataBean();
		
		ibDataDto.setRegion(rs.getString("region"));
		ibDataDto.setCustName(rs.getString("ge_duns_name"));
		ibDataDto.setCustNameCount(rs.getString("cust_count"));
		ibDataDto.setRegId(rs.getString("reg_id"));
		ibDataDto.setTechnologyIB(rs.getString("c_technology_desc_og"));
		ibDataDto.setTechCountIB(rs.getString("tech_cnt"));
		ibDataDto.setCustColorCodeIB(rs.getString("color_code"));
		
	return ibDataDto;
	}


}

