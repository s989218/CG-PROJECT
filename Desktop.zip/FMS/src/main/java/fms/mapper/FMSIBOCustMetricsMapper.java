package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSIBOMetricsCustDataBean;

public class FMSIBOCustMetricsMapper implements RowMapper<FMSIBOMetricsCustDataBean> {

	@Override
	public FMSIBOMetricsCustDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIBOMetricsCustDataBean ordersDataDto = new FMSIBOMetricsCustDataBean();
		
		ordersDataDto.setiBCustRegion(rs.getString("region"));
		ordersDataDto.setGeDunsName(rs.getString("ge_duns_name"));
		ordersDataDto.setiBCustAvtotSum(rs.getString("cust_avtot_sum"));
		ordersDataDto.setiBCustRegionId(rs.getString("reg_id"));
		ordersDataDto.setTechnologyIBO(rs.getString("c_technology_desc_og"));
		ordersDataDto.setTechSumIBO(rs.getString("tech_avtot_sum"));
		ordersDataDto.setCustColorCodeIBO(rs.getString("color_code"));
	return ordersDataDto;
	}


}

