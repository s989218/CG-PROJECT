package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSIBOMetricsTechDataBean;

public class FMSIBOTechMetricsCountryMapper implements RowMapper<FMSIBOMetricsTechDataBean> {

	@Override
	public FMSIBOMetricsTechDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIBOMetricsTechDataBean ordersDataDto = new FMSIBOMetricsTechDataBean();
		
		ordersDataDto.setiBTchRegion(rs.getString("region"));
		ordersDataDto.setiBTechAvtotSum(rs.getString("avtot_sum"));
		ordersDataDto.setiBTechnologyDes(rs.getString("c_technology_desc_og"));
		ordersDataDto.setiBTechRegionId(rs.getString("reg_id"));
		ordersDataDto.setiBTechCountry(rs.getString("c_site_customer_country"));
		ordersDataDto.setiBColorCode(rs.getString("color_code"));
		
	return ordersDataDto;
	}


}

