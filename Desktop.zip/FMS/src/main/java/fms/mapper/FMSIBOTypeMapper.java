package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSIBOTypeDropdownBean;

public class FMSIBOTypeMapper implements RowMapper<FMSIBOTypeDropdownBean> {
	
	@Override
	public FMSIBOTypeDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIBOTypeDropdownBean dropdownDto = new FMSIBOTypeDropdownBean();
		dropdownDto.setIboType(rs.getString("ibo_type"));
		return dropdownDto;
	}

}