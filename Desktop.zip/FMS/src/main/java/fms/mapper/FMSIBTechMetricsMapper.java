package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSIBMetricsTechDataBean;

public class FMSIBTechMetricsMapper implements RowMapper<FMSIBMetricsTechDataBean> {

	@Override
	public FMSIBMetricsTechDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIBMetricsTechDataBean ibDataDto = new FMSIBMetricsTechDataBean();

		ibDataDto.setmTechRegion(rs.getString("region"));
		ibDataDto.setmTechTechnology(rs.getString("c_technology_desc_og"));
		ibDataDto.setmTechTechnologyCount(rs.getString("tech_count"));
		ibDataDto.setmTechRegId(rs.getString("reg_id"));
		ibDataDto.setColorCode(rs.getString("color_code"));

		return ibDataDto;
	}


}

