package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSIBNoByTechDataBean;


public class FMSIbNoByTechMetricsMapper implements RowMapper<FMSIBNoByTechDataBean> {

	@Override
	public FMSIBNoByTechDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIBNoByTechDataBean metricsDataDto = new FMSIBNoByTechDataBean();
		
		metricsDataDto.setTechDesc(rs.getString("tech_desc"));
		metricsDataDto.setTechYear(rs.getString("year"));
		metricsDataDto.setTechQuarter(rs.getString("quarter"));
		String ibNoByTechValue = rs.getString("ib_by_tech");
		if(ibNoByTechValue != null){
			metricsDataDto.setIbNoByTechnology(ibNoByTechValue);
		}		
		return metricsDataDto;
	}


}

