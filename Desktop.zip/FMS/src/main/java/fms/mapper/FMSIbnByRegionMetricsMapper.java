package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSIBNByRegionDataBean;


public class FMSIbnByRegionMetricsMapper implements RowMapper<FMSIBNByRegionDataBean> {

	@Override
	public FMSIBNByRegionDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIBNByRegionDataBean metricsDataDto = new FMSIBNByRegionDataBean();
		
		metricsDataDto.setRegion(rs.getString("region"));
		metricsDataDto.setRegionYear(rs.getString("year"));
		metricsDataDto.setRegionQuarter(rs.getString("quarter"));
		String ibnByRegValue = rs.getString("ib_by_region");
		if(ibnByRegValue != null){
			metricsDataDto.setIbByRegion(ibnByRegValue);
		}		
		return metricsDataDto;
	}
}

