package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSIBOByRegionDataBean;

public class FMSIboByRegionMetricsMapper implements RowMapper<FMSIBOByRegionDataBean> {

	@Override
	public FMSIBOByRegionDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIBOByRegionDataBean metricsDataDto = new FMSIBOByRegionDataBean();
		
		metricsDataDto.setIboRegion(rs.getString("region"));
		metricsDataDto.setIboYear(rs.getString("year"));
		metricsDataDto.setIboQuarter(rs.getString("quarter"));
		String iboByRegValue = rs.getString("ibo_by_region");
		if(iboByRegValue != null){
			metricsDataDto.setIboByRegionValue(iboByRegValue);
		}		
		return metricsDataDto;
	}


}

