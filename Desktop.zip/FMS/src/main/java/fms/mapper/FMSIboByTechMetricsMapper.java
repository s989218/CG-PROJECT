package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSIBOByTechDataBean;


public class FMSIboByTechMetricsMapper implements RowMapper<FMSIBOByTechDataBean> {

	@Override
	public FMSIBOByTechDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIBOByTechDataBean metricsDataDto = new FMSIBOByTechDataBean();
		
		metricsDataDto.setTechDesc(rs.getString("tech_desc"));
		metricsDataDto.setYear(rs.getString("year"));
		metricsDataDto.setQuarter(rs.getString("quarter"));
		String iboByTechValue = rs.getString("ibo_by_tech");
		if(iboByTechValue != null){
			metricsDataDto.setIboByTechnology(iboByTechValue);
		}		
		return metricsDataDto;
	}


}

