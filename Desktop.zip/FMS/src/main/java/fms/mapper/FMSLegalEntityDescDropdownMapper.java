package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSLegalEntityDescDropdownBean;


public class FMSLegalEntityDescDropdownMapper implements RowMapper<FMSLegalEntityDescDropdownBean> {

	@Override
	public FMSLegalEntityDescDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSLegalEntityDescDropdownBean dropdownDto = new FMSLegalEntityDescDropdownBean();
		
		dropdownDto.setLegalEntityDesc(rs.getString("legal_entity"));
			
		return dropdownDto;
	}


}

