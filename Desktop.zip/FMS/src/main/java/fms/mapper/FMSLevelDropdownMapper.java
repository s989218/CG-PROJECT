package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSLevelDropdownBean;


public class FMSLevelDropdownMapper implements RowMapper<FMSLevelDropdownBean> {

	@Override
	public FMSLevelDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSLevelDropdownBean levelDropdownDto = new FMSLevelDropdownBean();
		
		levelDropdownDto.setLevel(rs.getString("level"));
			
		return levelDropdownDto;
	}


}

