package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSMaintPolicyCodeDropdownBean;


public class FMSMaintPolicyCodeDropdownMapper implements RowMapper<FMSMaintPolicyCodeDropdownBean> {

	@Override
	public FMSMaintPolicyCodeDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSMaintPolicyCodeDropdownBean dropdownDto = new FMSMaintPolicyCodeDropdownBean();
		
		dropdownDto.setMaintPolicyCode(rs.getString("c_maint_policy_cod"));
			
		return dropdownDto;
	}


}

