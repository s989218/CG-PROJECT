package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSMarketSegmentDescDropdownBean;


public class FMSMarketSegmentDropdownMapper implements RowMapper<FMSMarketSegmentDescDropdownBean> {

	@Override
	public FMSMarketSegmentDescDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSMarketSegmentDescDropdownBean dropdownDto = new FMSMarketSegmentDescDropdownBean();
		
		dropdownDto.setMarketSegmentDesc(rs.getString("c_market_segment_desc"));
			
		return dropdownDto;
	}


}

