package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSAllMetricsDataBean;

public class FMSMetricsMapper implements RowMapper<FMSAllMetricsDataBean> {

	@Override
	public FMSAllMetricsDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSAllMetricsDataBean metricsDataDto = new FMSAllMetricsDataBean();
		
		
		String coverageValue = rs.getString("fleet_coverage");
		String penetrationValue = rs.getString("fleet_penetration");
		String fltPenF2FValue = rs.getString("fleet_pen_f2f");
		String caloricIndexValue = rs.getString("caloric_index");
		String conversionIndexValue = rs.getString("conversion_index");
		String dollerByIBValue = rs.getString("dollar_by_ib");
		String iboByRegionValue = rs.getString("ibo_by_region");
		String revDolrbyRegionValue = rs.getString("rev_dollar_by_region");
		
		metricsDataDto.setAllMetricsDataRegion(rs.getString("region"));
		metricsDataDto.setAllMetricsDataYear(rs.getString("year"));
		metricsDataDto.setAllMetricsDataQuarter(rs.getString("quarter"));
				
		if(coverageValue != null){
			metricsDataDto.setCoverageValue(coverageValue);
		}
		if(penetrationValue != null){
			metricsDataDto.setPenetrationValue(penetrationValue);
		}
		if(fltPenF2FValue != null){
			metricsDataDto.setFleetPenF2FValue(fltPenF2FValue);
		}	
		if(caloricIndexValue != null){
			metricsDataDto.setCaloricIndexValue(caloricIndexValue);
		}
		if(conversionIndexValue != null){
			metricsDataDto.setConversionIndexValue(conversionIndexValue);
		}
		if(dollerByIBValue != null){
			metricsDataDto.setDollarByIBValue(dollerByIBValue);
		}
		if(iboByRegionValue != null){
			metricsDataDto.setIboByRegionValue(iboByRegionValue);
		}		
		if(revDolrbyRegionValue != null){
			metricsDataDto.setRevDollarByRegionValue(revDolrbyRegionValue);
		}
		
		return metricsDataDto;
	}


}

