package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSCurrentQuarterDTO;
import fms.bean.FMSOpptyExternalIdDTO;


public class FMSOpptyExternalIdMapper implements RowMapper<FMSOpptyExternalIdDTO>{
	@Override
	public FMSOpptyExternalIdDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSOpptyExternalIdDTO data = new FMSOpptyExternalIdDTO();
		data.setOpptyExternalId(rs.getString("OPPTY_EXTERNAL_ID"));
		return data;
	}
}
