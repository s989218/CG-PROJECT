package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSSiteCustomerNameDropdownBean;

public class FMSOrderMetricsCustomerNameMapper implements RowMapper<FMSSiteCustomerNameDropdownBean> {

	@Override
	public FMSSiteCustomerNameDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSSiteCustomerNameDropdownBean siteCustomerNameDropdownBean = new FMSSiteCustomerNameDropdownBean();
		siteCustomerNameDropdownBean.setCustomerName(rs.getString("ge_duns_name"));
		return siteCustomerNameDropdownBean;
	}
}
