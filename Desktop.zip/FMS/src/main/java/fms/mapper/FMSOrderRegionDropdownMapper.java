package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSOrderRegionDropdownBean;


public class FMSOrderRegionDropdownMapper implements RowMapper<FMSOrderRegionDropdownBean> {

	@Override
	public FMSOrderRegionDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSOrderRegionDropdownBean regionDropdownDto = new FMSOrderRegionDropdownBean();
		
		regionDropdownDto.setOrderRegion(rs.getString("c_og_sales_region"));
		regionDropdownDto.setOrderRegionId(rs.getString("region_id"));
		return regionDropdownDto;
	}


}

