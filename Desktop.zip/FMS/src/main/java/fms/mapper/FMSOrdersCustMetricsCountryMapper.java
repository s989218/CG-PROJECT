package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSOrdersMetricsCustDataBean;

public class FMSOrdersCustMetricsCountryMapper implements RowMapper<FMSOrdersMetricsCustDataBean> {

	@Override
	public FMSOrdersMetricsCustDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSOrdersMetricsCustDataBean ordersDataDto = new FMSOrdersMetricsCustDataBean();
		
		ordersDataDto.setOrderCustRegion(rs.getString("region"));
		ordersDataDto.setOrderCustEndUserName(rs.getString("end_user_name"));
		ordersDataDto.setOrderCustOrdersSum(rs.getString("cust_order_sum"));
		ordersDataDto.setOrderCustCountry(rs.getString("country"));
		ordersDataDto.setOrderCustTechnology(rs.getString("pm_product_mapping"));
		ordersDataDto.setOrderCustTechOrderSum(rs.getString("tech_order_sum"));
		ordersDataDto.setOrderCustColorCode(rs.getString("color_code"));
	return ordersDataDto;
	}


}

