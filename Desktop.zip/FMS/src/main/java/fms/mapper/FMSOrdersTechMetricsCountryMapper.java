package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSOrdersMetricsTechDataBean;

public class FMSOrdersTechMetricsCountryMapper implements RowMapper<FMSOrdersMetricsTechDataBean> {

	@Override
	public FMSOrdersMetricsTechDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSOrdersMetricsTechDataBean ordersDataDto = new FMSOrdersMetricsTechDataBean();
		
		ordersDataDto.setOrderTechRegion(rs.getString("region"));
		ordersDataDto.setOrderTechProduct(rs.getString("product"));
		ordersDataDto.setOrderTechOrdersSum(rs.getString("order_sum"));
		ordersDataDto.setOrderTechRegionId(rs.getString("reg_id"));
		ordersDataDto.setOrderTechCountry(rs.getString("country"));
		ordersDataDto.setOrderColorCode(rs.getString("color_code"));
	return ordersDataDto;
	}


}

