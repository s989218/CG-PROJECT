package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSOutLocationDTO;


public class FMSOutLocationMapper implements RowMapper<FMSOutLocationDTO> {

	@Override
	public FMSOutLocationDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSOutLocationDTO dropdownDto = new FMSOutLocationDTO();
		dropdownDto.setLoactionDesc(rs.getString("c_oem_location_desc"));
		return dropdownDto;
	}
}
