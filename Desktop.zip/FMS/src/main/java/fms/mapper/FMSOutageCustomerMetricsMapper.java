package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSOutageMetricsCustomerDTO;

public class FMSOutageCustomerMetricsMapper implements RowMapper<FMSOutageMetricsCustomerDTO> {

	@Override
	public FMSOutageMetricsCustomerDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSOutageMetricsCustomerDTO outageCustDto = new FMSOutageMetricsCustomerDTO();

		outageCustDto.setOcRegion(rs.getString("region"));
		outageCustDto.setOcCustomerName(rs.getString("ge_duns_name"));
		outageCustDto.setOcOutages(rs.getInt("cust_count"));
		outageCustDto.setOcRegId(rs.getInt("reg_id"));
		outageCustDto.setOcTechDesc(rs.getString("c_technology_desc_og"));
		outageCustDto.setOcTechCount(rs.getInt("tech_cnt"));
		outageCustDto.setOcColorCode(rs.getString("color_code"));
		return outageCustDto;	
	}
}