package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSOutageFilterCustDTO;

public class FMSOutageFilterCustCountryMapper implements RowMapper<FMSOutageFilterCustDTO> {

	@Override
	public FMSOutageFilterCustDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSOutageFilterCustDTO dataDto = new FMSOutageFilterCustDTO();
		dataDto.setOfCountry(rs.getString("country"));
		dataDto.setOfRegion(rs.getString("region"));
		dataDto.setOfCustomerName(rs.getString("ge_duns_name"));
		dataDto.setOfOutages(rs.getString("cust_count"));
		dataDto.setOfRegId(rs.getString("region_id"));
		dataDto.setOfTechDesc(rs.getString("c_technology_desc_og"));
		dataDto.setOfTechCount(rs.getInt("tech_cnt"));
		dataDto.setOfColorCode(rs.getString("color_code"));

		return dataDto;
	}


}
