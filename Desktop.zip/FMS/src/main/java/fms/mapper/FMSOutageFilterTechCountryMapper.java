package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSOutageFilterTechDTO;

public class FMSOutageFilterTechCountryMapper implements RowMapper<FMSOutageFilterTechDTO> {

	@Override
	public FMSOutageFilterTechDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSOutageFilterTechDTO dataDto = new FMSOutageFilterTechDTO();

		dataDto.setOtRegion(rs.getString("region"));
		dataDto.setOtTech(rs.getString("tech"));
		dataDto.setOtOutages(rs.getString("outages"));
		dataDto.setOtRegId(rs.getString("region_id"));
		dataDto.setOtColorCode(rs.getString("color_code"));
		dataDto.setOtCountry(rs.getString("country"));

		return dataDto;
	}


}

