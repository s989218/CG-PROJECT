package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSOutageMetricsTechDTO;

public class FMSOutageTechMetricsMapper implements RowMapper<FMSOutageMetricsTechDTO> {

	@Override
	public FMSOutageMetricsTechDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSOutageMetricsTechDTO outageTechDto = new FMSOutageMetricsTechDTO();

		outageTechDto.setOrRegion(rs.getString("region"));
		outageTechDto.setOrTech(rs.getString("tech"));
		outageTechDto.setOrTotalOutages(rs.getInt("totaloutages"));
		outageTechDto.setOrColorCode(rs.getString("color_code"));
		return outageTechDto;	
	}
}