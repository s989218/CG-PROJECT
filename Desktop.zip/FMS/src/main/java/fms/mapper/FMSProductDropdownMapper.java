package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSProductDropdownBean;


public class FMSProductDropdownMapper implements RowMapper<FMSProductDropdownBean> {

	@Override
	public FMSProductDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSProductDropdownBean dropdownDto = new FMSProductDropdownBean();
		
		dropdownDto.setProduct(rs.getString("product"));
			
		return dropdownDto;
	}


}

