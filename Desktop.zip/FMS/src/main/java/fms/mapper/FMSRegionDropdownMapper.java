package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSRegionDropdownBean;


public class FMSRegionDropdownMapper implements RowMapper<FMSRegionDropdownBean> {

	@Override
	public FMSRegionDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSRegionDropdownBean regionDropdownDto = new FMSRegionDropdownBean();
		
		regionDropdownDto.setRegion(rs.getString("c_og_sales_region"));
			
		return regionDropdownDto;
	}


}

