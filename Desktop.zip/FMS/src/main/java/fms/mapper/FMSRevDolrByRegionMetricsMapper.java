package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSRevDollarByRegDataBean;

public class FMSRevDolrByRegionMetricsMapper implements RowMapper<FMSRevDollarByRegDataBean> {

	@Override
	public FMSRevDollarByRegDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSRevDollarByRegDataBean metricsDataDto = new FMSRevDollarByRegDataBean();
		
		metricsDataDto.setRevDollarByRegion(rs.getString("region"));
		metricsDataDto.setRevDollarByRegionYear(rs.getString("year"));
		metricsDataDto.setRevDollarByRegionQuarter(rs.getString("quarter"));
		String revByRegValue = rs.getString("rev_dollar_by_region");
		if(revByRegValue != null){
			metricsDataDto.setRevDollarByRegionValue(revByRegValue);
		}		
		return metricsDataDto;
	}


}


