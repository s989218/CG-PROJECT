package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSInstalledBaseDataBean;

public class FMSSerialInformationMapper implements RowMapper<FMSInstalledBaseDataBean> {

	@Override
	public FMSInstalledBaseDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSInstalledBaseDataBean ibDataDto = new FMSInstalledBaseDataBean();
		
		ibDataDto.setSerialNumber(rs.getString("c_gib_serial_number"));
		ibDataDto.setTechnologyDescOG(rs.getString("c_technology_desc_og"));	
		ibDataDto.setTechDesc(rs.getString("c_technology_desc"));
		ibDataDto.setMaintPolicyCOD(rs.getString("c_maint_policy_cod"));
		ibDataDto.setOemLocationDesc(rs.getString("c_oem_location_desc"));
		ibDataDto.setUnitRating(rs.getString("unit_rating"));
		ibDataDto.setUnitSpeedRPM(rs.getString("n_unit_speed_rpm"));
		ibDataDto.setControlSystemDesc(rs.getString("c_control_system_desc"));
		ibDataDto.setDrivenEquipDesc(rs.getString("c_driven_equipment_desc"));
		ibDataDto.setCombustionSystemDesc(rs.getString("c_combustion_system_desc"));
		ibDataDto.setPrimaryFuelTypeDesc(rs.getString("c_primary_fuel_type_desc"));
		
		
	return ibDataDto;
	}


}

