package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSServRelDescOngDropdownBean;


public class FMSServRelDescDropdownMapper implements RowMapper<FMSServRelDescOngDropdownBean> {

	@Override
	public FMSServRelDescOngDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSServRelDescOngDropdownBean dropdownDto = new FMSServRelDescOngDropdownBean();
		
		dropdownDto.setServRelationDescOng(rs.getString("c_service_relation_desc_og"));
			
		return dropdownDto;
	}


}

