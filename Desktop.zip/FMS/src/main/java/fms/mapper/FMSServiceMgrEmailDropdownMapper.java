package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSServiceMgrEmailDropdownBean;


public class FMSServiceMgrEmailDropdownMapper implements RowMapper<FMSServiceMgrEmailDropdownBean> {

	@Override
	public FMSServiceMgrEmailDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

	FMSServiceMgrEmailDropdownBean serviceMgrEmailDropdownDto = new FMSServiceMgrEmailDropdownBean();
		
	serviceMgrEmailDropdownDto.setcServiceMgrEmail(rs.getString("c_service_mgr_email"));
			
		return serviceMgrEmailDropdownDto;
	}


}

