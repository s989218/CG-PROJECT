package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSServiceTypeDropdownBean;


public class FMSServiceTypeDropdownMapper implements RowMapper<FMSServiceTypeDropdownBean> {

	@Override
	public FMSServiceTypeDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSServiceTypeDropdownBean dropdownDto = new FMSServiceTypeDropdownBean();
		
		dropdownDto.setServiceType(rs.getString("service_type"));
			
		return dropdownDto;
	}


}

