package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSSiteCustCountryDropdownBean;


public class FMSSiteCustCountryDropdownMapper implements RowMapper<FMSSiteCustCountryDropdownBean> {

	@Override
	public FMSSiteCustCountryDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSSiteCustCountryDropdownBean dropdownDto = new FMSSiteCustCountryDropdownBean();
		
		dropdownDto.setSiteCustCountry(rs.getString("c_site_customer_country"));
			
		return dropdownDto;
	}


}

