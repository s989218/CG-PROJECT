package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSSiteCustomerNameDropdownBean;

public class FMSSiteCustomerNameMapper implements RowMapper<FMSSiteCustomerNameDropdownBean> {

	@Override
	public FMSSiteCustomerNameDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSSiteCustomerNameDropdownBean dropdownDto = new FMSSiteCustomerNameDropdownBean();
		dropdownDto.setCustomerName(rs.getString("c_site_customer_name"));
		return dropdownDto;
	}


}