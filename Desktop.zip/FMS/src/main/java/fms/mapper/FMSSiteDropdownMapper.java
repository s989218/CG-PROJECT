package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSSiteDropdownBean;


public class FMSSiteDropdownMapper implements RowMapper<FMSSiteDropdownBean> {

	@Override
	public FMSSiteDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSSiteDropdownBean siteDropdownDto = new FMSSiteDropdownBean();
		
		siteDropdownDto.setSiteName((rs.getString("c_site_customer_name")==null?"":rs.getString("c_site_customer_name"))+" "+(rs.getString("c_site_name_alias")==null?"":rs.getString("c_site_name_alias")));
			
		return siteDropdownDto;
	}


}

