package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSSiteCustomerNameDropdownBean;
import fms.bean.FMSSiteNameAliasDropdownBean;

public class FMSSiteNameAliasMapper implements RowMapper<FMSSiteNameAliasDropdownBean> {

	@Override
	public FMSSiteNameAliasDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSSiteNameAliasDropdownBean dropdownDto = new FMSSiteNameAliasDropdownBean();
		dropdownDto.setSiteNameAlias(rs.getString("c_site_name_alias"));
		return dropdownDto;
	}


}