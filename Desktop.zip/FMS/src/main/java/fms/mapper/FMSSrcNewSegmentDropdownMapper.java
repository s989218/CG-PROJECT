package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSSrcNewSegmentDropdownBean;


public class FMSSrcNewSegmentDropdownMapper implements RowMapper<FMSSrcNewSegmentDropdownBean> {

	@Override
	public FMSSrcNewSegmentDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSSrcNewSegmentDropdownBean dropdownDto = new FMSSrcNewSegmentDropdownBean();
		
		dropdownDto.setSrcNewSegment(rs.getString("segment"));
			
		return dropdownDto;
	}


}

