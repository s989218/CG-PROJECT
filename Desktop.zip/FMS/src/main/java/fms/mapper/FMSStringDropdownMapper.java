package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSStringDropdownBean;
import fms.constants.FMSVariableConstants;


public class FMSStringDropdownMapper implements RowMapper<FMSStringDropdownBean> {
	String strDDVal;
	public FMSStringDropdownMapper(Object objVal) {
		strDDVal = objVal.toString();
	}

	@Override
	public FMSStringDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSStringDropdownBean dropdownDto = new FMSStringDropdownBean();
		switch (strDDVal) {
		case FMSVariableConstants.OEM_LOC:
			dropdownDto.setStrColumn(rs.getString("c_oem_location_desc"));
			break;
			
		case FMSVariableConstants.SITE_CUST_DUNS_NAME:
			dropdownDto.setStrColumn(rs.getString("c_site_customer_duns"));
			break;
			
		case FMSVariableConstants.SITE_CUST_ALIAS:
			dropdownDto.setStrColumn(rs.getString("c_site_name_alias"));
			break;
			
		case FMSVariableConstants.SM_SEGMENT_MAPPING:
			dropdownDto.setStrColumn(rs.getString("sm_segment_mapping"));
			break;
			
		case FMSVariableConstants.PM_PRODUCT_MAPPING:
			dropdownDto.setStrColumn(rs.getString("pm_product_mapping"));
			break;
			
		case FMSVariableConstants.ME_TIER4:
			dropdownDto.setStrColumn(rs.getString("me_tier_4"));
			break;
			
		case FMSVariableConstants.ME_DM_TIER3:
			dropdownDto.setStrColumn(rs.getString("me_dm_tier_3"));
			break;
			
		case FMSVariableConstants.MARKET:
			dropdownDto.setStrColumn(rs.getString("c_market_segment_desc"));
			break;

		default:
			break;
		}
		
			
		return dropdownDto;
	}


}

