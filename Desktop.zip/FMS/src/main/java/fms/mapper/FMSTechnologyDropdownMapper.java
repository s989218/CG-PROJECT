package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSTechnologyDropdownBean;


public class FMSTechnologyDropdownMapper implements RowMapper<FMSTechnologyDropdownBean> {

	@Override
	public FMSTechnologyDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSTechnologyDropdownBean technologyDropdownDto = new FMSTechnologyDropdownBean();
		
		technologyDropdownDto.setTechnology(rs.getString("c_technology_desc_og"));
			
		return technologyDropdownDto;
	}


}

