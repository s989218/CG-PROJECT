package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSTier3DropdownBean;


public class FMSTier3DropdownMapper implements RowMapper<FMSTier3DropdownBean> {

	@Override
	public FMSTier3DropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSTier3DropdownBean dropdownDto = new FMSTier3DropdownBean();
		
		dropdownDto.setTeir3(rs.getString("tier_3"));
			
		return dropdownDto;
	}


}

