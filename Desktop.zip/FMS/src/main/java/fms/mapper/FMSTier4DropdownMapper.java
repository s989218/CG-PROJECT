package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSTier4DropdownBean;


public class FMSTier4DropdownMapper implements RowMapper<FMSTier4DropdownBean> {

	@Override
	public FMSTier4DropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSTier4DropdownBean dropdownDto = new FMSTier4DropdownBean();
		
		dropdownDto.setTier4(rs.getString("tier_4"));
			
		return dropdownDto;
	}


}

