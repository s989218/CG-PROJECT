package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSUnitStatusDesDropdownBean;


public class FMSUnitStatusDropdownMapper implements RowMapper<FMSUnitStatusDesDropdownBean> {

	@Override
	public FMSUnitStatusDesDropdownBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSUnitStatusDesDropdownBean dropdownDto = new FMSUnitStatusDesDropdownBean();
		
		dropdownDto.setUnitStatusDesc(rs.getString("c_unit_status_desc"));
			
		return dropdownDto;
	}


}

