package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSUserBean;



public class FMSUserMapper implements RowMapper<FMSUserBean> {
	@Override
	public FMSUserBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSUserBean userBean = new FMSUserBean();
		
		userBean.setUserId(rs.getString("user_id"));
		userBean.setUserFirstName(rs.getString("first_name"));
		userBean.setUserLastName(rs.getString("last_name"));
		userBean.setUserEmailId(rs.getString("email_id"));
		userBean.setUserActiveFlag(rs.getString("active"));
		userBean.setUserCrtdBy(rs.getString("created_by"));
		userBean.setUserCrtdDt(rs.getDate("created_date"));
		userBean.setUserUpdtBy(rs.getString("updated_by"));
		userBean.setUserUpdtDt(rs.getDate("updated_date"));
		
		return userBean;
	}
}

