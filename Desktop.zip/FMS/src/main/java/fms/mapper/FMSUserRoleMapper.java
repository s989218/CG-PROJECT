package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSUserRoleBean;



public class FMSUserRoleMapper implements RowMapper<FMSUserRoleBean> {
	@Override
	public FMSUserRoleBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		FMSUserRoleBean userRoleBean = new FMSUserRoleBean();
		
		userRoleBean.setRoleId(rs.getInt("role_id"));
		userRoleBean.setRoleName(rs.getString("role_name"));
		userRoleBean.setRoleActiveFlag(rs.getString("active"));
		userRoleBean.setDefaultRole(rs.getString("default_role"));
		
		return userRoleBean;
	}
}

