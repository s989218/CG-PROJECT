package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSMetricsDataBean;

public class FleetPenF2FMetricsMapper implements RowMapper<FMSMetricsDataBean> {

	@Override
	public FMSMetricsDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSMetricsDataBean metricsDataDto = new FMSMetricsDataBean();
		
		metricsDataDto.setMetricsDataRegion(rs.getString("region"));
		metricsDataDto.setMetricsDataYear(rs.getString("year"));
		metricsDataDto.setMetricsDataQuarter(rs.getString("quarter"));
		String fltPenF2FValue = rs.getString("fleet_pen_f2f_value");
		if(fltPenF2FValue != null){
			metricsDataDto.setFleetPenF2FValue(Float.valueOf(rs.getString("fleet_pen_f2f_value")));
		}		
		return metricsDataDto;
	}


}

