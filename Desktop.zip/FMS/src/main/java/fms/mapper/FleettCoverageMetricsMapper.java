package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSFleetCoverageDataBean;

public class FleettCoverageMetricsMapper implements RowMapper<FMSFleetCoverageDataBean> {

	@Override
	public FMSFleetCoverageDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSFleetCoverageDataBean metricsDataDto = new FMSFleetCoverageDataBean();
		
		metricsDataDto.setCoverageRegion(rs.getString("region"));
		metricsDataDto.setCoverageYear(rs.getString("year"));
		metricsDataDto.setCoverageQuarter(rs.getString("quarter"));
		String coverageValue = rs.getString("fleet_coverage");
		if(coverageValue != null){
			metricsDataDto.setCoverageValue(coverageValue);
		}		
		return metricsDataDto;
	}


}

