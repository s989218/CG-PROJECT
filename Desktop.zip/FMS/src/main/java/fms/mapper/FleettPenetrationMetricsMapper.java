package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSFleetPenetrationDataBean;

public class FleettPenetrationMetricsMapper implements RowMapper<FMSFleetPenetrationDataBean> {

	@Override
	public FMSFleetPenetrationDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSFleetPenetrationDataBean metricsDataDto = new FMSFleetPenetrationDataBean();
		
		metricsDataDto.setPenetrationRegion(rs.getString("region"));
		metricsDataDto.setPenetrationYear(rs.getString("year"));
		metricsDataDto.setPenetrationQuarter(rs.getString("quarter"));
		String penetrationValue = rs.getString("fleet_penetration");
		if(penetrationValue != null){
			metricsDataDto.setPenetrationValue(penetrationValue);;
		}		
		return metricsDataDto;
	}


}

