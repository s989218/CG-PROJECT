package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSMetricsDataBean;

public class FltPenetrationMetricsMapper implements RowMapper<FMSMetricsDataBean> {

	@Override
	public FMSMetricsDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSMetricsDataBean metricsDataDto = new FMSMetricsDataBean();
		
		metricsDataDto.setMetricsDataRegion(rs.getString("region"));
		metricsDataDto.setMetricsDataYear(rs.getString("year"));
		metricsDataDto.setMetricsDataQuarter(rs.getString("quarter"));
		String penetrationValue = rs.getString("penetration_value");
		if(penetrationValue != null){
			metricsDataDto.setPenetrationValue(Float.valueOf(rs.getString("penetration_value")));
		}		
		return metricsDataDto;
	}


}

