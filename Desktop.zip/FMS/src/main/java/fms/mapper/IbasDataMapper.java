package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSIbasDataBean;

public class IbasDataMapper implements RowMapper<FMSIbasDataBean> {

	@Override
	public FMSIbasDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIbasDataBean iBasDataDto = new FMSIbasDataBean();
		
		iBasDataDto.setOngRegion(rs.getString("c_og_sales_region"));
		iBasDataDto.setcSiteCustCntry(rs.getString("c_site_customer_country"));
		iBasDataDto.setcGibSrNo(rs.getString("c_gib_serial_number"));
		iBasDataDto.setnMaintPolicyId(rs.getFloat("n_maint_policy_id"));
		iBasDataDto.setcMaintPolicyCode(rs.getString("c_maint_policy_cod"));
		iBasDataDto.setcMaintPolicyDesc(rs.getString("c_maint_policy_desc"));
		iBasDataDto.setnInstallLtDays(rs.getFloat("n_install_lt_days"));
		iBasDataDto.setnAvgRepairVal(rs.getFloat("n_avg_repair_value"));
		iBasDataDto.setnAvgPartsVal(rs.getFloat("n_avg_parts_value"));
		iBasDataDto.setnAvgSvcsVal(rs.getFloat("n_avg_svcs_value"));
		iBasDataDto.settOtherMaintPolicy(rs.getString("t_other_maint_policy"));
		iBasDataDto.setdEstManufComplete(rs.getString("d_est_manuf_complete"));
		iBasDataDto.setdEstShipDate(rs.getString("d_est_ship_date"));
		iBasDataDto.setdEstSerStrtDate(rs.getString("d_est_service_start_date"));
		iBasDataDto.setnEstServHrsCnt(rs.getFloat("n_est_serv_hours_count"));
		iBasDataDto.setdEstServHrsDate(rs.getString("d_est_serv_hours_date"));
		iBasDataDto.setnMaintYr(rs.getInt("n_maint_year"));
		iBasDataDto.setcHqCustName(rs.getString("c_hq_customer_name"));
		iBasDataDto.setcHqCustCntry(rs.getString("c_hq_customer_country"));
		iBasDataDto.setcDomCustDuns(rs.getString("c_dom_customer_duns"));
		iBasDataDto.setcDomCustName(rs.getString("c_dom_customer_name"));
		iBasDataDto.setcTechDesc(rs.getString("c_technology_desc"));
		iBasDataDto.setcTechCodeOg(rs.getString("c_technology_code_og"));
		iBasDataDto.setcTechDescOg(rs.getString("c_technology_desc_og"));
		iBasDataDto.setcEquipCode(rs.getString("c_equipment_code"));
		iBasDataDto.setcEquipDesc(rs.getString("c_equipment_desc"));
		iBasDataDto.setcEquipEngDes(rs.getString("c_equipment_eng_desc"));
		iBasDataDto.setcOemLocDesc(rs.getString("c_oem_location_desc"));
		iBasDataDto.setdUnitShipDate(rs.getString("d_unit_ship_date"));
		iBasDataDto.setdUnitCodDate(rs.getString("d_unit_cod_date"));
		iBasDataDto.setcServMgrLast(rs.getString("c_service_mgr_last"));
		iBasDataDto.setcMktSegmentDesc(rs.getString("c_market_segment_desc"));
		iBasDataDto.setcMktIndustryDesc(rs.getString("c_market_industry_desc"));
		iBasDataDto.setcSalesChannelDesc(rs.getString("c_sales_channel_desc"));
		iBasDataDto.setcServRelationDescGib(rs.getString("c_service_relation_desc_gib"));
		iBasDataDto.setcControlSystemDesc(rs.getString("c_control_system_desc"));
		iBasDataDto.setcServTypeDesc(rs.getString("c_service_type_desc"));
		iBasDataDto.setcDrivenEquipDesc(rs.getString("c_driven_equipment_desc"));
		iBasDataDto.setcMkt(rs.getString("c_market"));
		iBasDataDto.setcProdEscPl(rs.getString("c_prod_exc_pl"));
		iBasDataDto.setnFfhCnt(rs.getInt("n_ffh_cnt"));
		iBasDataDto.setcUnitStatusDesc(rs.getString("c_unit_status_desc"));
		iBasDataDto.setcServRelnDescOng(rs.getString("c_service_relation_desc_og"));
		iBasDataDto.setcGloCustDuns(rs.getString("c_glo_customer_duns"));
		iBasDataDto.setcGloCustName(rs.getString("c_glo_customer_name"));
		iBasDataDto.setLevel(rs.getString("level"));
		iBasDataDto.setAvmanpow(rs.getInt("avmanpow"));
		iBasDataDto.setAvaux(rs.getInt("avaux"));
		iBasDataDto.setAvf2f(rs.getFloat("avf2f"));
		iBasDataDto.setAvtot(rs.getFloat("avtot"));
		iBasDataDto.setSiteCustomerName(rs.getString("c_site_customer_name"));
		iBasDataDto.setIbasCSiteCustDuns(rs.getString("c_site_customer_duns"));
		iBasDataDto.setIbasCSiteNameAlias(rs.getString("c_site_name_alias"));
		iBasDataDto.setIbasCSiteCustCity(rs.getString("c_site_customer_city"));
		iBasDataDto.setIbasCTierCod(rs.getString("c_tier_cod"));
		iBasDataDto.setIbasCEngProjectRef(rs.getString("c_eng_project_ref"));
		iBasDataDto.setIbasCOemSerialNumber(rs.getString("c_oem_serial_number"));
		iBasDataDto.setIbasCParentSerialNumber(rs.getString("c_parent_serial_number"));
		iBasDataDto.setIbasNServFactor(rs.getFloat("n_serv_factor"));
		iBasDataDto.setIbasCAccountMgrLast(rs.getString("c_account_mgr_last"));
		iBasDataDto.setCServMgrFirst(rs.getString("c_service_mgr_first"));

		
		
		String geGlobalDuns = rs.getString("ge_global_duns");
		String geDunsName = rs.getString("ge_duns_name");
		
		if(geGlobalDuns!=null){
			iBasDataDto.setGeGlobalDuns(geGlobalDuns);
		}else{
			iBasDataDto.setGeGlobalDuns(rs.getString("c_glo_customer_duns"));
		}
		if(geDunsName!=null){
			iBasDataDto.setGeDunsName(geDunsName);
		}else{
			iBasDataDto.setGeDunsName(rs.getString("c_glo_customer_name"));
		}
		return iBasDataDto;
	}


}

