package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSInstalledBaseDataBean;

public class LatLongByRegMapper implements RowMapper<FMSInstalledBaseDataBean> {

	@Override
	public FMSInstalledBaseDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSInstalledBaseDataBean ibDataDto = new FMSInstalledBaseDataBean();
		
		ibDataDto.setIbDataRegion(rs.getString("region"));
		ibDataDto.setLatitude(rs.getString("latitude"));
		ibDataDto.setLongitude(rs.getString("longitude"));
		
	return ibDataDto;
	}


}

