package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSInstalledBaseDataBean;

public class LatLongBySiteMapper implements RowMapper<FMSInstalledBaseDataBean> {

	@Override
	public FMSInstalledBaseDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSInstalledBaseDataBean ibDataDto = new FMSInstalledBaseDataBean();
		
		ibDataDto.setSiteName(rs.getString("site_name"));
		ibDataDto.setLatitude(rs.getString("latitude"));
		ibDataDto.setLongitude(rs.getString("longitude"));
		ibDataDto.setServiceRelationDesc(rs.getString("c_service_relation_desc_og"));
		
	return ibDataDto;
	}


}

