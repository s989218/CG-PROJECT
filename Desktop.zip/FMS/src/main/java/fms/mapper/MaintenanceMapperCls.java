package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSMaintenanceDataBean;

public class MaintenanceMapperCls implements RowMapper<FMSMaintenanceDataBean> {

	@Override
	public FMSMaintenanceDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSMaintenanceDataBean maintDTO = new FMSMaintenanceDataBean();
		maintDTO.setId(rs.getString("maint_id"));
		maintDTO.setPolicy(rs.getString("policy"));
		maintDTO.setPolicyAggr(rs.getString("policy_aggr"));
		maintDTO.setLevel(rs.getString("level")); 
		maintDTO.setHours(rs.getString("hours")); 
		maintDTO.setAge(rs.getString("age"));
		maintDTO.setParts(rs.getString("parts")); 
		maintDTO.setRepairs(rs.getString("repairs"));
		maintDTO.setServices(rs.getString("services")); 
		maintDTO.setManpower(rs.getString("manpower")); 
		maintDTO.setAux(rs.getString("aux")); 
		maintDTO.setTotal(rs.getString("total"));
		return maintDTO;
	}
}
 
        	