package fms.mapper;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;

public class MiscRowMapper implements RowMapper<Map<String, Object>> {

	@Override
	public Map<String, Object> mapRow(ResultSet resultSet, int arg1)
			throws SQLException {
		ResultSetMetaData meta = resultSet.getMetaData();
		Map<String, Object> results = new LinkedHashMap<>();
		for (int index = 1; index <= meta.getColumnCount(); index++) {
			results.put(meta.getColumnName(index), resultSet.getObject(index));
		}
		return results;
	}

}
