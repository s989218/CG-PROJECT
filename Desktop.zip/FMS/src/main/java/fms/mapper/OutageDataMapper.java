package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSOutageDataBean;

public class OutageDataMapper implements RowMapper<FMSOutageDataBean> {

	@Override
	public FMSOutageDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSOutageDataBean outageDataDto = new FMSOutageDataBean();
		
		outageDataDto.setnEventId(rs.getInt("N_EVENT_ID"));
		outageDataDto.setcGibSerialNumber(rs.getString("C_GIB_SERIAL_NUMBER"));
		outageDataDto.setnMaintPolicyCyc(rs.getInt("N_MAINT_POLICY_CYC"));
		outageDataDto.setnMaintLevelSeq(rs.getInt("N_MAINT_LEVEL_SEQ"));
		outageDataDto.setdEventDate(rs.getString("D_EVENT_DATE"));
		outageDataDto.settEventNotes(rs.getString("T_EVENT_NOTES"));
		outageDataDto.setcDemSvcsStatus(rs.getString("C_DEM_SVCS_STATUS"));
		outageDataDto.setcUsrIns(rs.getString("C_USR_INS"));
		outageDataDto.setdIns(rs.getString("D_INS"));
		outageDataDto.setcEventDemStatusParts(rs.getString("C_EVENT_DEM_STATUS_PARTS"));
		outageDataDto.setcEventDemStatusSvcs(rs.getString("C_EVENT_DEM_STATUS_SVCS"));
		outageDataDto.setCeventDemStatusRepairs(rs.getString("C_EVENT_DEM_STATUS_REPAIRS"));
		outageDataDto.setfUnsolicedStatusFlag(rs.getString("F_UNSOLICED_STATUS_FLAG"));
		outageDataDto.setdEstServiceStartDate(rs.getString("D_EST_SERVICE_START_DATE"));
		outageDataDto.setnEstServHoursCount(rs.getInt("N_EST_SERV_HOURS_COUNT"));
		outageDataDto.setnMaintYear(rs.getInt("N_MAINT_YEAR"));
		outageDataDto.setcCustLoyaltyDescParts(rs.getString("C_CUST_LOYALTY_DESC_PARTS"));
		outageDataDto.setcCustBehaviorDescParts(rs.getString("C_CUST_BEHAVIOR_DESC_PARTS"));
		outageDataDto.setcSiteCustomerDuns(rs.getString("C_SITE_CUSTOMER_DUNS"));
		outageDataDto.setcSiteCustomerName(rs.getString("C_SITE_CUSTOMER_NAME"));
		outageDataDto.setcSiteNameAlias(rs.getString("C_SITE_NAME_ALIAS"));
		outageDataDto.setcSiteCustomerCity(rs.getString("C_SITE_CUSTOMER_CITY"));
		outageDataDto.setcSiteCustomerCountry(rs.getString("C_SITE_CUSTOMER_COUNTRY"));
		outageDataDto.setcTechnologyDesc(rs.getString("C_TECHNOLOGY_DESC"));
		outageDataDto.setcTechnologyDescOg(rs.getString("C_TECHNOLOGY_DESC_OG"));
		outageDataDto.setcEquipmentDesc(rs.getString("C_EQUIPMENT_DESC"));
		outageDataDto.setcEngProjectRef(rs.getString("C_ENG_PROJECT_REF"));
		outageDataDto.setcOemLocationDesc(rs.getString("C_OEM_LOCATION_DESC"));
		outageDataDto.setcUnitStatusDesc(rs.getString("C_UNIT_STATUS_DESC"));
		outageDataDto.setdUnitShipDate(rs.getString("D_UNIT_SHIP_DATE"));
		outageDataDto.setdUnitCodDate(rs.getString("D_UNIT_COD_DATE"));
		outageDataDto.setcAccountMgrEmail(rs.getString("C_ACCOUNT_MGR_EMAIL"));
		outageDataDto.setcServiceMgrEmail(rs.getString("C_SERVICE_MGR_EMAIL"));
		outageDataDto.setcMarketSegmentDesc(rs.getString("C_MARKET_SEGMENT_DESC"));
		outageDataDto.setcServiceRelationDescOg(rs.getString("C_SERVICE_RELATION_DESC_OG"));
		outageDataDto.setcOgSalesRegion(rs.getString("C_OG_SALES_REGION"));
		outageDataDto.setcMainLvlCod(rs.getString("MAINT_LEVEL_COD"));
		outageDataDto.setcMaintLvlDesc(rs.getString("MAINT_LEVEL_DESC"));
		outageDataDto.setCeventStatus(rs.getString("c_event_status_desc"));
		outageDataDto.setGeDunsName(rs.getString("ge_duns_name"));
		outageDataDto.setEventYear(rs.getString("event_year"));
		outageDataDto.setEventQuarter(rs.getString("event_quarter"));
		
		return outageDataDto;
	}


}

