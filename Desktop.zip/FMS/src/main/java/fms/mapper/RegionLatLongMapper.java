package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSIBRegionDataBean;

public class RegionLatLongMapper implements RowMapper<FMSIBRegionDataBean> {

	@Override
	public FMSIBRegionDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIBRegionDataBean ibDataDto = new FMSIBRegionDataBean();
		
		ibDataDto.setIbRegion(rs.getString("region"));
		ibDataDto.setIbLatitude(rs.getString("latitude"));
		ibDataDto.setIbLongitude(rs.getString("longitude"));
		
	return ibDataDto;
	}


}

