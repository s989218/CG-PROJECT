package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSMetricsDataBean;

public class RevDolrByRegionMetricsMapper implements RowMapper<FMSMetricsDataBean> {

	@Override
	public FMSMetricsDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSMetricsDataBean metricsDataDto = new FMSMetricsDataBean();
		
		metricsDataDto.setMetricsDataRegion(rs.getString("region"));
		metricsDataDto.setMetricsDataYear(rs.getString("year"));
		metricsDataDto.setMetricsDataQuarter(rs.getString("quarter"));
		String revDolrbyRegionValue = rs.getString("fms_rev_dollar_by_region_value");
		if(revDolrbyRegionValue != null){
			metricsDataDto.setRevDollarByRegionValue(Float.valueOf(rs.getString("fms_rev_dollar_by_region_value")));
		}		
		return metricsDataDto;
	}


}

