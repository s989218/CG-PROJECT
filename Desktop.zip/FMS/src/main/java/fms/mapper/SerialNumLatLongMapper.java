package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSIBSerialNumDataBean;


public class SerialNumLatLongMapper implements RowMapper<FMSIBSerialNumDataBean> {

	@Override
	public FMSIBSerialNumDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIBSerialNumDataBean ibDataDto = new FMSIBSerialNumDataBean();
		
		ibDataDto.setInstallBaseSerialNum(rs.getString("c_gib_serial_number"));
		ibDataDto.setInstallBaseLatitude(rs.getString("latitude"));
		ibDataDto.setInstallBaseLongitude(rs.getString("longitude"));
		ibDataDto.setInstallBaseRegion(rs.getString("region"));
		
		return ibDataDto;
	}
}

