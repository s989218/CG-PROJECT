package fms.mapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSServiceReqDataBean;
public class ServiceReqDataMapper implements RowMapper<FMSServiceReqDataBean> {
	private final Logger log = Logger.getLogger(this.getClass());
	
	

	@Override
	public FMSServiceReqDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSServiceReqDataBean serviceReqDataDto = new FMSServiceReqDataBean();
		serviceReqDataDto.setCaseNo(rs.getString("case_number"));
		serviceReqDataDto.setOpened(rs.getString("opened"));
		serviceReqDataDto.setOriginalTypeofIssue(rs.getString("original_type_of_issue"));
		serviceReqDataDto.setCurrentTypeofIssue(rs.getString("current_type_of_issue"));
		serviceReqDataDto.setIssueEventDate(rs.getString("issue_event_date"));
		serviceReqDataDto.setProjectPhase(rs.getString("project_phase"));
		serviceReqDataDto.setCustAddReq(rs.getString("customer_add_request"));
		serviceReqDataDto.setSuggByRedFlgReview(rs.getString("suggested_by_red_flag_review"));
		serviceReqDataDto.setRcaReqByCust(rs.getString("rca_required_by_customer"));
		serviceReqDataDto.setEhsImpact(rs.getString("ehs_impact"));
		serviceReqDataDto.setCategory(rs.getString("category"));
		serviceReqDataDto.setState(rs.getString("state"));
		serviceReqDataDto.setCurStaLastinActDate(rs.getString("cur_sta_last_in_actual_date"));
		serviceReqDataDto.setAssignedGroup(rs.getString("assigned_group"));
		serviceReqDataDto.setStatus(rs.getString("status"));
		serviceReqDataDto.setEntryInCurStatus(rs.getString("entry_in_the_cur_status"));
		serviceReqDataDto.setAsRunningLastInDate(rs.getString("as_running_last_in_date"));
		serviceReqDataDto.setAsRunningLastOutDate(rs.getString("as_running_last_out_date"));
		serviceReqDataDto.setTechSoluType(rs.getString("tech_solu_type"));
		serviceReqDataDto.setSwTeamNeeded(rs.getString("software_team_needed"));
		serviceReqDataDto.setJobType(rs.getString("job_type"));
		serviceReqDataDto.setJobTypeDetails(rs.getString("job_type_details"));
		serviceReqDataDto.setBusiness(rs.getString("business"));
		serviceReqDataDto.setCustomerName(rs.getString("customer_name"));
		serviceReqDataDto.setExpectedResolDate(rs.getString("expected_resol_date"));
		serviceReqDataDto.setMachineType(rs.getString("machine_type"));
		serviceReqDataDto.setMachineTechnology(rs.getString("machine_technology"));
		serviceReqDataDto.setControlPanelType(rs.getString("control_panel_type"));
		serviceReqDataDto.setMachineTechOg(rs.getString("machine_technology_og"));
		serviceReqDataDto.setCod(rs.getString("cod"));
		serviceReqDataDto.setCostingProjectCharged(rs.getString("costing_project_to_be_charged"));
		serviceReqDataDto.setProjectManager(rs.getString("project_manager"));
		serviceReqDataDto.setInstaManagerCoordinator(rs.getString("insta_manager_coordinator"));
		serviceReqDataDto.setProblemDesc(rs.getString("problem_description"));
		serviceReqDataDto.setCin(rs.getString("cin"));
		serviceReqDataDto.setAssignedFun(rs.getString("assigned_function"));
		serviceReqDataDto.setActVsSupMateSol(rs.getString("act_vs_sup_mate_sol"));
		serviceReqDataDto.setSupplierNameMateSol(rs.getString("supplier_name_mate_sol"));
		serviceReqDataDto.setSolDesc(rs.getString("sol_description"));
		serviceReqDataDto.setAsRunningNeeded(rs.getString("as_running_needed"));
		serviceReqDataDto.setMateNeeded(rs.getString("mate_needed"));
		serviceReqDataDto.setSupplierResp(rs.getString("supplier_resp"));
		serviceReqDataDto.setWfcaTimeInvalid(rs.getString("wfca_time_in_valid"));
		serviceReqDataDto.setWfcaTimeInSol(rs.getString("wfca_time_in_sol"));
		serviceReqDataDto.setWfcaTimeInFulfSp(rs.getString("wfca_time_in_fulf_sp"));
		serviceReqDataDto.setWfcaTimeInImple(rs.getString("wfca_time_in_imple"));
		serviceReqDataDto.setWfcaTimeInAsBuilt(rs.getString("wfca_time_in_as_built"));
		serviceReqDataDto.setWfcaTimeInExpertAss(rs.getString("wfca_time_in_expert_ass"));
		serviceReqDataDto.setsEventYear(rs.getString("event_year"));
		serviceReqDataDto.setsEventQuarter(rs.getString("event_quarter"));
		
		return serviceReqDataDto;
	}


}
