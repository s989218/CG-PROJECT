package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSInstalledBaseDataBean;

public class SiteInfoInstalledUnitMapper implements RowMapper<FMSInstalledBaseDataBean> {

	@Override
	public FMSInstalledBaseDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSInstalledBaseDataBean ibDataDto = new FMSInstalledBaseDataBean();
		
		ibDataDto.setSiteName(rs.getString("site_name"));
		ibDataDto.setCustName(rs.getString("ge_duns_name"));
		ibDataDto.setSiteCustCity(rs.getString("c_site_customer_city"));
		ibDataDto.setSiteCustCountry(rs.getString("c_site_customer_country"));
		ibDataDto.setIbDataRegion(rs.getString("region"));
		ibDataDto.setProdExcPL(rs.getString("c_prod_exc_pl"));
		ibDataDto.setMarketSegmentDesc(rs.getString("c_market_segment_desc"));
		ibDataDto.setSerialNumber(rs.getString("c_gib_serial_number"));
		ibDataDto.setTechnologyDescOG(rs.getString("c_technology_desc_og"));
		ibDataDto.setUnitShipData(rs.getString("d_unit_ship_date"));
		ibDataDto.setEstServiceHrsCount(rs.getString("n_est_serv_hours_count"));
		ibDataDto.setServiceRelationDesc(rs.getString("c_service_relation_desc_og"));
		ibDataDto.setAvTot(rs.getString("avtot"));
		ibDataDto.setLevel(rs.getString("level"));
		ibDataDto.setEquipmentModel(rs.getString("c_equipment_desc"));
		ibDataDto.setUnitCustomerName(rs.getString("c_unit_customer_name"));
		ibDataDto.setEventDate(rs.getString("IBAS_event_date"));
		ibDataDto.setEventType(rs.getString("Type"));
		ibDataDto.setEventStatus(rs.getString("Status"));
		ibDataDto.setEquipmentCode(rs.getString("c_equipment_code"));
		ibDataDto.setEquipmentEngDesc(rs.getString("c_equipment_eng_desc"));
		
		
	return ibDataDto;
	}


}

