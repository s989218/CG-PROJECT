package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import fms.bean.FMSIBSiteNameDataBean;

public class SiteNameLatLongMapper implements RowMapper<FMSIBSiteNameDataBean> {

	@Override
	public FMSIBSiteNameDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSIBSiteNameDataBean ibDataDto = new FMSIBSiteNameDataBean();
		
		ibDataDto.setSiteName(rs.getString("site_name"));
		ibDataDto.setLatitude(rs.getString("latitude"));
		ibDataDto.setLongitude(rs.getString("longitude"));
		ibDataDto.setRegion(rs.getString("region"));
		ibDataDto.setServiceRelationDesc(rs.getString("c_service_relation_desc_og"));
	return ibDataDto;
	}


}

