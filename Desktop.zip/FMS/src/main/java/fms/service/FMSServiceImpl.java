package fms.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import fms.bean.FMSAllMetricsDetailsVO;
import fms.bean.FMSCountryNameDropdownBean;
import fms.bean.FMSDMDataBean;
import fms.bean.FMSDMFilterDataBean;
import fms.bean.FMSDMMetricsDetailsDTO;
import fms.bean.FMSDMMetricsDetailsVO;
import fms.bean.FMSIBFilterDataBean;
import fms.bean.FMSIBMetricsDetailsVO;
import fms.bean.FMSIBMetricsDropdownsVO;
import fms.bean.FMSIBOMetricsDetailsVO;
import fms.bean.FMSIBSearchResultsDataBean;
import fms.bean.FMSIBSerachResultsVO;
import fms.bean.FMSIbasDataBean;
import fms.bean.FMSInstalledBaseDataBean;
import fms.bean.FMSInstldBaseDropdownsVO;
import fms.bean.FMSMaintenanceDataBean;
import fms.bean.FMSOrderMappingExcelBean;
import fms.bean.FMSOrdersMetricsDataBean;
import fms.bean.FMSOrdersMetricsDetailsVO;
import fms.bean.FMSOrdersMetricsDropdownsVO;
import fms.bean.FMSOutageDataBean;
import fms.bean.FMSOutageDropdownDTO;
import fms.bean.FMSOutageFilterDataDTO;
import fms.bean.FMSOutageFilterVO;
import fms.bean.FMSOutageMetricsDetailsDTO;
import fms.bean.FMSServiceReqDataBean;
import fms.bean.FMSUserBean;
import fms.bean.FMSUserRoleBean;
import fms.constants.FMSVariableConstants;
import fms.dao.IFMSDao;
import fms.utils.Utils;

@EnableScheduling
@Service
public class FMSServiceImpl implements IFMSService{


	Log log = LogFactory.getLog(FMSServiceImpl.class);

	public static final String APPLICATION_OCTET_STREAM = "application/octet-stream";

	@Autowired
	private IFMSDao objDAO;

	@Override
	public List<FMSMaintenanceDataBean> getAllMaintenanceData() {
		return objDAO.getAllMaintenanceDao();
	}

	@Override
	public String updateMaintenanceData(FMSMaintenanceDataBean maintDTO) {
		return objDAO.updateMaintenanceDao(maintDTO);
	}

	@Override
	public String insertToMaintenanceData(FMSMaintenanceDataBean maintDTO) {
		return objDAO.insertToMaintenanceDao(maintDTO);
	}

	public List<FMSIbasDataBean> getIbasData()
	{
		return objDAO.getIbasDao();
	}

	@Override
	public String deleteMaintenanceData(List<String> finalData) {
		return objDAO.deleteMaintenanceDao(finalData);
	}

	public FMSAllMetricsDetailsVO getAllMetricsData(String businessSegment, Map<String, Object> data)
	{
		return objDAO.getAllMetricsDao(businessSegment,data);
	}

	@Override
	public List<FMSIbasDataBean> getIbasDataWithFilter(Map<String, Object> data) {
		return objDAO.getIbasDataWithFilterDao(data);
	}

	public List<FMSInstalledBaseDataBean> getLatLongByRegion(String businessSegment, Map<String, Object> data)
	{
		return objDAO.getLatLongByRegionDao(businessSegment,data);
	}

	public List<FMSInstalledBaseDataBean> getLatLongBySite(Map<String, Object> data)
	{
		return objDAO.getLatLongBySiteDao(data);
	}

	public List<FMSInstalledBaseDataBean> getSiteInfoAndInstalledUnits(String region, String siteName, String businessSegment, String marketIndustry, String accountManager)
	{
		return objDAO.getSiteInfoAndInstalledUnitsDao(region,siteName,businessSegment,marketIndustry,accountManager);
	}

	public List<FMSInstalledBaseDataBean> getSerialInfoData(String region, String siteName, String serialNumber, String businessSegment, String marketIndustry, String accountManager)
	{
		return objDAO.getSerialInfoDao(region,siteName,serialNumber, businessSegment, marketIndustry,accountManager);
	}

	public FMSInstldBaseDropdownsVO getInstldBaseDropdownsData(String businessSegment,Map<String, Object> data)
	{
		return objDAO.getInstldBaseDropdownsDao(businessSegment,data);
	}

	public FMSIBSerachResultsVO getIBSearchResultsData(FMSIBSearchResultsDataBean iBSearchResultData)
	{
		return objDAO.getIBSearchResultsDao(iBSearchResultData);
	}

	public FMSIBMetricsDetailsVO getIBMetricsData(String businessSegment, Map<String,Object> data)
	{
		return objDAO.getIBMetricsDao(businessSegment,data);
	}

	public FMSIBMetricsDropdownsVO getIBMetricsDropdownsData(String businessSegment,Map<String, Object> data)
	{
		return objDAO.getIBMetricsDropdownsDao(businessSegment,data);
	}

	public FMSIBMetricsDetailsVO getIBMetricsFilterData(FMSIBFilterDataBean filterData)
	{		
		return objDAO.getIBMetricsFilterDao(filterData);
	}

	@Override
	public FMSIBMetricsDetailsVO getIBFilterDataCountry(FMSIBFilterDataBean filterData)
	{
		return objDAO.getIBFilterDataCountryDao(filterData);
	}
	
	public FMSOrdersMetricsDetailsVO getOrdersMetricsData(String businessSegment, Map<String, Object> data)
	{
		return objDAO.getOrdersMetricsDao(businessSegment,data);
	}

	public FMSOrdersMetricsDropdownsVO getOrdersMetricsDropdownsData(String businessSegment,Map<String, Object> data)
	{
		return objDAO.getOrdersMetricsDropdownsDao(businessSegment,data);
	}

	public FMSOrdersMetricsDetailsVO getOrdersMetricsFilterData(FMSOrdersMetricsDataBean ordersMetricsDataBean)
	{
		return objDAO.getOrdersMetricsFilterDao(ordersMetricsDataBean);
	}

	public FMSOrdersMetricsDetailsVO getOrdersFilterDataCountry(FMSOrdersMetricsDataBean ordersMetricsDataBean)
	{
		return objDAO.getOrdersFilterDataCountryDao(ordersMetricsDataBean);
	}

	@Override
	public List<FMSCountryNameDropdownBean> getCountryData(Map<String, Object> data) {
		return objDAO.getCountryDao(data);
	}

	@Override
	public List<FMSCountryNameDropdownBean> getOrderCountry(String regionName) {
		return objDAO.getOrderCountryDao(regionName);
	}

	@Override
	public FMSIBOMetricsDetailsVO getIBOMetricsData(String businessSegment, Map<String, Object> data)
	{
		return objDAO.getIBOMetricsDao(businessSegment,data);
	}

	@Override
	public FMSIBOMetricsDetailsVO getIBOMetricsFilterData(FMSIBFilterDataBean filterData)
	{
		return objDAO.getIBOMetricsFilterDao(filterData);
	}

	@Override
	public FMSIBOMetricsDetailsVO getIBOFilterDataCountry(FMSIBFilterDataBean filterData)
	{
		return objDAO.getIBOFilterDataCountry(filterData);
	}

	@Override
//	@Scheduled(cron = "0 0 12 * * ?" , zone="Asia/Calcutta")
	public void getOracleData() {
		objDAO.getOracleData();
	}

	@Override
//	//@Scheduled(cron = "0 0 10 * * ?", zone="Asia/Calcutta")
	public void getOracleOBPData() {
		objDAO.getOracleOBPData();
	}

	@Override
//	@Scheduled(cron = "0 0 10 2 1,4,7,10 ?", zone="Asia/Calcutta")
	public void getOracleIBASData() {
		objDAO.getOracleIBASData();
	}

	@Override
//	@Scheduled(cron = "0 30 10 * * ?", zone="Asia/Calcutta")
	public void getOracleDMData() {
		objDAO.getOracleDMData();
	}

	@Override
//	@Scheduled(cron = "0 0 11 * * ?", zone="Asia/Calcutta")
	public void getOracleOutageData() {
		objDAO.getOracleOutageData();
	}

	@Override
//	@Scheduled(cron = "0 0 9 * * ?", zone="Asia/Calcutta")
	public void getOracleServiceRequestData() {
		log.info("inside FMSServiceIMPL of getOracleServiceRequestData()");
		objDAO.getOracleServiceRequestData();
	}

	@Override
	public Map<String, Object> getIPMPartsData(Map<String,Object> filterData) {
		return objDAO.getIPMPartsData(filterData);
	}

	@Override
	public List<Map<String, Object>> getOrderDataWithFilter(Map<String,Object> data) {
		return objDAO.getOrderDataWithFilter(data);
	}

	@Override
	public Map<String, List<String>> getIPMDropdownData(Map<String,Object> filterData) {
		return objDAO.getIPMDropdownData(filterData);
	}

	@Override
	public Map<String, Object> getIPMData(Map<String,Object> filterData, String type) {
		return objDAO.getIPMData(filterData,type);
	}

	@Override
	public List<Map<String, Object>> getOrderExportData() {
		return objDAO.getOrderExportData();
	}

	@Override
	public String updateIPMParts(Map<String, Object> data) {
		return objDAO.updateIPMParts(data);
	}

	@Override
	public Map<String,List<String>> getIPMPartsExcelDropdown() {
		List<Map<String,Object>> data = objDAO.getIPMPartsExcelDropdown();
		Map<String,List<String>> dropdownMap = new HashMap<>();
		for(int i=0;i<data.size();i++){
			Map<String,Object> obj = data.get(i);
			String values = (String) obj.get("values");
			String[] split = values.split(",");
			dropdownMap.put((String) obj.get("field_name"), Arrays.asList(split));
		}
		return dropdownMap;
	}

	@Override
	public Map<String, Map<String, Object>> getIPMDataEntryData(Map<String,Object> filterData) {
		List<Map<String,Object>> result =objDAO.getIPMDataEntryData(filterData);
		Map<String,Map<String,Object>> upResult = new HashMap<>();
		for(Map<String,Object> row : result){
			String identifier = (String) row.get("identifier");
			row.remove("identifier");
			upResult.put(identifier, row);
		}
		return upResult;
	}

	@Override
	public String updateIPMDataEntryData(Map<String, Map<String, Object>> updatedData) {
		return objDAO.updateIPMDataEntryData(updatedData);
	}

	@Override
	public Map<String, Object> walkByBusinessData(Map<String, Object> filterData) {
		return objDAO.walkByBusinessData(filterData);
	}

	@Override
	public Map<String,Object> walkByBusinessRegion(Map<String, Object> filterData) {
		return objDAO.walkByRegionData(filterData);
	}

	@Override
	public String updateIPMLogicFields() {
		return objDAO.updateIPMLogicFields();
	}

	@Override
	public Map<String, Object> projectController(Map<String, Object> filterData) {
		return objDAO.projectController(filterData);
	}

	@Override
	public Map<String, Object> getQuarterYear() {
		return objDAO.getQuarterYear();
		/**return objDAO.getGeneralisedChooseColumnDetails();*/
	}

	@Override
	public Map<String, Object> walkByProduct(Map<String, Object> filterData) {
		return objDAO.walkByProduct(filterData);
	}

	@Override
	public List<String> getIPMPartsDropdownData(Map<String, Object> filterData) {
		return objDAO.getIPMPartsDropdownData(filterData);
	}


	private String getContentType(byte[] b) {
		String contentType;
		try {
			contentType = URLConnection.guessContentTypeFromStream(new ByteArrayInputStream(b));
		} catch (IOException e) {
			if (log.isDebugEnabled()) {
				log.debug("unable to determine content type", e);
			}
			return APPLICATION_OCTET_STREAM;
		}
		if (log.isDebugEnabled()) {
			log.debug("content type inferred is"+contentType);
		}
		return contentType;
	}

	@Override
	public Map<String, Object> walkByFinance(Map<String, Object> filterData) {
		return objDAO.walkByFinance(filterData);
	}

	@Override
	public String importCSVToTable(InputStream inputStream, String fileName, String userSSO) {
		return objDAO.importCSVToTable(inputStream, fileName, userSSO);
	}

	@Override
	public void exportCSVFromTable(HttpServletResponse responses,Map<String,Object> filterData){
		objDAO.exportCSVFromTable(responses,filterData);
	}

	/* FMS Enhancement new services*/

	public FMSDMMetricsDetailsDTO getDMMetricsData(String businessSegment, Map<String, Object> data)
	{
		return objDAO.getDMMetricsData(businessSegment,data);
	}

	@Override
	public Map<String, Object> getDMMetricsDropdown(String businessSegment, Map<String, Object> data) {
		return objDAO.getDMMetricsDropdown(businessSegment,data);
	}

	@Override
	public List<FMSCountryNameDropdownBean> getDMCountry(Map<String, Object> data) {
		return objDAO.getDMCountry(data);
	}

	@Override
	public List<FMSDMDataBean> getDMData(Map<String,Object> data) {
		return objDAO.getDMData(data);
	}


	@Override
	public List<FMSServiceReqDataBean> getServiceReqData(String data) {
		return objDAO.getServiceReqData(data);
	}

	@Override
	public Map<String, Object> getPMOChartData(Map<String, Object> filterData) {
		return objDAO.getPMOChartData(filterData);
	}

	@Override
	public Map<String,Object> getChooseColumns(){
		return objDAO.getChooseColumns();
		/**return objDAO.getGeneralisedChooseColumnDetails();*/
	}

	public FMSDMMetricsDetailsVO getDMMetricsFilterData(FMSDMFilterDataBean filterData)
	{		
		return objDAO.getDMMetricsFilterDao(filterData);
	}

	@Override
	public FMSDMMetricsDetailsVO getDMFilterDataCountry(
			FMSDMFilterDataBean filterData) {
		return objDAO.getDMFilterDataCountryDao(filterData);
	}

	@Override
	public Map<String, Object> getPMOChartDetailsData(Map<String, Object> filterData) {
		return objDAO.getPMOChartDetailsData(filterData);
	}

	@Override
	public FMSOutageMetricsDetailsDTO getOutageMetricsData(Map<String, Object> data) {
		return objDAO.getOutageMetricsData(data);
	}

	@Override
	public void exportCSVFromMaster(HttpServletResponse responses) {
		objDAO.exportCSVFromMaster(responses);

	}

	@Override
	public void exportPMODrilDownData(HttpServletResponse responses, Map<String, Object> filterData) {
		objDAO.exportPMODrilDownData(responses, filterData);		
	}

	@Override
	public List<FMSOutageDataBean> getOutageData(Map<String, Object> data) {
		return objDAO.getOutageData(data);
	}


	@Override
	public FMSOutageDropdownDTO getOutageDropdown(Map<String, Object> data) {
		return objDAO.getOutageDropdown(data);
	}

	@Override
	public FMSOutageFilterVO getOutageFilterDataRegion(FMSOutageFilterDataDTO filterData) {
		return objDAO.getOutageFilterDataRegion(filterData);
	}

	@Override
	public FMSOutageFilterVO getOutageFilterDataCountry(FMSOutageFilterDataDTO filterData) {
		return objDAO.getOutageFilterDataCountry(filterData);
	}

	/*order mapping*/

	@Override
	public String mappingXlsToDao(InputStream inputStream, String mappingParam){
		List<Map<String,List<FMSOrderMappingExcelBean>>> objFmsOrderMappingPart=readMappingXlsxInputData(inputStream,mappingParam);
		return objDAO.storeMappingData(objFmsOrderMappingPart,mappingParam);
	}

	private List<Map<String,List<FMSOrderMappingExcelBean>>> readMappingXlsxInputData(InputStream inputStream,String mappingParam){
		log.info("inside readOrderMappingXlsxInputData service");
		try{
			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);

			XSSFSheet     xssfSheet = null;

			List<Map<String,List<FMSOrderMappingExcelBean>>> orderMappingDataList = new ArrayList<>();

			if("ALL".equalsIgnoreCase(mappingParam)){
				for(int i=0;i<workbook.getNumberOfSheets();i++){
					xssfSheet = workbook.getSheetAt(i);
					orderMappingDataList.add(readMappingSheets(xssfSheet));
				}
			}
			else{
				xssfSheet = workbook.getSheetAt(0);
				orderMappingDataList.add(readMappingSheets(xssfSheet));	
			}

			if(inputStream!=null){
				inputStream.close();
			}

			return orderMappingDataList;
		}catch (Exception e){
			log.info("inside readOrderMappingXlsxInputData service exception "+e);
			return null;
		}

	}

	private Map<String,List<FMSOrderMappingExcelBean>> readMappingSheets(XSSFSheet xSSFSheet){
		List<FMSOrderMappingExcelBean> mappingDataList= new ArrayList<>(); 
		Map<String,List<FMSOrderMappingExcelBean>> mapList = new HashMap<>();
		if("ME Mapping".equalsIgnoreCase(xSSFSheet.getSheetName())){
			Iterator<Row> rowIterator = xSSFSheet.iterator();

			while (rowIterator.hasNext()) 
			{
				Row row = rowIterator.next();
				if( row.getRowNum() >= 1){
					if(null!=row.getCell(0)){
						if(!"".equals(row.getCell(0).toString())){
							FMSOrderMappingExcelBean fmsOrderMappingObj = new FMSOrderMappingExcelBean();
							fmsOrderMappingObj.setMmCmgmtEntityCode(Utils.getValidation(row.getCell(0)));
							fmsOrderMappingObj.setMmMappingInclSCCorrections(Utils.getValidation(row.getCell(1)));
							fmsOrderMappingObj.setMmPandL(Utils.getValidation(row.getCell(2)));
							fmsOrderMappingObj.setMmSVCEQ(Utils.getValidation(row.getCell(3)));
							fmsOrderMappingObj.setMmTierThree(Utils.getValidation(row.getCell(4)));
							fmsOrderMappingObj.setMmDMTierThree(Utils.getValidation(row.getCell(5)));
							fmsOrderMappingObj.setMmTierFour(Utils.getValidation(row.getCell(6)));
							fmsOrderMappingObj.setMmUsage(Utils.getValidation(row.getCell(7)));
							mappingDataList.add(fmsOrderMappingObj);
						}
					}
				}
			}
			mapList.put("ME Mapping", mappingDataList);
		}else if("Segment Mapping".equalsIgnoreCase(xSSFSheet.getSheetName())){
			Iterator<Row> rowIterator = xSSFSheet.iterator();
			while (rowIterator.hasNext()) 
			{
				Row row = rowIterator.next();
				if( row.getRowNum() >= 1){
					if(null!=row.getCell(0)){
						if(!"".equals(row.getCell(0).toString())){
							FMSOrderMappingExcelBean fmsOrderMappingObj = new FMSOrderMappingExcelBean();
							fmsOrderMappingObj.setSkCSrcNewSegment(Utils.getValidation(row.getCell(0)));
							fmsOrderMappingObj.setSkSegmentMapping(Utils.getValidation(row.getCell(1)));
							mappingDataList.add(fmsOrderMappingObj);
						}
					}
				}
			}
			mapList.put("Segment Mapping", mappingDataList);	
		}else if("Product Mapping".equalsIgnoreCase(xSSFSheet.getSheetName())){
			Iterator<Row> rowIterator = xSSFSheet.iterator();
			while (rowIterator.hasNext()) 
			{
				Row row = rowIterator.next();
				if( row.getRowNum() >= 1){
					if(null!=row.getCell(0)){
						if(!"".equals(row.getCell(0).toString())){
							FMSOrderMappingExcelBean fmsOrderMappingObj = new FMSOrderMappingExcelBean();
							fmsOrderMappingObj.setPkCProductTypeDesc(Utils.getValidation(row.getCell(0)));
							fmsOrderMappingObj.setPkProductMapping(Utils.getValidation(row.getCell(1)));
							mappingDataList.add(fmsOrderMappingObj);
						}
					}
				}
			}
			mapList.put("Product Mapping", mappingDataList);	
		}
		else{
			log.error("Error In Service");
		}
		return mapList;
	}

	@Override
	public Map<String, Object> getServiceReqMetricsFilterData(Map<String, Object> data) {

		return objDAO.getServiceReqMetricsFilterData(data);
	}

	@Override
	public Map<String, Object> getServiceRequestMetricsData(Map<String, Object> data) {
		return objDAO.getServiceRequestMetricsData(data);
	}

	@Override
	public Map<String, Object> getServiceRequestDropdown() {
		return objDAO.getServiceRequestDropdown();
	}

	@Override
	public List<FMSUserBean> authorizeUser(String userId) {
		List<FMSUserBean> userInfo = null;
		List<FMSUserRoleBean> userRoles = null;
		try {
			userInfo = objDAO.authorizeUser(userId);
			for (FMSUserBean fmsUserBean : userInfo) {
				userRoles = objDAO.getUserRoles(fmsUserBean.getUserId());
				fmsUserBean.setUserRoles(userRoles);
			}
		} catch (Exception e) {
			log.error("Error in FMSServiceImplauthorizeUser()");

		}
		return userInfo;
	}

	@Override
	public Map<String, Object> getCombinedAnalysisDropdownData(Map<String, Object> data) {
		return objDAO.getCombinedAnalysisDropdownData(data);
	}
	@Override
	public Map<String, Object> getCombinedAnalysisMetrics(Map<String, Object> data) { 
		return objDAO.getCombinedAnalysisMetrics(data);
	}
	@Override
	public List<Map<String, Object>> exportCombinedAnalytics(Map<String, Object> data, String metrics) {
		return objDAO.exportCombinedAnalytics(data, metrics);
	}

	@Override
	public String importCSVToOrder(InputStream inputStream, String fileName, String userSSO, String businessSegment, String marketIndustry) {
		return objDAO.importCSVToOrder(inputStream, fileName, userSSO, businessSegment,marketIndustry);
	}

	@Override
	public String importCSVToCustMapping(InputStream inputStream) {
		return objDAO.importCSVToCustMapping(inputStream);
	}

	@Override
	public String importCSVToSalesData(InputStream inputStream, String businessSegment, String marketIndustry) {
		return objDAO.importCSVToSalesData(inputStream, businessSegment,marketIndustry);
	}

	public void downloadFile(HttpServletResponse responses, Map<String,Object> data){
		objDAO.downloadFile(responses, data);
	}

	@Override
	public List<Map<String, Object>> downloadExcelFile(String mappingParam) {
		return objDAO.downloadExcelFile(mappingParam);
	}

	@Override
	public Map<String, Object> getAllMetricsCountryTechData(String type,Map<String,Object> filters) {
		return objDAO.getAllMetricsCountryTechData(type,filters);
	}

	@Override
	public List<String> getPenetratinMetricsCountryDropdown(String businessSegment,Map<String,Object> filters) {
		return objDAO.getPenetratinMetricsCountryDropdown(businessSegment,filters);
	}

	@Override
	public List<String> getPenetratinMetricsRegionDropdown(Map<String,Object> filters) {
		return objDAO.getPenetratinMetricsRegionDropdown(filters);
	}

	@Override
	public Map<String, Object> getAllMetricsCountrySiteData(Map<String, Object> filters) {
		return objDAO.getAllMetricsCountrySiteData(filters);
	}

	@Override
	public List<String> getAllMetricsCountrySiteDropdown(String businessSegment,Map<String,Object> filters) {
		return objDAO.getAllMetricsCountrySiteDropdown(businessSegment,filters);
	}

	@Override
	public Map<String, Object> penetrationExportExcelData(Map<String, Object> filters) {
		return objDAO.penetrationExportExcelData(filters);
	}

	@Override
	public Map<String, Object> getRawDataIBOPage(String page, JSONObject jsonObj) {
		return objDAO.getRawDataIBOPage(page,jsonObj);
	}

	@Override
	public List<Map<String, Object>> exportRawDataMetrics(JSONObject jsonObj, String page) {
		return objDAO.exportRawDataMetrics(jsonObj,page);
	}

	@Override
	public List<String> getRawDataHeadersList(String exportSheet) {
		return objDAO.getRawDataHeadersList(exportSheet);
	}

	@Override
	public Map<String, Object> penetrationDashboard(String businessSegment,Map<String, Object> filters) {
		return objDAO.penetrationDashboard(businessSegment,filters);
	}

	@Override
	public List<String> getPenetrationMetricsGEDunsNameDropdown(String businessSegment,Map<String,Object> filters) {
		return objDAO.getPenetrationMetricsGEDunsNameDropdown(businessSegment,filters);
	}

	@Override
	public Map<String, Object> getAllMetricsGEDunsNameData(Map<String, Object> filters) {
		return objDAO.getAllMetricsGEDunsNameData(filters);
	}

	@Override
	public Map<String, Object> penetrationGEDunsExportExcelData(Map<String, Object> filters) {
		return objDAO.penetrationGEDunsExportExcelData(filters);
	}

	@Override
	public Map<String, Object> getPenMetricsTopSitesByRegion(Map<String, Object> filters) {
		return objDAO.getPenMetricsTopSitesByRegion(filters);
	}

	@Override
	public List<Map<String, Object>> fetchPostgreRegionData() {
		log.info("Inside FMSServiceImpl fetchPostgreRegionData()");
		return objDAO.fetchPostgreRegionData();
	}

	@Override
	public Map<String, Object> getIPMRawData(Map<String, Object> filterData) {
		return objDAO.getIPMRawData(filterData);
	}

	@Override
	public String updateIPMPartsQmi(Map<String, Object> filterData) {
		log.info("Inside FMSServiceImpl updateIPMPartsQmi()");
		return objDAO.updateIPMPartsQmi(filterData);
	}

	@Override
	public List<String> getOrdersYears() {
		return objDAO.getOrdersYears();
	}

	@Override
	public String manageUsers(Map<String, Object> userData) {
		log.info("Inside FMSServiceImpl manageUsers()");
		return objDAO.manageUsers(userData);
	}

	@Override
	public Map<String, Object> getParticularUserDetails(String sso) {
		log.info("Inside FMSServiceImpl getParticularUserDetails()");
		return objDAO.getParticularUserDetails(sso);
	}

	@Override
	public Map<String, Object> getUserManagementDetails() {
		return objDAO.getUserManagementDetails();
	}

	@Override
	public List<Map<String, Object>> exportUserManagementData(String exportType) {
		log.info("Inside FMSServiceImpl exportUserManagementData()");
		return objDAO.exportUserManagementData(exportType);
	}

	@Override
	public String manageRoles(Map<String, Object> rolesData) {
		log.info("Inside FMSServiceImpl manageRoles()");
		return objDAO.manageRoles(rolesData);
	}

	@Override
	public Map<String,Object> getUserDetailsBasedOnRole(int roleId) {
		log.info("Inside FMSServiceImpl getUserDetailsBasedOnRole()");
		return objDAO.getUserDetailsBasedOnRole(roleId);
	}

	/**
	 * This BackUp Service takes the backup of Existing Oracle data for DM, Outage & Service request EveryDay 
	 * at 4:30 AM IST
	 **/
	@Override
	@Scheduled(cron = "0 30 4 * * ?", zone="Asia/Calcutta")
	public void backUpService() {
		log.info("getSevenDaysPriorDate for backUpService() in ServiceImpl");
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date currentDate = new Date();
		Date sevenDaysBefore = new Date(currentDate.getTime() - 7 * 24 * 3600 * 1000l);   
		String sevenDaysPriorDate = dateFormat.format(sevenDaysBefore);
		String creationDate = dateFormat.format(currentDate);
		objDAO.backUpService(sevenDaysPriorDate.concat(FMSVariableConstants.TILDE_SEPARATOR).concat(creationDate));
	}

	@Override
	public void exportInvalidIPMData(HttpServletResponse responses, Map<String, Object> filterData) {
		objDAO.exportInvalidIPMData(responses, filterData);
		
	}

	@Override
	public List<Map<String, Object>> getImportStatusHistory(
			Map<String, Object> filterData) {
		return objDAO.getImportStatusHistory(filterData);
	}
	
	public void getOracleIBASData(Map<String,Object> filterData) {
		objDAO.getOracleIBASData(filterData);
	}

	@Override
	public String uploadDocuments(InputStream inputStream, String fileName,String fileDescription, String userSSO,String fileAccess) {
		return objDAO.uploadDocuments(inputStream, fileName,fileDescription, userSSO, fileAccess);
	}
	
	@Override
	public void downloadDocuments(HttpServletResponse responses, Map<String,Object> data){
		objDAO.downloadDocuments(responses, data);
	}

	@Override
	public List<Map<String, Object>> getAllDocuments(Map<String,Object> data) {
		return objDAO.getAllDocuments(data);
	}
	
	@Override
	public Map<String, Object> getAllRoles(Map<String,Object> data) {
		return objDAO.getAllRoles(data);
	}
	
	@Override
	public String deleteDocument(Map<String, Object> data) {
		return objDAO.deleteDocument(data);
	}
	@Override
	public String checkAkanaCallLocally() {
		return objDAO.checkAkanaCallLocally();
	}

	@Override
	public Map<String, Object> getManagersForTopSites(String businessSegment,Map<String, Object> params) {
		return objDAO.getManagersForTopSites(businessSegment,params);
	}

	@Override
	public Map<String, Object> getPenMetricsSegmentData(String type,Map<String, Object> filters) {
				return objDAO.getPenMetricsSegmentData(type,filters);
	}

	@Override
	public Map<String, Object> getAccountManagers(String businessSegment,Map<String,Object> data) {
		return objDAO.getAccountManagers(businessSegment,data);
	}

	@Override
	public Map<String, Object> getMarketIndustryDescDropdown(Map<String, Object> data) {
				return objDAO.getMarketIndustryDescDropdown(data);
	}

	@Override
	public String importIBOData(InputStream inputStream, String fileName, String userSSO) {
		return objDAO.importIBOData(inputStream, fileName,userSSO);
	}

	@Override
	public void exportEquipmentData(HttpServletResponse responses, Map<String, Object> filterData) {
		objDAO.exportEquipmentData(responses, filterData);
		
	}	
}
