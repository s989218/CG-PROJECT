package fms.service;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;

import fms.bean.FMSAllMetricsDetailsVO;
import fms.bean.FMSCountryNameDropdownBean;
import fms.bean.FMSDMDataBean;
import fms.bean.FMSDMFilterDataBean;
import fms.bean.FMSDMMetricsDetailsDTO;
import fms.bean.FMSDMMetricsDetailsVO;
import fms.bean.FMSIBFilterDataBean;
import fms.bean.FMSIBMetricsDetailsVO;
import fms.bean.FMSIBMetricsDropdownsVO;
import fms.bean.FMSIBOMetricsDetailsVO;
import fms.bean.FMSIBSearchResultsDataBean;
import fms.bean.FMSIBSerachResultsVO;
import fms.bean.FMSIbasDataBean;
import fms.bean.FMSInstalledBaseDataBean;
import fms.bean.FMSInstldBaseDropdownsVO;
import fms.bean.FMSMaintenanceDataBean;
import fms.bean.FMSOrdersMetricsDataBean;
import fms.bean.FMSOrdersMetricsDetailsVO;
import fms.bean.FMSOrdersMetricsDropdownsVO;
import fms.bean.FMSOutageDataBean;
import fms.bean.FMSOutageDropdownDTO;
import fms.bean.FMSOutageFilterDataDTO;
import fms.bean.FMSOutageFilterVO;
import fms.bean.FMSOutageMetricsDetailsDTO;
import fms.bean.FMSServiceReqDataBean;
import fms.bean.FMSUserBean;

public interface IFMSService {

	public List<FMSMaintenanceDataBean> getAllMaintenanceData();

	public String updateMaintenanceData(FMSMaintenanceDataBean maintDTO);

	public String insertToMaintenanceData(FMSMaintenanceDataBean maintDTO);

	public String  deleteMaintenanceData(List<String> finalData);

	public List<FMSIbasDataBean> getIbasData();

	public List<FMSIbasDataBean> getIbasDataWithFilter(Map<String, Object> data);

	public FMSAllMetricsDetailsVO getAllMetricsData(String businessSegment, Map<String, Object> data);

	public List<FMSInstalledBaseDataBean> getLatLongByRegion(String businessSegment, Map<String, Object> data);

	public List<FMSInstalledBaseDataBean> getLatLongBySite(Map<String, Object> data);

	public List<FMSInstalledBaseDataBean> getSiteInfoAndInstalledUnits(String region, String siteName, String businessSegment, String marketIndustry, String accountManager);

	public List<FMSInstalledBaseDataBean> getSerialInfoData(String region, String siteName, String serialNumber, String businessSegment, String marketIndustry, String accountManager);

	public FMSInstldBaseDropdownsVO getInstldBaseDropdownsData(String businessSegment,Map<String, Object> data); 

	public FMSIBSerachResultsVO getIBSearchResultsData(FMSIBSearchResultsDataBean iBSearchResultData);

	public FMSIBMetricsDetailsVO getIBMetricsData(String businessSegment, Map<String,Object> data);

	public FMSIBMetricsDropdownsVO getIBMetricsDropdownsData(String businessSegment,Map<String, Object> data); 

	public FMSIBMetricsDetailsVO getIBMetricsFilterData(FMSIBFilterDataBean filterData);

	public FMSIBMetricsDetailsVO getIBFilterDataCountry(FMSIBFilterDataBean filterData);
	
	public FMSOrdersMetricsDetailsVO getOrdersMetricsData(String businessSegment, Map<String, Object> data);

	public FMSOrdersMetricsDropdownsVO getOrdersMetricsDropdownsData(String businessSegment,Map<String, Object> data); 

	public FMSOrdersMetricsDetailsVO getOrdersMetricsFilterData(FMSOrdersMetricsDataBean ordersMetricsDataBean);

	public FMSOrdersMetricsDetailsVO getOrdersFilterDataCountry(FMSOrdersMetricsDataBean ordersMetricsDataBean);

	public List<FMSCountryNameDropdownBean> getCountryData(Map<String, Object> data); 

	public List<FMSCountryNameDropdownBean> getOrderCountry(String regionName);

	public FMSIBOMetricsDetailsVO getIBOMetricsData(String businessSegment, Map<String, Object> data);

	public FMSIBOMetricsDetailsVO getIBOMetricsFilterData(FMSIBFilterDataBean filterData);

	public FMSIBOMetricsDetailsVO getIBOFilterDataCountry(FMSIBFilterDataBean filterData); 

	public void getOracleData(); 

	public void getOracleOBPData();

	public void getOracleIBASData(Map<String,Object> filterData);
	
	public void getOracleIBASData();

	public void getOracleDMData();

	public void getOracleOutageData();
	
	public List<Map<String, Object>> getOrderDataWithFilter(Map<String,Object> data);

	public Map<String,List<String>> getIPMDropdownData(Map<String,Object> filterData);

	public Map<String, Object> getIPMData(Map<String,Object> filterData,String type);

	public Map<String, Object> getIPMPartsData(Map<String,Object> filterData);

	public List<Map<String,Object>> getOrderExportData();

	public String updateIPMParts(Map<String,Object> data);

	public Map<String, List<String>> getIPMPartsExcelDropdown();

	public Map<String, Map<String, Object>> getIPMDataEntryData(Map<String,Object> filterData);

	public String updateIPMDataEntryData(Map<String, Map<String, Object>> updatedData);

	public Map<String,Object> walkByBusinessData(Map<String,Object> filterData);

	public Map<String,Object> walkByBusinessRegion(Map<String,Object> filterData);

	public String updateIPMLogicFields();

	public Map<String,Object> projectController(Map<String,Object> filterData);

	public Map<String,Object> walkByProduct(Map<String,Object> filterData);

	public Map<String,Object> getQuarterYear();

	public List<String> getIPMPartsDropdownData(Map<String, Object> filterData);

	public Map<String,Object> walkByFinance(Map<String,Object> filterData);

	public String importCSVToTable(InputStream inputStream, String fileName, String userSSO);

	public void exportCSVFromTable(HttpServletResponse responses,Map<String,Object> filterData);

	public void exportCSVFromMaster(HttpServletResponse responses);

	/**FMS Enhancements new Service*/

	public FMSDMMetricsDetailsDTO getDMMetricsData(String businessSegment, Map<String, Object> data);

	public Map<String,Object> getDMMetricsDropdown(String businessSegment, Map<String, Object> data);

	public List<FMSCountryNameDropdownBean> getDMCountry(Map<String, Object> data); 
	
	public List<FMSDMDataBean> getDMData(Map<String,Object> data);

	public List<FMSServiceReqDataBean> getServiceReqData(String data);

	public Map<String, Object> getPMOChartData(Map<String,Object> filterData);

	public Map<String, Object> getPMOChartDetailsData(Map<String,Object> filterData);

	public Map<String,Object> getChooseColumns();

	public FMSDMMetricsDetailsVO getDMMetricsFilterData(FMSDMFilterDataBean filterData);

	public FMSDMMetricsDetailsVO getDMFilterDataCountry(FMSDMFilterDataBean filterData); 

	public FMSOutageMetricsDetailsDTO  getOutageMetricsData(Map<String, Object> data);

	public List<FMSOutageDataBean> getOutageData(Map<String, Object> data);

	public void exportPMODrilDownData(HttpServletResponse responses,Map<String,Object> filterData);

	public FMSOutageDropdownDTO  getOutageDropdown(Map<String, Object> data);

	public FMSOutageFilterVO getOutageFilterDataRegion(FMSOutageFilterDataDTO filterData);

	public FMSOutageFilterVO getOutageFilterDataCountry(FMSOutageFilterDataDTO filterData);

	public String mappingXlsToDao(InputStream inputStream, String mappingParam);

	public void getOracleServiceRequestData();

	public Map<String, Object> getServiceReqMetricsFilterData(Map<String,Object> data);

	public Map<String, Object>  getServiceRequestMetricsData(Map<String, Object> data);

	public Map<String, Object>  getServiceRequestDropdown();

	public List<FMSUserBean> authorizeUser(String userId);

	public Map<String,Object>  getCombinedAnalysisDropdownData(Map<String, Object> data);

	public Map<String, Object>  getCombinedAnalysisMetrics(Map<String, Object> data);

	public List<Map<String,Object>> exportCombinedAnalytics(Map<String, Object> data,String metrics);

	public String importCSVToOrder(InputStream inputStream,String fileName, String userSSO, String businessSegment, String marketIndustry);

	public String importCSVToCustMapping(InputStream inputStream);

	public String importCSVToSalesData(InputStream inputStream, String businessSegment, String marketIndustry);

	public void downloadFile(HttpServletResponse responses, Map<String,Object> data);

	public List<Map<String, Object>> downloadExcelFile(String mappingParam);

	public Map<String, Object> getAllMetricsCountryTechData(String type,Map<String,Object> filters);
	
	public Map<String, Object> getPenMetricsSegmentData(String type,Map<String,Object> filters);

	public List<String> getPenetratinMetricsCountryDropdown(String businessSegment,Map<String,Object> filters);

	public List<String>  getPenetratinMetricsRegionDropdown(Map<String,Object> filters);

	public Map<String, Object> getAllMetricsCountrySiteData(Map<String,Object> filters);

	public List<String> getAllMetricsCountrySiteDropdown(String businessSegment,Map<String,Object> filters);

	public Map<String, Object> penetrationExportExcelData(Map<String,Object> filters);

	public List<Map<String,Object>> exportRawDataMetrics(JSONObject jsonObj,String page);

	public List<String> getRawDataHeadersList(String exportSheet);

	public Map<String, Object> getRawDataIBOPage(String page, JSONObject jsonObj);

	public Map<String, Object> penetrationDashboard(String businessSegment,Map<String,Object> filters);

	public List<String> getPenetrationMetricsGEDunsNameDropdown(String businessSegment,Map<String,Object> filters);

	public Map<String, Object> getAllMetricsGEDunsNameData(Map<String, Object> filters);

	public Map<String, Object> penetrationGEDunsExportExcelData(Map<String,Object> filters);

	public Map<String, Object> getPenMetricsTopSitesByRegion(Map<String,Object> filters);

	public List<Map<String, Object>> fetchPostgreRegionData();

	public Map<String, Object> getIPMRawData(Map<String,Object> filterData);

	public String updateIPMPartsQmi(Map<String, Object> filterData);

	public List<String> getOrdersYears();

	public String manageUsers(Map<String, Object> userData);

	public Map<String, Object> getParticularUserDetails(String sso);
	
	public Map<String, Object> getUserManagementDetails();

	public List<Map<String, Object>> exportUserManagementData(String exportType);

	public String manageRoles(Map<String, Object> rolesData);

	public Map<String,Object> getUserDetailsBasedOnRole(int roleId);

	public void backUpService();
	
	public void exportInvalidIPMData(HttpServletResponse responses,Map<String,Object> filterData);
	
	public List<Map<String,Object>> getImportStatusHistory(@RequestBody Map<String,Object> filterData);
	
	public String uploadDocuments(InputStream inputStream, String fileName, String fileDescription, String userSSO, String fileAccess);
	
	public void downloadDocuments(HttpServletResponse responses, Map<String,Object> data);
	
	public List<Map<String,Object>> getAllDocuments(Map<String,Object> data);

	public Map<String,Object> getAllRoles(Map<String,Object> data);
	
	public String deleteDocument(Map<String,Object> data);
	
	public String checkAkanaCallLocally();

	public Map<String, Object> getManagersForTopSites(String businessSegment,Map<String, Object> params);

	public Map<String, Object> getAccountManagers(String businessSegment,Map<String,Object> data);

	public Map<String, Object> getMarketIndustryDescDropdown(Map<String, Object> data);
	
	public String importIBOData(InputStream inputStream,  String fileName, String userSSO);
	
	public void exportEquipmentData(HttpServletResponse responses,Map<String,Object> filterData);
}

