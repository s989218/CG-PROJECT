package fms.utils;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;




import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.google.gson.Gson;

import fms.constants.FMSVariableConstants;


public class Utils {

	private static final Logger log = Logger.getLogger(Utils.class);
	
	 private Utils() {
		 
	 }
	 public static String nullCheck(Object val){
		 try{
			 if(val.toString().isEmpty()){
				 return "";
			 }
			 else
			 {
				 return val.toString();
			 }
		 }
		 catch(Exception ex){
			 return "";
		 }
	 }
	 
	 public static int nullCheckInt(Object val){
		 try{
			 if(val != null){
				 return Integer.parseInt(val.toString());
			 }else{
				 return 0;
			 }
		 }catch(Exception ex){
			 return 0;
		 }
	 }
	 
	public static String getValidation(String val) {
		if (val != null && !val.isEmpty()) {
				return val;			
		} else {
			return "";
		}
	}
	
	public static int getValidationInt(int val) {
		if (val !=0) {
				return val;			
		} else {
			return 0;
		}
	}
	
	public static String getValidation(Object val) {
		if (val != null) {
				return val.toString();			
		} else {
			return "";
		}
	}
	
	public static boolean getValidationForBoolean(Object val) {
		if (val != null && "true".equalsIgnoreCase(val.toString())) {
			return true;			
		} else {
			return false;
		}
	}
	
	public static Double getNumericValidation(Object val) {		
		if (val != null) {
			return Double.parseDouble(val.toString()); 			
		} else {
			return 0.0;
		}
	}
	
	public static Integer getIntegerValidation(Object val) {		
		if (val != null) {
			return Integer.parseInt(val.toString()); 			
		} else {
			return 0;
		}
	}
	
	public static void sendSummaryComplEmail() {
		try {

			String to = "sitaram.rai@ge.com";
            String from = "sitaram.rai@ge.com";
            String host = "mail.ad.ge.com";

            Properties properties = new Properties();
            properties.setProperty("mail.user", "GE mail id");
            properties.setProperty("mail.transport.protocol","smtp");
            properties.setProperty("mail.smtp.auth", "false");
            properties.setProperty("mail.smtp.starttls.enable", "false");
            properties.setProperty("mail.smtp.socketFactory.port", "25");
            properties.setProperty("mail.smtp.host", host);
            properties.setProperty("http.proxyHost", "sjc1intproxy01.crd.ge.com");
            properties.setProperty("http.proxyPort", "8080");
            properties.setProperty("https.proxyHost", "sjc1intproxy01.crd.ge.com");
            properties.setProperty("https.proxyPort", "8080");
            Session session = Session.getDefaultInstance(properties);
           MimeMessage message = new MimeMessage(session);
           message.setFrom(new InternetAddress(from));
           message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
           message.setSubject("TEST mail");
           message.setText("We are testing email functinality for FMS App");
           Transport.send(message);
           
		} catch (Exception mex) {
			log.trace(mex);
		}
		
	}
	
    public static List<String> getEquipmentHeaderList(){
    	List<String> headerList = new ArrayList<>();
    	headerList.add("Gib Sr #");
    	headerList.add("Site Cust Name");
    	headerList.add("Serv Manager First");
    	headerList.add("Serv Manager Last");
    	headerList.add("Region");
    	headerList.add("Unit Status Desc");
    	headerList.add("Site Cust Country");
    	headerList.add("Serv Rel Desc OnG");
    	headerList.add("Tech Desc Og");
    	headerList.add("Oem Location Desc");
    	headerList.add("Market Segment Desc");
    	headerList.add("GE Duns Name");
    	headerList.add("Maintenance Policy Code");
    	headerList.add("Est. serv. Start Date");
    	headerList.add("Est. serv. Hrs. Count");
    	headerList.add("Level");
    	headerList.add("Avg Repair Value");
    	headerList.add("Avg Parts Value");
    	headerList.add("Avg Svcs Value");
    	headerList.add("Av ManPower");
    	headerList.add("Av AUX");
    	headerList.add("Av F2F");
    	headerList.add("Av Total");	
    	headerList.add("Site Name Alias");
    	headerList.add("Maintenance Policy Id");
    	headerList.add("Maintenance Policy Desc");
    	headerList.add("Install LT Days");
    	headerList.add("Other Maintenance Policy");
    	headerList.add("Est Manuf Complete");
    	headerList.add("Est Ship Date");
    	headerList.add("Est. serv. Hrs. Date");
    	headerList.add("Maintenance Year");
    	headerList.add("C HQ Customer Name");
    	headerList.add("C HQ customer Country");
    	headerList.add("Dom Customer Duns");
    	headerList.add("Dom Customer Name");
    	headerList.add("Tech Desc");
    	headerList.add("Tech Code Og");
    	headerList.add("Equip Code");
    	headerList.add("Equip Desc");
    	headerList.add("Equip Eng Desc");
    	headerList.add("Unit Ship Date");
    	headerList.add("Unit Code Date");
    	headerList.add("Account Manager Last");    	
    	headerList.add("Market Industry Desc");
    	headerList.add("Sales Channel Desc Gib");
    	headerList.add("Serv Relation System Desc");
    	headerList.add("Control System desc");
    	headerList.add("Serv Type Desc");
    	headerList.add("Driven Equip. Desc");
    	headerList.add("C Market");
    	headerList.add("Prod Esc PL");
    	headerList.add("FFh Count");
    	headerList.add("Glo Customer Duns");
    	headerList.add("Glo Customer Name");
    	headerList.add("GE Global Duns");
    	headerList.add("Site Customer Duns");
    	headerList.add("Site Customer City");
    	headerList.add("Tier Cod");
    	headerList.add("Eng Project ref");
    	headerList.add("OEM Serial Number");
    	headerList.add("Parent Serial Number");
    	headerList.add("Serv Factor");
		return headerList;
    }
       
    public static List<String> getIPMsHeadersList(){
    	List<String> headerList = new ArrayList<>();
    	headerList.add("CM TOTAL");
    	headerList.add("REGION");
    	headerList.add("CONCATENATE");
    	headerList.add("P&L");
    	headerList.add("PRODUCT");
    	headerList.add("END USER CUSTOMER NAME");
    	headerList.add("CM$/1000");
    	headerList.add("STATUS");
    	headerList.add("WB COMMENT");
    	headerList.add("NOTE");
    	headerList.add("DUE DATE");
    	headerList.add("TREND");
    	headerList.add("R/O");
		return headerList;
    }
    
	public static void downloadFile(String fileName, SXSSFWorkbook workbook, HttpServletResponse response) {
		try
		{
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbook.write(bos);
			bos.close();
			byte[] bytes = bos.toByteArray();
			response.setHeader(FMSVariableConstants.CONTENTDISPOSITION, "attachment; filename="+fileName);
			response.getOutputStream().write(bytes);
			response.flushBuffer();
		}
		catch(IOException e)
		{
			log.info(e);
		}
	}
	public static List<String> getSpotFireMonthst(){
    	List<String> monthList = new ArrayList<>();
    	monthList.add("0");
    	monthList.add("1");
    	monthList.add("2");
    	monthList.add("3");
    	monthList.add("4");
    	monthList.add("5");
    	monthList.add("6");
    	monthList.add("7");
    	monthList.add("8");
    	monthList.add("9");
    	monthList.add("10");
    	monthList.add("11");
    	monthList.add("12");
		return monthList;
    }
	
	public static String jsonConverter(Object obj) {
		Gson gson = new Gson();
		return gson.toJson(obj);
		
	}
	
	public static int getCurrentYear(){
		Calendar cal = Calendar.getInstance();
		return cal.get(Calendar.YEAR);
	}
	
	public static int getCurrentQuarter(){
		Calendar cal = Calendar.getInstance();
		int month = cal.get(Calendar.MONTH);
		int quarter = 0;
        if (month <= 3) {
            quarter = 1;
        } else if (month >3 && month <= 6) {
            quarter = 2;
        } else if (month >6 && month <= 9) {
            quarter = 3;
        } else {
            quarter = 4;
        }
        
        return quarter;
	}
	
	public static List<String> getDMDataHeaderList(){
    	List<String> headerList = new ArrayList<>();
    	headerList.add("Oppty Id");
    	headerList.add("Project Number");
    	headerList.add("Primary Sales Name");
    	headerList.add("Primary Region");
    	headerList.add("Primary Country");
    	headerList.add("Forecast Category");
    	headerList.add("Business Tier 3");
    	headerList.add("End User account Name");
    	headerList.add("Expected Order Year");
    	headerList.add("Expected Order Quarter");
    	headerList.add("Oppty Sales Stage");
    	headerList.add("Record Type Id");
    	headerList.add("Oppty Number");
    	headerList.add("Oppty Name");
    	headerList.add("Last Sales Stage Changed");
    	headerList.add("Expected Order Date");
    	headerList.add("Primary Industry");
    	headerList.add("Project Name");
    	headerList.add("Convertible This Qqtr");
    	headerList.add("Oppty Amount USD");
    	headerList.add("Oppty CM USD");
    	headerList.add("Primary Sales Id");
    	headerList.add("Is Comops Needed");
    	headerList.add("Comm Account Name");
    	headerList.add("End User Account Duns");
    	headerList.add("Deal Risk Path");
    	headerList.add("Deal Risk Level");
    	headerList.add("Deal Quote Type");
    	headerList.add("Rfq Received Date");
    	headerList.add("Bid Due Date");
    	headerList.add("Expected Delivery Date");
    	headerList.add("Bid Sent Date");
    	headerList.add("Disp Primary Reason");
    	headerList.add("Global Account Class");
    	headerList.add("Global Account Type");
    	headerList.add("Rep Business Tier 3");
    	headerList.add("Rep Business Tier 4");
    	headerList.add("Rep Biz Abbr Tier4");
    	headerList.add("Project Flow Type");
    	headerList.add("Created By Name");
    	headerList.add("Created Date");
    	headerList.add("Stale Deal Indicator");
    	headerList.add("Deal Budgetary Type");
    	headerList.add("Deal Unsolicited Type");
    	headerList.add("Oppty External Id");
    	
    	return headerList;
    }
	
	public static List<String> getOutageDataHeaderList(){
    	List<String> headerList = new ArrayList<>();
	    	headerList.add("N Event Id");
	    	headerList.add("C Gib Serial Number");
	    	headerList.add("C Service Mgr Email");
	    	headerList.add("D Event Date");
	    	headerList.add("C Og Sales Region");
	    	headerList.add("C Site Customer Country");
	    	headerList.add("C Unit Status Desc");
	    	headerList.add("C Service Relation Desc Og");
	    	headerList.add("C Technology Desc Og");
	    	headerList.add("C Equipment Desc");
	    	headerList.add("C Market Segment Desc");
	    	headerList.add("N Site Customer Name");
	    	headerList.add("C Oem Location Desc");
	    	headerList.add("GE Duns Name");
	    	headerList.add("Event Year");
	    	headerList.add("Event Quarter");
	    	headerList.add("Event Status Desc");
	    	headerList.add("N Maint Policy Cyc");
	    	headerList.add("N Maint Level Seq");
	    	headerList.add("T Event Notes");
	    	headerList.add("C Dem Svcs Status");
	    	headerList.add("C Usr Ins");
	    	headerList.add("D Ins");
	    	headerList.add("C Event Dem Status Parts");
	    	headerList.add("C Event Dem Status Svcs");
	    	headerList.add("C event Dem Status Repairs");
	    	headerList.add("F Unsoliced Status Flag");
	    	headerList.add("D Est Service Start Date");
	    	headerList.add("N Est Serv Hours Count");
	    	headerList.add("N Maint Year");
	    	headerList.add("N Cust Loyalty Desc Parts");
	    	headerList.add("N Cust Behavior Desc Parts");
	    	headerList.add("N Site Customer Duns");
	    	headerList.add("C Site Name Alias");
	    	headerList.add("C Site Customer City");
	    	headerList.add("C Technology Desc");
	    	headerList.add("C Eng Project Ref");
	    	headerList.add("D Unit Ship Date");
	    	headerList.add("D Unit Cod Date");
	    	headerList.add("C Account Mgr Email");
	    	headerList.add(" Maint Level COD");
	    	headerList.add("Maint Level Desc");
    	return headerList;
    }
	
	public static List<String> getServiceReqDataHeaderList(){
	       List<String> headerList = new ArrayList<>();
	       headerList.add("Case Number");
	       headerList.add("Current Type Of Issue");
	       headerList.add("Assigned Group");
	       headerList.add("State");
	       headerList.add("Opened");
	       headerList.add("Project Phase");
	       headerList.add("Status");
	       headerList.add("Job Type");
	       headerList.add("Customer Name");
	       headerList.add("Machine Technology OG");
	       headerList.add("Event Year");
	       headerList.add("Event Quarter");
	       headerList.add("Original Type Of Issue");
	       headerList.add("Issue Event Date");
	       headerList.add("Customer Add Request");
	       headerList.add("Suggested by Red Flag Review");
	       headerList.add("RCA Required by Customer");
	       headerList.add("EHS Impact");
	       headerList.add("Category");
	       headerList.add("Cur Sta Last in Actual Date");
	       headerList.add("Entry in the Current Status");
	       headerList.add("As Running Last in Date");
	       headerList.add("As Running Last out Date");
	       headerList.add("Tech Solution Type");
	       headerList.add("Software Team Needed");
	       headerList.add("Job Type Details");
	       headerList.add("Business");
	       headerList.add("Expected Resolutin Date");
	       headerList.add("Machine Type");
	       headerList.add("Machine Technology");
	       headerList.add("Control Panel Type");
	       headerList.add("COD");
	       headerList.add("Costing Project to be Charged");
	       headerList.add("Project Manager");
	       headerList.add("Insta Manager Coordinator");
	       headerList.add("PROBLEM_DESCRIPTION");
	       headerList.add("CIN");
	       headerList.add("Assigned Function");
	       headerList.add("Actual vs Sup Mate Sol");
	       headerList.add("Supplier Name Mate Sol");
	       headerList.add("Sol Description");
	       headerList.add("As Running Needed");
	       headerList.add("Mate Needed");
	       headerList.add("Supplier Resp");
	       headerList.add("WFCA Time in Valid");
	       headerList.add("WFCA Time in Sol");
	       headerList.add("WFCA Time in FULF SP");
	       headerList.add("WFCA Time in IMPLE");
	       headerList.add("WFCA Time in as Built");
	       headerList.add("WFCA Time in Expert ASS");
	       return headerList;
	    }

	
	public static List<String> getIBHeadersList(){
        List<String> headerList = new ArrayList<>();
        headerList.add("Region");
        headerList.add("Site Customer");
        headerList.add("Technology");
        headerList.add("Serial Number");
        headerList.add("IBO");
        headerList.add("Unit Status");
        headerList.add("Site Name");
        headerList.add("OEM Location");
        headerList.add("GE Duns");
        headerList.add("Segment");
        headerList.add("Country");
               return headerList;
     }
 public static List<String> getOrdersHeadersList(){
        List<String> headerList = new ArrayList<>();
        headerList.add("Region");
        headerList.add("Site Customer");
        headerList.add("Technology");
        headerList.add("Order Value OP Rate");
        headerList.add("Service Type");
        headerList.add("ME Tier 4");
        headerList.add("Opportunity ID");
        headerList.add("GE Duns");
        headerList.add("Segment");
        headerList.add("Tier 3");
        headerList.add("Country");
               return headerList;
     }
 
  public static List<String> getDMHeadersList(){
        List<String> headerList = new ArrayList<>();
        headerList.add("Region");
        headerList.add("Site Customer");
        headerList.add("Technology");
        headerList.add("Serial Number");
        headerList.add("Opportunity Amount");
        headerList.add("Forecast Category");
        headerList.add("Expected Order Date");
        headerList.add("Opportunity ID");
        headerList.add("GE Duns");
        headerList.add("Segment");
        headerList.add("Tier 3");
        headerList.add("Country");
               return headerList;
     }
 public static List<String> getOutagesHeadersList(){
        List<String> headerList = new ArrayList<>();
        headerList.add("Region");
        headerList.add("Site Customer");
        headerList.add("Technology");
        headerList.add("Serial Number");
        headerList.add("Maintenance Level");
        headerList.add("Event Status");
        headerList.add("Event Date");
        headerList.add("Event ID");
        headerList.add("GE Duns");
        headerList.add("Segment");
        headerList.add("Country");
               return headerList;
     }
 
  public static List<String> getServiceRequestHeadersList(){
        List<String> headerList = new ArrayList<>();
        headerList.add("Site Customer");
        headerList.add("Technology");
        headerList.add("Issue Type");
        headerList.add("State");
        headerList.add("Opened Date");
        headerList.add("Case Number");
        headerList.add("GE Duns");
               return headerList;
     }
  
  public static List<String> getMEMappingList(){
      List<String> headerList = new ArrayList<>();
      headerList.add("ME Management Entity Code");
      headerList.add("ME Mapping Incl SC Corrections");
      headerList.add("ME P and L");
      headerList.add("ME SVC or EQ");
      headerList.add("ME Tier 3");
      headerList.add("ME DM Tier 3");
      headerList.add("ME Tier 4");
      headerList.add("ME Usage");
             return headerList;
   }
  
  public static List<String> getProductMappingList(){
      List<String> headerList = new ArrayList<>();
      headerList.add("Product Type DESC");
      headerList.add("Product Mapping");
      return headerList;
   }
  
  public static List<String> getSegmentMappingList(){
      List<String> headerList = new ArrayList<>();
      headerList.add("SM SRC New OG P&L");
      headerList.add("Segment Mapping");
      headerList.add("Market Industry");
             return headerList;
   }
    	  
  public static List<String> getPenetrationDashboardList(String name){
      List<String> headerList = new ArrayList<>();
      headerList.add("State");
      headerList.add("Latitude");
      headerList.add("Longitude");
      headerList.add(name);
      headerList.add("IBO value");
      headerList.add("IBO Percentage");
      headerList.add("Performance Status");
             return headerList;
   }
  public static List<String> getPenetrationDashboardListUnmapped(){
      List<String> headerList = new ArrayList<>();
      headerList.add("Site");
      headerList.add("Country");
      headerList.add("Region");
      headerList.add("IBO value");
             return headerList;
   }
  
  public static List<String> getPenetrationMetricsReportNames(){
	  List<String> reportName = new ArrayList<>();
	  reportName.add("fleet_coverage");
	  reportName.add("fleet_penetration");
	  reportName.add("fleet_pen_f2f");
	  reportName.add("dollar_by_ib");
	  reportName.add("caloric_index");
	  reportName.add("conversion_index");
	  reportName.add("ibo_by_region");
	  reportName.add("rev_dollar_by_region");
	  reportName.add("parts_fleet_penetration");
	  reportName.add("repairs_fleet_penetration");
	  reportName.add("svcs_fleet_penetration");
	  reportName.add("ib_by_region");
	  reportName.add("ibo_by_tech");
	  reportName.add("ib_by_tech");
	  return reportName;
  }
  
  public static List<String> getPenetrationMetricsCountryReportNames(){
	  List<String> reportName = new ArrayList<>();
	  reportName.add("fleet_coverage");
	  reportName.add("fleet_penetration");
	  reportName.add("fleet_pen_f2f");
	  reportName.add("dollar_by_ib");
	  reportName.add("caloric_index");
	  reportName.add("conversion_index");
	return reportName;
	  
  }
  
  public static List<String> getPenetrationMetricsTechnologyReportNames(){
	  List<String> reportName = new ArrayList<>();
	  reportName.add("fleet_coverage");
	  reportName.add("fleet_penetration");
	  reportName.add("fleet_pen_f2f");
	  reportName.add("caloric_index");
	  return reportName;
  }
  
}
