package fms.bean;

import java.io.Serializable;

public class FMSCommitmentDataBean implements Serializable{
	
	private static final long serialVersionUID = 2069061748396484839L;
	private String commitmentDate;
	private String dateStamp;
	private String downloadDate;
	private String downloadUpdateDate;
	private String lineNumber;
	private String projectManager;
	private String projectNumber;
	private String remarks;
	private String userId;
	private String primaryId;
	private String salesTqle;
	private String cmTqle;
	public String getCommitmentDate() {
		return commitmentDate;
	}
	public void setCommitmentDate(String commitmentDate) {
		this.commitmentDate = commitmentDate;
	}
	public String getDateStamp() {
		return dateStamp;
	}
	public void setDateStamp(String dateStamp) {
		this.dateStamp = dateStamp;
	}
	public String getDownloadDate() {
		return downloadDate;
	}
	public void setDownloadDate(String downloadDate) {
		this.downloadDate = downloadDate;
	}
	public String getDownloadUpdateDate() {
		return downloadUpdateDate;
	}
	public void setDownloadUpdateDate(String downloadUpdateDate) {
		this.downloadUpdateDate = downloadUpdateDate;
	}
	public String getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}
	public String getProjectManager() {
		return projectManager;
	}
	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}
	public String getProjectNumber() {
		return projectNumber;
	}
	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPrimaryId() {
		return primaryId;
	}
	public void setPrimaryId(String primaryId) {
		this.primaryId = primaryId;
	}
	public String getSalesTqle() {
		return salesTqle;
	}
	public void setSalesTqle(String salesTqle) {
		this.salesTqle = salesTqle;
	}
	public String getCmTqle() {
		return cmTqle;
	}
	public void setCmTqle(String cmTqle) {
		this.cmTqle = cmTqle;
	}
	
	
}
