package fms.bean;

import java.io.Serializable;

public class FMSSpotFireDataBean implements Serializable{

	private static final long serialVersionUID = -3932175163398839631L;
	
	private String actualCost;
	private String actualShipmentDate;
	private String actualShipmentQuarter;
	private String agreementIddelProgeto;
	private String agreementName;
	private String amountReadyHP;
	
	private String amountReadySP;
	private String amountShipped;
	private String amtInShipping;
	private String amtNotReady;
	private String areIncGlobops;
	private String awb;
	private String baseline;
	private String basket;
	private String bookingMonth;
	private String bookingYear;
	
	private String boxNumber;
	private String oUName;
	private String bookingDate;
	private String boxClosureDate;
	private String bucCode;
	private String businessSegment;
	private String buyerCustCode;
	private String buyerCustCountryDesc;
	private String buyerCustName;
	private String cmGlobalContract;
	
	private String cmPerSold;
	private String cmPercent;
	private String contrPerShippAllwd;
	private String contractNumber;
	private String costingProject;
	private String csAgreementType;
	private String csRegion;
	private String csSubRegion;
	private String customerPOAmount;
	private String customerPONumber;
	
	private String cwdQuarter;
	private String cwdWeek;
	private String cwdYear;
	private String ddtDate;
	private String ddtNumber;
	private String deliverableNum;
	private String deliveryTerm;
	private String deliveryStatus;
	private String descreZoneClasse;
	private String discoutExtraPrice;
	
	private String dolDiscountPrice;
	private String dollarPrice;
	private String dpsRegion;
	private String dpsSubRegion;
	private String dwLoadDate;
	private String dwUpdateDate;
	private String earlyDeliveryAllowed;
	private String endUserCountryDesc;
	private String endUserCountryCode;
	private String endUserCustName;
	
	private String fxRate;
	private String g3Promised;
	private String gratisSI;
	private String grossWeight;
	private String height;
	private String iC;
	private String ibasEventId;
	private String invoiceAmount;
	private String invoiceDate;
	private String invoiceNumber;
	
	private String invoiceStatus;
	private String invoiceStatusChangeDt;
	private String itemCode;
	private String itemDescription;
	private String legalEntityCode;
	private String legalEntityName;
	private String length;
	private String lineBilledAmt;
	private String lineId;
	private String lineStatus;
	
	private String lineTrueCost;
	private String market;
	private String mngmtEntity;
	private String mngmtEntityDesc;
	private String motherJob;
	private String moveOrder;
	private String msRegion;
	private String multipleBox;
	private String netAmount;
	private String netWeight;
	
	private String orderType;
	private String orderedDate;
	private String orderedQuantity;
	private String otm;
	private String pAndL;
	private String penalty;
	private String poCurrency;
	private String poIRLineNumber;
	private String poNumber;
	private String poPromiseDate;
	
	private String product;
	private String productLine;
	private String projectManager;
	private String projectType;
	private String promiseDate;
	private String rescheduleMonth;
	private String rescheduleQuarter;
	private String rescheduleYear;
	private String residualPortSales;
	private String salesForecastingDate;
	
	private String salesForecastingMnth;
	private String salesForecastingQuarter;
	private String salesForecastingYear;
	private String scheduleShipDate;
	private String soCreationDate;
	private String soCwd;
	private String soLine;
	private String soStatus;
	private String supplierId;
	private String supplierName;
	
	private String supplyNumber;
	private String supplyType;
	private String tpRate;
	private String transferPrice;
	private String ttDate;
	private String unitCost;
	private String unitSellingPrice;
	private String unitTrueCost;
	private String userItemDescription;
	private String vatAmount;
	
	private String width;
	private String progress;
	private String site;
	private String euroDiscountPrice;
	private String euroPrice;
	private String invoiceWeek;
	private String invoiceYear;
	private String maxShippingDate;
	private String oldBoxCategory;
	private String oldBoxDays;
	
	private String partsStatus;
	private String promiseDateMonth;
	private String promiseDateYear;
	private String totalProInvoice;
	private String fxRateEur;
	private String primaryKey;
	private String salesType;
	private String lineType;
	private String rtsDate;
	private String tpPercentage;
	
	private String poReleaseDate;
	private String porReleaseDate;
	private String region;
	private String custPOLineNum;
	private String ttTime;
	private String leadTime;
	private String loadingProgress;
	private String subRegion;
	private String shipSetName;
	private String salesDateBkp;
	
	private String ogRegion;
	private String machineSN;
	private String taskNumber;
	private String advFlag;
	private String discountAmount;
	private String reversalAmount;
	private String manager;
	private String storage;
	
	private String commitmentDate;
	private String dateStamp;
	private String downloadDate;
	private String downloadUpdateDate;
	private String lineNumber;
	private String projectManagerCommitment;
	private String projectNumber;
	private String remarks;
	private String userId;
	private String primaryId;
	private String salesTqle;
	private String cmTqle;
	
	
	public String getActualCost() {
		return actualCost;
	}
	public void setActualCost(String actualCost) {
		this.actualCost = actualCost;
	}
	public String getBookingYear() {
		return bookingYear;
	}
	public void setBookingYear(String bookingYear) {
		this.bookingYear = bookingYear;
	}
	public String getBookingMonth() {
		return bookingMonth;
	}
	public void setBookingMonth(String bookingMonth) {
		this.bookingMonth = bookingMonth;
	}
	public String getProjectType() {
		return projectType;
	}
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getActualShipmentDate() {
		return actualShipmentDate;
	}
	public void setActualShipmentDate(String actualShipmentDate) {
		this.actualShipmentDate = actualShipmentDate;
	}
	public String getActualShipmentQuarter() {
		return actualShipmentQuarter;
	}
	public void setActualShipmentQuarter(String actualShipmentQuarter) {
		this.actualShipmentQuarter = actualShipmentQuarter;
	}
	public String getAgreementIddelProgeto() {
		return agreementIddelProgeto;
	}
	public void setAgreementIddelProgeto(String agreementIddelProgeto) {
		this.agreementIddelProgeto = agreementIddelProgeto;
	}
	public String getAgreementName() {
		return agreementName;
	}
	public void setAgreementName(String agreementName) {
		this.agreementName = agreementName;
	}
	public String getAmountReadyHP() {
		return amountReadyHP;
	}
	public void setAmountReadyHP(String amountReadyHP) {
		this.amountReadyHP = amountReadyHP;
	}
	public String getAmountReadySP() {
		return amountReadySP;
	}
	public void setAmountReadySP(String amountReadySP) {
		this.amountReadySP = amountReadySP;
	}
	public String getAmountShipped() {
		return amountShipped;
	}
	public void setAmountShipped(String amountShipped) {
		this.amountShipped = amountShipped;
	}
	public String getAmtInShipping() {
		return amtInShipping;
	}
	public void setAmtInShipping(String amtInShipping) {
		this.amtInShipping = amtInShipping;
	}
	public String getAmtNotReady() {
		return amtNotReady;
	}
	public void setAmtNotReady(String amtNotReady) {
		this.amtNotReady = amtNotReady;
	}
	public String getAreIncGlobops() {
		return areIncGlobops;
	}
	public void setAreIncGlobops(String areIncGlobops) {
		this.areIncGlobops = areIncGlobops;
	}
	public String getAwb() {
		return awb;
	}
	public void setAwb(String awb) {
		this.awb = awb;
	}
	public String getBaseline() {
		return baseline;
	}
	public void setBaseline(String baseline) {
		this.baseline = baseline;
	}
	public String getBasket() {
		return basket;
	}
	public void setBasket(String basket) {
		this.basket = basket;
	}
	public String getBoxNumber() {
		return boxNumber;
	}
	public void setBoxNumber(String boxNumber) {
		this.boxNumber = boxNumber;
	}
	public String getoUName() {
		return oUName;
	}
	public void setoUName(String oUName) {
		this.oUName = oUName;
	}
	public String getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}
	public String getBoxClosureDate() {
		return boxClosureDate;
	}
	public void setBoxClosureDate(String boxClosureDate) {
		this.boxClosureDate = boxClosureDate;
	}
	public String getBucCode() {
		return bucCode;
	}
	public void setBucCode(String bucCode) {
		this.bucCode = bucCode;
	}
	public String getBusinessSegment() {
		return businessSegment;
	}
	public void setBusinessSegment(String businessSegment) {
		this.businessSegment = businessSegment;
	}
	public String getBuyerCustCode() {
		return buyerCustCode;
	}
	public void setBuyerCustCode(String buyerCustCode) {
		this.buyerCustCode = buyerCustCode;
	}
	public String getBuyerCustCountryDesc() {
		return buyerCustCountryDesc;
	}
	public void setBuyerCustCountryDesc(String buyerCustCountryDesc) {
		this.buyerCustCountryDesc = buyerCustCountryDesc;
	}
	public String getBuyerCustName() {
		return buyerCustName;
	}
	public void setBuyerCustName(String buyerCustName) {
		this.buyerCustName = buyerCustName;
	}
	public String getCmGlobalContract() {
		return cmGlobalContract;
	}
	public void setCmGlobalContract(String cmGlobalContract) {
		this.cmGlobalContract = cmGlobalContract;
	}
	public String getCmPerSold() {
		return cmPerSold;
	}
	public void setCmPerSold(String cmPerSold) {
		this.cmPerSold = cmPerSold;
	}
	public String getCmPercent() {
		return cmPercent;
	}
	public void setCmPercent(String cmPercent) {
		this.cmPercent = cmPercent;
	}
	public String getContrPerShippAllwd() {
		return contrPerShippAllwd;
	}
	public void setContrPerShippAllwd(String contrPerShippAllwd) {
		this.contrPerShippAllwd = contrPerShippAllwd;
	}
	public String getContractNumber() {
		return contractNumber;
	}
	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}
	public String getCostingProject() {
		return costingProject;
	}
	public void setCostingProject(String costingProject) {
		this.costingProject = costingProject;
	}
	public String getCsAgreementType() {
		return csAgreementType;
	}
	public void setCsAgreementType(String csAgreementType) {
		this.csAgreementType = csAgreementType;
	}
	public String getCsRegion() {
		return csRegion;
	}
	public void setCsRegion(String csRegion) {
		this.csRegion = csRegion;
	}
	public String getCsSubRegion() {
		return csSubRegion;
	}
	public void setCsSubRegion(String csSubRegion) {
		this.csSubRegion = csSubRegion;
	}
	public String getCustomerPOAmount() {
		return customerPOAmount;
	}
	public void setCustomerPOAmount(String customerPOAmount) {
		this.customerPOAmount = customerPOAmount;
	}
	public String getCustomerPONumber() {
		return customerPONumber;
	}
	public void setCustomerPONumber(String customerPONumber) {
		this.customerPONumber = customerPONumber;
	}
	public String getCwdQuarter() {
		return cwdQuarter;
	}
	public void setCwdQuarter(String cwdQuarter) {
		this.cwdQuarter = cwdQuarter;
	}
	public String getCwdWeek() {
		return cwdWeek;
	}
	public void setCwdWeek(String cwdWeek) {
		this.cwdWeek = cwdWeek;
	}
	public String getCwdYear() {
		return cwdYear;
	}
	public void setCwdYear(String cwdYear) {
		this.cwdYear = cwdYear;
	}
	public String getDdtDate() {
		return ddtDate;
	}
	public void setDdtDate(String ddtDate) {
		this.ddtDate = ddtDate;
	}
	public String getDdtNumber() {
		return ddtNumber;
	}
	public void setDdtNumber(String ddtNumber) {
		this.ddtNumber = ddtNumber;
	}
	public String getDeliverableNum() {
		return deliverableNum;
	}
	public void setDeliverableNum(String deliverableNum) {
		this.deliverableNum = deliverableNum;
	}
	public String getDeliveryTerm() {
		return deliveryTerm;
	}
	public void setDeliveryTerm(String deliveryTerm) {
		this.deliveryTerm = deliveryTerm;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public String getDescreZoneClasse() {
		return descreZoneClasse;
	}
	public void setDescreZoneClasse(String descreZoneClasse) {
		this.descreZoneClasse = descreZoneClasse;
	}
	public String getDiscoutExtraPrice() {
		return discoutExtraPrice;
	}
	public void setDiscoutExtraPrice(String discoutExtraPrice) {
		this.discoutExtraPrice = discoutExtraPrice;
	}
	public String getDolDiscountPrice() {
		return dolDiscountPrice;
	}
	public void setDolDiscountPrice(String dolDiscountPrice) {
		this.dolDiscountPrice = dolDiscountPrice;
	}
	public String getDollarPrice() {
		return dollarPrice;
	}
	public void setDollarPrice(String dollarPrice) {
		this.dollarPrice = dollarPrice;
	}
	public String getDpsRegion() {
		return dpsRegion;
	}
	public void setDpsRegion(String dpsRegion) {
		this.dpsRegion = dpsRegion;
	}
	public String getDpsSubRegion() {
		return dpsSubRegion;
	}
	public void setDpsSubRegion(String dpsSubRegion) {
		this.dpsSubRegion = dpsSubRegion;
	}
	public String getDwLoadDate() {
		return dwLoadDate;
	}
	public void setDwLoadDate(String dwLoadDate) {
		this.dwLoadDate = dwLoadDate;
	}
	public String getDwUpdateDate() {
		return dwUpdateDate;
	}
	public void setDwUpdateDate(String dwUpdateDate) {
		this.dwUpdateDate = dwUpdateDate;
	}
	public String getEarlyDeliveryAllowed() {
		return earlyDeliveryAllowed;
	}
	public void setEarlyDeliveryAllowed(String earlyDeliveryAllowed) {
		this.earlyDeliveryAllowed = earlyDeliveryAllowed;
	}
	public String getEndUserCountryDesc() {
		return endUserCountryDesc;
	}
	public void setEndUserCountryDesc(String endUserCountryDesc) {
		this.endUserCountryDesc = endUserCountryDesc;
	}
	public String getEndUserCountryCode() {
		return endUserCountryCode;
	}
	public void setEndUserCountryCode(String endUserCountryCode) {
		this.endUserCountryCode = endUserCountryCode;
	}
	public String getEndUserCustName() {
		return endUserCustName;
	}
	public void setEndUserCustName(String endUserCustName) {
		this.endUserCustName = endUserCustName;
	}
	public String getFxRate() {
		return fxRate;
	}
	public void setFxRate(String fxRate) {
		this.fxRate = fxRate;
	}
	public String getG3Promised() {
		return g3Promised;
	}
	public void setG3Promised(String g3Promised) {
		this.g3Promised = g3Promised;
	}
	public String getGratisSI() {
		return gratisSI;
	}
	public void setGratisSI(String gratisSI) {
		this.gratisSI = gratisSI;
	}
	public String getGrossWeight() {
		return grossWeight;
	}
	public void setGrossWeight(String grossWeight) {
		this.grossWeight = grossWeight;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getiC() {
		return iC;
	}
	public void setiC(String iC) {
		this.iC = iC;
	}
	public String getIbasEventId() {
		return ibasEventId;
	}
	public void setIbasEventId(String ibasEventId) {
		this.ibasEventId = ibasEventId;
	}
	public String getInvoiceAmount() {
		return invoiceAmount;
	}
	public void setInvoiceAmount(String invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getInvoiceStatus() {
		return invoiceStatus;
	}
	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}
	public String getInvoiceStatusChangeDt() {
		return invoiceStatusChangeDt;
	}
	public void setInvoiceStatusChangeDt(String invoiceStatusChangeDt) {
		this.invoiceStatusChangeDt = invoiceStatusChangeDt;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public String getLegalEntityCode() {
		return legalEntityCode;
	}
	public void setLegalEntityCode(String legalEntityCode) {
		this.legalEntityCode = legalEntityCode;
	}
	public String getLegalEntityName() {
		return legalEntityName;
	}
	public void setLegalEntityName(String legalEntityName) {
		this.legalEntityName = legalEntityName;
	}
	public String getLength() {
		return length;
	}
	public void setLength(String length) {
		this.length = length;
	}
	public String getLineBilledAmt() {
		return lineBilledAmt;
	}
	public void setLineBilledAmt(String lineBilledAmt) {
		this.lineBilledAmt = lineBilledAmt;
	}
	
	public String getLineId() {
		return lineId;
	}
	public void setLineId(String lineId) {
		this.lineId = lineId;
	}
	public String getLineStatus() {
		return lineStatus;
	}
	public void setLineStatus(String lineStatus) {
		this.lineStatus = lineStatus;
	}
	public String getLineTrueCost() {
		return lineTrueCost;
	}
	public void setLineTrueCost(String lineTrueCost) {
		this.lineTrueCost = lineTrueCost;
	}
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	public String getMngmtEntity() {
		return mngmtEntity;
	}
	public void setMngmtEntity(String mngmtEntity) {
		this.mngmtEntity = mngmtEntity;
	}
	public String getMngmtEntityDesc() {
		return mngmtEntityDesc;
	}
	public void setMngmtEntityDesc(String mngmtEntityDesc) {
		this.mngmtEntityDesc = mngmtEntityDesc;
	}
	public String getMotherJob() {
		return motherJob;
	}
	public void setMotherJob(String motherJob) {
		this.motherJob = motherJob;
	}
	public String getMoveOrder() {
		return moveOrder;
	}
	public void setMoveOrder(String moveOrder) {
		this.moveOrder = moveOrder;
	}
	public String getMsRegion() {
		return msRegion;
	}
	public void setMsRegion(String msRegion) {
		this.msRegion = msRegion;
	}
	public String getMultipleBox() {
		return multipleBox;
	}
	public void setMultipleBox(String multipleBox) {
		this.multipleBox = multipleBox;
	}
	public String getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}
	public String getNetWeight() {
		return netWeight;
	}
	public void setNetWeight(String netWeight) {
		this.netWeight = netWeight;
	}
	public String getOrderedDate() {
		return orderedDate;
	}
	public void setOrderedDate(String orderedDate) {
		this.orderedDate = orderedDate;
	}
	public String getOrderedQuantity() {
		return orderedQuantity;
	}
	public void setOrderedQuantity(String orderedQuantity) {
		this.orderedQuantity = orderedQuantity;
	}
	public String getOtm() {
		return otm;
	}
	public void setOtm(String otm) {
		this.otm = otm;
	}
	public String getpAndL() {
		return pAndL;
	}
	public void setpAndL(String pAndL) {
		this.pAndL = pAndL;
	}
	public String getPenalty() {
		return penalty;
	}
	public void setPenalty(String penalty) {
		this.penalty = penalty;
	}
	public String getPoCurrency() {
		return poCurrency;
	}
	public void setPoCurrency(String poCurrency) {
		this.poCurrency = poCurrency;
	}
	public String getPoIRLineNumber() {
		return poIRLineNumber;
	}
	public void setPoIRLineNumber(String poIRLineNumber) {
		this.poIRLineNumber = poIRLineNumber;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public String getPoPromiseDate() {
		return poPromiseDate;
	}
	public void setPoPromiseDate(String poPromiseDate) {
		this.poPromiseDate = poPromiseDate;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getProductLine() {
		return productLine;
	}
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}
	public String getProjectManager() {
		return projectManager;
	}
	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}
	public String getPromiseDate() {
		return promiseDate;
	}
	public void setPromiseDate(String promiseDate) {
		this.promiseDate = promiseDate;
	}
	public String getRescheduleMonth() {
		return rescheduleMonth;
	}
	public void setRescheduleMonth(String rescheduleMonth) {
		this.rescheduleMonth = rescheduleMonth;
	}
	public String getRescheduleQuarter() {
		return rescheduleQuarter;
	}
	public void setRescheduleQuarter(String rescheduleQuarter) {
		this.rescheduleQuarter = rescheduleQuarter;
	}
	public String getRescheduleYear() {
		return rescheduleYear;
	}
	public void setRescheduleYear(String rescheduleYear) {
		this.rescheduleYear = rescheduleYear;
	}
	public String getResidualPortSales() {
		return residualPortSales;
	}
	public void setResidualPortSales(String residualPortSales) {
		this.residualPortSales = residualPortSales;
	}
	public String getSalesForecastingDate() {
		return salesForecastingDate;
	}
	public void setSalesForecastingDate(String salesForecastingDate) {
		this.salesForecastingDate = salesForecastingDate;
	}
	public String getSalesForecastingMnth() {
		return salesForecastingMnth;
	}
	public void setSalesForecastingMnth(String salesForecastingMnth) {
		this.salesForecastingMnth = salesForecastingMnth;
	}
	public String getSalesForecastingQuarter() {
		return salesForecastingQuarter;
	}
	public void setSalesForecastingQuarter(String salesForecastingQuarter) {
		this.salesForecastingQuarter = salesForecastingQuarter;
	}
	public String getSalesForecastingYear() {
		return salesForecastingYear;
	}
	public void setSalesForecastingYear(String salesForecastingYear) {
		this.salesForecastingYear = salesForecastingYear;
	}
	public String getScheduleShipDate() {
		return scheduleShipDate;
	}
	public void setScheduleShipDate(String scheduleShipDate) {
		this.scheduleShipDate = scheduleShipDate;
	}
	public String getSoCreationDate() {
		return soCreationDate;
	}
	public void setSoCreationDate(String soCreationDate) {
		this.soCreationDate = soCreationDate;
	}
	public String getSoCwd() {
		return soCwd;
	}
	public void setSoCwd(String soCwd) {
		this.soCwd = soCwd;
	}
	public String getSoLine() {
		return soLine;
	}
	public void setSoLine(String soLine) {
		this.soLine = soLine;
	}
	public String getSoStatus() {
		return soStatus;
	}
	public void setSoStatus(String soStatus) {
		this.soStatus = soStatus;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getSupplyNumber() {
		return supplyNumber;
	}
	public void setSupplyNumber(String supplyNumber) {
		this.supplyNumber = supplyNumber;
	}
	public String getSupplyType() {
		return supplyType;
	}
	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}
	public String getTpRate() {
		return tpRate;
	}
	public void setTpRate(String tpRate) {
		this.tpRate = tpRate;
	}
	public String getTransferPrice() {
		return transferPrice;
	}
	public void setTransferPrice(String transferPrice) {
		this.transferPrice = transferPrice;
	}
	public String getTtDate() {
		return ttDate;
	}
	public void setTtDate(String ttDate) {
		this.ttDate = ttDate;
	}
	public String getUnitCost() {
		return unitCost;
	}
	public void setUnitCost(String unitCost) {
		this.unitCost = unitCost;
	}
	public String getUnitSellingPrice() {
		return unitSellingPrice;
	}
	public void setUnitSellingPrice(String unitSellingPrice) {
		this.unitSellingPrice = unitSellingPrice;
	}
	public String getUnitTrueCost() {
		return unitTrueCost;
	}
	public void setUnitTrueCost(String unitTrueCost) {
		this.unitTrueCost = unitTrueCost;
	}
	public String getUserItemDescription() {
		return userItemDescription;
	}
	public void setUserItemDescription(String userItemDescription) {
		this.userItemDescription = userItemDescription;
	}
	public String getVatAmount() {
		return vatAmount;
	}
	public void setVatAmount(String vatAmount) {
		this.vatAmount = vatAmount;
	}
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	public String getProgress() {
		return progress;
	}
	public void setProgress(String progress) {
		this.progress = progress;
	}
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	public String getEuroDiscountPrice() {
		return euroDiscountPrice;
	}
	public void setEuroDiscountPrice(String euroDiscountPrice) {
		this.euroDiscountPrice = euroDiscountPrice;
	}
	public String getEuroPrice() {
		return euroPrice;
	}
	public void setEuroPrice(String euroPrice) {
		this.euroPrice = euroPrice;
	}
	public String getInvoiceWeek() {
		return invoiceWeek;
	}
	public void setInvoiceWeek(String invoiceWeek) {
		this.invoiceWeek = invoiceWeek;
	}
	public String getInvoiceYear() {
		return invoiceYear;
	}
	public void setInvoiceYear(String invoiceYear) {
		this.invoiceYear = invoiceYear;
	}
	public String getMaxShippingDate() {
		return maxShippingDate;
	}
	public void setMaxShippingDate(String maxShippingDate) {
		this.maxShippingDate = maxShippingDate;
	}
	public String getOldBoxCategory() {
		return oldBoxCategory;
	}
	public void setOldBoxCategory(String oldBoxCategory) {
		this.oldBoxCategory = oldBoxCategory;
	}
	public String getOldBoxDays() {
		return oldBoxDays;
	}
	public void setOldBoxDays(String oldBoxDays) {
		this.oldBoxDays = oldBoxDays;
	}
	public String getPartsStatus() {
		return partsStatus;
	}
	public void setPartsStatus(String partsStatus) {
		this.partsStatus = partsStatus;
	}
	public String getPromiseDateMonth() {
		return promiseDateMonth;
	}
	public void setPromiseDateMonth(String promiseDateMonth) {
		this.promiseDateMonth = promiseDateMonth;
	}
	public String getPromiseDateYear() {
		return promiseDateYear;
	}
	public void setPromiseDateYear(String promiseDateYear) {
		this.promiseDateYear = promiseDateYear;
	}
	public String getTotalProInvoice() {
		return totalProInvoice;
	}
	public void setTotalProInvoice(String totalProInvoice) {
		this.totalProInvoice = totalProInvoice;
	}
	public String getFxRateEur() {
		return fxRateEur;
	}
	public void setFxRateEur(String fxRateEur) {
		this.fxRateEur = fxRateEur;
	}
	public String getPrimaryKey() {
		return primaryKey;
	}
	public void setPrimaryKey(String primaryKey) {
		this.primaryKey = primaryKey;
	}
	public String getSalesType() {
		return salesType;
	}
	public void setSalesType(String salesType) {
		this.salesType = salesType;
	}
	public String getLineType() {
		return lineType;
	}
	public void setLineType(String lineType) {
		this.lineType = lineType;
	}
	public String getRtsDate() {
		return rtsDate;
	}
	public void setRtsDate(String rtsDate) {
		this.rtsDate = rtsDate;
	}
	public String getTpPercentage() {
		return tpPercentage;
	}
	public void setTpPercentage(String tpPercentage) {
		this.tpPercentage = tpPercentage;
	}
	public String getPoReleaseDate() {
		return poReleaseDate;
	}
	public void setPoReleaseDate(String poReleaseDate) {
		this.poReleaseDate = poReleaseDate;
	}
	public String getPorReleaseDate() {
		return porReleaseDate;
	}
	public void setPorReleaseDate(String porReleaseDate) {
		this.porReleaseDate = porReleaseDate;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCustPOLineNum() {
		return custPOLineNum;
	}
	public void setCustPOLineNum(String custPOLineNum) {
		this.custPOLineNum = custPOLineNum;
	}
	public String getTtTime() {
		return ttTime;
	}
	public void setTtTime(String ttTime) {
		this.ttTime = ttTime;
	}
	public String getLeadTime() {
		return leadTime;
	}
	public void setLeadTime(String leadTime) {
		this.leadTime = leadTime;
	}
	public String getLoadingProgress() {
		return loadingProgress;
	}
	public void setLoadingProgress(String loadingProgress) {
		this.loadingProgress = loadingProgress;
	}
	public String getSubRegion() {
		return subRegion;
	}
	public void setSubRegion(String subRegion) {
		this.subRegion = subRegion;
	}
	public String getShipSetName() {
		return shipSetName;
	}
	public void setShipSetName(String shipSetName) {
		this.shipSetName = shipSetName;
	}
	public String getSalesDateBkp() {
		return salesDateBkp;
	}
	public void setSalesDateBkp(String salesDateBkp) {
		this.salesDateBkp = salesDateBkp;
	}
	public String getOgRegion() {
		return ogRegion;
	}
	public void setOgRegion(String ogRegion) {
		this.ogRegion = ogRegion;
	}
	public String getMachineSN() {
		return machineSN;
	}
	public void setMachineSN(String machineSN) {
		this.machineSN = machineSN;
	}
	public String getTaskNumber() {
		return taskNumber;
	}
	public void setTaskNumber(String taskNumber) {
		this.taskNumber = taskNumber;
	}
	public String getAdvFlag() {
		return advFlag;
	}
	public void setAdvFlag(String advFlag) {
		this.advFlag = advFlag;
	}
	public String getDiscountAmount() {
		return discountAmount;
	}
	public void setDiscountAmount(String discountAmount) {
		this.discountAmount = discountAmount;
	}
	public String getReversalAmount() {
		return reversalAmount;
	}
	public void setReversalAmount(String reversalAmount) {
		this.reversalAmount = reversalAmount;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getStorage() {
		return storage;
	}
	public void setStorage(String storage) {
		this.storage = storage;
	}
	public String getCommitmentDate() {
		return commitmentDate;
	}
	public void setCommitmentDate(String commitmentDate) {
		this.commitmentDate = commitmentDate;
	}
	public String getDateStamp() {
		return dateStamp;
	}
	public void setDateStamp(String dateStamp) {
		this.dateStamp = dateStamp;
	}
	public String getDownloadDate() {
		return downloadDate;
	}
	public void setDownloadDate(String downloadDate) {
		this.downloadDate = downloadDate;
	}
	public String getDownloadUpdateDate() {
		return downloadUpdateDate;
	}
	public void setDownloadUpdateDate(String downloadUpdateDate) {
		this.downloadUpdateDate = downloadUpdateDate;
	}
	public String getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}
	public String getProjectManagerCommitment() {
		return projectManagerCommitment;
	}
	public void setProjectManagerCommitment(String projectManagerCommitment) {
		this.projectManagerCommitment = projectManagerCommitment;
	}
	public String getProjectNumber() {
		return projectNumber;
	}
	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPrimaryId() {
		return primaryId;
	}
	public void setPrimaryId(String primaryId) {
		this.primaryId = primaryId;
	}
	public String getSalesTqle() {
		return salesTqle;
	}
	public void setSalesTqle(String salesTqle) {
		this.salesTqle = salesTqle;
	}
	public String getCmTqle() {
		return cmTqle;
	}
	public void setCmTqle(String cmTqle) {
		this.cmTqle = cmTqle;
	}
		
	
}
