package fms.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class DataLakeSpotFireDatasource {

	@Bean(name = "dataLakeSpotfireDataSource")
   	@ConfigurationProperties(prefix="datasource.datalake.spotfire")
    public DataSource spotfireDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "dataLakeJdbc")
    @Autowired
    public JdbcTemplate spotfireJdbcTemplate(@Qualifier("dataLakeSpotfireDataSource") DataSource spotfireDataSource) {
        return new JdbcTemplate(spotfireDataSource);
    }
}
