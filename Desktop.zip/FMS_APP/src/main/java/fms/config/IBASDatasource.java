package fms.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;


@Configuration
public class IBASDatasource {
    @Bean(name = "ibasDataSource")
    @ConfigurationProperties(prefix="datasource.ibas")
    public DataSource ibasDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "ibasJdbc")
    @Autowired
    public JdbcTemplate ibasJdbcTemplate(@Qualifier("ibasDataSource") DataSource ibasDataSource) {
        return new JdbcTemplate(ibasDataSource);
    }
	
}
