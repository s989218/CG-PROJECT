package fms.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class OutageDatasource {


	@Bean(name = "outageDataSource")
	@ConfigurationProperties(prefix="datasource.outage")
	public DataSource outageDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean(name = "outageJdbc")
	public JdbcTemplate dmJdbcTemplate(@Qualifier("outageDataSource")DataSource outageDataSource) {
		return new JdbcTemplate(outageDataSource);
	}

}
