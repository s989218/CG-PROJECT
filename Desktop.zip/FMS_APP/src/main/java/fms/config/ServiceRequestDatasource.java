package fms.config;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class ServiceRequestDatasource {

	private final Logger log = Logger.getLogger(this.getClass());
	@Bean(name = "serviceRequestDataSource")
    @ConfigurationProperties(prefix="datasource.sr")
    public DataSource serviceRequestDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "srJdbc")
    public JdbcTemplate srJdbcTemplate(@Qualifier("serviceRequestDataSource")DataSource serviceRequestDataSource) {
    	log.info("!!!serviceRequestDataSource!!!"+serviceRequestDataSource);
        return new JdbcTemplate(serviceRequestDataSource);
    }

}