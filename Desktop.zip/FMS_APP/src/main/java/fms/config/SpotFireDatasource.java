package fms.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class SpotFireDatasource {

	@Bean(name = "spotfireDataSource")
    @ConfigurationProperties(prefix="datasource.spotfire")
    public DataSource spotfireDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "spotfireJdbc")
    @Autowired
    public JdbcTemplate spotfireJdbcTemplate(@Qualifier("spotfireDataSource") DataSource spotfireDataSource) {
        return new JdbcTemplate(spotfireDataSource);
    }
	
}
