package fms.dao;


import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import fms.bean.FMSCommitmentDataBean;
import fms.bean.FMSSpotFireDataBean;
import fms.constants.FMSQueryConstants;
import fms.mapper.CommitmentMapper;
import fms.mapper.CustomMapper;
import fms.mapper.SpotFireMapper;


@Repository
public class FMSDaoImpl implements IFMSDao {

	private static final Logger log = Logger.getLogger(FMSDaoImpl.class);

	@Autowired
	@Qualifier("obpJdbc")
	private JdbcTemplate obpJdbcTemplate;

	@Autowired
	@Qualifier("ibasJdbc")
	private JdbcTemplate ibasJdbcTemplate;

	@Autowired
	@Qualifier("spotfireJdbc")
	private JdbcTemplate spotfireJdbcTemplate;

	@Autowired
	@Qualifier("dmJdbc")
	private JdbcTemplate dmJdbcTemplate;

	@Autowired
	@Qualifier("outageJdbc")
	private JdbcTemplate outageJdbcTemplate;

	@Autowired
	@Qualifier("srJdbc")
	private JdbcTemplate serviceRequestJdbc;

	@Autowired
	@Qualifier("dataLakeJdbc")
	private JdbcTemplate datalakespotfireJdbc;

	@Override
	public List<FMSSpotFireDataBean> getSpotFireData(Map<String,String> postData) {
		log.info("getSpotFireData() in FMSDaoImpl");
		Object[] params = new Object[2];
		params[0] = postData.get("month");
		params[1] = postData.get("subRegion");
		return spotfireJdbcTemplate.query(FMSQueryConstants.RETRIEVE_SPOTFIRE_DATA,params, new SpotFireMapper());
	}

	@Override
	public List<FMSCommitmentDataBean> getCommitmentData() { 
		return spotfireJdbcTemplate.query(FMSQueryConstants.RETRIEVE_COMMITMENT_DATA,  new CommitmentMapper());
	}

	@Override
	public List<Map<String, Object>> getOBPData() {
		return obpJdbcTemplate.query(FMSQueryConstants.RETRIEVE_OBP_DATA,  new CustomMapper());
	}

	@Override
	public List<Map<String, Object>> getIBASData(Map<String,String> postData) {
		Object[] params = new Object[1];
		params[0] = postData.get("region");
		if("DTS".equalsIgnoreCase(postData.get("cProdExcPl").toString())){
			/**return ibasJdbcTemplate.query(FMSQueryConstants.RETRIEVE_IBAS_DATA_DTS,params,new CustomMapper());*/
			return ibasJdbcTemplate.query(FMSQueryConstants.RETRIEVE_IBAS_DATA,params,new CustomMapper());
		}else{
			return ibasJdbcTemplate.query(FMSQueryConstants.RETRIEVE_IBAS_DATA_TMS,params,new CustomMapper());
		}
	}

	@Override
	public List<String> getSpotFireSubRegions() {
		return spotfireJdbcTemplate.queryForList(FMSQueryConstants.RETRIEVE_SPOTFIRE_SUBREGIONS,String.class);
	}
	@Override
	public List<Map<String, Object>> getDMData(Map<String,String> postData) {
		try {
			log.info("inside getDMData() in DAOImpl");
			Object[] params = new Object[1];
			params[0] = postData.get("region");
			return dmJdbcTemplate.query(FMSQueryConstants.RETRIEVE_DM_DATA,params,  new CustomMapper());
		} catch (Exception e) {
			log.info("Error in fetching DM oracle data");
			return null;
		}

	} 


	@Override
	public List<String> getDMPrimaryRegion() {
		log.info("getDMPrimaryRegion() in FMSDaoImpl");
		return dmJdbcTemplate.queryForList(FMSQueryConstants.RETRIEVE_DM_DATA_PRIMARY_REGION,String.class);
	}

	@Override
	public List<Map<String, Object>> getOutageData(Map<String,String> postData) {
		Object[] params = new Object[1];
		params[0] = postData.get("Id");
		log.info("getOutageData() in FMSDaoImpl with Id : "+params[0]);
		if("".equals(params[0]) || params[0] == null){
			return outageJdbcTemplate.query(FMSQueryConstants.RETRIEVE_OUTAGE_DATA_NULL, new CustomMapper());
		}else{
			return outageJdbcTemplate.query(FMSQueryConstants.RETRIEVE_OUTAGE_DATA,params, new CustomMapper());
		}
	}

	@Override
	public List<Map<String, Object>> getServiceRequestdata(Map<String,String> postData){
		Object[] params = new Object[1];
		params[0] = postData.get("machineTech");
		log.info("getServiceRequestdata() in FMSDaoImpl");
		return serviceRequestJdbc.query(FMSQueryConstants.RETRIEVE_SERVICE_REQUEST_ORACLE_DATA,params,  new CustomMapper());
	}

	@Override
	public List<String> getIBASRegions(String data) {
		log.info("getIBASRegions() in FMSDaoImpl");
		if("DTS".equalsIgnoreCase(data)){
			return ibasJdbcTemplate.queryForList(FMSQueryConstants.RETRIEVE_IBAS_REGIONS_DTS,String.class);
		}else{
			return ibasJdbcTemplate.queryForList(FMSQueryConstants.RETRIEVE_IBAS_REGIONS_TMS,String.class);
		}
	}

	@Override
	public List<String> getOutageDemItemStatus() {
		log.info("getOutageDemItemStatus() in FMSDaoImpl");
		return outageJdbcTemplate.queryForList(FMSQueryConstants.RETRIEVE_OUTAGE_DEM_ITEM_STATUS,String.class);
	}

	@Override
	public List<String> getServiceRequestMacTech() {
		log.info("getServiceRequestMacTech() in FMSDaoImpl");
		return serviceRequestJdbc.queryForList(FMSQueryConstants.RETRIEVE_SERVICE_REQUEST_MAC_TECH,String.class);
	}

	@Override
	public List<FMSSpotFireDataBean> getDataLakeSpotFireData(Map<String,String> postData) {
		Object[] params = new Object[2];
		params[0] = postData.get("month");
		params[1] = postData.get("subRegion");
		return datalakespotfireJdbc.query(FMSQueryConstants.RETRIEVE_DATALAKE_SPOTFIRE_DATA,params, new SpotFireMapper());
	}

	@Override
	public List<String> getDataLakeSpotFireSubRegions() {
		return datalakespotfireJdbc.queryForList(FMSQueryConstants.RETRIEVE_DATALAKE_SPOTFIRE_SUBREGIONS,String.class);
	}
}	
