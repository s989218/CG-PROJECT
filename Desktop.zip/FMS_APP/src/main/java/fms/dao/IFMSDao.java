package fms.dao;

import java.util.List;
import java.util.Map;

import fms.bean.FMSCommitmentDataBean;
import fms.bean.FMSSpotFireDataBean;

public interface IFMSDao {

	public List<FMSSpotFireDataBean> getSpotFireData(Map<String,String> postData);

	public List<FMSCommitmentDataBean> getCommitmentData();

	public List<Map<String,Object>> getOBPData();

	public List<Map<String,Object>> getIBASData(Map<String,String> postData);

	public List<String> getSpotFireSubRegions();

	public List<Map<String,Object>> getDMData(Map<String,String> postData);

	public List<String> getDMPrimaryRegion();

	public List<Map<String,Object>> getOutageData(Map<String,String> postData);

	public List<Map<String,Object>> getServiceRequestdata(Map<String,String> postData);

	public List<String> getIBASRegions(String data);

	public List<String> getOutageDemItemStatus();

	public List<String> getServiceRequestMacTech();

	public List<FMSSpotFireDataBean> getDataLakeSpotFireData(Map<String,String> postData);

	public List<String> getDataLakeSpotFireSubRegions();
}
