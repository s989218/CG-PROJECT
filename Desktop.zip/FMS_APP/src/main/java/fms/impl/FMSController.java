package fms.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import fms.bean.FMSCommitmentDataBean;
import fms.bean.FMSSpotFireDataBean;
import fms.service.IFMSService;


@Controller
@RequestMapping("/fms")
public class FMSController {

	private static final Logger log = Logger.getLogger(FMSController.class);

	@Autowired
	private IFMSService objService;

	/*
	 * Get the spot fire data from the Oracle data base
	 */
	@RequestMapping(method=RequestMethod.POST,value="getSpotFireData",consumes="application/json", produces="application/json")
	@ResponseBody public List<FMSSpotFireDataBean> getSpotFireData(@RequestBody Map<String,String> postData) {
		log.info("getSpotFireData() in FMSController");   
		return objService.getSpotFireData(postData);
	}

	/*
	 * Get the Commitment data from the Oracle data base
	 */
	@RequestMapping(method=RequestMethod.GET,value="getCommitmentData")
	@ResponseBody public List<FMSCommitmentDataBean> getCommitmentData() {
		log.info("getCommitmentData() in FMSController ");   
		return objService.getCommitmentData();
	}

	/*
	 * Get OBP Details from Oracle data base
	 */
	@RequestMapping(method=RequestMethod.GET,value="getOBPData")
	@ResponseBody public List<Map<String, Object>> getOBPData() {
		log.info("getOBPData() in FMSController");
		return objService.getOBPData();
	}

	/*
	 * Get IBAS Details from Oracle data base
	 */
	@RequestMapping(method=RequestMethod.POST,value="getIBASData", consumes="application/json", produces="application/json")
	@ResponseBody public List<Map<String, Object>> getIBASData(@RequestBody Map<String,String> postData) {
		log.info("getIBASData() in FMSController");
		return objService.getIBASData(postData);
	}

	/***
	 * 
	 * IBAS sub region
	 */
	@RequestMapping(method=RequestMethod.POST,value="getIBASRegions")
	@ResponseBody public List<String> getIBASRegions(@RequestBody String data) { 
		return objService.getIBASRegions(data);
	}

	/*
	 *SpotFire SubRegions
	 */
	@RequestMapping(method=RequestMethod.GET,value="getSpotFireSubRegions")
	@ResponseBody public List<String> getSpotFireSubRegions() {   
		return objService.getSpotFireSubRegions();
	}

	@RequestMapping(method=RequestMethod.GET,value="checkGetMethod")
	@ResponseBody public String getGetData() {   
		return "Hello World This is Testing for GET methods... ";
	}

	@RequestMapping(method=RequestMethod.POST,value="checkPostMethod")
	@ResponseBody public String checkPostMethod(@RequestBody String data) {   
		return "Hi, checking post method, string sent to method is : " + data;
	}
	
	@RequestMapping(method=RequestMethod.GET,value="checkAkanaCallLocally",produces="application/json")
	@ResponseBody public List<String> checkAkanaCallLocally() {  
		List<String> akanaMessage = Arrays.asList("Hello !", " Akana Service Called ", "Successfuly!");
		return akanaMessage;
	}

	/*
	 * Get DM Details from Oracle data base
	 */
	@RequestMapping(method=RequestMethod.POST,value="getDMData",consumes="application/json", produces="application/json")
	@ResponseBody public List<Map<String, Object>> getDMData(@RequestBody Map<String,String> postData) {
		log.info("getDMData() in FMSController");
		return objService.getDMData(postData);
	}

	/*
	 * Get DM regions from Oracle data base
	 */
	@RequestMapping(method=RequestMethod.GET,value="getDMPrimaryRegion")
	@ResponseBody public List<String> getDMPrimaryRegion() {   
		return objService.getDMPrimaryRegion();
	}

	/*
	 * Get Outage Details from Oracle data base
	 */
	@RequestMapping(method=RequestMethod.POST,value="getOutageData", consumes="application/json", produces="application/json")
	@ResponseBody public List<Map<String, Object>> getOutageData(@RequestBody Map<String,String> postData) {
		log.info("getOutageData() in FMSController");
		return objService.getOutageData(postData);
	}

	@RequestMapping(method=RequestMethod.GET,value="getOutageDemItemStatus")
	@ResponseBody public List<String> getOutageDemItemStatus() {   
		return objService.getOutageDemItemStatus();
	}

	@RequestMapping(method=RequestMethod.POST,value="getServiceRequestdata", consumes="application/json", produces="application/json")
	@ResponseBody public List<Map<String, Object>> getServiceRequestdata(@RequestBody Map<String,String> postData) {
		log.info("getServiceRequestdata() in FMSController");
		return objService.getServiceRequestdata(postData);
	} 

	@RequestMapping(method=RequestMethod.GET,value="getServiceRequestMacTech")
	@ResponseBody public List<String> getServiceRequestMacTech() {   
		return objService.getServiceRequestMacTech();
	}


	/*
	 * Get the data lake spot fire data from the Oracle data base
	 */
	@RequestMapping(method=RequestMethod.POST,value="getDataLakeSpotFireData",consumes="application/json", produces="application/json")
	@ResponseBody public List<FMSSpotFireDataBean> getDataLakeSpotFireData(@RequestBody Map<String,String> postData) {
		log.info("getDataLakeSpotFireData() in FMSController");   
		return objService.getDataLakeSpotFireData(postData);
	}

	/*
	 * Data Lake SpotFire SubRegions
	 */
	@RequestMapping(method=RequestMethod.GET,value="getDataLakeSpotFireSubRegions")
	@ResponseBody public List<String> getDataLakeSpotFireSubRegions() {   
		return objService.getDataLakeSpotFireSubRegions();
	}

}
