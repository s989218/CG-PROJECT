package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSCommitmentDataBean;

public class CommitmentMapper implements RowMapper<FMSCommitmentDataBean> {

	public FMSCommitmentDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSCommitmentDataBean commitmentDTO = new FMSCommitmentDataBean();

		commitmentDTO.setCommitmentDate(rs.getString("COMMITMENTDATE"));
		commitmentDTO.setDateStamp(rs.getString("DATESTAMP"));
		commitmentDTO.setDownloadDate(rs.getString("DWLOADDATE"));
		commitmentDTO.setDownloadUpdateDate(rs.getString("DWUPDATEDATE"));
		commitmentDTO.setLineNumber(rs.getString("LINENUMBER"));
		commitmentDTO.setProjectManager(rs.getString("PROJECTMANAGER"));
		commitmentDTO.setProjectNumber(rs.getString("PROJECTNUMBER"));
		commitmentDTO.setRemarks(rs.getString("REMARKS"));
		commitmentDTO.setUserId(rs.getString("USERID"));
		commitmentDTO.setPrimaryId(rs.getString("PRIMAYID"));
		commitmentDTO.setSalesTqle(rs.getString("SALESTQLE"));
		commitmentDTO.setCmTqle(rs.getString("CMTQLE"));
	
		return commitmentDTO;
	}
}
 
        	