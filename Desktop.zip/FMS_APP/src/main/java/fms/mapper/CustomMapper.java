package fms.mapper;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;

public class CustomMapper implements RowMapper<Map<String, Object>>{

	@Override
	public Map<String, Object> mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		ResultSetMetaData meta = rs.getMetaData();
		Map<String, Object> result = new LinkedHashMap<String, Object>();
		for(int index=1; index<=meta.getColumnCount(); index++){
			result.put(meta.getColumnName(index), rs.getObject(index));
		}
		return result;
	}

}
