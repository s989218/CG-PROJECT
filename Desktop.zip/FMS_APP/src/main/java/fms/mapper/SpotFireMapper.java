package fms.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import fms.bean.FMSSpotFireDataBean;

public class SpotFireMapper implements RowMapper<FMSSpotFireDataBean> {

	public FMSSpotFireDataBean mapRow(ResultSet rs, int rowNum) throws SQLException {

		FMSSpotFireDataBean spotFireDTO = new FMSSpotFireDataBean();

		spotFireDTO.setActualCost(rs.getString("ACTUALCOST"));
		spotFireDTO.setActualShipmentDate(rs.getString("ACTUALSHIPMENTDATE"));
		spotFireDTO.setActualShipmentQuarter(rs.getString("ACTUALSHIPMENTQUARTER"));
		spotFireDTO.setAgreementIddelProgeto(rs.getString("AGREEMENTIDDELPROGETTO"));
		spotFireDTO.setAgreementName(rs.getString("AGREEMENTNAME"));
		spotFireDTO.setAmountReadyHP(rs.getString("AMOUNTREADYHP"));
		
		spotFireDTO.setAmountReadySP(rs.getString("AMOUNTREADYSP"));
		spotFireDTO.setAmountShipped(rs.getString("AMOUNTSHIPPED"));
		spotFireDTO.setAmtInShipping(rs.getString("AMTINSHIPPING"));
		spotFireDTO.setAmtNotReady(rs.getString("AMTNOTREADY"));
		spotFireDTO.setAreIncGlobops(rs.getString("AREINCGLOBOPS"));
		spotFireDTO.setAwb(rs.getString("AWB"));
		spotFireDTO.setBaseline(rs.getString("BASELINE"));
		spotFireDTO.setBasket(rs.getString("BASKET"));
		spotFireDTO.setBookingMonth(rs.getString("BOOKINGMONTH"));
		spotFireDTO.setBookingYear(rs.getString("BOOKINGYEAR"));
		
		spotFireDTO.setBoxNumber(rs.getString("BOXNUMBER"));
		spotFireDTO.setoUName(rs.getString("OU_NAME"));
		spotFireDTO.setBookingDate(rs.getString("BOOKINGDATE"));
		spotFireDTO.setBoxClosureDate(rs.getString("BOXCLOSUREDATE"));
		spotFireDTO.setBucCode(rs.getString("BUCCODE"));
		spotFireDTO.setBusinessSegment(rs.getString("BUSINESSSEGMENT"));
		spotFireDTO.setBuyerCustCode(rs.getString("BUYERCUSTCODE"));
		spotFireDTO.setBuyerCustCountryDesc(rs.getString("BUYERCUSTCOUNTRYDISC"));
		spotFireDTO.setBuyerCustName(rs.getString("BUYERCUSTNAME"));
		spotFireDTO.setCmGlobalContract(rs.getString("CMGLOBALCONTRACT"));
		
		spotFireDTO.setCmPerSold(rs.getString("CMPERSOLD"));
		spotFireDTO.setCmPercent(rs.getString("CMPERCENT"));
		spotFireDTO.setContrPerShippAllwd(rs.getString("CONTRPARSHIPALLWD"));
		spotFireDTO.setContractNumber(rs.getString("CONTRACTNUMBER"));
		spotFireDTO.setCostingProject(rs.getString("COSTINGPROJECT"));
		spotFireDTO.setCsAgreementType(rs.getString("CSAGREEMENTTYPE"));
		spotFireDTO.setCsRegion(rs.getString("CSREGION"));
		spotFireDTO.setCsSubRegion(rs.getString("CSSUBREGION"));
		spotFireDTO.setCustomerPOAmount(rs.getString("CUSTOMERPOAMOUNT"));
		spotFireDTO.setCustomerPONumber(rs.getString("CUSTOMERPONUMBER"));
		
		spotFireDTO.setCwdQuarter(rs.getString("CWDQUARTER"));
		spotFireDTO.setCwdWeek(rs.getString("CWDWEEK"));
		spotFireDTO.setCwdYear(rs.getString("CWDYEAR"));
		spotFireDTO.setDdtDate(rs.getString("DDTDATE"));
		spotFireDTO.setDdtNumber(rs.getString("DDTNUMBER"));
		spotFireDTO.setDeliverableNum(rs.getString("DELIVERABLENUM"));
		spotFireDTO.setDeliveryTerm(rs.getString("DELIVERYTERM"));
		spotFireDTO.setDeliveryStatus(rs.getString("DELVIERABLESTATUS"));
		spotFireDTO.setDescreZoneClasse(rs.getString("DESCRIZIONECLASSE"));
		spotFireDTO.setDiscoutExtraPrice(rs.getString("DISCOUNTEXTRAPRICE"));
		
		spotFireDTO.setDolDiscountPrice(rs.getString("DOLDISCOUNTPRICE"));
		spotFireDTO.setDollarPrice(rs.getString("DOLLARPRICE"));
		spotFireDTO.setDpsRegion(rs.getString("DPSREGION"));
		spotFireDTO.setDpsSubRegion(rs.getString("DPSSUBREGION"));
		spotFireDTO.setDwLoadDate(rs.getString("DWLOADDATE"));
		spotFireDTO.setDwUpdateDate(rs.getString("DWUPDATEDATE"));
		spotFireDTO.setEarlyDeliveryAllowed(rs.getString("EARLYDELIVERYALLOWED"));
		spotFireDTO.setEndUserCountryDesc(rs.getString("ENDUSERCOUNTRYDISC"));
		spotFireDTO.setEndUserCountryCode(rs.getString("ENDUSERCUSTCODE"));
		spotFireDTO.setEndUserCustName(rs.getString("ENDUSERCUSTNAME"));
		
		spotFireDTO.setFxRate(rs.getString("FXRATE"));
		spotFireDTO.setG3Promised(rs.getString("G3PROMISED"));
		spotFireDTO.setGratisSI(rs.getString("GRATISSI"));
		spotFireDTO.setGrossWeight(rs.getString("GROSSWEIGHT"));
		spotFireDTO.setHeight(rs.getString("HEIGHT"));
		spotFireDTO.setiC(rs.getString("IC"));
		spotFireDTO.setIbasEventId(rs.getString("IBASEVENTID"));
		spotFireDTO.setInvoiceAmount(rs.getString("INVOICEAMOUNT"));
		spotFireDTO.setInvoiceDate(rs.getString("INVOICEDATE"));
		spotFireDTO.setInvoiceNumber(rs.getString("INVOICENUMBER"));
		
		spotFireDTO.setInvoiceStatus(rs.getString("INVOICESTATUS"));
		spotFireDTO.setInvoiceStatusChangeDt(rs.getString("INVOICESTATUSCHANGEDATE"));
		spotFireDTO.setItemCode(rs.getString("ITEMCODE"));
		spotFireDTO.setItemDescription(rs.getString("ITEMDESCRIPTION"));
		spotFireDTO.setLegalEntityCode(rs.getString("LEGALENTITYCODE"));
		spotFireDTO.setLegalEntityName(rs.getString("LEGALENTITYNAME"));
		spotFireDTO.setLength(rs.getString("LENGTH"));
		spotFireDTO.setLineBilledAmt(rs.getString("LINEBILLEDAMT"));
		spotFireDTO.setLineId(rs.getString("LINEID"));
		spotFireDTO.setLineStatus(rs.getString("LINESTATUS"));
		
		spotFireDTO.setLineTrueCost(rs.getString("LINETRUECOST"));
		spotFireDTO.setMarket(rs.getString("MARKET"));
		spotFireDTO.setMngmtEntity(rs.getString("MGMTENTITY"));
		spotFireDTO.setMngmtEntityDesc(rs.getString("MGMTENTITYDESC"));
		spotFireDTO.setMotherJob(rs.getString("MOTHERJOB"));
		spotFireDTO.setMoveOrder(rs.getString("MOVEORDER"));
		spotFireDTO.setMsRegion(rs.getString("MSREGION"));
		spotFireDTO.setMultipleBox(rs.getString("MULTIPLEBOX"));
		spotFireDTO.setNetAmount(rs.getString("NETAMOUNT"));
		spotFireDTO.setNetWeight(rs.getString("NETWEIGHT"));
		
		spotFireDTO.setOrderType(rs.getString("ORDERTYPE"));
		spotFireDTO.setOrderedDate(rs.getString("ORDEREDDATE"));
		spotFireDTO.setOrderedQuantity(rs.getString("ORDEREDQUANTITY"));
		spotFireDTO.setOtm(rs.getString("OTM"));
		spotFireDTO.setpAndL(rs.getString("PANDL"));
		spotFireDTO.setPenalty(rs.getString("PENALTY"));
		spotFireDTO.setPoCurrency(rs.getString("POCURRENCY"));
		spotFireDTO.setPoIRLineNumber(rs.getString("POIRLINENUMBER"));
		spotFireDTO.setPoNumber(rs.getString("PONUMBER"));
		spotFireDTO.setPoPromiseDate(rs.getString("POPROMISEDATE"));
		
		spotFireDTO.setProduct(rs.getString("PRODUCT"));
		spotFireDTO.setProductLine(rs.getString("PRODUCTLINE"));
		spotFireDTO.setProjectManager(rs.getString("PROJECTMANAGER"));
		spotFireDTO.setProjectType(rs.getString("PROJECTTYPE"));
		spotFireDTO.setPromiseDate(rs.getString("PROMISEDATE"));
		spotFireDTO.setRescheduleMonth(rs.getString("RESCHEDULEMONTH"));
		spotFireDTO.setRescheduleQuarter(rs.getString("RESCHEDULEQUARTER"));
		spotFireDTO.setRescheduleYear(rs.getString("RESCHEDULEYEAR"));
		spotFireDTO.setResidualPortSales(rs.getString("RESIDUALPORTFOLIOSALES"));
		spotFireDTO.setSalesForecastingDate(rs.getString("SALESFORECASTINGDATE"));

		spotFireDTO.setSalesForecastingMnth(rs.getString("SALESFORECASTINGMONTH"));
		spotFireDTO.setSalesForecastingQuarter(rs.getString("SALESFORECASTINGQUARTER"));
		spotFireDTO.setSalesForecastingYear(rs.getString("SALESFORECASTINGYEAR"));
		spotFireDTO.setScheduleShipDate(rs.getString("SCHEDULESHIPDATE"));
		spotFireDTO.setSoCreationDate(rs.getString("SOCREATIONDATE"));
		spotFireDTO.setSoCwd(rs.getString("SOCWD"));
		spotFireDTO.setSoLine(rs.getString("SOLINE"));
		spotFireDTO.setSoStatus(rs.getString("SOSTATUS"));
		spotFireDTO.setSupplierId(rs.getString("SUPPLIERID"));
		spotFireDTO.setSupplierName(rs.getString("SUPPLIERNAME"));
		
		spotFireDTO.setSupplyNumber(rs.getString("SUPPLYNUMBER"));
		spotFireDTO.setSupplyType(rs.getString("SUPPLYTYPE"));
		spotFireDTO.setTpRate(rs.getString("TPRATE"));
		spotFireDTO.setTransferPrice(rs.getString("TRANSFERPRICE"));
		spotFireDTO.setTtDate(rs.getString("TTDATE"));
		spotFireDTO.setUnitCost(rs.getString("UNITCOST"));
		spotFireDTO.setUnitSellingPrice(rs.getString("UNITSELLINGPRICE"));
		spotFireDTO.setUnitTrueCost(rs.getString("UNITTRUECOST"));
		spotFireDTO.setUserItemDescription(rs.getString("USERITEMDESCRIPTION"));
		spotFireDTO.setVatAmount(rs.getString("VATAMOUNT"));
		
		spotFireDTO.setWidth(rs.getString("WIDTH"));
		spotFireDTO.setProgress(rs.getString("PROGRESS"));
		spotFireDTO.setSite(rs.getString("SITE"));
		spotFireDTO.setEuroDiscountPrice(rs.getString("EURODISCOUNTPRICE"));
		spotFireDTO.setEuroPrice(rs.getString("EUROPRICE"));
		spotFireDTO.setInvoiceWeek(rs.getString("INVOICEWEEK"));
		spotFireDTO.setInvoiceYear(rs.getString("INVOICEYEAR"));
		spotFireDTO.setMaxShippingDate(rs.getString("MAXSHIPPINGDATE"));
		spotFireDTO.setOldBoxCategory(rs.getString("OLDBOXCATEGORY"));
		spotFireDTO.setOldBoxDays(rs.getString("OLDBOXDAYS"));
		
		spotFireDTO.setPartsStatus(rs.getString("PARTSSTATUS"));
		spotFireDTO.setPromiseDateMonth(rs.getString("PROMISEDATEMONTH"));
		spotFireDTO.setPromiseDateYear(rs.getString("PROMISEDATEYEAR"));
		spotFireDTO.setTotalProInvoice(rs.getString("TOTALPROINVOICE"));
		spotFireDTO.setFxRateEur(rs.getString("FXRATEEUR"));
		spotFireDTO.setPrimaryKey(rs.getString("PRIMARYKEY"));
		spotFireDTO.setSalesType(rs.getString("SALESTYPE"));
		spotFireDTO.setLineType(rs.getString("LINETYPE"));
		spotFireDTO.setRtsDate(rs.getString("RTSDATE"));
		spotFireDTO.setTpPercentage(rs.getString("TPPERCENTAGE"));
		
		spotFireDTO.setPoReleaseDate(rs.getString("PORELEASEDATE"));
		spotFireDTO.setPorReleaseDate(rs.getString("PORRELEASEDATE"));
		spotFireDTO.setRegion(rs.getString("Region"));
		spotFireDTO.setCustPOLineNum(rs.getString("CUSTOMERPOLINE"));
		spotFireDTO.setTtTime(rs.getString("TTTIME"));
		spotFireDTO.setLeadTime(rs.getString("LEADTIME"));
		spotFireDTO.setLoadingProgress(rs.getString("LOADINGPROGRESS"));
		spotFireDTO.setSubRegion(rs.getString("SUBREGION"));
		spotFireDTO.setShipSetName(rs.getString("SHIPSETNAME"));
		spotFireDTO.setSalesDateBkp(rs.getString("SALESDATEPREVIOUS"));
		
		spotFireDTO.setOgRegion(rs.getString("OGREGION"));
		spotFireDTO.setMachineSN(rs.getString("MACHINESN"));
		spotFireDTO.setTaskNumber(rs.getString("TASKNUMBER"));
		spotFireDTO.setAdvFlag(rs.getString("ADVFLAG"));
		spotFireDTO.setDiscountAmount(rs.getString("DISCOUNTAMOUNT"));
		spotFireDTO.setReversalAmount(rs.getString("REVERSALAMOUNT"));
		spotFireDTO.setManager(rs.getString("MANAGER"));
		spotFireDTO.setStorage(rs.getString("STORAGE"));
		
		spotFireDTO.setCommitmentDate(rs.getString("C_COMMITMENTDATE"));
		spotFireDTO.setDateStamp(rs.getString("C_DATESTAMP"));
		spotFireDTO.setDwLoadDate(rs.getString("C_DWLOADDATE"));
		spotFireDTO.setDwUpdateDate(rs.getString("C_DWUPDATEDATE"));
		spotFireDTO.setLineNumber(rs.getString("C_LINENUMBER"));
		spotFireDTO.setProjectManagerCommitment(rs.getString("C_PROJECTMANAGER"));
		spotFireDTO.setProjectNumber(rs.getString("C_PROJECTNUMBER"));
		spotFireDTO.setRemarks(rs.getString("C_REMARKS"));
		spotFireDTO.setUserId(rs.getString("C_USERID"));
		spotFireDTO.setPrimaryId(rs.getString("C_PRIMARYID"));
		spotFireDTO.setSalesTqle(rs.getString("C_SALESTQLE"));
		spotFireDTO.setCmTqle(rs.getString("C_CMTQLE"));
		
		return spotFireDTO;
	}
}
 
        	