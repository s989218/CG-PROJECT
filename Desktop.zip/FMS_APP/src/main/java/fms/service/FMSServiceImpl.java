package fms.service;


import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fms.bean.FMSCommitmentDataBean;
import fms.bean.FMSSpotFireDataBean;
import fms.dao.IFMSDao;

@Service
public class FMSServiceImpl implements IFMSService{

	private static final Logger log = Logger.getLogger(FMSServiceImpl.class);
	@Autowired
	private IFMSDao objDAO;

	@Override
	public List<FMSSpotFireDataBean> getSpotFireData(Map<String,String> postData) {
		log.info("getSpotFireData() in FMSServiceImpl");
		return objDAO.getSpotFireData(postData);
	}

	@Override
	public List<FMSCommitmentDataBean> getCommitmentData() {
		log.info("getCommitmentData() in FMSServiceImpl");
		return objDAO.getCommitmentData();
	}

	@Override
	public List<Map<String, Object>> getOBPData() {
		log.info("getOBPData() in FMSServiceImpl");
		return objDAO.getOBPData();
	}

	@Override
	public List<Map<String, Object>> getIBASData(Map<String,String> postData) {
		log.info("getIBASData() in FMSServiceImpl");
		return objDAO.getIBASData(postData);
	}

	@Override
	public List<String> getSpotFireSubRegions() {
		log.info("getSpotFireSubRegions() in FMSServiceImpl");
		return objDAO.getSpotFireSubRegions();
	}	

	@Override
	public List<Map<String, Object>> getDMData(Map<String,String> postData) {
		log.info("getDMData() in FMSServiceImpl");
		return objDAO.getDMData(postData);
	}

	@Override
	public List<String> getDMPrimaryRegion() {
		log.info("getDMPrimaryRegion() in FMSServiceImpl");
		return objDAO.getDMPrimaryRegion();
	}

	@Override
	public List<Map<String, Object>> getOutageData(Map<String,String> postData) {
		log.info("getOutageData() in FMSServiceImpl");
		return objDAO.getOutageData(postData);
	}

	@Override
	public List<Map<String, Object>> getServiceRequestdata(Map<String,String> postData){
		log.info("getServiceRequestdata() in FMSServiceImpl");
		return objDAO.getServiceRequestdata(postData);
	}

	@Override
	public List<String> getIBASRegions(String data) {
		log.info("getIBASRegions() in FMSServiceImpl");
		return objDAO.getIBASRegions(data);
	}

	@Override
	public List<String> getOutageDemItemStatus() {
		log.info("getOutageDemItemStatus() in FMSServiceImpl");
		return objDAO.getOutageDemItemStatus();
	}

	@Override
	public List<String> getServiceRequestMacTech() {
		log.info("getServiceRequestMacTech() in FMSServiceImpl");
		return objDAO.getServiceRequestMacTech();
	}

	@Override
	public List<FMSSpotFireDataBean> getDataLakeSpotFireData(Map<String,String> postData) {
		return objDAO.getDataLakeSpotFireData(postData);
	}

	@Override
	public List<String> getDataLakeSpotFireSubRegions() {
		log.info("getSpotFireSubRegions() in FMSServiceImpl");
		return objDAO.getDataLakeSpotFireSubRegions();
	}
}
