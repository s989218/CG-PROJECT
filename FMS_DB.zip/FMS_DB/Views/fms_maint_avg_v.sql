-- View: fms_maint_avg_v

-- DROP VIEW fms_maint_avg_v;

CREATE OR REPLACE VIEW fms_maint_avg_v AS 
 SELECT fms_maintenance.policy,
    round(sum(COALESCE(fms_maintenance.parts, 0::numeric)) / 6::numeric, 2) AS avg_parts,
    round(sum(COALESCE(fms_maintenance.repairs, 0::numeric)) / 6::numeric, 2) AS avg_repairs,
    round(sum(COALESCE(fms_maintenance.services, 0::numeric)) / 6::numeric, 2) AS avg_services,
    round(sum(COALESCE(fms_maintenance.manpower, 0::numeric)) / 6::numeric, 2) AS avg_manpower,
    round(sum(COALESCE(fms_maintenance.aux, 0::numeric)) / 6::numeric, 2) AS avg_aux,
    round(sum(COALESCE(fms_maintenance.total, 0::numeric)) / 6::numeric, 2) AS avg_total,
    'NONAVG'::text AS type
   FROM fms_maintenance
  WHERE fms_maintenance.level::text <> 'Average'::text AND fms_maintenance.age <= 6::numeric
  GROUP BY fms_maintenance.policy
UNION
 SELECT fms_maintenance.policy,
    round(COALESCE(fms_maintenance.parts, 0::numeric), 2) AS avg_parts,
    round(COALESCE(fms_maintenance.repairs, 0::numeric), 2) AS avg_repairs,
    round(COALESCE(fms_maintenance.services, 0::numeric), 2) AS avg_services,
    round(COALESCE(fms_maintenance.manpower, 0::numeric), 2) AS avg_manpower,
    round(COALESCE(fms_maintenance.aux, 0::numeric), 2) AS avg_aux,
    round(COALESCE(fms_maintenance.total, 0::numeric), 2) AS avg_total,
    'AVG'::text AS type
   FROM fms_maintenance
  WHERE fms_maintenance.level::text = 'Average'::text AND fms_maintenance.age = 6::numeric;

