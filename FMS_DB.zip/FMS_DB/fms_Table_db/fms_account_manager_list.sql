CREATE TABLE fms_account_manager_list
(
  c_site_customer_name character varying,
  c_account_mgr_last character varying,
  c_account_mgr_first character varying,
  c_account_mgr_email character varying
)