CREATE TABLE fms_choose_columns_config
(
  fms_table_id integer NOT NULL,
  table_name character varying,
  column_name character varying,
  display_name character varying,
  active_status character varying(1),
  display_order integer,
  default_checked integer,
  CONSTRAINT myprimarykey PRIMARY KEY (fms_table_id)
);