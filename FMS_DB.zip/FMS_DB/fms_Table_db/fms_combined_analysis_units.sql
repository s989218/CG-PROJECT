CREATE TABLE fms_combined_analysis_units
(
  metrics character varying NOT NULL,
  unit character varying,
  CONSTRAINT fms_combined_analysis_units_pkey PRIMARY KEY (metrics)
)