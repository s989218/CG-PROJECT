-- Table: fms_db_log

-- DROP TABLE fms_db_log;

CREATE TABLE fms_db_log
(
  fms_db_log_id numeric NOT NULL DEFAULT nextval('seq_fms_db_log_id'::regclass),
  proc_name character varying(250),
  proc_paras character varying(4000),
  proc_postgre_err character varying(5000),
  proc_err_msg character varying(2500),
  proc_log_date timestamp without time zone DEFAULT now(),
  CONSTRAINT fms_db_log_pkey PRIMARY KEY (fms_db_log_id)
)
