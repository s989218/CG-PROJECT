CREATE TABLE fms_documents
(
  id bigserial NOT NULL,
  description character varying(255),
  filename character varying(255),
  content bytea,
  uploaded_by character varying(50),
  file_delete_access character varying(5),
  created timestamp without time zone DEFAULT now(),
  modified timestamp without time zone DEFAULT now(),
  CONSTRAINT documents_pkey PRIMARY KEY (id)
)