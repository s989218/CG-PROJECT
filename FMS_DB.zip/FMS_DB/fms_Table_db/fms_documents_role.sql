CREATE TABLE fms_documents_role
(
  doc_id numeric NOT NULL,
  role_id numeric NOT NULL,
  created timestamp without time zone DEFAULT now(),
  modified timestamp without time zone DEFAULT now()
)