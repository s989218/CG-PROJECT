CREATE TABLE fms_enhance_dm_color
(
  oppty_type character varying,
  color_code character varying
);