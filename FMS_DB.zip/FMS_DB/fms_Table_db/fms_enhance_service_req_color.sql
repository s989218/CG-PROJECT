CREATE TABLE fms_enhance_service_req_color
(
  state character varying,
  color_code character varying
)