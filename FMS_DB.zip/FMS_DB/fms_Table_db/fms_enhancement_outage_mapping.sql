CREATE TABLE fms_enhancement_outage_mapping
(
  n_maint_level_id numeric,
  maint_level_cod character varying,
  maint_level_desc character varying
)