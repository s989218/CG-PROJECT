-- Table: fms_ge_cust_mapping

-- DROP TABLE fms_ge_cust_mapping;

CREATE TABLE fms_ge_cust_mapping
(
  gib_serial_number character varying NOT NULL,
  oem_serial_number character varying,
  ge_global_duns character varying,
  ge_duns_name character varying,
  CONSTRAINT fms_ge_cust_mapping_pkey PRIMARY KEY (gib_serial_number)
)
