CREATE TABLE fms_ibo_metrics_column_headers (
    row_id integer NOT NULL,
    identifier character varying,
    field_name character varying,
    display_name character varying,
    active character varying(1)
);


CREATE SEQUENCE fms_ibo_metrics_column_headers_row_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
