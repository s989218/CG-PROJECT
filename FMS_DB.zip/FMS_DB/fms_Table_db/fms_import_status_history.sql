-- Table: fms_import_status_history

-- DROP TABLE fms_import_status_history;

CREATE TABLE fms_import_status_history
(
  id bigserial NOT NULL,
  sso_id character varying,
  task_name character varying,
  file_name character varying,
  created_date timestamp without time zone DEFAULT now(),
  status character varying,
  invalid_record_count numeric,
  CONSTRAINT fms_import_status_history_pkey PRIMARY KEY (id)
)
