-- Table: fms_ipm_dd_p_exp_fw_revrec_firts_pl

-- DROP TABLE fms_ipm_dd_p_exp_fw_revrec_firts_pl;

CREATE TABLE fms_ipm_dd_p_exp_fw_revrec_firts_pl
(
  exp_fw_revrec_firts_pl_id numeric,
  exp_fw_revrec_firts_pl character varying(250)
)