-- Table: fms_ipm_dd_p_r_by_o

-- DROP TABLE fms_ipm_dd_p_r_by_o;

CREATE TABLE fms_ipm_dd_p_r_by_o
(
  r_by_o_id numeric,
  r_by_o_data character varying(250)
)