-- Table: fms_ipm_dd_p_wb_comment

-- DROP TABLE fms_ipm_dd_p_wb_comment;

CREATE TABLE fms_ipm_dd_p_wb_comment
(
  wb_comment_id numeric,
  wb_comment_data character varying(250)
)