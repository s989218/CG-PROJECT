CREATE SEQUENCE seq_fms_ipm_field_type_id
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;

-- Table: fms_ipm_field_type

-- DROP TABLE fms_ipm_field_type;

CREATE TABLE fms_ipm_field_type
(
  field_type_id numeric NOT NULL DEFAULT nextval('seq_fms_ipm_field_type_id'::regclass),
  field_name character varying(250),
  title character varying(250),
  field_type character varying(250),
  editable character varying(1), -- Y : Editable...
  identifier character varying(250)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE fms_ipm_field_type
  OWNER TO postgres;
COMMENT ON COLUMN fms_ipm_field_type.editable IS 'Y : Editable
D: Default
N : Non Editable';

