CREATE TABLE fms_ipm_fw_history
(
  cm_total character varying,
  region character varying,
  concatenate character varying,
  p_and_l character varying,
  product character varying,
  end_user_cust_name character varying,
  cm_dol_by_1000 character varying,
  status character varying,
  wb_comment character varying,
  note character varying,
  due_date character varying,
  trend character varying,
  r_by_o character varying,
  week character varying,
  identifier character varying,
  business_unit character varying
)