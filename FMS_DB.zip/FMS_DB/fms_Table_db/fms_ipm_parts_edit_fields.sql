-- Table: fms_ipm_parts_edit_fields

-- DROP TABLE fms_ipm_parts_edit_fields;

CREATE TABLE fms_ipm_parts_edit_fields
(
  p_concatenate character varying(250) NOT NULL,
  p_note character varying(250),
  p_wb_comment character varying(250),
  p_r_by_o character varying(250),
  p_exp_fw_revrec_firts_pl character varying(250),
  p_exp_fw_revrec character varying(250),
  p_sum_sales numeric,
  p_sum_cm numeric,
  p_cm_dollar_by_1000 numeric,
  p_due_date character varying(250),
  p_status character varying(250),
  p_keydeals character varying(255),
  p_financial_basket character varying(250),
  p_operational_basket character varying(250),
  p_trend character varying(150),
  p_flow_or_no_flow character varying,
  p_status_aging character varying(250),
  p_new_date date,
  p_forecast_status character(1),
  p_qmi boolean DEFAULT false
);



