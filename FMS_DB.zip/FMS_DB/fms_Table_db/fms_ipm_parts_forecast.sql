-- Table: fms_ipm_parts_forecast

-- DROP TABLE fms_ipm_parts_forecast;

CREATE TABLE fms_ipm_parts_forecast
(
  quarter character varying(2) NOT NULL,
  year numeric,
  forecast numeric,
  parts_status character varying(100),
  new_p_and_l character varying(10),
  create_date timestamp without time zone DEFAULT now(),
  week character varying,
  quarter_status character varying,
  added numeric,
  removed numeric,
  new_forecast numeric,
  qtr_first_day_data boolean
)