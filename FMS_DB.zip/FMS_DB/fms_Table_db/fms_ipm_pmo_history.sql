-- Table: fms_ipm_pmo_history

-- DROP TABLE fms_ipm_pmo_history;

CREATE TABLE fms_ipm_pmo_history
(
  type character varying,
  sum_cm numeric,
  sales_year_qtr character varying,
  week character varying,
  business_unit character varying,
  sequence character varying,
  caption character varying,
  week_dt numeric
)