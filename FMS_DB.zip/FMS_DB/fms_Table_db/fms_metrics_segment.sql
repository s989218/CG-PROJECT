-- Table: fms_metrics_segment

-- DROP TABLE fms_metrics_segment;

CREATE TABLE fms_metrics_segment
(
  region_id numeric,
  country character varying,
  segment character varying,
  year numeric,
  quarter character varying(4),
  fleet_coverage numeric(20,2),
  fleet_penetration numeric(20,2),
  fleet_pen_f2f numeric(20,2),
  caloric_index numeric(20,2),
  last_created timestamp without time zone DEFAULT now(),
  last_updated timestamp without time zone DEFAULT now(),
  business_segment character varying,
  c_market_industry_desc character varying
)
