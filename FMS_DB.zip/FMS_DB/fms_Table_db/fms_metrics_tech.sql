-- Table: fms_metrics_tech

-- DROP TABLE fms_metrics_tech;

CREATE TABLE fms_metrics_tech
(
  fms_metrics_tech_id numeric NOT NULL DEFAULT nextval('seq_fms_metrics_tech_id'::regclass),
  tech_id numeric,
  year numeric,
  quarter character varying(4),
  ib_by_tech numeric(10,0),
  ibo_by_tech numeric(10,2),
  last_created timestamp without time zone DEFAULT now(),
  last_updated timestamp without time zone DEFAULT now(),
  business_segment character varying,
  c_market_industry_desc character varying
)