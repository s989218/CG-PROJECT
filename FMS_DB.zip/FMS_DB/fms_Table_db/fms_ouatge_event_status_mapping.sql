CREATE TABLE fms_ouatge_event_status_mapping
(
  n_event_status_id numeric,
  c_event_status_desc character varying
)