-- Table: fms_region

-- DROP TABLE fms_region;

CREATE TABLE fms_region
(
  region_id numeric NOT NULL DEFAULT nextval('seq_fms_region_id'::regclass),
  region character varying NOT NULL,
  CONSTRAINT fms_region_id_pkey PRIMARY KEY (region_id)
)
