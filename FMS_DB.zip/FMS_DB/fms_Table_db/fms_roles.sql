-- Table: fms_roles

-- DROP TABLE fms_roles;

CREATE TABLE fms_roles (
    role_id numeric NOT NULL,
    role_name character varying NOT NULL,
    role_name_desc character varying,
    active character varying(1),
    created_by character varying,
    creation_date date DEFAULT now(),
    updated_by character varying,
    last_update_date date,
    is_visible character varying(1)
);