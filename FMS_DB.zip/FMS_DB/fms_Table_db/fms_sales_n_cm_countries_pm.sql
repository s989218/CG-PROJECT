-- Table: fms_sales_n_cm_countries_pm

-- DROP TABLE fms_sales_n_cm_countries_pm;

CREATE TABLE fms_sales_n_cm_countries_pm
(
  ong_region_countries character varying(250),
  sales_amt_at_op_rate numeric(15,2),
  cm_amt_at_op_rate numeric(15,2),
  identifier character varying,
  region character varying,
  region_id numeric,
  year numeric(4,0),
  quarter character varying(2),
  create_date timestamp without time zone DEFAULT now(),
  business_segment character varying,
  c_market_industry_desc character varying
)