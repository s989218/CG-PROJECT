-- Table: fms_service_logs

-- DROP TABLE fms_service_logs;

CREATE TABLE fms_service_logs
(
  log_id bigserial NOT NULL,
  log_service_name character varying(500),
  log_desc character varying(5000),
  date_occured timestamp without time zone DEFAULT now(),
  status character varying(2000),
  CONSTRAINT fms_service_logs_pkey PRIMARY KEY (log_id)
)
