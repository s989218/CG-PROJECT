CREATE TABLE fms_service_orders_me_mapping
(
  me_mgmt_entity_code character varying(250) NOT NULL,
  me_mapping_incl_sc_corrections character varying(250),
  me_p_and_l character varying(250),
  me_svc_or_eq character varying(250),
  me_tier_3 character varying(250),
  me_dm_tier_3 character varying(250),
  me_tier_4 character varying(250),
  me_usage character varying(250),
  CONSTRAINT fms_me_mapping_pkey PRIMARY KEY (me_mgmt_entity_code)
);