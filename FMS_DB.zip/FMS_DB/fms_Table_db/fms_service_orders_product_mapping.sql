CREATE TABLE fms_service_orders_product_mapping
(
  pm_product_type_desc character varying(250) NOT NULL,
  pm_product_mapping character varying(250),
  CONSTRAINT fms_enhance_product_pkey PRIMARY KEY (pm_product_type_desc)
);