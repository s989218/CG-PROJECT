-- Table: fms_service_orders_segment_mapping

-- DROP TABLE fms_service_orders_segment_mapping;

CREATE TABLE fms_service_orders_segment_mapping
(
  sm_src_new_og_pl character varying(250) NOT NULL,
  sm_segment_mapping character varying(250),
  c_market_industry_desc character varying
)