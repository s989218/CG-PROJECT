CREATE TABLE fms_tech
(
  tech_id numeric NOT NULL DEFAULT nextval('seq_fms_tech_id'::regclass),
  tech_desc character varying NOT NULL,
  color_code character varying(100),
  CONSTRAINT fms_tech_id_pkey PRIMARY KEY (tech_id)
);