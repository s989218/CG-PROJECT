-- Table: fms_user

-- DROP TABLE fms_user;

CREATE TABLE fms_user
(
  user_id character varying NOT NULL,
  first_name character varying,
  last_name character varying,
  email_id character varying,
  active character varying(1),
  created_by character varying,
  created_date date DEFAULT now(),
  updated_by character varying,
  updated_date date
)