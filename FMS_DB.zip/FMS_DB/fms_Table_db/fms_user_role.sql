-- Table: fms_user_role

-- DROP TABLE fms_user_role;

CREATE TABLE fms_user_role (
    fms_uid numeric NOT NULL,
    user_id character varying NOT NULL,
    role_id numeric NOT NULL,
    active character varying(1),
    default_role character varying,
    created_by character varying,
    creation_date date DEFAULT now(),
    updated_by character varying,
    update_date date
);