-- Function: fms_add_new_user(character varying, character varying, character varying, character varying, character varying, character varying, character varying, numeric)

-- DROP FUNCTION fms_add_new_user(character varying, character varying, character varying, character varying, character varying, character varying, character varying, numeric);

CREATE OR REPLACE FUNCTION fms_add_new_user(
    sso character varying,
    firstname character varying,
    lastname character varying,
    email character varying,
    active character varying,
    createdby character varying,
    updatedby character varying,
    role numeric)
  RETURNS character varying AS
$BODY$ 
DECLARE

BEGIN

INSERT INTO fms_user( user_id, first_name, last_name, email_id, active, created_by, created_date, updated_by, updated_date) VALUES (sso, firstName, lastName, email, active, createdBy, now()::timestamp , updatedBy, now()::timestamp);

INSERT INTO fms_user_role( fms_uid, user_id, role_id, active, default_role, created_by, creation_date, updated_by, update_date) VALUES ((select max(fms_uid)::numeric+1 from fms_user_role), sso, role, 'Y',1, createdBy, now()::timestamp , updatedBy, now()::timestamp);

return 'SUCCESS';

EXCEPTION WHEN OTHERS THEN 
  
PERFORM fms_db_logger('fms_add_new_user',sso ||'~'||firstName ||'~'||lastName ||'~'||email ||'~'||active ||'~'||createdBy ||'~'||updatedBy ||'~'||role,sqlerrm,'DATABASE ERROR');
return 'DATABASE ERROR';


END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
