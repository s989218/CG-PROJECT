-- Function: fms_calc_all_metrics(numeric, character varying)

-- DROP FUNCTION fms_calc_all_metrics(numeric, character varying);

CREATE OR REPLACE FUNCTION fms_calc_all_metrics(
    in_year numeric,
    in_quarter character varying)
  RETURNS character AS
$BODY$
DECLARE

	metrics_query1 character (250) ;
	metrics_query2 character (250) ;
	metrics_query3 character (250) ;
	metrics_query4 character (250) ;
	metrics_query5 character (250) ;
	metrics_query6 character (250) ;
	metrics_query7 character (250) ;
	metrics_query8 character (250) ;
	metrics_query9 character (250) ;
	metrics_query10 character (250) ;
	metrics_query11 character (250) ;

	return_statement character (2500);
	return_check character (2500);

	query_return character varying(20);
	fms_metrics_records type_fms_metrics[];
	fms_metrics_tech_records type_fms_metrics[];
	
	v_av_value character varying;
	v_srvc_typ_desc character varying;
	v_report character varying;
	v_query character varying;
	
	v_total_id numeric;
	v_b_unit character varying;
	industry_desc character varying;
	v_proc_paras  character (2500); 
	
BEGIN


v_proc_paras =  to_char(in_year, '0000') || ' ; ' || 
		in_quarter;

--RAISE NOTICE 'proc Char % ', v_proc_paras;

/*

--fms_metrics_reion

select fms_calc_rev_dollar_by_region(in_year, in_quarter) into metrics_query1;
select fms_calc_caloric_index(in_year, in_quarter) into metrics_query2;
select fms_calc_dollar_by_ib(in_year, in_quarter)into metrics_query3;
select fms_calc_fleet_coverage(in_year, in_quarter) into metrics_query4;
select fms_calc_fleet_pen_f2f(in_year, in_quarter) into metrics_query5;
select fms_calc_fleet_penetration(in_year, in_quarter) into metrics_query6;
select fms_calc_ibo_by_region(in_year, in_quarter) into metrics_query7;
select fms_calc_conversion_index(in_year, in_quarter) into metrics_query8;
select fms_calc_ib_by_region(in_year, in_quarter) into metrics_query9;

--fms_metrics_tech

select fms_calc_ib_by_tech(in_year, in_quarter) into metrics_query10;
select fms_calc_ibo_by_tech(in_year, in_quarter) into metrics_query11;


return_statement =  metrics_query1 || ' ' || metrics_query2 || ' ' || metrics_query3 || ' ' || metrics_query4 || ' ' || metrics_query5 || ' ' || metrics_query6
 || ' ' || metrics_query7 || ' ' || metrics_query8 || ' ' || metrics_query9 || ' ' || metrics_query10 || ' ' || metrics_query11;

--RAISE NOTICE 'return_statement %',return_statement;

select substring(return_statement from '%#"DATABASE ERROR#"%' for '#') into return_check ;
RAISE NOTICE 'return_check %', return_check;

IF return_check IS NULL THEN
	RETURN 'SUCCESS';
ELSE
	RETURN 'DATABASE ERROR';
END IF;

*/

----------------------------------------------------------------REGION

--REV DOLLAR BY REGION

v_b_unit = '';

--v_b_unit = 'TMS';

  --FOR a IN 1..2 LOOP

SELECT region_id INTO v_total_id FROM fms_region WHERE 	UPPER(region) = 'TOTAL';

SELECT array_agg(s) INTO fms_metrics_records FROM
(
    (	
	select region_id, year, quarter, (sales_amt_at_op_rate/1000) as sum_sales_amt
	, v_b_unit ,c_market_industry_desc
		from fms_sales_n_cm_countries_pm 
		where year = in_year and UPPER(quarter) = UPPER(in_quarter)
		AND UPPER(trim(identifier)) = 'REGION'
		and upper(trim(region)) in (select upper(region) from fms_region)
		--AND UPPER(business_segment) = v_b_unit	
		GROUP BY region_id, year, quarter, (sales_amt_at_op_rate/1000), c_market_industry_desc
		order by region_id 
    )
    UNION
   (
	select v_total_id as region_id, year, quarter, (SUM(COALESCE(sales_amt_at_op_rate, 0)))/1000  as sum_sales_amt
	, v_b_unit, c_market_industry_desc
		from fms_sales_n_cm_countries_pm 
		where year = in_year and UPPER(quarter) = UPPER(in_quarter)
		AND UPPER(trim(identifier)) = 'REGION'
		and upper(trim(region)) in (select upper(region) from fms_region)
		--AND UPPER(business_segment) = v_b_unit		
		group by quarter, year, c_market_industry_desc
		order by region_id 
   )    		
) as s ;

SELECT fms_insert_metrics_data ('rev_dollar_by_region', fms_metrics_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_all_metrics',   v_proc_paras ,    COALESCE(v_b_unit,'')||' : '||'rev_dollar_by_region', query_return);

--CALORIC INDEX

SELECT array_agg(s) INTO fms_metrics_records FROM
	(
		(
		   select IBO_by_Region.region_id, IBO_by_Region.year, IBO_by_Region.quarter, (Round(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) as Caloric_Index
		   , v_b_unit , IBO_by_Region.c_market_industry_desc
			from 
			(
					(select count(c_gib_serial_number) as count_gis, region_id, year, quarter,c_market_industry_desc from fms_ibas_equipment 
						where year = in_year and UPPER(quarter) = UPPER(in_quarter) and UPPER(c_unit_status_desc) = UPPER('InService')
						and upper(c_og_sales_region) in (select upper(region) from fms_region)
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						 group by region_id, year, quarter, c_market_industry_desc order by region_id) as Count_IBRegion 
					INNER JOIN
					(select sum(COALESCE(avtot, 0)) as IBO_by_Region, region_id, year, quarter,c_market_industry_desc from fms_ibas_equipment 
						where year = in_year and UPPER(quarter) = UPPER(in_quarter) and UPPER(c_unit_status_desc) = UPPER('InService')
						and upper(c_og_sales_region) in (select upper(region) from fms_region)
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						 group by region_id, year, quarter,c_market_industry_desc order by region_id) as IBO_by_Region  
					ON Count_IBRegion.region_id = IBO_by_Region.region_id 
					and Count_IBRegion.year = IBO_by_Region.year
					and Count_IBRegion.quarter = IBO_by_Region.quarter
					and Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis>0
			) 
                 ) 
		UNION
		 (
			select IBO_by_Region_tot.region_id, IBO_by_Region_tot.year, IBO_by_Region_tot.quarter, 
			(Round(IBO_by_Region_tot.IBO_by_Region/Count_IBRegion_tot.count_gis, 2)) as Caloric_Index
			, v_b_unit  , IBO_by_Region_tot.c_market_industry_desc
			from 
			(
					(select count(c_gib_serial_number) as count_gis, v_total_id as region_id , year, quarter,c_market_industry_desc from fms_ibas_equipment 
						where year = in_year and UPPER(quarter) = UPPER(in_quarter) and UPPER(c_unit_status_desc) = UPPER('InService')
						and upper(c_og_sales_region) in (select upper(region) from fms_region)
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						 group by year, quarter,c_market_industry_desc) as Count_IBRegion_tot 
					INNER JOIN					
					(select sum(COALESCE(avtot, 0)) as IBO_by_Region, v_total_id  as region_id, year, quarter,c_market_industry_desc from fms_ibas_equipment 
						where year = in_year and UPPER(quarter) = UPPER(in_quarter) and UPPER(c_unit_status_desc) = UPPER('InService')
						and upper(c_og_sales_region) in (select upper(region) from fms_region)
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						 group by  year, quarter,c_market_industry_desc) as IBO_by_Region_tot  
					ON  Count_IBRegion_tot.year = IBO_by_Region_tot.year
					and Count_IBRegion_tot.quarter = IBO_by_Region_tot.quarter
					and Count_IBRegion_tot.c_market_industry_desc = IBO_by_Region_tot.c_market_industry_desc
					AND Count_IBRegion_tot.count_gis>0
			) 		 
		 )		
	) as s ;

SELECT fms_insert_metrics_data ('caloric_index', fms_metrics_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_all_metrics',   v_proc_paras ,    COALESCE(v_b_unit,'')||' : '||'caloric_index', query_return);
 
--DOLLAR BY IB

SELECT array_agg(s) INTO fms_metrics_records FROM
(
	(
		SELECT rev_by_region.region_id, rev_by_region.sales_year, rev_by_region.sales_quarter, (ROUND((rev_by_region.sum_sales_amt/1000)/ib_by_region.count_gis, 2))
		, v_b_unit , rev_by_region.c_market_industry_desc
		FROM
		   (
			(SELECT (sales_amt_at_op_rate*4)  AS sum_sales_amt, region_id, year AS sales_year, TRIM(both' ' FROM quarter) sales_quarter, c_market_industry_desc
					FROM fms_sales_n_cm_countries_pm
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter)
					AND UPPER(trim(identifier)) = 'REGION'
					--AND UPPER(business_segment) = v_b_unit
					GROUP BY (sales_amt_at_op_rate*4),region_id, year,TRIM(both' ' FROM quarter),c_market_industry_desc
				ORDER BY region_id) AS rev_by_region 
			INNER JOIN
			(SELECT count(c_gib_serial_number) AS count_gis, region_id, year, quarter , c_market_industry_desc
				FROM fms_ibas_equipment 
				where year = in_year AND UPPER(quarter) = UPPER(in_quarter)
				and upper(c_og_sales_region) in (select upper(region) from fms_region)	
				AND UPPER(c_unit_status_desc) = UPPER('InService')
				AND ibo_type = 'addressable_ibo'
				--AND UPPER(C_PROD_EXC_PL) = v_b_unit
				GROUP BY region_id, year, quarter , c_market_industry_desc
				ORDER BY region_id ) AS ib_by_region
			ON rev_by_region.region_id = ib_by_region.region_id
			AND sales_year = ib_by_region.year
			AND rev_by_region.sales_quarter = ib_by_region.quarter
			AND rev_by_region.c_market_industry_desc = ib_by_region.c_market_industry_desc
			AND ib_by_region.count_gis>0
		  )  
	)
	UNION
	(
	SELECT rev_by_region_tot.region_id, rev_by_region_tot.sales_year, rev_by_region_tot.sales_quarter, (ROUND((rev_by_region_tot.sum_sales_amt/1000)/ib_by_region_tot.count_gis, 2))
	, v_b_unit , rev_by_region_tot.c_market_industry_desc
		FROM
		   (
			(SELECT SUM(COALESCE(sales_amt_at_op_rate, 0))*4  AS sum_sales_amt, v_total_id AS region_id, year AS sales_year, TRIM(both' ' FROM quarter) sales_quarter, c_market_industry_desc
					FROM fms_sales_n_cm_countries_pm
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter)
					AND UPPER(trim(identifier)) = 'REGION'
					--AND UPPER(business_segment) = v_b_unit
				GROUP BY quarter, year, c_market_industry_desc) AS rev_by_region_tot 
			INNER JOIN
			(SELECT count(c_gib_serial_number) AS count_gis, v_total_id AS region_id, year, quarter , c_market_industry_desc
				FROM fms_ibas_equipment 
				where year = in_year AND UPPER(quarter) = UPPER(in_quarter)
				and upper(c_og_sales_region) in (select upper(region) from fms_region)
				AND UPPER(c_unit_status_desc) = UPPER('InService')
				AND ibo_type = 'addressable_ibo'
				--AND UPPER(C_PROD_EXC_PL) = v_b_unit
				GROUP BY year, quarter, c_market_industry_desc) AS ib_by_region_tot
			ON rev_by_region_tot.region_id = ib_by_region_tot.region_id
			AND sales_year = ib_by_region_tot.year
			AND rev_by_region_tot.sales_quarter = ib_by_region_tot.quarter
			AND rev_by_region_tot.c_market_industry_desc = ib_by_region_tot.c_market_industry_desc
			AND ib_by_region_tot.count_gis>0
		    )  
	)	     
) AS s ;

SELECT fms_insert_metrics_data ('dollar_by_ib', fms_metrics_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_all_metrics',   v_proc_paras ,    COALESCE(v_b_unit,'')||' : '||'dollar_by_ib', query_return);

--FLEET COVERAGE

SELECT array_agg(s) INTO fms_metrics_records FROM
(
	(
	   SELECT Order_Count_by_Region.region_id, Order_Count_by_Region.year, Order_Count_by_Region.quarter, ROUND((prj_count/count_gis ::float) * 100)
	   , v_b_unit , Order_Count_by_Region.c_market_industry_desc
	   from
		(SELECT COUNT(c_project)*4 as prj_count, region_id, year, quarter, c_market_industry_desc from fms_service_orders_pm 
			where year = in_year and UPPER(quarter) = UPPER(in_quarter)
			--AND UPPER(n_me_tier_2) = v_b_unit
			      --and UPPER(me_dm_tier_3) like UPPER('%Opex%')
			group by region_id, year, quarter, c_market_industry_desc order by region_id) as Order_Count_by_Region 
		INNER JOIN
		(SELECT count(c_gib_serial_number)*3 as count_gis, region_id, year, quarter, c_market_industry_desc from fms_ibas_equipment 
			where year = in_year and UPPER(quarter) = UPPER(in_quarter) 
			and UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			and upper(c_og_sales_region) in (select upper(region) from fms_region)
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			group by region_id, year, quarter, c_market_industry_desc order by region_id) as Count_IBRegion
		ON Order_Count_by_Region.region_id = Count_IBRegion.region_id 
		AND Order_Count_by_Region.year = Count_IBRegion.year
		AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
		AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
		AND Count_IBRegion.count_gis>0
	)
	UNION
	(
	   SELECT Order_Count_by_Region_tot.region_id, Order_Count_by_Region_tot.year, Order_Count_by_Region_tot.quarter, ROUND((prj_count/count_gis ::float) * 100)
	   , v_b_unit  , Order_Count_by_Region_tot.c_market_industry_desc
	   from
		(SELECT COUNT(c_project)*4 as prj_count, v_total_id as region_id, year, quarter, c_market_industry_desc from fms_service_orders_pm 
			where year = in_year and UPPER(quarter) = UPPER(in_quarter)
			--AND UPPER(n_me_tier_2) = v_b_unit
			--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
			group by year, quarter, c_market_industry_desc order by region_id) as Order_Count_by_Region_tot 
		INNER JOIN		
		(SELECT count(c_gib_serial_number)*3 as count_gis, v_total_id as region_id, year, quarter, c_market_industry_desc from fms_ibas_equipment 
			where year = in_year and UPPER(quarter) = UPPER(in_quarter) 
			and UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			and upper(c_og_sales_region) in (select upper(region) from fms_region)
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			group by year, quarter, c_market_industry_desc order by region_id) as Count_IBRegion_tot
		ON Order_Count_by_Region_tot.region_id = Count_IBRegion_tot.region_id 
		AND Order_Count_by_Region_tot.year = Count_IBRegion_tot.year
		AND Order_Count_by_Region_tot.quarter = Count_IBRegion_tot.quarter		
		AND Order_Count_by_Region_tot.c_market_industry_desc = Count_IBRegion_tot.c_market_industry_desc
		AND Count_IBRegion_tot.count_gis>0
	)	
) as s ;

SELECT fms_insert_metrics_data ('fleet_coverage', fms_metrics_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_all_metrics',   v_proc_paras ,    COALESCE(v_b_unit,'')||' : '||'fleet_coverage', query_return);

--FLEET PEN F2F

SELECT array_agg(s) INTO fms_metrics_records FROM
(
	select order_by_region.region_id, order_by_region.year, order_by_region.quarter, (Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100 as Fleet_Penetration
	, v_b_unit  , order_by_region.c_market_industry_desc
		from (
			(
			  select SUM(COALESCE(n_order_val_op_rate, 0)) * 4  as order_value_op_rate, region_id, year, quarter, c_market_industry_desc 
				from fms_service_orders_pm 
				where year = in_year and UPPER(quarter) = UPPER(in_quarter) 
				and UPPER(me_dm_tier_3) like UPPER('%Opex%')
				--AND UPPER(n_me_tier_2) = v_b_unit
				group by region_id, year, quarter, c_market_industry_desc 
				order by region_id
			) as order_by_region 
			INNER JOIN 
			(
			  select sum(COALESCE(avf2f, 0)) as sum_avf2f, region_id, year, quarter , c_market_industry_desc
				from fms_ibas_equipment 
				where year = in_year and UPPER(quarter) = UPPER(in_quarter) 
				and UPPER(c_unit_status_desc) = UPPER('InService')
				AND ibo_type = 'addressable_ibo'
				and upper(c_og_sales_region) in (select upper(region) from fms_region)
				--AND UPPER(C_PROD_EXC_PL) = v_b_unit
				group by region_id, year, quarter, c_market_industry_desc order by region_id	
			) as ibr 
	ON order_by_region.region_id = ibr.region_id
	and order_by_region.year = ibr.year
	and order_by_region.quarter = ibr.quarter
	and order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
	AND ibr.sum_avf2f > 0)
	
UNION

	select order_by_region_tot.region_id, order_by_region_tot.year, order_by_region_tot.quarter, (Round((order_by_region_tot.order_value_op_rate/1000)/ibr_tot.sum_avf2f, 2)) * 100 as Fleet_Penetration  
	, v_b_unit, order_by_region_tot.c_market_industry_desc
		from (
			(
			  select SUM(COALESCE(n_order_val_op_rate, 0)) * 4  as order_value_op_rate, v_total_id as region_id, year, quarter , c_market_industry_desc
				from fms_service_orders_pm 
				where year = in_year and UPPER(quarter) = UPPER(in_quarter)  
				and UPPER(me_dm_tier_3) like UPPER('%Opex%')
				--AND UPPER(n_me_tier_2) = v_b_unit
				group by year, quarter, c_market_industry_desc
			) as order_by_region_tot 
			INNER JOIN 
			(
			  select sum(COALESCE(avf2f, 0)) as sum_avf2f, v_total_id as region_id, year, quarter , c_market_industry_desc
				from fms_ibas_equipment 
				where year = in_year and UPPER(quarter) = UPPER(in_quarter) 
				and UPPER(c_unit_status_desc) = UPPER('InService')
				AND ibo_type = 'addressable_ibo'
				and upper(c_og_sales_region) in (select upper(region) from fms_region)
				--AND UPPER(C_PROD_EXC_PL) = v_b_unit
				group by year, quarter , c_market_industry_desc				
			) as ibr_tot 
	ON order_by_region_tot.region_id = ibr_tot.region_id
	and order_by_region_tot.year = ibr_tot.year
	and order_by_region_tot.quarter = ibr_tot.quarter
	and order_by_region_tot.c_market_industry_desc = ibr_tot.c_market_industry_desc
	AND ibr_tot.sum_avf2f > 0)
) as s ;

SELECT fms_insert_metrics_data ('fleet_pen_f2f', fms_metrics_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_all_metrics',   v_proc_paras ,    COALESCE(v_b_unit,'')||' : '||'fleet_pen_f2f', query_return);

--FLEET PENETRATION

FOR a IN 1..4 LOOP

IF a = 1 
                THEN v_av_value = 'avtot';
                                v_srvc_typ_desc = '  ';
                                v_report = 'fleet_penetration';
   ELSIF a = 2
                THEN v_av_value = 'COALESCE(n_avg_parts_value, 0) + COALESCE(avaux, 0)';
                                v_srvc_typ_desc = ' AND UPPER(n_service_type) = UPPER(''Parts'') ';
                                v_report = 'parts_fleet_penetration';
   ELSIF a = 3
                THEN v_av_value = 'n_avg_repair_value';
                                v_srvc_typ_desc = ' AND UPPER(n_service_type) = UPPER(''Repairs'') ';
                                v_report = 'repairs_fleet_penetration';
   ELSIF a = 4
                THEN v_av_value = 'COALESCE(n_avg_svcs_value, 0) + COALESCE(avmanpow, 0)';
                                v_srvc_typ_desc = ' AND UPPER(n_service_type) = UPPER(''Field Services'') ';
                                v_report = 'svcs_fleet_penetration';
END IF;

RAISE NOTICE 'a is %', a; 
RAISE NOTICE 'v_av_value is %', v_av_value;
RAISE NOTICE 'v_srvc_typ_desc is %', v_srvc_typ_desc;

v_query = '
SELECT array_agg(s) FROM
(
    select order_by_region.region_id, order_by_region.year, order_by_region.quarter, (Round((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100 as ' || v_report || '
	,' || '''' ||  v_b_unit    || '''' || ', order_by_region.c_market_industry_desc
                from (
                                (
                                select SUM(COALESCE(n_order_val_op_rate, 0)) * 4  as order_value_op_rate, region_id,  year, quarter, c_market_industry_desc 
                                                from fms_service_orders_pm 
                                                where year = ' ||  in_year  || '::NUMERIC and UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ')  and UPPER(me_dm_tier_3) like UPPER(''%Opex%'')
                                                ' ||  v_srvc_typ_desc  || '
												--AND UPPER(n_me_tier_2) = ' || '''' ||  v_b_unit    || '''' || '
                                                group by region_id, year, quarter, c_market_industry_desc 
                                                order by region_id
                                ) as order_by_region 
                                INNER JOIN 
                                (
                                  select sum(COALESCE(' ||  v_av_value  || ', 0)) as sum_value, region_id, year, quarter , c_market_industry_desc
                                                from fms_ibas_equipment 
                                                where year = ' ||  in_year  || '::NUMERIC and UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
                                                and UPPER(c_unit_status_desc) = UPPER(''InService'')
												AND ibo_type = ''addressable_ibo''
                                                and upper(c_og_sales_region) in (select upper(region) from fms_region)
												--AND UPPER(C_PROD_EXC_PL) = ' || '''' ||  v_b_unit    || '''' || '
                                                group by region_id, year, quarter, c_market_industry_desc order by region_id 
                                ) as ibr 
                                ON order_by_region.region_id = ibr.region_id
                                and order_by_region.year = ibr.year
                                and order_by_region.quarter = ibr.quarter
								and order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
								AND ibr.sum_value > 0
                     ) 
					 
                UNION
				
                select order_by_region_tot.region_id, order_by_region_tot.year, order_by_region_tot.quarter, (Round((order_value_op_rate/1000)/ibr_tot.sum_value, 2)) * 100 as ' || v_report || ' 
				,' || '''' ||  v_b_unit    || '''' || ' , order_by_region_tot.c_market_industry_desc
                from (
                                (
                                select SUM(COALESCE(n_order_val_op_rate, 0)) * 4  as order_value_op_rate, ' || v_total_id || ' as region_id,  year, quarter , c_market_industry_desc
                                                from fms_service_orders_pm 
                                                where year = '  || in_year  || '::NUMERIC and UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ')  and UPPER(me_dm_tier_3) like UPPER(''%Opex%'')
                                                ' ||  v_srvc_typ_desc  || '
												--AND UPPER(n_me_tier_2) = ' || '''' ||  v_b_unit    || '''' || '
                                                group by year, quarter , c_market_industry_desc
                                                order by region_id
                                ) as order_by_region_tot 
                                INNER JOIN           
                                (
                                  select sum(COALESCE(' ||  v_av_value  || ', 0)) as sum_value, ' || v_total_id || ' as region_id, year, quarter , c_market_industry_desc
                                                from fms_ibas_equipment 
                                                where year = ' ||  in_year  || '::NUMERIC and UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
                                                and UPPER(c_unit_status_desc) = UPPER(''InService'')
												AND ibo_type = ''addressable_ibo''
                                                and upper(c_og_sales_region) in (select upper(region) from fms_region)
												--AND UPPER(C_PROD_EXC_PL) = ' || '''' ||  v_b_unit    || '''' || '
                                                group by year, quarter , c_market_industry_desc order by region_id 
                                ) as ibr_tot 
                                ON order_by_region_tot.region_id = ibr_tot.region_id
                                and order_by_region_tot.year = ibr_tot.year
                                and order_by_region_tot.quarter = ibr_tot.quarter
								and order_by_region_tot.c_market_industry_desc = ibr_tot.c_market_industry_desc
								AND ibr_tot.sum_value  > 0
                     )                      
) as s' ;

RAISE NOTICE '%' , v_query;

EXECUTE v_query INTO fms_metrics_records;

RAISE NOTICE 'fms_metrics_records %', fms_metrics_records;
SELECT fms_insert_metrics_data (v_report, fms_metrics_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_all_metrics',   v_proc_paras ,  COALESCE(v_b_unit,'')||' : '||v_report , query_return);

END LOOP;

--IBO BY REGION

SELECT array_agg(s) INTO fms_metrics_records FROM
(
	(		
	   select reg.region_id, COALESCE(equip.year,in_year), COALESCE(equip.quarter,in_quarter), SUM(COALESCE(avtot,0)) as sum_av_tot
	   , v_b_unit , c_market_industry_desc
		from fms_ibas_equipment equip RIGHT OUTER JOIN fms_region reg
		ON reg.region = equip.c_og_sales_region
		and year = in_year and UPPER(quarter) = UPPER(in_quarter)
		and UPPER(c_unit_status_desc) = UPPER('InService')
		AND ibo_type = 'addressable_ibo'
		and upper(c_og_sales_region) in (select upper(region) from fms_region)
		--AND UPPER(C_PROD_EXC_PL) = v_b_unit
		where UPPER(reg.region) <> 'TOTAL'
		group by reg.region_id, year, quarter, c_market_industry_desc order by reg.region_id
	)
	UNION
	(
           select v_total_id AS region_id, year, quarter, SUM(COALESCE(avtot,0)) as sum_av_tot
		   , v_b_unit , c_market_industry_desc
		   from fms_ibas_equipment 
		where year = in_year and UPPER(quarter) = UPPER(in_quarter) 
		and UPPER(c_unit_status_desc) = UPPER('InService')
		AND ibo_type = 'addressable_ibo'
		and upper(c_og_sales_region) in (select upper(region) from fms_region)
		--AND UPPER(C_PROD_EXC_PL) = v_b_unit
		 group by year, quarter, c_market_industry_desc order by region_id
	)	
) as s ;

SELECT fms_insert_metrics_data ('ibo_by_region', fms_metrics_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_all_metrics',   v_proc_paras ,    COALESCE(v_b_unit,'')||' : '||'ibo_by_region', query_return);

-- CONVERSION INDEX

SELECT array_agg(s) INTO fms_metrics_records FROM
	(
	   SELECT region_id, year, quarter, round(((dollar_by_ib/CASE WHEN caloric_index = NULL THEN 1
									WHEN caloric_index = 0 THEN 1
									ELSE caloric_index
									END)*100)) as conv_index
									, v_b_unit ,c_market_industry_desc
		FROM fms_metrics where year = in_year and UPPER(quarter) = UPPER(in_quarter)
		--AND UPPER(business_segment) = v_b_unit
		order by region_id
	) as s ;

SELECT fms_insert_metrics_data ('conversion_index', fms_metrics_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_all_metrics',   v_proc_paras ,    COALESCE(v_b_unit,'')||' : '||'conversion_index', query_return);

--IB BY REGION

SELECT array_agg(s) INTO fms_metrics_records FROM
(
	(
        	select reg.region_id, COALESCE(equip.year,in_year), COALESCE(equip.quarter,in_quarter), count(c_gib_serial_number) as count_gis 
			, v_b_unit , c_market_industry_desc
			from fms_ibas_equipment equip RIGHT OUTER JOIN fms_region reg
			ON reg.region = equip.c_og_sales_region
			and year = in_year and UPPER(quarter) = UPPER(in_quarter)
			and UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			and upper(c_og_sales_region) in (select upper(region) from fms_region)
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			where UPPER(reg.region) <> 'TOTAL'
			group by reg.region_id, year, quarter , c_market_industry_desc
			order by reg.region_id 		
	)
	UNION
	(
		select v_total_id as region_id, year, quarter, count(c_gib_serial_number) as count_gis 
		, v_b_unit , c_market_industry_desc
			from fms_ibas_equipment 
			where year = in_year and UPPER(quarter) = UPPER(in_quarter)
			and UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			and upper(c_og_sales_region) in (select upper(region) from fms_region)
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			group by year, quarter, c_market_industry_desc
	)	     
) as s ;

SELECT fms_insert_metrics_data ('ib_by_region', fms_metrics_records) INTO query_return; 
 
PERFORM fms_db_logger('fms_calc_all_metrics',   v_proc_paras ,    COALESCE(v_b_unit,'')||' : '||'ib_by_region', query_return);

-----------------------------------------------------------------------------------------------TECHNOLOGY

SELECT tech_id INTO v_total_id FROM fms_tech WHERE 	UPPER(tech_desc) = 'TOTAL';

--IB BY TECH

FOR industry_desc IN (SELECT DISTINCT c_market_industry_desc FROM fms_ibas_equipment WHERE c_market_industry_desc IS NOT NULL
	AND ibo_type = 'addressable_ibo')

LOOP

SELECT array_agg(outer_1)  INTO fms_metrics_tech_records FROM
(
	SELECT * FROM
	(
		(
			select tech.tech_id, COALESCE(equip.year,in_year), COALESCE(equip.quarter,in_quarter), count(equip.c_gib_serial_number) as count_gis 
			, v_b_unit , industry_desc
				from fms_ibas_equipment equip RIGHT OUTER JOIN fms_tech tech
				ON 
				equip.C_TECHNOLOGY_DESC_OG = tech.tech_desc and
				year = in_year and UPPER(equip.quarter) = UPPER(in_quarter)	
				and UPPER(c_unit_status_desc) = UPPER('InService')
				AND ibo_type = 'addressable_ibo'
				and upper(c_og_sales_region) in (select upper(region) from fms_region)
				--AND UPPER(C_PROD_EXC_PL) = v_b_unit
				where UPPER(tech.tech_desc) <> 'TOTAL'
				group by tech.tech_id, year, quarter , industry_desc
				order by tech.tech_id 		
		)
		UNION
		(
			select v_total_id as tech_id, equip.year, equip.quarter, count(equip.c_gib_serial_number) as count_gis
			, v_b_unit , industry_desc
				from fms_ibas_equipment equip, fms_tech tech
				where 
				equip.C_TECHNOLOGY_DESC_OG = tech.tech_desc and
				year = in_year and UPPER(quarter) = UPPER(in_quarter)	
				and UPPER(c_unit_status_desc) = UPPER('InService')
				AND ibo_type = 'addressable_ibo'
				and upper(c_og_sales_region) in (select upper(region) from fms_region)
				--AND UPPER(C_PROD_EXC_PL) = v_b_unit
				group by year, quarter, industry_desc
				order by tech_id
		)	     
	) as inner_1 order by tech_id
) as outer_1;

raise notice 'fms_metrics_records %', fms_metrics_records;

SELECT fms_insert_metrics_tech_data ('ib_by_tech', fms_metrics_tech_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_all_metrics',   v_proc_paras ,    COALESCE(v_b_unit,'')||' : '||'ib_by_tech'||' : '||industry_desc, query_return);

--IBO BY TECH

SELECT array_agg(outer_1)  INTO fms_metrics_tech_records FROM
(
	SELECT * FROM
	(
		(
        	select tech.tech_id, COALESCE(year,in_year), COALESCE(quarter,in_quarter), sum(COALESCE(avtot, 0)) as sum_avtot
			, v_b_unit, industry_desc
			from fms_ibas_equipment equip right outer join fms_tech tech 
			on 
			equip.C_TECHNOLOGY_DESC_OG = tech.tech_desc and
			equip.year = in_year and UPPER(quarter) = UPPER(in_quarter) 
			and UPPER(equip.c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			and upper(c_og_sales_region) in (select upper(region) from fms_region)
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			where UPPER(tech.tech_desc) <> 'TOTAL'
			group by tech.tech_id, year, quarter, industry_desc order by tech.tech_id		
		)
		UNION
		(
		    select v_total_id as tech_id, equip.year, equip.quarter, sum(COALESCE(avtot, 0)) as sum_avtot
			, v_b_unit, industry_desc
			from fms_ibas_equipment equip, fms_tech tech
			where 
			equip.C_TECHNOLOGY_DESC_OG = tech.tech_desc and
			equip.year = in_year and UPPER(equip.quarter) = UPPER(in_quarter)
			and UPPER(equip.c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			and upper(c_og_sales_region) in (select upper(region) from fms_region)	
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit			
			group by year, quarter, industry_desc
		)	     
	) as inner_1 order by tech_id
) as outer_1;

raise notice 'fms_metrics_records %', fms_metrics_records;

SELECT fms_insert_metrics_tech_data ('ibo_by_tech', fms_metrics_tech_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_all_metrics',   v_proc_paras ,   COALESCE(v_b_unit,'')||' : '||'ibo_by_tech'||' : '||industry_desc, query_return);

END LOOP;

 --v_b_unit = 'DTS';
  
  --END LOOP;

  UPDATE fms_metrics SET business_segment = NULL WHERE business_segment = '';
  UPDATE fms_metrics_tech SET business_segment = NULL WHERE business_segment = '';
  
	RETURN 'SUCCESS';

	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_calc_all_metrics',
			     v_proc_paras ,
			     sqlerrm,
			     'DATABASE ERROR');		
	--RAISE NOTICE 'SQL ERROR %', sqlerrm;
	RETURN 'DATABASE ERROR';		
	
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
