-- Function: fms_calc_pen_metrics_country_overalldata()

-- DROP FUNCTION fms_calc_pen_metrics_country_overalldata();

CREATE OR REPLACE FUNCTION fms_calc_pen_metrics_country_overalldata()
  RETURNS character varying AS
$BODY$
DECLARE

    v_proc_paras character varying(2500);
    v_iterator numeric;
    v_max_regions numeric;
    v_factor numeric;
	
	v_b_unit character varying;
    
BEGIN

	DELETE FROM fms_metrics_country_tech WHERE year IS NULL AND quarter IS NULL;

	v_b_unit = '';
	
--	v_b_unit = 'TMS';

--	FOR a IN 1..2 LOOP
	
	Select Count(distinct n_book_year::text || n_book_quarter::text) *0.25::numeric INTO v_factor from fms_service_orders_pm;
	--WHERE UPPER(trim(n_me_tier_2)) = v_b_unit;
	
	--INSERT THE COUNTRY LEVEL POSSIBLE ROWS BASED ON THE NUMBER OF COUNTRIES (EQUIPMENT DATA)

	INSERT INTO fms_metrics_country_tech(REGION_ID, year, tech_id, quarter, country,c_market_industry_desc)
	--, business_segment)
	SELECT REGION_ID, Null AS year, NULL AS tech_id, Null AS quarter, country, c_market_industry_desc
	--,v_b_unit AS business_segment
	FROM 
	(SELECT DISTINCT country, REGION_ID, c_market_industry_desc
	--, v_b_unit AS business_segment 
	FROM
	(
		SELECT DISTINCT country, REGION_ID, c_market_industry_desc FROM 
		(SELECT DISTINCT c_site_customer_country AS country, REGION_ID, c_market_industry_desc
		FROM fms_ibas_equipment
		WHERE c_site_customer_country IS NOT NULL
		AND UPPER(c_unit_status_desc) = UPPER('InService') 
		AND ibo_type = 'addressable_ibo'
		--AND UPPER(C_PROD_EXC_PL) = v_b_unit
		and upper(c_og_sales_region) in (select upper(region) from fms_region)
		) AS inner_country 
	) AS country ) AS country_region ORDER BY country;

	--INSERT TOTAL FOR COUNTRY LEVEL DATA FOR ALL 8 REGIONS

	v_iterator = 1;
	
	SELECT COUNT(*) INTO v_max_regions FROM fms_region WHERE UPPER(region) <> 'TOTAL';

	FOR count in 1..v_max_regions LOOP

	INSERT INTO fms_metrics_country_tech(region_id, year, tech_id, quarter, country, c_market_industry_desc)
	--, business_segment)
	SELECT region_id, NULL AS year, NULL AS tech_id, NULL AS quarter, country, c_market_industry_desc
	FROM (SELECT DISTINCT c_market_industry_desc, v_iterator AS region_id,
	'TOTAL' AS country FROM fms_service_orders_segment_mapping) AS inner_q;
	--, v_b_unit AS business_segment) AS inner_q;

	v_iterator = v_iterator + 1;

	END LOOP;
	
	--COUNTRY WISE BREAK, Caloric_Index
	
	UPDATE fms_metrics_country_tech main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.region_id, Null, Null, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index, IBO_by_Region.country
		   , IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) * v_factor AS count_gis, region_id, c_site_customer_country AS country
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE UPPER(c_unit_status_desc) = UPPER('InService')
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, c_site_customer_country , c_market_industry_desc
						ORDER BY region_id, c_site_customer_country) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) * v_factor AS IBO_by_Region, region_id, c_site_customer_country AS country
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE UPPER(c_unit_status_desc) = UPPER('InService')
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, c_site_customer_country,c_market_industry_desc
						ORDER BY region_id, c_site_customer_country) AS IBO_by_Region 
					ON
					Count_IBRegion.region_id = IBO_by_Region.region_id 
					AND Count_IBRegion.country = IBO_by_Region.country 
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc 
					AND Count_IBRegion.count_gis>0
			)) as subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year IS Null
			AND main.quarter IS Null
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A REGION GROUPING ALL COUNTRIES OF THAT REGION

	UPDATE fms_metrics_country_tech main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.region_id, Null, Null, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) * v_factor AS count_gis, region_id
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id,c_market_industry_desc
						ORDER BY region_id) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) * v_factor AS IBO_by_Region, region_id
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, c_market_industry_desc
						ORDER BY region_id) AS IBO_by_Region 						 
					ON
					Count_IBRegion.region_id = IBO_by_Region.region_id 
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc 
					AND Count_IBRegion.count_gis>0
			)) as subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year IS Null
			AND main.quarter IS Null
			AND main.country = 'TOTAL'
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc; 
			--AND main.business_segment = v_b_unit;

	--FLEET COVERAGE (USES ORDERS & EQUIPMENT DATA); COUNTRY 

	--COUNTRY WISE BREAK

	UPDATE fms_metrics_country_tech main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.region_id, Null, Null,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage, Order_Count_by_Region.country
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project) as prj_count, region_id,
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					--WHERE UPPER(n_me_tier_2) = v_b_unit
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY region_id, c_country_name,c_market_industry_desc
					ORDER BY region_id, c_country_name) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number) * 3 * v_factor as count_gis, region_id, c_site_customer_country AS country
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit					
					GROUP BY region_id, c_site_customer_country,c_market_industry_desc 
					ORDER BY region_id, c_site_customer_country) as Count_IBRegion
				ON 
				Order_Count_by_Region.region_id = Count_IBRegion.region_id 
				AND Order_Count_by_Region.country = Count_IBRegion.country
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis>0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year IS Null
			AND main.quarter IS Null
			AND main.country = subQ.country 
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;
			
	--UPDATE TOTAL OF A REGION GROUPING ALL COUNTRIES OF THAT REGION

	UPDATE fms_metrics_country_tech main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.region_id, Null, Null,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project) as prj_count, region_id
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 	
					--WHERE UPPER(n_me_tier_2) = v_b_unit
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY region_id,c_market_industry_desc
					ORDER BY region_id) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number) * 3 * v_factor as count_gis, region_id
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'					
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id,c_market_industry_desc
					ORDER BY region_id) as Count_IBRegion
				ON 
				Order_Count_by_Region.region_id = Count_IBRegion.region_id 
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc 
				AND count_gis>0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year IS Null
			AND main.quarter IS Null
			AND main.country = 'TOTAL'
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
			--AND main.business_segment = v_b_unit;

	--FLEET PENETRATION F2F (USES ORDERS & EQUIPMENT DATA); COUNTRY 
	
	--COUNTRY WISE BREAK

	UPDATE fms_metrics_country_tech main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.region_id, NUll, Null,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F, order_by_region.country
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0))  AS order_value_op_rate, region_id, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit
					GROUP BY region_id, c_country_name,c_market_industry_desc
					ORDER BY region_id, c_country_name) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) * v_factor AS sum_avf2f, region_id, c_site_customer_country AS country
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_site_customer_country,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year IS Null
			AND main.quarter IS Null
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A REGION GROUPING ALL COUNTRIES OF THAT REGION

	UPDATE fms_metrics_country_tech main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.region_id, Null, Null,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) AS order_value_op_rate, region_id
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit
					GROUP BY region_id,c_market_industry_desc
					ORDER BY region_id) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) * v_factor AS sum_avf2f, region_id
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id , c_market_industry_desc
					ORDER BY region_id) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id  
			AND main.year IS Null
			AND main.quarter IS Null
			AND main.country = 'TOTAL'
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc  ;
			--AND main.business_segment = v_b_unit;


	--FLEET PENETRATION (USES ORDERS & EQUIPMENT DATA); COUNTRY 

	--COUNTRY WISE BREAK

	UPDATE fms_metrics_country_tech main
		SET fleet_penetration = subQ.Fleet_Penetration FROM
		(SELECT order_by_region.region_id, Null, Null,
		((ROUND((order_value_op_rate/1000)/ibr.sum_avtot, 2)) * 100) as Fleet_Penetration, order_by_region.country  
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) AS order_value_op_rate, region_id, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit
					GROUP BY region_id, c_country_name,c_market_industry_desc
					ORDER BY region_id, c_country_name) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(avtot, 0)) * v_factor AS sum_avtot, region_id, c_site_customer_country AS country 
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_site_customer_country,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avtot > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year IS Null
			AND main.quarter IS Null
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A REGION GROUPING ALL COUNTRIES OF THAT REGION

	UPDATE fms_metrics_country_tech main
		SET fleet_penetration = subQ.Fleet_Penetration FROM
		(SELECT order_by_region.region_id,Null, Null,
		((ROUND((order_value_op_rate/1000)/ibr.sum_avtot, 2)) * 100) as Fleet_Penetration
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0))  AS order_value_op_rate, region_id
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit
					GROUP BY region_id ,c_market_industry_desc
					ORDER BY region_id) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(avtot, 0)) * v_factor AS sum_avtot, region_id
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id ,c_market_industry_desc
					ORDER BY region_id) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avtot > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year IS Null
			AND main.quarter IS Null
			AND main.country = 'TOTAL'
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
			--AND main.business_segment = v_b_unit;

	--IBO BY COUNTRY (EQUIPMENT DATA); COUNTRY BREAK AVAILABLE
  
	--COUNTRY WISE BREAK

	UPDATE fms_metrics_country_tech main
		SET ibo_value = subQ.ibo_by_country FROM
		(SELECT region_id, SUM(COALESCE(avtot,0)) * v_factor AS ibo_by_country, c_site_customer_country as country
		,c_market_industry_desc
			FROM fms_ibas_equipment 
			WHERE UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			GROUP BY c_site_customer_country, region_id,c_market_industry_desc
			ORDER BY region_id, c_site_customer_country
		) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year IS Null
			AND main.quarter IS Null
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A REGION GROUPING ALL COUNTRIES OF THAT REGION

	UPDATE fms_metrics_country_tech main
		SET ibo_value = subQ.ibo_by_country FROM
		(SELECT region_id, SUM(COALESCE(avtot,0)) * v_factor AS ibo_by_country
		,c_market_industry_desc		
			FROM fms_ibas_equipment 
			WHERE UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			GROUP BY region_id ,c_market_industry_desc
			ORDER BY region_id
		) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year IS Null
			AND main.quarter IS Null
			AND main.country = 'TOTAL'
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
			--AND main.business_segment = v_b_unit;
			
--	v_b_unit = 'DTS';
  
--	END LOOP;
	
	RETURN 'SUCCESS';
	
	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_calc_pen_metrics_country_overalldata',
			     v_proc_paras ,
			     sqlerrm,
			     'DATABASE ERROR');		
	---- raise notice 'SQL ERROR %', sqlerrm;
	RETURN 'DATABASE ERROR';		
	
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
