-- Function: fms_calc_pen_metrics_region_overalldata()

-- DROP FUNCTION fms_calc_pen_metrics_region_overalldata();

CREATE OR REPLACE FUNCTION fms_calc_pen_metrics_region_overalldata()
  RETURNS character varying AS
$BODY$
DECLARE
    query_return character varying(20);
    fms_metrics_records type_fms_metrics[];

    v_proc_paras  character varying(2500); 
    v_total_id numeric;
    v_factor numeric;
	v_b_unit character varying;	
BEGIN

SELECT region_id INTO v_total_id FROM fms_region WHERE 	UPPER(region) = 'TOTAL';

	v_b_unit = '';

--	v_b_unit = 'TMS';

--	FOR a IN 1..2 LOOP

	Select Count(distinct n_book_year::text || n_book_quarter::text) *0.25::numeric INTO v_factor from fms_service_orders_pm ;
	--WHERE UPPER(trim(n_me_tier_2)) = v_b_unit;

	raise notice 'v_factor %', v_factor;

-- Caloric Index

SELECT array_agg(s) INTO fms_metrics_records FROM
	(
		(
		   select IBO_by_Region.region_id, Null, Null, (Round(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) as Caloric_Index 
		   , v_b_unit AS business_segment,IBO_by_Region.c_market_industry_desc
			from 
			(
					(select count(c_gib_serial_number) * v_factor as count_gis, region_id,c_market_industry_desc from fms_ibas_equipment 
						where UPPER(c_unit_status_desc) = UPPER('InService')
						AND ibo_type = 'addressable_ibo'
						and upper(c_og_sales_region) in (select upper(region) from fms_region)
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						 group by region_id,c_market_industry_desc order by region_id) as Count_IBRegion 
					INNER JOIN
					(select sum(COALESCE(avtot, 0)) * v_factor as IBO_by_Region, region_id,c_market_industry_desc from fms_ibas_equipment 
						where UPPER(c_unit_status_desc) = UPPER('InService')
						AND ibo_type = 'addressable_ibo'
						and upper(c_og_sales_region) in (select upper(region) from fms_region)
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						 group by region_id, c_market_industry_desc order by region_id) as IBO_by_Region  		
					ON Count_IBRegion.region_id = IBO_by_Region.region_id 
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc 
					AND Count_IBRegion.count_gis > 0
			) 
                 ) 
		UNION
		 (
			select IBO_by_Region_tot.region_id, Null, Null, (Round(IBO_by_Region_tot.IBO_by_Region/Count_IBRegion_tot.count_gis, 2)) as Caloric_Index  
			, v_b_unit AS business_segment,IBO_by_Region_tot.c_market_industry_desc
			from 
			(
					(select count(c_gib_serial_number) * v_factor as count_gis, v_total_id as region_id,c_market_industry_desc from fms_ibas_equipment 
						where  UPPER(c_unit_status_desc) = UPPER('InService')
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						and upper(c_og_sales_region) in (select upper(region) from fms_region)
						GROUP BY c_market_industry_desc) as Count_IBRegion_tot 
					INNER JOIN
					(select sum(COALESCE(avtot, 0)) * v_factor as IBO_by_Region, v_total_id  as region_id,c_market_industry_desc from fms_ibas_equipment 
						where UPPER(c_unit_status_desc) = UPPER('InService')
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						and upper(c_og_sales_region) in (select upper(region) from fms_region)
						GROUP BY c_market_industry_desc) as IBO_by_Region_tot  
					ON  Count_IBRegion_tot.region_id = IBO_by_Region_tot.region_id
					AND  Count_IBRegion_tot.c_market_industry_desc = IBO_by_Region_tot.c_market_industry_desc
					AND Count_IBRegion_tot.count_gis > 0
			) 		 
		 )	
	) as s ;

	raise notice 'fms_metrics_records %', fms_metrics_records;
	
SELECT fms_insert_metrics_data ('caloric_index', fms_metrics_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_pen_metrics_region_overalldata',   v_proc_paras ,   COALESCE(v_b_unit,'')||' : '||'caloric_index', query_return);

-- fleet_coverage

SELECT array_agg(s) INTO fms_metrics_records FROM
(
	(
	   SELECT Order_Count_by_Region.region_id, Null, Null, ROUND((prj_count/count_gis ::float) * 100)
	   , v_b_unit AS business_segment ,Order_Count_by_Region.c_market_industry_desc
	   from
		(SELECT COUNT(c_project) as prj_count, region_id,c_market_industry_desc from fms_service_orders_pm 
			--WHERE UPPER(n_me_tier_2) = v_b_unit		
			      --and UPPER(me_dm_tier_3) like UPPER('%Opex%')
			group by region_id,c_market_industry_desc order by region_id) as Order_Count_by_Region 
		INNER JOIN
		(SELECT count(c_gib_serial_number) * 3 * v_factor as count_gis, region_id,c_market_industry_desc from fms_ibas_equipment 
			where UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			and upper(c_og_sales_region) in (select upper(region) from fms_region)
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			group by region_id,c_market_industry_desc order by region_id) as Count_IBRegion
		ON Order_Count_by_Region.region_id = Count_IBRegion.region_id 
		AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
		AND  count_gis > 0
	)
	UNION
	(
	   SELECT Order_Count_by_Region_tot.region_id, Null, Null, ROUND((prj_count/count_gis ::float) * 100)
	   , v_b_unit AS business_segment ,Order_Count_by_Region_tot.c_market_industry_desc
	   from
		(SELECT COUNT(c_project) as prj_count, v_total_id as region_id,c_market_industry_desc from fms_service_orders_pm 
			--WHERE UPPER(n_me_tier_2) = v_b_unit	
			--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
			GROUP BY c_market_industry_desc
			order by region_id) as Order_Count_by_Region_tot 
		INNER JOIN		
		(SELECT count(c_gib_serial_number) * 3 * v_factor as count_gis, v_total_id as region_id,c_market_industry_desc from fms_ibas_equipment 
			where UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			and upper(c_og_sales_region) in (select upper(region) from fms_region)
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			GROUP BY c_market_industry_desc
			order by region_id) as Count_IBRegion_tot
		ON Order_Count_by_Region_tot.region_id = Count_IBRegion_tot.region_id 		
		AND Order_Count_by_Region_tot.c_market_industry_desc = Count_IBRegion_tot.c_market_industry_desc
		AND count_gis > 0		
	)	
) as s ;

raise notice 'fms_metrics_records %', fms_metrics_records;

SELECT fms_insert_metrics_data ('fleet_coverage', fms_metrics_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_pen_metrics_region_overalldata',   v_proc_paras ,   COALESCE(v_b_unit,'')||' : '||'fleet_coverage', query_return);

--fleet_penetration

SELECT array_agg(s) INTO fms_metrics_records FROM
(
    select order_by_region.region_id, Null, Null, (Round((order_value_op_rate/1000)/ibr.sum_avtot, 2)) * 100 as Fleet_Penetration 
	, v_b_unit AS business_segment	,order_by_region.c_market_industry_desc
	from (
		(
		 select SUM(COALESCE(n_order_val_op_rate, 0))  as order_value_op_rate, region_id ,c_market_industry_desc
			from fms_service_orders_pm 
			where UPPER(me_dm_tier_3) like UPPER('%Opex%')
			--AND UPPER(n_me_tier_2) = v_b_unit	
			group by region_id ,c_market_industry_desc
			order by region_id
		) as order_by_region 
		INNER JOIN 
		(
		  select sum(COALESCE(avtot, 0)) * v_factor as sum_avtot, region_id ,c_market_industry_desc
			from fms_ibas_equipment 
			where UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			and upper(c_og_sales_region) in (select upper(region) from fms_region)
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			group by region_id ,c_market_industry_desc order by region_id 
		) as ibr 
		ON order_by_region.region_id = ibr.region_id
		AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
		AND ibr.sum_avtot > 0
	     ) 
	UNION
	select order_by_region_tot.region_id, Null, Null, (Round((order_value_op_rate/1000)/ibr_tot.sum_avtot, 2)) * 100 as Fleet_Penetration
	, v_b_unit AS business_segment  ,order_by_region_tot.c_market_industry_desc
	from (
		(
		 select SUM(COALESCE(n_order_val_op_rate, 0)) as order_value_op_rate, v_total_id as region_id , c_market_industry_desc
			from fms_service_orders_pm 
			where UPPER(me_dm_tier_3) like UPPER('%Opex%')
			--AND UPPER(n_me_tier_2) = v_b_unit	
			GROUP BY c_market_industry_desc
			order by region_id
		) as order_by_region_tot 
		INNER JOIN 
		(
		  select sum(COALESCE(avtot, 0)) * v_factor as sum_avtot, v_total_id as region_id, c_market_industry_desc
			from fms_ibas_equipment 
			where UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			and upper(c_og_sales_region) in (select upper(region) from fms_region)
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			GROUP BY c_market_industry_desc
			order by region_id 
		) as ibr_tot 
		ON order_by_region_tot.region_id = ibr_tot.region_id
		AND order_by_region_tot.c_market_industry_desc = ibr_tot.c_market_industry_desc
		AND ibr_tot.sum_avtot > 0
	     )	      
) as s ;

	raise notice 'fms_metrics_records %', fms_metrics_records;

SELECT fms_insert_metrics_data ('fleet_penetration', fms_metrics_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_pen_metrics_region_overalldata',   v_proc_paras ,   COALESCE(v_b_unit,'')||' : '||'fleet_penetration', query_return);

--fleet_pen_f2f

SELECT array_agg(s) INTO fms_metrics_records FROM
(
	select order_by_region.region_id, Null, Null, (Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100 as Fleet_Penetration 
	, v_b_unit AS business_segment,order_by_region.c_market_industry_desc	
		from (
			(
			  select SUM(COALESCE(n_order_val_op_rate, 0)) as order_value_op_rate, region_id,c_market_industry_desc
				from fms_service_orders_pm 
				where UPPER(me_dm_tier_3) like UPPER('%Opex%')
				--AND UPPER(n_me_tier_2) = v_b_unit	
				group by region_id,c_market_industry_desc
				order by region_id
			) as order_by_region 
			INNER JOIN 
			(
			  select sum(COALESCE(avf2f, 0)) * v_factor as sum_avf2f, region_id ,c_market_industry_desc
				from fms_ibas_equipment 
				where UPPER(c_unit_status_desc) = UPPER('InService')
				AND ibo_type = 'addressable_ibo'
				and upper(c_og_sales_region) in (select upper(region) from fms_region)
				--AND UPPER(C_PROD_EXC_PL) = v_b_unit
				group by region_id,c_market_industry_desc order by region_id
			) as ibr 
	ON order_by_region.region_id = ibr.region_id
	AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
	AND ibr.sum_avf2f > 0)
UNION
	select order_by_region_tot.region_id, Null, Null, (Round((order_by_region_tot.order_value_op_rate/1000)/ibr_tot.sum_avf2f, 2)) * 100 as Fleet_Penetration 
	, v_b_unit AS business_segment ,order_by_region_tot.c_market_industry_desc
		from (
			(
			  select SUM(COALESCE(n_order_val_op_rate, 0)) as order_value_op_rate, v_total_id as region_id,c_market_industry_desc 
				from fms_service_orders_pm 
				where UPPER(me_dm_tier_3) like UPPER('%Opex%')
				--AND UPPER(n_me_tier_2) = v_b_unit	
				group by c_market_industry_desc
			) as order_by_region_tot 
			INNER JOIN 
			(
			  select sum(COALESCE(avf2f, 0)) * v_factor as sum_avf2f, v_total_id as region_id , c_market_industry_desc
				from fms_ibas_equipment 
				where UPPER(c_unit_status_desc) = UPPER('InService')
				AND ibo_type = 'addressable_ibo'
				and upper(c_og_sales_region) in (select upper(region) from fms_region)
				--AND UPPER(C_PROD_EXC_PL) = v_b_unit	
				group by c_market_industry_desc
			) as ibr_tot 
	ON order_by_region_tot.region_id = ibr_tot.region_id
	AND order_by_region_tot.c_market_industry_desc = ibr_tot.c_market_industry_desc
	AND ibr_tot.sum_avf2f > 0)
) as s ;

raise notice 'fms_metrics_records %', fms_metrics_records;

SELECT fms_insert_metrics_data ('fleet_pen_f2f', fms_metrics_records) INTO query_return;

PERFORM fms_db_logger('fms_calc_pen_metrics_region_overalldata',   v_proc_paras ,   COALESCE(v_b_unit,'')||' : '||'fleet_pen_f2f', query_return);

--ibo_by_region

SELECT array_agg(s) INTO fms_metrics_records FROM
(
	(		
	   select reg.region_id, Null, Null, SUM(COALESCE(avtot,0)) * v_factor as sum_av_tot
	   , v_b_unit AS business_segment ,c_market_industry_desc
		from fms_ibas_equipment equip RIGHT OUTER JOIN fms_region reg
		ON reg.region = equip.c_og_sales_region
		and UPPER(c_unit_status_desc) = UPPER('InService')
		AND ibo_type = 'addressable_ibo'
		and upper(c_og_sales_region) in (select upper(region) from fms_region)
		--AND UPPER(C_PROD_EXC_PL) = v_b_unit
		where UPPER(reg.region) <> 'TOTAL'
		group by reg.region_id,c_market_industry_desc order by reg.region_id
	)
	UNION
	(
           select v_total_id AS region_id, null, null, SUM(COALESCE(avtot,0)) * v_factor as sum_av_tot
		   , v_b_unit AS business_segment ,c_market_industry_desc
		   from fms_ibas_equipment 
		where UPPER(c_unit_status_desc) = UPPER('InService')
		AND ibo_type = 'addressable_ibo'
		and upper(c_og_sales_region) in (select upper(region) from fms_region)
		--AND UPPER(C_PROD_EXC_PL) = v_b_unit
		group by c_market_industry_desc
		 order by region_id
	)	
) as s ;

raise notice 'fms_metrics_records %', fms_metrics_records;

SELECT fms_insert_metrics_data ('ibo_by_region', fms_metrics_records) INTO query_return; 

PERFORM fms_db_logger('fms_calc_pen_metrics_region_overalldata',   v_proc_paras ,   COALESCE(v_b_unit,'')||' : '||'ibo_by_region', query_return);

--	v_b_unit = 'DTS';
  
--	END LOOP;

  UPDATE fms_metrics SET business_segment = NULL WHERE business_segment = '';
  UPDATE fms_metrics_tech SET business_segment = NULL WHERE business_segment = '';

RETURN 'SUCCESS';
    
	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_calc_pen_metrics_region_overalldata',
			     v_proc_paras ,
			     sqlerrm,
			     'DATABASE ERROR');		
	--RAISE NOTICE 'SQL ERROR %', sqlerrm;
	RETURN 'DATABASE ERROR';		
	
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
