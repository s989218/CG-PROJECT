-- Function: fms_calc_pen_metrics_segment_break(numeric, character varying)

-- DROP FUNCTION fms_calc_pen_metrics_segment_break(numeric, character varying);

CREATE OR REPLACE FUNCTION fms_calc_pen_metrics_segment_break(
    in_year numeric,
    in_quarter character varying)
  RETURNS character varying AS
$BODY$
DECLARE

    v_proc_paras character varying(2500); 
    v_iterator numeric;
    v_max_regions numeric;

    v_av_value character varying;
    v_srvc_typ_desc character varying;
    v_report character varying;
    v_query character varying;
    
	v_b_unit character varying;	
	
BEGIN

	v_proc_paras =  to_char(in_year, '0000') || ' ; ' || 
		in_quarter;

	SELECT TRIM(UPPER(in_quarter)) INTO in_quarter;

	/*

	GLOBAL WISE DATA IS SAVED WITH COUNTRY COLUMN AS NULL AND REGION_ID COLUMN AS NULL
	
	GLOBAL WISE TOTAL DATA IS SAVED WITH COUNTRY SEGMENT AS 'TOTAL' AND COUNTRY COLUMN AS NULL AND REGION_ID COLUMN AS NULL

	REGION WISE DATA IS SAVED WITH COUNTRY COLUMN AS NULL
	
	REGION WISE TOTAL DATA IS SAVED WITH COUNTRY COLUMN AS 'TOTAL' AND SEGMENT COULUMN AS NULL
	
	COUNTRY WISE DATA IS SAVED WITH COUNTRY COLUMN HAVING COUNTRY NAMES
	
	COUNTRY WISE TOTAL DATA IS SAVED WITH COUNTRY COLUMN HAVING COUNTRY NAMES||'_TOTAL' (EX: ITALY_TOTAL) AND SEGMENT COULUMN AS NULL

	*/

	DELETE FROM fms_metrics_segment WHERE year = in_year AND quarter = in_quarter;

	v_b_unit = '';
--	v_b_unit = 'TMS';

--	FOR a IN 1..2 LOOP
	
	--INSERT THE GLOBAL LEVEL POSSIBLE ROWS BASED ON THE NUMBER OF SEGMENTS

	INSERT INTO fms_metrics_segment(region_id,country,segment, year,  quarter,c_market_industry_desc)
	--, business_segment )
					
	SELECT NULL AS region_id, NULL AS country ,segment, in_year AS year,  
		in_quarter AS quarter,c_market_industry_desc
		--, v_b_unit AS business_segment
	FROM 
	(
		SELECT DISTINCT sm_segment_mapping AS segment, c_market_industry_desc FROM fms_service_orders_segment_mapping 
			WHERE sm_segment_mapping IS NOT NULL ORDER BY sm_segment_mapping 
	) AS region_segments;
	
	--INSERT THE GLOBAL LEVEL TOTAL ROWS

	INSERT INTO fms_metrics_segment(region_id,country,segment, year,  quarter,c_market_industry_desc)
	--, business_segment )
					
	SELECT DISTINCT NULL::NUMERIC AS region_id, NULL AS country ,'TOTAL' AS segment, in_year AS year,  
		in_quarter AS quarter,c_market_industry_desc FROM fms_service_orders_segment_mapping
		WHERE sm_segment_mapping IS NOT NULL ;
		--, v_b_unit AS business_segment;
	
	--INSERT THE REGION LEVEL POSSIBLE ROWS BASED ON THE NUMBER OF SEGMENTS OF EACH REGION

	INSERT INTO fms_metrics_segment(region_id,country,segment, year,  quarter ,c_market_industry_desc)
	--, business_segment)
					
	SELECT region_id, NULL AS country ,segment, in_year AS year,  
		in_quarter AS quarter,c_market_industry_desc
		--, v_b_unit AS business_segment
	FROM 
	(
		(SELECT DISTINCT region_id FROM fms_region WHERE region NOT IN ('Total') ORDER BY region_id) AS reg
		CROSS JOIN
		(SELECT DISTINCT sm_segment_mapping AS segment,c_market_industry_desc FROM fms_service_orders_segment_mapping 
			WHERE sm_segment_mapping IS NOT NULL ORDER BY sm_segment_mapping ) as seg
	) AS region_segments;
	
	--INSERT THE REGION LEVEL TOTAL POSSIBLE ROWS BASED ON THE NUMBER OF REGIONS 
	
	v_iterator = 1;

	SELECT COUNT(*) INTO v_max_regions FROM fms_region WHERE UPPER(region) <> 'TOTAL';

	--RAISE NOTICE '%', v_max_regions;

	FOR count in 1..v_max_regions LOOP

	INSERT INTO fms_metrics_segment(region_id,country,segment, year,  quarter,c_market_industry_desc)
	--, business_segment )
	SELECT DISTINCT v_iterator AS region_id, 'TOTAL' AS country, NULL AS segment, in_year AS year,
		in_quarter AS quarter,c_market_industry_desc FROM fms_service_orders_segment_mapping
		WHERE sm_segment_mapping IS NOT NULL ;
		--, v_b_unit AS business_segment;

	v_iterator = v_iterator + 1;

	END LOOP;
	
	--INSERT COUNTRY LEVEL POSSIBLE ROWS BASED ON THE NUMBER OF SEGMENTS IN ALL COUNTRIES

	INSERT INTO fms_metrics_segment(region_id,country,segment, year,  quarter,c_market_industry_desc)
	--, business_segment )
					
	SELECT region_id, country, segment, in_year AS year,
		in_quarter AS quarter,c_market_industry_desc
		--, v_b_unit AS business_segment
	FROM 
	(
		(SELECT DISTINCT region_id, c_site_customer_country AS country FROM fms_ibas_equipment 
			WHERE region_id IS NOT NULL AND c_site_customer_country IS NOT NULL AND UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			AND C_MARKET_INDUSTRY_DESC = 'Refinery & Petrochemical'
			ORDER BY region_id,country) AS coun
		CROSS JOIN
		(SELECT DISTINCT sm_segment_mapping AS segment,c_market_industry_desc FROM fms_service_orders_segment_mapping 
			WHERE sm_segment_mapping IS NOT NULL ORDER BY sm_segment_mapping ) as seg
	) AS country_segments ORDER BY region_id,country,segment;
	
	--INSERT COUNTRY LEVEL TOTAL POSSIBLE ROWS BASED ON THE NUMBER OF COUNTRIES

	INSERT INTO fms_metrics_segment(region_id,country,segment, year,  quarter,c_market_industry_desc)
	--, business_segment )
					
	SELECT region_id, country||'_TOTAL', NULL segment, in_year AS year,
		in_quarter AS quarter,c_market_industry_desc
		--, v_b_unit AS business_segment
	FROM 
	(
		SELECT DISTINCT region_id, c_site_customer_country AS country,c_market_industry_desc FROM fms_ibas_equipment 
			WHERE region_id IS NOT NULL AND c_site_customer_country IS NOT NULL AND UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			AND C_MARKET_INDUSTRY_DESC = 'Refinery & Petrochemical'
			ORDER BY region_id,country
	) AS country_segments ORDER BY region_id,country;
	
	
	--CALORIC INDEX (USES ONLY EQUIPMENT DATA);

	--COUNTRY WISE BREAK
	
	UPDATE fms_metrics_segment main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.region_id, IBO_by_Region.year,IBO_by_Region.segment, IBO_by_Region.quarter, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index,IBO_by_Region.country AS country
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) AS count_gis, region_id, year, quarter,c_market_segment_desc AS segment,c_site_customer_country AS country
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, c_site_customer_country,c_market_segment_desc, year, quarter ,c_market_industry_desc
						ORDER BY region_id, c_site_customer_country,c_market_segment_desc) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) AS IBO_by_Region, region_id, year, quarter,c_market_segment_desc AS segment,c_site_customer_country AS country
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, c_site_customer_country,c_market_segment_desc, year, quarter ,c_market_industry_desc
						ORDER BY region_id, c_site_customer_country,c_market_segment_desc) AS IBO_by_Region 
						 
					ON
					Count_IBRegion.region_id = IBO_by_Region.region_id
					AND Count_IBRegion.segment = IBO_by_Region.segment
					AND Count_IBRegion.country = IBO_by_Region.country
					AND Count_IBRegion.year = IBO_by_Region.year
					AND Count_IBRegion.quarter = IBO_by_Region.quarter
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis > 0
			)) as subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.segment = subQ.segment
			AND main.country = subQ.country
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A COUNTRY BASED ON GROUPING ALL SEGMENTS OF THAT COUNTRY
	
	UPDATE fms_metrics_segment main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.region_id, IBO_by_Region.year, IBO_by_Region.quarter, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index,IBO_by_Region.country||'_TOTAL' AS country
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) AS count_gis, region_id, year, quarter,c_site_customer_country AS country
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
						ORDER BY region_id, c_site_customer_country) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) AS IBO_by_Region, region_id, year, quarter,c_site_customer_country AS country
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
						ORDER BY region_id, c_site_customer_country) AS IBO_by_Region 
						 
					ON
					Count_IBRegion.region_id = IBO_by_Region.region_id
					AND Count_IBRegion.country = IBO_by_Region.country
					AND Count_IBRegion.year = IBO_by_Region.year
					AND Count_IBRegion.quarter = IBO_by_Region.quarter
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis > 0
			)) as subQ
		WHERE 
			main.region_id = subQ.region_id
			AND main.country = subQ.country
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.segment IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;
			
			
	--REGION WISE BREAK
	
	UPDATE fms_metrics_segment main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.region_id, IBO_by_Region.year,IBO_by_Region.segment, IBO_by_Region.quarter, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) AS count_gis, region_id, year, quarter,c_market_segment_desc AS segment
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, c_market_segment_desc, year, quarter ,c_market_industry_desc
						ORDER BY region_id, c_market_segment_desc) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) AS IBO_by_Region, region_id, year, quarter,c_market_segment_desc AS segment
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, c_market_segment_desc, year, quarter,c_market_industry_desc 
						ORDER BY region_id, c_market_segment_desc) AS IBO_by_Region 
						 
					ON
					Count_IBRegion.region_id = IBO_by_Region.region_id
					AND Count_IBRegion.segment = IBO_by_Region.segment
					AND Count_IBRegion.year = IBO_by_Region.year
					AND Count_IBRegion.quarter = IBO_by_Region.quarter
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis > 0
			)) as subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.segment = subQ.segment
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A REGION BASED ON GROUPING ALL SEGMENTS OF THAT REGION

	UPDATE fms_metrics_segment main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.region_id, IBO_by_Region.year, IBO_by_Region.quarter, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) AS count_gis, region_id, year, quarter
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, year, quarter ,c_market_industry_desc
						ORDER BY region_id) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) AS IBO_by_Region, region_id, year, quarter
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, year, quarter ,c_market_industry_desc
						ORDER BY region_id) AS IBO_by_Region 
						 
					ON
					Count_IBRegion.region_id = IBO_by_Region.region_id
					AND Count_IBRegion.year = IBO_by_Region.year
					AND Count_IBRegion.quarter = IBO_by_Region.quarter
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis >0
			)) as subQ
		WHERE 
			main.region_id = subQ.region_id
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country = 'TOTAL'
			AND main.segment IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;
			
	--GLOBAL BREAK
	
	UPDATE fms_metrics_segment main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT  IBO_by_Region.year,IBO_by_Region.segment, IBO_by_Region.quarter, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) AS count_gis,  year, quarter,c_market_segment_desc AS segment
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY  c_market_segment_desc, year, quarter ,c_market_industry_desc
						ORDER BY  c_market_segment_desc) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) AS IBO_by_Region,  year, quarter,c_market_segment_desc AS segment
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY  c_market_segment_desc, year, quarter ,c_market_industry_desc
						ORDER BY  c_market_segment_desc) AS IBO_by_Region 
						 
					ON
					Count_IBRegion.segment = IBO_by_Region.segment
					AND Count_IBRegion.year = IBO_by_Region.year
					AND Count_IBRegion.quarter = IBO_by_Region.quarter
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis > 0
			)) as subQ
		WHERE 
			main.segment = subQ.segment
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF GLOBAL LEVEL

	UPDATE fms_metrics_segment main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT  IBO_by_Region.year, IBO_by_Region.quarter, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) AS count_gis,  year, quarter
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY year, quarter,c_market_industry_desc 
						) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) AS IBO_by_Region,  year, quarter
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY year, quarter ,c_market_industry_desc
						) AS IBO_by_Region 
						 
					ON
					Count_IBRegion.year = IBO_by_Region.year
					AND Count_IBRegion.quarter = IBO_by_Region.quarter
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis > 0
			)) as subQ
		WHERE 
			main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.segment = 'TOTAL'
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--FLEET COVERAGE (USES ORDERS & EQUIPMENT DATA);

	--COUNTRY WISE BREAK

	UPDATE fms_metrics_segment main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.region_id, Order_Count_by_Region.year, Order_Count_by_Region.segment, Order_Count_by_Region.quarter,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage, Order_Count_by_Region.country
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project)*4 as prj_count, region_id, year, quarter, sm_segment_mapping AS segment, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter)
					--AND UPPER(n_me_tier_2) = v_b_unit
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY region_id, sm_segment_mapping, c_country_name, year, quarter ,c_market_industry_desc
					ORDER BY region_id, sm_segment_mapping, c_country_name) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number)*3 as count_gis, region_id, year, quarter, c_market_segment_desc AS segment, c_site_customer_country AS country
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_market_segment_desc,c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_market_segment_desc,c_site_customer_country) as Count_IBRegion
				ON 
				Order_Count_by_Region.region_id = Count_IBRegion.region_id 
				AND Order_Count_by_Region.year = Count_IBRegion.year
				AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
				AND Order_Count_by_Region.segment = Count_IBRegion.segment
				AND Order_Count_by_Region.country = Count_IBRegion.country
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.segment = subQ.segment 
			AND main.country = subQ.country 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A COUNTRY BASED ON GROUPING ALL SEGMENTS OF THAT COUNTRY

	UPDATE fms_metrics_segment main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.region_id, Order_Count_by_Region.year,  Order_Count_by_Region.quarter,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage, Order_Count_by_Region.country||'_TOTAL' AS country
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project)*4 as prj_count, region_id, year, quarter, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter)
					--AND UPPER(n_me_tier_2) = v_b_unit
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY region_id,  c_country_name, year, quarter ,c_market_industry_desc
					ORDER BY region_id,  c_country_name) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number)*3 as count_gis, region_id, year, quarter,  c_site_customer_country AS country
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as Count_IBRegion
				ON 
				Order_Count_by_Region.region_id = Count_IBRegion.region_id 
				AND Order_Count_by_Region.year = Count_IBRegion.year
				AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
				AND Order_Count_by_Region.country = Count_IBRegion.country
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id  
			AND main.country = subQ.country 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.segment IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--REGION WISE BREAK

	UPDATE fms_metrics_segment main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.region_id, Order_Count_by_Region.year, Order_Count_by_Region.segment, Order_Count_by_Region.quarter,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project)*4 as prj_count, region_id, year, quarter, sm_segment_mapping AS segment
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter)
					--AND UPPER(n_me_tier_2) = v_b_unit
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY region_id, sm_segment_mapping,  year, quarter ,c_market_industry_desc
					ORDER BY region_id, sm_segment_mapping) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number)*3 as count_gis, region_id, year, quarter, c_market_segment_desc AS segment
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_market_segment_desc, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_market_segment_desc) as Count_IBRegion
				ON 
				Order_Count_by_Region.region_id = Count_IBRegion.region_id 
				AND Order_Count_by_Region.year = Count_IBRegion.year
				AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
				AND Order_Count_by_Region.segment = Count_IBRegion.segment
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.segment = subQ.segment  
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A REGION BASED ON GROUPING ALL SEGMENTS OF THAT REGION

	UPDATE fms_metrics_segment main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.region_id, Order_Count_by_Region.year,  Order_Count_by_Region.quarter,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project)*4 as prj_count, region_id, year, quarter
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter)
					--AND UPPER(n_me_tier_2) = v_b_unit
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY region_id,  year, quarter ,c_market_industry_desc
					ORDER BY region_id) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number)*3 as count_gis, region_id, year, quarter
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id,  year, quarter ,c_market_industry_desc
					ORDER BY region_id) as Count_IBRegion
				ON 
				Order_Count_by_Region.region_id = Count_IBRegion.region_id 
				AND Order_Count_by_Region.year = Count_IBRegion.year
				AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country = 'TOTAL'
			AND main.segment IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--GLOBAL BREAK

	UPDATE fms_metrics_segment main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.year, Order_Count_by_Region.segment, Order_Count_by_Region.quarter,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project)*4 as prj_count, year, quarter, sm_segment_mapping AS segment
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter)
					--AND UPPER(n_me_tier_2) = v_b_unit
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY  sm_segment_mapping,  year, quarter ,c_market_industry_desc
					ORDER BY  sm_segment_mapping) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number)*3 as count_gis,  year, quarter, c_market_segment_desc AS segment
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY  c_market_segment_desc, year, quarter ,c_market_industry_desc
					ORDER BY  c_market_segment_desc) as Count_IBRegion
				ON 
				Order_Count_by_Region.year = Count_IBRegion.year
				AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
				AND Order_Count_by_Region.segment = Count_IBRegion.segment
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis > 0
			)) AS subQ
		WHERE 
			main.segment = subQ.segment  
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF GLOBAL LEVL

	UPDATE fms_metrics_segment main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.year, Order_Count_by_Region.quarter,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project)*4 as prj_count, year, quarter
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter)
					--AND UPPER(n_me_tier_2) = v_b_unit
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY  year, quarter ,c_market_industry_desc
					) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number)*3 as count_gis,  year, quarter
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY  year, quarter ,c_market_industry_desc
					) as Count_IBRegion
				ON 
				Order_Count_by_Region.year = Count_IBRegion.year
				AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis>0
			)) AS subQ
		WHERE 
			main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.segment = 'TOTAL'
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;
			
	--FLEET PENETRATION F2F (USES ORDERS & EQUIPMENT DATA);

	--COUNTRY WISE BREAK

	UPDATE fms_metrics_segment main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.segment, order_by_region.quarter,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F, order_by_region.country
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, sm_segment_mapping AS segment,
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit
					GROUP BY region_id, sm_segment_mapping, c_country_name, year, quarter,c_market_industry_desc 
					ORDER BY region_id, sm_segment_mapping, c_country_name) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) AS sum_avf2f, region_id, year, quarter, c_market_segment_desc AS segment
				, c_site_customer_country AS country
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_market_segment_desc,c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_market_segment_desc,c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.segment = ibr.segment
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.segment = subQ.segment
			AND main.country = subQ.country
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A COUNTRY BASED ON GROUPING ALL SEGMENTS OF THAT COUNTRY

	UPDATE fms_metrics_segment main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.region_id, order_by_region.year,  order_by_region.quarter,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F, order_by_region.country||'_TOTAL' AS country
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit
					GROUP BY region_id,  c_country_name, year, quarter ,c_market_industry_desc
					ORDER BY region_id,  c_country_name) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) AS sum_avf2f, region_id, year, quarter,  c_site_customer_country AS country
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id
			AND main.country = subQ.country
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.segment IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--REGION WISE BREAK

	UPDATE fms_metrics_segment main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.segment, order_by_region.quarter,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, sm_segment_mapping AS segment
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit
					GROUP BY region_id, sm_segment_mapping, year, quarter ,c_market_industry_desc
					ORDER BY region_id, sm_segment_mapping) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) AS sum_avf2f, region_id, year, quarter, c_market_segment_desc AS segment
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_market_segment_desc, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_market_segment_desc) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.segment = ibr.segment
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.segment = subQ.segment
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A REGION BASED ON GROUPING ALL SEGMENTS OF THAT REGION

	UPDATE fms_metrics_segment main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.quarter,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit
					GROUP BY region_id, year, quarter ,c_market_industry_desc
					ORDER BY region_id) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) AS sum_avf2f, region_id, year, quarter
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, year, quarter ,c_market_industry_desc
					ORDER BY region_id) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country = 'TOTAL'
			AND main.segment IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--GLOBAL BREAK

	UPDATE fms_metrics_segment main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT  order_by_region.year, order_by_region.segment, order_by_region.quarter,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate,  year, quarter, sm_segment_mapping AS segment
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit
					GROUP BY  sm_segment_mapping, year, quarter ,c_market_industry_desc
					ORDER BY  sm_segment_mapping) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) AS sum_avf2f,  year, quarter, c_market_segment_desc AS segment
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY  c_market_segment_desc, year, quarter ,c_market_industry_desc
					ORDER BY  c_market_segment_desc) as ibr 
				ON 
				order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.segment = ibr.segment
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.segment = subQ.segment
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL GLOBAL LEVEL

	UPDATE fms_metrics_segment main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT  order_by_region.year,  order_by_region.quarter,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate,  year, quarter
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit
					GROUP BY   year, quarter ,c_market_industry_desc
					) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) AS sum_avf2f,  year, quarter
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY   year, quarter ,c_market_industry_desc
					) as ibr 
				ON 
				order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.segment = 'TOTAL'
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;
	
	--FLEET PENETRATION (USES ORDERS & EQUIPMENT DATA);


	FOR a IN 1..4 LOOP

		IF a = 1 
                THEN v_av_value = 'avtot';
                                v_srvc_typ_desc = '  ';
                                v_report = 'fleet_penetration';
		ELSIF a = 2
                THEN 
                continue;
--                  v_av_value = 'COALESCE(n_avg_parts_value, 0) + COALESCE(avaux, 0)';
--                                 v_srvc_typ_desc = ' AND UPPER(n_service_type) = UPPER(''Parts'') ';
--                                 v_report = 'parts_fleet_penetration';
		ELSIF a = 3
                THEN 
                continue;
--                  v_av_value = 'n_avg_repair_value';
--                                 v_srvc_typ_desc = ' AND UPPER(n_service_type) = UPPER(''Repairs'') ';
--                                 v_report = 'repairs_fleet_penetration'; 
		ELSIF a = 4
                THEN 
                continue;
--                  v_av_value = 'COALESCE(n_avg_svcs_value, 0) + COALESCE(avmanpow, 0)';
--                                 v_srvc_typ_desc = ' AND UPPER(n_service_type) = UPPER(''Field Services'') ';
--                                 v_report = 'svcs_fleet_penetration'; 
		END IF;

	RAISE NOTICE 'a is %', a; 
	RAISE NOTICE 'v_av_value is %', v_av_value;
	RAISE NOTICE 'v_srvc_typ_desc is %', v_srvc_typ_desc;

	--COUNTRY WISE BREAK

	v_query = '
	UPDATE fms_metrics_segment main
		SET ' || v_report || ' = subQ.' || v_report || ' FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.segment, order_by_region.quarter,
		((ROUND((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100) as ' || v_report || ', order_by_region.country  
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, sm_segment_mapping AS segment,
					(CASE WHEN UPPER(c_country_name) = ''BOLIVIA, PLURINATIONAL STATE OF'' THEN ''BOLIVIA'' 
						WHEN UPPER(c_country_name) = ''LIBYAN ARAB JAMAHIRIYA'' THEN ''LIBYA'' 
						WHEN UPPER(c_country_name) = ''VENEZUELA, BOLIVARIAN REPUBLIC OF'' THEN ''VENEZUELA'' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(me_dm_tier_3) LIKE UPPER(''%Opex%'')
					--AND UPPER(n_me_tier_2) = ' || '''' || v_b_unit || '''' || '
					' ||  v_srvc_typ_desc  || '
					GROUP BY region_id, sm_segment_mapping, c_country_name, year, quarter ,c_market_industry_desc
					ORDER BY region_id, sm_segment_mapping, c_country_name) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(' ||  v_av_value  || ', 0)) AS sum_value, region_id, year, quarter, c_market_segment_desc AS segment
				, c_site_customer_country AS country 
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(c_unit_status_desc) = UPPER(''InService'')
					AND ibo_type = ''addressable_ibo''
					--AND UPPER(C_PROD_EXC_PL) = ' || '''' || v_b_unit || '''' || '
					GROUP BY region_id, c_market_segment_desc,c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_market_segment_desc,c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.segment = ibr.segment
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_value > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.segment = subQ.segment
			AND main.country = subQ.country
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.c_market_industry_desc = subQ.c_market_industry_desc';
			--AND main.business_segment = ' || '''' || v_b_unit || '''' || '';
			
	RAISE NOTICE 'COUNTRY WISE BREAK %' , v_query;

	EXECUTE v_query;
	
	--UPDATE TOTAL OF A COUNTRY BASED ON GROUPING ALL SEGMENTS OF THAT COUNTRY

	v_query = '
	UPDATE fms_metrics_segment main
		SET ' || v_report || ' = subQ.' || v_report || ' FROM
		(SELECT order_by_region.region_id, order_by_region.year,  order_by_region.quarter,
		((ROUND((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100) as ' || v_report || ', order_by_region.country||''_TOTAL'' AS country 
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, 
					(CASE WHEN UPPER(c_country_name) = ''BOLIVIA, PLURINATIONAL STATE OF'' THEN ''BOLIVIA'' 
						WHEN UPPER(c_country_name) = ''LIBYAN ARAB JAMAHIRIYA'' THEN ''LIBYA'' 
						WHEN UPPER(c_country_name) = ''VENEZUELA, BOLIVARIAN REPUBLIC OF'' THEN ''VENEZUELA'' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(me_dm_tier_3) LIKE UPPER(''%Opex%'')
					--AND UPPER(n_me_tier_2) = ' || '''' || v_b_unit || '''' || '
					' ||  v_srvc_typ_desc  || '
					GROUP BY region_id,  c_country_name, year, quarter ,c_market_industry_desc
					ORDER BY region_id,  c_country_name) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(' ||  v_av_value  || ', 0)) AS sum_value, region_id, year, quarter,  c_site_customer_country AS country
				,c_market_industry_desc				
					FROM fms_ibas_equipment equip 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(c_unit_status_desc) = UPPER(''InService'')
					AND ibo_type = ''addressable_ibo''
					--AND UPPER(C_PROD_EXC_PL) = ' || '''' || v_b_unit || '''' || '
					GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_value > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id
			AND main.country = subQ.country
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.segment IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc';
			--AND main.business_segment = ' || '''' || v_b_unit || '''' || '';
			
	RAISE NOTICE 'UPDATE TOTAL OF A COUNTRY BASED ON GROUPING ALL SEGMENTS OF THAT COUNTRY %' , v_query;

	EXECUTE v_query;

	--REGION WISE BREAK

	v_query = '
	UPDATE fms_metrics_segment main
		SET ' || v_report || ' = subQ.' || v_report || ' FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.segment, order_by_region.quarter,
		((ROUND((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100) as ' || v_report || '
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, sm_segment_mapping AS segment
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(me_dm_tier_3) LIKE UPPER(''%Opex%'')
					--AND UPPER(n_me_tier_2) = ' || '''' || v_b_unit || '''' || '
					' ||  v_srvc_typ_desc  || '
					GROUP BY region_id, sm_segment_mapping,  year, quarter ,c_market_industry_desc
					ORDER BY region_id, sm_segment_mapping) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(' ||  v_av_value  || ', 0)) AS sum_value, region_id, year, quarter, c_market_segment_desc AS segment
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(c_unit_status_desc) = UPPER(''InService'')
					AND ibo_type = ''addressable_ibo''
					--AND UPPER(C_PROD_EXC_PL) = ' || '''' || v_b_unit || '''' || '
					GROUP BY region_id, c_market_segment_desc, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_market_segment_desc) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.segment = ibr.segment
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_value > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.segment = subQ.segment
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc';
		--	AND main.business_segment = ' || '''' || v_b_unit || '''' || '';
			
	RAISE NOTICE 'REGION WISE BREAK %' , v_query;

	EXECUTE v_query;

	--UPDATE TOTAL OF A REGION BASED ON GROUPING ALL SEGMENTS OF THAT REGION

	v_query = '
	UPDATE fms_metrics_segment main
		SET ' || v_report || ' = subQ.' || v_report || ' FROM
		(SELECT order_by_region.region_id, order_by_region.year,  order_by_region.quarter,
		((ROUND((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100) as ' || v_report || '
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(me_dm_tier_3) LIKE UPPER(''%Opex%'')
					--AND UPPER(n_me_tier_2) = ' || '''' || v_b_unit || '''' || '
					' ||  v_srvc_typ_desc  || '
					GROUP BY region_id, year, quarter ,c_market_industry_desc
					ORDER BY region_id) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(' ||  v_av_value  || ', 0)) AS sum_value, region_id, year, quarter
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(c_unit_status_desc) = UPPER(''InService'')
					AND ibo_type = ''addressable_ibo''
				--	AND UPPER(C_PROD_EXC_PL) = ' || '''' || v_b_unit || '''' || '
					GROUP BY region_id, year, quarter ,c_market_industry_desc
					ORDER BY region_id) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_value > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country = ''TOTAL''
			AND main.segment IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc';
			--AND main.business_segment = ' || '''' || v_b_unit || '''' || '';
			
	RAISE NOTICE 'UPDATE TOTAL OF A REGION BASED ON GROUPING ALL SEGMENTS OF THAT REGION %' , v_query;

	EXECUTE v_query;
	
	--GLOBAL BREAK

	v_query = '
	UPDATE fms_metrics_segment main
		SET ' || v_report || ' = subQ.' || v_report || ' FROM
		(SELECT  order_by_region.year, order_by_region.segment, order_by_region.quarter,
		((ROUND((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100) as ' || v_report || '
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate,  year, quarter, sm_segment_mapping AS segment
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(me_dm_tier_3) LIKE UPPER(''%Opex%'')
					--AND UPPER(n_me_tier_2) = ' || '''' || v_b_unit || '''' || '
					' ||  v_srvc_typ_desc  || '
					GROUP BY  sm_segment_mapping,  year, quarter ,c_market_industry_desc
					ORDER BY  sm_segment_mapping) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(' ||  v_av_value  || ', 0)) AS sum_value,  year, quarter, c_market_segment_desc AS segment
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(c_unit_status_desc) = UPPER(''InService'')
					AND ibo_type = ''addressable_ibo''
					--AND UPPER(C_PROD_EXC_PL) = ' || '''' || v_b_unit || '''' || '
					GROUP BY  c_market_segment_desc, year, quarter ,c_market_industry_desc
					ORDER BY  c_market_segment_desc) as ibr 
				ON 
				order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.segment = ibr.segment
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_value > 0
			)) AS subQ
		WHERE 
			main.segment = subQ.segment
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc';
			--AND main.business_segment = ' || '''' || v_b_unit || '''' || '';
			
	RAISE NOTICE 'GLOBAL BREAK %' , v_query;

	EXECUTE v_query;

	--UPDATE TOTAL OF GLOBAL LEVEL

	v_query = '
	UPDATE fms_metrics_segment main
		SET ' || v_report || ' = subQ.' || v_report || ' FROM
		(SELECT  order_by_region.year,  order_by_region.quarter,
		((ROUND((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100) as ' || v_report || '
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate,  year, quarter
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(me_dm_tier_3) LIKE UPPER(''%Opex%'')
					--AND UPPER(n_me_tier_2) = ' || '''' || v_b_unit || '''' || '
					' ||  v_srvc_typ_desc  || '
					GROUP BY  year, quarter ,c_market_industry_desc
					) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(' ||  v_av_value  || ', 0)) AS sum_value,  year, quarter
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(c_unit_status_desc) = UPPER(''InService'')
					AND ibo_type = ''addressable_ibo''
					--AND UPPER(C_PROD_EXC_PL) = ' || '''' || v_b_unit || '''' || '
					GROUP BY   year, quarter ,c_market_industry_desc
					) as ibr 
				ON 
				order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_value > 0
			)) AS subQ
		WHERE 
			main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country IS NULL
			AND main.segment = ''TOTAL''
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc';
			--AND main.business_segment = ' || '''' || v_b_unit || '''' || '';
			
	RAISE NOTICE 'UPDATE TOTAL OF GLOBAL LEVEL %' , v_query;

	EXECUTE v_query;
	
	END LOOP;

--	v_b_unit = 'DTS';
  
--	END LOOP;			
	
	RETURN 'SUCCESS';
	
	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_calc_pen_metrics_segment_break',
			     v_proc_paras ,
			     sqlerrm,
			     'DATABASE ERROR');		
	--RAISE NOTICE 'SQL ERROR %', sqlerrm;
	RETURN 'DATABASE ERROR';		
	
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
