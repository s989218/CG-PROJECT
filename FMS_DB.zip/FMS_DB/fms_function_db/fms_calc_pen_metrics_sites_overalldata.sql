-- Function: fms_calc_pen_metrics_sites_overalldata()

-- DROP FUNCTION fms_calc_pen_metrics_sites_overalldata();

CREATE OR REPLACE FUNCTION fms_calc_pen_metrics_sites_overalldata()
  RETURNS character varying AS
$BODY$
DECLARE

    v_proc_paras character varying(2500); 
    v_factor numeric;
	
	v_b_unit character varying;	
    
BEGIN

	--DELETE THE ROWS RELATED TO in_year & in_quarter

	DELETE FROM fms_metrics_sites WHERE year is Null AND quarter is Null;

	v_b_unit = '';
	
--	v_b_unit = 'TMS';

--	FOR a IN 1..2 LOOP
	
	Select Count(distinct n_book_year::text || n_book_quarter::text) *0.25::numeric INTO v_factor from fms_service_orders_pm;
--	WHERE UPPER(trim(n_me_tier_2)) = v_b_unit;
	
	--INSERT POSSIBLE ROWS BASED ON THE NUMBER OF SITES & COUNTRIES (EQUIPMENT DATA) 
	
	INSERT INTO fms_metrics_sites(REGION_ID, year, quarter, country,  site_name, ge_duns_name,c_market_industry_desc)
	--, business_segment)
					
	SELECT REGION_ID, Null as year, Null AS quarter, country,  site_name , ge_duns_name, c_market_industry_desc
	--, v_b_unit AS business_segment
	FROM 
	(SELECT DISTINCT region_id,  c_site_customer_country AS country,
		c_site_customer_name AS site_name, ge_duns_name AS  ge_duns_name
		,c_market_industry_desc
		  FROM fms_ibas_equipment
		  WHERE 
		  c_site_customer_name IS NOT NULL
		  AND c_site_customer_country IS NOT NULL
		  AND UPPER(c_unit_status_desc) = UPPER('InService')
		  AND ibo_type = 'addressable_ibo'
		 -- AND UPPER(C_PROD_EXC_PL) = v_b_unit
		  and upper(c_og_sales_region) in (select upper(region) from fms_region)
	) AS sites;

	--INSERT ROWS TO HOLD THE COUNTRY WISE TOTAL VALUES (FOR EACH DISTINCT COUNTRY)

	/* THE TOTAL FOR COUNTRIES ARE REPRESENTED AS country_name_TOTAL (EXAMPLE INDIA_TOTAL) AND THEIR SITE IS NULL */

	INSERT INTO fms_metrics_sites(REGION_ID, year, quarter, country,c_market_industry_desc)
	--, business_segment)

	SELECT REGION_ID, Null as year, Null AS quarter, country ,c_market_industry_desc
	--, v_b_unit AS business_segment
	FROM
	(SELECT DISTINCT c_site_customer_country||'_TOTAL' AS country, REGION_ID
	,c_market_industry_desc
			FROM fms_ibas_equipment 
			WHERE 
			c_site_customer_name IS NOT NULL
			AND c_site_customer_country IS NOT NULL
			AND UPPER(c_unit_status_desc) = UPPER('InService') 
			AND ibo_type = 'addressable_ibo'
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			and upper(c_og_sales_region) in (select upper(region) from fms_region)
	) AS sites_total;

	--INSERT ROWS TO HOLD THE GE_DUNS WISE TOTAL VALUES (FOR EACH DISTINCT COUNTRY)

	/* THE TOTAL FOR GE_DUNS ARE REPRESENTED AS duns_name_TOTAL (EXAMPLE HEFAALYS_TOTAL) AND THEIR SITE IS NULL */

	INSERT INTO fms_metrics_sites(REGION_ID, year, quarter, country,  ge_duns_name,c_market_industry_desc)
	--, business_segment)

	SELECT NULL AS REGION_ID, Null as year, Null AS quarter, NULL AS country,  ge_duns_name,c_market_industry_desc
	--, v_b_unit AS business_segment
	FROM
	(SELECT DISTINCT ge_duns_name||'_TOTAL' as ge_duns_name
	,c_market_industry_desc
			FROM fms_ibas_equipment
			WHERE 
			c_site_customer_name IS NOT NULL
			AND c_site_customer_country IS NOT NULL
			AND UPPER(c_unit_status_desc) = UPPER('InService') 
			AND ibo_type = 'addressable_ibo'
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			and upper(c_og_sales_region) in (select upper(region) from fms_region)
	) AS ge_duns_total;

	--CALORIC INDEX (USES ONLY EQUIPMENT DATA); SITE BREAK AVAILABLE

	--SITE WISE BREAK
	
	UPDATE fms_metrics_sites main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.region_id, (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index
		, IBO_by_Region.country, IBO_by_Region.site_name,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) * v_factor AS count_gis, region_id, 
					c_site_customer_country AS country, c_site_customer_name AS site_name,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE  UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, site_name, c_site_customer_country,c_market_industry_desc
						ORDER BY region_id, site_name, c_site_customer_country) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) * v_factor AS IBO_by_Region, region_id, 
					c_site_customer_country AS country, c_site_customer_name AS site_name,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE  UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, site_name, c_site_customer_country,c_market_industry_desc
						ORDER BY region_id, site_name, c_site_customer_country) AS IBO_by_Region  
					ON
					Count_IBRegion.region_id = IBO_by_Region.region_id 
					AND Count_IBRegion.site_name = IBO_by_Region.site_name 
					AND Count_IBRegion.country = IBO_by_Region.country 
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc 
					AND Count_IBRegion.count_gis>0
			)) as subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.site_name = subQ.site_name 
			AND main.year IS Null
			AND main.quarter IS Null
			AND main.country = subQ.country
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A COUNTRY GROUPING ALL SITES OF THAT COUNTRY

	UPDATE fms_metrics_sites main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.region_id, (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index
		, IBO_by_Region.country||'_TOTAL' as country,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) * v_factor AS count_gis, region_id, 
					c_site_customer_country AS country,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE  UPPER(c_unit_status_desc) = UPPER('InService')
						AND ibo_type = 'addressable_ibo'						
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, c_site_customer_country,c_market_industry_desc
						ORDER BY region_id, c_site_customer_country) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0))* v_factor AS IBO_by_Region, region_id, 
					c_site_customer_country AS country,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE  UPPER(c_unit_status_desc) = UPPER('InService')
						AND ibo_type = 'addressable_ibo'						
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, c_site_customer_country,c_market_industry_desc
						ORDER BY region_id, c_site_customer_country) AS IBO_by_Region 
						 
					ON
					Count_IBRegion.region_id = IBO_by_Region.region_id 
					AND Count_IBRegion.country = IBO_by_Region.country 
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc 
					AND Count_IBRegion.count_gis>0
			)) as subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.site_name IS NULL
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.ge_duns_name IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A GE_DUNS_NAME GROUPING ALL SITES OF THAT GE_DUNS_NAME

	UPDATE fms_metrics_sites main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index
		, IBO_by_Region.ge_duns_name||'_TOTAL' as ge_duns_name,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) * v_factor AS count_gis, 
					ge_duns_name AS ge_duns_name,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE  UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY  ge_duns_name,c_market_industry_desc
						ORDER BY  ge_duns_name) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0))* v_factor AS IBO_by_Region, 
					ge_duns_name AS ge_duns_name,c_market_industry_desc
						FROM fms_ibas_equipment equip
						WHERE  UPPER(c_unit_status_desc) = UPPER('InService')
						AND ibo_type = 'addressable_ibo'						
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY  ge_duns_name,c_market_industry_desc
						ORDER BY  ge_duns_name) AS IBO_by_Region 
						 
					ON
					 Count_IBRegion.ge_duns_name = IBO_by_Region.ge_duns_name 
					 AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc 
					 AND Count_IBRegion.count_gis>0
			)) as subQ
		WHERE 
			 main.ge_duns_name = subQ.ge_duns_name 
			AND main.site_name IS NULL
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
		--	AND main.business_segment = v_b_unit;


	--FLEET COVERAGE (USES ORDERS & EQUIPMENT DATA); SITE BREAK AVAILABLE

	--SITE WISE BREAK

	UPDATE fms_metrics_sites main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.region_id, (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage
		, Order_Count_by_Region.country, Order_Count_by_Region.site_name ,Order_Count_by_Region.c_market_industry_desc
			
			FROM
			(
				(SELECT COUNT(c_project) as prj_count, region_id, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country,
					e_site_cust_name AS site_name
					,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					--WHERE UPPER(n_me_tier_2) = v_b_unit
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY region_id, e_site_cust_name, c_country_name,c_market_industry_desc
					ORDER BY region_id, e_site_cust_name, c_country_name) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number) * 3 * v_factor as count_gis, region_id,  
					c_site_customer_country AS country, c_site_customer_name AS site_name
					,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')	
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit					
					GROUP BY region_id, c_site_customer_name, c_site_customer_country,c_market_industry_desc
					ORDER BY region_id, c_site_customer_name, c_site_customer_country) as Count_IBRegion
				ON 
				Order_Count_by_Region.region_id = Count_IBRegion.region_id 
				AND Order_Count_by_Region.country = Count_IBRegion.country
				AND Order_Count_by_Region.site_name = Count_IBRegion.site_name
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis>0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.site_name = subQ.site_name
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A COUNTRY GROUPING ALL SITES OF THAT COUNTRY

	UPDATE fms_metrics_sites main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.region_id, (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage
		, Order_Count_by_Region.country||'_TOTAL' as country
		,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project) as prj_count, region_id, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 		
					--WHERE UPPER(n_me_tier_2) = v_b_unit					
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY region_id, c_country_name,c_market_industry_desc
					ORDER BY region_id, c_country_name) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number) * 3 * v_factor as count_gis, region_id,  
					c_site_customer_country AS country,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_site_customer_country,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as Count_IBRegion
				ON 
				Order_Count_by_Region.region_id = Count_IBRegion.region_id 
				AND Order_Count_by_Region.country = Count_IBRegion.country
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis>0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country
			AND main.site_name IS NULL
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.ge_duns_name IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A GE_DUNS_NAME GROUPING ALL SITES OF THAT GE_DUNS_NAME

	UPDATE fms_metrics_sites main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT  (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage
		, Order_Count_by_Region.ge_duns_name||'_TOTAL' as ge_duns_name
		,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project) as prj_count, 
					ge_duns_name,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					--WHERE UPPER(n_me_tier_2) = v_b_unit
					GROUP BY  ge_duns_name,c_market_industry_desc
					ORDER BY  ge_duns_name) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number) * 3 * v_factor as count_gis, 
					ge_duns_name ,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY  ge_duns_name,c_market_industry_desc
					ORDER BY  ge_duns_name) as Count_IBRegion
				ON 
				 Order_Count_by_Region.ge_duns_name = Count_IBRegion.ge_duns_name
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis>0
			)) AS subQ
		WHERE 
			 main.ge_duns_name = subQ.ge_duns_name 
			AND main.site_name IS NULL
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
			--AND main.business_segment = v_b_unit;
			
	--FLEET PENETRATION F2F (USES ORDERS & EQUIPMENT DATA); SITE BREAK AVAILABLE

	--SITE WISE BREAK

	UPDATE fms_metrics_sites main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.region_id, CASE d_contract_type when 'CONTRACTUAL' then 100 
			else((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) end AS Fleet_Pen_F2F
			, order_by_region.country, order_by_region.site_name,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) AS order_value_op_rate, region_id, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country,
					e_site_cust_name AS site_name
					,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit
					GROUP BY region_id, e_site_cust_name, c_country_name,c_market_industry_desc
					ORDER BY region_id, e_site_cust_name, c_country_name) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) * v_factor AS sum_avf2f, region_id,d_contract_type, 
					c_site_customer_country AS country, c_site_customer_name AS site_name
					,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
				--	AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY d_contract_type,region_id, c_site_customer_name, c_site_customer_country,c_market_industry_desc
					ORDER BY region_id, c_site_customer_name, c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.country = ibr.country
				AND order_by_region.site_name = ibr.site_name
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.site_name = subQ.site_name
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A COUNTRY GROUPING ALL SITES OF THAT COUNTRY

	UPDATE fms_metrics_sites main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.region_id, ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F
		, order_by_region.country||'_TOTAL' as country
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0))  AS order_value_op_rate, region_id, country
				,c_market_industry_desc
					FROM 
						(SELECT order_by_region.region_id as region_id,  
							Case When d_contract_type = 'CONTRACTUAL' then sum_avf2f * 1000 else order_value_op_rate end as n_order_val_op_rate, 
							order_by_region.country as country, order_by_region.site_name as site_name,order_by_region.c_market_industry_desc
							FROM 
							 (
								(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) AS order_value_op_rate, region_id, 
									(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
									WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
									WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country,
									e_site_cust_name AS site_name,c_market_industry_desc
									FROM fms_service_orders_pm orders 
									WHERE UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
								--	AND UPPER(n_me_tier_2) = v_b_unit
									GROUP BY region_id, e_site_cust_name, c_country_name,c_market_industry_desc
									ORDER BY region_id, e_site_cust_name, c_country_name) AS order_by_region 

								INNER JOIN 
					
								(SELECT SUM(COALESCE(avf2f, 0)) * v_factor AS sum_avf2f, region_id, d_contract_type,
									c_site_customer_country AS country, c_site_customer_name AS site_name
									,c_market_industry_desc
									FROM fms_ibas_equipment equip 
									WHERE UPPER(c_unit_status_desc) = UPPER('InService')
									AND ibo_type = 'addressable_ibo'
									--AND UPPER(C_PROD_EXC_PL) = v_b_unit
									GROUP BY region_id, c_site_customer_name, c_site_customer_country, d_contract_type,c_market_industry_desc
									ORDER BY region_id, c_site_customer_name, c_site_customer_country) as ibr 
								ON 
								order_by_region.region_id = ibr.region_id
								AND order_by_region.country = ibr.country
								AND order_by_region.site_name = ibr.site_name				
								AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
							)
						)as site_data
					GROUP BY region_id, country,c_market_industry_desc 
					ORDER BY region_id, country) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) * v_factor AS sum_avf2f, region_id, 
					c_site_customer_country AS country
					,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_site_customer_country,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.site_name IS NULL
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.ge_duns_name IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
		--	AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A GE_DUNS_NAME GROUPING ALL SITES OF THAT GE_DUNS_NAME

	UPDATE fms_metrics_sites main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F
		, order_by_region.ge_duns_name||'_TOTAL' as ge_duns_name
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0))  AS order_value_op_rate, region_id, ge_duns_name
				,c_market_industry_desc
					FROM 
						(SELECT order_by_region.region_id as region_id, 
							Case When d_contract_type = 'CONTRACTUAL' then sum_avf2f * 1000 else order_value_op_rate end as n_order_val_op_rate, 
							order_by_region.ge_duns_name as ge_duns_name, order_by_region.site_name as site_name
							,order_by_region.c_market_industry_desc
							FROM 
							 (
								(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) AS order_value_op_rate, region_id, ge_duns_name
								, e_site_cust_name AS site_name,c_market_industry_desc
									FROM fms_service_orders_pm orders 
									WHERE UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
									--AND UPPER(n_me_tier_2) = v_b_unit
									GROUP BY region_id, e_site_cust_name, ge_duns_name,c_market_industry_desc
									ORDER BY region_id, e_site_cust_name, ge_duns_name) AS order_by_region 
								INNER JOIN 
					
								(SELECT SUM(COALESCE(avf2f, 0)) * v_factor AS sum_avf2f, region_id, d_contract_type,
									ge_duns_name AS ge_duns_name, c_site_customer_name AS site_name
									,c_market_industry_desc
									FROM fms_ibas_equipment equip 
									WHERE UPPER(c_unit_status_desc) = UPPER('InService')
									AND ibo_type = 'addressable_ibo'
								--	AND UPPER(C_PROD_EXC_PL) = v_b_unit
									GROUP BY region_id, c_site_customer_name, ge_duns_name,d_contract_type,c_market_industry_desc
									ORDER BY region_id, c_site_customer_name, ge_duns_name) as ibr 
								ON 
								order_by_region.region_id = ibr.region_id
								AND order_by_region.ge_duns_name = ibr.ge_duns_name
								AND order_by_region.site_name = ibr.site_name				
								AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc	
							)
						)as site_data
					GROUP BY region_id, ge_duns_name, c_market_industry_desc
					ORDER BY region_id, ge_duns_name) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) * v_factor AS sum_avf2f,  
					ge_duns_name AS ge_duns_name
					,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
				--	AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY  ge_duns_name,c_market_industry_desc
					ORDER BY  ge_duns_name) as ibr 
				ON 
				 order_by_region.ge_duns_name = ibr.ge_duns_name
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			 main.ge_duns_name = subQ.ge_duns_name 
			AND main.site_name IS NULL
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc; 
			--AND main.business_segment = v_b_unit;

	--FLEET PENETRATION (USES ORDERS & EQUIPMENT DATA); SITE BREAK AVAILABLE

	--SITE WISE BREAK

	UPDATE fms_metrics_sites main
		SET fleet_penetration = subQ.Fleet_Penetration FROM
		(SELECT order_by_region.region_id, CASE d_contract_type when 'CONTRACTUAL' then 100 
			else ((ROUND((order_value_op_rate/1000)/ibr.sum_avtot, 2)) * 100) END as Fleet_Penetration, order_by_region.country
			, order_by_region.site_name
			,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) AS order_value_op_rate, region_id, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country,
					e_site_cust_name AS site_name
					,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
				--	AND UPPER(n_me_tier_2) = v_b_unit
					GROUP BY region_id, e_site_cust_name, c_country_name,c_market_industry_desc
					ORDER BY region_id, e_site_cust_name, c_country_name) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(avtot, 0)) * v_factor AS sum_avtot, region_id, d_contract_type,
					c_site_customer_country AS country, c_site_customer_name AS site_name
					,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
				--	AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY d_contract_type,region_id, c_site_customer_name, c_site_customer_country,c_market_industry_desc
					ORDER BY region_id, c_site_customer_name, c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.country = ibr.country
				AND order_by_region.site_name = ibr.site_name
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avtot > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.site_name = subQ.site_name
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
			--AND main.business_segment = v_b_unit; 

	--UPDATE TOTAL OF A COUNTRY GROUPING ALL SITES OF THAT COUNTRY

	UPDATE fms_metrics_sites main
		SET fleet_penetration = subQ.Fleet_Penetration FROM
		(SELECT order_by_region.region_id, ((ROUND((order_value_op_rate/1000)/ibr.sum_avtot, 2)) * 100) as Fleet_Penetration
		, order_by_region.country||'_TOTAL' AS country
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0))  AS order_value_op_rate, region_id, country
				,c_market_industry_desc
					FROM 
						(SELECT order_by_region.region_id as region_id,  
							Case When d_contract_type = 'CONTRACTUAL' then sum_avtot * 1000 else order_value_op_rate end as n_order_val_op_rate, 
							order_by_region.country as country, order_by_region.site_name as site_name
							,order_by_region.c_market_industry_desc
							FROM 
							 (
								(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) AS order_value_op_rate, region_id, 
									(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
									WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
									WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country,
									e_site_cust_name AS site_name
									,c_market_industry_desc
									FROM fms_service_orders_pm orders 
									WHERE UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
							--		AND UPPER(n_me_tier_2) = v_b_unit
									GROUP BY region_id, e_site_cust_name, c_country_name,c_market_industry_desc
									ORDER BY region_id, e_site_cust_name, c_country_name) AS order_by_region 

								INNER JOIN 
					
								(SELECT SUM(COALESCE(avtot, 0)) * v_factor AS sum_avtot, region_id, d_contract_type,
									c_site_customer_country AS country, c_site_customer_name AS site_name
									,c_market_industry_desc
									FROM fms_ibas_equipment equip 
									WHERE UPPER(c_unit_status_desc) = UPPER('InService')
									AND ibo_type = 'addressable_ibo'
							--		AND UPPER(C_PROD_EXC_PL) = v_b_unit
									GROUP BY region_id, c_site_customer_name, c_site_customer_country, d_contract_type,c_market_industry_desc
									ORDER BY region_id, c_site_customer_name, c_site_customer_country) as ibr 
								ON 
								order_by_region.region_id = ibr.region_id
								AND order_by_region.country = ibr.country
								AND order_by_region.site_name = ibr.site_name				
								AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc	
							)
						)as site_data
					GROUP BY region_id, country ,c_market_industry_desc
					ORDER BY region_id, country) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(avtot, 0)) * v_factor AS sum_avtot, region_id, 
					c_site_customer_country AS country,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
				--	AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_site_customer_country,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avtot > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.site_name IS NULL
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.ge_duns_name IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
		--	AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A GE_DUNS_NAME GROUPING ALL SITES OF THAT GE_DUNS_NAME

	UPDATE fms_metrics_sites main
		SET fleet_penetration = subQ.Fleet_Penetration FROM
		(SELECT  ((ROUND((order_value_op_rate/1000)/ibr.sum_avtot, 2)) * 100) as Fleet_Penetration
		, order_by_region.ge_duns_name||'_TOTAL' AS ge_duns_name
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0))  AS order_value_op_rate, region_id, ge_duns_name
				,c_market_industry_desc
					FROM 
						(SELECT order_by_region.region_id as region_id, 
							Case When d_contract_type = 'CONTRACTUAL' then sum_avtot * 1000 else order_value_op_rate end as n_order_val_op_rate, 
							order_by_region.ge_duns_name as ge_duns_name, order_by_region.site_name as site_name
							,order_by_region.c_market_industry_desc
							FROM 
							 (
								(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) AS order_value_op_rate, region_id, ge_duns_name
								, e_site_cust_name AS site_name
								,c_market_industry_desc
									FROM fms_service_orders_pm orders 
									WHERE UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
								--	AND UPPER(n_me_tier_2) = v_b_unit
									GROUP BY region_id, e_site_cust_name, ge_duns_name,c_market_industry_desc
									ORDER BY region_id, e_site_cust_name, ge_duns_name) AS order_by_region 
								INNER JOIN 
					
								(SELECT SUM(COALESCE(avtot, 0)) * v_factor AS sum_avtot, region_id, d_contract_type,
									ge_duns_name AS ge_duns_name, c_site_customer_name AS site_name
									,c_market_industry_desc
									FROM fms_ibas_equipment equip 
									WHERE UPPER(c_unit_status_desc) = UPPER('InService')
									AND ibo_type = 'addressable_ibo'
								--	AND UPPER(C_PROD_EXC_PL) = v_b_unit
									GROUP BY region_id, c_site_customer_name, ge_duns_name,d_contract_type,c_market_industry_desc
									ORDER BY region_id, c_site_customer_name, ge_duns_name) as ibr 
								ON 
								order_by_region.region_id = ibr.region_id
								AND order_by_region.ge_duns_name = ibr.ge_duns_name
								AND order_by_region.site_name = ibr.site_name				
								AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
							)
						)as site_data
					GROUP BY region_id, ge_duns_name,c_market_industry_desc
					ORDER BY region_id, ge_duns_name) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(avtot, 0)) * v_factor AS sum_avtot, 
					ge_duns_name as ge_duns_name
					,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
				--	AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY  ge_duns_name,c_market_industry_desc
					ORDER BY  ge_duns_name) as ibr 
				ON 
				 order_by_region.ge_duns_name = ibr.ge_duns_name
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avtot > 0
			)) AS subQ
		WHERE 
			 main.ge_duns_name = subQ.ge_duns_name 
			AND main.site_name IS NULL
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
		--	AND main.business_segment = v_b_unit;

	--IBO VALUE (EQUIPMENT DATA); SITE BREAK AVAILABLE

	--SITE WISE BREAK

	UPDATE fms_metrics_sites main
		SET ibo_value = subQ.ibo_value FROM
		(SELECT region_id, SUM(COALESCE(avtot,0)) * v_factor AS ibo_value, c_site_customer_country as country, c_site_customer_name AS site_name
		,c_market_industry_desc
			FROM fms_ibas_equipment 
			WHERE UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
		--	AND UPPER(C_PROD_EXC_PL) = v_b_unit
			GROUP BY c_site_customer_name, c_site_customer_country, region_id,c_market_industry_desc
			ORDER BY region_id, c_site_customer_country, c_site_customer_name
		) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.country = subQ.country 
			AND main.site_name = subQ.site_name
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
		--	AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A COUNTRY GROUPING ALL SITES OF THAT COUNTRY

	UPDATE fms_metrics_sites main
		SET ibo_value = subQ.ibo_by_country FROM
		(SELECT region_id, SUM(COALESCE(avtot,0)) * v_factor AS ibo_by_country, c_site_customer_country||'_TOTAL' as country
		,c_market_industry_desc
			FROM fms_ibas_equipment 
			WHERE UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
		--	AND UPPER(C_PROD_EXC_PL) = v_b_unit
			GROUP BY c_site_customer_country, region_id,c_market_industry_desc
			ORDER BY region_id, c_site_customer_country
		) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.site_name IS NULL
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.ge_duns_name IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
		--	AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A GE_DUNS_NAME GROUPING ALL SITES OF THAT GE_DUNS_NAME

	UPDATE fms_metrics_sites main
		SET ibo_value = subQ.ibo_value FROM
		(SELECT  SUM(COALESCE(avtot,0)) * v_factor AS ibo_value, ge_duns_name||'_TOTAL' as ge_duns_name
		,c_market_industry_desc
			FROM fms_ibas_equipment
			WHERE  UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
		--	AND UPPER(C_PROD_EXC_PL) = v_b_unit
			GROUP BY ge_duns_name||'_TOTAL',c_market_industry_desc
			ORDER BY  ge_duns_name||'_TOTAL'
		) AS subQ
		WHERE 
			 main.ge_duns_name = subQ.ge_duns_name 
			AND main.site_name IS NULL
			AND main.year IS Null
			AND main.quarter IS Null			
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc; 
		--	AND main.business_segment = v_b_unit;

--	v_b_unit = 'DTS';
  
--	END LOOP;	

	RETURN 'SUCCESS';
	
	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_calc_pen_metrics_sites_overalldata',
			     v_proc_paras ,
			     sqlerrm,
			     'DATABASE ERROR');		
	--RAISE NOTICE 'SQL ERROR %', sqlerrm;
	RETURN 'DATABASE ERROR';		
	
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
