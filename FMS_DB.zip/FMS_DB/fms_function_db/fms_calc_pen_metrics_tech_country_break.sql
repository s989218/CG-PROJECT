-- Function: fms_calc_pen_metrics_tech_country_break(numeric, character varying)

-- DROP FUNCTION fms_calc_pen_metrics_tech_country_break(numeric, character varying);

CREATE OR REPLACE FUNCTION fms_calc_pen_metrics_tech_country_break(
    in_year numeric,
    in_quarter character varying)
  RETURNS character varying AS
$BODY$
DECLARE

    v_proc_paras character varying(2500); 
    v_iterator numeric;
    v_max_regions numeric;

    v_av_value character varying;
    v_srvc_typ_desc character varying;
    v_report character varying;
    v_query character varying;
	v_b_unit character varying;	
    
BEGIN

	v_proc_paras =  to_char(in_year, '0000') || ' ; ' || 
		in_quarter;

	SELECT TRIM(UPPER(in_quarter)) INTO in_quarter;

	/*

	TECH WISE DATA IS SAVED WITH THE TECH ID POPUPALTED AND TECH_ID 14 IS THE TOTAL OF ALL THE TECHs OF A PARTICULAR COUNTRY/GLOBAL

	REGION WISE TECH DATA IS SAVED WITH THE TECH ID POPUPALTED AND THE TOTAL OF A REGION IS SAVED WITH 'TOTAL' IN THE COUNTRY COLUMN AND THIER RESPECTIVE REGION_IDs

	COUNTRY WISE DATA IS SAVED WITH TECH_IDs AS NULL. THE TOTAL OF A REGION IS SAVED WITHE 'TOTAL' IN THE COUNTRY COLUMN AND THIER RESPECTIVE REGION_IDs

	*/
	
	DELETE FROM fms_metrics_country_tech WHERE year = in_year AND quarter = in_quarter;
	
	--INSERT THE TECH LEVEL POSSIBLE ROWS BASED ON THE NUMBER OF COUNTRIES (EQUIPMENT DATA) & TECHNOLOGY (EXCEPT VARIOUS)
	
	v_b_unit = '';
	
--	v_b_unit = 'TMS';

--	FOR a IN 1..2 LOOP
	
	INSERT INTO fms_metrics_country_tech(REGION_ID, year, tech_id, quarter, country,c_market_industry_desc)
	--, business_segment)
					
	SELECT REGION_ID, in_year AS year, tech_id, 
		in_quarter AS quarter, country ,c_market_industry_desc
		--, v_b_unit AS business_segment
	FROM (
	(SELECT DISTINCT country, REGION_ID,c_market_industry_desc FROM
	
		(SELECT DISTINCT c_site_customer_country AS country, REGION_ID,c_market_industry_desc
		FROM fms_ibas_equipment 
		WHERE c_site_customer_country IS NOT NULL
		AND UPPER(c_unit_status_desc) = UPPER('InService')
		AND ibo_type = 'addressable_ibo'
		--AND UPPER(C_PROD_EXC_PL) = v_b_unit
		and upper(c_og_sales_region) in (select upper(region) from fms_region) 
		) AS inner_country  
				
	) AS country

	CROSS JOIN

	(SELECT tech_id FROM fms_tech WHERE UPPER(tech_desc)  <> 'VARIOUS') AS tech
	
	) AS country_tech ORDER BY country,tech_id;

	--INSERT THE TECH LEVEL POSSIBLE ROWS BASED ON THE NUMBER OF REGIONS (EQUIPMENT DATA) & TECHNOLOGY (EXCEPT VARIOUS & TOTAL)

	INSERT INTO fms_metrics_country_tech(REGION_ID, year, tech_id, quarter, country,c_market_industry_desc)
	--, business_segment)
					
	SELECT REGION_ID, in_year AS year, tech_id, 
		in_quarter AS quarter, NULL AS country ,c_market_industry_desc
		--, v_b_unit AS business_segment
	FROM (
	(SELECT DISTINCT REGION_ID,c_market_industry_desc FROM
	
		(SELECT DISTINCT c_site_customer_country AS country, REGION_ID,c_market_industry_desc
		FROM fms_ibas_equipment 
		WHERE c_site_customer_country IS NOT NULL
		AND UPPER(c_unit_status_desc) = UPPER('InService')
		AND ibo_type = 'addressable_ibo'
		--AND UPPER(C_PROD_EXC_PL) = v_b_unit
		and upper(c_og_sales_region) in (select upper(region) from fms_region) 
		) AS inner_country  
				
	) AS country

	CROSS JOIN

	(SELECT tech_id FROM fms_tech WHERE UPPER(tech_desc)  NOT IN  ('VARIOUS','TOTAL') order by tech_id) AS tech
	
	) AS country_tech ORDER BY country,tech_id;

	--INSERT THE TECH LEVEL POSSIBLE ROWS BASED ON GLOBAL LEVEL (EQUIPMENT DATA) & TECHNOLOGY (EXCEPT VARIOUS)
	
	INSERT INTO fms_metrics_country_tech(REGION_ID, year, tech_id, quarter, country,c_market_industry_desc)
	--, business_segment)
					
	SELECT NULL AS REGION_ID, in_year AS year, tech_id, 
		in_quarter AS quarter, NULL AS country ,c_market_industry_desc
		--, v_b_unit AS business_segment
	FROM (
		(SELECT tech_id FROM fms_tech WHERE UPPER(tech_desc)  <> 'VARIOUS') AS tech
		CROSS JOIN
		(SELECT DISTINCT c_market_industry_desc FROM fms_service_orders_segment_mapping) AS seg
	) AS country_tech ORDER BY country,tech_id;

	--INSERT THE COUNTRY LEVEL POSSIBLE ROWS BASED ON THE NUMBER OF COUNTRIES (EQUIPMENT DATA)

	INSERT INTO fms_metrics_country_tech(REGION_ID, year, tech_id, quarter, country,c_market_industry_desc)
	--, business_segment)
	SELECT REGION_ID, in_year AS year, NULL AS tech_id, 
		in_quarter AS quarter, country ,c_market_industry_desc
		--, v_b_unit AS business_segment
	FROM 
	(SELECT DISTINCT country, REGION_ID,c_market_industry_desc FROM
	(
		SELECT DISTINCT country, REGION_ID,c_market_industry_desc FROM 
		(SELECT DISTINCT c_site_customer_country AS country, REGION_ID,c_market_industry_desc
		FROM fms_ibas_equipment
		WHERE c_site_customer_country IS NOT NULL
		AND UPPER(c_unit_status_desc) = UPPER('InService')
		AND ibo_type = 'addressable_ibo'
		--AND UPPER(C_PROD_EXC_PL) = v_b_unit
		and upper(c_og_sales_region) in (select upper(region) from fms_region) 
		) AS inner_country 
	) AS country ) AS country_region ORDER BY country;

	--INSERT TOTAL FOR COUNTRY LEVEL DATA FOR ALL 7 REGIONS

	v_iterator = 1;

	SELECT COUNT(*) INTO v_max_regions FROM fms_region WHERE UPPER(region) <> 'TOTAL';

	--RAISE NOTICE '%', v_max_regions;

	FOR count in 1..v_max_regions LOOP

	INSERT INTO fms_metrics_country_tech(region_id, year, tech_id, quarter, country,c_market_industry_desc)
	--, business_segment)
	SELECT DISTINCT v_iterator AS region_id,in_year AS year, NULL::numeric AS tech_id, 
		in_quarter AS quarter, 'TOTAL' AS country,c_market_industry_desc FROM fms_service_orders_segment_mapping;
		--, v_b_unit AS business_segment;

	v_iterator = v_iterator + 1;

	END LOOP;
	
	--CALORIC INDEX (USES ONLY EQUIPMENT DATA); COUNTRY & TECHNOLOGY BREAK AVAILABLE

	--TECH WISE BREAK
	
	UPDATE fms_metrics_country_tech main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.region_id, IBO_by_Region.year,IBO_by_Region.tech_id, IBO_by_Region.quarter, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index, IBO_by_Region.country
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) AS count_gis, region_id, year, quarter, tech_id, c_site_customer_country AS country
					,c_market_industry_desc
						FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService')
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit						
						GROUP BY region_id, tech_id,c_site_customer_country, year, quarter,c_market_industry_desc
						ORDER BY region_id, tech_id, c_site_customer_country) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) AS IBO_by_Region, region_id, year, quarter, tech_id, c_site_customer_country AS country
					,c_market_industry_desc
						FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, tech_id,c_site_customer_country, year, quarter ,c_market_industry_desc
						ORDER BY region_id, tech_id, c_site_customer_country) AS IBO_by_Region 
						 
					ON
					Count_IBRegion.region_id = IBO_by_Region.region_id 
					AND Count_IBRegion.tech_id = IBO_by_Region.tech_id 
					AND Count_IBRegion.country = IBO_by_Region.country 
					AND Count_IBRegion.year = IBO_by_Region.year
					AND Count_IBRegion.quarter = IBO_by_Region.quarter
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis>0
			)) as subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.tech_id = subQ.tech_id 
			AND main.country = subQ.country 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A COUNTRY BASED ON GROUPING ALL TECHNOLOGIES OF THAT COUNTRY

	UPDATE fms_metrics_country_tech main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.region_id, IBO_by_Region.year, IBO_by_Region.quarter, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index, IBO_by_Region.country
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) AS count_gis, region_id, year, quarter, c_site_customer_country AS country
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						AND equip.C_TECHNOLOGY_DESC_OG IS NOT NULL
						GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
						ORDER BY region_id, c_site_customer_country) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) AS IBO_by_Region, region_id, year, quarter, c_site_customer_country AS country
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						AND equip.C_TECHNOLOGY_DESC_OG IS NOT NULL
						GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
						ORDER BY region_id, c_site_customer_country) AS IBO_by_Region 
						 
					ON
					Count_IBRegion.region_id = IBO_by_Region.region_id 
					AND Count_IBRegion.country = IBO_by_Region.country 
					AND Count_IBRegion.year = IBO_by_Region.year
					AND Count_IBRegion.quarter = IBO_by_Region.quarter
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis>0
			)) as subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id = 14
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--REGION WISE TECH BREAK
	
	UPDATE fms_metrics_country_tech main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.region_id, IBO_by_Region.year,IBO_by_Region.tech_id, IBO_by_Region.quarter, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) AS count_gis, region_id, year, quarter, tech_id
					,c_market_industry_desc
						FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, tech_id, year, quarter ,c_market_industry_desc
						ORDER BY region_id, tech_id) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) AS IBO_by_Region, region_id, year, quarter, tech_id
					,c_market_industry_desc
						FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, tech_id, year, quarter ,c_market_industry_desc
						ORDER BY region_id, tech_id) AS IBO_by_Region 
						 
					ON
					Count_IBRegion.region_id = IBO_by_Region.region_id 
					AND Count_IBRegion.tech_id = IBO_by_Region.tech_id 
					AND Count_IBRegion.year = IBO_by_Region.year
					AND Count_IBRegion.quarter = IBO_by_Region.quarter
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis >0
			)) as subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.tech_id = subQ.tech_id 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.country IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--GLOBAL TECH BREAK
	
	UPDATE fms_metrics_country_tech main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.year,IBO_by_Region.tech_id, IBO_by_Region.quarter, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) AS count_gis, year, quarter, tech_id
					,c_market_industry_desc
						FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY tech_id, year, quarter ,c_market_industry_desc
						ORDER BY tech_id) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) AS IBO_by_Region, year, quarter, tech_id
					,c_market_industry_desc
						FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY tech_id, year, quarter ,c_market_industry_desc
						ORDER BY tech_id) AS IBO_by_Region 
						 
					ON
					Count_IBRegion.tech_id = IBO_by_Region.tech_id 
					AND Count_IBRegion.year = IBO_by_Region.year
					AND Count_IBRegion.quarter = IBO_by_Region.quarter
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis>0
			)) as subQ
		WHERE 
			main.tech_id = subQ.tech_id 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;
			
	--GLOBAL TECH BREAK TOTAL
	
	UPDATE fms_metrics_country_tech main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.year, IBO_by_Region.quarter, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) AS count_gis, year, quarter
					,c_market_industry_desc
						FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY year, quarter ,c_market_industry_desc
						) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) AS IBO_by_Region, year, quarter
					,c_market_industry_desc
						FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY year, quarter ,c_market_industry_desc
						) AS IBO_by_Region 
						 
					ON
					Count_IBRegion.year = IBO_by_Region.year
					AND Count_IBRegion.quarter = IBO_by_Region.quarter
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis>0
			)) as subQ
		WHERE 
			main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND tech_id = 14
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;
	
	--COUNTRY WISE BREAK
	
	UPDATE fms_metrics_country_tech main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.region_id, IBO_by_Region.year, IBO_by_Region.quarter, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index, IBO_by_Region.country
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) AS count_gis, region_id, year, quarter, c_site_customer_country AS country
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
						ORDER BY region_id, c_site_customer_country) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) AS IBO_by_Region, region_id, year, quarter, c_site_customer_country AS country
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
						ORDER BY region_id, c_site_customer_country) AS IBO_by_Region 					 
					ON
					Count_IBRegion.region_id = IBO_by_Region.region_id 
					AND Count_IBRegion.country = IBO_by_Region.country 
					AND Count_IBRegion.year = IBO_by_Region.year
					AND Count_IBRegion.quarter = IBO_by_Region.quarter
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis>0
			)) as subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A REGION GROUPING ALL COUNTRIES OF THAT REGION

	UPDATE fms_metrics_country_tech main
		SET caloric_index = subQ.Caloric_Index FROM 
		(SELECT IBO_by_Region.region_id, IBO_by_Region.year, IBO_by_Region.quarter, 
		   (ROUND(IBO_by_Region.IBO_by_Region/Count_IBRegion.count_gis, 2)) AS Caloric_Index
		   ,IBO_by_Region.c_market_industry_desc
			FROM 
			(
					(SELECT count(c_gib_serial_number) AS count_gis, region_id, year, quarter
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, year, quarter,c_market_industry_desc 
						ORDER BY region_id) AS Count_IBRegion 
					INNER JOIN
					(SELECT sum(COALESCE(avtot, 0)) AS IBO_by_Region, region_id, year, quarter
					,c_market_industry_desc
						FROM fms_ibas_equipment equip 
						WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
						AND UPPER(c_unit_status_desc) = UPPER('InService') 
						AND ibo_type = 'addressable_ibo'
						--AND UPPER(C_PROD_EXC_PL) = v_b_unit
						GROUP BY region_id, year, quarter ,c_market_industry_desc
						ORDER BY region_id) AS IBO_by_Region 
						 
					ON
					Count_IBRegion.region_id = IBO_by_Region.region_id 
					AND Count_IBRegion.year = IBO_by_Region.year
					AND Count_IBRegion.quarter = IBO_by_Region.quarter
					AND Count_IBRegion.c_market_industry_desc = IBO_by_Region.c_market_industry_desc
					AND Count_IBRegion.count_gis>0
			)) as subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country = 'TOTAL'
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;
	
	--FLEET COVERAGE (USES ORDERS & EQUIPMENT DATA); COUNTRY & TECHNOLOGY BREAK AVAILABLE

	--TECH WISE BREAK

	UPDATE fms_metrics_country_tech main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.region_id, Order_Count_by_Region.year, Order_Count_by_Region.tech_id, Order_Count_by_Region.quarter,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage, Order_Count_by_Region.country
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project)*4 as prj_count, region_id, year, quarter, tech_id, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders INNER JOIN fms_tech tech
						ON tech.tech_desc = orders.pm_product_mapping
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter)
					--AND UPPER(n_me_tier_2) = v_b_unit	
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY region_id, tech_id, c_country_name, year, quarter,c_market_industry_desc 
					ORDER BY region_id, tech_id, c_country_name) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number)*3 as count_gis, region_id, year, quarter, tech_id, c_site_customer_country AS country
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, tech_id,c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, tech_id,c_site_customer_country) as Count_IBRegion
				ON 
				Order_Count_by_Region.region_id = Count_IBRegion.region_id 
				AND Order_Count_by_Region.year = Count_IBRegion.year
				AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
				AND Order_Count_by_Region.tech_id = Count_IBRegion.tech_id
				AND Order_Count_by_Region.country = Count_IBRegion.country
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis>0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.tech_id = subQ.tech_id 
			AND main.country = subQ.country 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL FOR A COUNTRY CLUBBING ALL THE TECHNOLOGIES OF THAT COUNTRY

	UPDATE fms_metrics_country_tech main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.region_id, Order_Count_by_Region.year, Order_Count_by_Region.quarter,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage, Order_Count_by_Region.country
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project)*4 as prj_count, region_id, year, quarter, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter)
					AND orders.pm_product_mapping IS NOT NULL
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit	
					GROUP BY region_id, c_country_name, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_country_name) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number)*3 as count_gis, region_id, year, quarter,  c_site_customer_country AS country
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					AND equip.C_TECHNOLOGY_DESC_OG IS NOT NULL
					GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as Count_IBRegion
				ON 
				Order_Count_by_Region.region_id = Count_IBRegion.region_id 
				AND Order_Count_by_Region.year = Count_IBRegion.year
				AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
				AND Order_Count_by_Region.country = Count_IBRegion.country
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis>0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country = subQ.country 
			AND main.tech_id = 14
			AND main.c_market_industry_desc = subQ.c_market_industry_desc ;
			--AND main.business_segment = v_b_unit;

	--REGION WISE TECH BREAK

	UPDATE fms_metrics_country_tech main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.region_id, Order_Count_by_Region.year, Order_Count_by_Region.tech_id, Order_Count_by_Region.quarter,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project)*4 as prj_count, region_id, year, quarter, tech_id
				,c_market_industry_desc
					FROM fms_service_orders_pm orders INNER JOIN fms_tech tech
						ON tech.tech_desc = orders.pm_product_mapping
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter)
					--AND UPPER(n_me_tier_2) = v_b_unit	
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY region_id, tech_id,  year, quarter,c_market_industry_desc 
					ORDER BY region_id, tech_id) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number)*3 as count_gis, region_id, year, quarter, tech_id
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, tech_id, year, quarter ,c_market_industry_desc
					ORDER BY region_id, tech_id) as Count_IBRegion
				ON 
				Order_Count_by_Region.region_id = Count_IBRegion.region_id 
				AND Order_Count_by_Region.year = Count_IBRegion.year
				AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
				AND Order_Count_by_Region.tech_id = Count_IBRegion.tech_id
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis>0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.tech_id = subQ.tech_id 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.country IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--GLOBAL TECH BREAK

	UPDATE fms_metrics_country_tech main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.year, Order_Count_by_Region.tech_id, Order_Count_by_Region.quarter,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project)*4 as prj_count, year, quarter, tech_id
				,c_market_industry_desc
					FROM fms_service_orders_pm orders INNER JOIN fms_tech tech
						ON tech.tech_desc = orders.pm_product_mapping
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter)
					--AND UPPER(n_me_tier_2) = v_b_unit	
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY tech_id,  year, quarter ,c_market_industry_desc
					ORDER BY tech_id) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number)*3 as count_gis, year, quarter, tech_id
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY tech_id, year, quarter ,c_market_industry_desc
					ORDER BY tech_id) as Count_IBRegion
				ON 
				Order_Count_by_Region.year = Count_IBRegion.year
				AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
				AND Order_Count_by_Region.tech_id = Count_IBRegion.tech_id
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis>0
			)) AS subQ
		WHERE 
			main.tech_id = subQ.tech_id 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;
			
	--GLOBAL TECH BREAK TOTAL

	UPDATE fms_metrics_country_tech main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.year, Order_Count_by_Region.quarter,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project)*4 as prj_count, year, quarter
				,c_market_industry_desc
					FROM fms_service_orders_pm orders INNER JOIN fms_tech tech
						ON tech.tech_desc = orders.pm_product_mapping
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter)
					--AND UPPER(n_me_tier_2) = v_b_unit	
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY year, quarter ,c_market_industry_desc
					) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number)*3 as count_gis, year, quarter
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY year, quarter ,c_market_industry_desc
					) as Count_IBRegion
				ON 
				Order_Count_by_Region.year = Count_IBRegion.year
				AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis>0
			)) AS subQ
		WHERE 
			main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.tech_id = 14
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;
			
	--COUNTRY WISE BREAK

	UPDATE fms_metrics_country_tech main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.region_id, Order_Count_by_Region.year, Order_Count_by_Region.quarter,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage, Order_Count_by_Region.country
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project)*4 as prj_count, region_id, year, quarter, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter)
					--AND UPPER(n_me_tier_2) = v_b_unit	
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY region_id, c_country_name, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_country_name) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number)*3 as count_gis, region_id, year, quarter,  c_site_customer_country AS country
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as Count_IBRegion
				ON 
				Order_Count_by_Region.region_id = Count_IBRegion.region_id 
				AND Order_Count_by_Region.year = Count_IBRegion.year
				AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
				AND Order_Count_by_Region.country = Count_IBRegion.country
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis>0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country = subQ.country 
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A REGION GROUPING ALL COUNTRIES OF THAT REGION

	UPDATE fms_metrics_country_tech main
		SET fleet_coverage = subQ.Fleet_Coverage FROM
		(SELECT Order_Count_by_Region.region_id, Order_Count_by_Region.year, Order_Count_by_Region.quarter,
		 (ROUND((prj_count/count_gis ::float) * 100)) AS Fleet_Coverage
		 ,Order_Count_by_Region.c_market_industry_desc
			FROM
			(
				(SELECT COUNT(c_project)*4 as prj_count, region_id, year, quarter
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter)
					--AND UPPER(n_me_tier_2) = v_b_unit	
					--and UPPER(me_dm_tier_3) like UPPER('%Opex%')
					GROUP BY region_id, year, quarter ,c_market_industry_desc
					ORDER BY region_id) as Order_Count_by_Region 
				INNER JOIN
				(SELECT count(c_gib_serial_number)*3 as count_gis, region_id, year, quarter
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = in_year and UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, year, quarter ,c_market_industry_desc
					ORDER BY region_id) as Count_IBRegion
				ON 
				Order_Count_by_Region.region_id = Count_IBRegion.region_id 
				AND Order_Count_by_Region.year = Count_IBRegion.year
				AND Order_Count_by_Region.quarter = Count_IBRegion.quarter
				AND Order_Count_by_Region.c_market_industry_desc = Count_IBRegion.c_market_industry_desc
				AND count_gis>0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country = 'TOTAL'
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;
			
	--FLEET PENETRATION F2F (USES ORDERS & EQUIPMENT DATA); COUNTRY & TECHNOLOGY BREAK AVAILABLE

	--TECH WISE BREAK

	UPDATE fms_metrics_country_tech main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.tech_id, order_by_region.quarter,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F, order_by_region.country
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, tech_id,
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders INNER JOIN fms_tech tech
						ON tech.tech_desc = orders.pm_product_mapping
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit	
					GROUP BY region_id, tech_id, c_country_name, year, quarter ,c_market_industry_desc
					ORDER BY region_id, tech_id, c_country_name) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) AS sum_avf2f, region_id, year, quarter, tech_id, c_site_customer_country AS country
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, tech_id,c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, tech_id,c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.tech_id = ibr.tech_id
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.tech_id = subQ.tech_id 
			AND main.country = subQ.country 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
		---	AND main.business_segment = v_b_unit;

	--UPDATE TOTAL FOR A COUNTRY CLUBBING ALL THE TECHNOLOGIES OF THAT COUNTRY

	UPDATE fms_metrics_country_tech main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.quarter,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F, order_by_region.country
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter)
					AND orders.pm_product_mapping IS NOT NULL 
					AND UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
				--	AND UPPER(n_me_tier_2) = v_b_unit	
					GROUP BY region_id, c_country_name, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_country_name) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) AS sum_avf2f, region_id, year, quarter, c_site_customer_country AS country
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					AND equip.C_TECHNOLOGY_DESC_OG IS NOT NULL
				--	AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id = 14
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
		--	AND main.business_segment = v_b_unit;

	--REGION WISE TECH BREAK

	UPDATE fms_metrics_country_tech main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.tech_id, order_by_region.quarter,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, tech_id
				,c_market_industry_desc
					FROM fms_service_orders_pm orders INNER JOIN fms_tech tech
						ON tech.tech_desc = orders.pm_product_mapping
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
				--	AND UPPER(n_me_tier_2) = v_b_unit	
					GROUP BY region_id, tech_id,  year, quarter ,c_market_industry_desc
					ORDER BY region_id, tech_id) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) AS sum_avf2f, region_id, year, quarter, tech_id
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
				--	AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, tech_id, year, quarter ,c_market_industry_desc
					ORDER BY region_id, tech_id) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.tech_id = ibr.tech_id
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.tech_id = subQ.tech_id 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.country IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--GLOBAL TECH BREAK

	UPDATE fms_metrics_country_tech main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.year, order_by_region.tech_id, order_by_region.quarter,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, year, quarter, tech_id
				,c_market_industry_desc
					FROM fms_service_orders_pm orders INNER JOIN fms_tech tech
						ON tech.tech_desc = orders.pm_product_mapping
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
				--	AND UPPER(n_me_tier_2) = v_b_unit	
					GROUP BY tech_id,  year, quarter ,c_market_industry_desc
					ORDER BY tech_id) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) AS sum_avf2f, year, quarter, tech_id
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY tech_id, year, quarter ,c_market_industry_desc
					ORDER BY tech_id) as ibr 
				ON 
				order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.tech_id = ibr.tech_id
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.tech_id = subQ.tech_id 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;		
	
	--GLOBAL TECH BREAK TOTAL

	UPDATE fms_metrics_country_tech main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.year, order_by_region.quarter,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, year, quarter
				,c_market_industry_desc
					FROM fms_service_orders_pm orders INNER JOIN fms_tech tech
						ON tech.tech_desc = orders.pm_product_mapping
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
				--	AND UPPER(n_me_tier_2) = v_b_unit	
					GROUP BY year, quarter ,c_market_industry_desc
					) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) AS sum_avf2f, year, quarter
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
				--	AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY year, quarter ,c_market_industry_desc
					) as ibr 
				ON 
				order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.tech_id = 14
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;
	
	--COUNTRY WISE BREAK

	UPDATE fms_metrics_country_tech main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.quarter,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F, order_by_region.country
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, 
					(CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
						WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
						WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
				--	AND UPPER(n_me_tier_2) = v_b_unit	
					GROUP BY region_id, c_country_name, year, quarter,c_market_industry_desc 
					ORDER BY region_id, c_country_name) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) AS sum_avf2f, region_id, year, quarter, c_site_customer_country AS country
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A REGION GROUPING ALL COUNTRIES OF THAT REGION

	UPDATE fms_metrics_country_tech main
		SET fleet_pen_f2f = subQ.Fleet_Pen_F2F FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.quarter,
		 ((Round((order_by_region.order_value_op_rate/1000)/ibr.sum_avf2f, 2)) * 100) AS Fleet_Pen_F2F
		 ,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(me_dm_tier_3) LIKE UPPER('%Opex%')
					--AND UPPER(n_me_tier_2) = v_b_unit	
					GROUP BY region_id, year, quarter ,c_market_industry_desc
					ORDER BY region_id) AS order_by_region 
				INNER JOIN 
			
				(SELECT SUM(COALESCE(avf2f, 0)) AS sum_avf2f, region_id, year, quarter
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter) 
					AND UPPER(c_unit_status_desc) = UPPER('InService')
					AND ibo_type = 'addressable_ibo'
					--AND UPPER(C_PROD_EXC_PL) = v_b_unit
					GROUP BY region_id, year, quarter ,c_market_industry_desc
					ORDER BY region_id) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_avf2f > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id  
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country = 'TOTAL'
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;


	--FLEET PENETRATION (USES ORDERS & EQUIPMENT DATA); COUNTRY & TECHNOLOGY BREAK AVAILABLE


	FOR a IN 1..4 LOOP

		IF a = 1 
                THEN v_av_value = 'avtot';
                                v_srvc_typ_desc = '  ';
                                v_report = 'fleet_penetration';
		ELSIF a = 2
                THEN v_av_value = 'COALESCE(n_avg_parts_value, 0) + COALESCE(avaux, 0)';
                                v_srvc_typ_desc = ' AND UPPER(n_service_type) = UPPER(''Parts'') ';
                                v_report = 'parts_fleet_penetration';
		ELSIF a = 3
                THEN v_av_value = 'n_avg_repair_value';
                                v_srvc_typ_desc = ' AND UPPER(n_service_type) = UPPER(''Repairs'') ';
                                v_report = 'repairs_fleet_penetration';
		ELSIF a = 4
                THEN v_av_value = 'COALESCE(n_avg_svcs_value, 0) + COALESCE(avmanpow, 0)';
                                v_srvc_typ_desc = ' AND UPPER(n_service_type) = UPPER(''Field Services'') ';
                                v_report = 'svcs_fleet_penetration';
		END IF;

	RAISE NOTICE 'a is %', a; 
	RAISE NOTICE 'v_av_value is %', v_av_value;
	RAISE NOTICE 'v_srvc_typ_desc is %', v_srvc_typ_desc;

	--TECH WISE BREAK

	v_query = '
	UPDATE fms_metrics_country_tech main
		SET ' || v_report || ' = subQ.' || v_report || ' FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.tech_id, order_by_region.quarter,
		((ROUND((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100) as ' || v_report || ', order_by_region.country  
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, tech_id,
					(CASE WHEN UPPER(c_country_name) = ''BOLIVIA, PLURINATIONAL STATE OF'' THEN ''BOLIVIA'' 
						WHEN UPPER(c_country_name) = ''LIBYAN ARAB JAMAHIRIYA'' THEN ''LIBYA'' 
						WHEN UPPER(c_country_name) = ''VENEZUELA, BOLIVARIAN REPUBLIC OF'' THEN ''VENEZUELA'' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders INNER JOIN fms_tech tech
						ON tech.tech_desc = orders.pm_product_mapping
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(me_dm_tier_3) LIKE UPPER(''%Opex%'')
					--AND UPPER(n_me_tier_2) = ' || '''' || v_b_unit || '''' || '	
					' ||  v_srvc_typ_desc  || '
					GROUP BY region_id, tech_id, c_country_name, year, quarter ,c_market_industry_desc
					ORDER BY region_id, tech_id, c_country_name) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(' ||  v_av_value  || ', 0)) AS sum_value, region_id, year, quarter, tech_id, c_site_customer_country AS country 
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(c_unit_status_desc) = UPPER(''InService'')
					AND ibo_type = ''addressable_ibo''
					--AND UPPER(C_PROD_EXC_PL) = ' || '''' || v_b_unit || '''' || '
					GROUP BY region_id, tech_id,c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, tech_id,c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.tech_id = ibr.tech_id
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_value > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.tech_id = subQ.tech_id 
			AND main.country = subQ.country 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc';
			--AND main.business_segment = ' || '''' || v_b_unit || '''' || '';
			
	RAISE NOTICE 'TECH WISE BREAK %' , v_query;

	EXECUTE v_query;

	--UPDATE TOTAL FOR A COUNTRY CLUBBING ALL THE TECHNOLOGIES OF THAT COUNTRY

	v_query = '
	UPDATE fms_metrics_country_tech main
		SET ' || v_report || ' = subQ.' || v_report || ' FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.quarter,
		((ROUND((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100) as ' || v_report || ', order_by_region.country  
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, 
					(CASE WHEN UPPER(c_country_name) = ''BOLIVIA, PLURINATIONAL STATE OF'' THEN ''BOLIVIA'' 
						WHEN UPPER(c_country_name) = ''LIBYAN ARAB JAMAHIRIYA'' THEN ''LIBYA'' 
						WHEN UPPER(c_country_name) = ''VENEZUELA, BOLIVARIAN REPUBLIC OF'' THEN ''VENEZUELA'' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND orders.pm_product_mapping IS NOT NULL 
					AND UPPER(me_dm_tier_3) LIKE UPPER(''%Opex%'')
					--AND UPPER(n_me_tier_2) = ' || '''' || v_b_unit || '''' || '	
					' ||  v_srvc_typ_desc  || '
					GROUP BY region_id, c_country_name, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_country_name) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(' ||  v_av_value  || ', 0)) AS sum_value, region_id, year, quarter, c_site_customer_country AS country 
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(c_unit_status_desc) = UPPER(''InService'')
					AND ibo_type = ''addressable_ibo''
					AND equip.C_TECHNOLOGY_DESC_OG IS NOT NULL 
					--AND UPPER(C_PROD_EXC_PL) = ' || '''' || v_b_unit || '''' || '
					GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_value > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id = 14
			AND main.c_market_industry_desc = subQ.c_market_industry_desc';
			--AND main.business_segment = ' || '''' || v_b_unit || '''' || '';
			
	RAISE NOTICE 'UPDATE TOTAL FOR A COUNTRY CLUBBING ALL THE TECHNOLOGIES OF THAT COUNTRY %' , v_query;

	EXECUTE v_query;

	--REGION WISE TECH BREAK

	v_query = '
	UPDATE fms_metrics_country_tech main
		SET ' || v_report || ' = subQ.' || v_report || ' FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.tech_id, order_by_region.quarter,
		((ROUND((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100) as ' || v_report || '
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, tech_id
				,c_market_industry_desc
					FROM fms_service_orders_pm orders INNER JOIN fms_tech tech
						ON tech.tech_desc = orders.pm_product_mapping
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(me_dm_tier_3) LIKE UPPER(''%Opex%'')
					--AND UPPER(n_me_tier_2) = ' || '''' || v_b_unit || '''' || '	
					' ||  v_srvc_typ_desc  || '
					GROUP BY region_id, tech_id,  year, quarter ,c_market_industry_desc
					ORDER BY region_id, tech_id) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(' ||  v_av_value  || ', 0)) AS sum_value, region_id, year, quarter, tech_id
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(c_unit_status_desc) = UPPER(''InService'')
					AND ibo_type = ''addressable_ibo''
					--AND UPPER(C_PROD_EXC_PL) = ' || '''' || v_b_unit || '''' || '
					GROUP BY region_id, tech_id, year, quarter ,c_market_industry_desc
					ORDER BY region_id, tech_id) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.tech_id = ibr.tech_id
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_value > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.tech_id = subQ.tech_id
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.country IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc';
			--AND main.business_segment = ' || '''' || v_b_unit || '''' || '';
			
	RAISE NOTICE 'REGION WISE TECH BREAK %' , v_query;

	EXECUTE v_query;

	--GLOBAL TECH BREAK

	v_query = '
	UPDATE fms_metrics_country_tech main
		SET ' || v_report || ' = subQ.' || v_report || ' FROM
		(SELECT order_by_region.year, order_by_region.tech_id, order_by_region.quarter,
		((ROUND((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100) as ' || v_report || '
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, year, quarter, tech_id
				,c_market_industry_desc
					FROM fms_service_orders_pm orders INNER JOIN fms_tech tech
						ON tech.tech_desc = orders.pm_product_mapping
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(me_dm_tier_3) LIKE UPPER(''%Opex%'')
					--AND UPPER(n_me_tier_2) = ' || '''' || v_b_unit || '''' || '	
					' ||  v_srvc_typ_desc  || '
					GROUP BY tech_id,  year, quarter ,c_market_industry_desc
					ORDER BY tech_id) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(' ||  v_av_value  || ', 0)) AS sum_value, year, quarter, tech_id
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(c_unit_status_desc) = UPPER(''InService'')
					AND ibo_type = ''addressable_ibo''
					--AND UPPER(C_PROD_EXC_PL) = ' || '''' || v_b_unit || '''' || '
					GROUP BY tech_id, year, quarter ,c_market_industry_desc
					ORDER BY tech_id) as ibr 
				ON 
				order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.tech_id = ibr.tech_id
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_value > 0
			)) AS subQ
		WHERE 
			main.tech_id = subQ.tech_id
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc';
			--AND main.business_segment = ' || '''' || v_b_unit || '''' || '';
			
	RAISE NOTICE 'GLOBAL TECH BREAK %' , v_query;

	EXECUTE v_query;
	
	--GLOBAL TECH BREAK TOTAL

	v_query = '
	UPDATE fms_metrics_country_tech main
		SET ' || v_report || ' = subQ.' || v_report || ' FROM
		(SELECT order_by_region.year, order_by_region.quarter,
		((ROUND((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100) as ' || v_report || '
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, year, quarter
				,c_market_industry_desc
					FROM fms_service_orders_pm orders INNER JOIN fms_tech tech
						ON tech.tech_desc = orders.pm_product_mapping
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(me_dm_tier_3) LIKE UPPER(''%Opex%'')
					--AND UPPER(n_me_tier_2) = ' || '''' || v_b_unit || '''' || '	
					' ||  v_srvc_typ_desc  || '
					GROUP BY year, quarter ,c_market_industry_desc
					) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(' ||  v_av_value  || ', 0)) AS sum_value, year, quarter
				,c_market_industry_desc
					FROM fms_ibas_equipment equip INNER JOIN fms_tech tech
						ON tech.tech_desc = equip.C_TECHNOLOGY_DESC_OG
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(c_unit_status_desc) = UPPER(''InService'')
					AND ibo_type = ''addressable_ibo''
					--AND UPPER(C_PROD_EXC_PL) = ' || '''' || v_b_unit || '''' || '
					GROUP BY year, quarter ,c_market_industry_desc
					) as ibr 
				ON 
				order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_value > 0
			)) AS subQ
		WHERE 
			main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NOT NULL
			AND main.country IS NULL
			AND main.region_id IS NULL
			AND main.tech_id = 14
			AND main.c_market_industry_desc = subQ.c_market_industry_desc';
			--AND main.business_segment = ' || '''' || v_b_unit || '''' || '';
			
	RAISE NOTICE 'GLOBAL TECH BREAK TOTAL %' , v_query;

	EXECUTE v_query;
	
	--COUNTRY WISE BREAK

	v_query = '
	UPDATE fms_metrics_country_tech main
		SET ' || v_report || ' = subQ.' || v_report || ' FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.quarter,
		((ROUND((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100) as ' || v_report || ', order_by_region.country
		,order_by_region.c_market_industry_desc		
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter, 
					(CASE WHEN UPPER(c_country_name) = ''BOLIVIA, PLURINATIONAL STATE OF'' THEN ''BOLIVIA'' 
						WHEN UPPER(c_country_name) = ''LIBYAN ARAB JAMAHIRIYA'' THEN ''LIBYA'' 
						WHEN UPPER(c_country_name) = ''VENEZUELA, BOLIVARIAN REPUBLIC OF'' THEN ''VENEZUELA'' ELSE c_country_name END) AS country
						,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(me_dm_tier_3) LIKE UPPER(''%Opex%'')
					--AND UPPER(n_me_tier_2) = ' || '''' || v_b_unit || '''' || '	
					' ||  v_srvc_typ_desc  || '
					GROUP BY region_id, c_country_name, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_country_name) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(' ||  v_av_value  || ', 0)) AS sum_value, region_id, year, quarter, c_site_customer_country AS country 
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(c_unit_status_desc) = UPPER(''InService'')
					AND ibo_type = ''addressable_ibo''
					--AND UPPER(C_PROD_EXC_PL) = ' || '''' || v_b_unit || '''' || '
					GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
					ORDER BY region_id, c_site_customer_country) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.country = ibr.country
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_value > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc';
			--AND main.business_segment = ' || '''' || v_b_unit || '''' || '';
			
	RAISE NOTICE 'COUNTRY WISE BREAK %' , v_query;

	EXECUTE v_query;

	--UPDATE TOTAL OF A REGION GROUPING ALL COUNTRIES OF THAT REGION

	v_query = '
	UPDATE fms_metrics_country_tech main
		SET ' || v_report || ' = subQ.' || v_report || ' FROM
		(SELECT order_by_region.region_id, order_by_region.year, order_by_region.quarter,
		((ROUND((order_value_op_rate/1000)/ibr.sum_value, 2)) * 100) as ' || v_report || '
		,order_by_region.c_market_industry_desc
			FROM 
			(
				(SELECT SUM(COALESCE(n_order_val_op_rate, 0)) * 4  AS order_value_op_rate, region_id, year, quarter
				,c_market_industry_desc
					FROM fms_service_orders_pm orders 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(me_dm_tier_3) LIKE UPPER(''%Opex%'')
					--AND UPPER(n_me_tier_2) = ' || '''' || v_b_unit || '''' || '	
					' ||  v_srvc_typ_desc  || '
					GROUP BY region_id, year, quarter,c_market_industry_desc 
					ORDER BY region_id) AS order_by_region 
				INNER JOIN 
		
				(SELECT sum(COALESCE(' ||  v_av_value  || ', 0)) AS sum_value, region_id, year, quarter
				,c_market_industry_desc
					FROM fms_ibas_equipment equip 
					WHERE year = ' || in_year || ' AND UPPER(quarter) = UPPER(' || '''' || in_quarter || '''' || ') 
					AND UPPER(c_unit_status_desc) = UPPER(''InService'')
					AND ibo_type = ''addressable_ibo''
					--AND UPPER(C_PROD_EXC_PL) = ' || '''' || v_b_unit || '''' || '
					GROUP BY region_id, year, quarter ,c_market_industry_desc
					ORDER BY region_id) as ibr 
				ON 
				order_by_region.region_id = ibr.region_id
				AND order_by_region.year = ibr.year
				AND order_by_region.quarter = ibr.quarter
				AND order_by_region.c_market_industry_desc = ibr.c_market_industry_desc
				AND ibr.sum_value > 0
			)) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country = ''TOTAL''
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc';
			--AND main.business_segment = ' || '''' || v_b_unit || '''' || '';

	RAISE NOTICE 'UPDATE TOTAL OF A REGION GROUPING ALL COUNTRIES OF THAT REGION %' , v_query;

	EXECUTE v_query;

	END LOOP;


	--DOLLAR BY IB (USES SALES & EQUIPMENT DATA); COUNTRY BREAK AVAILABLE
  
	--COUNTRY WISE BREAK

	UPDATE fms_metrics_country_tech main
		SET dollar_by_ib = subQ.dollar_by_ib_val FROM
		(SELECT rev_by_region.region_id, rev_by_region.sales_year, rev_by_region.sales_quarter, 
		(Round((rev_by_region.sum_sales_amt/1000)/ib_by_region.count_gis, 2)) as dollar_by_ib_val, rev_by_region.country
		,rev_by_region.c_market_industry_desc
		FROM
		   (
			(SELECT (SUM(COALESCE(sales_amt_at_op_rate,0)) *4)  AS sum_sales_amt, region_id, year AS sales_year, quarter AS sales_quarter, 
				(CASE WHEN ong_region_countries = 'VIETNAM' THEN 'VIET NAM'
					WHEN ong_region_countries = 'PROVINCE OF CHINA-TAIWAN' THEN 'TAIWAN, PROVINCE OF CHINA'
					WHEN ong_region_countries = 'SLOVAKIA (SLOVAK REPUBLIC)' THEN 'SLOVAKIA'
					WHEN ong_region_countries = 'CROATIA (LOCAL NAME: HRVATSKA)' THEN 'CROATIA' ELSE ong_region_countries END) AS country
					,c_market_industry_desc
					FROM fms_sales_n_cm_countries_pm
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter)
					AND UPPER(TRIM(identifier)) = 'COUNTRY'
					--AND UPPER(business_segment) = v_b_unit
					GROUP BY region_id, ong_region_countries, year, quarter ,c_market_industry_desc
					ORDER BY region_id, ong_region_countries) AS rev_by_region 
			INNER JOIN
			
			(SELECT COUNT(c_gib_serial_number) AS count_gis, region_id, year, quarter, c_site_customer_country AS country  
			,c_market_industry_desc
				FROM fms_ibas_equipment 
				WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter)	
				AND UPPER(c_unit_status_desc) = UPPER('InService')
				AND ibo_type = 'addressable_ibo'
				--AND UPPER(C_PROD_EXC_PL) = v_b_unit
				GROUP BY region_id, c_site_customer_country, year, quarter ,c_market_industry_desc
				ORDER BY region_id, c_site_customer_country ) as ib_by_region

			ON 
			rev_by_region.region_id = ib_by_region.region_id
			AND sales_year = ib_by_region.year
			AND rev_by_region.sales_quarter = ib_by_region.quarter
			AND rev_by_region.country = ib_by_region.country
			AND rev_by_region.c_market_industry_desc = ib_by_region.c_market_industry_desc
			AND ib_by_region.count_gis>0
		  )) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year = subQ.sales_year
			AND main.quarter = subQ.sales_quarter
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A REGION GROUPING ALL COUNTRIES OF THAT REGION

	UPDATE fms_metrics_country_tech main
		SET dollar_by_ib = subQ.dollar_by_ib_val FROM
		(SELECT rev_by_region.region_id, rev_by_region.sales_year, rev_by_region.sales_quarter, 
		(Round((rev_by_region.sum_sales_amt/1000)/ib_by_region.count_gis, 2)) as dollar_by_ib_val
		,rev_by_region.c_market_industry_desc
		FROM
		   (
			(SELECT (SUM(COALESCE(sales_amt_at_op_rate,0)) *4)  AS sum_sales_amt, region_id, year AS sales_year, quarter AS sales_quarter
			,c_market_industry_desc
					FROM fms_sales_n_cm_countries_pm
					WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter)
					AND UPPER(TRIM(identifier)) = 'COUNTRY'
					--AND UPPER(business_segment) = v_b_unit
					GROUP BY region_id, year, quarter ,c_market_industry_desc
					ORDER BY region_id) AS rev_by_region 
			INNER JOIN
			
			(SELECT COUNT(c_gib_serial_number) AS count_gis, region_id, year, quarter
			,c_market_industry_desc
				FROM fms_ibas_equipment 
				WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter)	
				AND UPPER(c_unit_status_desc) = UPPER('InService')
				AND ibo_type = 'addressable_ibo'
				--AND UPPER(C_PROD_EXC_PL) = v_b_unit
				GROUP BY region_id, year, quarter ,c_market_industry_desc
				ORDER BY region_id ) as ib_by_region

			ON 
			rev_by_region.region_id = ib_by_region.region_id
			AND sales_year = ib_by_region.year
			AND rev_by_region.sales_quarter = ib_by_region.quarter
			AND rev_by_region.c_market_industry_desc = ib_by_region.c_market_industry_desc
			AND ib_by_region.count_gis>0
		  )) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year = subQ.sales_year
			AND main.quarter = subQ.sales_quarter
			AND main.country = 'TOTAL'
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;


	--CONVERSION INDEX (USES SALES & EQUIPMENT DATA , DIVISION OF DOLLAR_BY_IB & CALORIC_INDEX) ; COUNTRY BREAK AVAILABLE
  
	--COUNTRY WISE BREAK  &  TOTAL OF A REGION GROUPING ALL COUNTRIES OF THAT REGION

	UPDATE fms_metrics_country_tech main
		SET conversion_index = subQ.conv_index FROM
		(
			SELECT region_id, year, quarter, country,
				ROUND(((dollar_by_ib/CASE WHEN caloric_index = NULL THEN 1
									WHEN caloric_index = 0 THEN 1
									ELSE caloric_index
									END)*100)) AS conv_index
			FROM fms_metrics_country_tech 
			WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter)  
			AND tech_id IS NULL
			--AND UPPER(business_segment) = v_b_unit
			ORDER BY region_id
		) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year = subQ.year
			AND main.country = subQ.country
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NULL;
			--AND main.business_segment = v_b_unit;
			
	--IBO BY COUNTRY (EQUIPMENT DATA); COUNTRY BREAK AVAILABLE
  
	--COUNTRY WISE BREAK

	UPDATE fms_metrics_country_tech main
		SET ibo_value = subQ.ibo_by_country FROM
		(SELECT region_id, year, quarter, SUM(COALESCE(avtot,0)) AS ibo_by_country, c_site_customer_country as country
		,c_market_industry_desc
			FROM fms_ibas_equipment 
			WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter)
			AND UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			GROUP BY c_site_customer_country, region_id, year, quarter ,c_market_industry_desc
			ORDER BY region_id, c_site_customer_country
		) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.country = subQ.country 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;

	--UPDATE TOTAL OF A REGION GROUPING ALL COUNTRIES OF THAT REGION

	UPDATE fms_metrics_country_tech main
		SET ibo_value = subQ.ibo_by_country FROM
		(SELECT region_id, year, quarter, SUM(COALESCE(avtot,0)) AS ibo_by_country 
		,c_market_industry_desc
			FROM fms_ibas_equipment 
			WHERE year = in_year AND UPPER(quarter) = UPPER(in_quarter)
			AND UPPER(c_unit_status_desc) = UPPER('InService')
			AND ibo_type = 'addressable_ibo'
			--AND UPPER(C_PROD_EXC_PL) = v_b_unit
			GROUP BY region_id, year, quarter ,c_market_industry_desc
			ORDER BY region_id
		) AS subQ
		WHERE 
			main.region_id = subQ.region_id 
			AND main.year = subQ.year
			AND main.quarter = subQ.quarter
			AND main.country = 'TOTAL'
			AND main.tech_id IS NULL
			AND main.c_market_industry_desc = subQ.c_market_industry_desc;
			--AND main.business_segment = v_b_unit;
	
--	v_b_unit = 'DTS';
  
--	END LOOP;
	
	RETURN 'SUCCESS';
	
	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_calc_pen_metrics_tech_country_break',
			     v_proc_paras ,
			     sqlerrm,
			     'DATABASE ERROR');		
	--RAISE NOTICE 'SQL ERROR %', sqlerrm;
	RETURN 'DATABASE ERROR';		
	
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
