-- Function: fms_db_logger(character varying, character varying, character varying, character varying)

-- DROP FUNCTION fms_db_logger(character varying, character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION fms_db_logger(in_proc_name character varying, in_proc_paras character varying, in_proc_postgre_err character varying, in_proc_err_msg character varying)
  RETURNS character varying AS
$BODY$
DECLARE
    v_proc_paras  character varying(4000);
BEGIN

Raise notice 'Inside logger ';

INSERT INTO fms_db_log (proc_name , proc_paras, proc_postgre_err, proc_err_msg, proc_log_date)
	VALUES (in_proc_name, in_proc_paras, in_proc_postgre_err, in_proc_err_msg, now());

Raise notice 'Insert Log done';

RETURN in_proc_err_msg;		
	
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
