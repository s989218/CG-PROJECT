-- Function: fms_dm_data_mapping(character varying)

-- DROP FUNCTION fms_dm_data_mapping(character varying);

CREATE OR REPLACE FUNCTION fms_dm_data_mapping(msg character varying)
  RETURNS character varying AS
$BODY$
DECLARE


--success integer :=0;
message character varying := 'success';

BEGIN

--IF msg=message THEN

--business_segment mapping
/*
	UPDATE fms_dm_data_oracle SET business_tier_2 = 'TMS' where business_tier_2 LIKE '%TMS%';
	UPDATE fms_dm_data_oracle SET business_tier_2 = 'TMS' where business_tier_2 LIKE '%Turbomachinery Solutions%';
	UPDATE fms_dm_data_oracle SET business_tier_2 = 'DTS' where business_tier_2 LIKE '%DTS%';
	UPDATE fms_dm_data_oracle SET business_tier_2 = 'DTS' where business_tier_2 LIKE '%DP&S%';
	UPDATE fms_dm_data_oracle SET business_tier_2 = 'DTS' where business_tier_2 LIKE '%Downstream Technology Solutions%';
*/
--market industry mapping

	UPDATE fms_dm_data_oracle SET primary_industry = 
		(CASE WHEN primary_industry IN 
				('Refinery & Petrochemical')
				THEN 'Refinery & Petrochemical'
			WHEN primary_industry IN 
				('Industrial', 'Industrial Power Generation', 'Marine', 'Mining', 'Utility Power Generation')
				THEN 'Industrial'
			WHEN primary_industry IN 
				('Conventional hydrocarbons', 'Unconventional hydrocarbons', 'Upstream Onshore', 'Upstream Offshore', 'Onshore/Offshore Production')
				THEN 'Onshore/Offshore Production'
			END);

--To update ge_duns_name & technology description in DM table

	UPDATE fms_dm_data_oracle main SET ge_duns_name = cbn.ge_duns_name, technology_desc = cbn.C_TECHNOLOGY_DESC_OG
	from
		(
		SELECT equip.ge_duns_name,  dm.END_USER_ACCOUNT_NAME, equip.C_TECHNOLOGY_DESC_OG FROM 
			(SELECT ge_duns_name, c_site_customer_name, C_TECHNOLOGY_DESC_OG FROM fms_ibas_equipment) AS equip
			INNER JOIN 
			(SELECT DISTINCT END_USER_ACCOUNT_NAME FROM fms_dm_data_oracle) AS dm
		ON dm.END_USER_ACCOUNT_NAME = equip.c_site_customer_name
		) cbn
	where main.END_USER_ACCOUNT_NAME = cbn.END_USER_ACCOUNT_NAME;

--END IF;

	--success:=1;
	RETURN 'SUCCESS';

	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_dm_data_mapping',
			     msg ,
			     sqlerrm,
			     'DATABASE ERROR');	
	--RAISE NOTICE 'SQL ERROR %', sqlerrm;
	--success:=0;
	RETURN 'DATABASE ERROR';

END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
