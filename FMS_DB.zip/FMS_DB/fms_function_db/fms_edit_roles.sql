-- Function: fms_edit_roles(character varying, character varying, character varying, character varying, numeric)

-- DROP FUNCTION fms_edit_roles(character varying, character varying, character varying, character varying, numeric);

CREATE OR REPLACE FUNCTION fms_edit_roles(
    v_role_name character varying,
    v_role_name_desc character varying,
    v_active character varying,
    v_updated_by character varying,
    v_role_id numeric)
  RETURNS character varying AS
$BODY$
DECLARE

role_name_exist integer:= 0;
role_id_exist integer:= 0;

BEGIN

select role_id into role_id_exist from fms_roles where upper(role_name) = upper(v_role_name);
select count(role_name) into role_name_exist from fms_roles where upper(role_name) = upper(v_role_name);

if (role_id_exist = v_role_id) then
update fms_roles set (role_name_desc,active,updated_by,last_update_date) = (v_role_name_desc,v_active,v_updated_by,now()::timestamp) where role_id = v_role_id;
update fms_user_role set (active,updated_by,update_date) = (v_active,v_updated_by,now()::timestamp) where role_id = v_role_id;
RETURN 'SUCCESS';

elsif (role_name_exist = 0) then 
update fms_roles set (role_name,role_name_desc,active,updated_by,last_update_date) = (v_role_name,v_role_name_desc,v_active,v_updated_by,now()::timestamp) where role_id = v_role_id;
update fms_user_role set (active,updated_by,update_date) = (v_active,v_updated_by,now()::timestamp) where role_id = v_role_id;
RETURN 'SUCCESS';

else 
RETURN 'FAILURE';

end if;

	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_edit_roles',
			     msg ,
			     sqlerrm,
			     'DATABASE ERROR');	
	--RAISE NOTICE 'SQL ERROR %', sqlerrm;
	RETURN 'DATABASE ERROR';

END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
