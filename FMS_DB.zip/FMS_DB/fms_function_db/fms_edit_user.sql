-- Function: fms_edit_user(character varying, character varying, character varying, character varying, character varying, character varying, character varying, numeric)

-- DROP FUNCTION fms_edit_user(character varying, character varying, character varying, character varying, character varying, character varying, character varying, numeric);

CREATE OR REPLACE FUNCTION fms_edit_user(
    sso character varying,
    firstname character varying,
    lastname character varying,
    email character varying,
    activestatus character varying,
    dummydata character varying,
    updatedby character varying,
    role numeric)
  RETURNS character varying AS
$BODY$ 
DECLARE
--success integer :=0;

BEGIN

UPDATE fms_user_role set( role_id, updated_by, update_date, active) = (role, updatedBy, now()::timestamp,activestatus) where user_id = sso;
  
  UPDATE fms_user set(first_name, last_name, email_id, active, updated_by, updated_date) = (firstName, lastName, email, activeStatus, updatedBy, now()::timestamp) where user_id = sso;

--success:=1;
return 'SUCCESS';

EXCEPTION WHEN OTHERS THEN 
  
PERFORM fms_db_logger('fms_edit_user',sso ||'~'||firstName ||'~'||lastName ||'~'||email ||'~'||active ||'~'|| updatedBy ||'~'||role,sqlerrm,'DATABASE ERROR');
--success:=0;
return 'DATABASE ERROR';


END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
