-- Function: fms_fuzzy_match(character varying, numeric, numeric)

-- DROP FUNCTION fms_fuzzy_match(character varying, numeric, numeric);

CREATE OR REPLACE FUNCTION fms_fuzzy_match(
    keyfunc character varying,
    in_year numeric,
    in_quarter numeric)
  RETURNS character varying AS
$BODY$
DECLARE
    v_proc_paras  character varying(2500); 
    v_sql  character varying(5000); 
    v_UpdateTable character varying(2500); 
	v_column_name character varying(2500); 
	v_column_name_2 character varying(2500); 
    v_year  character varying(30); 
    v_quarter  character varying(30); 
    v_b_unit character varying;

BEGIN

--RAISE notice 'B4 SELECT';

v_proc_paras =  keyfunc  || ' ; ' || to_char(in_year, '0000') || ' ; ' || in_quarter;

		
IF UPPER(keyfunc) = 'ORDERS' then

	UPDATE fms_service_orders_pm SET e_site_cust_name = NULL, match_per = NULL WHERE n_book_year = in_year and n_book_quarter = in_quarter;

	--1.	End User Duns matched to Site Customer Duns for an exact match 

	UPDATE fms_service_orders_pm ORD
	SET e_site_cust_name = subquery.keyfield_2,
	    match_per = 100 -- ,
-- 		c_market_industry_desc = subquery.c_market_industry_desc
	 FROM ( SELECT  Distinct c_end_user_duns_code as keyfield_1, c_site_customer_name as keyfield_2, c_country_name as country, c_og_region_name as region, n_book_year as year, n_book_quarter as quarter
	 --,equip.c_market_industry_desc AS c_market_industry_desc
	 --, n_me_tier_2 as business_segment
			from fms_service_orders_pm , fms_ibas_equipment equip
			where UPPER(c_end_user_duns_code) = UPPER(equip.c_site_customer_duns) and n_book_year = in_year and n_book_quarter = in_quarter
	     )subquery
	WHERE UPPER(ORD.c_end_user_duns_code) = UPPER(subquery.keyfield_1) and UPPER(ORD.c_country_name) =  UPPER(subquery.country) 
	and UPPER(ORD.c_og_region_name) = UPPER(subquery.region) 
	--and UPPER(ORD.n_me_tier_2) =  UPPER(subquery.business_segment) 
	and ORD.n_book_year = subquery.year and ORD.n_book_quarter = subquery.quarter;



	--2.	End User name matched to Site customer name for an exact match.


	UPDATE fms_service_orders_pm ORD
	SET e_site_cust_name = subquery.keyfield_2,
	    match_per = 100 -- ,
-- 		c_market_industry_desc = subquery.c_market_industry_desc
	 FROM ( SELECT  Distinct c_end_user_name as keyfield_1, c_site_customer_name as keyfield_2, c_country_name as country, c_og_region_name as region, n_book_year as year, n_book_quarter as quarter
	 --,equip.c_market_industry_desc AS c_market_industry_desc
		--, n_me_tier_2 as business_segment
		from fms_service_orders_pm , fms_ibas_equipment equip
		where UPPER(c_end_user_name) = UPPER(equip.c_site_customer_name) and n_book_year = in_year and n_book_quarter = in_quarter
	     )subquery
	WHERE UPPER(ORD.c_end_user_name) = UPPER(subquery.keyfield_1) and UPPER(ORD.c_country_name) =  UPPER(subquery.country) 
	and UPPER(ORD.c_og_region_name) = UPPER(subquery.region) 
	--and UPPER(ORD.n_me_tier_2) =  UPPER(subquery.business_segment)
	and ORD.n_book_year = subquery.year and ORD.n_book_quarter = subquery.quarter and COALESCE(match_per, 0) = 0;



	--3. With the remaining 50% of the Data, the End User Name + Country + Region is matched to Site Customer Name + Country + Region 
	
	v_b_unit = '';
	
--	v_b_unit = 'TMS';

--	FOR a IN 1..2 LOOP	
	
	UPDATE fms_service_orders_pm ORD
	SET match_per = subquery.sim_score,
	    e_site_cust_name = subquery.keyfield_2 -- ,
-- 		c_market_industry_desc = subquery.c_market_industry_desc
	 FROM
	(Select keyfield_1, keyfield_2, country, region, year, quarter, sim_score,c_market_industry_desc
	from
		(Select keyfield_1, keyfield_2, country, region, sim_score, year, quarter,c_market_industry_desc
		, Row_Number() over (PARTITION BY keyfield_1 order by sim_score desc) as RowNumber
			from
			 (
				Select Distinct c_end_user_name as keyfield_1, equip.c_site_customer_name as keyfield_2, c_country_name as country, c_og_region_name as region, n_book_year as year, n_book_quarter as quarter, Round(Similarity(equip.c_site_customer_name, c_end_user_name) *100) As sim_score
				,ord.c_market_industry_desc AS c_market_industry_desc
				from fms_ibas_equipment equip 
				JOIN fms_service_orders_pm ord ON equip.c_site_customer_name <> c_end_user_name 
				--AND equip.c_site_customer_name % c_end_user_name
				--and Similarity(equip.c_site_customer_name, c_end_user_name) >0.50
				where n_book_year = in_year and n_book_quarter = in_quarter 
				and UPPER(c_site_customer_country) = UPPER((CASE WHEN UPPER(c_country_name) = 'BOLIVIA, PLURINATIONAL STATE OF' THEN 'BOLIVIA' 
										 WHEN UPPER(c_country_name) = 'LIBYAN ARAB JAMAHIRIYA' THEN 'LIBYA' 
										 WHEN UPPER(c_country_name) = 'VENEZUELA, BOLIVARIAN REPUBLIC OF' THEN 'VENEZUELA' ELSE c_country_name END)) 
				and UPPER(c_og_sales_region) = UPPER(c_og_region_name)
				and UPPER(equip.c_market_industry_desc) = UPPER(ord.c_market_industry_desc)
				and COALESCE(match_per, 0) = 0 
				--AND ord.n_me_tier_2 = v_b_unit AND equip.C_PROD_EXC_PL = v_b_unit
				order by keyfield_1, sim_score desc
			 )as t
		) as q
	where RowNumber = 1) subquery
	Where UPPER(ORD.c_end_user_name) = UPPER(subquery.keyfield_1) and UPPER(ORD.c_country_name) =  UPPER(subquery.country) 
	and UPPER(ORD.c_og_region_name) = UPPER(subquery.region) 
	and ORD.c_market_industry_desc = subquery.c_market_industry_desc
	--and UPPER(ORD.n_me_tier_2) =  UPPER(v_b_unit) 
	and ORD.n_book_year = subquery.year and ORD.n_book_quarter = subquery.quarter;

--	v_b_unit = 'DTS';
  
--	END LOOP;
	
RETURN ('SUCCESS');

----******-----
ELSIF UPPER(keyfunc) = 'DM' THEN

v_UpdateTable = 'fms_dm_data_oracle';
v_column_name = 'business_tier_2';
v_column_name_2 = 'primary_industry';

RAISE NOTICE 'in_year %', in_year;

IF in_year is NULL THEN
	v_year = 'expected_order_year';
ELSE 
	v_year = in_year;
END IF;

RAISE NOTICE 'in_quarter %', in_quarter;

IF in_quarter is NULL THEN
	v_quarter = 'expected_order_quarter';
ELSE 
	v_quarter = in_quarter;
END IF;

RAISE NOTICE '1';

v_sql = 'UPDATE ' || v_UpdateTable || ' SET site_cust_name = NULL, match_per = NULL WHERE expected_order_year = ' || v_year || ' and expected_order_quarter = ' || v_quarter;

RAISE NOTICE 'update_sql %', v_sql;
EXECUTE v_sql;
	--1.	End User Duns matched to Site Customer Duns for an exact match 

	v_sql = 'UPDATE ' || v_UpdateTable || ' updtab  
			 SET site_cust_name = subquery.keyfield_2, match_per = 100
			 FROM 
				( SELECT  Distinct end_user_account_duns as keyfield_1, c_site_customer_name as keyfield_2, primary_country as country, primary_region as region,     	expected_order_year as year, expected_order_quarter as quarter
				--, ' || v_column_name || ' AS business_segment 
				, ' || v_column_name_2 || ' AS c_market_industry_desc 
				from ' || v_UpdateTable || '  , fms_ibas_equipment equip
				where UPPER(end_user_account_duns) = UPPER(equip.c_site_customer_duns) and expected_order_year = ' || v_year || ' and expected_order_quarter = ' || v_quarter ||' 
				)subquery
			WHERE UPPER(updtab.end_user_account_duns) = UPPER(subquery.keyfield_1) and UPPER(updtab.primary_country) =  UPPER(subquery.country) and UPPER(updtab.primary_region) = UPPER(subquery.region) 
			--and UPPER(' || v_column_name || ') =  UPPER(subquery.business_segment) 
			and UPPER(' || v_column_name_2 || ') =  UPPER(subquery.c_market_industry_desc) 
			--and updtab.expected_order_year = subquery.year and updtab.expected_order_quarter = subquery.quarter';

RAISE NOTICE 'update_sql %', v_sql;
EXECUTE v_sql;

	--2.	End User name matched to Site customer name for an exact match.	

	v_sql = 'UPDATE ' || v_UpdateTable || ' updtab  
			SET site_cust_name = subquery.keyfield_2,  match_per = 100
			FROM ( SELECT  Distinct end_user_account_name as keyfield_1, c_site_customer_name as keyfield_2, primary_country as country, 
					primary_region as region, 			expected_order_year as year,	expected_order_quarter as quarter
					--, ' || v_column_name || ' AS business_segment 
					, ' || v_column_name_2 || ' AS c_market_industry_desc 
					from  ' || v_UpdateTable || '   , fms_ibas_equipment equip
					where UPPER(end_user_account_name) = UPPER(equip.c_site_customer_name) and expected_order_year = ' || v_year || ' and expected_order_quarter = ' || v_quarter ||
				' )subquery
			WHERE UPPER(updtab.end_user_account_name) = UPPER(subquery.keyfield_1) and UPPER(updtab.primary_country) =  UPPER(subquery.country) and UPPER(updtab.primary_region) = UPPER(subquery.region) 
			--and UPPER(' || v_column_name || ') =  UPPER(subquery.business_segment) 
			and UPPER(' || v_column_name_2 || ') =  UPPER(subquery.c_market_industry_desc) 
			--and updtab.expected_order_year = subquery.year and updtab.expected_order_quarter = subquery.quarter 
			and COALESCE(match_per, 0) = 0';

RAISE NOTICE 'update_sql %', v_sql;
EXECUTE v_sql;

	--3. With the remaining 50% of the Data, the End User Name + Country + Region is matched to Site Customer Name + Country + Region 
	
	v_b_unit = '';
	
--	v_b_unit = 'TMS';

--	FOR a IN 1..2 LOOP	
	
	v_sql = 'UPDATE ' || v_UpdateTable || ' updtab 
			 SET match_per = subquery.sim_score, site_cust_name = subquery.keyfield_2
			 FROM
				(Select keyfield_1, keyfield_2, country, region, year, quarter, sim_score,c_market_industry_desc
					from
						(Select keyfield_1, keyfield_2, country, region, sim_score, year, quarter, c_market_industry_desc,Row_Number() over (PARTITION BY keyfield_1 order by sim_score desc) as RowNumber
						from
							(
								Select Distinct end_user_account_name as keyfield_1, equip.c_site_customer_name as keyfield_2, primary_country as country, primary_region as region, expected_order_year as year, expected_order_quarter as quarter, Round(Similarity(equip.c_site_customer_name, end_user_account_name) *100) As sim_score
								,equip.c_market_industry_desc
								from fms_ibas_equipment equip 
								JOIN ' || v_UpdateTable || '  ON equip.c_site_customer_name <> end_user_account_name 
								--AND equip.c_site_customer_name % c_end_user_name
								--and Similarity(equip.c_site_customer_name, c_end_user_name) >0.50
								where expected_order_year = ' || v_year || ' and expected_order_quarter = ' || v_quarter || ' 
								and UPPER(c_site_customer_country) = UPPER((CASE WHEN UPPER(primary_country) = ''BOLIVIA, PLURINATIONAL STATE OF'' THEN ''BOLIVIA'' 
										 WHEN UPPER(primary_country) = ''LIBYAN ARAB JAMAHIRIYA'' THEN ''LIBYA'' 
										 WHEN UPPER(primary_country) = ''VENEZUELA, BOLIVARIAN REPUBLIC OF'' THEN ''VENEZUELA'' ELSE primary_country END)) 
								and COALESCE(match_per, 0) = 0 
								and UPPER(' || v_column_name_2 || ') =  UPPER(equip.c_market_industry_desc)
								--AND ' || v_column_name || ' = ' || '''' || v_b_unit || '''' || ' 
								--AND equip.C_PROD_EXC_PL = ' || '''' || v_b_unit || '''' || '
								order by keyfield_1, sim_score desc
							)as t
						) as q
				where RowNumber = 1) subquery
			Where UPPER(updtab.end_user_account_name) = UPPER(subquery.keyfield_1) and UPPER(updtab.primary_country) =  UPPER(subquery.country) and UPPER(updtab.primary_region) = UPPER(subquery.region) 

			and UPPER(' || v_column_name_2 || ') =  UPPER(c_market_industry_desc)
			--and UPPER(' || v_column_name || ') =  UPPER(' || '''' || v_b_unit || '''' || ')			
			--and updtab.expected_order_year = subquery.year and updtab.expected_order_quarter = subquery.quarter';

RAISE NOTICE 'update_sql %', v_sql;
EXECUTE v_sql;
	
--	v_b_unit = 'DTS';
  
--	END LOOP;

RETURN ('SUCCESS');
END IF;



    
	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_fuzzy_match',
			     v_proc_paras ,
			     sqlerrm,
			     'DATABASE ERROR');	
	--RAISE NOTICE 'SQL ERROR %', sqlerrm;
	RETURN 'DATABASE ERROR';		
	
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;

  