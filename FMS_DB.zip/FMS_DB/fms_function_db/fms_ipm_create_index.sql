-- Function: fms_ipm_create_index(character varying, character varying)

-- DROP FUNCTION fms_ipm_create_index(character varying, character varying);

CREATE OR REPLACE FUNCTION fms_ipm_create_index(
    in_table_name character varying,
    in_index character varying)
  RETURNS character varying AS
$BODY$   
DECLARE
v_index_sql character varying;

BEGIN

IF UPPER(in_table_name) = 'FMS_IPM_PARTS_EDIT_FIELDS' or UPPER(in_index) = 'ALL' then

  DROP INDEX IF EXISTS ipm_p_cocatenate_idx;

  v_index_sql = 'CREATE INDEX ipm_p_cocatenate_idx
      ON fms_ipm_parts_edit_fields 
       USING btree
      (p_concatenate COLLATE pg_catalog."default")'; 

  raise notice '%', v_index_sql;
  execute v_index_sql;

  if UPPER(in_index) <> 'ALL' then
    RETURN ('SUCCESS');
  end if;  
end if;

IF UPPER(in_index) = UPPER('ipm_cocatenate_idx') or UPPER(in_index) = 'ALL' then
  DROP INDEX IF EXISTS ipm_cocatenate_idx;

  v_index_sql = 'CREATE INDEX ipm_cocatenate_idx
      ON ' || in_table_name || 
      ' USING btree
      (concatenate COLLATE pg_catalog."default")'; 

  raise notice '%', v_index_sql;
  execute v_index_sql;

  if UPPER(in_index) <> 'ALL' then
    RETURN ('SUCCESS');  
  end if;    
end if;


IF UPPER(in_index) = UPPER('ipm_sales_date_year_qtr_idx') or UPPER(in_index) = 'ALL' then
  DROP INDEX IF EXISTS ipm_sales_date_year_qtr_idx;

  v_index_sql = 'CREATE INDEX ipm_sales_date_year_qtr_idx
      ON ' || in_table_name || 
      ' USING btree
      (sales_date_year_qtr COLLATE pg_catalog."default")'; 

  raise notice '%', v_index_sql;
  execute v_index_sql;

  if UPPER(in_index) <> 'ALL' then
    RETURN ('SUCCESS');  
  end if;    
end if;

DROP INDEX IF EXISTS ipm_unique_id_idx;

v_index_sql = 'CREATE INDEX ipm_unique_id_idx
    ON ' || in_table_name || 
    ' USING btree
     (ipm_unique_id)'; 

raise notice '%', v_index_sql;
execute v_index_sql;

DROP INDEX IF EXISTS ipm_project_manager_idx;

v_index_sql = 'CREATE INDEX ipm_project_manager_idx
    ON ' || in_table_name || 
    ' USING btree
    (project_manager COLLATE pg_catalog."default")'; 

raise notice '%', v_index_sql;
execute v_index_sql;


DROP INDEX IF EXISTS ipm_p_and_l_idx;

v_index_sql = 'CREATE INDEX ipm_p_and_l_idx
    ON ' || in_table_name || 
    ' USING btree
    (p_and_l COLLATE pg_catalog."default")'; 

raise notice '%', v_index_sql;
execute v_index_sql;


DROP INDEX IF EXISTS ipm_new_p_and_l_idx;

v_index_sql = 'CREATE INDEX ipm_new_p_and_l_idx
    ON ' || in_table_name || 
    ' USING btree
    (new_p_and_l COLLATE pg_catalog."default")'; 

raise notice '%', v_index_sql;
execute v_index_sql;




DROP INDEX IF EXISTS ipm_product_idx;

v_index_sql = 'CREATE INDEX ipm_product_idx
    ON ' || in_table_name || 
    ' USING btree
    (product COLLATE pg_catalog."default")'; 

raise notice '%', v_index_sql;
execute v_index_sql;


DROP INDEX IF EXISTS ipm_ou_name_idx;

v_index_sql = 'CREATE INDEX ipm_ou_name_idx
    ON ' || in_table_name || 
    ' USING btree
    (ou_name COLLATE pg_catalog."default")'; 

raise notice '%', v_index_sql;
execute v_index_sql;


DROP INDEX IF EXISTS ipm_og_region_idx;

v_index_sql = 'CREATE INDEX ipm_og_region_idx
    ON ' || in_table_name || 
    ' USING btree
    (og_region COLLATE pg_catalog."default")'; 

raise notice '%', v_index_sql;
execute v_index_sql;

DROP INDEX IF EXISTS ipm_subregion_idx;

v_index_sql = 'CREATE INDEX ipm_subregion_idx
    ON ' || in_table_name || 
    ' USING btree
    (subregion COLLATE pg_catalog."default")'; 

raise notice '%', v_index_sql;
execute v_index_sql;


DROP INDEX IF EXISTS ipm_end_user_country_disc_idx;

v_index_sql = 'CREATE INDEX ipm_end_user_country_disc_idx
    ON ' || in_table_name || 
    ' USING btree
    (end_user_country_disc COLLATE pg_catalog."default")'; 

raise notice '%', v_index_sql;
execute v_index_sql;

   

DROP INDEX IF EXISTS ipm_mother_job_idx;

v_index_sql = 'CREATE INDEX ipm_mother_job_idx
    ON ' || in_table_name || 
    ' USING btree
    (mother_job COLLATE pg_catalog."default")'; 
    

DROP INDEX IF EXISTS ipm_enduser_cust_name_idx;

v_index_sql = 'CREATE INDEX ipm_enduser_cust_name_idx
    ON ' || in_table_name || 
    ' USING btree
    (enduser_cust_name COLLATE pg_catalog."default")'; 
 

DROP INDEX IF EXISTS ipm_costing_project_idx;

v_index_sql = 'CREATE INDEX ipm_costing_project_idx
    ON ' || in_table_name || 
    ' USING btree
    (costing_project COLLATE pg_catalog."default")'; 
    
  
DROP INDEX IF EXISTS ipm_order_type_idx;

v_index_sql = 'CREATE INDEX ipm_order_type_idx
    ON ' || in_table_name || 
    ' USING btree
    (order_type COLLATE pg_catalog."default")'; 
    
      
RETURN ('SUCCESS');
    
  EXCEPTION WHEN OTHERS THEN 
  --ROLLBACK; 
  PERFORM fms_db_logger('fms_ipm_create_index',
           '' ,
           sqlerrm,
           'DATABASE ERROR');    
  --RAISE NOTICE 'SQL ERROR %', sqlerrm;
  RETURN 'DATABASE ERROR';    
  
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
