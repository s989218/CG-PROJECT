-- Function: fms_ipm_dataentry_daily_update()

-- DROP FUNCTION fms_ipm_dataentry_daily_update();

CREATE OR REPLACE FUNCTION fms_ipm_dataentry_daily_update()
  RETURNS character varying AS
$BODY$
DECLARE

	v_current_week CHARACTER VARYING;
BEGIN
--select (extract (week from current_timestamp))::character varying;
  create or replace temp view parts_data_v as 
	select COALESCE(parts.p_cm_dollar_by_1000, 0) as p_cm_dollar_by_1000, parts.p_r_by_o, master.p_and_l, master.new_p_and_l,
		master.project_type, master.invoice_status, master.parts_status, master.ACTUAL_SHIPMENT_DATE, master.basket, master.product
	from fms_ipm_parts_edit_fields parts , fms_ipm_master master  
	where master.concatenate = parts.p_concatenate 
		and sales_date_year_qtr in (extract (year from current_timestamp) || '-' || extract (quarter from current_timestamp));


  SELECT extract(WEEK from now()):: CHARACTER VARYING INTO v_current_week;

  if UPPER(TRIM(to_char(current_date, 'day'))) = 'MONDAY'  AND v_current_week not in ((SELECT DISTINCT week from fms_ipm_data_entry)) THEN
	INSERT INTO fms_ipm_data_entry (identifier, is_region, week, business_unit) SELECT DISTINCT identifier, is_region, v_current_week, 'DTS' FROM fms_ipm_data_entry WHERE business_unit = 'DTS' AND WEEK = extract(week from now()-(interval '1 week')):: CHARACTER VARYING;
	INSERT INTO fms_ipm_data_entry (identifier, is_region, week, business_unit) SELECT DISTINCT identifier, is_region, v_current_week, 'TMS' FROM fms_ipm_data_entry WHERE business_unit = 'TMS' AND WEEK = extract(week from now()-(interval '1 week')):: CHARACTER VARYING;

	  update fms_ipm_data_entry as de_mst
	  set pe_val = new_data.ce_val
	  from(
		Select ce_val,identifier,business_unit from fms_ipm_data_entry where week = (extract (week from current_timestamp - (interval '1 week'))::character varying)
	       )new_data  
	  where de_mst.identifier = new_data.identifier
	    and de_mst.business_unit = new_data.business_unit
	    AND WEEK = v_current_week;
  end if;

  -- CE
  update fms_ipm_data_entry as de_mst
  set ce_val = new_data.CE
  from(
    (select 'TX' as identifier, COALESCE(round(sum(p_cm_dollar_by_1000), 2), 0) as CE, new_p_and_l  
      from parts_data_v where (p_r_by_o !=  'OPPS' or p_r_by_o is null) and p_and_l = 'TX' group by new_p_and_l)
    union
    (select 'CS' as identifier , COALESCE(round(sum(p_cm_dollar_by_1000), 2), 0) as CE, new_p_and_l 
      from parts_data_v where (p_r_by_o !=  'OPPS' or p_r_by_o is null) and p_and_l = 'CS' group by new_p_and_l) 
       )new_data  
  where de_mst.identifier = new_data.identifier
    and de_mst.business_unit = new_data.new_p_and_l
    AND WEEK = v_current_week;
    

  -- RISK
  update fms_ipm_data_entry as de_mst
  set risk_val = new_data.RISK
  from(
    (select 'TX' as identifier, COALESCE(round(sum(p_cm_dollar_by_1000), 2), 0) as RISK, new_p_and_l  
      from parts_data_v where  p_r_by_o =  'RISK' and p_and_l = 'TX' group by new_p_and_l)
    union
    (select 'CS' as identifier , COALESCE(round(sum(p_cm_dollar_by_1000), 2), 0) as RISK, new_p_and_l 
      from parts_data_v where  p_r_by_o =  'RISK' and p_and_l = 'CS' group by new_p_and_l) 
      )new_data  
  where de_mst.identifier = new_data.identifier
    and de_mst.business_unit = new_data.new_p_and_l
    AND WEEK = v_current_week;

  --OPPS
  update fms_ipm_data_entry as de_mst
  set opp_val = new_data.OPP
  from(    
    (select 'TX' as identifier, COALESCE(round(sum(p_cm_dollar_by_1000), 2), 0) as OPP, new_p_and_l  
      from parts_data_v where p_r_by_o =  'OPPS' and p_and_l = 'TX' group by new_p_and_l)
    union
    (select 'CS' as identifier , COALESCE(round(sum(p_cm_dollar_by_1000), 2), 0) as OPP, new_p_and_l 
      from parts_data_v where p_r_by_o =  'OPPS' and p_and_l = 'CS' group by new_p_and_l) 
      )new_data
  where de_mst.identifier = new_data.identifier
    and de_mst.business_unit = new_data.new_p_and_l
    AND WEEK = v_current_week;

-- PARTS

  update fms_ipm_data_entry as de_mst
  set ce_val = new_data.CE
  from
    (
	Select SUM(CE_VAL) as CE, business_unit from fms_ipm_data_entry where identifier IN ('TX', 'CS') AND WEEK = v_current_week group by business_unit
     )new_data  
  where UPPER(de_mst.identifier) = 'PARTS'
    and de_mst.business_unit = new_data.business_unit
    AND WEEK = v_current_week;
    

-- Region level
  Create or replace temp view parts_data_region_v as select COALESCE(parts.p_cm_dollar_by_1000,0) as p_cm_dollar_by_1000, master.p_and_l, master.new_p_and_l, 
    (case when master.new_p_and_l = 'TMS' then TRIM(master.region)
      else (
        CASE WHEN master.og_region = 'Sub-saharan Africa' then 'SUB_SAHARAN_AFRICA'
             WHEN master.og_region = 'Russia & CIS' then 'RUSSIA_CIS'
             WHEN master.og_region = 'North America' then 'NORTH_AMERICA'
             WHEN master.og_region = 'Latin America' then 'LATIN_AMERICA'
         ELSE UPPER(TRIM(master.og_region))
         end
        )
      end) region 
      from fms_ipm_parts_edit_fields parts , fms_ipm_master master  where master.concatenate = parts.p_concatenate and  (p_r_by_o !=  'OPPS' or p_r_by_o is null)
      and sales_date_year_qtr in (extract (year from current_timestamp) || '-' || extract (quarter from current_timestamp))
      and region is not NULL;        
  --TX         
  update fms_ipm_data_entry as de_mst
  set tx_ce_val = new_data.new_val
  from(
    select COALESCE(Round(sum(p_cm_dollar_by_1000), 2), 0) as new_val, region, new_p_and_l from parts_data_region_v  
    where p_and_l = 'TX' group by region, new_p_and_l
      )new_data
  where de_mst.identifier = new_data.region
    and de_mst.business_unit = new_data.new_p_and_l
    AND WEEK = v_current_week;  

  --CS
  update fms_ipm_data_entry as de_mst
  set cs_ce_val = new_data.new_val
  from(
    select COALESCE(Round(sum(p_cm_dollar_by_1000), 2), 0) as new_val, region, new_p_and_l from parts_data_region_v  
    where p_and_l = 'CS' group by region, new_p_and_l
      )new_data
  where de_mst.identifier = new_data.region
    and de_mst.business_unit = new_data.new_p_and_l
    AND WEEK = v_current_week;

-- Region CE val
  update fms_ipm_data_entry as de_mst
  set ce_val = new_data.new_val
  from(
	select COALESCE(sum(tx_ce_val + cs_ce_val + ins_ce_val), 0) as new_val, identifier, business_unit from fms_ipm_data_entry
	where is_region = true  AND WEEK = v_current_week group by identifier, business_unit
      )new_data
  where de_mst.identifier = new_data.identifier
    and de_mst.business_unit = new_data.business_unit
    AND WEEK = v_current_week;    
        
-- Actual TX
	  update fms_ipm_data_entry as de_mst
		set actuals_val = new_data.new_val
		from(
			select 'TX'::character varying as identifier, 'DTS'::character varying as business_unit, (
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v  where new_p_and_l = 'DTS' and TRIM(upper(project_type)) = TRIM('TX') and upper(invoice_status) = trim('C')),0)),2))  
				+
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v 
					where TRIM(upper(project_type)) in (TRIM('GLOBAL CONTRACTUAL'), TRIM('GLOBAL EW'), TRIM('TMGL')) and trim(upper(parts_status)) = trim('SHIPPED') 
					and new_p_and_l = 'DTS' AND ACTUAL_SHIPMENT_DATE + (interval '15 day')> current_timestamp),0)),2)) 
			) as new_val
			)new_data
	 where de_mst.identifier = new_data.identifier
	 and de_mst.business_unit = new_data.business_unit
	 AND WEEK = v_current_week; 

	  update fms_ipm_data_entry as de_mst
		set actuals_val = new_data.new_val
		from(
			select 'TX'::character varying as identifier, 'TMS'::character varying as business_unit, (
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v where 
					new_p_and_l = 'TMS' and TRIM(upper(project_type)) = TRIM('TX') and upper(invoice_status) = trim('C')),0)),2))  +
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v where
					TRIM(upper(project_type)) in (TRIM('GLOBAL CONTRACTUAL'), TRIM('GLOBAL EW'), TRIM('TMGL')) and trim(upper(parts_status)) = trim('SHIPPED') 
					and new_p_and_l = 'TMS' AND ACTUAL_SHIPMENT_DATE + (interval '15 day')> current_timestamp),0)),2)) 
			) as new_val
			)new_data
	 where de_mst.identifier = new_data.identifier
	 and de_mst.business_unit = new_data.business_unit
	AND WEEK = v_current_week; 	 

-- Actual CS
	  update fms_ipm_data_entry as de_mst
		set actuals_val = new_data.new_val
		from(
			select 'CS'::character varying as identifier, 'DTS'::character varying as business_unit, (
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v
					where new_p_and_l = 'DTS' and TRIM(upper(project_type)) = TRIM('CS') and upper(invoice_status) = trim('C')),0)),2))  +
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v
					where TRIM(upper(project_type)) in (TRIM('GLOBAL CONTRACTUAL'), TRIM('GLOBAL EW'), TRIM('TMGL')) and trim(upper(parts_status)) = trim('SHIPPED') 
					and new_p_and_l = 'DTS' AND ACTUAL_SHIPMENT_DATE + (interval '15 day')> current_timestamp),0)),2)) 
			) as new_val
			)new_data
	 where de_mst.identifier = new_data.identifier
	 and de_mst.business_unit = new_data.business_unit
	 AND WEEK = v_current_week; 

	  update fms_ipm_data_entry as de_mst
		set actuals_val = new_data.new_val
		from(
			select 'CS'::character varying as identifier, 'TMS'::character varying as business_unit, (
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v
					where new_p_and_l = 'TMS' and TRIM(upper(project_type)) = TRIM('CS') and upper(invoice_status) = trim('C')),0)),2))  +
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v
					where TRIM(upper(project_type)) in (TRIM('GLOBAL CONTRACTUAL'), TRIM('GLOBAL EW'), TRIM('TMGL')) and trim(upper(parts_status)) = trim('SHIPPED') 
					and new_p_and_l = 'TMS' AND ACTUAL_SHIPMENT_DATE + (interval '15 day')> current_timestamp),0)),2)) 
			) as new_val
			)new_data
	 where de_mst.identifier = new_data.identifier
	 and de_mst.business_unit = new_data.business_unit
	AND WEEK = v_current_week; 

-- UnConfirmed TX

	update fms_ipm_data_entry as de_mst
		set unconfirmed_val = new_data.new_val
		from(	
			select 'TX'::character varying as identifier, 'DTS'::character varying as business_unit,(
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v 
					where new_p_and_l = 'DTS' and TRIM(upper(project_type)) = TRIM('TX') and upper(invoice_status) = trim('U')),0)),2))+
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v 
					where new_p_and_l = 'DTS' and TRIM(upper(project_type)) in (TRIM('GLOBAL CONTRACTUAL'), TRIM('GLOBAL EW'), TRIM('TMGL')) and trim(upper(parts_status)) = trim('SHIPPED') 
					AND ACTUAL_SHIPMENT_DATE + (interval '15 day')< current_timestamp),0)),2))
			) as new_val

		    ) new_data
	 where de_mst.identifier = new_data.identifier
	 and de_mst.business_unit = new_data.business_unit
	AND WEEK = v_current_week; 
	 
	update fms_ipm_data_entry as de_mst
		set unconfirmed_val = new_data.new_val
		from(	
			select 'TX'::character varying as identifier, 'TMS'::character varying as business_unit,(
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v
					where new_p_and_l = 'TMS' and TRIM(upper(project_type)) = TRIM('TX') and upper(invoice_status) = trim('U')),0)),2))+
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v
					where new_p_and_l = 'TMS' and TRIM(upper(project_type)) in (TRIM('GLOBAL CONTRACTUAL'), TRIM('GLOBAL EW'), TRIM('TMGL')) and trim(upper(parts_status)) = trim('SHIPPED') 
					AND ACTUAL_SHIPMENT_DATE + (interval '15 day')< current_timestamp),0)),2))
			) as new_val

		    ) new_data
	 where de_mst.identifier = new_data.identifier
	 and de_mst.business_unit = new_data.business_unit
	AND WEEK = v_current_week; 			


-- UnConfirmed CS

	update fms_ipm_data_entry as de_mst
		set unconfirmed_val = new_data.new_val
		from(	
			select 'CS'::character varying as identifier, 'DTS'::character varying as business_unit,(
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v
					where new_p_and_l = 'DTS' and TRIM(upper(project_type)) = TRIM('CS') and upper(invoice_status) = trim('U')),0)),2))+
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v 
					where new_p_and_l = 'DTS' and TRIM(upper(project_type)) in (TRIM('GLOBAL CONTRACTUAL'), TRIM('GLOBAL EW'), TRIM('TMGL')) and trim(upper(parts_status)) = trim('SHIPPED') 
					AND ACTUAL_SHIPMENT_DATE + (interval '15 day')< current_timestamp),0)),2))
			) as new_val

		    ) new_data
	 where de_mst.identifier = new_data.identifier
	 and de_mst.business_unit = new_data.business_unit
	AND WEEK = v_current_week; 
	 
	update fms_ipm_data_entry as de_mst
		set unconfirmed_val = new_data.new_val
		from(	
			select 'CS'::character varying as identifier, 'TMS'::character varying as business_unit,(
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v 
					where new_p_and_l = 'TMS' and TRIM(upper(project_type)) = TRIM('CS') and upper(invoice_status) = trim('U')),0)),2))+
				(select round((COALESCE((select sum(p_cm_dollar_by_1000) from parts_data_v
					where new_p_and_l = 'TMS' and TRIM(upper(project_type)) in (TRIM('GLOBAL CONTRACTUAL'), TRIM('GLOBAL EW'), TRIM('TMGL')) and trim(upper(parts_status)) = trim('SHIPPED') 
					AND ACTUAL_SHIPMENT_DATE + (interval '15 day')< current_timestamp),0)),2))
			) as new_val

		    ) new_data
	 where de_mst.identifier = new_data.identifier
	 and de_mst.business_unit = new_data.business_unit
	 AND WEEK = v_current_week; 

-- Backlog
update fms_ipm_data_entry as de_mst
	set ce_val = new_data.new_val
	from(
		select Round(COALESCE(sum(p_cm_dollar_by_1000), 0),2) as new_val,new_p_and_l, UPPER(basket) as identifier from parts_data_v  
		where trim(upper(basket)) = 'BACKLOG'
		and upper(product) like '%PARTS%'
		group by new_p_and_l, basket 	 
	     )new_data
where de_mst.identifier = new_data.identifier
  and de_mst.business_unit = new_data.new_p_and_l
AND WEEK = v_current_week; 

-- Early
update fms_ipm_data_entry as de_mst
	set ce_val = new_data.new_val
	from(
		select Round(COALESCE(sum(p_cm_dollar_by_1000), 0),2) as new_val,new_p_and_l, UPPER(basket) as identifier from parts_data_v  
		where trim(upper(basket)) = 'EARLY'
		and upper(product) like '%PARTS%'
		group by new_p_and_l, basket 	 
	     )new_data
where de_mst.identifier = new_data.identifier
  and de_mst.business_unit = new_data.new_p_and_l
	AND WEEK = v_current_week;   

-- CONVERTIBLE
update fms_ipm_data_entry as de_mst
	set ce_val = new_data.new_val
	from(
		select Round(COALESCE(sum(p_cm_dollar_by_1000), 0),2) as new_val, new_p_and_l, UPPER(basket) as identifier from parts_data_v  
		where trim(upper(basket)) in ('CONVERTIBLE')
		and upper(product) like '%PARTS%'
		group by new_p_and_l, basket 	 
	     )new_data
where de_mst.identifier = new_data.identifier
  and de_mst.business_unit = new_data.new_p_and_l
	AND WEEK = v_current_week; 

-- CONVTOGO
update fms_ipm_data_entry as de_mst
	set ce_val = new_data.new_val
	from(
		select Round(COALESCE(sum(p_cm_dollar_by_1000), 0),2) as new_val, new_p_and_l, 'CONVTOGO'::character varying as identifier from parts_data_v  
		where trim(upper(basket)) in ('BUSINESS RELEASE')
		and upper(product) like '%PARTS%'
		group by new_p_and_l 	 
	     )new_data
where de_mst.identifier = new_data.identifier
  and de_mst.business_unit = new_data.new_p_and_l
	AND WEEK = v_current_week;  
    

  DROP view IF EXISTS parts_data_v;  
  DROP view IF EXISTS parts_data_region_v;


RETURN ('SUCCESS');
    
  EXCEPTION WHEN OTHERS THEN 
  PERFORM fms_db_logger('fms_ipm_dataentry_daily_update',
           '' ,
           sqlerrm,
           'DATABASE ERROR');  
  --RAISE NOTICE 'SQL ERROR %', sqlerrm;

  DROP view IF EXISTS parts_data_v;  
  DROP view IF EXISTS parts_data_region_v;
  RETURN 'DATABASE ERROR';    
  
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
