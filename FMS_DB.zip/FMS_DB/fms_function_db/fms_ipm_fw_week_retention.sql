-- Function: fms_ipm_fw_week_retention()

-- DROP FUNCTION fms_ipm_fw_week_retention();

CREATE OR REPLACE FUNCTION fms_ipm_fw_week_retention()
  RETURNS character varying AS
$BODY$
DECLARE

	v_result character varying;
	v_max_week numeric;

--select extract(week from cast('2027/01/01' as date)), UPPER(TRIM(to_char(cast('2026/01/01' as date), 'day')))

	
BEGIN

	
	if extract(quarter from now()) = 1 then 
		raise notice ' quarter 1';

		Select max(week::numeric) into v_max_week from fms_ipm_data_entry;

		raise notice 'Max week @ quarter 1 %', v_max_week;
		
		
		if UPPER(TRIM(to_char(current_date, 'day'))) = 'SUNDAY' then
			select fms_ipm_insert_fw_history() into v_result;
			select fms_ipm_pmo_data_table('DTS','','','','','','','','','','','', '', TRUE) into v_result;
			select fms_ipm_pmo_data_table('TMS','','','','','','','','','','','', '', TRUE) into v_result;
			
		end if;

		delete from fms_ipm_data_entry where week::numeric not between 1 and 13 and week::numeric <> v_max_week;
		delete from fms_ipm_fw_history where week::numeric not between 1 and 13 and week::numeric <> v_max_week;
		delete from fms_ipm_pmo_history where week::numeric not between 1 and 13 and week::numeric <> v_max_week;
		delete from fms_ipm_parts_forecast where week::numeric not between 1 and 13 and week::numeric <> v_max_week;

	elsif extract(quarter from now()) = 2 then 
		raise notice ' quarter 2';

		Select max(week::numeric) into v_max_week from fms_ipm_data_entry;

		raise notice 'Max week @ quarter 2 %', v_max_week;
				
		if UPPER(TRIM(to_char(current_date, 'day'))) = 'SUNDAY' then
			select fms_ipm_insert_fw_history() into v_result;
			select fms_ipm_pmo_data_table('DTS','','','','','','','','','','','', '', TRUE) into v_result;
			select fms_ipm_pmo_data_table('TMS','','','','','','','','','','','','', TRUE) into v_result;
		end if;
		
		delete from fms_ipm_data_entry where week::numeric not between 13 and 26;
		delete from fms_ipm_fw_history where week::numeric not between 13 and 26;
		delete from fms_ipm_pmo_history where week::numeric not between 13 and 26;
		delete from fms_ipm_parts_forecast where week::numeric not between 13 and 26;
		
	elsif extract(quarter from now()) = 3 then 
		raise notice ' quarter 3';
		if UPPER(TRIM(to_char(current_date, 'day'))) = 'SUNDAY' then
			select fms_ipm_insert_fw_history() into v_result;
			select fms_ipm_pmo_data_table('DTS','','','','','','','','','','','', '',TRUE) into v_result;
			select fms_ipm_pmo_data_table('TMS','','','','','','','','','','','', '',TRUE) into v_result;
		end if;
		
		delete from fms_ipm_data_entry where week::numeric not between 26 and 39;
		delete from fms_ipm_fw_history where week::numeric not between 26 and 39;
		delete from fms_ipm_pmo_history where week::numeric not between 26 and 39;
		delete from fms_ipm_parts_forecast where week::numeric not between 26 and 39;
	else
		raise notice ' quarter 4';
		if UPPER(TRIM(to_char(current_date, 'day'))) = 'SUNDAY' then
			select fms_ipm_insert_fw_history() into v_result;
			select fms_ipm_pmo_data_table('DTS','','','','','','','','','','','', '',TRUE) into v_result;
			select fms_ipm_pmo_data_table('TMS','','','','','','','','','','','', '',TRUE) into v_result;
		end if;

		delete from fms_ipm_data_entry where week::numeric not between 39 and 53;
		delete from fms_ipm_fw_history where week::numeric not between 39 and 53;
		delete from fms_ipm_pmo_history where week::numeric not between 39 and 53;
		delete from fms_ipm_parts_forecast where week::numeric not between 39 and 53;
	end if;
	

	return 'SUCCESS';

	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_ipm_fw_week_retention',
			     '' ,
			     sqlerrm,
			     'DATABASE ERROR');		
	--RAISE NOTICE 'SQL ERROR %', sqlerrm;
	RETURN 'DATABASE ERROR';		
	
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
