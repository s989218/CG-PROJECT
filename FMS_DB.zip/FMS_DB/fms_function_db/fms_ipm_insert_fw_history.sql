-- Function: fms_ipm_insert_fw_history()

-- DROP FUNCTION fms_ipm_insert_fw_history();

CREATE OR REPLACE FUNCTION fms_ipm_insert_fw_history()
  RETURNS character varying AS
$BODY$  
DECLARE

  v_b_unit character varying;

begin

  
  v_b_unit = 'TMS';

  for a in 1..2 loop

--Insert key deals
  
  insert into fms_ipm_fw_history 
  --(pa_cm_total,pa_region, pa_concatenate, pa_p_and_l, pa_product, pa_end_user_cust_name, pa_cm_dol_by_1000, pa_status, pa_rev_rec_needs, pa_note, pa_due_date, pa_trend, pa_r_by_o, pa_week, pa_identifier)
    SELECT cm_sum, final_region, concatenate, p_and_l, product, enduser_cust_name, 
  p_cm_dollar_by_1000, p_status, p_wb_comment, p_note, p_due_date, p_trend,p_r_by_o, 
  extract(week from current_timestamp) as week, 'KEY_DEALS' as identifier, v_b_unit as business_unit
FROM
  (SELECT ROUND(data2.cm_sum,2)::VARCHAR AS cm_sum,
    data1.*
  FROM
    (SELECT *
    FROM
      (SELECT (
        CASE
          WHEN fim.new_p_and_l = 'TMS'
          THEN fim.region
          ELSE fim.og_region
        END) AS final_region ,
        fim.concatenate,
        fim.p_and_l,
        fim.product,
        fim.enduser_cust_name,
        ROUND(fip.p_cm_dollar_by_1000,2)::VARCHAR AS p_cm_dollar_by_1000,
        fip.p_status,
        fip.p_wb_comment,
        fip.p_note,
        fip.p_due_date,
        fip.p_trend,
        fip.p_r_by_o,
        ROW_NUMBER() OVER (PARTITION BY (
        CASE
          WHEN fim.new_p_and_l = 'TMS'
          THEN fim.region
          ELSE fim.og_region
        END) order by fip.p_cm_dollar_by_1000 DESC) AS Row_ID
      FROM fms_ipm_master fim,
        fms_ipm_parts_edit_fields fip
      WHERE fim.concatenate = fip.p_concatenate
      AND fim.new_p_and_l = v_b_unit
      AND COALESCE(fim.p_and_l,'') ~* ''
      AND COALESCE(fim.product,'') ~* ''
      AND COALESCE(fim.ou_name,'') ~* ''
      AND COALESCE(fim.og_region,'') ~* ''
      AND COALESCE(fim.region,'') ~* ''
      AND COALESCE(fim.subregion,'') ~* ''
      AND COALESCE(fim.end_user_country_disc,'') ~* ''
      AND COALESCE(fim.mother_job,'') ~* ''
      AND COALESCE(fim.enduser_cust_name,'') ~* ''
      AND COALESCE(fim.costing_project,'') ~* ''
      AND COALESCE(fim.order_type,'') ~* ''
      AND (fip.p_r_by_o           IS NULL
      OR fip.p_r_by_o             <> 'OPPS')
      AND fim.sales_date_year_qtr IN (extract (YEAR FROM CURRENT_TIMESTAMP)
        ||'-'
        ||extract (quarter FROM CURRENT_TIMESTAMP))
      ) AS IPM
    WHERE Row_ID <=5
    ORDER BY final_region
    ) data1
  INNER JOIN
    (SELECT final_region ,
      SUM(p_cm_dollar_by_1000) AS cm_sum
    FROM
      (SELECT *
      FROM
        (SELECT (
          CASE
            WHEN fim.new_p_and_l = 'TMS'
            THEN fim.region
            ELSE fim.og_region
          END) AS final_region ,
          fip.p_cm_dollar_by_1000,
          ROW_NUMBER() OVER (PARTITION BY (
          CASE
            WHEN fim.new_p_and_l = 'TMS'
            THEN fim.region
            ELSE fim.og_region
          END) order by fip.p_cm_dollar_by_1000 DESC) AS Row_ID
        FROM fms_ipm_master fim,
          fms_ipm_parts_edit_fields fip
        WHERE fim.concatenate = fip.p_concatenate
        AND fim.new_p_and_l = v_b_unit
        AND COALESCE(fim.p_and_l,'') ~* ''
        AND COALESCE(fim.product,'') ~* ''
        AND COALESCE(fim.ou_name,'') ~* ''
        AND COALESCE(fim.og_region,'') ~* ''
        AND COALESCE(fim.region,'') ~* ''
        AND COALESCE(fim.subregion,'') ~* ''
        AND COALESCE(fim.end_user_country_disc,'') ~* ''
        AND COALESCE(fim.mother_job,'') ~* ''
        AND COALESCE(fim.enduser_cust_name,'') ~* ''
        AND COALESCE(fim.costing_project,'') ~* ''
        AND COALESCE(fim.order_type,'') ~* ''
        AND (fip.p_r_by_o           IS NULL
        OR fip.p_r_by_o             <> 'OPPS')
        AND fim.sales_date_year_qtr IN (extract (YEAR FROM CURRENT_TIMESTAMP)
          ||'-'
          ||extract (quarter FROM CURRENT_TIMESTAMP))
        ) AS IPM_SUM
      WHERE Row_ID <=5
      ORDER BY final_region
      ) AS region_sum
    GROUP BY final_region
    ) data2
  ON data1.final_region = data2.final_region
  ) AS result;


--Insert Risks

  insert into fms_ipm_fw_history 
    SELECT cm_sum, final_region, concatenate, p_and_l, product, enduser_cust_name, 
  p_cm_dollar_by_1000, p_status, p_wb_comment, p_note, p_due_date, p_trend, null as r_by_o,
   extract(week from current_timestamp) as week, 'RISK' as identifier, v_b_unit as business_unit
FROM
  (SELECT ROUND(data2.cm_sum,2)::VARCHAR AS cm_sum,
    data1.*
  FROM(
    (SELECT (
      CASE
        WHEN fim.new_p_and_l = 'TMS'
        THEN fim.region
        ELSE fim.og_region
      END) AS final_region ,
      fim.concatenate,
      fim.p_and_l,
      fim.product,
      fim.enduser_cust_name,
      ROUND(fip.p_cm_dollar_by_1000,2)::VARCHAR AS p_cm_dollar_by_1000,
      fip.p_status,
      fip.p_wb_comment,
      fip.p_note,
      fip.p_due_date,
      fip.p_trend
    FROM fms_ipm_master fim,
      fms_ipm_parts_edit_fields fip
    WHERE fim.concatenate = fip.p_concatenate
    AND fim.new_p_and_l = v_b_unit
    AND COALESCE(fim.p_and_l,'') ~* ''
    AND COALESCE(fim.product,'') ~* ''
    AND COALESCE(fim.ou_name,'') ~* ''
    AND COALESCE(fim.og_region,'') ~* ''
    AND COALESCE(fim.region,'') ~* ''
    AND COALESCE(fim.subregion,'') ~* ''
    AND COALESCE(fim.end_user_country_disc,'') ~* ''
    AND COALESCE(fim.mother_job,'') ~* ''
    AND COALESCE(fim.enduser_cust_name,'') ~* ''
    AND COALESCE(fim.costing_project,'') ~* ''
    AND COALESCE(fim.order_type,'') ~* ''
    AND fip.p_r_by_o             = 'RISK'
    AND fim.sales_date_year_qtr IN (extract (YEAR FROM CURRENT_TIMESTAMP)
      ||'-'
      ||extract (quarter FROM CURRENT_TIMESTAMP))
    )) data1
  INNER JOIN
    (SELECT (
      CASE
        WHEN fim.new_p_and_l = 'TMS'
        THEN fim.region
        ELSE fim.og_region
      END)                         AS final_region ,
      SUM(fip.p_cm_dollar_by_1000) AS cm_sum
    FROM fms_ipm_master fim,
      fms_ipm_parts_edit_fields fip
    WHERE fim.concatenate = fip.p_concatenate
	AND fim.new_p_and_l = v_b_unit
    AND COALESCE(fim.p_and_l,'') ~* ''
    AND COALESCE(fim.product,'') ~* ''
    AND COALESCE(fim.ou_name,'') ~* ''
    AND COALESCE(fim.og_region,'') ~* ''
    AND COALESCE(fim.region,'') ~* ''
    AND COALESCE(fim.subregion,'') ~* ''
    AND COALESCE(fim.end_user_country_disc,'') ~* ''
    AND COALESCE(fim.mother_job,'') ~* ''
    AND COALESCE(fim.enduser_cust_name,'') ~* ''
    AND COALESCE(fim.costing_project,'') ~* ''
    AND COALESCE(fim.order_type,'') ~* ''
    AND fip.p_r_by_o             = 'RISK'
    AND fim.sales_date_year_qtr IN (extract (YEAR FROM CURRENT_TIMESTAMP)
      ||'-'
      ||extract (quarter FROM CURRENT_TIMESTAMP))
    GROUP BY final_region
    ) data2
  ON data1.final_region = data2.final_region
  ) AS result
ORDER BY p_cm_dollar_by_1000 DESC;



--Insert Opps

  insert into fms_ipm_fw_history 
    SELECT cm_sum, final_region, concatenate, p_and_l, product, enduser_cust_name, 
  p_cm_dollar_by_1000, p_status, p_wb_comment, p_note, p_due_date, p_trend, null as r_by_o,
   extract(week from current_timestamp) as week, 'OPPS' as identifier, v_b_unit as business_unit
FROM
  (SELECT data2.cm_sum,
    data1.*
  FROM (
    (SELECT (
      CASE
        WHEN fim.new_p_and_l = 'TMS'
        THEN fim.region
        ELSE fim.og_region
      END) AS final_region ,
      fim.concatenate,
      fim.p_and_l,
      fim.product,
      fim.enduser_cust_name,
      fip.p_cm_dollar_by_1000,
      fip.p_status,
      fip.p_wb_comment,
      fip.p_note,
      fip.p_due_date,
      fip.p_trend
    FROM fms_ipm_master fim,
      fms_ipm_parts_edit_fields fip
    WHERE fim.concatenate = fip.p_concatenate
    AND fim.new_p_and_l = v_b_unit
    AND COALESCE(fim.p_and_l,'') ~* ''
    AND COALESCE(fim.product,'') ~* ''
    AND COALESCE(fim.ou_name,'') ~* ''
    AND COALESCE(fim.og_region,'') ~* ''
    AND COALESCE(fim.region,'') ~* ''
    AND COALESCE(fim.subregion,'') ~* ''
    AND COALESCE(fim.end_user_country_disc,'') ~* ''
    AND COALESCE(fim.mother_job,'') ~* ''
    AND COALESCE(fim.enduser_cust_name,'') ~* ''
    AND COALESCE(fim.costing_project,'') ~* ''
    AND COALESCE(fim.order_type,'') ~* ''
    AND fip.p_r_by_o             = 'OPPS'
    AND fim.sales_date_year_qtr IN (extract (YEAR FROM CURRENT_TIMESTAMP)
      ||'-'
      ||extract (quarter FROM CURRENT_TIMESTAMP))
    )) data1
  INNER JOIN
    (SELECT (
      CASE
        WHEN fim.new_p_and_l = 'TMS'
        THEN fim.region
        ELSE fim.og_region
      END)                         AS final_region ,
      SUM(fip.p_cm_dollar_by_1000) AS cm_sum
    FROM fms_ipm_master fim,
      fms_ipm_parts_edit_fields fip
    WHERE fim.concatenate = fip.p_concatenate
    AND fim.new_p_and_l = v_b_unit
    AND COALESCE(fim.p_and_l,'') ~* ''
    AND COALESCE(fim.product,'') ~* ''
    AND COALESCE(fim.ou_name,'') ~* ''
    AND COALESCE(fim.og_region,'') ~* ''
    AND COALESCE(fim.region,'') ~* ''
    AND COALESCE(fim.subregion,'') ~* ''
    AND COALESCE(fim.end_user_country_disc,'') ~* ''
    AND COALESCE(fim.mother_job,'') ~* ''
    AND COALESCE(fim.enduser_cust_name,'') ~* ''
    AND COALESCE(fim.costing_project,'') ~* ''
    AND COALESCE(fim.order_type,'') ~* ''
    AND fip.p_r_by_o             = 'OPPS'
    AND fim.sales_date_year_qtr IN (extract (YEAR FROM CURRENT_TIMESTAMP)
      ||'-'
      ||extract (quarter FROM CURRENT_TIMESTAMP))
    GROUP BY final_region
    ) data2
  ON data1.final_region = data2.final_region
  ) AS result;


  v_b_unit = 'DTS';
  
  end loop;


  RETURN 'SUCCESS';

  EXCEPTION WHEN OTHERS THEN 
  --ROLLBACK; 
  PERFORM fms_db_logger('fms_ipm_insert_fw_history',
           '' ,
           sqlerrm,
           'DATABASE ERROR');    
  
  --RAISE NOTICE 'SQL ERROR %', sqlerrm;
  RETURN 'DATABASE ERROR';

end
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
