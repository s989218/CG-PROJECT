


CREATE OR REPLACE FUNCTION fms_ipm_parts_validation(in_sso_id character varying)
  RETURNS character varying AS
$BODY$
DECLARE
    
    v_proc_paras  character varying(2500); 

BEGIN

	v_proc_paras = in_sso_id;

	update fms_ipm_csv_parts_import set p_new_date = NULL, p_wb_comment = NULL where sso_id = in_sso_id and TRIM(p_new_date) = '' or TRIM(p_wb_comment) = '';

	update fms_ipm_csv_parts_import set invalid_status = -1 where sso_id=in_sso_id and (fms_is_date(p_new_date) = false and p_new_date is not null) or (cast(p_new_date as date) < current_date ) or (cast(p_new_date as date) is not null and p_wb_comment is null);

	update fms_ipm_csv_parts_import set invalid_status = -1 where sso_id=in_sso_id and (UPPER(p_wb_comment) NOT IN (select UPPER(wb_comment_data) from fms_ipm_dd_p_wb_comment));

	update fms_ipm_csv_parts_import set invalid_status = -1 where sso_id=in_sso_id and p_r_by_o NOT IN (SELECT DISTINCT r_by_o_data FROM fms_ipm_dd_p_r_by_o) OR (COALESCE(p_status,'') NOT IN ('High','Medium','Low') ) OR p_keydeals NOT IN ('Key Deals');

	update fms_ipm_csv_parts_import set invalid_status = -1 where sso_id=in_sso_id and ( parts_status not in ('AVAILABLE','SHIPPED','PACKING','SHIPPING','SALES','INCOMING','BILLING') and parts_status is not null );

RETURN 'SUCCESS';
    
	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_ipm_parts_validation',
			     v_proc_paras ,
			     sqlerrm,
			     'DATABASE ERROR');		
	--RAISE  notice 'SQL ERROR %', sqlerrm;
	RETURN 'DATABASE ERROR';		
	
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;


  