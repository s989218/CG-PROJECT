-- Function: fms_ipm_pmo_data_table(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, boolean)

-- DROP FUNCTION fms_ipm_pmo_data_table(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, boolean);

CREATE OR REPLACE FUNCTION fms_ipm_pmo_data_table(
    IN in_new_p_and_l character varying,
    IN in_p_and_l character varying,
    IN in_product character varying,
    IN in_ou_name character varying,
    IN in_og_region character varying,
    IN in_region character varying,
    IN in_subregion character varying,
    IN in_end_user_country_disc character varying,
    IN in_mother_job character varying,
    IN in_enduser_cust_name character varying,
    IN in_costing_project character varying,
    IN in_order_type character varying,
    IN in_project_manager character varying,
    IN in_flag boolean,
    OUT out_pmo_chart character varying,
    OUT out_data_table_current character varying,
    OUT out_data_table_future character varying,
    OUT out_data_finance character varying)
  RETURNS record AS
$BODY$  
DECLARE

    v_proc_paras character varying(2500); 
    v_pmo_chart_sql character varying;
    v_current_sql character varying;
    v_future_sql character varying;
    v_max_week numeric;
    v_finance_view_sql character varying;
    v_firstweek character varying;
    v_lastweek character varying;
    v_firstweek_int numeric;
    v_lastweek_int numeric;    

 BEGIN


  v_proc_paras = in_new_p_and_l||';'||
      in_p_and_l||';'||
      in_product||';'||
      in_ou_name||';'||
      in_og_region||';'||
      in_region||';'||
      in_subregion||';'||
      in_end_user_country_disc||';'||
      in_mother_job||';'||
      in_enduser_cust_name||';'||
      in_costing_project||';'||
      in_order_type||';'||
      in_project_manager||';'||
      in_flag

      ;

raise notice '%', in_new_p_and_l;
raise notice '%', 
      in_p_and_l;raise notice '%', 
      in_product;raise notice '%', 
      in_ou_name;raise notice '%', 
      in_og_region;raise notice '%', 
      in_region;raise notice '%', 
      in_subregion;raise notice '%', 
      in_end_user_country_disc;raise notice '%', 
      in_mother_job;raise notice '%', 
      in_enduser_cust_name;raise notice '%', 
      in_costing_project;raise notice '%',
      in_project_manager;raise notice '%', 
      in_order_type;

Select max(week::numeric) into v_max_week from fms_ipm_data_entry;
raise notice 'v_max_week %',v_max_week;
--(case when  extract (week from cast(extract(year from current_timestamp)||'/1/1' as date) ) = v_max_week then 1 else  v_max_week end)::character varying 

  if Extract(week from Now()) >= 1 and Extract(week from Now()) <= 13 then     
    v_firstweek = '1'; v_firstweek_int = 1;
          v_lastweek = '13'; v_lastweek_int = 13;
  elsif Extract(week from Now()) >= 14 and Extract(week from Now()) <= 26 then            
    v_firstweek = '14'; v_firstweek_int = 14;
          v_lastweek = '26'; v_lastweek_int = 26;
  elsif Extract(week from Now()) >= 27 and Extract(week from Now()) <= 39 then            
    v_firstweek = '27'; v_firstweek_int = 27;
          v_lastweek = '39'; v_lastweek_int = 39;    
  elsif Extract(week from Now()) >= 40 and Extract(week from Now()) <= 53 then            
    v_firstweek = '40'; v_firstweek_int = 40;
          v_lastweek = '53'; v_lastweek_int = 53;             
  end if;         

raise notice 'v_firstweek - %', v_firstweek;
raise notice 'v_lastweek - %', v_lastweek;
    
--PMO Charts

v_pmo_chart_sql = '

create or replace temp view pmo_chart_v as
select parts_status,  sum(sum_cm) as sum_cm, (CASE WHEN parts_status = ''INCOMING'' THEN 1 
      WHEN parts_status = ''AVAILABLE'' THEN 2 
      WHEN parts_status = ''PACKING'' THEN 3 
      WHEN parts_status = ''BILLING'' THEN 4 
      WHEN parts_status = ''SHIPPING'' THEN 5 
      WHEN parts_status = ''SHIPPED'' THEN 6 
      WHEN parts_status = ''SALES'' THEN 7 
      WHEN parts_status = ''BLANK'' THEN 8 
      END) as seq_parts_status, 
      sales_year_qtr 
      from 
       (Select UPPER(COALESCE(parts_status, ''BLANK'')) as parts_status, 
       sum(p_sum_cm) as sum_cm, 
      (case when  
      (fim.sales_date_year_qtr in (extract (year from current_timestamp)||''-''||extract (quarter from current_timestamp)) or fed.p_forecast_status = ''A'' ) and (fed.p_forecast_status <> ''R'' or fed.p_forecast_status is null) 
       then ''CURRENT'' 
      else ''FUTURE'' end) as sales_year_qtr 
      from fms_ipm_parts_edit_fields fed join fms_ipm_master fim on fed.p_concatenate = fim.concatenate 
      where
      new_p_and_l = ' || '''' || in_new_p_and_l || '''' || ' AND COALESCE(fim.p_and_l,'''') ~* ' || '''' || in_p_and_l || '''' || '
      AND COALESCE(fim.product,'''') ~* ' || '''' || in_product || '''' || ' AND COALESCE(fim.ou_name,'''') ~* ' || '''' || in_ou_name || '''' || '
      AND COALESCE(fim.og_region,'''') ~* ' || '''' || in_og_region || '''' || ' AND COALESCE(fim.region,'''') ~* ' || '''' || in_region  || '''' || ' 
      AND COALESCE(fim.subregion,'''') ~* ' || '''' || in_subregion || '''' || ' AND COALESCE(fim.end_user_country_disc,'''') ~* ' || '''' || in_end_user_country_disc  || '''' || '
      AND COALESCE(fim.mother_job,'''') ~* ' || '''' || in_mother_job || '''' || ' AND COALESCE(fim.enduser_cust_name,'''') ~* ' || '''' || in_enduser_cust_name || '''' || ' 
      AND COALESCE(fim.costing_project,'''') ~* ' || '''' || in_costing_project || '''' || ' AND COALESCE(fim.order_type,'''') ~* ' || '''' || in_order_type  || '''' || '
      AND COALESCE(fim.project_manager,'''') ~* ' || '''' || in_project_manager  || '''' || ' 
      AND fim.sales_date_year_qtr in 
      (((extract(year from now())||''-''||extract(quarter from current_timestamp))), 
      ((extract(year from now()+ (interval ''3 month''))||''-''||extract(quarter from current_timestamp+ (interval ''3 month'')))), 
      ((extract(year from now()+ (interval ''6 month''))||''-''||extract(quarter from current_timestamp+ (interval ''6 month'')))), 
      ((extract(year from now()+ (interval ''9 month''))||''-''||extract(quarter from current_timestamp+ (interval ''9 month'')))), 
      ((extract(year from now()+ (interval ''12 month''))||''-''||extract(quarter from current_timestamp+ (interval ''12 month'')))))
      group by parts_status,sales_date_year_qtr, p_forecast_status) as sub_query group by sales_year_qtr, parts_status order by  seq_parts_status, sales_year_qtr';

      
raise notice '%', v_pmo_chart_sql;

execute v_pmo_chart_sql;


--Current Data table

v_current_sql = '

create or replace temp view pmo_data_table_current_v as

Select InnerT.parts_status as parts_status, COALESCE(InnerT.forecasted, 0) as forecasted, COALESCE(added.added, 0) as added, COALESCE(InnerT.removed, 0) as removed, 
  (COALESCE(InnerT.forecasted, 0) + COALESCE(added.added, 0) - COALESCE(InnerT.removed, 0)) as New_Forecasted from
(Select forecasted.parts_status as parts_status, forecasted.forecasted as forecasted, removed.removed as removed from
(select sum(COALESCE(forecast, 0)) as forecasted , parts_status from fms_ipm_parts_forecast where quarter in (extract(quarter from current_timestamp)::text||''Q'') 
and 
year in ( extract(year from current_timestamp ) )
and new_p_and_l = ' || '''' || in_new_p_and_l || '''' || '
and quarter_status = ''CURRENT'' 
and qtr_first_day_data = TRUE
 group by parts_status order by parts_status
) as forecasted

Left Outer join
(select sum(COALESCE(fed.p_sum_cm, 0)) as removed, coalesce(fim.parts_status,''BLANK'') as parts_status from fms_ipm_parts_edit_fields fed inner join fms_ipm_master fim on fim. concatenate = fed.p_concatenate where p_forecast_status = ''R'' and 
fim.sales_date_year_qtr in (extract(year from now() )::text||''-''||extract(quarter from now() )::text ) 

AND COALESCE(fim.new_p_and_l,'''') ~* ' || '''' || in_new_p_and_l || '''' || ' AND COALESCE(fim.p_and_l,'''') ~* ' || '''' || in_p_and_l || '''' || '
      AND COALESCE(fim.product,'''') ~* ' || '''' || in_product || '''' || ' AND COALESCE(fim.ou_name,'''') ~* ' || '''' || in_ou_name || '''' || '
      AND COALESCE(fim.og_region,'''') ~* ' || '''' || in_og_region || '''' || ' AND COALESCE(fim.region,'''') ~* ' || '''' || in_region  || '''' || '
      AND COALESCE(fim.subregion,'''') ~* ' || '''' || in_subregion || '''' || ' AND COALESCE(fim.end_user_country_disc,'''') ~* ' || '''' || in_end_user_country_disc  || '''' || '
      AND COALESCE(fim.mother_job,'''') ~* ' || '''' || in_mother_job || '''' || ' AND COALESCE(fim.enduser_cust_name,'''') ~* ' || '''' || in_enduser_cust_name || '''' || ' 
      AND COALESCE(fim.costing_project,'''') ~* ' || '''' || in_costing_project || '''' || ' AND COALESCE(fim.order_type,'''') ~* ' || '''' || in_order_type  || '''' || '
      AND COALESCE(fim.project_manager,'''') ~* ' || '''' || in_project_manager  || '''' || ' 
group by parts_status order by parts_status ) as removed
ON forecasted.parts_status = removed.parts_status) as InnerT
Left outer join
(select sum(COALESCE(fed.p_sum_cm, 0)) as added, coalesce(fim.parts_status,''BLANK'') as parts_status from fms_ipm_parts_edit_fields fed inner join fms_ipm_master fim on fim. concatenate = fed.p_concatenate where p_forecast_status = ''A'' and 
fim.sales_date_year_qtr in ((extract(year from now()+ (interval ''3 month''))::text||''-''||extract(quarter from current_timestamp+ (interval ''3 month''))::text),
  (extract(year from now()+ (interval ''6 month''))::text||''-''||extract(quarter from current_timestamp+ (interval ''6 month''))::text),
  (extract(year from now()+ (interval ''9 month''))::text||''-''||extract(quarter from current_timestamp+ (interval ''9 month''))::text),
  (extract(year from now()+ (interval ''12 month''))::text||''-''||extract(quarter from current_timestamp+ (interval ''12 month''))::text))

AND COALESCE(fim.new_p_and_l,'''') ~* ' || '''' || in_new_p_and_l || '''' || ' AND COALESCE(fim.p_and_l,'''') ~* ' || '''' || in_p_and_l || '''' || '
      AND COALESCE(fim.product,'''') ~* ' || '''' || in_product || '''' || ' AND COALESCE(fim.ou_name,'''') ~* ' || '''' || in_ou_name || '''' || '
      AND COALESCE(fim.og_region,'''') ~* ' || '''' || in_og_region || '''' || ' AND COALESCE(fim.region,'''') ~* ' || '''' || in_region  || '''' || '
      AND COALESCE(fim.subregion,'''') ~* ' || '''' || in_subregion || '''' || ' AND COALESCE(fim.end_user_country_disc,'''') ~* ' || '''' || in_end_user_country_disc  || '''' || '
      AND COALESCE(fim.mother_job,'''') ~* ' || '''' || in_mother_job || '''' || ' AND COALESCE(fim.enduser_cust_name,'''') ~* ' || '''' || in_enduser_cust_name || '''' || ' 
      AND COALESCE(fim.costing_project,'''') ~* ' || '''' || in_costing_project || '''' || ' AND COALESCE(fim.order_type,'''') ~* ' || '''' || in_order_type  || '''' || '
      AND COALESCE(fim.project_manager,'''') ~* ' || '''' || in_project_manager  || '''' || ' 
 group by parts_status order by parts_status) as added
ON InnerT.parts_status = added.parts_status';

raise notice '%', v_current_sql;

execute v_current_sql;


-- Future Data table

v_future_sql = '

create or replace temp view pmo_data_table_future_v as

Select InnerT.parts_status as parts_status, COALESCE(InnerT.forecasted, 0) as forecasted, COALESCE(added.added, 0) as added, COALESCE(InnerT.removed, 0) as removed, 
  (COALESCE(InnerT.forecasted, 0) + COALESCE(added.added, 0) - COALESCE(InnerT.removed, 0)) as New_Forecasted from
(Select forecasted.parts_status as parts_status, forecasted.forecasted as forecasted, removed.removed as removed from
(select sum(COALESCE(forecast, 0)) as forecasted , parts_status from fms_ipm_parts_forecast where quarter in (extract(quarter from current_timestamp )::text||''Q'') 
and 
year in ( extract(year from current_timestamp ) )
and new_p_and_l = ' || '''' || in_new_p_and_l || '''' || '
 and quarter_status = ''FUTURE''
 and qtr_first_day_data = TRUE
 group by parts_status order by parts_status
) as forecasted

Left Outer join
(select sum(COALESCE(fed.p_sum_cm, 0)) as removed, coalesce(fim.parts_status,''BLANK'') as parts_status from fms_ipm_parts_edit_fields fed inner join fms_ipm_master fim on fim. concatenate = fed.p_concatenate where p_forecast_status = ''A'' and 
fim.sales_date_year_qtr in 
((extract(year from now()+ (interval ''3 month''))::text||''-''||extract(quarter from current_timestamp+ (interval ''3 month''))::text),
  (extract(year from now()+ (interval ''6 month''))::text||''-''||extract(quarter from current_timestamp+ (interval ''6 month''))::text),
  (extract(year from now()+ (interval ''9 month''))::text||''-''||extract(quarter from current_timestamp+ (interval ''9 month''))::text),
  (extract(year from now()+ (interval ''12 month''))::text||''-''||extract(quarter from current_timestamp+ (interval ''12 month''))::text))

AND COALESCE(fim.new_p_and_l,'''') ~* ' || '''' || in_new_p_and_l || '''' || ' AND COALESCE(fim.p_and_l,'''') ~* ' || '''' || in_p_and_l || '''' || '
      AND COALESCE(fim.product,'''') ~* ' || '''' || in_product || '''' || ' AND COALESCE(fim.ou_name,'''') ~* ' || '''' || in_ou_name || '''' || '
      AND COALESCE(fim.og_region,'''') ~* ' || '''' || in_og_region || '''' || ' AND COALESCE(fim.region,'''') ~* ' || '''' || in_region  || '''' || '
      AND COALESCE(fim.subregion,'''') ~* ' || '''' || in_subregion || '''' || ' AND COALESCE(fim.end_user_country_disc,'''') ~* ' || '''' || in_end_user_country_disc  || '''' || '
      AND COALESCE(fim.mother_job,'''') ~* ' || '''' || in_mother_job || '''' || ' AND COALESCE(fim.enduser_cust_name,'''') ~* ' || '''' || in_enduser_cust_name || '''' || ' 
      AND COALESCE(fim.costing_project,'''') ~* ' || '''' || in_costing_project || '''' || ' AND COALESCE(fim.order_type,'''') ~* ' || '''' || in_order_type  || '''' || '
      AND COALESCE(fim.project_manager,'''') ~* ' || '''' || in_project_manager  || '''' || ' 
 group by parts_status order by parts_status ) as removed

ON forecasted.parts_status = removed.parts_status) as InnerT
Left outer join
(select sum(COALESCE(fed.p_sum_cm, 0)) as added, coalesce(fim.parts_status,''BLANK'') as parts_status from fms_ipm_parts_edit_fields fed inner join fms_ipm_master fim on fim. concatenate = fed.p_concatenate where p_forecast_status = ''R'' and 
fim.sales_date_year_qtr in (extract(year from now() )||''-''||extract(quarter from now() ) )


AND COALESCE(fim.new_p_and_l,'''') ~* ' || '''' || in_new_p_and_l || '''' || ' AND COALESCE(fim.p_and_l,'''') ~* ' || '''' || in_p_and_l || '''' || '
      AND COALESCE(fim.product,'''') ~* ' || '''' || in_product || '''' || ' AND COALESCE(fim.ou_name,'''') ~* ' || '''' || in_ou_name || '''' || '
      AND COALESCE(fim.og_region,'''') ~* ' || '''' || in_og_region || '''' || ' AND COALESCE(fim.region,'''') ~* ' || '''' || in_region  || '''' || '
      AND COALESCE(fim.subregion,'''') ~* ' || '''' || in_subregion || '''' || ' AND COALESCE(fim.end_user_country_disc,'''') ~* ' || '''' || in_end_user_country_disc  || '''' || '
      AND COALESCE(fim.mother_job,'''') ~* ' || '''' || in_mother_job || '''' || ' AND COALESCE(fim.enduser_cust_name,'''') ~* ' || '''' || in_enduser_cust_name || '''' || ' 
      AND COALESCE(fim.costing_project,'''') ~* ' || '''' || in_costing_project || '''' || ' AND COALESCE(fim.order_type,'''') ~* ' || '''' || in_order_type  || '''' || '
      AND COALESCE(fim.project_manager,'''') ~* ' || '''' || in_project_manager  || '''' || ' 
 group by parts_status order by parts_status) as added
ON InnerT.parts_status = added.parts_status';

raise notice '%', v_future_sql;

execute v_future_sql;

v_finance_view_sql = 
' create or replace temp view pmo_finance_v as
    Select Type,  p_sum_cm, NULL as sales_year_qtr, cur_week, business_unit, sequence, caption,week_dt from
  (
    Select ''PMO FINANCIAL VIEW'':: character varying as Type,  p_sum_cm, Extract(week from Now()):: character varying as cur_week, 0 as week_dt, ' ||  '''' || in_new_p_and_l || '''' || ' :: character varying as business_unit, caption, 1 as sequence from
    (
    SELECT ROUND(COALESCE(SUM(COALESCE(p_sum_cm, 0)), 0), 2) as p_sum_cm, ''UNCONFIRMED'':: character varying as caption                                                      
                    from fms_ipm_master mst join fms_ipm_parts_edit_fields pef on mst.concatenate = pef.p_concatenate 
                    where  new_p_and_l  = ' || '''' || in_new_p_and_l || '''' || ' 
                        AND COALESCE(mst.p_and_l,'''') ~* ' || '''' || in_p_and_l || '''' || '
                        AND COALESCE(mst.product,'''') ~* ' || '''' || in_product || '''' || ' AND COALESCE(mst.ou_name,'''') ~* ' || '''' || in_ou_name || '''' || '
                        AND COALESCE(mst.og_region,'''') ~* ' || '''' || in_og_region || '''' || ' AND COALESCE(mst.region,'''') ~* ' || '''' || in_region  || '''' || ' 
                        AND COALESCE(mst.subregion,'''') ~* ' || '''' || in_subregion || '''' || ' AND COALESCE(mst.end_user_country_disc,'''') ~* ' || '''' || in_end_user_country_disc  || '''' || '
                        AND COALESCE(mst.mother_job,'''') ~* ' || '''' || in_mother_job || '''' || ' AND COALESCE(mst.enduser_cust_name,'''') ~* ' || '''' || in_enduser_cust_name || '''' || ' 
                        AND COALESCE(mst.costing_project,'''') ~* ' || '''' || in_costing_project || '''' || ' AND COALESCE(mst.order_type,'''') ~* ' || '''' || in_order_type  || '''' || '
                        AND COALESCE(mst.project_manager,'''') ~* ' || '''' || in_project_manager  || '''' || '
                      AND UPPER(invoice_status) = ''U''
                      AND Extract(year from COALESCE(pef.p_new_date, sales_date)) ||''-'' || Extract(quarter from COALESCE(pef.p_new_date, sales_date)) < (extract(Year from current_timestamp)||''-''||extract (quarter from current_timestamp))
    )T1
    
    UNION

    Select ''PMO FINANCIAL VIEW'':: character varying as Type,  sum(p_sum_cm) over (order by week::numeric asc)as p_sum_cm, Extract(week from Now()):: character varying as cur_week, 
      week::numeric as week_dt, ' ||  '''' || in_new_p_and_l || '''' || ' :: character varying as business_unit, caption, 2 as sequence from
    (

      select COALESCE(p_sum_cm, 0.00) as p_sum_cm, allweek.week as week, COALESCE(caption, ''CONFIRMED'') as caption from
      (

        (SELECT   generate_series as week FROM generate_series(' || v_firstweek_int || ', ' || v_lastweek_int || ')) as allweek

          LEFT OUTER JOIN

        (      
        SELECT ROUND(COALESCE(SUM(COALESCE(p_sum_cm, 0)), 0), 2) as p_sum_cm, ''CONFIRMED'':: character varying as caption,
         Extract(week from COALESCE(pef.p_new_date, sales_date)):: character varying as week
          from fms_ipm_master mst join fms_ipm_parts_edit_fields pef on mst.concatenate = pef.p_concatenate 
            where  new_p_and_l  = ' || '''' || in_new_p_and_l || '''' || ' 
                        AND COALESCE(mst.p_and_l,'''') ~* ' || '''' || in_p_and_l || '''' || '
                        AND COALESCE(mst.product,'''') ~* ' || '''' || in_product || '''' || ' AND COALESCE(mst.ou_name,'''') ~* ' || '''' || in_ou_name || '''' || '
                        AND COALESCE(mst.og_region,'''') ~* ' || '''' || in_og_region || '''' || ' AND COALESCE(mst.region,'''') ~* ' || '''' || in_region  || '''' || ' 
                        AND COALESCE(mst.subregion,'''') ~* ' || '''' || in_subregion || '''' || ' AND COALESCE(mst.end_user_country_disc,'''') ~* ' || '''' || in_end_user_country_disc  || '''' || '
                        AND COALESCE(mst.mother_job,'''') ~* ' || '''' || in_mother_job || '''' || ' AND COALESCE(mst.enduser_cust_name,'''') ~* ' || '''' || in_enduser_cust_name || '''' || ' 
                        AND COALESCE(mst.costing_project,'''') ~* ' || '''' || in_costing_project || '''' || ' AND COALESCE(mst.order_type,'''') ~* ' || '''' || in_order_type  || '''' || '
                        AND COALESCE(mst.project_manager,'''') ~* ' || '''' || in_project_manager  || '''' || '
                      AND UPPER(invoice_status) = ''C''
        AND Extract(year from COALESCE(pef.p_new_date, sales_date)) = Extract(year from current_timestamp)
        AND Extract(week from COALESCE(pef.p_new_date, sales_date)) >= ' || v_firstweek || ' AND  Extract(week from COALESCE(pef.p_new_date, sales_date)) <= ' || v_lastweek || ' 
        group by Extract(week from COALESCE(pef.p_new_date, sales_date))
        )as Weekdata
        ON allweek.week = Weekdata.week::numeric  
      )  
    )T2    

    UNION

    select ''PMO FINANCIAL VIEW'':: character varying as Type,  week_data.p_sum_cm +  old_data.p_sum_cm as p_sum_cm , Extract(week from Now()):: character varying as cur_week, 
      week_data.week::numeric as week_dt, week_data.business_unit, week_data.caption, 3 as sequence from
    (

      Select  sum(p_sum_cm) over (order by week::numeric asc)as p_sum_cm,  week, business_unit, caption from
      (
      Select COALESCE(p_sum_cm, 0.00) as p_sum_cm, allweek.week as week, COALESCE(business_unit, ' || '''' || in_new_p_and_l || '''' || ') as business_unit, 
        COALESCE(caption, ''UNCONFIRMED'') as caption from
      (

        (SELECT   generate_series as week FROM generate_series(' || v_firstweek_int || ', ' || v_lastweek_int || ')) as allweek

          LEFT OUTER JOIN
      
        (SELECT ROUND(COALESCE(SUM(COALESCE(p_sum_cm, 0)), 0), 2) as p_sum_cm, ''UNCONFIRMED'':: character varying as caption,  ' ||  '''' || in_new_p_and_l || '''' || ' :: character varying as business_unit,
            Extract(week from COALESCE(pef.p_new_date, sales_date)):: character varying as week
              from fms_ipm_master mst join fms_ipm_parts_edit_fields pef on mst.concatenate = pef.p_concatenate 
              where  new_p_and_l  =  ' || '''' || in_new_p_and_l || '''' || '  
                        AND COALESCE(mst.p_and_l,'''') ~* ' || '''' || in_p_and_l || '''' || '
                        AND COALESCE(mst.product,'''') ~* ' || '''' || in_product || '''' || ' AND COALESCE(mst.ou_name,'''') ~* ' || '''' || in_ou_name || '''' || '
                        AND COALESCE(mst.og_region,'''') ~* ' || '''' || in_og_region || '''' || ' AND COALESCE(mst.region,'''') ~* ' || '''' || in_region  || '''' || ' 
                        AND COALESCE(mst.subregion,'''') ~* ' || '''' || in_subregion || '''' || ' AND COALESCE(mst.end_user_country_disc,'''') ~* ' || '''' || in_end_user_country_disc  || '''' || '
                        AND COALESCE(mst.mother_job,'''') ~* ' || '''' || in_mother_job || '''' || ' AND COALESCE(mst.enduser_cust_name,'''') ~* ' || '''' || in_enduser_cust_name || '''' || '
                        AND COALESCE(mst.costing_project,'''') ~* ' || '''' || in_costing_project || '''' || ' AND COALESCE(mst.order_type,'''') ~* ' || '''' || in_order_type  || '''' || '
                        AND COALESCE(mst.project_manager,'''') ~* ' || '''' || in_project_manager  || '''' || '                      
             AND UPPER(invoice_status) = ''U''
             AND Extract(year from COALESCE(pef.p_new_date, sales_date)) = Extract(year from current_timestamp)
            AND Extract(week from COALESCE(pef.p_new_date, sales_date)) >= ' || v_firstweek || ' AND  Extract(week from COALESCE(pef.p_new_date, sales_date)) <= ' || v_lastweek || ' 
            group by Extract(week from COALESCE(pef.p_new_date, sales_date))
        )as Weekdata
        ON allweek.week = Weekdata.week::numeric
      )
      )T
    )week_data

    inner join 
    
    (
      Select ''PMO FINANCIAL VIEW'':: character varying as Type,  p_sum_cm, ''0'' as week, business_unit, caption, 1 as sequence from
      (  
           SELECT ROUND(COALESCE(SUM(COALESCE(p_sum_cm, 0)), 0), 2) as p_sum_cm, ''UNCONFIRMED'':: character varying as caption,  ' ||  '''' || in_new_p_and_l || '''' || ' :: character varying as business_unit                                                      
                        from fms_ipm_master mst join fms_ipm_parts_edit_fields pef on mst.concatenate = pef.p_concatenate 
                        where  new_p_and_l  = ' || '''' || in_new_p_and_l || '''' || ' 
                        AND COALESCE(mst.p_and_l,'''') ~* ' || '''' || in_p_and_l || '''' || '
                        AND COALESCE(mst.product,'''') ~* ' || '''' || in_product || '''' || ' AND COALESCE(mst.ou_name,'''') ~* ' || '''' || in_ou_name || '''' || '
                        AND COALESCE(mst.og_region,'''') ~* ' || '''' || in_og_region || '''' || ' AND COALESCE(mst.region,'''') ~* ' || '''' || in_region  || '''' || ' 
                        AND COALESCE(mst.subregion,'''') ~* ' || '''' || in_subregion || '''' || ' AND COALESCE(mst.end_user_country_disc,'''') ~* ' || '''' || in_end_user_country_disc  || '''' || '
                        AND COALESCE(mst.mother_job,'''') ~* ' || '''' || in_mother_job || '''' || ' AND COALESCE(mst.enduser_cust_name,'''') ~* ' || '''' || in_enduser_cust_name || '''' || ' 
                        AND COALESCE(mst.costing_project,'''') ~* ' || '''' || in_costing_project || '''' || ' AND COALESCE(mst.order_type,'''') ~* ' || '''' || in_order_type  || '''' || '
                        AND COALESCE(mst.project_manager,'''') ~* ' || '''' || in_project_manager  || '''' || '
                          AND UPPER(invoice_status) = ''U''
                          AND Extract(year from COALESCE(pef.p_new_date, sales_date)) ||''-'' || Extract(quarter from COALESCE(pef.p_new_date, sales_date)) < (extract(Year from current_timestamp)||''-''||extract (quarter from current_timestamp))    
                          
      )T1
    )old_data

    on week_data.business_unit = old_data.business_unit    

    
    UNION
        
    Select ''PMO FINANCIAL VIEW'':: character varying as Type,  sum(p_sum_cm) over (order by week::numeric asc)as p_sum_cm,  Extract(week from Now()):: character varying as cur_week, 
      week::numeric as week_dt, ' ||  '''' || in_new_p_and_l || '''' || ' :: character varying as business_unit, caption, 4 as sequence from  
    (
      select COALESCE(p_sum_cm, 0.00) as p_sum_cm, allweek.week as week, COALESCE(caption, ''FORECASTED'') as caption from
      (

        (SELECT   generate_series as week FROM generate_series(' || v_firstweek_int || ', ' || v_lastweek_int || ')) as allweek

          LEFT OUTER JOIN

        (SELECT ROUND(COALESCE(SUM(COALESCE(p_sum_cm, 0)), 0), 2) as p_sum_cm, ''FORECASTED'':: character varying as caption,  Extract(week from COALESCE(pef.p_new_date, sales_date)):: character varying as week 
          from fms_ipm_master mst join fms_ipm_parts_edit_fields pef on mst.concatenate = pef.p_concatenate 
          where  new_p_and_l  = ' || '''' || in_new_p_and_l || '''' || ' 
                      AND COALESCE(mst.p_and_l,'''') ~* ' || '''' || in_p_and_l || '''' || '
                      AND COALESCE(mst.product,'''') ~* ' || '''' || in_product || '''' || ' AND COALESCE(mst.ou_name,'''') ~* ' || '''' || in_ou_name || '''' || '
                      AND COALESCE(mst.og_region,'''') ~* ' || '''' || in_og_region || '''' || ' AND COALESCE(mst.region,'''') ~* ' || '''' || in_region  || '''' || ' 
                      AND COALESCE(mst.subregion,'''') ~* ' || '''' || in_subregion || '''' || ' AND COALESCE(mst.end_user_country_disc,'''') ~* ' || '''' || in_end_user_country_disc  || '''' || '
                      AND COALESCE(mst.mother_job,'''') ~* ' || '''' || in_mother_job || '''' || ' AND COALESCE(mst.enduser_cust_name,'''') ~* ' || '''' || in_enduser_cust_name || '''' || ' 
                      AND COALESCE(mst.costing_project,'''') ~* ' || '''' || in_costing_project || '''' || ' AND COALESCE(mst.order_type,'''') ~* ' || '''' || in_order_type  || '''' || '
                      AND COALESCE(mst.project_manager,'''') ~* ' || '''' || in_project_manager  || '''' || '
                      AND Extract(year from COALESCE(pef.p_new_date, sales_date)) = Extract(year from current_timestamp) 
          AND Extract(week from COALESCE(pef.p_new_date, sales_date)) >= ' || v_firstweek || ' AND  Extract(week from COALESCE(pef.p_new_date, sales_date)) <= ' || v_lastweek || ' 
          group by Extract(week from COALESCE(pef.p_new_date, sales_date))
        )as Weekdata
      ON allweek.week = Weekdata.week::numeric
      )    
    ) T4                  
  ) as ForInsert order by week_dt, sequence';

raise notice 'v_finance_view_sql : %', v_finance_view_sql;

execute v_finance_view_sql;    


IF in_flag = TRUE THEN

raise notice 'IF';


  
  INSERT INTO fms_ipm_pmo_history
  
  select parts_status, sum_cm, sales_year_qtr,  
  extract(week from current_timestamp) as week, in_new_p_and_l as business_unit , seq_parts_status

  from (select parts_status, sum_cm, sales_year_qtr, seq_parts_status from pmo_chart_v) as inner_pmo_chart;
  
-- PMO Monitor
       insert into fms_ipm_pmo_history
       
       SELECT type, sum_cm, sales_year_qtr, extract(week from current_timestamp) as week, in_new_p_and_l as business_unit, '0' as sequence, day_range AS Caption
  from (
    Select parts_status, SUM(p_sum_cm) as sum_cm, day_range, sales_year_qtr, 'BOX OLD DOGS' as type from 
      (Select parts_status, days, p_sum_cm, case when days >= 0 and days <= 30 then '0-30 days' 
                   when days >= 31 and days <= 60 then '31-60 days' 
                   when days >= 61 and days <= 90 then '61-90 days' 
                   when days >90 then '90 days' end as day_range, sales_year_qtr from 
          (SELECT mst.parts_status, (extract(days from now() - mst.box_closure_date)) as days, COALESCE(p_sum_cm, 0) as p_sum_cm, 
          (case when (mst.sales_date_year_qtr in (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) 
            or pef.p_forecast_status = 'A' ) and (pef.p_forecast_status <> 'R' or pef.p_forecast_status is null) then 'CURRENT' else 'FUTURE' end) as sales_year_qtr 
            from fms_ipm_master mst join fms_ipm_parts_edit_fields pef on mst.concatenate = pef.p_concatenate 
            WHERE mst.new_p_and_l = in_new_p_and_l AND COALESCE(mst.p_and_l,'') ~* '' AND COALESCE(mst.product,'') ~* '' 
            AND COALESCE(mst.ou_name,'') ~* '' AND COALESCE(mst.og_region,'') ~* '' AND COALESCE(mst.region,'') ~* '' 
            AND COALESCE(mst.subregion,'') ~* '' AND COALESCE(mst.end_user_country_disc,'') ~* '' 
            AND COALESCE(mst.mother_job,'') ~* '' AND COALESCE(mst.enduser_cust_name,'') ~* '' 
            AND COALESCE(mst.costing_project,'') ~* '' AND COALESCE(mst.order_type,'') ~* '' 
            AND COALESCE(mst.project_manager,'') ~* '' AND mst.sales_date_year_qtr in 
            (((extract(year from now())||'-'||extract(quarter from current_timestamp))), 
            ((extract(year from now() + (interval '3 month'))||'-'||extract(quarter from current_timestamp + (interval '3 month')))), 
            ((extract(year from now() + (interval '6 month'))||'-'||extract(quarter from current_timestamp + (interval '6 month')))), 
            ((extract(year from now() + (interval '9 month'))||'-'||extract(quarter from current_timestamp + (interval '9 month')))), 
            ((extract(year from now() + (interval '12 month'))||'-'||extract(quarter from current_timestamp + (interval '12 month'))))) 
            AND UPPER(parts_status) = 'SHIPPING' AND mst.box_closure_date IS NOT NULL ) inner1 )inner2 
        group by parts_status, day_range, sales_year_qtr order by day_range, sales_year_qtr) as PMO_monitor_Data;

       insert into fms_ipm_pmo_history
       
       SELECT type, sum_cm, sales_year_qtr, extract(week from current_timestamp) as week, in_new_p_and_l as business_unit, '0' as sequence, day_range AS Caption
  from (
    Select parts_status, SUM(p_sum_cm) as sum_cm, day_range, sales_year_qtr, 'CWD EXPIRED' as type from 
      (Select parts_status, days, p_sum_cm, case when days >= 0 and days <= 10 then '0-10 days' 
                   when days >= 11 and days <= 20 then '11-20 days' 
                   when days >= 21 and days <= 30 then '21-30 days' 
                   when days >30 then '30 days' end as day_range, sales_year_qtr from 
        (SELECT mst.parts_status, extract(days from now() - mst.so_cwd) as days, COALESCE(p_sum_cm, 0) as p_sum_cm, 
          (case when (mst.sales_date_year_qtr in (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) 
            or pef.p_forecast_status = 'A' ) and (pef.p_forecast_status <> 'R' or pef.p_forecast_status is null) then 'CURRENT' else 'FUTURE' end) as sales_year_qtr 
            from fms_ipm_master mst join fms_ipm_parts_edit_fields pef on mst.concatenate = pef.p_concatenate 
            WHERE mst.new_p_and_l = in_new_p_and_l AND COALESCE(mst.p_and_l,'') ~* '' AND COALESCE(mst.product,'') ~* '' AND COALESCE(mst.ou_name,'') ~* '' 
            AND COALESCE(mst.og_region,'') ~* '' AND COALESCE(mst.region,'') ~* '' AND COALESCE(mst.subregion,'') ~* '' 
            AND COALESCE(mst.end_user_country_disc,'') ~* '' AND COALESCE(mst.mother_job,'') ~* '' AND COALESCE(mst.enduser_cust_name,'') ~* '' 
            AND COALESCE(mst.costing_project,'') ~* '' AND COALESCE(mst.order_type,'') ~* ''
            AND COALESCE(mst.project_manager,'') ~* '' AND mst.sales_date_year_qtr in 
            (((extract(year from now())||'-'||extract(quarter from current_timestamp))), 
            ((extract(year from now() + (interval '3 month'))||'-'||extract(quarter from current_timestamp + (interval '3 month')))), 
            ((extract(year from now() + (interval '6 month'))||'-'||extract(quarter from current_timestamp + (interval '6 month')))), 
            ((extract(year from now() + (interval '9 month'))||'-'||extract(quarter from current_timestamp + (interval '9 month')))), 
            ((extract(year from now() + (interval '12 month'))||'-'||extract(quarter from current_timestamp + (interval '12 month'))))) 
            AND UPPER(parts_status) = 'INCOMING' AND mst.so_cwd IS NOT NULL AND extract(days from now() - mst.so_cwd) > 0 ) inner1 )inner2 
          group by parts_status, day_range, sales_year_qtr order by day_range, sales_year_qtr) as PMO_monitor_Data;

       insert into fms_ipm_pmo_history
       
       SELECT type, sum_cm, sales_year_qtr, extract(week from current_timestamp) as week, in_new_p_and_l as business_unit, '0' as sequence, day_range AS Caption
  from ( 
    Select parts_status, SUM(p_sum_cm) as sum_cm, day_range, sales_year_qtr, 'PROMISE DATE' as type from 
      (Select parts_status, days, p_sum_cm, case when days >= 0 and days <= 10 then '0-10 days' 
                   when days >= 11 and days <= 20 then '11-20 days' 
                   when days >= 21 and days <= 30 then '21-30 days' 
                   when days >30 then '30 days' end as day_range, sales_year_qtr from 
        (SELECT mst.parts_status, extract(days from mst.promise_date - Now()) as days, COALESCE(p_sum_cm, 0) as p_sum_cm, 
          (case when (mst.sales_date_year_qtr in (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp))
          or pef.p_forecast_status = 'A' ) and (pef.p_forecast_status <> 'R' or pef.p_forecast_status is null) then 'CURRENT' else 'FUTURE' end) as sales_year_qtr 
        from fms_ipm_master mst join fms_ipm_parts_edit_fields pef on mst.concatenate = pef.p_concatenate 
        WHERE mst.new_p_and_l = in_new_p_and_l AND COALESCE(mst.p_and_l,'') ~* '' AND COALESCE(mst.product,'') ~* '' AND COALESCE(mst.ou_name,'') ~* '' 
          AND COALESCE(mst.og_region,'') ~* '' AND COALESCE(mst.region,'') ~* '' AND COALESCE(mst.subregion,'') ~* '' 
          AND COALESCE(mst.end_user_country_disc,'') ~* '' AND COALESCE(mst.mother_job,'') ~* '' AND COALESCE(mst.enduser_cust_name,'') ~* '' 
          AND COALESCE(mst.costing_project,'') ~* '' AND COALESCE(mst.order_type,'') ~* ''
          AND COALESCE(mst.project_manager,'') ~* '' AND mst.sales_date_year_qtr in 
          (((extract(year from now())||'-'||extract(quarter from current_timestamp))), 
          ((extract(year from now() + (interval '3 month'))||'-'||extract(quarter from current_timestamp + (interval '3 month')))), 
          ((extract(year from now() + (interval '6 month'))||'-'||extract(quarter from current_timestamp + (interval '6 month')))), 
          ((extract(year from now() + (interval '9 month'))||'-'||extract(quarter from current_timestamp + (interval '9 month')))), 
          ((extract(year from now() + (interval '12 month'))||'-'||extract(quarter from current_timestamp + (interval '12 month'))))) 
        AND UPPER(parts_status) = 'INCOMING' AND mst.promise_date IS NOT NULL AND extract(days from mst.promise_date - Now()) > 0) inner1 )inner2 
      group by parts_status, day_range, sales_year_qtr order by day_range, sales_year_qtr) as PMO_monitor_Data;

       insert into fms_ipm_pmo_history
       
       SELECT type, sum_cm, sales_year_qtr, extract(week from current_timestamp) as week, in_new_p_and_l as business_unit, '0' as sequence, item_description AS Caption
  from ( 
    SELECT mst.parts_status as parts_status, SUM(COALESCE(p_sum_cm, 0)) as sum_cm, UPPER(item_description) as item_description, 
      (case when (mst.sales_date_year_qtr in (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) 
      or pef.p_forecast_status = 'A' ) and (pef.p_forecast_status <> 'R' or pef.p_forecast_status is null) then 'CURRENT' else 'FUTURE' end) as sales_year_qtr, 
    'DUMMY CODES' as type 
    from fms_ipm_master mst join fms_ipm_parts_edit_fields pef on mst.concatenate = pef.p_concatenate 
    WHERE mst.new_p_and_l = in_new_p_and_l AND COALESCE(mst.p_and_l,'') ~* '' AND COALESCE(mst.product,'') ~* '' AND COALESCE(mst.ou_name,'') ~* '' 
    AND COALESCE(mst.og_region,'') ~* '' AND COALESCE(mst.region,'') ~* '' AND COALESCE(mst.subregion,'') ~* '' AND COALESCE(mst.end_user_country_disc,'') ~* '' 
    AND COALESCE(mst.mother_job,'') ~* '' AND COALESCE(mst.enduser_cust_name,'') ~* '' AND COALESCE(mst.costing_project,'') ~* '' 
    AND COALESCE(mst.order_type,'') ~* '' AND COALESCE(mst.project_manager,'') ~* '' AND mst.sales_date_year_qtr in 
    (((extract(year from now())||'-'||extract(quarter from current_timestamp))), 
    ((extract(year from now() + (interval '3 month'))||'-'||extract(quarter from current_timestamp + (interval '3 month')))), 
    ((extract(year from now() + (interval '6 month'))||'-'||extract(quarter from current_timestamp + (interval '6 month')))), 
    ((extract(year from now() + (interval '9 month'))||'-'||extract(quarter from current_timestamp + (interval '9 month')))), 
    ((extract(year from now() + (interval '12 month'))||'-'||extract(quarter from current_timestamp + (interval '12 month'))))) 
    AND UPPER(item_description) in ('ITEM TO BE DEFINED', 'CODE TO BE CREATED', 'ORDER ACKNOWLEDGEMENT', 'OTHER') AND UPPER(parts_status) = 'INCOMING' 
    group by parts_status, item_description, sales_year_qtr order by item_description, sales_year_qtr) as PMO_monitor_Data;

-- PMO Financial view

INSERT INTO fms_ipm_pmo_history Select * from pmo_finance_v  order by sequence;
      
  


  IF extract(week from now() ) in (1, 14,27,40 ) THEN

--  raise notice 'INSIDE';

    UPDATE fms_ipm_parts_forecast as forecast set week = extract (week from current_timestamp), added = current_data.added, removed = current_data.removed, new_forecast = current_data.new_forecasted from
    (select parts_status, added, removed, new_forecasted from pmo_data_table_current_v) as current_data
    where forecast.qtr_first_day_data = TRUE
    and forecast.quarter_status = 'CURRENT'
    and forecast.new_p_and_l = in_new_p_and_l
    and forecast.parts_status = current_data.parts_status;


    UPDATE fms_ipm_parts_forecast as forecast set week = extract (week from current_timestamp), added = future_data.added, removed = future_data.removed, new_forecast = future_data.new_forecasted from
    (select parts_status, added, removed, new_forecasted from pmo_data_table_future_v) as future_data
    where forecast.qtr_first_day_data = TRUE
    and forecast.quarter_status = 'FUTURE'
    and forecast.new_p_and_l = in_new_p_and_l
    and forecast.parts_status = future_data.parts_status;
    
  
  ELSE
  
--  raise notice 'outside';
  
  
    INSERT INTO fms_ipm_parts_forecast  (quarter, year, forecast, parts_status, new_p_and_l, week, quarter_status, added, removed, new_forecast, qtr_first_day_data)

    select parts_forecast.quarter, parts_forecast.year, parts_forecast.forecast, parts_forecast.parts_status, parts_forecast.new_p_and_l,
     extract (week from current_timestamp) , parts_forecast.quarter_status, current_data.added, current_data.removed, current_data.new_forecasted, FALSE from

       (select quarter, year, forecast, parts_status, new_p_and_l, quarter_status from fms_ipm_parts_forecast where 
      fms_ipm_parts_forecast.qtr_first_day_data = TRUE and fms_ipm_parts_forecast.week is not null and fms_ipm_parts_forecast.new_p_and_l = in_new_p_and_l) as parts_forecast
      inner join 
      (select parts_status, added, removed, new_forecasted from pmo_data_table_current_v) as current_data
       
      on  parts_forecast.parts_status = current_data.parts_status
      where parts_forecast.quarter_status = 'CURRENT';
      
    
    INSERT INTO fms_ipm_parts_forecast  (quarter, year, forecast, parts_status, new_p_and_l, week, quarter_status, added, removed, new_forecast, qtr_first_day_data)

    select parts_forecast.quarter, parts_forecast.year, parts_forecast.forecast, parts_forecast.parts_status, parts_forecast.new_p_and_l,
     extract (week from current_timestamp) , parts_forecast.quarter_status, future_data.added, future_data.removed, future_data.new_forecasted, FALSE from

      (select quarter, year, forecast, parts_status, new_p_and_l, quarter_status from fms_ipm_parts_forecast where 
      fms_ipm_parts_forecast.qtr_first_day_data = TRUE and fms_ipm_parts_forecast.week is not null and fms_ipm_parts_forecast.new_p_and_l = in_new_p_and_l ) as parts_forecast
      inner join 
      (select parts_status, added, removed, new_forecasted from pmo_data_table_future_v) as future_data

      on  parts_forecast.parts_status = future_data.parts_status
      where parts_forecast.quarter_status = 'FUTURE';

  
    
  END IF;
ELSE

raise notice 'ELSE';

END IF;



select(

coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'INCOMING' and sales_year_qtr = 'CURRENT'),
'INCOMING;0;0;CURRENT')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'INCOMING' and sales_year_qtr = 'FUTURE'),
'INCOMING;0;0;FUTURE')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'AVAILABLE' and sales_year_qtr = 'CURRENT'),
'AVAILABLE;0;0;CURRENT')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'AVAILABLE' and sales_year_qtr = 'FUTURE'),
'AVAILABLE;0;0;FUTURE')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'PACKING' and sales_year_qtr = 'CURRENT'),
'PACKING;0;0;CURRENT')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'PACKING' and sales_year_qtr = 'FUTURE'),
'PACKING;0;0;FUTURE')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'BILLING' and sales_year_qtr = 'CURRENT'),
'BILLING;0;0;CURRENT')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'BILLING' and sales_year_qtr = 'FUTURE'),
'BILLING;0;0;FUTURE')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'SHIPPING' and sales_year_qtr = 'CURRENT'),
'SHIPPING;0;0;CURRENT')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'SHIPPING' and sales_year_qtr = 'FUTURE'),
'SHIPPING;0;0;FUTURE')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'SHIPPED' and sales_year_qtr = 'CURRENT'),
'SHIPPED;0;0;CURRENT')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'SHIPPED' and sales_year_qtr = 'FUTURE'),
'SHIPPED;0;0;FUTURE')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'SALES' and sales_year_qtr = 'CURRENT'),
'SALES;0;0;CURRENT')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'SALES' and sales_year_qtr = 'FUTURE'),
'SALES;0;0;FUTURE')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'BLANK' and sales_year_qtr = 'CURRENT'),
'BLANK;0;0;CURRENT')
||'~'||
coalesce((select parts_status||';'|| sum_cm||';'||seq_parts_status||';'|| sales_year_qtr from pmo_chart_v where parts_status = 'BLANK' and sales_year_qtr = 'FUTURE'),
'BLANK;0;0;FUTURE')


) into out_pmo_chart;


select( 
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_current_v where parts_status = 'INCOMING'),
'INCOMING;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_current_v where parts_status = 'AVAILABLE'),
'AVAILABLE;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_current_v where parts_status = 'PACKING'),
'PACKING;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_current_v where parts_status = 'BILLING'),
'BILLING;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_current_v where parts_status = 'SHIPPING'),
'SHIPPING;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_current_v where parts_status = 'SHIPPED'),
'SHIPPED;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_current_v where parts_status = 'SALES'),
'SALES;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_current_v where parts_status = 'BLANK'),
'BLANK;0;0;0;0') 
) 
into out_data_table_current;



select( 
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_future_v where parts_status = 'INCOMING'),
'INCOMING;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_future_v where parts_status = 'AVAILABLE'),
'AVAILABLE;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_future_v where parts_status = 'PACKING'),
'PACKING;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_future_v where parts_status = 'BILLING'),
'BILLING;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_future_v where parts_status = 'SHIPPING'),
'SHIPPING;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_future_v where parts_status = 'SHIPPED'),
'SHIPPED;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_future_v where parts_status = 'SALES'),
'SALES;0;0;0;0') 
||'~'||
coalesce((select parts_status||';'||forecasted||';'||added||';'||removed||';'||new_forecasted from pmo_data_table_future_v where parts_status = 'BLANK'),
'BLANK;0;0;0;0') 
) 
into out_data_table_future;

RAISE NOTICE 'out_data_table_future% ', out_data_table_future;
    
select array_to_string
  (array
    (
      Select TRIM(Type) ||';'||  p_sum_cm ||';'|| 'FW'||week_dt::character varying ||';'|| business_unit ||';'|| caption 
        from pmo_finance_v order by week_dt, sequence
      
    ), 
  '~') into out_data_finance;

RAISE NOTICE 'out_data_finance% ', out_data_finance;




  drop view IF EXISTS pmo_chart_v;
  drop view IF EXISTS pmo_data_table_current_v;
  drop view IF EXISTS pmo_data_table_future_v;
  drop view IF EXISTS pmo_finance_v;


  EXCEPTION WHEN OTHERS THEN 
  --ROLLBACK; 
  PERFORM fms_db_logger('fms_ipm_pmo_data_table',
           v_proc_paras ,
           sqlerrm,
           'DATABASE ERROR');    

  drop view IF EXISTS pmo_chart_v;
  drop view IF EXISTS pmo_data_table_current_v;
  drop view IF EXISTS pmo_data_table_future_v;
  drop view IF EXISTS pmo_finance_v;
           
  --RAISE NOTICE 'SQL ERROR %', sqlerrm;
  select 'DATABASE ERROR' into out_data_table_current;
  select 'DATABASE ERROR' into out_data_table_future;
  
end
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
