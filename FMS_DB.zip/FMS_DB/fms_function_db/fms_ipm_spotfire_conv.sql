-- Function: fms_ipm_spotfire_conv()

-- DROP FUNCTION fms_ipm_spotfire_conv();

CREATE OR REPLACE FUNCTION fms_ipm_spotfire_conv()
  RETURNS character varying AS
$BODY$        
DECLARE
 v_field character varying(200);
 v_status character varying(200);
 v_max_fx_rate_euro numeric;
 v_max_fx_rate_dzd numeric;
 v_count numeric;
BEGIN


Select count(*) into v_count from fms_ipm_stage;

IF v_count = 0 then
  PERFORM fms_db_logger('fms_ipm_spotfire_conv',
           '' ,
           'Error in conversion: NO data received from SpotFire DB',
           'DATABASE ERROR');    

  RETURN 'DATABASE ERROR';               
END IF;


-- concatenate
v_field = 'concatenate';

RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

Select fms_ipm_create_index('fms_ipm_stage', 'Y') into v_status;

Update fms_ipm_stage set concatenate = TRIM(costing_project::VARCHAR|| ' - ' || COALESCE(so_line, '')::VARCHAR || ' - '||
(CASE WHEN ((order_type<>'NP_FSR') OR (UPPER(ou_name)='GEII')) THEN CAST (COALESCE(line_id, 0) AS varchar) ELSE COALESCE(ibas_event_id, '') END)::varchar) ;


-- concatenate
--Select fms_ipm_create_index('fms_ipm_stage') into v_status;

Select fms_ipm_create_index('fms_ipm_stage', 'ipm_cocatenate_idx') into v_status;

RAISE notice 'Cocatenate update field fms_ipm_stage Index Done %', Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: Cocatenate update field fms_ipm_stage Index Done CurrentTime: ' || Now(),     'Test field conversion');  

--

INSERT INTO fms_ipm_parts_edit_fields (p_concatenate)
       SELECT distinct concatenate from fms_ipm_stage
       WHERE not EXISTS (SELECT 1 FROM fms_ipm_parts_edit_fields WHERE p_concatenate = fms_ipm_stage.concatenate);       

     RAISE notice 'Cocatenate Insert Concatenate field fms_ipm_parts_edit_fields Done %', Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: Cocatenate Insert Concatenate field fms_ipm_parts_edit_fields Done CurrentTime: ' || Now(),     'Test field conversion');

Select fms_ipm_create_index('fms_ipm_parts_edit_fields', 'ipm_p_cocatenate_idx') into v_status;

RAISE notice 'Cocatenate INDEX Concatenate field fms_ipm_parts_edit_fields Done %', Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: Cocatenate Insert Concatenate field fms_ipm_parts_edit_fields Done CurrentTime: ' || Now(),     'Test field conversion');  
--

-- BookingMonthNr  ***start *** 

v_field = 'BookingMonthNr';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set d_booking_month_nr = (Case when TRIM(upper(BOOKING_MONTH))='JANUARY' then 1
  when TRIM(upper(BOOKING_MONTH))='FEBRUARY' then 2
  when TRIM(upper(BOOKING_MONTH))='MARCH' then 3
  when TRIM(upper(BOOKING_MONTH))='APRIL' then 4
  when TRIM(upper(BOOKING_MONTH))='MAY' then 5
  when TRIM(upper(BOOKING_MONTH))='JUNE' then 6
  when TRIM(upper(BOOKING_MONTH))='JULY' then 7
  when TRIM(upper(BOOKING_MONTH))='AUGUST' then 8
  when TRIM(upper(BOOKING_MONTH))='SEPTEMBER' then 9
  when TRIM(upper(BOOKING_MONTH))='OCTOBER' then 10
  when TRIM(upper(BOOKING_MONTH))='NOVEMBER' then 11
  when TRIM(upper(BOOKING_MONTH))='DECEMBER' then 12
END);
-- BookingMonthNr  ***End *** 

-- Forecast2Actual 
v_field = 'Forecast2Actual';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set d_forecast_to_actual = (Case when ((PROJECT_TYPE='TX') or (PROJECT_TYPE='T & M')) and ((INVOICE_STATUS='C')) then 
  'Y'
  when ((strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) or (PROJECT_TYPE='TMGL')) and (ACTUAL_SHIPMENT_DATE is not null) and 
  (current_timestamp + (interval '15 day')>=ACTUAL_SHIPMENT_DATE) then 'Y'
else
'N'
end);

-- Forecast2Actual

-- FX Rate Eur, FX Rate Euro
v_field = 'FX Rate Eur, FX Rate Euro';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

select max(COALESCE(FX_RATE, 0)) into v_max_fx_rate_euro from fms_ipm_stage where PO_CURRENCY='EUR';
select max(COALESCE(FX_RATE, 0)) into v_max_fx_rate_dzd from fms_ipm_stage where PO_CURRENCY='DZD';

update fms_ipm_stage set d_fx_rate_euro = 
  (Case when PO_CURRENCY='EUR' THEN
    v_max_fx_rate_euro
    ELSE 0 END);
-- FX Rate Eur, FX Rate Euro

-- FX Rate DZD 
v_field = 'FX Rate DZD';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set d_fx_rate_dzd = 
  (Case when PO_CURRENCY='DZD' THEN
    v_max_fx_rate_dzd
    ELSE 0 END);
-- FX Rate DZD


-- Discount Extra Price Proportion
v_field = 'Discount Extra Price Proportion';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage as mst 
set over_d_discount_extraprice_proportion  = subquery.sum_inner 
from (Select concatenate, SUM(ORDERED_QUANTITY * UNIT_SELLING_PRICE) OVER (PARTITION BY COSTING_PROJECT) as sum_inner from fms_ipm_stage)subquery 
where  mst.concatenate = subquery.concatenate;

update fms_ipm_stage 
set d_discount_extraprice_proportion = 
(case when ((strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 0) and UPPER(ORDER_TYPE) !='NC GLOBAL SERVICES'  and UPPER(INVOICE_STATUS) <> 'C' or  INVOICE_STATUS IS NULL) 
    and  (over_d_discount_extraprice_proportion * discount_extraprice) <> 0 
  then  ORDERED_QUANTITY * UNIT_SELLING_PRICE / over_d_discount_extraprice_proportion * discount_extraprice 
else d_discount_extraprice_proportion end);

-- Discount Extra Price Proportion

-- Line True Cost
v_field = 'Line True Cost';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

Update fms_ipm_stage set d_line_true_cost = (case when (I_C='N') AND (LINE_TRUE_COST is NULL) then 
  (UNIT_COST * ORDERED_QUANTITY)
 else LINE_TRUE_COST
 end);
-- Line True Cost

-- Actual Amount
v_field = 'Actual Amount';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

Update fms_ipm_stage set d_actual_amount = (case when ADV_FLAG = 'Y' then INVOICE_AMOUNT
     when ADV_FLAG is null then COALESCE(INVOICE_AMOUNT,0) + ABS(COALESCE(REVERSAL_AMOUNT,0))
END );

-- Actual Amount

-- Actual Cost
v_field = 'Actual Cost';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set actual_cost= case when Upper(LINE_STATUS)='CLOSED' then actual_cost  else actual_cost end;

-- Actual Cost

-- Process
v_field = 'Process';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set Process =  (case when ACTUAL_SHIPMENT_DATE is not null then 'SH'
  when INVOICE_STATUS_CHANGE_DATE is not null then 'BC INV'
  when BOX_CLOSURE_DATE is not null then 'BC'
  when Upper(LINE_STATUS)='PICKED'then 'MO'
  when Upper(SUPPLY_TYPE)='ON HAND'then 'OH'
  when PROMISE_DATE is null then 'OTH'
  when Extract(Year from Now()) > Extract(Year from PROMISE_DATE) then 'OLD'
  when Extract(Year from Now()) < Extract(Year from PROMISE_DATE) then 'FUT'
  when Extract(Year from Now()) = Extract(Year from PROMISE_DATE) then to_char(PROMISE_DATE, 'month')
end );

-- Process

-- TT Date Modified
v_field = 'TT Date Modified';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set d_tt_date_modified= 
(CASE WHEN INVOICE_STATUS='U' then
   (CASE when extract(quarter from current_timestamp)=1 then cast(extract(year from current_timestamp)||'/3/1' as date)
    when extract(quarter from current_timestamp)=2 then cast(extract(year from current_timestamp)||'/6/1' as date)
    when extract(quarter from current_timestamp)=3 then cast(extract(year from current_timestamp)||'/9/1' as date)
    when extract(quarter from current_timestamp)=4 then cast(extract(year from current_timestamp)||'/12/1' as date)
   end)
      WHEN ((extract(month from current_timestamp)=3) or (extract(month from current_timestamp)=6) or (extract(month from current_timestamp)=9) or (extract(month from current_timestamp)=12)) and (Product='Parts') and (SUPPLY_TYPE='ON HAND') and (SUPPLY_TYPE is not NULL) then
    cast (extract(year from current_timestamp)||'/'||extract(month from current_timestamp)||'/'||1 as date)+(interval '9 day'*COALESCE(TT_TIME::int,0)) 
      WHEN OU_NAME='GEII' THEN cast(TT_DATE as date)
      when Upper(Product)<>'PARTS' then cast(TT_DATE as date)
ELSE
(case when ((Upper(Product)='PARTS') and ((PROJECT_TYPE='TX') or (PROJECT_TYPE='T & M'))) or ((Upper(Product)='PARTS') and ((PROJECT_TYPE!='TX') or (PROJECT_TYPE!='T & M')) and (ACTUAL_SHIPMENT_DATE is NULL)) then
  (case when(Upper(LINE_STATUS)<>'BOOKED') or (LINE_STATUS is NULL) then
    (case when(Upper(LINE_STATUS)<>'ENTERED') or (upper(LINE_STATUS) is NULL) then
      (case when Process='OTH' then
        (CASE when ((LEAD_TIME is NULL) or (LEAD_TIME=0)) and (current_timestamp + (interval '92 day')>=SO_CWD) then
          current_timestamp + (interval '92 day')
              when (SO_CWD<current_timestamp) and (LEAD_TIME is not NULL) then
          current_timestamp + (interval '1 day'*COALESCE(LEAD_TIME::int,0))
              when ((LEAD_TIME is NULL) or (LEAD_TIME=0)) and (current_timestamp + (interval '92 day')<SO_CWD) then
            SO_CWD
              WHEN current_timestamp + (interval '1 day'*COALESCE(LEAD_TIME::int,0))>=SO_CWD then
            current_timestamp + (interval '1 day'*COALESCE(LEAD_TIME::int,0))
              WHEN current_timestamp + (interval '1 day'*COALESCE(LEAD_TIME::int,0))<SO_CWD then
          SO_CWD
        end)
            when (Upper(SUPPLY_TYPE)<>'PLANNED ORDER') or (SUPPLY_TYPE is NULL) or (Upper(SUPPLY_TYPE)<>'PO IN RECEIVING') then cast(TT_DATE as date)
      else SO_CWD
      end) 
     else SO_CWD end) 
  else SO_CWD end) 
  else 
    (case when(Upper(Product)='PARTS') and ((PROJECT_TYPE!='TX') or (PROJECT_TYPE!='T & M')) and (ACTUAL_SHIPMENT_DATE is not NULL) then
      ACTUAL_SHIPMENT_DATE + (interval '15 day') 
    end)
End)
END);
-- TT Date Modified


-- Title Transfer Date
v_field = 'Title Transfer Date';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage as mst
set over_title_transfer_date  = subquery.max_inner
from
(Select concatenate, Max(d_tt_date_modified) over (partition by COSTING_PROJECT,OU_NAME,Site,d_forecast_to_actual) as max_inner from fms_ipm_stage)subquery 
where  mst.concatenate = subquery.concatenate;

update fms_ipm_stage set title_transfer_date = (case when (Upper(Product)='PARTS') and (Upper(LINE_STATUS)<>'CLOSED') and (upper(OU_NAME)<>'GEII') then
(case when (CONTR_PAR_SHIP_ALLWD='Y') or (CONTR_PAR_SHIP_ALLWD is NULL) then d_tt_date_modified
when CONTR_PAR_SHIP_ALLWD='N' then over_title_transfer_date
end) else d_tt_date_modified end);

-- Title Transfer Date

-- Booking Quarter
v_field = 'Booking Quarter';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set d_booking_quarter = (Case when TRIM(upper(BOOKING_MONTH))='JANUARY' or TRIM(upper(BOOKING_MONTH))='FEBRUARY' or TRIM(upper(BOOKING_MONTH))='MARCH' then 
 BOOKING_YEAR || '-' || '1'
 when TRIM(upper(BOOKING_MONTH))='APRIL' or TRIM(upper(BOOKING_MONTH))='MAY' or TRIM(upper(BOOKING_MONTH))='JUNE' then 
 BOOKING_YEAR || '-' || '2'
 when TRIM(upper(BOOKING_MONTH))='JULY' or TRIM(upper(BOOKING_MONTH))='AUGUST' or TRIM(upper(BOOKING_MONTH))='SEPTEMBER' then 
 BOOKING_YEAR || '-' || '3'
 when TRIM(upper(BOOKING_MONTH))='OCTOBER' or TRIM(upper(BOOKING_MONTH))='NOVEMBER' or TRIM(upper(BOOKING_MONTH))='DECEMBER' then 
 BOOKING_YEAR || '-' || '4'
END);
-- Booking Quarter




-- TT Date Modified YQ Calc
v_field = 'TT Date Modified YQ Calc';


RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

update fms_ipm_stage set d_tt_date_mod_yq_calc = (CASE WHEN INVOICE_STATUS='U' then
(CASE when EXTRACT(QUARTER FROM current_timestamp)=1 then EXTRACT(year FROM d_tt_date_modified)||'-'||EXTRACT(quarter FROM d_tt_date_modified)
 when EXTRACT(QUARTER FROM current_timestamp)=2 then EXTRACT(year FROM d_tt_date_modified)||'-'||EXTRACT(quarter FROM d_tt_date_modified)
 when EXTRACT(QUARTER FROM current_timestamp)=3 then EXTRACT(year FROM d_tt_date_modified)||'-'||EXTRACT(quarter FROM d_tt_date_modified)
 when EXTRACT(QUARTER FROM current_timestamp)=4 then EXTRACT(year FROM d_tt_date_modified)||'-'||EXTRACT(quarter FROM d_tt_date_modified)
 end)
WHEN ((EXTRACT(month FROM current_timestamp)=3) or (EXTRACT(month FROM current_timestamp)=6) or (EXTRACT(month FROM current_timestamp)=9) or (EXTRACT(month FROM current_timestamp)=12)) and (Product='Parts') and (SUPPLY_TYPE='ON HAND') and (SUPPLY_TYPE is not NULL) then
 EXTRACT(year FROM d_tt_date_modified)||'-'||EXTRACT(quarter FROM d_tt_date_modified)
WHEN OU_NAME='GEII' THEN EXTRACT(year FROM d_tt_date_modified)||'-'||EXTRACT(quarter FROM d_tt_date_modified)
when Upper(Product)<>'PARTS' then EXTRACT(year FROM d_tt_date_modified)||'-'||EXTRACT(quarter FROM d_tt_date_modified)
ELSE
(case when((Upper(Product)='PARTS') and ((PROJECT_TYPE='TX') or (PROJECT_TYPE='T & M'))) or ((Upper(Product)='PARTS') and ((PROJECT_TYPE!='TX') or (PROJECT_TYPE!='T & M')) and (ACTUAL_SHIPMENT_DATE is NULL)) then
 (case when(upper(LINE_STATUS)<>'BOOKED') or (upper(LINE_STATUS) is NULL) then
   (case when(Upper(LINE_STATUS)<>'ENTERED') or (upper(LINE_STATUS) is NULL) then
    (case when d_forecast_to_actual='N' then (case when Process='OTH' then
      (CASE when (SO_CWD<current_timestamp) and (LEAD_TIME is not NULL) then
        EXTRACT(year FROM d_tt_date_modified)||'-'||EXTRACT(quarter FROM d_tt_date_modified)
       when ((LEAD_TIME is NULL) or (LEAD_TIME=0)) and ((current_timestamp + (interval '92 day'))>=SO_CWD) then
        EXTRACT(year FROM d_tt_date_modified)||'-'||EXTRACT(quarter FROM d_tt_date_modified)
       when ((LEAD_TIME is NULL) or (LEAD_TIME=0)) and ((current_timestamp + (interval '92 day'))<SO_CWD) then
        EXTRACT(year FROM d_tt_date_modified)||'-'||EXTRACT(quarter FROM d_tt_date_modified)
       WHEN (((current_timestamp + (interval '1 day')*COALESCE(LEAD_TIME::int,0)))>=SO_CWD) OR (LEAD_TIME is NULL) then
        EXTRACT(year FROM d_tt_date_modified)||'-'||EXTRACT(quarter FROM d_tt_date_modified)
       WHEN ((current_timestamp + (interval '1 day')*COALESCE(LEAD_TIME::int,0)))<SO_CWD then
        EXTRACT(year FROM d_tt_date_modified)||'-'||EXTRACT(quarter FROM d_tt_date_modified)
      end)
     when (Upper(SUPPLY_TYPE)<>'PLANNED ORDER') or (SUPPLY_TYPE is NULL) or (Upper(SUPPLY_TYPE)<>'PO IN RECEIVING') then extract(year from cast(tt_date as date))||'-'||extract(quarter from cast(tt_date as date))
     else extract(year from SO_CWD)||'-'||extract(quarter from SO_CWD) end)
    else 'BILLED' END)
   else extract(year from SO_CWD)||'-'||extract(quarter from SO_CWD) End)
  else extract(year from SO_CWD)||'-'||extract(quarter from SO_CWD) End)
else (case when(Upper(Product)='PARTS') and ((PROJECT_TYPE!='TX') or (PROJECT_TYPE!='T & M')) and (ACTUAL_SHIPMENT_DATE is not NULL) then
 extract( year from (ACTUAL_SHIPMENT_DATE + (interval '15 day')))||'-'||extract( quarter from (ACTUAL_SHIPMENT_DATE + (interval '15 day'))) End)
END)
END);

-- TT Date Modified YQ Calc


-- Title Transfer Date (Year-Quarter)
v_field = 'Title Transfer Date (Year-Quarter)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage as mst set over_title_transfer_date_year_qtr = subquery.max_inner from
(Select concatenate, max(d_tt_date_mod_yq_calc) over (partition by COSTING_PROJECT,OU_NAME,Site,d_forecast_to_actual) as max_inner from fms_ipm_stage)subquery 
where  mst.concatenate = subquery.concatenate;

update fms_ipm_stage set title_transfer_date_year_qtr = (case when (Upper(Product)='PARTS') and (Upper(LINE_STATUS)<>'CLOSED') and (OU_NAME<>'GEII') then
 (case when (CONTR_PAR_SHIP_ALLWD='Y') or (CONTR_PAR_SHIP_ALLWD = NULL)
 then
 d_tt_date_mod_yq_calc
 when CONTR_PAR_SHIP_ALLWD='N' then 
 over_title_transfer_date_year_qtr
 end)
 else d_tt_date_mod_yq_calc end);

-- Title Transfer Date (Year-Quarter)

-- Forecast Date
v_field = 'Forecast Date';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set forecast_date = (case when c_COMMITMENT_DATE IS NOT NULL then  c_commitment_date 
          else title_transfer_date end);


/*
update fms_ipm_stage set forecast_date = (case when (select max(c_commitment_date) from fms_ipm_stage where c_COMMITMENT_DATE IS NOT NULL) 
  IS NOT NULL then  (select max(c_commitment_date) from fms_ipm_stage ) else title_transfer_date end);
*/

-- Forecast Date

-- Forecast Date (Year-Quarter)
v_field = 'Forecast Date (Year-Quarter)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set forecast_date_year_qtr = extract(year from forecast_date)||'-'||extract(quarter from forecast_date);

/*
update fms_ipm_stage set forecast_date_year_qtr = (case when (select max(c_commitment_date) from fms_ipm_stage where c_COMMITMENT_DATE IS NOT NULL) IS NOT NULL then (Select extract(year from max(c_COMMITMENT_DATE)) || '-' || extract(quarter from max(c_COMMITMENT_DATE)) from fms_ipm_stage)
else title_transfer_date_year_qtr end);
*/
-- Forecast Date (Year-Quarter)

-- Sales Date
v_field = 'Sales Date';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set INVOICE_STATUS_CHANGE_DATE = null where INVOICE_STATUS_CHANGE_DATE = 'DTS Technology Services (TS)';

update fms_ipm_stage set sales_date= (CASE WHEN NEW_P_AND_L='DTS' THEN
(CASE WHEN INVOICE_STATUS_CHANGE_DATE IS NOT NULL THEN cast(INVOICE_STATUS_CHANGE_DATE as date)
ELSE forecast_date END)
WHEN NEW_P_AND_L='TMS' THEN
(case when (OU_NAME<>'GEII') and (Product='Parts') then
(case when c_COMMITMENT_DATE IS NOT NULL then c_commitment_date 
when OU_NAME='GEII' THEN forecast_date
WHEN (PROJECT_TYPE is not NUll) and (((strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) or (Upper(PROJECT_TYPE)='TMGL')) or (Upper(INVOICE_STATUS)<>'C') or (INVOICE_STATUS is NUll)) THEN forecast_date else
cast(INVOICE_STATUS_CHANGE_DATE as date) END) else
(case when c_COMMITMENT_DATE IS NOT NULL then c_commitment_date
when OU_NAME='GEII' THEN forecast_date
WHEN (PROJECT_TYPE is not NUll) and (((strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) or (Upper(PROJECT_TYPE)='TMGL')) or (Upper(INVOICE_STATUS)<>'C') or (INVOICE_STATUS is NUll)) THEN forecast_date else
cast(INVOICE_STATUS_CHANGE_DATE as date) END) END) END);

-- Sales Date

-- Sales Date (Year-Quarter)
v_field = 'Sales Date (Year-Quarter)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set sales_date_year_qtr = extract(year from sales_date)||'-'||extract(quarter from sales_date);

Select fms_ipm_create_index('fms_ipm_stage', 'ipm_sales_date_year_qtr_idx') into v_status;

PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion INDEX : ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

/*
update fms_ipm_stage set sales_date_year_qtr = (CASE WHEN (OU_NAME<>'GEII') and (Product='Parts') and (NEW_P_AND_L='TMS') THEN
  (case when (select Max(c_COMMITMENT_DATE) from   fms_ipm_stage where c_COMMITMENT_DATE IS NOT NULL) is not null then
      (Select extract(year from max(c_COMMITMENT_DATE)) || '-' || extract(quarter from max(c_COMMITMENT_DATE)) from fms_ipm_stage)
   when OU_NAME='GEII' THEN forecast_date_year_qtr 
   WHEN (PROJECT_TYPE is not NULL) and (((strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) or (Upper(PROJECT_TYPE)='TMGL')) or (Upper(INVOICE_STATUS)<>'C') or (INVOICE_STATUS is NULL)) THEN forecast_date_year_qtr
     else
    extract(year from cast(INVOICE_STATUS_CHANGE_DATE as date))||'-'||extract(quarter from cast(INVOICE_STATUS_CHANGE_DATE as date))
     END)
 else
   (case when (select Max(c_COMMITMENT_DATE) from   fms_ipm_stage where c_COMMITMENT_DATE IS NOT NULL) is not null then
      (Select extract(year from max(c_COMMITMENT_DATE)) || '-' || extract(quarter from max(c_COMMITMENT_DATE)) from fms_ipm_stage)
   when OU_NAME='GEII' THEN forecast_date_year_qtr 
   WHEN (PROJECT_TYPE is not NULL) and (((strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) or (Upper(PROJECT_TYPE)='TMGL')) or (Upper(INVOICE_STATUS)<>'C') or (INVOICE_STATUS is NULL)) THEN forecast_date_year_qtr
     else
    extract(year from cast(INVOICE_STATUS_CHANGE_DATE as date))||'-'||extract(quarter from cast(INVOICE_STATUS_CHANGE_DATE as date))
     END)  
 end);*/
-- Sales Date (Year-Quarter)

-- Booking Date (Year-Month)
v_field = 'Booking Date (Year-Month)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set booking_date_year_mnth  =  BOOKING_YEAR||' - '||BOOKING_MONTH;

-- Booking Date (Year-Month)

-- BUC Code
v_field = 'BUC Code';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set buc_code =
(case  when (PROJECT_TYPE is not NULL) and ((PROJECT_TYPE = 'TX') or (PROJECT_TYPE = 'T & M')) then 'NA' 
                  when (PROJECT_TYPE is not NULL) and ((strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) or (PROJECT_TYPE= 'TMGL')) and ((I_C is NULL) or (I_C='N')) then 'NA' 
                  when PROJECT_TYPE is NULL then 'NA'
else 
                COALESCE(BUC_CODE,'NA')
END);
-- BUC Code


-- CM %
v_field = 'CM %';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set cm_percent = ROUND(COALESCE(CM_PERCENT::numeric, 0), 2);
-- CM %

-- Line Sales Forecast ($)

RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

v_field = 'Line Sales Forecast ($)';

update fms_ipm_stage set line_sales_forecast_dollar = 
  (case when (OU_NAME='GEII') and (sales_date_year_qtr>=(extract(year from current_timestamp)||'-'||extract(Quarter from current_timestamp) )::character varying) then UNIT_SELLING_PRICE * ORDERED_QUANTITY 
   else
      (case when (strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) or (Upper(PROJECT_TYPE)='TMGL') then 
    (case when (ACTUAL_SHIPMENT_DATE is null) or (current_timestamp < (ACTUAL_SHIPMENT_DATE + (interval '1 day'* 15))) and 
      ((1 - (CM_GLOBAL_CONTRACT / 100)) * 
        (CASE WHEN OU_NAME='OU_NP_IT' THEN v_max_fx_rate_euro
                    WHEN OU_NAME='OU_AM_US' THEN 1
                    WHEN OU_NAME='OU_TD_FR' THEN v_max_fx_rate_euro 
                    WHEN OU_NAME='OU_NA_DZ' THEN v_max_fx_rate_dzd 
               END)) <> 0 then 
               
        d_line_true_cost / (1 - (CM_GLOBAL_CONTRACT / 100)) * 
        (CASE WHEN OU_NAME='OU_NP_IT' THEN v_max_fx_rate_euro
                    WHEN OU_NAME='OU_AM_US' THEN 1
                    WHEN OU_NAME='OU_TD_FR' THEN v_max_fx_rate_euro
                    WHEN OU_NAME='OU_NA_DZ' THEN v_max_fx_rate_dzd
               END)
      end) 
      else 
       (case when ((PROJECT_TYPE='TX') or (PROJECT_TYPE='T & M')) and (Upper(ORDER_TYPE)!='NC GLOBAL SERVICES') and ((Upper(INVOICE_STATUS)!='C') or (INVOICE_STATUS is null)) and 
      (COALESCE(CUSTOMER_PO_AMOUNT, 0) - COALESCE(DISCOUNT_EXTRAPRICE,0)) * COALESCE(FX_RATE, 0) <> 0 then 
      ORDERED_QUANTITY * UNIT_SELLING_PRICE * (1 + (COALESCE(DISCOUNT_EXTRAPRICE,0) / (COALESCE(CUSTOMER_PO_AMOUNT, 0) - COALESCE(DISCOUNT_EXTRAPRICE,0)))) * FX_RATE else 
         null end) 
     end) 
   end); 


-- Line Sales Forecast ($)

-- Line CM Forecast ($)
v_field = 'Line CM Forecast ($)';

RAISE notice 'Start % :- %', v_field, Now();   
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

update fms_ipm_stage set line_cm_forecast_dollar =
(case when (OU_NAME='GEII') and (sales_date_year_qtr>=(extract(Year from current_timestamp)||'-'||extract(Quarter from current_timestamp))::character varying) then
 (case when line_sales_forecast_dollar<>0 then
 UNIT_SELLING_PRICE * ORDERED_QUANTITY * (COALESCE(Round(CM_PERCENT::numeric, 2), 0) / 100)
 when (line_sales_forecast_dollar=0) and (AMT_NOT_READY<>0) then
 AMT_NOT_READY
 end) else
(case when (strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1 or (Upper(PROJECT_TYPE)='TMGL')) and ((ACTUAL_SHIPMENT_DATE is NULL) or 
 (current_timestamp< ACTUAL_SHIPMENT_DATE+(interval '1 day'*15))) then
 line_sales_forecast_dollar - (unit_true_cost * ORDERED_QUANTITY * (
CASE WHEN OU_NAME='OU_NP_IT' THEN v_max_fx_rate_euro
WHEN OU_NAME='OU_AM_US' THEN 1
WHEN OU_NAME='OU_TD_FR' THEN v_max_fx_rate_euro
WHEN OU_NAME='OU_NA_DZ' THEN v_max_fx_rate_dzd
END)) else
(case when (strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 0) and (Upper(ORDER_TYPE)!='NC GLOBAL SERVICES') and ((Upper(INVOICE_STATUS)<>'C') or (INVOICE_STATUS is NULL)) then
line_sales_forecast_dollar * (COALESCE(Round(CM_PERCENT::numeric, 2), 0) / 100) else
NULL end) end)end);
-- Line CM Forecast ($)

-- Cumcatch
/* Not required
v_field = 'Cumcatch';

update fms_ipm_stage as mst set over_cumcatch_1 = subquery.sum_inner
from
(Select concatenate,((Sum((case when d_not_duplicate then line_sales_forecast_dollar - line_cm_forecast_dollar end)) over (partition by COSTING_PROJECT) / ((1 - COALESCE(Round(CM_PERCENT::numeric, 0), 0)) * 100)) - (
                 Sum((case when d_not_duplicate then line_sales_forecast_dollar - line_cm_forecast_dollar end)) over (partition by COSTING_PROJECT) / ((1 - CM_GLOBAL_CONTRACT) * 100))) as sum_inner from fms_ipm_stage)subquery 
where  mst.concatenate = subquery.concatenate;


update fms_ipm_stage as mst set over_cumcatch_2  = subquery.sum_inner
from
(Select concatenate,((Sum((case when d_not_duplicate then actual_cost end)) over (partition by COSTING_PROJECT) / ((1 - COALESCE(Round(CM_PERCENT::numeric, 0), 0)) * 100)) - (
                 Sum((case when d_not_duplicate then actual_cost end)) over (partition by COSTING_PROJECT) / ((1 - CM_GLOBAL_CONTRACT) * 100))) as sum_inner from fms_ipm_stage)subquery 
where  mst.concatenate = subquery.concatenate;


update fms_ipm_stage as mst set cumcatch = 
(((case when (strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 0) then 0 else
        (case when (AMOUNT_SHIPPED is NULL) or (AMOUNT_SHIPPED=0) then over_cumcatch_1
     else over_cumcatch_2 end) end)) * FX_Rate);
*/
-- Cumcatch

-- Non-Standard Line Billed Amount
v_field = 'Non-Standard Line Billed Amount';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

Update fms_ipm_stage set d_nonstd_line_bill_amt= (case when (actual_shipment_date IS NOT NULL and line_billed_amt IS NULL) then 
                case when (strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1 or UPPER(PROJECT_TYPE) = 'TMGL') and (1 - (cm_global_contract / 100)) <> 0  
      then d_line_true_cost /(1 - (cm_global_contract / 100)) 
                                                                else ((ordered_quantity *unit_selling_price) + COALESCE(d_discount_extraprice_proportion,0))end
                else d_nonstd_line_bill_amt end);
-- Non-Standard Line Billed Amount

--Invoice Amount Proportional
v_field = 'Invoice Amount Proportional';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage as mst set over_d_invoice_amt_prop  = coalesce(subquery.sum_inner, 1)
from (Select concatenate, SUM(COALESCE(LINE_BILLED_AMT,0) + COALESCE(d_nonstd_line_bill_amt,0)) OVER (PARTITION BY INVOICE_NUMBER) as sum_inner from fms_ipm_stage)subquery 
where  mst.concatenate = subquery.concatenate;

update fms_ipm_stage set d_invoice_amt_prop = (case when ((strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 0) and UPPER(ORDER_TYPE) !='NC GLOBAL SERVICES' and  UPPER(INVOICE_STATUS) = 'C')
  and over_d_invoice_amt_prop * invoice_amount <> 0 then 
(COALESCE(LINE_BILLED_AMT,0) + COALESCE(d_nonstd_line_bill_amt,0))/coalesce(over_d_invoice_amt_prop * invoice_amount, 1) 
else d_invoice_amt_prop end) ;

-- Invoice Amount Proportional

-- Customer P.O. Amount Billed Confirmed
/*
v_field = 'Customer P.O. Amount Billed Confirmed';

update fms_ipm_stage as mst set cust_po_amt_bill_conf  = subquery.sum_inner from 
(select concatenate, (FX_rate * (sum((select d_invoice_amt_prop from fms_ipm_stage where ((Upper(INVOICE_STATUS)= 'C') and (INVOICE_STATUS is not null)) and d_not_duplicate)) over (partition by COSTING_PROJECT)))as sum_inner from fms_ipm_stage) subquery 
where  mst.concatenate = subquery.concatenate; 
*/
-- Customer P.O. Amount Billed Confirmed

-- CWD (Year-Quarter)
v_field = 'CWD (Year-Quarter)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set cwd_year_qtr = CWD_YEAR || '-' ||substring(CWD_QUARTER from 2 for 1);

-- CWD (Year-Quarter)

-- Legal Entity Code new
v_field = 'Legal Entity Code new';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set legal_entity_code_new =
CASE WHEN OU_NAME = 'GEII' then IBAS_EVENT_ID
                else LEGAL_ENTITY_CODE::text
end; 

-- Legal Entity Code new
      
-- Line  Cost  (�)
v_field = 'Line Cost(�)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');
update fms_ipm_stage set line_cost_euro =
       (case when COALESCE(unit_true_cost,0)>0 then 
                  unit_true_cost*ordered_quantity 
        else 
               case when COALESCE(UNIT_COST, 0) > 0 then
                            UNIT_COST*ordered_quantity 
               else ordered_quantity*unit_selling_price * (1- COALESCE(Round(CM_PERCENT::numeric, 2), 0)/100) 
           end
        end
    ) * (FX_RATE / fx_rate_eur)
where fx_rate_eur <> 0;

-- Line  Cost  (�)

-- Invoice Proportional Actual
v_field = 'Invoice Proportional Actual';

RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

update fms_ipm_stage as mst set over_d_invoice_prop_actual  = COALESCE(subquery.sum_inner, 0) from 
  (Select concatenate, SUM(COALESCE(LINE_BILLED_AMT,0) + COALESCE(d_nonstd_line_bill_amt,0)) OVER (PARTITION BY INVOICE_NUMBER, site) as sum_inner from fms_ipm_stage)subquery 
  where  mst.concatenate = subquery.concatenate;

update fms_ipm_stage set d_invoice_prop_actual = (case when ((strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 0) and UPPER(ORDER_TYPE) !='NC GLOBAL SERVICES' and  UPPER(INVOICE_STATUS) = 'C') 
  and (over_d_invoice_prop_actual::numeric * d_actual_amount) <> 0 then 
(COALESCE(LINE_BILLED_AMT,0) + COALESCE(d_nonstd_line_bill_amt,0))/over_d_invoice_prop_actual::numeric * d_actual_amount 
else d_invoice_prop_actual end) ;

-- Invoice Proportional Actual

-- Line Sales Actual ($)
v_field = 'Line Sales Actual ($)';

RAISE notice 'Start % :- %', v_field, Now();   
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

update fms_ipm_stage set line_sales_actual_dollar = 
  (case when (OU_NAME='GEII') and (sales_date_year_qtr<extract(year from current_timestamp)||'-'||extract(Quarter from current_timestamp)) then 
    (UNIT_SELLING_PRICE * ORDERED_QUANTITY) 
    else
    (case when ((strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) or (Upper(PROJECT_TYPE)='TMGL')) and (ACTUAL_SHIPMENT_DATE is not NULL) and 
      (current_timestamp >= ACTUAL_SHIPMENT_DATE + (interval '1 day' * 15)) and
      (1 - (CM_GLOBAL_CONTRACT / 100)) * (
          CASE WHEN OU_NAME='OU_NP_IT' THEN v_max_fx_rate_euro
            WHEN OU_NAME='OU_AM_US' THEN 1
            WHEN OU_NAME='OU_TD_FR' THEN v_max_fx_rate_euro
            WHEN OU_NAME='OU_NA_DZ' THEN v_max_fx_rate_dzd
            END) <> 0 then
        d_line_true_cost / (1 - (CM_GLOBAL_CONTRACT / 100)) * (
          CASE WHEN OU_NAME='OU_NP_IT' THEN v_max_fx_rate_euro
            WHEN OU_NAME='OU_AM_US' THEN 1
            WHEN OU_NAME='OU_TD_FR' THEN v_max_fx_rate_euro
            WHEN OU_NAME='OU_NA_DZ' THEN v_max_fx_rate_dzd
            END) 
          else (case when ((PROJECT_TYPE='TX') or (PROJECT_TYPE='T & M')) and (Upper(ORDER_TYPE)!='NC GLOBAL SERVICES') and (Upper(INVOICE_STATUS)='C') then
            (d_invoice_prop_actual * FX_RATE) else NULL end) 
    end) 
  end);

-- Line Sales Actual ($)

-- Line Sales $ (d_line_sales_dollar)
v_field = 'Line Sales $ (d_line_sales_dollar)';

RAISE notice 'Start % :- %', v_field, Now();   
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

update fms_ipm_stage set d_line_sales_dollar  = 

      (case when line_sales_actual_dollar is NULL 
        then line_sales_forecast_dollar 
       else line_sales_actual_dollar 
       end);
-- Line Sales $ (d_line_sales_dollar)

-- Line Sales � (line_sales_euro)
v_field = 'Line Sales � (line_sales_euro)';

RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

update fms_ipm_stage set line_sales_euro =
  (CASE WHEN (strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) AND (PROJECT_TYPE is not NULL) AND (COALESCE(Round(CM_PERCENT::numeric, 2), 0)!=100) THEN
    line_cost_euro / (1 - (COALESCE(Round(CM_PERCENT::numeric, 2), 0) / 100))
        WHEN (strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) AND (PROJECT_TYPE is not NULL) AND (COALESCE(Round(CM_PERCENT::numeric, 2), 0)=100) THEN 
    line_cost_euro / (1 - (99 / 100))
    ELSE
    (CASE WHEN (PO_CURRENCY='EUR') AND ((DISCOUNT_EXTRAPRICE IS NULL) or (DISCOUNT_EXTRAPRICE=0)) THEN
      ORDERED_QUANTITY * UNIT_SELLING_PRICE
    WHEN (PO_CURRENCY='EUR') AND (DISCOUNT_EXTRAPRICE IS NOT NULL) and ((COALESCE(CUSTOMER_PO_AMOUNT, 0) - COALESCE(DISCOUNT_EXTRAPRICE,0)) <> 0 ) THEN
      ORDERED_QUANTITY * UNIT_SELLING_PRICE * (1 + (COALESCE(DISCOUNT_EXTRAPRICE,0) / (CUSTOMER_PO_AMOUNT - COALESCE(DISCOUNT_EXTRAPRICE,0))))
    WHEN (PO_CURRENCY='USD') AND ((DISCOUNT_EXTRAPRICE IS NULL) or (DISCOUNT_EXTRAPRICE=0)) THEN 
      ORDERED_QUANTITY * UNIT_SELLING_PRICE
    WHEN (PO_CURRENCY='USD') AND (DISCOUNT_EXTRAPRICE IS NOT NULL) AND ((COALESCE(CUSTOMER_PO_AMOUNT, 0) - COALESCE(DISCOUNT_EXTRAPRICE,0)) <> 0 ) and fx_rate_eur <> 0 THEN
      ORDERED_QUANTITY * UNIT_SELLING_PRICE * (1 + (COALESCE(DISCOUNT_EXTRAPRICE,0) / (CUSTOMER_PO_AMOUNT - COALESCE(DISCOUNT_EXTRAPRICE,0)))) / fx_rate_eur
    WHEN (PO_CURRENCY!='USD') AND (PO_CURRENCY!='EUR') AND ((DISCOUNT_EXTRAPRICE IS NULL) OR (DISCOUNT_EXTRAPRICE=0)) and fx_rate_eur <> 0 THEN
      ORDERED_QUANTITY * UNIT_SELLING_PRICE * FX_RATE / fx_rate_eur
    WHEN ((COALESCE(CUSTOMER_PO_AMOUNT, 0) - COALESCE(DISCOUNT_EXTRAPRICE,0)) <> 0 ) and fx_rate_eur <> 0 THEN
      ORDERED_QUANTITY * UNIT_SELLING_PRICE * FX_RATE * (1 + (COALESCE(DISCOUNT_EXTRAPRICE,0) / (CUSTOMER_PO_AMOUNT - COALESCE(DISCOUNT_EXTRAPRICE,0)))) / fx_rate_eur
   end)
  end);


-- Line Sales � (line_sales_euro)

-- Line Sales(�) (line_sales_euro_conditional)
v_field = 'Line Sales(�) (line_sales_euro_conditional)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set line_sales_euro_conditional = 
(case when line_sales_euro is null then d_line_sales_dollar else line_sales_euro end);

-- Line Sales  (�) (line_sales_euro_conditional)

-- Line Sales ($) (line_sales_dollar_conditional)
v_field = 'Line Sales($) (line_sales_dollar_conditional)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set line_sales_dollar_conditional = 
(case when d_line_sales_dollar is null then line_sales_euro else d_line_sales_dollar end);
-- Line Sales ($) (line_sales_dollar_conditional)


-- Line  Cost  ($)
v_field = 'Line Cost($)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set d_line_cost_dol = line_cost_euro * FX_RATE;

-- Line  Cost  ($)

-- Line CM ($)
v_field = 'Line CM($)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set line_cm_dollar  = coalesce(line_sales_dollar_conditional, 0) - coalesce(d_line_cost_dol, 0);


-- Line CM ($)

-- Line CM (�)
v_field = 'Line CM(�)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set line_cm_euro  = coalesce(line_sales_euro_conditional, 0) - coalesce(line_cost_euro,0);

-- Line CM (�)

-- Line CM Actual ($)
v_field = 'Line CM Actual($)';

RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

update fms_ipm_stage set line_cm_actual_dollar = 
  (case when (OU_NAME='GEII') and (sales_date_year_qtr<extract(Year from current_timestamp)||'-'||extract (Quarter from current_timestamp)) then UNIT_SELLING_PRICE * ORDERED_QUANTITY * (COALESCE(Round(CM_PERCENT::numeric, 2), 0) / 100) else 
    (case when Upper(Product)='PARTS' then
      (case when ((strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) or (Upper(PROJECT_TYPE)='TMGL')) and (current_timestamp>= ACTUAL_SHIPMENT_DATE + (interval '1 day'*15)) and (ACTUAL_SHIPMENT_DATE is not NULL) then
        line_sales_actual_dollar - (COALESCE(d_line_true_cost,0) * 
          (
            CASE WHEN OU_NAME='OU_NP_IT' THEN v_max_fx_rate_euro
            WHEN OU_NAME='OU_AM_US' THEN 1
            WHEN OU_NAME='OU_TD_FR' THEN v_max_fx_rate_euro
            WHEN OU_NAME='OU_NA_DZ' THEN v_max_fx_rate_dzd
             END)) 
       else
        (case when (strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 0) and (ORDER_TYPE!='NC GLOBAL SERVICES') and (Invoice_Status='C') then
          (CASE WHEN (actual_cost=0) OR (actual_cost IS NULL) THEN
            line_sales_actual_dollar * COALESCE(Round(CM_PERCENT::numeric, 2), 0) / 100
           ELSE line_sales_actual_dollar - (COALESCE(actual_cost,0) * 
            (CASE WHEN OU_NAME='OU_NP_IT' THEN v_max_fx_rate_euro
                 WHEN OU_NAME='OU_AM_US' THEN 1
                 WHEN OU_NAME='OU_TD_FR' THEN v_max_fx_rate_euro
                 WHEN OU_NAME='OU_NA_DZ' THEN v_max_fx_rate_dzd
            END)) 
          END) 
         else
            NULL 
        end) 
      end) 
    else
    line_sales_actual_dollar * COALESCE(Round(CM_PERCENT::numeric, 2), 0) / 100 
    end) 
end);
-- Line CM Actual ($)

-- Line CM Actual(With Reversal)
v_field = 'Line CM Actual(With Reversal)';

RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

update fms_ipm_stage set line_cm_actual_reversal = 
(case when (OU_NAME='GEII') and (sales_date_year_qtr>=(extract(Year from current_timestamp)||'-'||extract(Quarter from current_timestamp))::character varying) then
(case when line_sales_forecast_dollar<>0 then
UNIT_SELLING_PRICE * ORDERED_QUANTITY * (COALESCE(Round(CM_PERCENT::numeric, 2), 0) / 100)
when (line_sales_forecast_dollar=0) and (AMT_NOT_READY<>0) then
AMT_NOT_READY
end) else
(case when ((strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) or (Upper(PROJECT_TYPE)='TMGL')) and ((ACTUAL_SHIPMENT_DATE is NULL) or 
(current_timestamp<ACTUAL_SHIPMENT_DATE + (interval '1 day'*15))) then
line_sales_forecast_dollar - (unit_true_cost * ORDERED_QUANTITY * (
CASE WHEN OU_NAME='OU_NP_IT' THEN v_max_fx_rate_euro
WHEN OU_NAME='OU_AM_US' THEN 1
WHEN OU_NAME='OU_TD_FR' THEN v_max_fx_rate_euro
WHEN OU_NAME='OU_NA_DZ' THEN v_max_fx_rate_dzd
END)) else
(case when (strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 0) and (Upper(ORDER_TYPE)!='NC GLOBAL SERVICES') and ((Upper(INVOICE_STATUS)<>'C') or (INVOICE_STATUS is NULL)) then
line_sales_forecast_dollar * (COALESCE(Round(CM_PERCENT::numeric, 2), 0) / 100) else NULL end) end) end);
-- Line CM Actual(With Reversal)

-- Line Sales Actual (Reversal)
v_field = 'Line Sales Actual (Reversal)';
RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

update fms_ipm_stage set line_sales_actual_reversal = 
(case when (OU_NAME='GEII') and sales_date_year_qtr<extract (Year from current_timestamp)||'-'||extract(Quarter from current_timestamp) then 
  (UNIT_SELLING_PRICE * ORDERED_QUANTITY) 
 else
  (case when ((strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) or (Upper(PROJECT_TYPE)='TMGL')) and (current_timestamp>=ACTUAL_SHIPMENT_DATE+(interval '1 day' *15)) 
    and (ACTUAL_SHIPMENT_DATE is not NULL) and (1 - (CM_GLOBAL_CONTRACT / 100)) * 
      (CASE  WHEN OU_NAME='OU_NP_IT' THEN v_max_fx_rate_euro
        WHEN OU_NAME='OU_AM_US' THEN 1 
        WHEN OU_NAME='OU_TD_FR' THEN v_max_fx_rate_euro
        WHEN OU_NAME='OU_NA_DZ' THEN v_max_fx_rate_dzd
        END) <> 0 then
    d_line_true_cost / (1 - (CM_GLOBAL_CONTRACT / 100)) * 
      (CASE  WHEN OU_NAME='OU_NP_IT' THEN v_max_fx_rate_euro
        WHEN OU_NAME='OU_AM_US' THEN 1 
        WHEN OU_NAME='OU_TD_FR' THEN v_max_fx_rate_euro
        WHEN OU_NAME='OU_NA_DZ' THEN v_max_fx_rate_dzd
        END) 
    else
      (case when (Upper(ORDER_TYPE)!='NC GLOBAL SERVICES') and (Upper(INVOICE_STATUS)='C') then
              (d_invoice_prop_actual * FX_RATE) 
             else
                NULL 
             end) 
          end) 
end);
-- Line Sales Actual (Reversal)

-- OTR planning (Year-Quarter)
v_field = 'OTR planning (Year-Quarter)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');
update fms_ipm_stage set otr_planning_year_qtr = Extract(Year from c_commitment_date) || '-' || Extract(Quarter from c_commitment_date); 
-- OTR planning (Year-Quarter)

-- P&L
v_field = 'P&L';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');
update fms_ipm_stage set p_and_l = (case when Upper(P_AND_L)='MS' then
 'TX'
 else P_AND_L
 end);
-- P&L


-- Progress % calculated in Spotfire
/*v_field = 'Progress % calculated in Spotfire';

update fms_ipm_stage as mst
set over_progress_perc_spotfire  = subquery.sum_inner
from
(Select concatenate, Sum((case when d_not_duplicate = TRUE and (Upper(INVOICE_STATUS)='C') then d_invoice_amt_prop end)) over (partition by COSTING_PROJECT) as sum_inner from fms_ipm_stage)subquery 
where  mst.concatenate = subquery.concatenate;

update fms_ipm_stage set progress_perc_spotfire = (COALESCE( over_progress_perc_spotfire/ CUSTOMER_PO_AMOUNT * 100,0))
where CUSTOMER_PO_AMOUNT is not null and CUSTOMER_PO_AMOUNT <> 0;
*/
-- Progress % calculated in Spotfire


-- Reschedule Date (Year-Month)
v_field = 'Reschedule Date (Year-Month)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');
update fms_ipm_stage set reschedule_date_year_mnth = (case when (RESCHEDULE_YEAR is not NULL) or (RESCHEDULE_MONTH is not NULL) then
  RESCHEDULE_YEAR || '-' || RESCHEDULE_MONTH 
else  reschedule_date_year_mnth end);
-- Reschedule Date (Year-Month)

-- Residual Portfolio CM (�)
v_field = 'Residual Portfolio CM (�)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');
update fms_ipm_stage set residual_portfolio_cm_euro = 
  (case when (strpos(UPPER(PROJECT_TYPE), 'GLOBAL') = 1) then 
    (RESIDUAL_PORTFOLIO_SALES * (CM_GLOBAL_CONTRACT / 100))
  else 
  (RESIDUAL_PORTFOLIO_SALES * (ROUND(COALESCE(CM_PERCENT::numeric, 0), 0) / 100)) 
  end);

-- Residual Portfolio CM (�)

-- Residual Portfolio CM ($)
v_field = 'Residual Portfolio CM ($)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');
update fms_ipm_stage set residual_portfolio_cm_dol = (residual_portfolio_cm_euro * FX_RATE);
-- Residual Portfolio CM ($)

-- Residual Portfolio sales ($)
v_field = 'Residual Portfolio sales ($)';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');
update fms_ipm_stage set residual_portfolio_sales_dol = (RESIDUAL_PORTFOLIO_SALES * FX_RATE);
-- Residual Portfolio sales ($)


-- Parts Status

v_field = 'Parts Status';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

Update fms_ipm_stage set parts_status = 
    (CASE 
      WHEN Upper(Product)='PARTS' then
        (CASE   WHEN INVOICE_STATUS='C' THEN 'SALES'
                WHEN ACTUAL_SHIPMENT_DATE IS NOT NULL THEN 'SHIPPED'
          WHEN INVOICE_NUMBER IS NOT NULL  THEN 'SHIPPING'
          WHEN BOX_NUMBER IS NOT NULL THEN 'BILLING'
          WHEN MOVE_ORDER IS NOT NULL THEN 'PACKING'
          WHEN SUPPLY_TYPE='ON HAND'THEN 'AVAILABLE'
        ELSE 'INCOMING'
        END) 
    END);

-- Parts Status

-- Timeline
v_field = 'Timeline';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

update fms_ipm_stage set timeline = 
    (case when Upper(PARTS_STATUS)<>'INCOMING' then 'Ready'
        when (Upper(PARTS_STATUS)='INCOMING') and (PO_PROMISE_DATE is null) then 'Future'
        when (Upper(PARTS_STATUS)='INCOMING') and (coalesce((extract(year from PO_PROMISE_DATE)),0)=extract(year from current_timestamp)) then ''||(extract(year from current_timestamp))||''
    else 'Future'
    end);
-- Timeline

--  Basket
v_field = 'Basket';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');
RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

UPDATE fms_ipm_stage SET basket = (CASE WHEN UPPER(NEW_P_AND_L) = 'DTS' THEN 
  (CASE WHEN UPPER(GRATIS_SI) = 'YES' THEN 'Business Release'
         WHEN (d_booking_quarter = sales_date_year_qtr) AND (sales_date_year_qtr <= cwd_year_qtr) THEN 'Convertible'
         WHEN (d_booking_quarter < sales_date_year_qtr) AND (sales_date_year_qtr < cwd_year_qtr) THEN 'Early'
         WHEN (d_booking_quarter < sales_date_year_qtr) AND (sales_date_year_qtr > cwd_year_qtr) and (otr_planning_year_qtr > Extract(Year from SO_CWD) || '-' || Extract(Quarter from SO_CWD)) THEN 'Carry Over'
         WHEN (d_booking_quarter < sales_date_year_qtr) AND (sales_date_year_qtr >= cwd_year_qtr) THEN 'Backlog'       
  END)
             WHEN UPPER(NEW_P_AND_L) = 'TMS' THEN
  (CASE WHEN UPPER(GRATIS_SI) = 'YES' THEN 'Business Release'
         WHEN (d_booking_quarter = sales_date_year_qtr) AND (sales_date_year_qtr <= cwd_year_qtr) THEN 'Convertible'
         WHEN (d_booking_quarter < sales_date_year_qtr) AND (sales_date_year_qtr < cwd_year_qtr) THEN 'Early'
         WHEN (d_booking_quarter < sales_date_year_qtr) AND (sales_date_year_qtr >= cwd_year_qtr) THEN 'Backlog'       
  END)
END) ;

-- Basket

-- Operational Basket 
v_field = 'Operational Basket';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');
RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

UPDATE fms_ipm_parts_edit_fields as PEF
SET p_operational_basket = subquery.operational_basket
 FROM ( SELECT concatenate, 
  (CASE WHEN UPPER(NEW_P_AND_L) = 'DTS' THEN 
        (CASE  WHEN (d_booking_quarter = sales_date_year_qtr) AND (sales_date_year_qtr <= cwd_year_qtr) THEN 'Convertible'
        WHEN (d_booking_quarter < sales_date_year_qtr) AND (sales_date_year_qtr < cwd_year_qtr) THEN 'Early'
        WHEN (d_booking_quarter < sales_date_year_qtr) AND (sales_date_year_qtr > cwd_year_qtr) and (SO_CWD > SO_CWD) THEN 'Carry Over'
        WHEN (d_booking_quarter < sales_date_year_qtr) AND (sales_date_year_qtr >= cwd_year_qtr) THEN 'Backlog'       
        END)
      WHEN UPPER(NEW_P_AND_L) = 'TMS' THEN
        (CASE WHEN UPPER(GRATIS_SI) = 'YES' THEN 'Convertible'
        WHEN (d_booking_quarter = sales_date_year_qtr) AND (sales_date_year_qtr <= cwd_year_qtr) THEN 'Convertible'
        WHEN (d_booking_quarter < sales_date_year_qtr) AND (sales_date_year_qtr < cwd_year_qtr) THEN 'Early'
        WHEN (d_booking_quarter < sales_date_year_qtr) AND (sales_date_year_qtr >= cwd_year_qtr) THEN 'Backlog'       
        END)
    END) AS operational_basket  from fms_ipm_stage mst, fms_ipm_parts_edit_fields inner_pef where inner_pef.P_concatenate = mst.concatenate
     )subquery
WHERE PEF.P_concatenate = subquery.concatenate;

-- Operational Basket 

-- Financial Basket
v_field = 'Financial Basket';

RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

UPDATE fms_ipm_parts_edit_fields PEF
SET p_financial_basket = subquery.financial_basket
 FROM ( SELECT concatenate, (
      CASE WHEN UPPER(NEW_P_AND_L) = 'DTS' THEN 
        (
          CASE WHEN UPPER(GRATIS_SI) = 'YES' THEN 'Convertible'
              WHEN (d_booking_quarter < Extract(Year from Now()) || '-' || Extract(Quarter from Now())) AND (UPPER(PARTS_STATUS) = 'SALES') THEN 'Backlog'
              WHEN (d_booking_quarter = Extract(Year from Now()) || '-' || Extract(Quarter from Now())) THEN 'Convertible'
              WHEN (Extract(Year from p_new_date) || '-' || Extract(Quarter from p_new_date) > Extract(Year from Now()) || '-' || Extract(Quarter from Now())) THEN 'CWD'
          END
        )
       WHEN UPPER(NEW_P_AND_L) = 'TMS' THEN
       (
        CASE WHEN UPPER(GRATIS_SI) = 'YES' THEN 'Convertible'
        WHEN (d_booking_quarter = sales_date_year_qtr) AND (sales_date_year_qtr <= cwd_year_qtr) THEN 'Convertible'
        WHEN (d_booking_quarter < sales_date_year_qtr) AND (sales_date_year_qtr < cwd_year_qtr) THEN 'Early'
        WHEN (d_booking_quarter < sales_date_year_qtr) AND (sales_date_year_qtr >= cwd_year_qtr) THEN 'Backlog'       
        END
       )
      END) AS financial_basket   from fms_ipm_stage mst, fms_ipm_parts_edit_fields inner_pef where inner_pef.P_concatenate = mst.concatenate
     )subquery
WHERE PEF.P_concatenate = subquery.concatenate;
-- Financial Basket

--
v_field = 'sum sales';

RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

UPDATE fms_ipm_parts_edit_fields PEF
SET p_sum_sales = ROUND(subquery.new_p_sum_sales, 2)
 FROM ( SELECT  SUM(COALESCE(line_sales_forecast_dollar, 0) + COALESCE(line_sales_actual_dollar, 0)) as new_p_sum_sales, p_concatenate as concatenate 
  from fms_ipm_stage mst, fms_ipm_parts_edit_fields inner_pef 
  where inner_pef.p_concatenate = mst.concatenate
  group by p_concatenate
     )subquery
WHERE PEF.P_concatenate = subquery.concatenate;
--

--
v_field = 'SUM CM';

RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

UPDATE fms_ipm_parts_edit_fields PEF
SET p_sum_cm = ROUND(subquery.new_p_sum_cm, 2)
 FROM ( SELECT  SUM(COALESCE(line_cm_forecast_dollar, 0) + COALESCE(line_cm_actual_dollar, 0)) as new_p_sum_cm, p_concatenate as concatenate 
  from fms_ipm_stage mst, fms_ipm_parts_edit_fields inner_pef 
  where inner_pef.p_concatenate = mst.concatenate
  group by p_concatenate
     )subquery
WHERE PEF.P_concatenate = subquery.concatenate;
--

--
v_field = 'CM$/1000';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');
update fms_ipm_parts_edit_fields set p_cm_dollar_by_1000 = ROUND(COALESCE(p_sum_cm, 0)/1000, 2);
--

--
v_field = 'Parts Status Aging';

RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

UPDATE fms_ipm_parts_edit_fields PEF
SET p_status_aging = subquery.new_p_status_aging
 FROM ( SELECT  Extract( Days from (Now() - box_closure_date)) || ' Day(s)' as new_p_status_aging, p_concatenate as concatenate 
  from fms_ipm_stage mst, fms_ipm_parts_edit_fields inner_pef 
  where inner_pef.p_concatenate = mst.concatenate and PARTS_STATUS IN ('BILLING', 'SHIPPING', 'SHIPPED') and box_closure_date is not null
     )subquery
WHERE PEF.P_concatenate = subquery.concatenate;


UPDATE fms_ipm_parts_edit_fields PEF
SET p_status_aging = subquery.new_p_status_aging
 FROM ( SELECT  Extract( Days from (Now() - ACTUAL_SHIPMENT_DATE)) || ' Day(s)' as new_p_status_aging, p_concatenate as concatenate 
  from fms_ipm_stage mst, fms_ipm_parts_edit_fields inner_pef 
  where inner_pef.p_concatenate = mst.concatenate and PARTS_STATUS IN ('SALES') and ACTUAL_SHIPMENT_DATE is not null
     )subquery
WHERE PEF.P_concatenate = subquery.concatenate;

--


--
v_field = 'Flow No Flow';

RAISE notice 'Start % :- %', v_field, Now();
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');  

UPDATE fms_ipm_parts_edit_fields PEF
SET p_flow_or_no_flow = subquery.new_p_flow_or_no_flow
 FROM ( SELECT  
    (case when (SUM(COALESCE(line_sales_forecast_dollar, 0) + COALESCE(line_sales_actual_dollar, 0))) <= 80000 then 'Flow'
          when (SUM(COALESCE(line_sales_forecast_dollar, 0) + COALESCE(line_sales_actual_dollar, 0))) > 80000 then 'No-Flow'
    end)
     as new_p_flow_or_no_flow, p_concatenate as concatenate 
  from fms_ipm_stage mst, fms_ipm_parts_edit_fields inner_pef 
  where inner_pef.p_concatenate = mst.concatenate
  group by p_concatenate
     )subquery
WHERE PEF.P_concatenate = subquery.concatenate;
--

v_field = 'Alter Table';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');

ALTER TABLE fms_ipm_master RENAME TO fms_ipm_stage_new;

ALTER TABLE fms_ipm_stage RENAME TO fms_ipm_master;

ALTER TABLE fms_ipm_stage_new RENAME TO fms_ipm_stage;


-- Update Forecasted value for Quarter

IF ((extract (day from now()) || '-' || extract (month from now())) = '01-01') OR ((extract (day from now()) || '-' || extract (month from now())) = '1-1')
   OR	((extract (day from now()) || '-' || extract (month from now())) = '01-04') OR ((extract (day from now()) || '-' || extract (month from now())) = '1-4')
   OR	((extract (day from now()) || '-' || extract (month from now())) = '01-07') OR ((extract (day from now()) || '-' || extract (month from now())) = '1-7')
   OR	((extract (day from now()) || '-' || extract (month from now())) = '01-10') OR ((extract (day from now()) || '-' || extract (month from now())) = '1-10')
   THEN


--Reseting the added and removed fields of previous quarters

UPDATE fms_ipm_parts_edit_fields SET p_forecast_status = NULL, p_new_date = NULL, p_wb_comment = NULL;

--Current Quarters

INSERT INTO fms_ipm_parts_forecast(
            quarter, year, forecast, parts_status, new_p_and_l, quarter_status, qtr_first_day_data)
     (SELECT extract(QUARTER from now()) || 'Q' as quarter, 
	extract(YEAR from now()) as year, 
	SUM(COALESCE(p_sum_cm, 0)) as p_sum_cm,
	coalesce(parts_status,'BLANK') as parts_status, 
	'DTS' as new_p_and_l, 
	'CURRENT' as quarter_status, TRUE as qtr_first_day_data
		FROM fms_ipm_parts_edit_fields PEF,  fms_ipm_master MST 
			WHERE PEF.P_concatenate = MST.concatenate AND new_p_and_l = 'DTS' AND 
			MST.sales_date_year_qtr in (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp)) 
		group by parts_status, quarter, year, new_p_and_l);

		
	INSERT INTO fms_ipm_parts_forecast(
            quarter, year, forecast, parts_status, new_p_and_l, quarter_status, qtr_first_day_data)
     (SELECT extract(QUARTER from now()) || 'Q' as quarter, 
	extract(YEAR from now()) as year, 
	SUM(COALESCE(p_sum_cm, 0)) as p_sum_cm,
	coalesce(parts_status,'BLANK') as parts_status, 
	'TMS' as new_p_and_l, 
	'CURRENT' as quarter_status, TRUE as qtr_first_day_data
		FROM fms_ipm_parts_edit_fields PEF,  fms_ipm_master MST 
			WHERE PEF.P_concatenate = MST.concatenate AND new_p_and_l = 'TMS' AND 
			MST.sales_date_year_qtr in (extract (year from current_timestamp)||'-'||extract (quarter from current_timestamp))
			 group by parts_status, quarter, year, new_p_and_l);	

--Future Quarters

	INSERT INTO fms_ipm_parts_forecast(
            quarter, year, forecast, parts_status, new_p_and_l, quarter_status, qtr_first_day_data)
     (SELECT extract(QUARTER from now()) || 'Q' as quarter, 
	extract(YEAR from now()) as year, 
	SUM(COALESCE(p_sum_cm, 0)) as p_sum_cm,
	coalesce(parts_status,'BLANK') as parts_status, 
	'DTS' as new_p_and_l, 
	'FUTURE' as quarter_status, TRUE as qtr_first_day_data
		FROM fms_ipm_parts_edit_fields PEF,  fms_ipm_master MST 
			WHERE PEF.P_concatenate = MST.concatenate AND new_p_and_l = 'DTS' AND 
			MST.sales_date_year_qtr in (((extract(year from now()+ (interval '3 month'))||'-'||extract(quarter from current_timestamp+ (interval '3 month')))), 
				((extract(year from now()+ (interval '6 month'))||'-'||extract(quarter from current_timestamp+ (interval '6 month')))), 
				((extract(year from now()+ (interval '9 month'))||'-'||extract(quarter from current_timestamp+ (interval '9 month')))), 
				((extract(year from now()+ (interval '12 month'))||'-'||extract(quarter from current_timestamp+ (interval '12 month')))) ) 
			group by parts_status, quarter, year, new_p_and_l);

			
	INSERT INTO fms_ipm_parts_forecast(
            quarter, year, forecast, parts_status, new_p_and_l, quarter_status, qtr_first_day_data)
     (SELECT extract(QUARTER from now()) || 'Q' as quarter, 
	extract(YEAR from now()) as year, 
	SUM(COALESCE(p_sum_cm, 0)) as p_sum_cm,
	coalesce(parts_status,'BLANK') as parts_status, 
	'TMS' as new_p_and_l, 
	'FUTURE' as quarter_status, TRUE as qtr_first_day_data
		FROM fms_ipm_parts_edit_fields PEF,  fms_ipm_master MST 
			WHERE PEF.P_concatenate = MST.concatenate AND new_p_and_l = 'TMS' AND 
			MST.sales_date_year_qtr in (((extract(year from now()+ (interval '3 month'))||'-'||extract(quarter from current_timestamp+ (interval '3 month')))), 
				((extract(year from now()+ (interval '6 month'))||'-'||extract(quarter from current_timestamp+ (interval '6 month')))), 
				((extract(year from now()+ (interval '9 month'))||'-'||extract(quarter from current_timestamp+ (interval '9 month')))), 
				((extract(year from now()+ (interval '12 month'))||'-'||extract(quarter from current_timestamp+ (interval '12 month'))))) 
			group by parts_status, quarter, year, new_p_and_l);	

				

END IF;   


v_field = 'Data Entry Daily Updates';
PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: ' || v_field || ' CurrentTime: ' || Now(),     'Test field conversion');
--select fms_ipm_dataentry_daily_update() into v_status;

PERFORM fms_db_logger('fms_ipm_spotfire_conv',   '' ,    'Test field conversion: SUCCESS CurrentTime: ' || Now(),     'Test field conversion');

RETURN ('SUCCESS');
    
  EXCEPTION WHEN OTHERS THEN 
  --ROLLBACK; 
  
  PERFORM fms_db_logger('fms_ipm_spotfire_conv',
           '' ,
           'Error in conversion of: ' || v_field || ' Error: ' || sqlerrm,
           'DATABASE ERROR');    
  --RAISE NOTICE 'SQL ERROR %', sqlerrm;
  Select fms_ipm_create_index('fms_ipm_master', 'ALL') into v_status;
  RETURN 'DATABASE ERROR';    
  
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
