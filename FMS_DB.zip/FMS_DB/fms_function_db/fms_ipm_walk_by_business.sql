-- Function: fms_ipm_walk_by_business(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying)

-- DROP FUNCTION fms_ipm_walk_by_business(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION fms_ipm_walk_by_business(IN in_new_p_and_l character varying, IN in_p_and_l character varying, IN in_product character varying, IN in_ou_name character varying, IN in_og_region character varying, IN in_region character varying, IN in_subregion character varying, IN in_end_user_country_disc character varying, IN in_mother_job character varying, IN in_enduser_cust_name character varying, IN in_costing_project character varying, IN in_order_type character varying, IN in_week character varying, OUT out_data_table character varying, OUT out_charts character varying)
  RETURNS record AS
$BODY$
declare
	v_cs_chart numeric;
	v_inst_chart numeric;
	v_sc_chart numeric;
	v_blank character varying;
	v_bar_1 character varying;
	v_bar_2 character varying;
	v_bar_3 character varying;
	v_total character varying;
	v_gap character varying;
	v_view1_sql character varying;
	v_view2_sql character varying;
	v_view3_sql character varying;
	v_proc_paras  character varying;
	v_week character varying;

begin

	v_proc_paras = in_new_p_and_l||';'||
			in_p_and_l||';'||
			in_product||';'||
			in_ou_name||';'||
			in_og_region||';'||
			in_region||';'||
			in_subregion||';'||
			in_end_user_country_disc||';'||
			in_mother_job||';'||
			in_enduser_cust_name||';'||
			in_costing_project||';'||
			in_order_type||';'||
			in_week;

	v_week := in_week;
	
	if(v_week = '' or v_week is null) then 
		v_week  := (extract (week from current_timestamp))::character varying;
	else
		v_week := v_week;
	end if;
	
	

-- view for data entry table
	v_view2_sql = 'create or replace temp view data_entry_table_v as
		select * from fms_ipm_data_entry where business_unit = ' || '''' || in_new_p_and_l || '''' || '  and week = ' || '''' || v_week || '''' || ' ';

	raise notice '%', v_view2_sql;
	execute v_view2_sql;
	
IF (Trim(in_p_and_l) = '' or in_p_and_l is null) and (Trim(in_product) = '' or in_product is null) and (Trim(in_ou_name) = '' or in_ou_name is null) and (Trim(in_og_region) = '' or in_og_region is null) and (Trim(in_region) = '' or in_region is null) and (Trim(in_subregion) = '' or in_subregion is null) and (Trim(in_end_user_country_disc) = '' or in_end_user_country_disc is null) and (Trim(in_mother_job) = '' or in_mother_job is null)and (Trim(in_enduser_cust_name) = '' or in_enduser_cust_name is null) and (Trim(in_costing_project) = '' or in_costing_project is null) and (Trim(in_order_type) = '' or in_order_type is null) then

Raise Notice 'All data entry';

v_view3_sql = 'create or replace temp view parts_data_table_v as(
	select ''CE'' as type , *, (tx + cs + inst + sc) as tot  from  ( select 
		COALESCE((select COALESCE(round(ce_val/1000, 2), 0) from data_entry_table_v where identifier = ''TX'' ),0)  as tx,
		COALESCE((select COALESCE(round(ce_val/1000, 2), 0) from data_entry_table_v where identifier = ''CS'' ),0) as cs,
		COALESCE((select COALESCE(round(ce_val/1000, 2), 0) from data_entry_table_v where identifier = ''INST''   ),0) as inst,
		COALESCE((select COALESCE(round(ce_val/1000, 2), 0) from data_entry_table_v where identifier = ''SC''  ),0) as sc) as inner_ce
	Union       
	select ''PE'' as type,*, (tx + cs + inst + sc) as tot  from  ( select
		COALESCE((select COALESCE(round(pe_val/1000, 2), 0) from data_entry_table_v where identifier = ''TX''   ),0) as tx,
		COALESCE((select COALESCE(round(pe_val/1000, 2), 0) from data_entry_table_v where identifier = ''CS''  ),0) as cs,
		COALESCE((select COALESCE(round(pe_val/1000, 2), 0) from data_entry_table_v where identifier = ''INST''  ),0) as inst,
		COALESCE((select COALESCE(round(pe_val/1000, 2), 0) from data_entry_table_v where identifier = ''SC''  ),0) as sc) as inner_pe 
	Union       
	select ''RISK'' as type,*, (tx + cs + inst + sc) as tot  from  ( select
		COALESCE((select COALESCE(round(risk_val/1000,2),0) from data_entry_table_v where identifier = ''TX''   ),0) as tx,
		COALESCE((select COALESCE(round(risk_val/1000,2),0) from data_entry_table_v where identifier = ''CS''   ),0) as cs,
		COALESCE((select COALESCE(round(risk_val/1000,2),0) from data_entry_table_v where identifier = ''INST''   ),0) as inst,
		COALESCE((select COALESCE(round(risk_val/1000,2),0) from data_entry_table_v where identifier = ''SC''  ),0) as sc) as inner_risk
	Union       
	select ''OPP'' as type,*, (tx + cs + inst + sc) as tot  from  ( select
		COALESCE((select COALESCE(round(opp_val/1000,2), 0) from data_entry_table_v where identifier = ''TX''  ),0) as tx,
		COALESCE((select COALESCE(round(opp_val/1000,2), 0) from data_entry_table_v where identifier = ''CS''  ),0) as cs,
		COALESCE((select COALESCE(round(opp_val/1000,2), 0) from data_entry_table_v where identifier = ''INST''  ),0) as inst,
		COALESCE((select COALESCE(round(opp_val/1000,2), 0) from data_entry_table_v where identifier = ''SC'' ),0) as sc) as inner_opp
	Union       
	select ''OP'' as type,*, (tx + cs + inst + sc) as tot  from  ( select 
		COALESCE((select COALESCE(round(op_val/1000,2), 0) from data_entry_table_v where identifier = ''TX''  ),0) as tx,
		COALESCE((select COALESCE(round(op_val/1000,2), 0) from data_entry_table_v where identifier = ''CS''  ),0) as cs,
		COALESCE((select COALESCE(round(op_val/1000,2), 0) from data_entry_table_v where identifier = ''INST''   ),0) as inst,
		COALESCE((select COALESCE(round(op_val/1000,2), 0) from data_entry_table_v where identifier = ''SC''  ),0) as sc) as inner_op
	)';

else

Raise Notice 'Master + Data Entry';

    v_view1_sql = 'create or replace temp view parts_filter_data_v as select COALESCE(parts.p_cm_dollar_by_1000, 0) as p_cm_dollar_by_1000, parts.p_r_by_o, master.p_and_l, master.new_p_and_l 
		from fms_ipm_parts_edit_fields parts , fms_ipm_master master  where master.concatenate = parts.p_concatenate
		AND master.sales_date_year_qtr in (extract (year from current_timestamp)||''-''||extract (quarter from current_timestamp))
		  AND COALESCE(master.new_p_and_l,'''') ~* ' || '''' || in_new_p_and_l || '''' || 
		' AND COALESCE(master.p_and_l, '''') ~* ' || '''' || in_p_and_l || '''' ||  
		' AND COALESCE(master.product, '''') ~*' || '''' || in_product || '''' ||  
		' AND COALESCE(master.ou_name, '''') ~*' || '''' || in_ou_name || '''' ||  
		' AND COALESCE(master.og_region, '''') ~*' || '''' || in_og_region || '''' ||  
		' AND COALESCE(master.region, '''') ~*' || '''' || in_region || '''' ||  
		' AND COALESCE(master.subregion, '''') ~*' || '''' || in_subregion || '''' || 
		' AND COALESCE(master.end_user_country_disc, '''') ~*' || '''' || in_end_user_country_disc || '''' || 
		' AND COALESCE(master.mother_job, '''') ~*' || '''' || in_mother_job || '''' ||  
		' AND COALESCE(master.enduser_cust_name, '''') ~*' || '''' || in_enduser_cust_name || '''' ||  
		' AND COALESCE(master.costing_project, '''') ~*' || '''' || in_costing_project || '''' || 
		' AND COALESCE(master.order_type, '''') ~*' || '''' || in_order_type  || '''' ;

    RAISE NOTICE '%', v_view1_sql;
	execute v_view1_sql;
	--raise notice '%', (select count(*) from parts_filter_data_v);


-- Data Table
v_view3_sql = 'create or replace temp view parts_data_table_v as(
	select ''CE'' as type , *, (tx + cs + inst + sc) as tot  from  ( select 
		COALESCE((select COALESCE(round(sum(p_cm_dollar_by_1000)/1000,2), 0)  from parts_filter_data_v where (p_r_by_o !=  ''OPPS'' or p_r_by_o is null) and p_and_l = ''TX'' ),0) as tx,
		COALESCE((select COALESCE(round(sum(p_cm_dollar_by_1000)/1000, 2), 0) from parts_filter_data_v where (p_r_by_o !=  ''OPPS'' or p_r_by_o is null) and p_and_l = ''CS'' ),0) as cs,
		COALESCE((select COALESCE(round(ce_val/1000, 2), 0) from data_entry_table_v where identifier = ''INST''   ),0) as inst,
		COALESCE((select COALESCE(round(ce_val/1000, 2), 0) from data_entry_table_v where identifier = ''SC''  ),0) as sc) as inner_ce
	Union       
	select ''PE'' as type,*, (tx + cs + inst + sc) as tot  from  ( select
		COALESCE((select COALESCE(round(pe_val/1000, 2), 0) from data_entry_table_v where identifier = ''TX''   ),0) as tx,
		COALESCE((select COALESCE(round(pe_val/1000, 2), 0) from data_entry_table_v where identifier = ''CS''  ),0) as cs,
		COALESCE((select COALESCE(round(pe_val/1000, 2), 0) from data_entry_table_v where identifier = ''INST''  ),0) as inst,
		COALESCE((select COALESCE(round(pe_val/1000, 2), 0) from data_entry_table_v where identifier = ''SC''  ),0) as sc) as inner_pe 
	Union       
	select ''RISK'' as type,*, (tx + cs + inst + sc) as tot  from  ( select
		COALESCE((select COALESCE(round(sum(p_cm_dollar_by_1000)/1000,2), 0)  from parts_filter_data_v where p_r_by_o =  ''RISK'' and p_and_l = ''TX'' ),0) as tx,
		COALESCE((select COALESCE(round(sum(p_cm_dollar_by_1000)/1000,2),0) from parts_filter_data_v where p_r_by_o =  ''RISK'' and p_and_l = ''CS'' ),0) as cs,
		COALESCE((select COALESCE(round(risk_val/1000,2),0) from data_entry_table_v where identifier = ''INST''   ),0) as inst,
		COALESCE((select COALESCE(round(risk_val/1000,2),0) from data_entry_table_v where identifier = ''SC''  ),0) as sc) as inner_risk
	Union       
	select ''OPP'' as type,*, (tx + cs + inst + sc) as tot  from  ( select
		COALESCE((select COALESCE(round(sum(p_cm_dollar_by_1000)/1000,2), 0)  from parts_filter_data_v where p_r_by_o =  ''OPPS'' and p_and_l = ''TX'' ),0) as tx,
		COALESCE((select COALESCE(round(sum(p_cm_dollar_by_1000)/1000,2), 0) from parts_filter_data_v where p_r_by_o =  ''OPPS'' and p_and_l = ''CS'' ),0) as cs,
		COALESCE((select COALESCE(round(opp_val/1000,2), 0) from data_entry_table_v where identifier = ''INST''  ),0) as inst,
		COALESCE((select COALESCE(round(opp_val/1000,2), 0) from data_entry_table_v where identifier = ''SC'' ),0) as sc) as inner_opp
	Union       
	select ''OP'' as type,*, (tx + cs + inst + sc) as tot  from  ( select 
		COALESCE((select COALESCE(round(op_val/1000,2), 0) from data_entry_table_v where identifier = ''TX''  ),0) as tx,
		COALESCE((select COALESCE(round(op_val/1000,2), 0) from data_entry_table_v where identifier = ''CS''  ),0) as cs,
		COALESCE((select COALESCE(round(op_val/1000,2), 0) from data_entry_table_v where identifier = ''INST''   ),0) as inst,
		COALESCE((select COALESCE(round(op_val/1000,2), 0) from data_entry_table_v where identifier = ''SC''  ),0) as sc) as inner_op
	)';

end if;

raise notice '%', v_view3_sql;
execute v_view3_sql;

--Chart

--blank row

--tx of blank row is 0

--cs of blank row
/*
select Max( COALESCE((case when (type = 'CE') then 
		(case when cs >=0 then 
			(case when (tx >0)  then
				(Select COALESCE((0 + (Select ce_val - risk_val from data_entry_table_v where identifier = 'TX')),0))
				else 
				   (Select COALESCE((0 + (Select ce_val - risk_val from data_entry_table_v where identifier = 'TX') + tx),0)) 
				   
				end)
		 else 
			(case when tx > 0 then 
				(Select COALESCE((0 + (Select ce_val - risk_val from data_entry_table_v where identifier = 'TX') + cs),0) )
			 else 
			      0 + cs 
		         end) 
		end)      
	end),0) + case when type = 'RISK' then tx end) cs_chart  into v_cs_chart from parts_data_table_v;	

*/
--select ((Select COALESCE((0 + (Select ce_val - risk_val from data_entry_table_v where identifier = 'TX')),0))+(select tx from parts_data_table_v where type ='RISK'))/1000 as cs_chart into v_cs_chart;

select round(COALESCE((select abs(tx) from parts_data_table_v where type = 'CE'),0),2) into v_cs_chart ;

--inst of blank row
/*
select Max(COALESCE((case when (type = 'CE') then 
		(case when inst >=0 then 
			(case when (cs >0)  then
				(Select COALESCE((v_cs_chart + (Select ce_val - risk_val from data_entry_table_v where identifier = 'CS')),0))
			  else 
				   (Select COALESCE((v_cs_chart + (Select ce_val - risk_val from data_entry_table_v where identifier = 'CS') + cs),0) ) 
				   
			 end)
		else 
			(case when cs > 0 then 
				(Select COALESCE((v_cs_chart + (Select ce_val - risk_val from data_entry_table_v where identifier = 'CS') + inst),0) )
			 else 
			      COALESCE((v_cs_chart + inst),0) 
			  end) 
		end)	  
	end),0) + case when type = 'RISK' then cs end) inst_chart  into v_inst_chart from parts_data_table_v;
*/
--v_inst_chart := (Select COALESCE((0 + (Select ce_val - risk_val from data_entry_table_v where identifier = 'CS'))),0)+(select cs from parts_data_table_v where type ='RISK') ;

v_inst_chart := round(COALESCE((v_cs_chart+(select abs(cs) from parts_data_table_v where type = 'CE')),0),2) ;

--sc of blank row
/*
select Max(COALESCE((case when (type = 'CE') then 
		(case when sc >=0 then 
			(case when (inst >0)  then
				(Select COALESCE((v_inst_chart + (Select ce_val - risk_val from data_entry_table_v where identifier = 'INST')),0))
			  else 
				   (Select COALESCE((v_inst_chart + (Select ce_val - risk_val from data_entry_table_v where identifier = 'INST') + inst),0) ) 
				   
			 end)
		else 
			(case when inst > 0 then 
				(Select COALESCE((v_inst_chart + (Select ce_val - risk_val from data_entry_table_v where identifier = 'INST') + sc),0) )
			 else 
			      COALESCE((v_inst_chart + sc),0) 
			  end) 
		end)	  
	end),0) + case when type = 'RISK' then inst end) sc_chart 
	into v_sc_chart 
	from parts_data_table_v;
*/

--v_sc_chart:= ((0+(Select COALESCE((0 + (Select ce_val - risk_val from data_entry_table_v where identifier = 'INST'))),0))+(select inst from parts_data_table_v where type ='RISK'))/1000  ;

v_sc_chart := round(COALESCE((v_inst_chart+(select abs(inst) from parts_data_table_v where type = 'CE')),0),2) ;

--raise notice 'inst %' , (select inst from parts_data_table_v where type= 'CE');
--raise notice 'tx %' , (select tx from parts_data_table_v where type= 'CE');
--raise notice 'cs %' , (select cs from parts_data_table_v where type= 'CE');
--raise notice 'sc %' , (select sc from parts_data_table_v where type= 'CE');
--raise notice 'v_cs_chart %' , v_cs_chart;
--raise notice 'v_inst_chart %' , v_inst_chart;
--raise notice 'v_sc_chart %' , v_sc_chart;

-- chart rows

	select 0 ||';'|| v_cs_chart ||';'|| v_inst_chart ||';'|| v_sc_chart ||';'|| 0 ||';'|| 
		(case when (select abs(tot) from parts_data_table_v where type= 'CE') <= (select tot from parts_data_table_v where type= 'OP') then
			(select abs(tot) from parts_data_table_v where type= 'CE')
		else
			((select abs(tot) from parts_data_table_v where type= 'CE')-
			((select abs(tot) from parts_data_table_v where type= 'CE')-(select abs(tot) from parts_data_table_v where type= 'OP')))
			end)
		 ||';'|| 0 into v_blank;

	--raise notice 'v_blank %' , v_blank;

	select 0 ||';'|| 0 ||';'|| 0 ||';'|| 0 ||';'|| (select abs(tot) from parts_data_table_v where type= 'CE')||';'|| 0 ||';'|| (select abs(tot) from parts_data_table_v where type= 'OP')into v_total;

	--raise notice 'v_total %' , v_total;
	
	select 
		0 ||';'|| 0 ||';'|| 0 ||';'|| 0 ||';'|| 0 ||';'||
		abs(((select tot from parts_data_table_v where type= 'OP')-(select tot from parts_data_table_v where type= 'CE'))) 
		||';'|| 0 
	into v_gap;

	--raise notice 'v_gap %' , v_gap;

	IF (Trim(in_p_and_l) = '' or in_p_and_l is null) and (Trim(in_product) = '' or in_product is null) and (Trim(in_ou_name) = '' or in_ou_name is null) and (Trim(in_og_region) = '' or in_og_region is null) and (Trim(in_region) = '' or in_region is null) and (Trim(in_subregion) = '' or in_subregion is null) and (Trim(in_end_user_country_disc) = '' or in_end_user_country_disc is null) and (Trim(in_mother_job) = '' or in_mother_job is null)and (Trim(in_enduser_cust_name) = '' or in_enduser_cust_name is null) and (Trim(in_costing_project) = '' or in_costing_project is null) and (Trim(in_order_type) = '' or in_order_type is null) then

	Raise Notice 'All data entry';
	
	select ((Select coalesce(abs((ce_val - risk_val))/1000,0) from data_entry_table_v where identifier = 'TX') 
	||';'|| (Select coalesce(abs((ce_val - risk_val))/1000,0) from data_entry_table_v where identifier = 'CS') 
	||';'|| (Select coalesce(abs((ce_val - risk_val))/1000,0) from data_entry_table_v where identifier = 'INST') 
	||';'|| (Select coalesce(abs((ce_val - risk_val))/1000,0) from data_entry_table_v where identifier = 'SC') ||';'|| 0 ||';'|| 0 ||';'|| 0) as solid_val_chart into v_bar_1;

	--raise notice 'v_bar_1 %' , v_bar_1;

	else

	Raise Notice 'Master + Data Entry';

	select (((select abs(tx) from parts_data_table_v where type = 'CE')-(select tx from parts_data_table_v where type = 'RISK')) 
	||';'|| ((select abs(cs) from parts_data_table_v where type = 'CE')-(select cs from parts_data_table_v where type = 'RISK')) 
	||';'|| (Select coalesce(abs((ce_val - risk_val))/1000,0) from data_entry_table_v where identifier = 'INST') 
	||';'|| (Select coalesce(abs((ce_val - risk_val))/1000,0) from data_entry_table_v where identifier = 'SC') ||';'|| 0 ||';'|| 0 ||';'|| 0) as solid_val_chart into v_bar_1;

	end if;

	select ((select abs(tx) from parts_data_table_v where type = 'RISK')||';'||(select abs(cs) from parts_data_table_v where type = 'RISK')||';'||(select abs(inst) from parts_data_table_v where type = 'RISK')||';'||(select abs(sc) from  parts_data_table_v where type = 'RISK') ||';'|| 0 ||';'|| 0 ||';'|| 0) as risk_val_chart into v_bar_2;

	--raise notice 'v_bar_2 %' , v_bar_2;

	select ((select abs(tx) from parts_data_table_v where type = 'OPP')||';'||(select abs(cs) from parts_data_table_v where type = 'OPP')||';'||(select abs(inst) from parts_data_table_v where type = 'OPP')||';'||(select abs(sc) from  parts_data_table_v where type = 'OPP')  ||';'|| 0 ||';'|| 0 ||';'|| 0) as opp_val_chart  into v_bar_3;

	--raise notice 'v_bar_3 %' , v_bar_3;
    
select 
(COALESCE((select type ||';'|| tx ||';'|| cs ||';'|| inst ||';'|| sc ||';'|| tot from parts_data_table_v where type = 'CE'),'CE;0;0;0;0;0')
||'~'||COALESCE((select type ||';'|| tx ||';'|| cs ||';'|| inst ||';'|| sc ||';'|| tot from parts_data_table_v where type = 'PE'),'PE;0;0;0;0;0')
||'~'||COALESCE((select type ||';'|| tx ||';'|| cs ||';'|| inst ||';'|| sc ||';'|| tot from parts_data_table_v where type = 'RISK'),'RISK;0;0;0;0;0')
||'~'||COALESCE((select type ||';'|| tx ||';'|| cs ||';'|| inst ||';'|| sc ||';'|| tot from parts_data_table_v where type = 'OPP'),'OPP;0;0;0;0;0')
||'~'||COALESCE((select type ||';'|| tx ||';'|| cs ||';'|| inst ||';'|| sc ||';'|| tot from parts_data_table_v where type = 'OP'),'OP;0;0;0;0;0'))
  into out_data_table ; 

select (COALESCE(v_bar_3,'0;0;0;0;0;0;0')||'~'||COALESCE(v_bar_2,'0;0;0;0;0;0;0')||'~'||COALESCE(v_bar_1,'0;0;0;0;0;0;0')||'~'||COALESCE(v_total,'0;0;0;0;0;0;0')||'~'||COALESCE(v_gap,'0;0;0;0;0;0;0')||'~'||COALESCE(v_blank,'0;0;0;0;0;0;0')) into out_charts;

drop view IF EXISTS parts_data_table_v;
drop view IF EXISTS parts_filter_data_v;

	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_ipm_walk_by_business',
			     v_proc_paras ,
			     sqlerrm,
			     'DATABASE ERROR');		
	drop view IF EXISTS parts_data_table_v;
	drop view IF EXISTS parts_filter_data_v;			     
	
	--RAISE NOTICE 'SQL ERROR %', sqlerrm;
	select 'DATABASE ERROR' into out_data_table;
	select 'DATABASE ERROR' into out_charts;


end
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
