-- Function: fms_ipm_walk_by_product(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying)

-- DROP FUNCTION fms_ipm_walk_by_product(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION fms_ipm_walk_by_product(IN in_new_p_and_l character varying, IN in_p_and_l character varying, IN in_product character varying, IN in_ou_name character varying, IN in_og_region character varying, IN in_region character varying, IN in_subregion character varying, IN in_end_user_country_disc character varying, IN in_mother_job character varying, IN in_enduser_cust_name character varying, IN in_costing_project character varying, IN in_order_type character varying, IN in_week character varying, OUT out_data_table character varying, OUT out_charts character varying, OUT out_actual character varying, OUT out_unconfirmed character varying)
  RETURNS record AS
$BODY$

declare

	v_view1_sql character varying;
	v_view2_sql character varying;
	v_blank_field_services numeric;
	v_blank_repairs numeric;
	v_blank_other_ge_le numeric;
	v_blank_ct numeric;
	v_blank_hq numeric;
	v_blank_coq numeric;
	v_blank_convtogo numeric;
	v_blank_stretch numeric;
	v_blank_risk numeric;
	v_blank_opp numeric;
	v_blank_row character varying;
	v_solid_row character varying;
	v_proc_paras character varying;
	v_week character varying;


begin

	v_proc_paras = in_new_p_and_l||';'||
			in_p_and_l||';'||
			in_product||';'||
			in_ou_name||';'||
			in_og_region||';'||
			in_region||';'||
			in_subregion||';'||
			in_end_user_country_disc||';'||
			in_mother_job||';'||
			in_enduser_cust_name||';'||
			in_costing_project||';'||
			in_order_type||';'||
			v_week;

	v_week := in_week;
	
	if(v_week = '' or v_week is null) then 
		v_week  := (extract (week from current_timestamp))::character varying;
	else
		v_week := v_week;
	end if;
	
			

	v_view1_sql = 'create or replace temp view parts_filter_data_product_v as select COALESCE(parts.p_cm_dollar_by_1000,0) as p_cm_dollar_by_1000, parts.p_r_by_o, master.p_and_l, master.new_p_and_l, 
		--(case when master.new_p_and_l = ''TMS'' then master.region
			--else master.og_region end) region 
			master.og_region, master.project_type, master.invoice_status, master.parts_status, master.actual_shipment_date,
			master.product as product, master.basket as basket
			from fms_ipm_parts_edit_fields parts , fms_ipm_master master  where master.concatenate = parts.p_concatenate
		  AND (upper(p_r_by_o) !=  ''OPPS''  or p_r_by_o is null)
		  AND master.sales_date_year_qtr in (extract (year from current_timestamp)||''-''||extract (quarter from current_timestamp))
		  AND trim(upper(product)) in (''PARTS'',''FIELD_SERVICES'',''REPAIRS'') 
		  AND COALESCE(master.new_p_and_l,'''') ~* ' || '''' || in_new_p_and_l || '''' || 
		' AND COALESCE(master.p_and_l, '''') ~* ' || '''' || in_p_and_l || '''' ||  
		' AND COALESCE(master.product, '''') ~*' || '''' || in_product || '''' ||  
		' AND COALESCE(master.ou_name, '''') ~*' || '''' || in_ou_name || '''' ||  
		' AND COALESCE(master.og_region, '''') ~*' || '''' || in_og_region || '''' ||  
		' AND COALESCE(master.region, '''') ~*' || '''' || in_region || '''' ||  
		' AND COALESCE(master.subregion, '''') ~*' || '''' || in_subregion || '''' || 
		' AND COALESCE(master.end_user_country_disc, '''') ~*' || '''' || in_end_user_country_disc || '''' || 
		' AND COALESCE(master.mother_job, '''') ~*' || '''' || in_mother_job || '''' ||  
		' AND COALESCE(master.enduser_cust_name, '''') ~*' || '''' || in_enduser_cust_name || '''' ||  
		' AND COALESCE(master.costing_project, '''') ~*' || '''' || in_costing_project || '''' || 
		' AND COALESCE(master.order_type, '''') ~*' || '''' || in_order_type  || '''' ;

		
	execute v_view1_sql;

--data table

	v_view2_sql = 'create or replace temp view parts_data_table_product_v as
(select type, (case when "PARTS" = -2147483648.00 then 0.00 else "PARTS" end), (case when "FIELD_SERVICES" = -2147483648.00 then 0.00 else "FIELD_SERVICES" end),
	(case when "REPAIRS" = -2147483648.00 then 0.00 else "REPAIRS" end), "OTHER_GE_LE", "CT", "HQ", "COQ","CONVTOGO","STRETCH", "RISK", "OPP" 
	from 
(Select p_and_l as type,
MAX(Case when upper(product) = ''PARTS'' then tx_cs else -2147483648.00 end) as "PARTS",
MAX(Case when upper(product) = ''FIELD_SERVICES'' then tx_cs else -2147483648.00 end) as "FIELD_SERVICES",
MAX(Case when upper(product) = ''REPAIRS'' then tx_cs else -2147483648.00 end) as "REPAIRS",
(case when p_and_l = ''TX'' then 
	round(COALESCE((select (tx_ce_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''OTHER_GE_LE'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2)
when p_and_l = ''CS'' then
	round(COALESCE((select (cs_ce_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''OTHER_GE_LE'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) end )as "OTHER_GE_LE",
(case when p_and_l = ''TX'' then 
	round(COALESCE((select (tx_ce_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''CT'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2)
when p_and_l = ''CS'' then
	round(COALESCE((select (cs_ce_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''CT'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) end )as "CT",
(case when p_and_l = ''TX'' then 
	round(COALESCE((select (tx_ce_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''HQ'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2)
when p_and_l = ''CS'' then
	round(COALESCE((select (cs_ce_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''HQ'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) end )as "HQ",
(case when p_and_l = ''TX'' then 
	round(COALESCE((select (tx_ce_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''COQ'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2)
when p_and_l = ''CS'' then
	round(COALESCE((select (cs_ce_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''COQ'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) end )as "COQ",
MAX(Case when upper(product) = ''BUSINESS RELEASE'' then tx_cs else 0 end) as "CONVTOGO",
(case when p_and_l = ''TX'' then 
	round(COALESCE((select (tx_ce_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''STRETCH'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2)
when p_and_l = ''CS'' then
	round(COALESCE((select (cs_ce_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''STRETCH'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) end ) as "STRETCH",
(case when p_and_l = ''TX'' then 
	round(COALESCE((select ((risk_val)*(-1))/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''TX'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2)
when p_and_l = ''CS'' then
	round(COALESCE((select ((risk_val)*(-1))/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''CS'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) end ) as "RISK",
(case when p_and_l = ''TX'' then 
	round(COALESCE((select (opp_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''TX'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2)
when p_and_l = ''CS'' then
	round(COALESCE((select (opp_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''CS'' and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) end ) as "OPP"
from ';

IF (Trim(in_product) = '' or in_product is null) and (Trim(in_ou_name) = '' or in_ou_name is null) and (Trim(in_og_region) = '' or in_og_region is null) and (Trim(in_region) = '' or in_region is null) and (Trim(in_subregion) = '' or in_subregion is null) and (Trim(in_end_user_country_disc) = '' or in_end_user_country_disc is null) and (Trim(in_mother_job) = '' or in_mother_job is null)and (Trim(in_enduser_cust_name) = '' or in_enduser_cust_name is null) and (Trim(in_costing_project) = '' or in_costing_project is null) and (Trim(in_order_type) = '' or in_order_type is null) then
Raise Notice 'All data entry';

v_view2_sql =  v_view2_sql || '(

Select ''TX''::character varying as p_and_l,round(COALESCE((select round((tx_ce_val/1000),2) as tx from fms_ipm_data_entry where trim(upper(identifier)) = ''PARTS''
	 and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''PARTS'' as product 
UNION
Select ''TX''::character varying as p_and_l,round(COALESCE((select round((tx_ce_val/1000),2) as tx from fms_ipm_data_entry where trim(upper(identifier)) = ''FIELD_SERVICES''
	 and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''FIELD_SERVICES'' as product
UNION
Select ''TX''::character varying as p_and_l,round(COALESCE((select round((tx_ce_val/1000),2) as tx from fms_ipm_data_entry where trim(upper(identifier)) = ''REPAIRS''
	 and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''REPAIRS'' as product
UNION
Select ''TX''::character varying as p_and_l,round(COALESCE((select round((tx_ce_val/1000),2) as tx from fms_ipm_data_entry where trim(upper(identifier)) = ''CONVTOGO''
	 and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''BUSINESS RELEASE'' as product
UNION
Select ''CS''::character varying as p_and_l,round(COALESCE((select round(( cs_ce_val/1000),2) as cs from fms_ipm_data_entry where trim(upper(identifier)) = ''PARTS''
	 and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''PARTS'' as product 
UNION
Select ''CS''::character varying as p_and_l,round(COALESCE((select round(( cs_ce_val/1000),2) as  cs from fms_ipm_data_entry where trim(upper(identifier)) = ''FIELD_SERVICES''
	 and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''FIELD_SERVICES'' as product
UNION
Select ''CS''::character varying as p_and_l,round(COALESCE((select round(( cs_ce_val/1000),2) as  cs from fms_ipm_data_entry where trim(upper(identifier)) = ''REPAIRS''
	 and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''REPAIRS'' as product
UNION
Select ''CS''::character varying as p_and_l,round(COALESCE((select round((cs_ce_val/1000),2) as tx from fms_ipm_data_entry where trim(upper(identifier)) = ''CONVTOGO''
	 and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''BUSINESS RELEASE'' as product
) as subq_ce_tx_cs ';

else

Raise Notice 'Master + Data Entry';

v_view2_sql =  v_view2_sql || '(
select round(COALESCE(((sum(p_cm_dollar_by_1000))/1000),0),2) as tx_cs, product, p_and_l from parts_filter_data_product_v  
where upper(p_and_l ) in (''TX'', ''CS'')
and new_p_and_l = '|| '''' || in_new_p_and_l || '''' ||'
group by p_and_l, product

UNION

select round(COALESCE(((sum(p_cm_dollar_by_1000))/1000),0),2) as tx_cs, trim(UPPER(basket)) as product, p_and_l from parts_filter_data_product_v  
where upper(p_and_l ) in (''TX'', ''CS'')
and new_p_and_l = '|| '''' || in_new_p_and_l || '''' ||'
and trim(upper(basket)) = ''BUSINESS RELEASE''
group by p_and_l, basket

) as subq_ce_tx_cs';
end if;

v_view2_sql =  v_view2_sql || ' group by p_and_l )  as subq_ce_tx_cs_abs
)

union

(select * from (
Select ''INS''::character varying as type,
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''PARTS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "PARTS",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''FIELD_SERVICES''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "FIELD_SERVICES",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''REPAIRS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "REPAIRS",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''OTHER_GE_LE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OTHER_GE_LE",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CT",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''HQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "HQ",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''COQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "COQ",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CONVTOGO''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CONVTOGO",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''STRETCH''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "STRETCH",
round(COALESCE((select (risk_val*(-1))/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''INST''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "RISK",
round(COALESCE((select (opp_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''INST''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OPP"
) as subq_ce_ins ) 


union

(
select * from (
Select ''PE_TX''::character varying as type,
round(COALESCE((select round((tx_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''PARTS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "PARTS",
round(COALESCE((select round((tx_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''FIELD_SERVICES''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "FIELD_SERVICES",
round(COALESCE((select round((tx_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''REPAIRS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "REPAIRS",
round(COALESCE((select round((tx_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''OTHER_GE_LE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OTHER_GE_LE",
round(COALESCE((select round((tx_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CT",
round(COALESCE((select round((tx_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''HQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "HQ",
round(COALESCE((select round((tx_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''COQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "COQ",
round(COALESCE((select round((tx_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CONVTOGO''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CONVTOGO",
round(COALESCE((select round((tx_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''STRETCH''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "STRETCH",
round(COALESCE((select (tx_pe_val*(-1))/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''RISK_PE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "RISK",
round(COALESCE((select (tx_pe_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''OPPS_PE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OPP"
) as subq_pe_tx )

union

(
select * from (
Select ''PE_CS''::character varying as type,
round(COALESCE((select round((cs_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''PARTS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "PARTS",
round(COALESCE((select round((cs_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''FIELD_SERVICES''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "FIELD_SERVICES",
round(COALESCE((select round((cs_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''REPAIRS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "REPAIRS",
round(COALESCE((select round((cs_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''OTHER_GE_LE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OTHER_GE_LE",
round(COALESCE((select round((cs_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CT",
round(COALESCE((select round((cs_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''HQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "HQ",
round(COALESCE((select round((cs_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''COQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "COQ",
round(COALESCE((select round((cs_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CONVTOGO''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CONVTOGO",
round(COALESCE((select round((cs_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''STRETCH''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "STRETCH",
round(COALESCE((select (cs_pe_val*(-1))/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''RISK_PE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "RISK",
round(COALESCE((select (cs_pe_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''OPPS_PE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OPP"
) as subq_pe_cs )

union

(
select * from (
Select ''PE_INS''::character varying as type,
round(COALESCE((select round((ins_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''PARTS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "PARTS",
round(COALESCE((select round((ins_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''FIELD_SERVICES''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "FIELD_SERVICES",
round(COALESCE((select round((ins_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''REPAIRS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "REPAIRS",
round(COALESCE((select round((ins_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''OTHER_GE_LE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OTHER_GE_LE",
round(COALESCE((select round((ins_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CT",
round(COALESCE((select round((ins_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''HQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "HQ",
round(COALESCE((select round((ins_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''COQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "COQ",
round(COALESCE((select round((ins_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CONVTOGO''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CONVTOGO",
round(COALESCE((select round((ins_pe_val/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''STRETCH''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "STRETCH",
round(COALESCE((select (ins_pe_val*(-1))/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''RISK_PE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "RISK",
round(COALESCE((select (ins_pe_val)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''OPPS_PE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OPP"
) as subq_pe_ins )

union


select * from (
	Select ''BACKLOG_PE_TX''::character varying as type,
round(COALESCE((select round((tx_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''PARTS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "PARTS",
round(COALESCE((select round((tx_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''FIELD_SERVICES''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "FIELD_SERVICES",
round(COALESCE((select round((tx_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''REPAIRS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "REPAIRS",
round(COALESCE((select round((tx_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''OTHER_GE_LE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OTHER_GE_LE",
round(COALESCE((select round((tx_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CT",
round(COALESCE((select round((tx_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''HQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "HQ",
round(COALESCE((select round((tx_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''COQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "COQ",
round(COALESCE((select round((tx_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CONVTOGO''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CONVTOGO",
round(COALESCE((select round((tx_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''STRETCH''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "STRETCH",
 0 as "RISK",
 0 as "OPP"
) as subq_backlog_pe_tx

union


select * from (
	Select ''BACKLOG_PE_CS''::character varying as type,
round(COALESCE((select round((cs_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''PARTS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "PARTS",
round(COALESCE((select round((cs_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''FIELD_SERVICES''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "FIELD_SERVICES",
round(COALESCE((select round((cs_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''REPAIRS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "REPAIRS",
round(COALESCE((select round((cs_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''OTHER_GE_LE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OTHER_GE_LE",
round(COALESCE((select round((cs_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CT",
round(COALESCE((select round((cs_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''HQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "HQ",
round(COALESCE((select round((cs_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''COQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "COQ",
round(COALESCE((select round((cs_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CONVTOGO''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CONVTOGO",
round(COALESCE((select round((cs_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''STRETCH''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "STRETCH",
 0 as "RISK",
 0 as "OPP"
) as subq_backlog_pe_cs

union


select * from (
	Select ''BACKLOG_PE_INS''::character varying as type,
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''PARTS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "PARTS",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''FIELD_SERVICES''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "FIELD_SERVICES",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''REPAIRS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "REPAIRS",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''OTHER_GE_LE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OTHER_GE_LE",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CT",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''HQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "HQ",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''COQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "COQ",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CONVTOGO''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CONVTOGO",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''STRETCH''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "STRETCH",
 0 as "RISK",
 0 as "OPP"
) as subq_backlog_pe_ins

UNION

select * from (
	Select ''CWD_TX''::character varying as type,
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''PARTS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "PARTS",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''FIELD_SERVICES''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "FIELD_SERVICES",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''REPAIRS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "REPAIRS",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''OTHER_GE_LE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OTHER_GE_LE",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CT",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''HQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "HQ",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''COQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "COQ",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CONVTOGO''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CONVTOGO",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''STRETCH''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "STRETCH",
round(COALESCE((select (ins_pe_backlog*(-1))/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''RISK_PE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "RISK",
round(COALESCE((select (ins_pe_backlog)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''OPPS_PE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OPP"
) as subq_cwd_tx

UNION

select * from (
	Select ''CWD_CS''::character varying as type,
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''PARTS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "PARTS",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''FIELD_SERVICES''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "FIELD_SERVICES",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''REPAIRS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "REPAIRS",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''OTHER_GE_LE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OTHER_GE_LE",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CT",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''HQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "HQ",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''COQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "COQ",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CONVTOGO''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CONVTOGO",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''STRETCH''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "STRETCH",
round(COALESCE((select (ins_pe_backlog*(-1))/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''RISK_PE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "RISK",
round(COALESCE((select (ins_pe_backlog)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''OPPS_PE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OPP"
) as subq_cwd_cs

UNION

select * from (
	Select ''CWD_INS''::character varying as type,
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''PARTS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "PARTS",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''FIELD_SERVICES''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "FIELD_SERVICES",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''REPAIRS''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "REPAIRS",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''OTHER_GE_LE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OTHER_GE_LE",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CT",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''HQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "HQ",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''COQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "COQ",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''CONVTOGO''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "CONVTOGO",
round(COALESCE((select round((ins_pe_backlog/1000),2) as ins from fms_ipm_data_entry where trim(upper(identifier)) = ''STRETCH''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "STRETCH",
round(COALESCE((select (ins_pe_backlog*(-1))/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''RISK_PE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "RISK",
round(COALESCE((select (ins_pe_backlog)/1000 from fms_ipm_data_entry where trim(upper(identifier)) = ''OPPS_PE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||' and week = ' || '''' || v_week || '''' || '),0),2) as "OPP"
) as subq_cwd_ins
';


	raise notice '%', v_view1_sql;

	raise notice '%', v_view2_sql;
	
	execute v_view2_sql;


	if (Trim(upper(in_p_and_l)) = 'TX') then

	--'TX';

	--data table

	select 
	(
	COALESCE((select (select 'CE' as type)::text ||';'||"PARTS"||';'||"FIELD_SERVICES"||';'||"REPAIRS"||';'||"OTHER_GE_LE"||';'||"CT"||';'||"HQ"||';'||"COQ"||';'||"CONVTOGO"||';'||"STRETCH"||';'||"RISK"||';'||"OPP" from parts_data_table_product_v where type = 'TX'),
	'CE;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select (select 'PE' as type)::text ||';'||"PARTS"||';'||"FIELD_SERVICES"||';'||"REPAIRS"||';'||"OTHER_GE_LE"||';'||"CT"||';'||"HQ"||';'||"COQ"||';'||"CONVTOGO"||';'||"STRETCH"||';'||"RISK"||';'||"OPP" from parts_data_table_product_v where type = 'PE_TX'),
	'PE;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select (select 'BACKLOG_PE' as type)::text ||';'||"PARTS"||';'||"FIELD_SERVICES"||';'||"REPAIRS"||';'||"OTHER_GE_LE"||';'||"CT"||';'||"HQ"||';'||"COQ"||';'||"CONVTOGO"||';'||"STRETCH"||';'||"RISK"||';'||"OPP" from parts_data_table_product_v where type = 'BACKLOG_PE_TX'),
	'BACKLOG_PE;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select (select 'CWD' as type)::text ||';'||"PARTS"||';'||"FIELD_SERVICES"||';'||"REPAIRS"||';'||"OTHER_GE_LE"||';'||"CT"||';'||"HQ"||';'||"COQ"||';'||"CONVTOGO"||';'||"STRETCH"||';'||"RISK"||';'||"OPP" from parts_data_table_product_v where type = 'CWD_TX'),
	'CWD;0;0;0;0;0;0;0;0;0;0;0')
	)
	into out_data_table;
	

	--chart

	
--blank row

--"PARTS" of blank row is 0

--"FIELD_SERVICES" of blank row

	select abs(round(COALESCE((select "PARTS" from parts_data_table_product_v where upper(type) in ('TX')),0),2)) as blank_field_services  into v_blank_field_services;

	--raise notice 'v_blank_field_services %',v_blank_field_services;

--"REPAIRS" of blank row 

	v_blank_repairs := abs(round(COALESCE(((select "FIELD_SERVICES" from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)) + v_blank_field_services;

	--raise notice 'v_blank_repairs %',v_blank_repairs;
	
--"OTHER_GE_LE" of blank row 	

	v_blank_other_ge_le := abs(round(COALESCE(((select "REPAIRS" from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)) + v_blank_repairs ;

--"CT" of blank row

	v_blank_ct := abs(round(COALESCE(((select "OTHER_GE_LE" from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)) + v_blank_other_ge_le;

--"HQ" of blank row

	v_blank_hq := abs(round(COALESCE(((select "CT" from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)) + v_blank_ct;

--"COQ" of blank row

	v_blank_coq := abs(round(COALESCE(((select "HQ" from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)) + v_blank_hq;

--"CONVTOGO" of blank row

	v_blank_convtogo := abs(round(COALESCE(((select "COQ" from parts_data_table_product_v where upper(type) in ('TX'))),0),2))  + v_blank_coq;

--"STRETCH" of blank row

	v_blank_stretch := abs(round(COALESCE(((select "CONVTOGO" from parts_data_table_product_v where upper(type) in ('TX'))),0),2))  + v_blank_convtogo;

--"RISK" of blank row

	v_blank_risk := (v_blank_stretch-abs(COALESCE((select "RISK" from parts_data_table_product_v where upper(type) in ('TX')),0)));

--"OPP" of blank row

	v_blank_opp := v_blank_risk;

--blank row 

	select COALESCE((0 ||';'|| abs(v_blank_field_services) ||';'|| abs(v_blank_repairs) ||';'|| abs(v_blank_other_ge_le) ||';'|| abs(v_blank_ct) ||';'|| abs(v_blank_hq) ||';'|| abs(v_blank_coq) ||';'|| abs(v_blank_convtogo) ||';'|| abs(v_blank_stretch)
	||';'|| abs(v_blank_risk) ||';'|| abs(v_blank_opp) ||';'||0||';'||0),
	'0;0;0;0;0;0;0;0;0;0;0;0;0') as blank_row into v_blank_row;

--solid row

	select (
	round(COALESCE((select abs("PARTS") from parts_data_table_product_v where upper(type) in ('TX')),0),2)
	||';'||
	round(COALESCE(((select abs("FIELD_SERVICES") from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)
	||';'||
	round(COALESCE(((select abs("REPAIRS") from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)
	||';'||
	round(COALESCE(((select abs("OTHER_GE_LE") from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)
	||';'||
	round(COALESCE(((select abs("CT") from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)
	||';'||
	round(COALESCE(((select abs("HQ") from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)
	||';'||
	round(COALESCE(((select abs("COQ") from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)
	||';'||
	round(COALESCE(((select abs("CONVTOGO") from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)
	||';'||
	round(COALESCE(((select abs("STRETCH") from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)
	||';'||
	round(COALESCE(((select abs("RISK") from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)
	||';'||
	round(COALESCE(((select abs("OPP") from parts_data_table_product_v where upper(type) in ('TX')) ),0),2)
	||';'||
	0||';'||
	round(COALESCE(((select abs(op_val)/1000 from fms_ipm_data_entry where upper(identifier) in ('TX') 
		and business_unit = in_new_p_and_l and week = v_week) ),0),2)
	) into v_solid_row;

	select 
	v_blank_row||'~'||v_solid_row
	 into out_charts;


	select '-1' into out_actual;
	select '-1' into out_unconfirmed;


/*
--actual & unconfirmed

		IF (Trim(in_product) = '' or in_product is null) and (Trim(in_ou_name) = '' or in_ou_name is null) and 
			(Trim(in_og_region) = '' or in_og_region is null) and (Trim(in_region) = '' or in_region is null) and 
			(Trim(in_subregion) = '' or in_subregion is null) and (Trim(in_end_user_country_disc) = '' or in_end_user_country_disc is null) and 
			(Trim(in_mother_job) = '' or in_mother_job is null)and (Trim(in_enduser_cust_name) = '' or in_enduser_cust_name is null) and 
			(Trim(in_costing_project) = '' or in_costing_project is null) and (Trim(in_order_type) = '' or in_order_type is null) then
		-- 'All data entry'
	
			select (
				round(COALESCE((select round((actuals_val/1000), 2) as op from fms_ipm_data_entry where upper(identifier) = 'TX'
				and business_unit = in_new_p_and_l and week = v_week),0),2)
			) into out_actual;
			select (
				round(COALESCE((select round((unconfirmed_val/1000), 2) as op from fms_ipm_data_entry where upper(identifier) = 'TX'
				and business_unit = in_new_p_and_l and week = v_week),0),2)
			) into out_unconfirmed;

		else

			select (
				(select round((COALESCE((select sum(p_cm_dollar_by_1000)/1000 from parts_filter_data_product_v 
					where TRIM(upper(project_type)) = TRIM('TX') and upper(invoice_status) = trim('C')),0)),2))+
				(select round((COALESCE((select sum(p_cm_dollar_by_1000)/1000 from parts_filter_data_product_v 
					where TRIM(upper(project_type)) in (TRIM('GLOBAL CONTRACTUAL'), TRIM('GLOBAL EW'), TRIM('TMGL')) and trim(upper(parts_status)) = trim('SHIPPED') 
					AND ACTUAL_SHIPMENT_DATE + (interval '15 day')> current_timestamp),0)),2))
			) into out_actual;

			select (
				(select round((COALESCE((select sum(p_cm_dollar_by_1000)/1000 from parts_filter_data_product_v 
					where TRIM(upper(project_type)) = TRIM('TX') and upper(invoice_status) = trim('U')),0)),2))+
				(select round((COALESCE((select sum(p_cm_dollar_by_1000)/1000 from parts_filter_data_product_v 
					where TRIM(upper(project_type)) in (TRIM('GLOBAL CONTRACTUAL'), TRIM('GLOBAL EW'), TRIM('TMGL')) and trim(upper(parts_status)) = trim('SHIPPED') 
					AND ACTUAL_SHIPMENT_DATE + (interval '15 day')< current_timestamp),0)),2))
			) into out_unconfirmed;

		end if;

*/

	elsif (Trim(upper(in_p_and_l)) = 'CS') then

	--'CS';

	select 
	(
	COALESCE((select (select 'CE' as type)::text ||';'||"PARTS"||';'||"FIELD_SERVICES"||';'||"REPAIRS"||';'||"OTHER_GE_LE"||';'||"CT"||';'||"HQ"||';'||"COQ"||';'||"CONVTOGO"||';'||"STRETCH"||';'||"RISK"||';'||"OPP" from parts_data_table_product_v where type = 'CS'),
	'CE;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select (select 'PE' as type)::text ||';'||"PARTS"||';'||"FIELD_SERVICES"||';'||"REPAIRS"||';'||"OTHER_GE_LE"||';'||"CT"||';'||"HQ"||';'||"COQ"||';'||"CONVTOGO"||';'||"STRETCH"||';'||"RISK"||';'||"OPP" from parts_data_table_product_v where type = 'PE_CS'),
	'PE;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select (select 'BACKLOG_PE' as type)::text ||';'||"PARTS"||';'||"FIELD_SERVICES"||';'||"REPAIRS"||';'||"OTHER_GE_LE"||';'||"CT"||';'||"HQ"||';'||"COQ"||';'||"CONVTOGO"||';'||"STRETCH"||';'||"RISK"||';'||"OPP" from parts_data_table_product_v where type = 'BACKLOG_PE_CS'),
	'BACKLOG_PE;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select (select 'CWD' as type)::text ||';'||"PARTS"||';'||"FIELD_SERVICES"||';'||"REPAIRS"||';'||"OTHER_GE_LE"||';'||"CT"||';'||"HQ"||';'||"COQ"||';'||"CONVTOGO"||';'||"STRETCH"||';'||"RISK"||';'||"OPP" from parts_data_table_product_v where type = 'CWD_CS'),
	'CWD;0;0;0;0;0;0;0;0;0;0;0')
	)
	into out_data_table;
	

	--chart

	
--blank row

--"PARTS" of blank row is 0

--"FIELD_SERVICES" of blank row

	select abs(round(COALESCE((select "PARTS" from parts_data_table_product_v where upper(type) in ('CS')),0),2)) as blank_field_services  into v_blank_field_services;

	--raise notice 'v_blank_field_services %',v_blank_field_services;

--"REPAIRS" of blank row 

	v_blank_repairs := abs(round(COALESCE(((select "FIELD_SERVICES" from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)) + v_blank_field_services;

	--raise notice 'v_blank_repairs %',v_blank_repairs;
	
--"OTHER_GE_LE" of blank row 	

	v_blank_other_ge_le := abs(round(COALESCE(((select "REPAIRS" from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)) + v_blank_repairs ;

--"CT" of blank row

	v_blank_ct := abs(round(COALESCE(((select "OTHER_GE_LE" from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)) + v_blank_other_ge_le;

--"HQ" of blank row

	v_blank_hq := abs(round(COALESCE(((select "CT" from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)) + v_blank_ct;

--"COQ" of blank row

	v_blank_coq := abs(round(COALESCE(((select "HQ" from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)) + v_blank_hq;

--"CONVTOGO" of blank row

	v_blank_convtogo := abs(round(COALESCE(((select "COQ" from parts_data_table_product_v where upper(type) in ('CS'))),0),2))  + v_blank_coq;

--"STRETCH" of blank row

	v_blank_stretch := abs(round(COALESCE(((select "CONVTOGO" from parts_data_table_product_v where upper(type) in ('CS'))),0),2))  + v_blank_convtogo;

--"RISK" of blank row

	v_blank_risk := (v_blank_stretch-abs(COALESCE((select "RISK" from parts_data_table_product_v where upper(type) in ('CS')),0)));

--"OPP" of blank row

	v_blank_opp := v_blank_risk;

--blank row 

	select COALESCE((0 ||';'|| abs(v_blank_field_services) ||';'|| abs(v_blank_repairs) ||';'|| abs(v_blank_other_ge_le) ||';'|| abs(v_blank_ct) ||';'|| abs(v_blank_hq) ||';'|| abs(v_blank_coq) ||';'|| abs(v_blank_convtogo) ||';'|| abs(v_blank_stretch)
	||';'|| abs(v_blank_risk) ||';'|| abs(v_blank_opp) ||';'||0||';'||0),
	'0;0;0;0;0;0;0;0;0;0;0;0;0') as blank_row into v_blank_row;

--solid row

	select (
	round(COALESCE((select abs("PARTS") from parts_data_table_product_v where upper(type) in ('CS')),0),2)
	||';'||
	round(COALESCE(((select abs("FIELD_SERVICES") from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("REPAIRS") from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("OTHER_GE_LE") from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("CT") from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("HQ") from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("COQ") from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("CONVTOGO") from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("STRETCH") from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("RISK") from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("OPP") from parts_data_table_product_v where upper(type) in ('CS')) ),0),2)
	||';'||
	0||';'||
	round(COALESCE(((select abs(op_val)/1000 from fms_ipm_data_entry where upper(identifier) in ('CS') 
		and business_unit = in_new_p_and_l and week = v_week) ),0),2)
	) into v_solid_row;

	select 
	v_blank_row||'~'||v_solid_row
	 into out_charts;


	select '-1' into out_actual;
	select '-1' into out_unconfirmed;


/*
--actual & unconfirmed

	IF (Trim(in_product) = '' or in_product is null) and (Trim(in_ou_name) = '' or in_ou_name is null) and 
			(Trim(in_og_region) = '' or in_og_region is null) and (Trim(in_region) = '' or in_region is null) and 
			(Trim(in_subregion) = '' or in_subregion is null) and (Trim(in_end_user_country_disc) = '' or in_end_user_country_disc is null) and 
			(Trim(in_mother_job) = '' or in_mother_job is null)and (Trim(in_enduser_cust_name) = '' or in_enduser_cust_name is null) and 
			(Trim(in_costing_project) = '' or in_costing_project is null) and (Trim(in_order_type) = '' or in_order_type is null) then
		-- 'All data entry'
	
			select (
				round(COALESCE((select round((actuals_val/1000), 2) as op from fms_ipm_data_entry where upper(identifier) = 'CS'
				and business_unit = in_new_p_and_l and week = v_week ),0),2)
			) into out_actual;
			select (
				round(COALESCE((select round((unconfirmed_val/1000), 2) as op from fms_ipm_data_entry where upper(identifier) = 'CS'
				and business_unit = in_new_p_and_l and week = v_week),0),2)
			) into out_unconfirmed;

		else

			select (
				(select round((COALESCE((select sum(p_cm_dollar_by_1000)/1000 from parts_filter_data_product_v 
					where TRIM(upper(project_type)) = TRIM('TX') and upper(invoice_status) = trim('C')),0)),2))+
				(select round((COALESCE((select sum(p_cm_dollar_by_1000)/1000 from parts_filter_data_product_v 
					where TRIM(upper(project_type)) in (TRIM('GLOBAL CONTRACTUAL'), TRIM('GLOBAL EW'), TRIM('TMGL')) and trim(upper(parts_status)) = trim('SHIPPED') 
					AND ACTUAL_SHIPMENT_DATE + (interval '15 day')> current_timestamp),0)),2))
			) into out_actual;

			select (
				(select round((COALESCE((select sum(p_cm_dollar_by_1000)/1000 from parts_filter_data_product_v 
					where TRIM(upper(project_type)) = TRIM('TX') and upper(invoice_status) = trim('U')),0)),2))+
				(select round((COALESCE((select sum(p_cm_dollar_by_1000)/1000 from parts_filter_data_product_v 
					where TRIM(upper(project_type)) in (TRIM('GLOBAL CONTRACTUAL'), TRIM('GLOBAL EW'), TRIM('TMGL')) and trim(upper(parts_status)) = trim('SHIPPED') 
					AND ACTUAL_SHIPMENT_DATE + (interval '15 day')< current_timestamp),0)),2))
			) into out_unconfirmed;

		end if;

*/
	
	else

	--'INS';

	--data table

	select 
	(
	COALESCE((select (select 'CE' as type)::text ||';'||"PARTS"||';'||"FIELD_SERVICES"||';'||"REPAIRS"||';'||"OTHER_GE_LE"||';'||"CT"||';'||"HQ"||';'||"COQ"||';'||"CONVTOGO"||';'||"STRETCH"||';'||"RISK"||';'||"OPP" from parts_data_table_product_v where type = 'INS'),
	'CE;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select (select 'PE' as type)::text ||';'||"PARTS"||';'||"FIELD_SERVICES"||';'||"REPAIRS"||';'||"OTHER_GE_LE"||';'||"CT"||';'||"HQ"||';'||"COQ"||';'||"CONVTOGO"||';'||"STRETCH"||';'||"RISK"||';'||"OPP" from parts_data_table_product_v where type = 'PE_INS'),
	'PE;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select (select 'BACKLOG_PE' as type)::text ||';'||"PARTS"||';'||"FIELD_SERVICES"||';'||"REPAIRS"||';'||"OTHER_GE_LE"||';'||"CT"||';'||"HQ"||';'||"COQ"||';'||"CONVTOGO"||';'||"STRETCH"||';'||"RISK"||';'||"OPP" from parts_data_table_product_v where type = 'BACKLOG_PE_INS'),
	'BACKLOG_PE;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select (select 'CWD' as type)::text ||';'||"PARTS"||';'||"FIELD_SERVICES"||';'||"REPAIRS"||';'||"OTHER_GE_LE"||';'||"CT"||';'||"HQ"||';'||"COQ"||';'||"CONVTOGO"||';'||"STRETCH"||';'||"RISK"||';'||"OPP" from parts_data_table_product_v where type = 'CWD_INS'),
	'CWD;0;0;0;0;0;0;0;0;0;0;0')
	)
	into out_data_table;
	

	--chart

	
--blank row

--"PARTS" of blank row is 0

--"FIELD_SERVICES" of blank row

	select abs(round(COALESCE((select "PARTS" from parts_data_table_product_v where upper(type) in ('INS')),0),2)) as blank_field_services  into v_blank_field_services;

	--raise notice 'v_blank_field_services %',v_blank_field_services;

--"REPAIRS" of blank row 

	v_blank_repairs := abs(round(COALESCE(((select "FIELD_SERVICES" from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)) + v_blank_field_services;

	--raise notice 'v_blank_repairs %',v_blank_repairs;
	
--"OTHER_GE_LE" of blank row 	

	v_blank_other_ge_le := abs(round(COALESCE(((select "REPAIRS" from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)) + v_blank_repairs ;

--"CT" of blank row

	v_blank_ct := abs(round(COALESCE(((select "OTHER_GE_LE" from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)) + v_blank_other_ge_le;

--"HQ" of blank row

	v_blank_hq := abs(round(COALESCE(((select "CT" from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)) + v_blank_ct;

--"COQ" of blank row

	v_blank_coq := abs(round(COALESCE(((select "HQ" from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)) + v_blank_hq;

--"CONVTOGO" of blank row

	v_blank_convtogo := abs(round(COALESCE(((select "COQ" from parts_data_table_product_v where upper(type) in ('INS'))),0),2))  + v_blank_coq;

--"STRETCH" of blank row

	v_blank_stretch := abs(round(COALESCE(((select "CONVTOGO" from parts_data_table_product_v where upper(type) in ('INS'))),0),2))  + v_blank_convtogo;

--"RISK" of blank row

	v_blank_risk := (v_blank_stretch-abs(COALESCE((select "RISK" from parts_data_table_product_v where upper(type) in ('INS')),0)));

--"OPP" of blank row

	v_blank_opp := v_blank_risk;

--blank row 

	select COALESCE((0 ||';'|| abs(v_blank_field_services) ||';'|| abs(v_blank_repairs) ||';'|| abs(v_blank_other_ge_le) ||';'|| abs(v_blank_ct) ||';'|| abs(v_blank_hq) ||';'|| abs(v_blank_coq) ||';'|| abs(v_blank_convtogo) ||';'|| abs(v_blank_stretch)
	||';'|| abs(v_blank_risk) ||';'|| abs(v_blank_opp) ||';'||0||';'||0),
	'0;0;0;0;0;0;0;0;0;0;0;0;0') as blank_row into v_blank_row;

--solid row

	select (
	round(COALESCE((select abs("PARTS") from parts_data_table_product_v where upper(type) in ('INS')),0),2)
	||';'||
	round(COALESCE(((select abs("FIELD_SERVICES") from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("REPAIRS") from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("OTHER_GE_LE") from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("CT") from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("HQ") from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("COQ") from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("CONVTOGO") from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("STRETCH") from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("RISK") from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)
	||';'||
	round(COALESCE(((select abs("OPP") from parts_data_table_product_v where upper(type) in ('INS')) ),0),2)
	||';'||
	0||';'||
	round(COALESCE(((select abs(op_val)/1000 from fms_ipm_data_entry where upper(identifier) in ('INST') 
		and business_unit = in_new_p_and_l and week = v_week) ),0),2)
	) into v_solid_row;

	select 
	v_blank_row||'~'||v_solid_row
	 into out_charts;


	select '-1' into out_actual;
	select '-1' into out_unconfirmed;
	

/*
--actual & unconfirmed
	
	select (
		round(COALESCE((select round((actuals_val/1000), 2) as op from fms_ipm_data_entry where upper(identifier) = 'INST'
		and business_unit = in_new_p_and_l and week = v_week),0),2)
	) into out_actual;
	select (
		round(COALESCE((select round((unconfirmed_val/1000), 2) as op from fms_ipm_data_entry where upper(identifier) = 'INST'
		and business_unit = in_new_p_and_l and week = v_week),0),2)
	) into out_unconfirmed;
*/	

	end if;
	
	
	drop view IF EXISTS parts_data_table_product_v;
	
	drop view IF EXISTS parts_filter_data_product_v;

	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_ipm_walk_by_product',
			     v_proc_paras ,
			     sqlerrm,
			     'DATABASE ERROR');	

	drop view IF EXISTS parts_data_table_product_v;	
	drop view IF EXISTS parts_filter_data_product_v;
				     	
	--RAISE NOTICE 'SQL ERROR %', sqlerrm;
	select 'DATABASE ERROR' into out_data_table;
	select 'DATABASE ERROR' into out_charts;
	select 'DATABASE ERROR' into out_actual;
	select 'DATABASE ERROR' into out_unconfirmed;
	
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
