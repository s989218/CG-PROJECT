-- Function: fms_ipm_walk_by_region(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying)

-- DROP FUNCTION fms_ipm_walk_by_region(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION fms_ipm_walk_by_region(IN in_new_p_and_l character varying, IN in_p_and_l character varying, IN in_product character varying, IN in_ou_name character varying, IN in_og_region character varying, IN in_region character varying, IN in_subregion character varying, IN in_end_user_country_disc character varying, IN in_mother_job character varying, IN in_enduser_cust_name character varying, IN in_costing_project character varying, IN in_order_type character varying, IN in_week character varying, OUT out_data_table character varying, OUT out_charts character varying)
  RETURNS record AS
$BODY$

declare

	v_view1_sql character varying;
	v_view2_sql character varying;
	v_blank_china numeric;
	v_blank_europe numeric;
	v_blank_india numeric;
	v_blank_latam numeric;
	v_blank_menat numeric;
	v_blank_nam numeric;
	v_blank_rcis numeric;
	v_blank_ssa numeric;
	v_blank_sc numeric;
	v_blank_hq numeric;
	v_blank_risk numeric;
	v_blank_opp numeric;
	v_total_val numeric;
	v_op_total_val numeric;
	v_gap_val numeric;
	v_blank_row character varying;
	v_gap_row character varying;
	v_total_row character varying;
	v_tx_row character varying;
	v_cs_row character varying;
	v_ins_row character varying;
	v_hq_row character varying;
	v_risk_row character varying;
	v_opp_row character varying;
	v_other_row character varying;
	v_proc_paras character varying;
	v_coalesce_data_table character varying;
	v_week character varying;


begin

		v_proc_paras = in_new_p_and_l||';'||
			in_p_and_l||';'||
			in_product||';'||
			in_ou_name||';'||
			in_og_region||';'||
			in_region||';'||
			in_subregion||';'||
			in_end_user_country_disc||';'||
			in_mother_job||';'||
			in_enduser_cust_name||';'||
			in_costing_project||';'||
			in_order_type||';'||
			in_week;

	v_week := in_week;
	
	if(v_week = '' or v_week is null) then 
		v_week  := (extract (week from current_timestamp))::character varying;
	else
		v_week := v_week;
	end if;
	

	v_view1_sql = 'create or replace temp view parts_filter_data_region_v as select COALESCE(parts.p_cm_dollar_by_1000,0) as p_cm_dollar_by_1000, parts.p_r_by_o, master.p_and_l as p_and_l, master.new_p_and_l as new_p_and_l, 
		(case when master.new_p_and_l = ''TMS'' then trim(master.region)
			else trim(master.og_region) end) as region 
			from fms_ipm_parts_edit_fields parts , fms_ipm_master master  where master.concatenate = parts.p_concatenate
			AND master.sales_date_year_qtr in (extract (year from current_timestamp)||''-''||extract (quarter from current_timestamp))
		  AND (upper(p_r_by_o) !=  ''OPPS''  or p_r_by_o is null)
		  AND COALESCE(master.new_p_and_l,'''') ~* ' || '''' || in_new_p_and_l || '''' || 
		' AND COALESCE(master.p_and_l, '''') ~* ' || '''' || in_p_and_l || '''' ||  
		' AND COALESCE(master.product, '''') ~*' || '''' || in_product || '''' ||  
		' AND COALESCE(master.ou_name, '''') ~*' || '''' || in_ou_name || '''' ||  
		' AND COALESCE(master.og_region, '''') ~*' || '''' || in_og_region || '''' ||  
		' AND COALESCE(master.region, '''') ~*' || '''' || in_region || '''' ||  
		' AND COALESCE(master.subregion, '''') ~*' || '''' || in_subregion || '''' || 
		' AND COALESCE(master.end_user_country_disc, '''') ~*' || '''' || in_end_user_country_disc || '''' || 
		' AND COALESCE(master.mother_job, '''') ~*' || '''' || in_mother_job || '''' ||  
		' AND COALESCE(master.enduser_cust_name, '''') ~*' || '''' || in_enduser_cust_name || '''' ||  
		' AND COALESCE(master.costing_project, '''') ~*' || '''' || in_costing_project || '''' || 
		' AND COALESCE(master.order_type, '''') ~*' || '''' || in_order_type  || '''' ;

		
	execute v_view1_sql;

--data table

	v_view2_sql = 'create or replace temp view parts_data_table_region_v as
(select type, (case when "APANZ_APAC" = -2147483648.00 then 0.00 else "APANZ_APAC" end), (case when "CHINA_AMERICAS" = -2147483648.00 then 0.00 else "CHINA_AMERICAS" end),
	(case when "EUROPE" = -2147483648.00 then 0.00 else "EUROPE" end), (case when "INDIA_ATM" = -2147483648.00 then 0.00 else "INDIA_ATM" end),
	(case when "LATIN_AMERICA" = -2147483648.00 then 0.00 else "LATIN_AMERICA" end), (case when "MENAT" = -2147483648.00 then 0.00 else "MENAT" end),
	(case when "NORTH_AMERICA" = -2147483648.00 then 0.00 else "NORTH_AMERICA" end), (case when "RUSSIA_CIS_MET" = -2147483648.00 then 0.00 else "RUSSIA_CIS_MET" end),
	(case when "SUB_SAHARAN_AFRICA" = -2147483648.00 then 0.00 else "SUB_SAHARAN_AFRICA" end), "SC", "HQ", "Risk", "Opp","total","gap", "OP" 
	from 
(Select p_and_l as type,
MAX(Case when TRIM(upper(region)) in (''APANZ'',''APAC'') then tx_cs else -2147483648.00 end) as "APANZ_APAC",
MAX(Case when TRIM(upper(region)) in (''CHINA'',''AMERICAS'') then tx_cs else -2147483648.00 end) as "CHINA_AMERICAS",
MAX(Case when TRIM(upper(region)) = ''EUROPE'' then tx_cs else -2147483648.00 end) as "EUROPE",
MAX(Case when TRIM(upper(region)) in (''INDIA'',''ATM'') then tx_cs else -2147483648.00 end) as "INDIA_ATM",
MAX(Case when TRIM(upper(region)) in (''LATIN_AMERICA'',''LATIN AMERICA'',''LATAM'') then tx_cs else -2147483648.00 end) as "LATIN_AMERICA",
MAX(Case when TRIM(upper(region)) = ''MENAT'' then tx_cs else -2147483648.00 end) as "MENAT",
MAX(Case when TRIM(upper(region)) in (''NORTH_AMERICA'',''NORTH AMERICA'') then tx_cs else -2147483648.00 end) as "NORTH_AMERICA",
MAX(Case when TRIM(upper(region)) in (''RUSSIA_CIS'',''RUSSIA & CIS'', ''MET'') then tx_cs else -2147483648.00 end) as "RUSSIA_CIS_MET",
MAX(Case when TRIM(upper(region)) in (''SUB_SAHARAN_AFRICA'',''SUB-SAHARAN AFRICA'',''SSA'') then tx_cs else -2147483648.00 end) as "SUB_SAHARAN_AFRICA", 
0 as "SC",
(case when p_and_l = ''TX'' then 
	round(COALESCE((select ((tx_ce_val)*(1))/1000 from fms_ipm_data_entry where upper(identifier) = ''HQ'' 
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2)
when p_and_l = ''CS'' then
	round(COALESCE((select ((cs_ce_val)*(1))/1000 from fms_ipm_data_entry where upper(identifier) = ''HQ'' 
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) end )as "HQ",
(case when p_and_l = ''TX'' then 
	round(COALESCE((select ((risk_val)*(-1))/1000 from fms_ipm_data_entry where upper(identifier) = ''TX'' 
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2)
when p_and_l = ''CS'' then
	round(COALESCE((select ((risk_val)*(-1))/1000 from fms_ipm_data_entry where upper(identifier) = ''CS'' 
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) end ) as "Risk",
(case when p_and_l = ''TX'' then 
	round(COALESCE((select ((opp_val))/1000 from fms_ipm_data_entry where upper(identifier) = ''TX'' 
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2)
when p_and_l = ''CS'' then
	round(COALESCE((select ((opp_val))/1000 from fms_ipm_data_entry where upper(identifier) = ''CS'' 
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) end ) as "Opp",
0 as "total",
0 as "gap",
(case when p_and_l = ''TX'' then (select round(COALESCE(
	((select sum(tx_op_val) from fms_ipm_data_entry 
	where upper(identifier) in (''APANZ'',''APAC'',''CHINA'',''AMERICAS'',''EUROPE'',''INDIA'',''ATM'',''LATIN_AMERICA'',''LATAM'',''MENAT'', ''NORTH_AMERICA'', ''RUSSIA_CIS'',''MET'', ''SUB_SAHARAN_AFRICA'',''SSA'', ''HQ'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || ')
	)/1000,0),2)
	)
	when p_and_l = ''CS'' then (select round(COALESCE(
	((select sum(cs_op_val) from fms_ipm_data_entry 
	where upper(identifier) in (''APANZ'',''APAC'',''CHINA'',''AMERICAS'',''EUROPE'',''INDIA'',''ATM'',''LATIN_AMERICA'',''LATAM'',''MENAT'', ''NORTH_AMERICA'', ''RUSSIA_CIS'',''MET'', ''SUB_SAHARAN_AFRICA'',''SSA'', ''HQ'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || ')
	)/1000,0),2)
	)
	end)as "OP"
from ';

IF (Trim(in_p_and_l) = '' or in_p_and_l is null) and (Trim(in_product) = '' or in_product is null) and (Trim(in_ou_name) = '' or in_ou_name is null) and (Trim(in_og_region) = '' or in_og_region is null) and (Trim(in_region) = '' or in_region is null) and (Trim(in_subregion) = '' or in_subregion is null) and (Trim(in_end_user_country_disc) = '' or in_end_user_country_disc is null) and (Trim(in_mother_job) = '' or in_mother_job is null)and (Trim(in_enduser_cust_name) = '' or in_enduser_cust_name is null) and (Trim(in_costing_project) = '' or in_costing_project is null) and (Trim(in_order_type) = '' or in_order_type is null) then
Raise Notice 'All data entry';

v_view2_sql =  v_view2_sql || '(

Select ''TX''::character varying as p_and_l,round(COALESCE((select round((tx_ce_val/1000),2) as tx from fms_ipm_data_entry where upper(identifier) in (''APANZ'',''APAC'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''APANZ'' as region 
UNION
Select ''TX''::character varying as p_and_l,round(COALESCE((select round((tx_ce_val/1000),2) as tx from fms_ipm_data_entry where upper(identifier) in (''CHINA'',''AMERICAS'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''CHINA'' as region
UNION
Select ''TX''::character varying as p_and_l,round(COALESCE((select round((tx_ce_val/1000),2) as tx from fms_ipm_data_entry where upper(identifier) in (''EUROPE'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''EUROPE'' as region
UNION
Select ''TX''::character varying as p_and_l,round(COALESCE((select round((tx_ce_val/1000),2) as tx from fms_ipm_data_entry where upper(identifier) in (''INDIA'',''ATM'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''INDIA'' as region
UNION
Select ''TX''::character varying as p_and_l,round(COALESCE((select round((tx_ce_val/1000),2) as tx from fms_ipm_data_entry where upper(identifier) in (''LATIN_AMERICA'', ''LATAM'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''LATIN_AMERICA'' as region
UNION
Select ''TX''::character varying as p_and_l,round(COALESCE((select round((tx_ce_val/1000),2) as tx from fms_ipm_data_entry where upper(identifier) = ''MENAT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''MENAT'' as region
UNION
Select ''TX''::character varying as p_and_l,round(COALESCE((select round((tx_ce_val/1000),2) as tx from fms_ipm_data_entry where upper(identifier) = ''NORTH_AMERICA''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''NORTH_AMERICA'' as region
UNION
Select ''TX''::character varying as p_and_l,round(COALESCE((select round((tx_ce_val/1000),2) as tx from fms_ipm_data_entry where upper(identifier) in (''RUSSIA_CIS'', ''MET'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''RUSSIA_CIS'' as region
UNION
Select ''TX''::character varying as p_and_l,round(COALESCE((select round((tx_ce_val/1000),2) as tx from fms_ipm_data_entry where upper(identifier) in (''SUB_SAHARAN_AFRICA'',''SSA'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''SUB_SAHARAN_AFRICA'' as region
UNION
Select ''CS''::character varying as p_and_l,round(COALESCE((select round(( cs_ce_val/1000),2) as cs from fms_ipm_data_entry where upper(identifier) in (''APANZ'',''APAC'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''APANZ'' as region 
UNION
Select ''CS''::character varying as p_and_l,round(COALESCE((select round(( cs_ce_val/1000),2) as  cs from fms_ipm_data_entry where upper(identifier) in (''CHINA'',''AMERICAS'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''CHINA'' as region
UNION
Select ''CS''::character varying as p_and_l,round(COALESCE((select round(( cs_ce_val/1000),2) as  cs from fms_ipm_data_entry where upper(identifier) = ''EUROPE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''EUROPE'' as region
UNION
Select ''CS''::character varying as p_and_l,round(COALESCE((select round(( cs_ce_val/1000),2) as  cs from fms_ipm_data_entry where upper(identifier) in (''INDIA'',''ATM'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''INDIA'' as region
UNION
Select ''CS''::character varying as p_and_l,round(COALESCE((select round(( cs_ce_val/1000),2) as  cs from fms_ipm_data_entry where upper(identifier) in (''LATIN_AMERICA'', ''LATAM'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''LATIN_AMERICA'' as region
UNION
Select ''CS''::character varying as p_and_l,round(COALESCE((select round(( cs_ce_val/1000),2) as  cs from fms_ipm_data_entry where upper(identifier) = ''MENAT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''MENAT'' as region
UNION
Select ''CS''::character varying as p_and_l,round(COALESCE((select round(( cs_ce_val/1000),2) as  cs from fms_ipm_data_entry where upper(identifier) = ''NORTH_AMERICA''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''NORTH_AMERICA'' as region
UNION
Select ''CS''::character varying as p_and_l,round(COALESCE((select round(( cs_ce_val/1000),2) as  cs from fms_ipm_data_entry where upper(identifier) in (''RUSSIA_CIS'', ''MET'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''RUSSIA_CIS'' as region
UNION
Select ''CS''::character varying as p_and_l,round(COALESCE((select round(( cs_ce_val/1000),2) as  cs from fms_ipm_data_entry where upper(identifier) in (''SUB_SAHARAN_AFRICA'',''SSA'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as tx_cs, ''SUB_SAHARAN_AFRICA'' as region
) as subq_tx_cs ';

else

Raise Notice 'Master + Data Entry';

v_view2_sql =  v_view2_sql || '(
select round(COALESCE(((sum(p_cm_dollar_by_1000))/1000),0),2) as tx_cs, region, p_and_l from parts_filter_data_region_v  
where upper(p_and_l ) in (''TX'', ''CS'')
and new_p_and_l = '|| '''' || in_new_p_and_l || '''' ||'
and region is not null
group by p_and_l, region
) as subq_tx_cs';
end if;

v_view2_sql =  v_view2_sql || ' group by p_and_l )  as subq_tx_cs_abs
)

union

(select * from (
Select ''INS''::character varying as type,
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where upper(identifier) in (''APANZ'',''APAC'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "APANZ_APAC",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where upper(identifier) in (''CHINA'',''AMERICAS'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "CHINA_AMERICAS",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where upper(identifier) = ''EUROPE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "EUROPE",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where upper(identifier) in (''INDIA'',''ATM'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "INDIA_ATM",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where upper(identifier) in (''LATIN_AMERICA'', ''LATAM'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "LATIN_AMERICA",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where upper(identifier) = ''MENAT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "MENAT",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where upper(identifier) = ''NORTH_AMERICA''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "NORTH_AMERICA",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where upper(identifier) in (''RUSSIA_CIS'', ''MET'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "RUSSIA_CIS_MET",
round(COALESCE((select round((ins_ce_val/1000),2) as ins from fms_ipm_data_entry where upper(identifier) in (''SUB_SAHARAN_AFRICA'',''SSA'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "SUB_SAHARAN_AFRICA",
0 as "SC",
round(COALESCE((select (ins_ce_val*(-1))/1000 from fms_ipm_data_entry where upper(identifier) = ''HQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "HQ",
round(COALESCE((select (risk_val*(-1))/1000 from fms_ipm_data_entry where upper(identifier) = ''INST''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "Risk",
round(COALESCE((select (opp_val)/1000 from fms_ipm_data_entry where upper(identifier) = ''INST''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "Opp",
0 as "total",
0 as "gap",
	(select round(COALESCE(
	((select sum(ins_op_val) from fms_ipm_data_entry 
	where upper(identifier) in (''APANZ'',''APAC'',''CHINA'',''AMERICAS'',''EUROPE'',''INDIA'',''ATM'',''LATIN_AMERICA'',''LATAM'',''MENAT'', ''NORTH_AMERICA'', ''RUSSIA_CIS'',''MET'', ''SUB_SAHARAN_AFRICA'',''SSA'', ''HQ'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || ')
	)/1000,0),2)
	) as "OP"
) as subq_ins ) 

union

(
select * from (
Select ''OTHER''::character varying as type,
0 as "APANZ_APAC",
0 as "CHINA_AMERICAS",
0 as "EUROPE",
0 as "INDIA_ATM",
0 as "LATIN_AMERICA",
0 as "MENAT",
0 as "NORTH_AMERICA",
0 as "RUSSIA_CIS_MET",
0 as "SUB_SAHARAN_AFRICA",
round(COALESCE((select ce_val/1000 from fms_ipm_data_entry where upper(identifier) = ''SC''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "SC",
0 as "HQ",
round(COALESCE((select (risk_val*(-1))/1000 from fms_ipm_data_entry where upper(identifier) = ''SC''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "Risk",
round(COALESCE((select (opp_val)/1000 from fms_ipm_data_entry where upper(identifier) = ''SC''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "Opp",
0 as "total",
0 as "gap",
round(COALESCE((select op_val/1000 from fms_ipm_data_entry where upper(identifier) = ''SC''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "OP"
) as subq_other
)

union

(
select * from (
Select ''PE''::character varying as type,
round(COALESCE((select round((pe_val/1000),2) as pe from fms_ipm_data_entry where upper(identifier) in (''APANZ'',''APAC'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "APANZ_APAC",
round(COALESCE((select round((pe_val/1000),2) as pe from fms_ipm_data_entry where upper(identifier) in (''CHINA'',''AMERICAS'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "CHINA_AMERICAS",
round(COALESCE((select round((pe_val/1000),2) as pe from fms_ipm_data_entry where upper(identifier) = ''EUROPE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "EUROPE",
round(COALESCE((select round((pe_val/1000),2) as pe from fms_ipm_data_entry where upper(identifier) in (''INDIA'',''ATM'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "INDIA_ATM",
round(COALESCE((select round((pe_val/1000),2) as pe from fms_ipm_data_entry where upper(identifier) in (''LATIN_AMERICA'', ''LATAM'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "LATIN_AMERICA",
round(COALESCE((select round((pe_val/1000),2) as pe from fms_ipm_data_entry where upper(identifier) = ''MENAT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "MENAT",
round(COALESCE((select round((pe_val/1000),2) as pe from fms_ipm_data_entry where upper(identifier) = ''NORTH_AMERICA''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "NORTH_AMERICA",
round(COALESCE((select round((pe_val/1000),2) as pe from fms_ipm_data_entry where upper(identifier) in (''RUSSIA_CIS'', ''MET'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "RUSSIA_CIS_MET",
round(COALESCE((select round((pe_val/1000),2) as pe from fms_ipm_data_entry where upper(identifier) in (''SUB_SAHARAN_AFRICA'',''SSA'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "SUB_SAHARAN_AFRICA",
round(COALESCE((select round((pe_val/1000),2) as pe from fms_ipm_data_entry where upper(identifier) = ''SC''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "SC",
round(COALESCE((select round((pe_val/1000),2) as pe from fms_ipm_data_entry where upper(identifier) = ''HQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "HQ",
round(COALESCE((select round((risk_val/1000), 2) from fms_ipm_data_entry  where upper(identifier) = ''PE_R_BY_O''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "Risk",
round(COALESCE((select round((opp_val/1000), 2) from fms_ipm_data_entry  where upper(identifier) = ''PE_R_BY_O''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "Opp",
round(COALESCE((select round(sum(pe_val)/1000, 2) from fms_ipm_data_entry where upper(identifier) in 
(''APANZ'',''APAC'',''CHINA'',''AMERICAS'',''EUROPE'',''INDIA'',''ATM'',''LATIN_AMERICA'',''LATAM'',''MENAT'', ''NORTH_AMERICA'', ''RUSSIA_CIS'',''MET'', ''SUB_SAHARAN_AFRICA'',''SSA'', ''HQ'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "total",
round(COALESCE((select round((pe_val/1000), 2) from fms_ipm_data_entry where upper(identifier) = ''PE_REGION_GAP''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "gap",
round(COALESCE((select round((pe_val/1000), 2) from fms_ipm_data_entry  where upper(identifier) = ''OP_REGION_GAP''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "OP"
) as subq_pe )

union

(
select * from (
	Select ''OP''::character varying as type,
	round(COALESCE((select (tx_op_val+cs_op_val+ins_op_val)/1000 as op from fms_ipm_data_entry where upper(identifier) in (''APANZ'',''APAC'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "APANZ_APAC",
	round(COALESCE((select (tx_op_val+cs_op_val+ins_op_val)/1000 as op from fms_ipm_data_entry where upper(identifier) in (''CHINA'',''AMERICAS'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "CHINA_AMERICAS",
	round(COALESCE((select (tx_op_val+cs_op_val+ins_op_val)/1000 as op from fms_ipm_data_entry where upper(identifier) = ''EUROPE''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "EUROPE",
	round(COALESCE((select (tx_op_val+cs_op_val+ins_op_val)/1000 as op from fms_ipm_data_entry where upper(identifier) in (''INDIA'',''ATM'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "INDIA_ATM",
	round(COALESCE((select (tx_op_val+cs_op_val+ins_op_val)/1000 as op from fms_ipm_data_entry where upper(identifier) in (''LATIN_AMERICA'', ''LATAM'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "LATIN_AMERICA",
	round(COALESCE((select (tx_op_val+cs_op_val+ins_op_val)/1000 as op from fms_ipm_data_entry where upper(identifier) = ''MENAT''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "MENAT",
	round(COALESCE((select (tx_op_val+cs_op_val+ins_op_val)/1000 as op from fms_ipm_data_entry where upper(identifier) = ''NORTH_AMERICA''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "NORTH_AMERICA",
	round(COALESCE((select (tx_op_val+cs_op_val+ins_op_val)/1000 as op from fms_ipm_data_entry where upper(identifier) in (''RUSSIA_CIS'', ''MET'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "RUSSIA_CIS_MET",
	round(COALESCE((select (tx_op_val+cs_op_val+ins_op_val)/1000 as op from fms_ipm_data_entry where upper(identifier) in (''SUB_SAHARAN_AFRICA'',''SSA'')
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "SUB_SAHARAN_AFRICA",
	round(COALESCE((select op_val/1000 as op from fms_ipm_data_entry where upper(identifier) = ''SC''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "SC",
	round(COALESCE((select (tx_op_val+cs_op_val+ins_op_val)/1000 as op from fms_ipm_data_entry where upper(identifier) = ''HQ''
	and business_unit = '|| '''' || in_new_p_and_l || '''' ||'  and week = ' || '''' || v_week || '''' || '),0),2) as "HQ",
	0 as "Risk",
	0 as "Opp",
	0 as "total",
	0 as "gap",
	-1 as "OP"
) as subq_op
)';


	raise notice '%', v_view1_sql;

	raise notice '%', v_view2_sql;
	
	execute v_view2_sql;

--chart

--blank row

--"APNAZ" of blank row is 0

--"CHINA" of blank row

	select abs(round(COALESCE((select sum("APANZ_APAC") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER')),0),2)) as blank_china  into v_blank_china;

	raise notice 'v_blank_china %',v_blank_china;

--"EUROPE" of blank row 

	v_blank_europe := v_blank_china + abs(round(COALESCE((select sum("CHINA_AMERICAS") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER') ),0),2));

	raise notice 'v_blank_europe %',v_blank_europe;
	
--"INDIA" of blank row 	

	v_blank_india := v_blank_europe + abs(round(COALESCE((select sum("EUROPE") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER') ),0),2)) ;

--"LATAM" of blank row

	v_blank_latam := v_blank_india + abs(round(COALESCE((select sum("INDIA_ATM") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER') ),0),2)) ;

--"MENAT" of blank row

	v_blank_menat := v_blank_latam + abs(round(COALESCE((select sum("LATIN_AMERICA") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER') ),0),2)) ;

--"NAM" of blank row

	v_blank_nam := v_blank_menat + abs(round(COALESCE((select sum("MENAT") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER') ),0),2)) ;

--"RCIS" of blank row

	v_blank_rcis := v_blank_nam + abs(round(COALESCE((select sum("NORTH_AMERICA") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER') ),0),2)) ;

--"SSA" of blank row

	v_blank_ssa := v_blank_rcis + abs(round(COALESCE((select sum("RUSSIA_CIS_MET") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER') ),0),2)) ;
	
--"SC" of blank row

	v_blank_sc := v_blank_ssa + abs(round(COALESCE((select sum("SUB_SAHARAN_AFRICA") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER') ),0),2)) ;

--"HQ" of blank row

	v_blank_hq := v_blank_sc + round(COALESCE(((select sum(abs("SC")) from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER'))+(select sum(abs("HQ")) from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER')) ),0),2) ;

--"Risk" of blank row

	--select round(COALESCE((v_blank_hq-(select sum("Risk") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER'))),0),2) as blank_risk  into v_blank_risk;
	v_blank_risk := (v_blank_hq-abs(COALESCE((select sum("Risk") from parts_data_table_region_v where upper(type) in ('TX','CS','INS')),0)));

--"Opp" of blank row

	v_blank_opp := v_blank_risk;

--"Total" of total row

	Select round(( COALESCE((select sum("APANZ_APAC") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER')),0) +
		COALESCE((select sum("CHINA_AMERICAS") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER')),0) +
		COALESCE((select sum("EUROPE") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER')),0) +
		COALESCE((select sum("INDIA_ATM") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER')),0) +
		COALESCE((select sum("LATIN_AMERICA") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER')),0) +
		COALESCE((select sum("MENAT") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER')),0) +
		COALESCE((select sum("NORTH_AMERICA") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER')),0) +
		COALESCE((select sum("RUSSIA_CIS_MET") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER')),0) +
		COALESCE((select sum("SUB_SAHARAN_AFRICA") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER')),0) +
		COALESCE((select sum("SC") from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER')),0) +
		COALESCE((select (sum("HQ")) from parts_data_table_region_v where upper(type) in ('TX','CS','INS','OTHER')),0)
		),2) as total_val into v_total_val;

--"OP" of total row

	select round(COALESCE((select "APANZ_APAC"+"CHINA_AMERICAS"+"EUROPE"+"INDIA_ATM"+"LATIN_AMERICA"+"MENAT"+"NORTH_AMERICA"+"RUSSIA_CIS_MET"+"SUB_SAHARAN_AFRICA"+"SC"+"HQ" from parts_data_table_region_v where upper(type)='OP'),0),2) as op_total_val into v_op_total_val;

--"GAP" of gap row 

	select round(COALESCE((v_op_total_val-v_total_val),0),2) as gap_val into v_gap_val;

--blank row 

	v_coalesce_data_table = '0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0';
	
	select COALESCE((0 ||';'|| abs(v_blank_china) ||';'|| abs(v_blank_europe) ||';'|| abs(v_blank_india) ||';'|| abs(v_blank_latam) ||';'|| abs(v_blank_menat) ||';'|| abs(v_blank_nam) ||';'|| abs(v_blank_rcis) ||';'|| abs(v_blank_ssa) ||';'|| abs(v_blank_sc) ||';'|| abs(v_blank_hq) 
	||';'|| abs(v_blank_risk) ||';'|| abs(v_blank_opp)||';'||0||';'||
	(case when abs(v_total_val) <= abs(v_op_total_val) then
			abs(v_total_val)
		else
			(abs(v_total_val)-abs(v_gap_val))
		end)
	||';'||0),
	v_coalesce_data_table) as blank_row into v_blank_row;

raise notice 'Whole Blank Row %', v_blank_row;
--gap row

	select COALESCE((0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||abs(v_gap_val)||';'||0),
	v_coalesce_data_table) into v_gap_row;

raise notice 'Whole gap Row %', v_gap_row;

--total row

	select COALESCE((0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0
		||';'|| abs(v_total_val) ||';'||0||';'||
		abs(v_op_total_val)),v_coalesce_data_table) as total_row into v_total_row;

raise notice 'Whole total Row %', v_total_row;
				
--tx row

	select COALESCE( ( COALESCE((select abs("APANZ_APAC") from parts_data_table_region_v where upper(type) = 'TX'),0)
		||';'||COALESCE((select abs("CHINA_AMERICAS") from parts_data_table_region_v where upper(type) = 'TX'),0)
		||';'||COALESCE((select abs("EUROPE") from parts_data_table_region_v where upper(type) = 'TX'),0)
		||';'||COALESCE((select abs("INDIA_ATM") from parts_data_table_region_v where upper(type) = 'TX'),0)
		||';'||COALESCE((select abs("LATIN_AMERICA") from parts_data_table_region_v where upper(type) = 'TX'),0)
		||';'||COALESCE((select abs("MENAT") from parts_data_table_region_v where upper(type) = 'TX'),0)
		||';'||COALESCE((select abs("NORTH_AMERICA") from parts_data_table_region_v where upper(type) = 'TX'),0)
		||';'||COALESCE((select abs("RUSSIA_CIS_MET") from parts_data_table_region_v where upper(type) = 'TX'),0)
		||';'||COALESCE((select abs("SUB_SAHARAN_AFRICA") from parts_data_table_region_v where upper(type) = 'TX'),0)
		||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0),
		v_coalesce_data_table) as tx_row into v_tx_row;

raise notice 'Whole tx Row %', v_tx_row;

--cs row

	select COALESCE( ( COALESCE((select abs("APANZ_APAC") from parts_data_table_region_v where upper(type) = 'CS'),0)
		||';'||COALESCE((select abs("CHINA_AMERICAS") from parts_data_table_region_v where upper(type) = 'CS'),0)
		||';'||COALESCE((select abs("EUROPE") from parts_data_table_region_v where upper(type) = 'CS'),0)
		||';'||COALESCE((select abs("INDIA_ATM") from parts_data_table_region_v where upper(type) = 'CS'),0)
		||';'||COALESCE((select abs("LATIN_AMERICA") from parts_data_table_region_v where upper(type) = 'CS'),0)
		||';'||COALESCE((select abs("MENAT") from parts_data_table_region_v where upper(type) = 'CS'),0)
		||';'||COALESCE((select abs("NORTH_AMERICA") from parts_data_table_region_v where upper(type) = 'CS'),0)
		||';'||COALESCE((select abs("RUSSIA_CIS_MET") from parts_data_table_region_v where upper(type) = 'CS'),0)
		||';'||COALESCE((select abs("SUB_SAHARAN_AFRICA") from parts_data_table_region_v where upper(type) = 'CS'),0)
		||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0),
		v_coalesce_data_table) as cs_row into v_cs_row;

raise notice 'Whole cs Row %', v_cs_row;

--ins row

	select COALESCE( ( COALESCE((select abs("APANZ_APAC") from parts_data_table_region_v where upper(type) = 'INS'),0)
		||';'||COALESCE((select abs("CHINA_AMERICAS") from parts_data_table_region_v where upper(type) = 'INS'),0)
		||';'||COALESCE((select abs("EUROPE") from parts_data_table_region_v where upper(type) = 'INS'),0)
		||';'||COALESCE((select abs("INDIA_ATM") from parts_data_table_region_v where upper(type) = 'INS'),0)
		||';'||COALESCE((select abs("LATIN_AMERICA") from parts_data_table_region_v where upper(type) = 'INS'),0)
		||';'||COALESCE((select abs("MENAT") from parts_data_table_region_v where upper(type) = 'INS'),0)
		||';'||COALESCE((select abs("NORTH_AMERICA") from parts_data_table_region_v where upper(type) = 'INS'),0)
		||';'||COALESCE((select abs("RUSSIA_CIS_MET") from parts_data_table_region_v where upper(type) = 'INS'),0)
		||';'||COALESCE((select abs("SUB_SAHARAN_AFRICA") from parts_data_table_region_v where upper(type) = 'INS'),0)
		||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0),
		v_coalesce_data_table) as ins_row into v_ins_row;

raise notice 'Whole ins Row %', v_ins_row;

--hq row

	select COALESCE( (0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||
		abs(COALESCE((select sum("HQ") from parts_data_table_region_v where upper(type) in ('TX','CS','INS')),0))
		||';'||0||';'||0||';'||0||';'||0||';'||0) ,
		v_coalesce_data_table) as hq_row into v_hq_row;

raise notice 'Whole hq Row %', v_hq_row;

--risk row

	select COALESCE( (0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||
		abs(COALESCE((select sum("Risk") from parts_data_table_region_v where upper(type) in ('TX','CS','INS')),0))
		||';'||0||';'||0||';'||0||';'||0) ,v_coalesce_data_table) as risk_row into v_risk_row;

raise notice 'Whole risk Row %', v_risk_row;

--opp row

	select COALESCE( (0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||
		abs(COALESCE((select sum("Opp") from parts_data_table_region_v where upper(type) in ('TX','CS','INS')),0))
		||';'||0||';'||0||';'||0) ,v_coalesce_data_table) as opp_row into v_opp_row;

raise notice 'Whole opp Row %', v_opp_row;

--sc row

	select COALESCE( (0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0||';'||
		abs(COALESCE((select "SC" from parts_data_table_region_v where upper(type) = 'OTHER'),0))
		||';'||0||';'||0||';'||0||';'||0||';'||0||';'||0) ,v_coalesce_data_table) as other_row into v_other_row;

raise notice 'Whole sc Row %', v_other_row;


--output


-- data table

	
	select 
	(COALESCE((select type||';'||"APANZ_APAC"||';'||"CHINA_AMERICAS"||';'||"EUROPE"||';'||"INDIA_ATM"||';'||"LATIN_AMERICA"||';'||"MENAT"||';'||"NORTH_AMERICA"||';'||"RUSSIA_CIS_MET"||';'||"SUB_SAHARAN_AFRICA"||';'||"SC"||';'||"HQ"||';'||"Risk"||';'||"Opp"||';'||"total"||';'||"gap"||';'||"OP" from parts_data_table_region_v where type = 'TX'),
	'TX;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select type||';'||"APANZ_APAC"||';'||"CHINA_AMERICAS"||';'||"EUROPE"||';'||"INDIA_ATM"||';'||"LATIN_AMERICA"||';'||"MENAT"||';'||"NORTH_AMERICA"||';'||"RUSSIA_CIS_MET"||';'||"SUB_SAHARAN_AFRICA"||';'||"SC"||';'||"HQ"||';'||"Risk"||';'||"Opp"||';'||"total"||';'||"gap"||';'||"OP" from parts_data_table_region_v where type = 'CS'),
	'CS;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select type||';'||"APANZ_APAC"||';'||"CHINA_AMERICAS"||';'||"EUROPE"||';'||"INDIA_ATM"||';'||"LATIN_AMERICA"||';'||"MENAT"||';'||"NORTH_AMERICA"||';'||"RUSSIA_CIS_MET"||';'||"SUB_SAHARAN_AFRICA"||';'||"SC"||';'||"HQ"||';'||"Risk"||';'||"Opp"||';'||"total"||';'||"gap"||';'||"OP" from parts_data_table_region_v where type = 'INS'),
	'INS;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select type||';'||"APANZ_APAC"||';'||"CHINA_AMERICAS"||';'||"EUROPE"||';'||"INDIA_ATM"||';'||"LATIN_AMERICA"||';'||"MENAT"||';'||"NORTH_AMERICA"||';'||"RUSSIA_CIS_MET"||';'||"SUB_SAHARAN_AFRICA"||';'||"SC"||';'||"HQ"||';'||"Risk"||';'||"Opp"||';'||"total"||';'||"gap"||';'||"OP" from parts_data_table_region_v where type = 'OTHER'),
	'OTHER;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select type||';'||"APANZ_APAC"||';'||"CHINA_AMERICAS"||';'||"EUROPE"||';'||"INDIA_ATM"||';'||"LATIN_AMERICA"||';'||"MENAT"||';'||"NORTH_AMERICA"||';'||"RUSSIA_CIS_MET"||';'||"SUB_SAHARAN_AFRICA"||';'||"SC"||';'||"HQ"||';'||"Risk"||';'||"Opp"||';'||"total"||';'||"gap"||';'||"OP" from parts_data_table_region_v where type = 'PE'),
	'PE;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0')
	||'~'||
	COALESCE((select type||';'||"APANZ_APAC"||';'||"CHINA_AMERICAS"||';'||"EUROPE"||';'||"INDIA_ATM"||';'||"LATIN_AMERICA"||';'||"MENAT"||';'||"NORTH_AMERICA"||';'||"RUSSIA_CIS_MET"||';'||"SUB_SAHARAN_AFRICA"||';'||"SC"||';'||"HQ"||';'||"Risk"||';'||"Opp"||';'||"total"||';'||"gap"||';'||"OP" from parts_data_table_region_v where type = 'OP'),
	'OP;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0'))
	into out_data_table;
	


--charts 

	select 

	( v_opp_row||'~'||v_risk_row||'~'||v_hq_row||'~'||v_ins_row||'~'||v_cs_row||'~'||v_tx_row||'~'||v_total_row||'~'||v_gap_row||'~'||v_other_row||'~'||v_blank_row
	)
	as outcharts
	into out_charts;

	raise notice 'out_charts Row %', out_charts;
	raise notice 'out_data_table Row %', out_data_table;

	drop view IF EXISTS parts_data_table_region_v;
	drop view IF EXISTS parts_filter_data_region_v;


	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_ipm_walk_by_region',
			     v_proc_paras ,
			     sqlerrm,
			     'DATABASE ERROR');		

	drop view IF EXISTS parts_data_table_region_v;
	drop view IF EXISTS parts_filter_data_region_v;
			     
	--RAISE NOTICE 'SQL ERROR %', sqlerrm;
	select 'DATABASE ERROR' into out_data_table;
	select 'DATABASE ERROR' into out_charts;
	
end
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
