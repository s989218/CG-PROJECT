-- Function: fms_is_date(character varying)

-- DROP FUNCTION fms_is_date(character varying);

CREATE OR REPLACE FUNCTION fms_is_date(s character varying)
  RETURNS boolean AS
$BODY$
begin
  perform s::date;
  return true;
exception when others then
  return false;
end;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
