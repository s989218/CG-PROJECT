-- Function: fms_mapping_functions(character varying)

-- DROP FUNCTION fms_mapping_functions(character varying);

CREATE OR REPLACE FUNCTION fms_mapping_functions(in_report character varying)
  RETURNS character AS
$BODY$
DECLARE

	v_proc_paras character varying;
	v_status character varying;
	v_PROC_CALLED character varying;
	
BEGIN


	v_proc_paras =  (SELECT EXTRACT(YEAR FROM current_timestamp - interval '3 month')) || ' ; ' || 
		(SELECT CONCAT(EXTRACT( QUARTER from date_trunc('quarter', current_date)::date-1),'Q'))::character varying 
		|| ' ; ' || in_report;

	v_status = '';
	
	IF in_report = 'IBAS_IBO'
		THEN
		
		--IBAS & IBO RELATED QUERIES
		
		--CALL_TO_UPDATE_IBAS_EQUIP_DATA 
		/*
			UPDATES THE FOLLOWING DATA
				ALL RELATED TO IBAS & IBO DATA
				IMPACTED TABLES IS fms_ibas_equipment
			->business_segment mapping
			->ge duns name and ge global duns update
			->'CONTRACTUAL' & 'TRANSACTIONAL' site update
			->UPDATE ACCOUNT MANAGER TABLE
			->segment mapping
			->tier 4 mapping
			->Update of the records as InService
			->ibo type update
			->UPDATE of Parts, Repairs, Services, Aux, Manpower
			->UPDATE of avf2f, avtot
			
		*/
		v_PROC_CALLED = 'fms_update_ibas_equipment';
		SELECT fms_update_ibas_equipment(NULL) INTO v_status;
		rAISE NOTICE  '---------------fms_update_ibas_equipment %', v_status;
		
		PERFORM fms_db_logger('fms_update_ibas_equipment',   v_proc_paras ,'', v_status);
		
		IF v_status = 'DATABASE ERROR' THEN 
			RETURN 'DATABASE ERROR';
		END IF;
		
		--CALL_TO_UPDATE_IBAS_EQUIP_REG_YR_QTR
		/*
			UPDATES THE FOLLOWING DATA
				ALL RELATED TO IBAS & IBO DATA
				IMPACTED TABLES IS fms_ibas_equipment
			->THE YEAR AND QUARTER FIELDS
			->THE REGION_ID FIELD
			
		*/
		
		v_PROC_CALLED = 'fms_update_ibas_equip_yr_qtr_data';
		
		SELECT fms_update_ibas_equip_yr_qtr_data() INTO v_status;
		rAISE NOTICE  '---------------fms_update_ibas_equip_yr_qtr_data %', v_status;
		
		PERFORM fms_db_logger('fms_update_ibas_equip_yr_qtr_data',   v_proc_paras ,'', v_status);
		
		IF v_status = 'DATABASE ERROR' THEN 
			RETURN 'DATABASE ERROR';
		END IF;
		
		--END OF IBAS & IBO RELATED QUERIES
	
	END IF;
	
	IF in_report = 'ORDERS' OR in_report = 'IBAS_IBO'
		THEN
		
		--ORDERS RELATED QUERIES
		
		--ALL_ORDERS_MAPPING_FUNC
		/*
			UPDATES THE FOLLOWING DATA
				ALL RELATED TO ORDERS DATA
				IMPACTED TABLES IS fms_service_orders_pm
			->UPDATE of (ME FIELDS)
				i.e. me_mapping_incl_SC_corrections, me_P_and_L, me_SVC_or_EQ, me_tier_3, me_DM_Tier_3,me_Tier_4,me_usage
			->UPDATE of (PRODUCT FIELD i.e. TECHNOLOGY) pm_product_mapping
			->UPDATE of (SEGMENT FIELD) sm_segment_mapping
			->business_segment mapping
			->ge_duns_code TO 0 WHERE ge_duns_code is null
			->YEAR & QUARTER update
			->MARKET INDUSTRY UPDATE
			->THE REGION_ID FIELD
			
		*/
		v_PROC_CALLED = 'fms_me_pm_sm_mapping_in_orders';
		SELECT fms_me_pm_sm_mapping_in_orders('ALL') INTO v_status;
		
		PERFORM fms_db_logger('fms_me_pm_sm_mapping_in_orders',   v_proc_paras ,'', v_status);
		
		IF v_status = 'DATABASE ERROR' THEN 
			RETURN 'DATABASE ERROR';
		END IF;
		
	END IF;
	
	IF in_report = 'ORDERS' OR in_report = 'IBAS_IBO' OR in_report = 'GE_DUNS'
		THEN
		
		--ORDERS_DUNS_MAPPING_FUNC
		/*
			UPDATES THE FOLLOWING DATA
				ALL RELATED TO ORDERS DATA
				IMPACTED TABLES IS fms_service_orders_pm
			->ge duns name and ge global duns update
			
		*/
		v_PROC_CALLED = 'fms_order_mapping_func';
		
		SELECT fms_order_mapping_func('START') INTO v_status;
		
		PERFORM fms_db_logger('fms_order_mapping_func',   v_proc_paras ,'', v_status);
		
		IF v_status = 'DATABASE ERROR' THEN 
			RETURN 'DATABASE ERROR';
		END IF;
		
		--UPDATE_FUZZY_MATCH
		/*
			UPDATES THE FOLLOWING DATA
				ALL RELATED TO ORDERS DATA
				IMPACTED TABLES IS fms_service_orders_pm
			->e_site_cust_name FIELD (FUZZY MATCHED SITE NAME)
			->match_per FIELD (FUZZY MATCHED %)
			
		*/
		v_PROC_CALLED = 'fms_fuzzy_match ORDERS';
		SELECT fms_fuzzy_match('ORDERS', EXTRACT(YEAR FROM current_timestamp - interval '3 month')::numeric, 
			CONCAT(EXTRACT( QUARTER from date_trunc('quarter', current_date)::date-1))::numeric) INTO v_status;
			
		PERFORM fms_db_logger('fms_fuzzy_match',   v_proc_paras ,'', v_status);
		
		IF v_status = 'DATABASE ERROR' THEN 
			RETURN 'DATABASE ERROR';
		END IF;
		
		--END OF ORDERS QUERIES

	END IF;		
		
		--PEN METRICS GENERATION FUNCTIONS
		
	IF in_report = 'ORDERS' OR in_report = 'IBAS_IBO' OR in_report = 'SALES'
		THEN
		
		--REGION START
				
		--UPDATE_ALL_PEN_METRICS
		/*
			UPDATES THE FOLLOWING DATA
				ALL RELATED TO REGION LEVEL PENETRATION METRICS
				IMPACTED TABLES ARE fms_metrics & fms_metrics_tech
			->rev_dollar_by_region field
			->caloric_index field
			->dollar_by_ib field
			->fleet_coverage field
			->fleet_pen_f2f field
			->fleet_penetration field
			->parts_fleet_penetration field
			->repairs_fleet_penetration field
			->svcs_fleet_penetration field
			->ibo_by_region field
			->conversion_index field
			->ib_by_region field
			->ib_by_tech field
			->ibo_by_tech field
			
		*/
		v_PROC_CALLED = 'fms_calc_all_metrics';
		SELECT fms_calc_all_metrics((SELECT EXTRACT(YEAR FROM current_timestamp - interval '3 month'))::numeric,
			(SELECT CONCAT(EXTRACT( QUARTER from date_trunc('quarter', current_date)::date-1),'Q'))::character varying) INTO v_status;
			
		PERFORM fms_db_logger('fms_calc_all_metrics',   v_proc_paras ,'', v_status);
		
		IF v_status = 'DATABASE ERROR' THEN 
			RETURN 'DATABASE ERROR';
		END IF;
		
		--UPDATE_OVERALL_REGIONS_SPLIT
		/*
			UPDATES THE FOLLOWING DATA
				ALL RELATED TO REGION LEVEL PENETRATION METRICS
				IMPACTED TABLES ARE fms_metrics_country_tech
			->caloric_index field
			->fleet_coverage field
			->fleet_penetration field
			->fleet_pen_f2f field
			->ibo_by_region field
			
		*/
		v_PROC_CALLED = 'fms_calc_pen_metrics_region_overalldata';
		SELECT fms_calc_pen_metrics_region_overalldata() INTO v_status;
		
		PERFORM fms_db_logger('fms_calc_pen_metrics_region_overalldata',   v_proc_paras ,'', v_status);
		
		IF v_status = 'DATABASE ERROR' THEN 
			RETURN 'DATABASE ERROR';
		END IF;
		
		--REGION END
		
		--COUNTRY & TECH START
		
		--UPDATE_ALL_PEN_METRICS_COUNTRY_TECH_SPLIT
		/*
			UPDATES THE FOLLOWING DATA
				ALL RELATED TO COUNTRY & TECHNOLOGY LEVEL PENETRATION METRICS
				IMPACTED TABLES ARE fms_metrics_country_tech
			->fleet_coverage field
			->fleet_penetration field
			->fleet_pen_f2f field
			->caloric_index field
			->dollar_by_ib field
			->conversion_index field
			->ibo_value field
			->parts_fleet_penetration field
			->repairs_fleet_penetration field
			->svcs_fleet_penetration field
			
		*/
		v_PROC_CALLED = 'fms_calc_pen_metrics_tech_country_break';
		SELECT fms_calc_pen_metrics_tech_country_break((SELECT EXTRACT(YEAR FROM current_timestamp - interval '3 month'))::numeric,
			(SELECT CONCAT(EXTRACT( QUARTER from date_trunc('quarter', current_date)::date-1),'Q'))::character varying) INTO v_status;
			
		PERFORM fms_db_logger('fms_calc_pen_metrics_tech_country_break',   v_proc_paras ,'', v_status);
		
		IF v_status = 'DATABASE ERROR' THEN 
			RETURN 'DATABASE ERROR';
		END IF;
		
		--UPDATE_OVERALL_COUNTRIES_SPLIT
		/*
			UPDATES THE FOLLOWING DATA
				ALL RELATED TO COUNTRY LEVEL PENETRATION METRICS
				IMPACTED TABLES ARE fms_metrics
			->caloric_index field
			->fleet_coverage field
			->fleet_penetration field
			->fleet_pen_f2f field
			->ibo_by_region field
			
		*/
		v_PROC_CALLED = 'fms_calc_pen_metrics_country_overalldata';
		SELECT fms_calc_pen_metrics_country_overalldata() INTO v_status;
		
		PERFORM fms_db_logger('fms_calc_pen_metrics_country_overalldata',   v_proc_paras ,'', v_status);
		
		IF v_status = 'DATABASE ERROR' THEN 
			RETURN 'DATABASE ERROR';
		END IF;
		
		--COUNTRY & TECH END
		
	END IF;
	
	IF in_report = 'ORDERS' OR in_report = 'IBAS_IBO' OR in_report = 'GE_DUNS'
		THEN
		
		--SITES START
		
		--UPDATE_ALL_PEN_METRICS_SITES_SPLIT
		/*
			UPDATES THE FOLLOWING DATA
				ALL RELATED TO SITE & GE DUNS LEVEL PENETRATION METRICS
				IMPACTED TABLES ARE fms_metrics_sites
			->fleet_coverage field
			->fleet_penetration field
			->fleet_pen_f2f field
			->caloric_index field
			->ibo_value field
			->ge_duns_name field
			
		*/
		v_PROC_CALLED = 'fms_calc_pen_metrics_sites_break';
		SELECT fms_calc_pen_metrics_sites_break((SELECT EXTRACT(YEAR FROM current_timestamp - interval '3 month'))::numeric,
			(SELECT CONCAT(EXTRACT( QUARTER from date_trunc('quarter', current_date)::date-1),'Q'))::character varying) INTO v_status;
		
		PERFORM fms_db_logger('fms_calc_pen_metrics_sites_break',   v_proc_paras ,'', v_status);
		
		IF v_status = 'DATABASE ERROR' THEN 
			RETURN 'DATABASE ERROR';
		END IF;
		
		--UPDATE_OVERALL_SITES_SPLIT
		/*
			UPDATES THE FOLLOWING DATA
				ALL RELATED TO SITE LEVEL PENETRATION METRICS
				IMPACTED TABLES ARE fms_metrics_sites
			->caloric_index field
			->fleet_coverage field
			->fleet_penetration field
			->fleet_pen_f2f field
			->ibo_by_region field
			
		*/
		v_PROC_CALLED = 'fms_calc_pen_metrics_sites_overalldata';
		SELECT fms_calc_pen_metrics_sites_overalldata() INTO v_status;
		
		PERFORM fms_db_logger('fms_calc_pen_metrics_sites_overalldata',   v_proc_paras ,'', v_status);
		
		IF v_status = 'DATABASE ERROR' THEN 
			RETURN 'DATABASE ERROR';
		END IF;
			
		--SITES END
		
	END IF;
	
	IF in_report = 'ORDERS' OR in_report = 'IBAS_IBO'
		THEN
			
		--UPDATE_ALL_PEN_METRICS_SEGMENT_SPLIT
		/*
			UPDATES THE FOLLOWING DATA
				ALL RELATED TO SEGMENT LEVEL PENETRATION METRICS
				IMPACTED TABLES ARE fms_metrics_segment
			->fleet_coverage field
			->fleet_penetration field
			->fleet_pen_f2f field
			->caloric_index field
			
		*/
		v_PROC_CALLED = 'fms_calc_pen_metrics_segment_break';
		SELECT fms_calc_pen_metrics_segment_break((SELECT EXTRACT(YEAR FROM current_timestamp - interval '3 month'))::numeric,
			(SELECT CONCAT(EXTRACT( QUARTER from date_trunc('quarter', current_date)::date-1),'Q'))::character varying) INTO v_status;
		
		PERFORM fms_db_logger('fms_calc_pen_metrics_segment_break',   v_proc_paras ,'', v_status);
		
		IF v_status = 'DATABASE ERROR' THEN 
			RETURN 'DATABASE ERROR';
		END IF;
		
	END IF;	

		--END OF PEN METRICS GENERATION FUNCTIONS

	RETURN 'SUCCESS';

	EXCEPTION WHEN OTHERS THEN 
	--ROLLBACK; 
	PERFORM fms_db_logger('fms_mapping_functions',
			     v_proc_paras || ' = '|| v_PROC_CALLED,
			     sqlerrm,
			     'DATABASE ERROR');		
	--RAISE NOTICE 'SQL ERROR %', sqlerrm;
	RETURN 'DATABASE ERROR';		
	
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
