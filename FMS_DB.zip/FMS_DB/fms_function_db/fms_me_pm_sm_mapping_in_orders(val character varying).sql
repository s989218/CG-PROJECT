-- Function: fms_me_pm_sm_mapping_in_orders(character varying)

-- DROP FUNCTION fms_me_pm_sm_mapping_in_orders(character varying);

CREATE OR REPLACE FUNCTION fms_me_pm_sm_mapping_in_orders(val character varying)
  RETURNS character varying AS
$BODY$ 
DECLARE
--success integer :=0;
v_query_result character varying;
-- cursors for 3 mapping tables
-- me_mapping cursor for
-- select me_mgmt_entity_code,me_mapping_incl_SC_corrections,me_P_and_L,me_SVC_or_EQ,me_tier_3,me_DM_Tier_3,me_Tier_4,me_usage from fms_service_orders_me_mapping;
-- product_mapping cursor for
-- select pm_product_type_desc,pm_product_mapping from fms_service_orders_product_mapping;
-- segment_mapping cursor for
-- select sm_src_new_og_pl,sm_segment_mapping from fms_service_orders_segment_mapping;

-- year_quarter cursor for
-- select extract(year from current_timestamp - interval '3 month') as yr,
-- CONCAT(extract( quarter from date_trunc('quarter', current_date)::date-1),'Q') as qtr;

BEGIN

--select CONCAT(extract( quarter from date_trunc('quarter', current_date)::date-1),'Q')as qtr into v_quarter;
--raise notice 'value of quarter is %',v_quarter;

IF val='ME' OR val='ALL' THEN

	--ME MAPPING

	UPDATE fms_service_orders_pm main
	SET 
		me_mapping_incl_SC_corrections = subquery.me_mapping_incl_SC_corrections,
		me_P_and_L = subquery.me_P_and_L,
		me_SVC_or_EQ =  subquery.me_SVC_or_EQ,
		me_tier_3 =  subquery.me_tier_3,
		me_DM_Tier_3 =  subquery.me_DM_Tier_3,
		me_Tier_4 =  subquery.me_Tier_4,
		me_usage =  subquery.me_usage
			FROM (SELECT me_mapping_incl_SC_corrections, me_P_and_L, me_SVC_or_EQ, me_tier_3, me_DM_Tier_3, 
				me_Tier_4, me_usage,me_mgmt_entity_code from fms_service_orders_me_mapping) subquery
	WHERE UPPER(TRIM(main.c_mgmt_entity_code)) = UPPER(TRIM(subquery.me_mgmt_entity_code));

/*
for ids in me_mapping loop
update fms_service_orders_pm set 
(me_mapping_incl_SC_corrections,me_P_and_L,me_SVC_or_EQ,me_tier_3,me_DM_Tier_3,me_Tier_4,me_usage)
=(ids.me_mapping_incl_SC_corrections,ids.me_P_and_L,ids.me_SVC_or_EQ,ids.me_tier_3,ids.me_DM_Tier_3,ids.me_Tier_4,ids.me_usage)
where c_mgmt_entity_code=ids.me_mgmt_entity_code;
end loop;
*/

END IF;

IF val='PK' OR val='ALL' THEN

	--PRODUCT MAPPING
	
	UPDATE fms_service_orders_pm main
	SET 
		pm_product_mapping = subquery.pm_product_mapping
			FROM (SELECT pm_product_type_desc, pm_product_mapping FROM fms_service_orders_product_mapping) subquery 
	WHERE UPPER(TRIM(subquery.pm_product_type_desc)) = UPPER(TRIM(main.c_product_type_desc)) ;
  
/*
for val in product_mapping loop
update fms_service_orders_pm set (pm_product_mapping)=(val.pm_product_mapping) where c_product_type_desc=val.pm_product_type_desc;
end loop;
*/

END IF;


--if val='SK' or val='ALL' then

	--SEGMENT MAPPING

	--1
	UPDATE fms_service_orders_pm SET c_market_industry_desc = NULL;
	
	--2
	UPDATE fms_service_orders_pm SET c_market_industry_desc = 
		(CASE WHEN c_market IN ('Refinery & Petrochemical','TPS: Refinery & Petrochemical')
				THEN 'Refinery & Petrochemical'
			WHEN c_market IN 
				('Industrial','TPS: Industrial')
				THEN 'Industrial'
			WHEN c_market IN 
				('Onshore/Offshore Production','TPS: Other')
				THEN 'Onshore/Offshore Production'
			END);

	--3
	UPDATE fms_service_orders_pm SET sm_segment_mapping = NULL;
	
	--4
	UPDATE fms_service_orders_pm main
	SET 
		sm_segment_mapping = subquery.sm_segment_mapping
			FROM (SELECT sm_src_new_og_pl, sm_segment_mapping,c_market_industry_desc FROM fms_service_orders_segment_mapping 
					WHERE C_MARKET_INDUSTRY_DESC = 'Refinery & Petrochemical') subquery
	WHERE UPPER(TRIM(subquery.sm_src_new_og_pl)) = UPPER(TRIM(main.c_src_new_og_pl))
	AND c_market = 'Refinery & Petrochemical';

	--5
	UPDATE fms_service_orders_pm SET sm_segment_mapping = 'Other',
			c_market_industry_desc = 'Refinery & Petrochemical' 
	WHERE sm_segment_mapping IS NULL AND c_market = 'Refinery & Petrochemical';
	  
--for vals in segment_mapping loop
--update fms_service_orders_pm set (sm_segment_mapping)=(vals.sm_segment_mapping) where c_src_new_og_pl=vals.sm_src_new_og_pl;
--end loop;

--end if;

	--BUSINESS SEGMENT MAPPING
/*
	UPDATE fms_service_orders_pm SET n_me_tier_2 = 'TMS' WHERE n_me_tier_2 LIKE '%TMS%';
	UPDATE fms_service_orders_pm SET n_me_tier_2 = 'DTS' WHERE n_me_tier_2 LIKE '%DTS%';
	UPDATE fms_service_orders_pm SET n_me_tier_2 = 'DTS' WHERE n_me_tier_2 LIKE '%DP&S%';
*/		
	--GE DUNS CODE UPDATE
	UPDATE fms_service_orders_pm SET ge_duns_code='0' WHERE ge_duns_code IS NULL;
		
	--YEAR QUARTER UPDATE
	UPDATE fms_service_orders_pm SET year = n_book_year, quarter = CONCAT(n_book_quarter,'Q');

	--UPDATE REGION ID 

	SELECT fms_update_fms_regions_desc('fms_service_orders_pm') INTO v_query_result;

--success:=1;

		RETURN 'SUCCESS';

		EXCEPTION WHEN OTHERS THEN 
		  
		PERFORM fms_db_logger('fms_me_pm_sm_mapping_in_orders',
							val ,
							sqlerrm,
							'DATABASE ERROR');
		--success:=0;
		RETURN 'DATABASE ERROR';


END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
