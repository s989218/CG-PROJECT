-- Function: fms_order_mapping_func(character varying)

-- DROP FUNCTION fms_order_mapping_func(character varying);

CREATE OR REPLACE FUNCTION fms_order_mapping_func(str character varying)
  RETURNS character varying AS
$BODY$
DECLARE
--success integer :=0;
--count integer :=0;
cmp_string character varying:='START';
-- cursor for mapping
/*
-- OLD Code
order_mapping cursor for
select distinct o.n_ord_rec_id as order_id,v.c_site_customer_duns as site_customer,v.ge_global_duns as priority_code,v.ge_duns_name as priority_name,o.c_end_user_duns_code as later_code,o.c_end_user_name as later_name from 
fms_service_orders_pm o left join fms_ibas_equipment_v as v on o.c_end_user_duns_code=v.c_site_customer_duns order by o.n_ord_rec_id;
*/
BEGIN
if cmp_string=str then
/*
-- OLD Code
for val in order_mapping loop
update fms_service_orders_pm set ge_duns_code=COALESCE(val.priority_code, val.later_code),
ge_duns_name=COALESCE(val.priority_name, val.later_name) where n_ord_rec_id=val.order_id;
count:= count + 1;
end loop;
*/


update fms_service_orders_pm set 
	ge_duns_code=COALESCE(subquery.priority_code, subquery.later_code),
	ge_duns_name=COALESCE(subquery.priority_name, subquery.later_name)
from 
	(select distinct o.n_ord_rec_id as order_id,v.c_site_customer_duns as site_customer,v.ge_global_duns as priority_code,v.ge_duns_name as priority_name,o.c_end_user_duns_code as later_code,o.c_end_user_name as later_name from 
	fms_service_orders_pm o left join fms_ibas_equipment as v on o.c_end_user_duns_code=v.c_site_customer_duns 
	/*where
	o.year = (SELECT EXTRACT(year FROM current_timestamp - interval '3 month')) AND o.quarter = (SELECT CONCAT(EXTRACT( quarter FROM date_trunc('quarter', current_date)::date-1),'Q'))*/ order by o.n_ord_rec_id) subquery 
where n_ord_rec_id=subquery.order_id;
/*and year = (SELECT EXTRACT(year FROM current_timestamp - interval '3 month')) AND quarter = (SELECT CONCAT(EXTRACT( quarter FROM date_trunc('quarter', current_date)::date-1),'Q'));*/

end if;
--RAISE NOTICE '---count value--- %', count;
--success:=1;
return 'SUCCESS';

EXCEPTION WHEN OTHERS THEN 
	
PERFORM fms_db_logger('fms_order_mapping_func',str ,sqlerrm,'DATABASE ERROR');
--success:=0;
return 'DATABASE ERROR';


END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
