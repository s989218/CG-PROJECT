-- Function: fms_outage_equip_data(character varying)

-- DROP FUNCTION fms_outage_equip_data(character varying);

CREATE OR REPLACE FUNCTION fms_outage_equip_data(msg character varying)
  RETURNS character varying AS
$BODY$
DECLARE
--success integer :=0;
message character varying := 'success';

outage_equip_mapping cursor for
select c_gib_serial_number,ge_duns_name,d_est_service_start_date,n_est_serv_hours_count,n_maint_year,c_cust_loyalty_desc_parts,c_cust_behavior_desc_parts,
c_site_customer_duns,c_site_customer_name,c_site_name_alias,c_site_customer_city,c_site_customer_country,c_technology_desc,c_technology_desc_og,
c_equipment_desc,c_eng_project_ref,c_oem_location_desc,c_unit_status_desc,d_unit_ship_date,d_unit_cod_date,c_account_mgr_email,c_service_mgr_email,
c_market_segment_desc,c_service_relation_desc_og,c_og_sales_region from fms_ibas_equipment;

year_quarter cursor for
SELECT d_event_date,to_char((to_timestamp((cast(d_event_date as bigint))/1000)),'dd-MON-yy') as date_format,
EXTRACT(YEAR FROM date (to_char((to_timestamp((cast(d_event_date as bigint))/1000)),'dd-MON-yy'))):: numeric as year,
EXTRACT(quarter FROM date (to_char((to_timestamp((cast(d_event_date as bigint))/1000)),'dd-MON-yy'))):: numeric as quarter from fms_outage_data_oracle;

outage_maintenance_mapping cursor for
select n_maint_level_id as lvl_id,maint_level_cod as lvl_cod,maint_level_desc as lvel_desc from fms_enhancement_outage_mapping;

outage_event_status_mapping cursor for
select n_event_status_id,c_event_status_desc from fms_ouatge_event_status_mapping;

BEGIN
if msg=message then
for ids in outage_equip_mapping loop
update fms_outage_data_oracle set 
(d_est_service_start_date,n_est_serv_hours_count,n_maint_year,c_cust_loyalty_desc_parts,c_cust_behavior_desc_parts,
c_site_customer_duns,c_site_customer_name,c_site_name_alias,c_site_customer_city,c_site_customer_country,c_technology_desc,c_technology_desc_og,
c_equipment_desc,c_eng_project_ref,c_oem_location_desc,c_unit_status_desc,d_unit_ship_date,d_unit_cod_date,c_account_mgr_email,c_service_mgr_email,
c_market_segment_desc,c_service_relation_desc_og,c_og_sales_region,ge_duns_name)
=(ids.d_est_service_start_date,ids.n_est_serv_hours_count,ids.n_maint_year,ids.c_cust_loyalty_desc_parts,ids.c_cust_behavior_desc_parts,
ids.c_site_customer_duns,ids.c_site_customer_name,ids.c_site_name_alias,ids.c_site_customer_city,ids.c_site_customer_country,ids.c_technology_desc,ids.c_technology_desc_og,
ids.c_equipment_desc,ids.c_eng_project_ref,ids.c_oem_location_desc,ids.c_unit_status_desc,ids.d_unit_ship_date,ids.d_unit_cod_date,ids.c_account_mgr_email,ids.c_service_mgr_email,
ids.c_market_segment_desc,ids.c_service_relation_desc_og,ids.c_og_sales_region,ids.ge_duns_name)
 where c_gib_serial_number=ids.c_gib_serial_number;
end loop;

for val in year_quarter loop
update fms_outage_data_oracle set (event_year,event_quarter)=(val.year,val.quarter) where d_event_date=val.d_event_date;
end loop;

for lvl in outage_maintenance_mapping loop
update fms_outage_data_oracle set (maint_level_cod,maint_level_desc)=(lvl.lvl_cod,lvl.lvel_desc) where n_maint_level_id=lvl.lvl_id;
end loop;

for stat in outage_event_status_mapping loop
update fms_outage_data_oracle set c_event_status_desc=(stat.c_event_status_desc) where n_event_status_id=stat.n_event_status_id;
end loop;

end if;
--success:=1;
return 'SUCCESS';

EXCEPTION WHEN OTHERS THEN 
	
PERFORM fms_db_logger('fms_outage_equip_data',msg ,sqlerrm,'DATABASE ERROR');
--success:=0;
return 'DATABASE ERROR';


END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
