-- Function: fms_service_req_mapping(character varying)

-- DROP FUNCTION fms_service_req_mapping(character varying);

CREATE OR REPLACE FUNCTION fms_service_req_mapping(msg character varying)
  RETURNS character varying AS
$BODY$
DECLARE
--success integer :=0;
message character varying := 'success';

year_quarter cursor for
SELECT opened,to_char((to_timestamp((cast(opened as bigint))/1000)),'dd-MON-yy') as date_format,
EXTRACT(YEAR FROM date (to_char((to_timestamp((cast(opened as bigint))/1000)),'dd-MON-yy'))):: numeric as year,
EXTRACT(quarter FROM date (to_char((to_timestamp((cast(opened as bigint))/1000)),'dd-MON-yy'))):: numeric as quarter from fms_oracle_service_request;

convrsn_to_date cursor for 
SELECT --opened,to_char((to_timestamp((cast(opened as bigint))/1000)),'dd-MON-yy') as opened_date,
entry_in_the_cur_status,to_char((to_timestamp((cast(entry_in_the_cur_status as bigint))/1000)),'dd-MON-yy') as entry_sts_date from fms_oracle_service_request;

BEGIN
if msg=message then

for val in year_quarter loop
update fms_oracle_service_request set (p_opened_date,event_year,event_quarter)=(val.date_format,val.year,val.quarter) where opened=val.opened;
end loop;

-- for dt in convrsn_to_date loop
-- update fms_oracle_service_request set p_opened_date=dt.opened_date where opened=dt.opened;
-- end loop;
raise notice 'inside if';

for dte in convrsn_to_date loop
update fms_oracle_service_request set p_entry_sts_date=dte.entry_sts_date where entry_in_the_cur_status=dte.entry_in_the_cur_status;
end loop;

-- To update the ge_duns_name

UPDATE fms_oracle_service_request main SET ge_duns_name = cbn.ge_duns_name
	FROM
		(
		SELECT equip.ge_duns_name,  sr.CUSTOMER_NAME FROM 
			(SELECT ge_duns_name, c_site_customer_name FROM fms_ibas_equipment ) AS equip
			INNER JOIN 
			(SELECT DISTINCT CUSTOMER_NAME FROM fms_oracle_service_request) AS sr
		ON sr.CUSTOMER_NAME = equip.c_site_customer_name
		) cbn
	where main.CUSTOMER_NAME = cbn.CUSTOMER_NAME;

end if;
--success:=1;
return 'SUCCESS';

EXCEPTION WHEN OTHERS THEN 
	
PERFORM fms_db_logger('fms_service_req_mapping',msg ,sqlerrm,'DATABASE ERROR');
--success:=0;
return 'DATABASE ERROR';


END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
