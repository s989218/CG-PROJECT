-- Function: fms_update_fms_regions_desc(character varying)

-- DROP FUNCTION fms_update_fms_regions_desc(character varying);

CREATE OR REPLACE FUNCTION fms_update_fms_regions_desc(in_data character varying)
  RETURNS character varying AS
$BODY$ 
  DECLARE

	v_proc_paras  character varying(250);
	v_query character varying(2500);
	v_field character varying(250);
    
  BEGIN

	v_proc_paras =  in_data ;

	IF in_data = 'fms_ibas_equipment'
		THEN v_field = 'c_og_sales_region';
		RAISE NOTICE '%' ,in_data;
	ELSIF in_data = 'fms_service_orders_pm'
		THEN v_field = 'c_og_region_name';
		RAISE NOTICE '%' ,in_data;
	ELSE
		RAISE NOTICE '%' ,in_data;
		RETURN 'SUCCESS';
	END IF;
	

	v_query = 'Update ' || in_data || ' set ' || v_field || ' = ''Asia Pacific'' where ' || v_field || ' = ''Asia Pacific & Australia''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set ' || v_field || ' = ''Asia Pacific'' where ' || v_field || ' = ''APANZ''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set ' || v_field || ' = ''Asia Pacific'' where ' || v_field || ' = ''China''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set ' || v_field || ' = ''Europe & North Sea'' where ' || v_field || ' = ''Europe''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set ' || v_field || ' = ''MENAT'' where ' || v_field || ' = ''Middle East / North Africa''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set ' || v_field || ' = ''MENAT'' where ' || v_field || ' = ''India''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set ' || v_field || ' = ''Latin America'' where ' || v_field || ' = ''LATAM''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set ' || v_field || ' = ''North America'' where ' || v_field || ' = ''NAM''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set ' || v_field || ' = ''Russia & CIS'' where ' || v_field || ' = ''RCIS''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set ' || v_field || ' = ''Russia & CIS'' where ' || v_field || ' = ''Russia / CIS''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set ' || v_field || ' = ''Sub-Saharan Africa'' where ' || v_field || ' = ''Sub-saharan Africa''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set ' || v_field || ' = ''Sub-Saharan Africa'' where ' || v_field || ' = ''SSA''';
	EXECUTE v_query;
	
	
	
	
	v_query = 'Update ' || in_data || ' set region_id = 1 where ' || v_field || ' = ''Asia Pacific''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set region_id = 2 where ' || v_field || ' = ''Europe & North Sea''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set region_id = 3 where ' || v_field || ' = ''MENAT''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set region_id = 4 where ' || v_field || ' = ''Latin America''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set region_id = 5 where ' || v_field || ' = ''North America'''; 
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set region_id = 6 where ' || v_field || ' = ''Russia & CIS''';
	EXECUTE v_query;
	v_query = 'Update ' || in_data || ' set region_id = 7 where ' || v_field || ' = ''Sub-Saharan Africa''';
	EXECUTE v_query;
	
  
  RETURN 'SUCCESS';

    
  EXCEPTION WHEN OTHERS THEN 
  PERFORM fms_db_logger('fms_update_fms_regions_desc',
           v_proc_paras ,
           sqlerrm,
           'DATABASE ERROR');  
  --RAISE EXCEPTION 'DATABASE ERROR'; 
  RETURN 'DATABASE ERROR';    
  
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
