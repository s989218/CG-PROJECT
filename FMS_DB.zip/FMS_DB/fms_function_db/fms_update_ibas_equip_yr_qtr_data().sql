-- Function: fms_update_ibas_equip_yr_qtr_data()

-- DROP FUNCTION fms_update_ibas_equip_yr_qtr_data();

CREATE OR REPLACE FUNCTION fms_update_ibas_equip_yr_qtr_data()
  RETURNS character varying AS
$BODY$DECLARE
--success integer :=0;
v_query_result character varying;
/*
year_quarter cursor for
select extract(year from current_timestamp - interval '3 month') as yr,
CONCAT(extract( quarter from date_trunc('quarter', current_date)::date-1),'Q') as qtr;
*/

BEGIN
/*
for val in year_quarter loop
update fms_ibas_equipment set year = val.yr, quarter = val.qtr;
end loop;
*/

update fms_ibas_equipment set year = (SELECT EXTRACT(YEAR FROM current_timestamp - interval '3 month'))::numeric, quarter = (SELECT CONCAT(EXTRACT( QUARTER from date_trunc('quarter', current_date)::date-1),'Q'))::character varying;

select fms_update_fms_regions_desc('fms_ibas_equipment') into v_query_result;

--success:=1;
return 'SUCCESS';

EXCEPTION WHEN OTHERS THEN 
	
PERFORM fms_db_logger('fms_update_ibas_equip_yr_qtr_data','' ,sqlerrm,'DATABASE ERROR');
--success:=0;
return 'DATABASE ERROR';


END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
