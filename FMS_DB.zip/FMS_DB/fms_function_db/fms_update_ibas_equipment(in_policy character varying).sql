-- Function: fms_update_ibas_equipment(character varying)

-- DROP FUNCTION fms_update_ibas_equipment(character varying);

CREATE OR REPLACE FUNCTION fms_update_ibas_equipment(in_policy character varying)
  RETURNS character varying AS
$BODY$ 
DECLARE

    v_proc_paras character varying(2500); 
	v_column_name character varying(2500); 
	v_category_name character varying(2500); 
	v_query character varying(2500); 
	
BEGIN

	v_proc_paras =  in_Policy ;
  
	--=======================================--
	
	--business_segment mapping
/*
	UPDATE fms_ibas_equipment SET C_PROD_EXC_PL = 'TMS' WHERE C_PROD_EXC_PL LIKE '%TMS%';
	UPDATE fms_ibas_equipment SET C_PROD_EXC_PL = 'DTS' WHERE C_PROD_EXC_PL LIKE '%DTS%';
	UPDATE fms_ibas_equipment SET C_PROD_EXC_PL = 'DTS' WHERE C_PROD_EXC_PL LIKE '%DP&S%';
*/
	--=======================================--
	
	--ge duns name and ge global duns update
	
	UPDATE fms_ibas_equipment equip SET 
		ge_global_duns = c_glo_customer_duns;
	UPDATE fms_ibas_equipment equip SET 
		ge_global_duns = cust_map.ge_global_duns
		FROM fms_ge_cust_mapping cust_map 
		WHERE cust_map.gib_serial_number::text = equip.c_gib_serial_number::text 
		AND cust_map.ge_global_duns is not null;
		
	UPDATE fms_ibas_equipment SET 
		ge_duns_name = c_glo_customer_name;
	UPDATE fms_ibas_equipment equip SET 
		ge_duns_name = cust_map.ge_duns_name
		FROM fms_ge_cust_mapping cust_map 
		WHERE cust_map.gib_serial_number::text = equip.c_gib_serial_number::text 
		AND cust_map.ge_duns_name is not null;
	
	--=======================================--
	
	-- 'CONTRACTUAL' & 'TRANSACTIONAL' site update
	
	UPDATE fms_ibas_equipment SET d_contract_type = Null;

	UPDATE fms_ibas_equipment SET d_contract_type = 
		CASE UPPER(c_service_relation_desc_og) WHEN 'GLOBAL AGREEMENT' THEN 'CONTRACTUAL' 
		ELSE 'TRANSACTIONAL' END;

	/*
	select count(*) from fms_ibas_equipment where c_site_customer_name IN (
	(Select c_site_customer_name  from
		(Select distinct d_contract_type, c_site_customer_name from fms_ibas_equipment)as contract
			group by c_site_customer_name having count(*) >1))

	*/

	UPDATE fms_ibas_equipment equip SET d_contract_type = 'CONTRACTUAL' FROM
	(SELECT c_site_customer_name,count(*), C_PROD_EXC_PL FROM
		(SELECT DISTINCT d_contract_type, c_site_customer_name AS a, c_site_customer_name, C_PROD_EXC_PL from fms_ibas_equipment) AS contract
			GROUP BY c_site_customer_name, C_PROD_EXC_PL  HAVING count(*) > 1)subquery
	WHERE equip.c_site_customer_name = subquery.c_site_customer_name
	AND equip.C_PROD_EXC_PL = subquery.C_PROD_EXC_PL;  


	--Select Distinct d_contract_type from fms_ibas_equipment;
	
	--=======================================--
	
	--UPDATE ACCOUNT MANAGER TABLE

	TRUNCATE TABLE fms_account_manager_list;

	INSERT INTO fms_account_manager_list
	SELECT DISTINCT UPPER(c_site_customer_name), c_account_mgr_last
		, c_account_mgr_first, c_account_mgr_email 
	FROM fms_ibas_equipment WHERE c_site_customer_name IS NOT NULL; 
	--AND c_account_mgr_last IS NOT NULL AND c_account_mgr_first IS NOT NULL AND c_account_mgr_email IS NOT NULL;

	-- Inserts a dummy NULL values, so that if no Manager is selected, all sites should get considered for processing 
	
	INSERT INTO fms_account_manager_list(c_site_customer_name, c_account_mgr_last, c_account_mgr_first, c_account_mgr_email)
    VALUES (NULL, NULL, NULL, NULL);
    
	--=======================================--
	
	--segment mapping

	/*TRUNCATE TABLE fms_service_orders_segment_mapping;

	INSERT INTO fms_service_orders_segment_mapping(sm_src_new_og_pl,sm_segment_mapping, c_market_industry_desc)

	SELECT DISTINCT c_market_segment_desc AS sm_src_new_og_pl, NULL AS sm_segment_mapping,
	'TPS: Refinery & Petrochemical' AS c_market_industry_desc FROM fms_ibas_equipment
	WHERE c_market_segment_desc IS NOT NULL ORDER BY c_market_segment_desc;

	*/

	--1
	UPDATE fms_ibas_equipment main SET c_market_segment_desc = NULL
		WHERE C_MARKET_INDUSTRY_DESC IN 
			('Industrial','TPS: Industrial','TPS: Upstream Offshore','TPS: Upstream Onshore',
				'TPS: Other','Onshore/Offshore Production');	
	
	--2
	UPDATE fms_ibas_equipment main SET C_MARKET_INDUSTRY_DESC =
		(CASE WHEN C_MARKET_INDUSTRY_DESC IN ('TPS: Industrial' ,'Industrial')
				THEN 'Industrial'
			WHEN C_MARKET_INDUSTRY_DESC IN ('TPS: Upstream Onshore','TPS: Upstream Offshore',
					'TPS: Other','Onshore/Offshore Production')
				THEN 'Onshore/Offshore Production'
			WHEN C_MARKET_INDUSTRY_DESC IN ('Refinery & Petrochemical','TPS: Refinery & Petrochemical')
				THEN 'Refinery & Petrochemical' END);
	
	--3
	INSERT INTO fms_service_orders_segment_mapping(sm_src_new_og_pl,
	sm_segment_mapping, c_market_industry_desc)

	SELECT DISTINCT c_market_segment_desc AS sm_src_new_og_pl, NULL AS sm_segment_mapping,
		'Refinery & Petrochemical' AS c_market_industry_desc FROM fms_ibas_equipment
		WHERE c_market_segment_desc IS NOT NULL
		AND c_market_segment_desc NOT IN 
			(SELECT DISTINCT sm_src_new_og_pl FROM fms_service_orders_segment_mapping)
		AND c_market_segment_desc NOT IN 
			(SELECT DISTINCT sm_segment_mapping FROM fms_service_orders_segment_mapping)
		AND C_MARKET_INDUSTRY_DESC NOT IN 
			('TPS: Industrial','Industrial',
				'TPS: Upstream Offshore','TPS: Upstream Onshore','TPS: Other','Onshore/Offshore Production')
		ORDER BY c_market_segment_desc;
	
	--4
	UPDATE fms_service_orders_segment_mapping SET sm_segment_mapping = 
		(CASE WHEN TRIM(UPPER(sm_src_new_og_pl)) LIKE TRIM(UPPER('%Fertilizer%')) THEN 'Fertilizer' 
			WHEN TRIM(UPPER(sm_src_new_og_pl)) LIKE TRIM(UPPER('%O&G PowerGen%')) THEN 'O&G PowerGen' 
			WHEN TRIM(UPPER(sm_src_new_og_pl)) LIKE TRIM(UPPER('%Petrochem%')) 
				AND TRIM(UPPER(sm_src_new_og_pl)) NOT LIKE TRIM(UPPER('%Refinery & Petrochem%')) 
			THEN 'Petrochem' 
			WHEN TRIM(UPPER(sm_src_new_og_pl)) LIKE TRIM(UPPER('%Refinery%')) 
				AND TRIM(UPPER(sm_src_new_og_pl)) NOT LIKE TRIM(UPPER('%Refinery & Petrochem%')) 
			THEN 'Refinery'
			WHEN TRIM(UPPER(sm_src_new_og_pl)) LIKE TRIM(UPPER('%Refinery & Petrochem%')) 
			THEN 'Refinery & Petrochem'
		ELSE 'Other' END)
		WHERE C_MARKET_INDUSTRY_DESC = 'Refinery & Petrochemical';

	--5
	INSERT INTO fms_service_orders_segment_mapping(sm_src_new_og_pl,
	sm_segment_mapping, c_market_industry_desc)
	
	SELECT DISTINCT NULL AS sm_src_new_og_pl, NULL AS sm_segment_mapping,
		c_market_industry_desc AS c_market_industry_desc FROM fms_ibas_equipment
		WHERE c_market_industry_desc IS NOT NULL
		AND c_market_industry_desc NOT IN 
			(SELECT DISTINCT c_market_industry_desc FROM fms_service_orders_segment_mapping)
		AND c_market_industry_desc IN 
			('TPS: Other','Onshore/Offshore Production','TPS: Industrial','Industrial')
		ORDER BY c_market_industry_desc;
		
	--6
	UPDATE fms_ibas_equipment set c_market_segment_desc = 'Other' 
		WHERE c_market_segment_desc IS NULL AND C_MARKET_INDUSTRY_DESC = 'Refinery & Petrochemical';

	--7
	UPDATE fms_ibas_equipment main
	SET 
	c_market_segment_desc = subquery.sm_segment_mapping
	FROM (SELECT sm_src_new_og_pl, sm_segment_mapping FROM fms_service_orders_segment_mapping 
		WHERE C_MARKET_INDUSTRY_DESC = 'Refinery & Petrochemical') subquery
	WHERE upper(trim(subquery.sm_src_new_og_pl)) = upper(trim(main.c_market_segment_desc));

	/*
	SELECT DISTINCT sm_src_new_og_pl, sm_segment_mapping, C_MARKET_INDUSTRY_DESC FROM fms_service_orders_segment_mapping ORDER BY  C_MARKET_INDUSTRY_DESC, sm_segment_mapping,sm_src_new_og_pl
	SELECT DISTINCT c_market_segment_desc,  C_MARKET_INDUSTRY_DESC FROM fms_ibas_equipment ORDER BY C_MARKET_INDUSTRY_DESC,c_market_segment_desc
	*/
	
	--=======================================--
	
	--tier 4 mapping

	--Select count(*) from fms_ibas_equipment where c_oem_location_desc IN ('AC Compressor - Oshkosh WI, USA', 'Conmec - Bethlehem PA, USA', 'Rotoflow - Gardena CA, USA');
	UPDATE fms_ibas_equipment SET c_oem_location_desc = 'Small Centrifugal' 
		WHERE c_oem_location_desc IN 
		('AC Compressor - Oshkosh WI, USA', 'Conmec - Bethlehem PA, USA', 'Rotoflow - Gardena CA, USA');

	--Select count(*) from fms_ibas_equipment where c_oem_location_desc IN ('Thermodyn, Le Creusot, FR');
	UPDATE fms_ibas_equipment SET c_oem_location_desc = 'Thermodyn' 
		WHERE c_oem_location_desc IN 
		('Thermodyn, Le Creusot, FR');


	--Select count(*) from fms_ibas_equipment where (c_oem_location_desc Not like ('%Alstom%') and c_oem_location_desc not in ('Small Centrifugal', 'Thermodyn'));
	UPDATE fms_ibas_equipment SET c_oem_location_desc = 'Core' 
		WHERE (c_oem_location_desc NOT LIKE ('%Alstom%') AND c_oem_location_desc NOT IN 
		('Small Centrifugal', 'Thermodyn') );

	--=======================================--
	
	--Update of the records as InService
	
	UPDATE fms_ibas_equipment SET C_UNIT_STATUS_DESC = NULL
		WHERE UPPER(C_UNIT_STATUS_DESC) = UPPER('InService');
		
	UPDATE fms_ibas_equipment equip SET C_UNIT_STATUS_DESC = 'InService'
		FROM (SELECT DISTINCT gib_serial_number FROM fms_ibo) ibo 
		WHERE equip.c_gib_serial_number::text = ibo.gib_serial_number::text;
	
	--=======================================--
	
	--ibo type update
	
	UPDATE fms_ibas_equipment equip SET ibo_type = 'full_ibo';
	
	UPDATE fms_ibas_equipment equip SET ibo_type = 'core_ibo'
		FROM (SELECT DISTINCT gib_serial_number 
			FROM fms_ibo WHERE UPPER(country) NOT IN ('LIBYA','UKRAINE','YEMEN')
			AND UPPER(equipment) NOT IN ('12A','31G','32A','32B','32C','32D','32E','32G',
				'51A','51B','51C','51E','51G','51H','51K','SBW','CC','LM15','LM16','LM5') ) ibo
		WHERE equip.c_gib_serial_number::text = ibo.gib_serial_number::text;
	
	UPDATE fms_ibas_equipment equip SET ibo_type = 'addressable_ibo'
		FROM (SELECT DISTINCT gib_serial_number 
			FROM fms_ibo WHERE UPPER(maint_policy_cod) NOT IN ('MROC_GG') ) ibo
		WHERE equip.c_gib_serial_number::text = ibo.gib_serial_number::text
			AND ibo_type = 'core_ibo';
	
	--=======================================--
	
	--UPDATE of Parts, Repairs, Services, Aux, Manpower
	
	UPDATE fms_ibas_equipment equip SET n_avg_parts_value = 0, n_avg_repair_value = 0,
			n_avg_svcs_value = 0, AvManPow = 0, AvAux = 0
				WHERE UPPER(c_unit_status_desc) = UPPER('InService');
				
	UPDATE fms_ibas_equipment SET n_avg_parts_value = 0 WHERE n_avg_parts_value IS NULL;
	UPDATE fms_ibas_equipment SET n_avg_repair_value = 0 WHERE n_avg_repair_value IS NULL; 
	UPDATE fms_ibas_equipment SET n_avg_svcs_value = 0 WHERE n_avg_svcs_value IS NULL; 	
	UPDATE fms_ibas_equipment SET AvManPow = 0 WHERE AvManPow IS NULL;
	UPDATE fms_ibas_equipment SET AvAux = 0 WHERE AvAux IS NULL;  
	
	FOR a IN 1..5 LOOP
	
	IF a = 1 
                THEN v_column_name = 'n_avg_parts_value';
                     v_category_name = 'Parts';

	ELSIF a = 2
                THEN v_column_name = 'n_avg_repair_value';
                     v_category_name = 'Repairs';

	ELSIF a = 3
                THEN v_column_name = 'n_avg_svcs_value';
                     v_category_name = 'Field Service';

	ELSIF a = 4
                THEN v_column_name = 'AvManPow';
                     v_category_name = 'MP';

	ELSIF a = 5
                THEN v_column_name = 'AvAux';
                     v_category_name = 'Aux';

	END IF;
	
	v_query = '
	UPDATE fms_ibas_equipment equip SET 
		' ||  v_column_name  || ' = sub_query.' ||  v_column_name  || '
		FROM
		(SELECT * FROM(
			SELECT (CASE WHEN UPPER(ibo.source_code) = UPPER(TRIM(''AVG_IBO'')) 
							THEN (CASE WHEN ibo.buying_year_vs_event_year = (SELECT EXTRACT(year FROM now()) )
								THEN (COALESCE(ibo.value_normalized,0)
								--*COALESCE(ibo.service_factor,1)
								) ELSE 0 END)
						WHEN UPPER(ibo.source_code) = UPPER(TRIM(''OUTAGE_IBO''))
							THEN (CASE WHEN extract(year FROM ibo.event_date_new) = (SELECT EXTRACT(year FROM now()) ) 
								THEN (SELECT SUM(COALESCE(value_normalized,0)) FROM fms_ibo WHERE 
										extract(year FROM event_date_new) = (SELECT EXTRACT(year FROM now()) )
										AND UPPER(TRIM(category)) = UPPER(TRIM(' || '''' || v_category_name || '''' || '))
										AND UPPER(source_code) = UPPER(TRIM(''OUTAGE_IBO''))
										AND fms_ibo.gib_serial_number = ibo.gib_serial_number)
									ELSE 0 END) 
						ELSE 0 END) AS ' ||  v_column_name  || ', 
				(CASE WHEN UPPER(ibo.source_code) = UPPER(TRIM(''AVG_IBO'')) 
						THEN (CASE WHEN ibo.buying_year_vs_event_year = (SELECT EXTRACT(year FROM now()) )
							THEN (SELECT EXTRACT(year FROM now()) ) ELSE 0 END)
					WHEN UPPER(ibo.source_code) = UPPER(TRIM(''OUTAGE_IBO''))
						THEN (CASE WHEN extract(year FROM ibo.event_date_new) = (SELECT EXTRACT(year FROM now()) ) 	
							THEN  (SELECT EXTRACT(year FROM now()) ) ELSE 0 END)							
					ELSE 0	END) AS year, ibo.gib_serial_number AS gib_serial_number
			FROM fms_ibo ibo WHERE UPPER(TRIM(ibo.category)) = UPPER(TRIM(' || '''' || v_category_name || '''' || ')) ) as inner_1 
			WHERE Year = EXTRACT(year FROM now())
		) AS sub_query
	WHERE equip.c_gib_serial_number::text = sub_query.gib_serial_number::text  
	AND equip.ibo_type = ''addressable_ibo'' ' ;

	RAISE NOTICE '%' , v_query;

	EXECUTE v_query;
	
	v_query = '
	UPDATE fms_ibas_equipment equip SET 
		' ||  v_column_name  || ' = sub_query.' ||  v_column_name  || '
		FROM
		(SELECT * FROM(
			SELECT (CASE WHEN UPPER(ibo.source_code) = UPPER(TRIM(''AVG_IBO'')) 
							THEN (CASE WHEN ibo.buying_year_vs_event_year = (SELECT EXTRACT(year FROM now()) )
								THEN (COALESCE(ibo.value_normalized,0)) ELSE 0 END)
						WHEN UPPER(ibo.source_code) = UPPER(TRIM(''OUTAGE_IBO''))
							THEN (CASE WHEN extract(year FROM ibo.event_date_new) = (SELECT EXTRACT(year FROM now()) ) 
								THEN (SELECT SUM(COALESCE(value_normalized,0)) FROM fms_ibo WHERE 
										extract(year FROM event_date_new) = (SELECT EXTRACT(year FROM now()) )
										AND UPPER(TRIM(category)) = UPPER(TRIM(' || '''' || v_category_name || '''' || '))
										AND UPPER(source_code) = UPPER(TRIM(''OUTAGE_IBO''))
										AND fms_ibo.gib_serial_number = ibo.gib_serial_number)
									ELSE 0 END) 
						ELSE 0 END) AS ' ||  v_column_name  || ', 
				(CASE WHEN UPPER(ibo.source_code) = UPPER(TRIM(''AVG_IBO'')) 
						THEN (CASE WHEN ibo.buying_year_vs_event_year = (SELECT EXTRACT(year FROM now()) )
							THEN (SELECT EXTRACT(year FROM now()) ) ELSE 0 END)
					WHEN UPPER(ibo.source_code) = UPPER(TRIM(''OUTAGE_IBO''))
						THEN (CASE WHEN extract(year FROM ibo.event_date_new) = (SELECT EXTRACT(year FROM now()) ) 	
							THEN  (SELECT EXTRACT(year FROM now()) ) ELSE 0 END)							
					ELSE 0	END) AS year, ibo.gib_serial_number AS gib_serial_number
			FROM fms_ibo ibo WHERE UPPER(TRIM(ibo.category)) = UPPER(TRIM(' || '''' || v_category_name || '''' || ')) ) as inner_1 
			WHERE Year = EXTRACT(year FROM now())
		) AS sub_query
	WHERE equip.c_gib_serial_number::text = sub_query.gib_serial_number::text  
	AND equip.ibo_type <> ''addressable_ibo'' ' ;

	RAISE NOTICE '%' , v_query;

	EXECUTE v_query;

	END LOOP;

	--TESTING QUERIES

	/*
	
	select n_avg_parts_value,n_avg_repair_value,n_avg_svcs_value,AvManPow,AvAux,(value_normalized* service_factor), value_normalized, service_factor, 
	ibo_type, buying_year_vs_event_year, event_date_new,c_gib_serial_number,category,source_code from fms_ibas_equipment inner join fms_ibo 
	on c_gib_serial_number::text = gib_serial_number::text
	where (buying_year_vs_event_year = (SELECT EXTRACT(year FROM now()) ) or extract(year FROM event_date_new) = (SELECT EXTRACT(year FROM now()) ) ) 
	--and c_gib_serial_number = 'TD-A0457B' 
	and
	 UPPER(source_code) = UPPER(TRIM('OUTAGE_IBO'))
	order by category , source_code, ibo_type,c_gib_serial_number


	select n_avg_parts_value,n_avg_repair_value,n_avg_svcs_value,AvManPow,AvAux,(value_normalized* service_factor), value_normalized, service_factor, 
	ibo_type, buying_year_vs_event_year, event_date_new,c_gib_serial_number,category,source_code from fms_ibas_equipment inner join fms_ibo 
	on c_gib_serial_number::text = gib_serial_number::text
	where (buying_year_vs_event_year = (SELECT EXTRACT(year FROM now()) ) or extract(year FROM event_date_new) = (SELECT EXTRACT(year FROM now()) ) ) 
	--and c_gib_serial_number = 'TD-A0457B' 
	and
	 UPPER(source_code) = UPPER(TRIM('AVG_IBO'))
	order by category , source_code, ibo_type,c_gib_serial_number

	*/
	
	/*
	UPDATE fms_ibas_equipment equip SET 
		n_avg_parts_value = sub_query.n_avg_parts_value
		FROM
		(SELECT * FROM(
			SELECT (CASE WHEN UPPER(ibo.source_code) = UPPER(TRIM('AVG_IBO')) THEN 
						(CASE WHEN ibo.buying_year_vs_event_year = (SELECT EXTRACT(year FROM now()) )THEN 
							(CASE WHEN (in_equip.ibo_type = 'addressable_ibo') THEN
								(COALESCE(ibo.value_normalized,0) * COALESCE(ibo.service_factor,1)) 
							ELSE
								COALESCE(ibo.value_normalized,0)
							END)	
						ELSE 
							0 
						END)
				     WHEN UPPER(ibo.source_code) = UPPER(TRIM('OUTAGE_IBO')) THEN 
						(CASE WHEN extract(year FROM ibo.event_date_new) = (SELECT EXTRACT(year FROM now()) )THEN 
							(SELECT SUM(COALESCE(value_normalized,0)) 
								FROM fms_ibo 
								WHERE 
									extract(year FROM event_date_new) = (SELECT EXTRACT(year FROM now()) )
									AND UPPER(TRIM(category)) = UPPER(TRIM('Parts'))
									AND UPPER(source_code) = UPPER(TRIM('OUTAGE_IBO'))
									AND fms_ibo.gib_serial_number = ibo.gib_serial_number)
						ELSE 
							0 
						END) 
				ELSE 
					0 
				END) AS n_avg_parts_value, 
				(CASE WHEN UPPER(ibo.source_code) = UPPER(TRIM('AVG_IBO')) THEN 
					(CASE WHEN ibo.buying_year_vs_event_year = (SELECT EXTRACT(year FROM now()) )THEN 
						(SELECT EXTRACT(year FROM now()) ) 
					ELSE 
						0 
					END)
					WHEN UPPER(ibo.source_code) = UPPER(TRIM('OUTAGE_IBO')) THEN 
						(CASE WHEN extract(year FROM ibo.event_date_new) = (SELECT EXTRACT(year FROM now()) )THEN  
							(SELECT EXTRACT(year FROM now()) ) 
						ELSE 
							0 
						END)							
				ELSE 
					0	
				END) AS year, ibo.gib_serial_number AS gib_serial_number
			FROM fms_ibo ibo INNER JOIN fms_ibas_equipment in_equip 
				ON in_equip.c_gib_serial_number::text = ibo.gib_serial_number::text 
			WHERE UPPER(TRIM(ibo.category)) = UPPER(TRIM('Parts')) 
			) as inner_1 
		WHERE Year = EXTRACT(year FROM now())
		) AS sub_query
	WHERE equip.c_gib_serial_number::text = sub_query.gib_serial_number::text ;
	--AND equip.ibo_type = 'addressable_ibo';

	*/
			
	--=======================================--
	
	--UPDATE of avf2f, avtot
	
	UPDATE fms_ibas_equipment equip SET avf2f = 0, avtot = 0
		WHERE UPPER(c_unit_status_desc) = UPPER('InService');
		
	UPDATE fms_ibas_equipment SET avf2f = 0 WHERE avf2f IS NULL;
	UPDATE fms_ibas_equipment SET avtot = 0 WHERE avtot IS NULL;
	
	UPDATE fms_ibas_equipment 
	   SET avf2f = ROUND((coalesce(n_avg_parts_value, 0) + coalesce(n_avg_repair_value,0) + coalesce(n_avg_svcs_value, 0)) , 2); 
    
	UPDATE fms_ibas_equipment SET avtot = ROUND((avf2f + AvManPow + AvAux), 2); 
	
	UPDATE fms_ibas_equipment equip
	   SET avf2f = 0 FROM fms_ibo ibo
	   WHERE equip.c_gib_serial_number::text = ibo.gib_serial_number::text 
				AND UPPER(ibo.technology_aggregated) IN ('COOLER', 'MOTOR', 'GENERATOR', 'GEARBOX'); 
    
	UPDATE fms_ibas_equipment equip
		SET avtot = 0 FROM fms_ibo ibo
		WHERE equip.c_gib_serial_number::text = ibo.gib_serial_number::text 
				AND UPPER(ibo.technology_aggregated) IN ('COOLER', 'MOTOR', 'GENERATOR', 'GEARBOX'); 
	
  RETURN 'SUCCESS';

    
  EXCEPTION WHEN OTHERS THEN 
  PERFORM fms_db_logger('fms_update_ibas_equipment',
           v_proc_paras ,
           sqlerrm,
           'DATABASE ERROR');  
  --RAISE EXCEPTION 'DATABASE ERROR'; 
  RETURN 'DATABASE ERROR';    
  
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
