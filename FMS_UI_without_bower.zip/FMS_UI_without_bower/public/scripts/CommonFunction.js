/**
 * 
 */

var sessionTimer = setTimeout("SessionTimeoutCheck();", 27 * 60 * 1000);

function resetSessionTimer() {
	clearTimeout(sessionTimer);
	sessionTimer = setTimeout("SessionTimeoutCheck();", 27 * 60 * 1000);
}

function logOutOfApplication() {
	window.px.auth._logoutUrl="/logout"
	window.px.auth.logout();
	//window.location.href="/logout";
	//sessionStorage.clear();
	//window.location.href="/logout/engageSurface";
}

function SessionTimeoutCheck() {
	clearTimeout(sessionTimer);
	sessionAlert("Session Expired please click on Ok and Login again to the application");
}

function sessionAlert(message){
	showLoaderSession();
	$(".alertBoxSession").show();
	$(".alertMsgAlert").html(message);
}

function showLoaderSession(){
    $(".overlaySession").css('display','block');
   // $(".alertBoxSession").center();
    $(".alertBoxSession").css({top: ($(window).height() - $(".alertBoxSession").outerHeight()) / 2,left: ($(window).width() - $(".alertBoxSession").outerWidth()) / 2});
    /* $(".loading").css('display','block');   */ 
}

function closeLoaderSession(){
    $(".overlaySession").css('display','none');
    /*$(".loading").css('display','none');*/
}

function getYearQuarter(){
	var yearQ = {};
	var currentYear = new Date().getFullYear();
	var currentQuarter = Math.ceil(( new Date().getMonth() + 1) / 3 );
	var month=new Date().getMonth()+1;
	var previouscurrentYear,previousQuarter;
	if((month-3)<= 0){
		previouscurrentYear = new Date().getFullYear()-1;
	}else{
		previouscurrentYear = new Date().getFullYear();	
	}
	var backQuarter = Math.ceil(((new Date().getMonth()+1)-3) / 3 );
	if(backQuarter <= 0){
		previousQuarter = 4;
	}else{
		previousQuarter = backQuarter;
	}
	yearQ["currentYearQuarter"] = currentYear+'-'+currentQuarter+'Q';
	yearQ["ibo_equipmentquarteryear"] = previouscurrentYear+'-'+previousQuarter+'Q';
	yearQ["ibo_equipmentyear"] = currentYear;
	yearQ["ibo_orderquarteryear"] = previouscurrentYear+'-'+previousQuarter+'Q';
	return yearQ;
}

function htmlEntities(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}