/**
 * Load controllers, directives, filters, services before bootstrapping the application.
 * NOTE: These are named references that are defined inside of the config.js RequireJS configuration file.
 */
define([
        'jquery',
        'angular',
        'main',
        'routes',
        'interceptors',
        'px-datasource',
        'ng-bind-polymer',
        'uiSwitch'
        ], function ($, angular) {
	'use strict';

	/**
	 * Application definition
	 * This is where the AngularJS application is defined and all application dependencies declared.
	 * @type {module}
	 */
	var predixApp = angular.module('predixApp', [
	                                             'app.routes',
	                                             'app.interceptors',
	                                             'sample.module',
	                                             'predix.datasource',
	                                             'px.ngBindPolymer',
	                                             'uiSwitch'
	                                             ]);

	/**
	 * Main Controller
	 * This controller is the top most level controller that allows for all
	 * child controllers to access properties defined on the $rootScope.
	 */
	predixApp.controller('MainCtrl', ['$scope', '$rootScope', '$q', 'PredixUserService','$http','$injector','$state', function ($scope, $rootScope, $q, predixUserService,$http,$injector,$state) {
		
        $rootScope.editAccess = 'Y';
		$rootScope.ipmRole    = 'N';
        
        $rootScope.isMobile = false;
        $rootScope.isTablet = false;
        
        if(screen.width <= 800 && screen.height <= 1024) {
            $rootScope.isMobile = true;
        }
        
        $rootScope.isTablet = navigator.userAgent.match(/iPad/i) != null;
        
		$scope.allShow = true;
		$scope.tmsShow = true;
		$scope.dtsShow = true;
        
        $scope.marketIndustry = "Refinery & Petrochemical";
        $rootScope.marketIndustry = $scope.marketIndustry;
        
        $rootScope.cHistoryLegacySwitch = 'history';
        
        //Global application object
		window.App = $rootScope.App = {
				version: '1.0',
				name: 'Fleet Mining system',
				session: {},
				tabs: [ {icon: 'fa fa-cog', state: 'InstalledBase', label: 'Installed Base'},
				        {icon: 'fa fa-bar-chart', state: 'IPM', label: 'IPM', subitems: [
                            {icon: 'fa fa-bar-chart',label: 'KeyDeals'},
                            {icon: 'fa fa-cogs',label: 'Risk'},
                            {icon: 'fa fa-cogs',label: 'Opps'},
                            {icon: 'fa fa-cogs',label: 'BO (Walk By Business)'},
                            {icon: 'fa fa-cogs',label: 'BO (Walk By Regions)'},
                            {icon: 'fa fa-cogs',label: 'Data Entry'},
                            {icon: 'fa fa-cogs',label: 'Project Controller - TX'},
                            {icon: 'fa fa-cogs',label: 'Project Controller - CS'},
                            {icon: 'fa fa-cogs',label: 'Project Controller - INST'},
                            {icon: 'fa fa-cogs',label: 'Walk By Product - TX'},
                            {icon: 'fa fa-cogs',label: 'Walk By Product - CS'},
                            {icon: 'fa fa-cogs',label: 'Walk By Product - INST'},
                            {icon: 'fa fa-cogs',label: 'Walk By Finance'}
                        ]},
                        {icon: 'fa fa-cog', label: 'Admin Panel', subitems: [
                            {icon: 'fa fa-user', state: 'Users', label: 'Manage Users'},
                            {icon: 'fa fa-user-with-cog', state: 'Roles', label: 'Manage Roles'},
                            {icon: 'fa fa-user-with-cog', state: 'Documents', label: 'Manage Documents'},
//                          {icon: 'fa fa-bar-chart', state: 'RegionTable', label: 'Set Region Table'},
//                          {icon: 'fa fa-cogs', state: 'LETable', label: 'Set LE Table'},
//                          {icon: 'fa fa-cogs', state: 'VariablesTable', label: 'Set Varialbes Table'},
//                          {icon: 'fa fa-cogs', state: 'BuyerTable', label: 'Set Buyer Table'}
                        ]},
                        {icon: 'fa fa-cog', state: 'IPMParts', label: 'IPM Parts'},
                        {icon: 'fa fa-bar-chart', state: 'NewMetrics', label: 'IBO Metrics', subitems: [
                            {icon: 'fa fa-bar-chart', state: 'Metrics', label: 'Penetration Metrics'},
                            //{icon: 'fa fa-cogs', state: 'MaintenanceData', label: 'Maintenance'},
                            {icon: 'fa fa-desktop', state: 'EquipmentData', label: 'Equipment Data'},
                            {icon: 'fa fa-cog', state: 'Orders', label: 'Orders Data'},
                            {icon: 'fa fa-cog', state: 'DealMachinesData', label: 'DM Data'},
                            {icon: 'fa fa-cog', state: 'OutageData', label: 'Outage Data'},
                            {icon: 'fa fa-cog', state: 'ServiceReqData', label: 'Service Request Data'}
                        ]},
                        {icon: 'fa fa-cog', state: 'CombinedAnalysis', label: 'Combined Analysis'},
                        {icon: 'fa fa-cog', state: 'UserManual', label: 'User Manual'}
                    ]
		};
		setTimeout(function(){
			$('#ibTab,#iboTab,#orderTab').on('click', function(){
				$('#'+this.id).find('ul').toggleClass('visuallyhidden');
			});
		},500);
		$rootScope.safeApply = function() {
			var $scope, fn, force = false;
			if(arguments.length == 1) {
				var arg = arguments[0];
				if(typeof arg == 'function') {
					fn = arg;
				}
				else {
					$scope = arg;
				}
			}
			else {
				$scope = arguments[0];
				fn = arguments[1];
				if(arguments.length == 3) {
					force = !!arguments[2];
				}
			}
			$scope = $scope || this;
			fn = fn || function() { };
			if(force || !$scope.$$phase) {
				$scope.$apply ? $scope.$apply(fn) : $scope.apply(fn);
			}
			else {
				fn();
			}
		};
		$rootScope.$on('$stateChangeError', function (event, toState, toParams, fromState, fromParams, error) {
			if (angular.isObject(error) && angular.isString(error.code)) {
				switch (error.code) {
				case 'UNAUTHORIZED':
					//redirect
					predixUserService.login(toState);
					break;
				default:
					//go to other error state
				}
			}
			else {
				// unexpected error
			}
		});

		// showing authorization message
		$rootScope.shwAuthorizeMsg = function () {
			var message = "You dont have access to application. Please contact Admin.";
			$(".overlaySession").css('display','block');
			$(".authorizeAlertBoxSection").css('display','block');
			$(".authorizeAlertBoxSection").css({top: ($(window).height() - $(".authorizeAlertBoxSection").outerHeight()) / 2,left: ($(window).width() - $(".authorizeAlertBoxSection").outerWidth()) / 2});
			$(".authorizeAlertBoxSection").show();
			$(".authorizeMsgAlert").html(message);
		}

		// getting role id and role name setting into root scope
		$rootScope.shwRoleBasedMenu = function () {
			for (var i = 0; i < $rootScope.userRoles.length; i++) {
				$rootScope.roleId = $rootScope.userRoles[i].roleId;
				$rootScope.roleName = $rootScope.userRoles[i].roleName;
				if($rootScope.roleId == 1) {
					window.App.tabs = [ {icon: 'fa fa-cog', state: 'InstalledBase', label: 'Installed Base'},
					                    {icon: 'fa fa-bar-chart', state: 'IPM', label: 'IPM', subitems: [
                                            {icon: 'fa fa-bar-chart',label: 'KeyDeals'},
                                            {icon: 'fa fa-cogs',label: 'Risk'},
                                            {icon: 'fa fa-cogs',label: 'Opps'},
                                            {icon: 'fa fa-cogs',label: 'BO (Walk By Business)'},
                                            {icon: 'fa fa-cogs',label: 'BO (Walk By Regions)'},
                                            {icon: 'fa fa-cogs',label: 'Data Entry'},
                                            {icon: 'fa fa-cogs',label: 'Project Controller - TX'},
                                            {icon: 'fa fa-cogs',label: 'Project Controller - CS'},
                                            {icon: 'fa fa-cogs',label: 'Project Controller - INST'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Product - TX'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Product - CS'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Product - INST'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Finance'}
                                        ]},
                                        {icon: 'fa fa-cog', label: 'Admin Panel', subitems: [
                                            {icon: 'fa fa-user', state: 'Users', label: 'Manage Users'},
                                            {icon: 'fa fa-user-with-cog', state: 'Roles', label: 'Manage Roles'},
                                            {icon: 'fa fa-user-with-cog', state: 'Documents', label: 'Manage Documents'},
//                                          {icon: 'fa fa-bar-chart', state: 'RegionTable', label: 'Set Region Table'},
//                                          {icon: 'fa fa-cogs', state: 'LETable', label: 'Set LE Table'},
//                                          {icon: 'fa fa-cogs', state: 'VariablesTable', label: 'Set Varialbes Table'},
//                                          {icon: 'fa fa-cogs', state: 'BuyerTable', label: 'Set Buyer Table'}
                                        ]},
                                        {icon: 'fa fa-cog', state: 'IPMParts', label: 'IPM Parts'},
                                        {icon: 'fa fa-bar-chart', state: 'NewMetrics', label: 'IBO Metrics', subitems: [
                                           {icon: 'fa fa-bar-chart', state: 'Metrics', label: 'Penetration Metrics'},
                                           //{icon: 'fa fa-cogs', state: 'MaintenanceData', label: 'Maintenance'},
                                           {icon: 'fa fa-desktop', state: 'EquipmentData', label: 'Equipment Data'},
                                           {icon: 'fa fa-cog', state: 'Orders', label: 'Orders Data'},
                                           {icon: 'fa fa-cog', state: 'DealMachinesData', label: 'DM Data'},
                                           {icon: 'fa fa-cog', state: 'OutageData', label: 'Outage Data'},
                                           {icon: 'fa fa-cog', state: 'ServiceReqData', label: 'Service Request Data'}
                                       ]},
                                       {icon: 'fa fa-cog', state: 'CombinedAnalysis', label: 'Combined Analysis'},
                                       {icon: 'fa fa-cog', state: 'UserManual', label: 'User Manual'}
                                   ];
					// used this scope variable in IPMMainCtrl.js
					$rootScope.ipmRole = 'N';
				} else if($rootScope.roleId == 9) {
					window.App.tabs = [ {icon: 'fa fa-cog', state: 'InstalledBase', label: 'Installed Base'},
					                    {icon: 'fa fa-bar-chart', state: 'IPM', label: 'IPM', subitems: [
                                            {icon: 'fa fa-bar-chart',label: 'KeyDeals'},
                                            {icon: 'fa fa-cogs',label: 'Risk'},
                                            {icon: 'fa fa-cogs',label: 'Opps'},
                                            {icon: 'fa fa-cogs',label: 'BO (Walk By Business)'},
                                            {icon: 'fa fa-cogs',label: 'BO (Walk By Regions)'},
                                            {icon: 'fa fa-cogs',label: 'Data Entry'},
                                            {icon: 'fa fa-cogs',label: 'Project Controller - TX'},
                                            {icon: 'fa fa-cogs',label: 'Project Controller - CS'},
                                            {icon: 'fa fa-cogs',label: 'Project Controller - INST'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Product - TX'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Product - CS'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Product - INST'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Finance'}
                                        ]},
                                        {icon: 'fa fa-cog', state: 'IPMParts', label: 'IPM Parts'},
                                        {icon: 'fa fa-bar-chart', state: 'NewMetrics', label: 'IBO Metrics', subitems: [
                                           {icon: 'fa fa-bar-chart', state: 'Metrics', label: 'Penetration Metrics'},
                                           //{icon: 'fa fa-cogs', state: 'MaintenanceData', label: 'Maintenance'},
                                           {icon: 'fa fa-desktop', state: 'EquipmentData', label: 'Equipment Data'},
                                           {icon: 'fa fa-cog', state: 'Orders', label: 'Orders Data'},
                                           {icon: 'fa fa-cog', state: 'DealMachinesData', label: 'DM Data'},
                                           {icon: 'fa fa-cog', state: 'OutageData', label: 'Outage Data'},
                                           {icon: 'fa fa-cog', state: 'ServiceReqData', label: 'Service Request Data'}
                                       ]},
                                       {icon: 'fa fa-cog', state: 'CombinedAnalysis', label: 'Combined Analysis'},
                                       {icon: 'fa fa-cog', state: 'UserManual', label: 'User Manual'}
                                   ];
					// used this scope variable in IPMMainCtrl.js
					$rootScope.ipmRole = 'N';
//				} else if($rootScope.roleId == 2 || $rootScope.roleId == 11 || $rootScope.roleId == 12){
                } else if($rootScope.roleId == 2) {
                    
//					if($rootScope.roleId == 2 || $rootScope.roleId == 11) {
                    if($rootScope.roleId == 2) {
					window.App.tabs = [ {icon: 'fa fa-cog', state: 'InstalledBase', label: 'Installed Base'},
                                        {icon: 'fa fa-cog', label: 'Admin Panel', subitems: [
                                            {icon: 'fa fa-user-with-cog', state: 'Documents', label: 'Manage Documents'}
                                        ]},
					                    {icon: 'fa fa-bar-chart', state: 'NewMetrics', label: 'IBO Metrics', subitems: [
                                            {icon: 'fa fa-bar-chart', state: 'Metrics', label: 'Penetration Metrics'},
                                            //{icon: 'fa fa-cogs', state: 'MaintenanceData', label: 'Maintenance'},
                                            {icon: 'fa fa-desktop', state: 'EquipmentData', label: 'Equipment Data'},
                                            {icon: 'fa fa-cog', state: 'Orders', label: 'Orders Data'},
                                            {icon: 'fa fa-cog', state: 'DealMachinesData', label: 'DM Data'},
                                            {icon: 'fa fa-cog', state: 'OutageData', label: 'Outage Data'},
                                            {icon: 'fa fa-cog', state: 'ServiceReqData', label: 'Service Request Data'}
                                        ]},
                                        {icon: 'fa fa-cog', state: 'CombinedAnalysis', label: 'Combined Analysis'},
                                        {icon: 'fa fa-cog', state: 'UserManual', label: 'User Manual'}
                                       ];
					
					}
                    
//					if($rootScope.roleId == 12){
//					window.App.tabs = [ {icon: 'fa fa-cog', state: 'InstalledBase', label: 'Installed Base'},
//                                        {icon: 'fa fa-cog', label: 'Admin Panel', subitems: [
//                                            {icon: 'fa fa-user-with-cog', state: 'Documents', label: 'Manage Documents'}
//                                        ]},
//					                    {icon: 'fa fa-bar-chart', state: 'NewMetrics', label: 'IBO Metrics', subitems: [
//                                            {icon: 'fa fa-bar-chart', state: 'Metrics', label: 'Penetration Metrics'},
//                                            {icon: 'fa fa-desktop', state: 'EquipmentData', label: 'Equipment Data'},
//                                            {icon: 'fa fa-cog', state: 'Orders', label: 'Orders Data'},
//                                            {icon: 'fa fa-cog', state: 'DealMachinesData', label: 'DM Data'},
//                                            {icon: 'fa fa-cog', state: 'OutageData', label: 'Outage Data'},
//                                        ]},
//                                        {icon: 'fa fa-cog', state: 'CombinedAnalysis', label: 'Combined Analysis'},
//                                        {icon: 'fa fa-cog', state: 'UserManual', label: 'User Manual'}
//                                       ];
//
//					}
					// used this scope variable in IPMMainCtrl.js
					$rootScope.ipmRole = 'N';
//				} else if($rootScope.roleId == 3 || $rootScope.roleId == 13 || $rootScope.roleId == 14){
                } else if($rootScope.roleId == 3) {
                    
//                  if($rootScope.roleId == 3 || $rootScope.roleId == 13){
					if($rootScope.roleId == 3) {
					window.App.tabs = [ {icon: 'fa fa-cog', state: 'InstalledBase', label: 'Installed Base'},
					                    {icon: 'fa fa-bar-chart', state: 'NewMetrics', label: 'IBO Metrics', subitems: [
                                            {icon: 'fa fa-bar-chart', state: 'Metrics', label: 'Penetration Metrics'},
                                            //{icon: 'fa fa-cogs', state: 'MaintenanceData', label: 'Maintenance'},
                                            {icon: 'fa fa-desktop', state: 'EquipmentData', label: 'Equipment Data'},
                                            {icon: 'fa fa-cog', state: 'Orders', label: 'Orders Data'},
                                            {icon: 'fa fa-cog', state: 'DealMachinesData', label: 'DM Data'},
                                            {icon: 'fa fa-cog', state: 'OutageData', label: 'Outage Data'},
                                            {icon: 'fa fa-cog', state: 'ServiceReqData', label: 'Service Request Data'}
                                        ]},
                                        {icon: 'fa fa-cog', state: 'CombinedAnalysis', label: 'Combined Analysis'},
                                        {icon: 'fa fa-cog', state: 'UserManual', label: 'User Manual'}
                                       ];

					}
                    
//					if($rootScope.roleId == 14) {
//					window.App.tabs = [ {icon: 'fa fa-cog', state: 'InstalledBase', label: 'Installed Base'},
//					                    {icon: 'fa fa-bar-chart', state: 'NewMetrics', label: 'IBO Metrics', subitems: [
//                                            {icon: 'fa fa-bar-chart', state: 'Metrics', label: 'Penetration Metrics'},
//                                            {icon: 'fa fa-desktop', state: 'EquipmentData', label: 'Equipment Data'},
//                                            {icon: 'fa fa-cog', state: 'Orders', label: 'Orders Data'},
//                                            {icon: 'fa fa-cog', state: 'DealMachinesData', label: 'DM Data'},
//                                            {icon: 'fa fa-cog', state: 'OutageData', label: 'Outage Data'},
//                                        ]},
//                                        {icon: 'fa fa-cog', state: 'CombinedAnalysis', label: 'Combined Analysis'},
//                                        {icon: 'fa fa-cog', state: 'UserManual', label: 'User Manual'}
//                                       ];
//					}
					// used this scope variable in IPMMainCtrl.js
					$rootScope.ipmRole = 'N';
//				} else if($rootScope.roleId == 10 || $rootScope.roleId == 15 || $rootScope.roleId == 16){
//					if($rootScope.roleId == 10 || $rootScope.roleId == 15){
//					window.App.tabs = [ {icon: 'fa fa-cog', state: 'InstalledBase', label: 'Installed Base'},
//					                    {icon: 'fa fa-bar-chart', state: 'NewMetrics', label: 'IBO Metrics', subitems: [
//                                            {icon: 'fa fa-bar-chart', state: 'Metrics', label: 'Penetration Metrics'},
//                                            {icon: 'fa fa-cogs', state: 'MaintenanceData', label: 'Maintenance'},
//                                            {icon: 'fa fa-desktop', state: 'EquipmentData', label: 'Equipment Data'},
//                                            {icon: 'fa fa-cog', state: 'DealMachinesData', label: 'DM Data'},
//                                            {icon: 'fa fa-cog', state: 'OutageData', label: 'Outage Data'},
//                                            {icon: 'fa fa-cog', state: 'ServiceReqData', label: 'Service Request Data'}
//                                        ]},
//                                        {icon: 'fa fa-cog', state: 'CombinedAnalysis', label: 'Combined Analysis'},
//                                        {icon: 'fa fa-cog', state: 'UserManual', label: 'User Manual'}
//                                    ];
//
//					}
//					if($rootScope.roleId == 16){
//					window.App.tabs = [ {icon: 'fa fa-cog', state: 'InstalledBase', label: 'Installed Base'},
//					                    {icon: 'fa fa-bar-chart', state: 'NewMetrics', label: 'IBO Metrics', subitems: [
//                                            {icon: 'fa fa-bar-chart', state: 'Metrics', label: 'Penetration Metrics'},
//                                            {icon: 'fa fa-desktop', state: 'EquipmentData', label: 'Equipment Data'},
//                                            {icon: 'fa fa-cog', state: 'DealMachinesData', label: 'DM Data'},
//                                            {icon: 'fa fa-cog', state: 'OutageData', label: 'Outage Data'},
//                                        ]},
//                                        {icon: 'fa fa-cog', state: 'CombinedAnalysis', label: 'Combined Analysis'},
//                                        {icon: 'fa fa-cog', state: 'UserManual', label: 'User Manual'}
//                                    ];
//					}
//					// used this scope variable in IPMMainCtrl.js
//					$rootScope.ipmRole = 'N';
				} else if ($rootScope.userRoles[i].roleId == 4) {
					window.App.tabs = [ {icon: 'fa fa-bar-chart', state: 'IPM', label: 'IPM', subitems: [
                                            {icon: 'fa fa-bar-chart',label: 'KeyDeals'},
                                            {icon: 'fa fa-cogs',label: 'Risk'},
                                            {icon: 'fa fa-cogs',label: 'Opps'},
                                            {icon: 'fa fa-cogs',label: 'BO (Walk By Business)'},
                                            {icon: 'fa fa-cogs',label: 'BO (Walk By Regions)'},
                                            {icon: 'fa fa-cogs',label: 'Data Entry'},
                                            {icon: 'fa fa-cogs',label: 'Project Controller - TX'},
                                            {icon: 'fa fa-cogs',label: 'Project Controller - CS'},
                                            {icon: 'fa fa-cogs',label: 'Project Controller - INST'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Product - TX'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Product - CS'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Product - INST'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Finance'}
                                        ]},
                                        {icon: 'fa fa-cog', label: 'Admin Panel', subitems: [
                                            {icon: 'fa fa-user-with-cog', state: 'Documents', label: 'Manage Documents'}
                                        ]},
                                        {icon: 'fa fa-cog', state: 'IPMParts', label: 'IPM Parts'},
                                        {icon: 'fa fa-cog', state: 'UserManual', label: 'User Manual'}
                                    ];
					// used this scope variable in IPMMainCtrl.js
					$rootScope.ipmRole = 'Y';
				} else if ($rootScope.userRoles[i].roleId == 5 || $rootScope.userRoles[i].roleId == 6 || $rootScope.userRoles[i].roleId == 7 || $rootScope.userRoles[i].roleId == 8) {
					window.App.tabs = [ {icon: 'fa fa-bar-chart', state: 'IPM', label: 'IPM', subitems: [
                                            {icon: 'fa fa-bar-chart',label: 'KeyDeals'},
                                            {icon: 'fa fa-cogs',label: 'Risk'},
                                            {icon: 'fa fa-cogs',label: 'Opps'},
                                            {icon: 'fa fa-cogs',label: 'BO (Walk By Business)'},
                                            {icon: 'fa fa-cogs',label: 'BO (Walk By Regions)'},
                                            {icon: 'fa fa-cogs',label: 'Data Entry'},
                                            {icon: 'fa fa-cogs',label: 'Project Controller - TX'},
                                            {icon: 'fa fa-cogs',label: 'Project Controller - CS'},
                                            {icon: 'fa fa-cogs',label: 'Project Controller - INST'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Product - TX'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Product - CS'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Product - INST'},
                                            {icon: 'fa fa-cogs',label: 'Walk By Finance'}
                                        ]},
                                        {icon: 'fa fa-cog', state: 'IPMParts', label: 'IPM Parts'},
                                        {icon: 'fa fa-cog', state: 'UserManual', label: 'User Manual'}
                                    ];
					// used this scope variable in IPMMainCtrl.js
					$rootScope.ipmRole = 'Y';
				}
				// setting edit/upload functinality status to the respective roles
//				if ($rootScope.userRoles[i].roleId == 1 || $rootScope.userRoles[i].roleId == 2 ||
//					$rootScope.userRoles[i].roleId == 4 || $rootScope.userRoles[i].roleId == 5 ||
//					$rootScope.userRoles[i].roleId == 7 || $rootScope.userRoles[i].roleId == 11||
//					$rootScope.userRoles[i].roleId == 12){
                
                if ($rootScope.userRoles[i].roleId == 1 || $rootScope.userRoles[i].roleId == 2 ||
					$rootScope.userRoles[i].roleId == 4 || $rootScope.userRoles[i].roleId == 5 ){
					$rootScope.editAccess = 'Y';
				} else {
					$rootScope.editAccess = 'N';
				}
                
                if ($rootScope.userRoles[i].roleId !== 4 || $rootScope.userRoles[i].roleId !== 5 ||
					$rootScope.userRoles[i].roleId !== 6 || $rootScope.userRoles[i].roleId !== 7 ||
					$rootScope.userRoles[i].roleId !== 8){
					$rootScope.mShow = "Y";
				}

//				if($rootScope.businessSegment === null ||$rootScope.businessSegment === undefined){
//					if ($rootScope.roleId == 1 ||$rootScope.roleId == 2 ||
//							$rootScope.roleId == 3 || $rootScope.roleId == 4 ||
//							$rootScope.roleId == 9 || $rootScope.roleId == 10){
//						$rootScope.businessSegment="admin"
//					}else if ($rootScope.roleId == 5 || $rootScope.roleId == 6 ||
//							$rootScope.roleId == 12 || $rootScope.roleId == 14 ||
//							$rootScope.roleId == 16){
//					    $rootScope.businessSegment= 'TMS'
//					} else if($rootScope.roleId == 7 || $rootScope.roleId == 8 ||
//							$rootScope.roleId == 11 || $rootScope.roleId == 13 ||
//							$rootScope.roleId == 15){
//					    $rootScope.businessSegment= 'DTS';
//					}
//				}
                
                if($rootScope.businessSegment === null ||$rootScope.businessSegment === undefined){
					if ($rootScope.roleId == 1 ||$rootScope.roleId == 2 || $rootScope.roleId == 3 || $rootScope.roleId == 4 || $rootScope.roleId == 9){
						$rootScope.businessSegment="admin"
					} else if ($rootScope.roleId == 5 || $rootScope.roleId == 6) {
					    $rootScope.businessSegment= 'TMS'
					} else if($rootScope.roleId == 7 || $rootScope.roleId == 8) {
					    $rootScope.businessSegment= 'DTS';
					}
				}
				
				if($rootScope.businessSegment === "DTS"){
					$scope.dtsShow = false;
					$scope.disabled = true;
				}else if($rootScope.businessSegment === "TMS"){
					$scope.tmsShow = false;
					$scope.disabled = true;
				}else if ($rootScope.businessSegment === "admin") {
					$scope.allShow = false;
					$scope.enabled = true;
                    
					if(sessionStorage.businessSegment === null ||sessionStorage.businessSegment === undefined){
						$rootScope.businessSegment = 'DTS';
					}else {
						$rootScope.businessSegment = sessionStorage.businessSegment;
						if($rootScope.businessSegment === 'TMS'){
							$timeout(function(){
								$("#switchUser #enabled").removeClass("checked");
							})
						}
					}
				}
			}
		}

		var _userRoleInfo = {}, $timeout=$injector.get('$timeout');
		
		$rootScope.userAuthentication = function(userDataObj, next_state) {

			userDataObj = userDataObj || null;
			if (userDataObj === null || userDa0taObj === undefined) {
                $.ajax({
                method: 'GET',
                async: false,
                url: window.px.auth._userInfoUrl,
                }).success(function(userInfo){
                        $rootScope.userSSO = userInfo.user_name;
//                        $rootScope.userSSO = '502667253';
                        var userRoles = [];
                        $.ajax({
                            method: 'POST',
                            headers: { 
                                'Accept': 'application/json',
                                'Content-Type': 'application/json' 
                            },
                            async: false,
                            url: 'connect/fms/authorizeUser',
                            data: JSON.stringify({"data":$rootScope.userSSO}),
                            dataType: 'json',
                        }).success(function(response){
                            _userRoleInfo = response;
                        }).error(function(error){
                            console.log(error);
                        });
                }).error(function(error){
                    console.log(error);
                });
			}
		}
		
		var eligibleStates = null;
		var authorizeUser = function(toStateName){
			if(_userRoleInfo.length>0){
				var tempUserInfo = _userRoleInfo[0];
				var _roles = tempUserInfo.userRoles;
				if(_roles.length>0){
					$rootScope.userRoles=_roles;
					_roles=_roles[0];
					_roles = _roles.roleId;
					$rootScope.roleId = _roles;
					if(eligibleStates===null){
						$rootScope.shwRoleBasedMenu();
						eligibleStates = [];
						_.forEach(window.App.tabs, function(tabs){
							eligibleStates.push(tabs.state);
							if(tabs.subitems!==undefined && tabs.subitems!==undefined && tabs.subitems.length>0){
								_.forEach(tabs.subitems, function(subItems){
									eligibleStates.push(subItems.state);
								});
							}
						});
						if(eligibleStates.indexOf("NewMetrics")) {
							var newMetricsSubItemsArray = ['ib/TechnoRegion','ib/topCustomer','dm/technoRegion','dm/topCustomer','ibo/technoRegion','ibo/topCustomer','order/technoRegion','order/topCustomer','outage/technoRegion','outage/topCustomer','serviceReq/technology','serviceReq/topCustomer'];
							_.forEach(newMetricsSubItemsArray, function(subItems){
							eligibleStates.push(subItems);
							});
						}
						$rootScope.eligibleStates = eligibleStates;
					}
					var newState = '';

					if(_roles){
						if(toStateName!==null && toStateName!==undefined){
							newState = toStateName;
						}
						if(newState==='homepage'){
							toStateName = eligibleStates[0];
							newState = toStateName;
						}
						if(eligibleStates.indexOf(newState)===-1){
							//Not Authorized
							newState = ('Authorization');
						}
						else
							newState = toStateName || newState;
						$timeout(function(){
							document.querySelector('px-app-nav').markSelected('/'+newState);
						})

						$state.go(newState);
					}
				}else {
					$state.go('Authorization');
				}
			} else {
				$state.go('Authorization');
			}

		}
		var preAuthorize = function(toState, fromState){
			var authCheck = _userRoleInfo===null || $.isEmptyObject(_userRoleInfo);
			if(authCheck){
				//User is not authenticated yet.
				$rootScope.userAuthentication();
			}else{

			}
			if(toState!==undefined && fromState!==undefined){
				if(toState.name!==fromState.name){
					authorizeUser(toState.name);
				}
			}	else{
				authorizeUser();
			}		
		}
        
		$rootScope.$on('$stateChangeSuccess', function(event, toState, toStateParams, fromState, fromStateParams){
			event.preventDefault();
			
			if(toState.name!=='Authorization'){
                
                $("#marketIndustryDropdownBean option[value*='Industrial']").prop('disabled',false);
                $("#marketIndustryDropdownBean option[value*='Onshore/Offshore Production']").prop('disabled',false);
                
                if(toState.name === "IPM" || toState.name === "IPMParts"){
                    $(".fms-navbar").hide();
                } else {
                   $(".fms-navbar").show();
                }
                
                if(toState.name === "InstalledBase" || toState.name === "NewMetrics" || toState.name === "CombinedAnalysis" || toState.name === "ib/TechnoRegion" || toState.name === "ib/topCustomer" || toState.name === "ibo/technoRegion" || toState.name === "ibo/topCustomer" || toState.name === "order/technoRegion" || toState.name === "order/topCustomer" || toState.name === "dm/technoRegion" || toState.name === "dm/topCustomer" || toState.name === "outage/technoRegion" || toState.name === "outage/topCustomer") {
                    $("#fmsAccountManager").show();
                } else {
                    $("#fmsAccountManager").hide();
                }
                
                if(toState.name === "InstalledBase" || toState.name === "NewMetrics" || toState.name === "Metrics" || toState.name === "EquipmentData" || toState.name === "Orders" || toState.name === "DealMachinesData" || toState.name === "OutageData" || toState.name === "CombinedAnalysis" || toState.name === "ib/TechnoRegion" || toState.name === "ib/topCustomer" || toState.name === "ibo/technoRegion" || toState.name === "ibo/topCustomer" || toState.name === "order/technoRegion" || toState.name === "order/topCustomer" || toState.name === "dm/technoRegion" || toState.name === "dm/topCustomer" || toState.name === "outage/technoRegion" || toState.name === "outage/topCustomer") {
                    $("#fmsMarketIndustry").show();
                } else {
                    $("#fmsMarketIndustry").hide();
                }
                
                
                if(toState.name === "InstalledBase" || toState.name === "NewMetrics" || toState.name === "Metrics" || toState.name === "EquipmentData" || toState.name === "Orders" || toState.name === "DealMachinesData" || toState.name === "OutageData" || toState.name === "CombinedAnalysis" || toState.name === "ib/TechnoRegion" || toState.name === "ib/topCustomer" || toState.name === "ibo/technoRegion" || toState.name === "ibo/topCustomer" || toState.name === "order/technoRegion" || toState.name === "order/topCustomer" || toState.name === "dm/technoRegion" || toState.name === "dm/topCustomer" || toState.name === "outage/technoRegion" || toState.name === "outage/topCustomer") {
                    $("#fmsNavButton").show();
                } else {
                    $("#fmsNavButton").hide();
                }
                
                if(toState.name === "Metrics") {
                    $("#switchHistory").show();
                } else {
                    $("#switchHistory").hide();
                }
                
				if($rootScope.eligibleStates==null || $rootScope.eligibleStates==undefined){
					preAuthorize(toState, fromState);
				}else{
					if(toState.name!=='homepage' && $rootScope.eligibleStates.indexOf(toState.name)===-1){
						$state.go('Authorization');
					}
				}
			}
		});
        
        $timeout(function(){
            if(sessionStorage.getItem("accountManager")) {
                $scope.account_mgr_detail = JSON.parse(sessionStorage.getItem("accountManager"));
                $rootScope.accountManager = getSelectedValue(JSON.parse(sessionStorage.getItem("accountManager")));
            }
            
            if(sessionStorage.getItem("marketIndustry")) {
                $scope.marketIndustry     = sessionStorage.getItem("marketIndustry");
                $rootScope.marketIndustry = "^"+sessionStorage.getItem("marketIndustry")+"$";
            }
            
            $http.post("connect/fms/getMarketIndustryDescDropdown", JSON.stringify({})).success(function(response) {
                $scope.arrMarketIndustry = response["marketIndustryValues"];
            });
            
            if ($rootScope.accountManager || $rootScope.marketIndustry) {
                
                $http.post("connect/fms/getAccountManagers/"+$rootScope.businessSegment, {}).then(function(response) {
                    var selectOption        = "";
                    var accountManager      = "";
                    var accountManagerArray = response["data"]["accountManagerDetails"];

                    $timeout(function(){							
                         _.forEach(accountManagerArray, function(response){
                             accountManager = response.account_mgr_details;
                             selectOption   = selectOption + '<option value="'+accountManager+'">'+htmlEntities(accountManager)+'</option>';
                        })
                    })
                    .then(function(){
                        var scriptTag='<script>$("select#accountManagerDropdownBean").multipleSelect({filter: true, selectAll: true, onCheckAll: function() { $("#applyAccountManagerBtn").css("background-color", "#e64b3b"); }, onUncheckAll: function() { $("#applyAccountManagerBtn").css("background-color", "#e64b3b"); }, onClick: function() { $("#applyAccountManagerBtn").css("background-color", "#e64b3b"); }});</script>'
                        $timeout(function(){
                            /* Show Multiselect */
                            $('#accountManagerDropdownBean').empty().append(selectOption).append(scriptTag);
                            $('div.accountManagerSelectBtn').show(100);
                            $('select.dependentFilter[id="accountManagerDropdownBean"]').prop('disabled','false');
                            $('select.dependentFilter[id="accountManagerDropdownBean"]').siblings().children().removeClass('disabled');
                            $('button#placeMultiSelect').hide(100);

                            $("#accountManagerDropdownBean").multipleSelect();
                            $("#accountManagerDropdownBean").multipleSelect('setSelects', $scope.account_mgr_detail);
                        }).finally(function(){
                            $scope.applyAccountManagerData();
                        });
                    });
                });
            } else {
                $http.post("connect/fms/getAccountManagers/"+$rootScope.businessSegment, {}).then(function(response) {
                    var selectOption        = "";
                    var accountManager      = "";
                    var accountManagerArray = response["data"]["accountManagerDetails"];

                    $timeout(function(){
                         _.forEach(accountManagerArray, function(response){
                             accountManager = response.account_mgr_details;
                             selectOption   = selectOption + '<option value="'+accountManager+'">'+htmlEntities(accountManager)+'</option>';
                        })
                    })
                    .then(function(){
                        var scriptTag='<script>$("select#accountManagerDropdownBean").multipleSelect({filter: true, selectAll: true, onCheckAll: function() { $("#applyAccountManagerBtn").css("background-color", "#e64b3b"); }, onUncheckAll: function() { $("#applyAccountManagerBtn").css("background-color", "#e64b3b"); }, onClick: function() { $("#applyAccountManagerBtn").css("background-color", "#e64b3b"); }});</script>'
                        $timeout(function(){
                            /* Show Multiselect */
                            $('#accountManagerDropdownBean').empty().append(selectOption).append(scriptTag);
                            $('div.accountManagerSelectBtn').show(100);
                            $('select.dependentFilter[id="accountManagerDropdownBean"]').prop('disabled','false');
                            $('select.dependentFilter[id="accountManagerDropdownBean"]').siblings().children().removeClass('disabled');
                            $('button#placeMultiSelect').hide(100);
                        });
                    });
                });    
            }
        }, 5000);
        
        
        $( "#marketIndustryDropdownBean" ).change(function() {
            $("#applyAccountManagerBtn").css("background-color", "#e64b3b");
        });
        
        $scope.applyAccountManagerData = function() {
            
            $("#applyAccountManagerBtn").css("background-color", "#3CB371");
            
            $rootScope.accountManager     = getSelectedValue($scope.account_mgr_details);
            sessionStorage.accountManager = JSON.stringify($scope.account_mgr_details);
            
            $rootScope.marketIndustry     = $scope.marketIndustry ? "^"+$scope.marketIndustry+"$" : "";
            sessionStorage.marketIndustry = $scope.marketIndustry;
            
            if ($rootScope.accountManager || $rootScope.marketIndustry) {
                if($state.current.name === "InstalledBase") {
                    $rootScope.getInstalledBaseDropdownsData();
                    
                    if(localStorage.getItem("siteFilterCode") === null && localStorage.getItem("regionFilterCode") === null && localStorage.getItem("countryFilterCode") === null) {
                        $rootScope.ibSearchData();    
                    }
                } else if($state.current.name === "NewMetrics") {
                    $rootScope.ibMetricsSearchData();
                    $rootScope.iboMetricsSearchData();
                    $rootScope.orderMetricsSearchData();
                    $rootScope.dmMetricsSearchData();
                    $rootScope.outageMetricsSearchData();
                } else if($state.current.name === "ib/TechnoRegion") {
                    var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                    if(selectedTab===0) {
                        $rootScope.ibTechnoRegionDropdownsData();
                        $rootScope.ibTechnoRegionSearchData();
                    } else {
                        $rootScope.ibTechnoRegionDropdownsData();
                        $rootScope.dep_ibTechnoCountrySearchData();
                    }
                } else if($state.current.name === "ib/topCustomer") {
                    var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                    if(selectedTab===0) {
                        $rootScope.ibTopCustomerDropdownsData();
                        $rootScope.ibTopCustomerRegionSearchData();
                    } else {
                        $rootScope.ibTopCustomerDropdownsData();
                        $rootScope.dep_ibTopCustomerCountrySearchData();
                    }
                } else if($state.current.name === "ibo/technoRegion") {
                    var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                    if(selectedTab===0) {
                        $rootScope.iboTechnoRegionDropdownsData();
                        $rootScope.iboTechnoRegionSearchData();
                    } else {
                        $rootScope.iboTechnoRegionDropdownsData();
                        $rootScope.dep_iboTechnoCountrySearchData();
                    }
                } else if($state.current.name === "ibo/topCustomer") {
                    var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                    if(selectedTab===0) {
                        $rootScope.iboTopCustomerDropdownsData();
                        $rootScope.iboTopCustomerRegionSearchData();
                    } else {
                        $rootScope.iboTopCustomerDropdownsData();
                        $rootScope.dep_iboTopCustomerCountrySearchData();
                    }
                } else if($state.current.name === "order/technoRegion") {
                    var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                    if(selectedTab===0) {
                        $rootScope.orderTechnoRegionDropdownsData();
                        $rootScope.orderTechnoRegionSearchData();
                    } else {
                        $rootScope.orderTechnoRegionDropdownsData();
                        $rootScope.dep_orderTechnoCountrySearchData();
                    }
                } else if($state.current.name === "order/topCustomer") {
                    var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                    if(selectedTab===0) {
                        $rootScope.orderTopCustomerDropdownsData();
                        $rootScope.orderTopCustomerRegionSearchData();
                    } else {
                        $rootScope.orderTopCustomerDropdownsData();
                        $rootScope.dep_orderTopCustomerCountrySearchData();
                    }
                } else if($state.current.name === "dm/technoRegion") {
                    var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                    if(selectedTab===0) {
                        $rootScope.dmTechnoRegionDropdownsData();
                        $rootScope.dmTechnoRegionSearchData();
                    } else {
                        $rootScope.dmTechnoRegionDropdownsData();
                        $rootScope.dep_dmTechnoCountrySearchData();
                    }
                } else if($state.current.name === "dm/topCustomer") {
                    var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                    if(selectedTab===0) {
                        $rootScope.dmTopCustomerDropdownsData();
                        $rootScope.dmTopCustomerRegionSearchData();
                    } else {
                        $rootScope.dmTopCustomerDropdownsData();
                        $rootScope.dep_dmTopCustomerCountrySearchData();
                    }
                } else if($state.current.name === "outage/technoRegion") {
                    var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                    if(selectedTab===0) {
                        $rootScope.outageTechnoRegionDropdownsData();
                        $rootScope.outageTechnoRegionSearchData();
                    } else {
                        $rootScope.outageTechnoRegionDropdownsData();
                        $rootScope.dep_outageTechnoCountrySearchData();
                    }
                } else if($state.current.name === "outage/topCustomer") {
                    var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                    if(selectedTab===0) {
                        $rootScope.outageTopCustomerDropdownsData();
                        $rootScope.outageTopCustomerRegionSearchData();
                    } else {
                        $rootScope.outageTopCustomerDropdownsData();
                        $rootScope.dep_outageTopCustomerCountrySearchData();
                    }
                } else if($state.current.name === "CombinedAnalysis") {
                    $rootScope.getCombinedAnalysisDropdownsData();
                    if(localStorage.getItem("siteFilterCode") === null && localStorage.getItem("regionFilterCode") === null && localStorage.getItem("countryFilterCode") === null && localStorage.getItem("yearQuarterFilterCode") === null) {
                        $rootScope.combinedAnalysisSearchData();
                    }
                } else if($state.current.name === "EquipmentData") {
                    $rootScope.equipmentSearchData('DEFAULT');
                } else if($state.current.name === "Orders") {
                    $rootScope.ordersSearchData('DEFAULT');
                } else if($state.current.name === "DealMachinesData") {
                    $rootScope.dealMachinesSearchData('DEFAULT');
                } else if($state.current.name === "OutageData") {
                    $rootScope.outageSearchData('DEFAULT');
                } else if($state.current.name === "Metrics") {
                    if($rootScope.marketIndustry === "^Industrial$" || $rootScope.marketIndustry === "^Onshore/Offshore Production$") {
                        $('#indep_segment').addClass('visuallyhidden');
                    } else {
                        $('#indep_segment').removeClass('visuallyhidden');
                    }
                    
                    var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                    if(selectedTab === 0) {
                        $rootScope.iboByRegionData(false, true);
                    } else {
                        $rootScope.regionLevelSearchData();
                        $rootScope.getGEDunsDropdownsData();
                    }
                }
            }
        }
        
        $scope.clearAccountManagerData = function() {
            
            $("#applyAccountManagerBtn").css("background-color", "#3CB371");
            
            $rootScope.accountManager  = null;
            $scope.account_mgr_details = "";
            sessionStorage.removeItem('accountManager');
            
            $("#accountManagerDropdownBean").val();
            
            $('.accountManagerSelectBtn').find('.ms-choice > span').html('');
            $('.accountManagerSelectBtn').find('input[type="checkbox"]').attr('checked', false);
            $('.accountManagerSelectBtn').find('input[type="radio"]').attr('checked', false);
            $('.accountManagerSelectBtn').find("select").val('');
            
            if($state.current.name === "InstalledBase") {
                $rootScope.getInstalledBaseDropdownsData();
                $rootScope.ibSearchData();
            } else if($state.current.name === "NewMetrics") {
                $rootScope.ibMetricsSearchData();
                $rootScope.iboMetricsSearchData();
                $rootScope.orderMetricsSearchData();
                $rootScope.dmMetricsSearchData();
                $rootScope.outageMetricsSearchData();
            } else if($state.current.name === "ib/TechnoRegion") {
                var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                if(selectedTab===0) {
                    $rootScope.ibTechnoRegionDropdownsData();
                    $rootScope.ibTechnoRegionSearchData();
                } else {
                    $rootScope.ibTechnoRegionDropdownsData();
                    $rootScope.dep_ibTechnoCountrySearchData();
                }
            } else if($state.current.name === "ib/topCustomer") {
                var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                if(selectedTab===0) {
                    $rootScope.ibTopCustomerDropdownsData();
                    $rootScope.ibTopCustomerRegionSearchData();
                } else {
                    $rootScope.ibTopCustomerDropdownsData();
                    $rootScope.dep_ibTopCustomerCountrySearchData();
                }
            } else if($state.current.name === "ibo/technoRegion") {
                var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                if(selectedTab===0) {
                    $rootScope.iboTechnoRegionDropdownsData();
                    $rootScope.iboTechnoRegionSearchData();
                } else {
                    $rootScope.iboTechnoRegionDropdownsData();
                    $rootScope.dep_iboTechnoCountrySearchData();
                }
            } else if($state.current.name === "ibo/topCustomer") {
                var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                if(selectedTab===0) {
                    $rootScope.iboTopCustomerDropdownsData();
                    $rootScope.iboTopCustomerRegionSearchData();
                } else {
                    $rootScope.iboTopCustomerDropdownsData();
                    $rootScope.dep_iboTopCustomerCountrySearchData();
                }
            } else if($state.current.name === "order/technoRegion") {
                var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                if(selectedTab===0) {
                    $rootScope.orderTechnoRegionDropdownsData();
                    $rootScope.orderTechnoRegionSearchData();
                } else {
                    $rootScope.orderTechnoRegionDropdownsData();
                    $rootScope.dep_orderTechnoCountrySearchData();
                }
            } else if($state.current.name === "order/topCustomer") {
                var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                if(selectedTab===0) {
                    $rootScope.orderTopCustomerDropdownsData();
                    $rootScope.orderTopCustomerRegionSearchData();
                } else {
                    $rootScope.orderTopCustomerDropdownsData();
                    $rootScope.dep_orderTopCustomerCountrySearchData();
                }
            } else if($state.current.name === "dm/technoRegion") {
                var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                if(selectedTab===0) {
                    $rootScope.dmTechnoRegionDropdownsData();
                    $rootScope.dmTechnoRegionSearchData();
                } else {
                    $rootScope.dmTechnoRegionDropdownsData();
                    $rootScope.dep_dmTechnoCountrySearchData();
                }
            } else if($state.current.name === "dm/topCustomer") {
                var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                if(selectedTab===0) {
                    $rootScope.dmTopCustomerDropdownsData();
                    $rootScope.dmTopCustomerRegionSearchData();
                } else {
                    $rootScope.dmTopCustomerDropdownsData();
                    $rootScope.dep_dmTopCustomerCountrySearchData();
                }
            } else if($state.current.name === "outage/technoRegion") {
                var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                if(selectedTab===0) {
                    $rootScope.outageTechnoRegionDropdownsData();
                    $rootScope.outageTechnoRegionSearchData();
                } else {
                    $rootScope.outageTechnoRegionDropdownsData();
                    $rootScope.dep_outageTechnoCountrySearchData();
                }
            } else if($state.current.name === "outage/topCustomer") {
                var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
                if(selectedTab===0) {
                    $rootScope.outageTopCustomerDropdownsData();
                    $rootScope.outageTopCustomerRegionSearchData();
                } else {
                    $rootScope.outageTopCustomerDropdownsData();
                    $rootScope.dep_outageTopCustomerCountrySearchData();
                }
            } else if($state.current.name === "CombinedAnalysis") {
                $rootScope.getCombinedAnalysisDropdownsData();
                $rootScope.combinedAnalysisSearchData();
            } else if($state.current.name === "EquipmentData") {
                $rootScope.equipmentSearchData('DEFAULT');
            } else if($state.current.name === "Orders") {
                $rootScope.ordersSearchData('DEFAULT');
            } else if($state.current.name === "DealMachinesData") {
                $rootScope.dealMachinesSearchData('DEFAULT');
            } else if($state.current.name === "OutageData") {
                $rootScope.outageSearchData('DEFAULT');
            } else if($state.current.name === "Metrics") {
                $rootScope.iboByRegionData(false, true);
                $rootScope.regionLevelSearchData();
                $rootScope.getGEDunsDropdownsData();
            }
    	}
        
		$scope.changeCallback = function() {
			if($rootScope.businessSegment == 'TMS'){
				$rootScope.businessSegment = 'DTS';
				sessionStorage.businessSegment='DTS';
			} else {
				$rootScope.businessSegment = 'TMS';
				sessionStorage.businessSegment='TMS';
			}
			location.reload(true);
		};
        
        $scope.changeHistoryCallback = function() {
			if($rootScope.cHistoryLegacySwitch === 'history'){
				$rootScope.cHistoryLegacySwitch     = 'legacy';
				sessionStorage.cHistoryLegacySwitch = 'legacy';
                $("#fmsMarketIndustry").hide();
                $("#fmsNavButton").hide();
			} else {
				$rootScope.cHistoryLegacySwitch     = 'history';
				sessionStorage.cHistoryLegacySwitch = 'history';
                $("#fmsMarketIndustry").show();
                $("#fmsNavButton").show();
			}
            
            var selectedTab = Polymer.dom().querySelector('px-tab-pages').selected;
            if(selectedTab === 2 ) {
               $rootScope.regionLevelSearchData();
            } else if(selectedTab === 3 ) {
               $rootScope.countryLevelSearchData();
            } else if(selectedTab === 4 ) {
               $rootScope.technologyLevelSearchData();
            } else if(selectedTab === 5 ) {
               $rootScope.siteLevelSearchData();
            } else if(selectedTab === 6 ) {
               $rootScope.geDunsLevelSearchData();
            } else if(selectedTab === 7 ) {
               $rootScope.segmentLevelSearchData();
            }
		};
		$rootScope.loader = true;
		
	}]);
	//Set on window for debugging
	window.predixApp = predixApp;
	$('#loader').outerWidth($('.viewport').outerWidth());
	$('#loader').outerHeight($('main').outerHeight());
	$('#loader').css('position','absolute');
	//Return the application  object
	return predixApp;
});