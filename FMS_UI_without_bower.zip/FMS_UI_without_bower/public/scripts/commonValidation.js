/**
 * 
 */

 
 
 
function isNullCheck(input, datatype){
	if(datatype=="CHAR")
	{
		if(input==null || input=="" || input==undefined)
		{
			return "";
		}
		else
		{
			return input;
		}
	}
	else if(datatype=="NUM")
	{
		if(input==null || input=="" || input==undefined)
		{
			return 0;
		}
		else
		{
			return input;
		}
	}
	else
	{
		return input;
	}
	
}

function isAlphanumeric(input){
	var regAlphanumeric = /^[-a-zA-Z0-9_\s]*$/; /*Alphanumeric*/
	if(!regAlphanumeric.test(input))
	{
		return false;
	}
	else
	{
		return true;
	}
}

function isAlpha(input){
	var regAlpha = /^[-a-zA-Z]*$/; /*Alpha*/
	if(!regAlpha.test(input))
	{
		return false;
	}
	else
	{
		return true;
	}
}

function isDecimal(input){
	var regDecimal = /^\d+(\.\d+)?$/i;
	if(!regDecimal.test(input))
	{
		return false;
	}
	else
	{
		return true;
	}
}
function isNumber(input){
	var regNumber = /^[0-9]*$/;
	if(!regNumber.test(input))
	{
		return false;
	}
	else
	{
		return true;
	}
}

function resizeAll(){
    setTimeout(function(){
                    var mainDivHeight=window.innerHeight-angular.element("header").outerHeight()-angular.element("footer").outerHeight();
                    angular.element("#mainDivSection").outerHeight(mainDivHeight+42);
                    angular.element("#metricsmainDivSection").outerHeight(mainDivHeight-40);
                    angular.element("#countryLevelDiv").outerHeight(mainDivHeight-180);
                    angular.element("#technologyLevelDiv").outerHeight(mainDivHeight-180);
                    angular.element("#siteLevelDiv").outerHeight(mainDivHeight-180);
                    angular.element("#dunsLevelDiv").outerHeight(mainDivHeight-180);
                    angular.element("#topSitesDiv").outerHeight(mainDivHeight-180);
                    if ( ((screen.width === 1280) && (screen.height === 720)) || ((screen.width === 1280) && (screen.height === 600))) {
                        mainDivHeight = 515;
                    }
                    
                    var isMobile = false;
                    var isTablet = false;
                    if(screen.width <= 800 && screen.height <= 1024) {
                        isMobile = true;
                    }
        
                    isTablet = navigator.userAgent.match(/iPad/i) != null;
        
                    if (isMobile === false && isTablet === false) {
                        angular.element("#penetrationMetricsMainDivSection").outerHeight(mainDivHeight-40);
                        angular.element(".mapViewDiv").outerHeight(mainDivHeight-40); 
                        angular.element("#sidebar-wrapper").outerHeight(mainDivHeight-40); 
                        angular.element("#container").outerHeight(mainDivHeight-200); 
                        angular.element("#PenContainer").outerHeight(mainDivHeight-200);
                    } 
                    
    },200);
}

function numberWithCommas(x) {
	if (x ==="" || x === null || x === "undefined") 
	 {
		x=0.00;
		return x.toString();
	 }
	else
	{
		return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	}
}




function checkDDValue(input){
	if(input=="Select"||input==undefined)
	{
		input="";
	}
	return input;
}

function getSelectedValue(id){
    if(id!==undefined){
        var values = [];
        _.forEach(id, function(choice){
        values.push("^"+choice+"$");
        });
        return values.join("|");
    }else {
        return "";
    }
}
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    





