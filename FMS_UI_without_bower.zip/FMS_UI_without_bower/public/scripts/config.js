/* global requirejs, define */
/* jshint camelcase: false */
/* jshint unused: false */

'use strict';
/**
* This file sets up the basic module libraries you'll need
* for your application.
*/
requirejs.onError = function(err) {
    //console.log(err.requireType);
    if (err.requireType === 'timeout') {
        //console.error('modules: ' + err.requireModules);
    }
    throw err;
};
/**
* RequireJS Config
* This is configuration for the entire application.
*/
require.config({
    enforceDefine: false,
    xhtml: false,
    //Cache buster
    //urlArgs : '_=' + Date.now(),
    waitSeconds: 15,
    config: {
        text: {
            env: 'xhr'
        }
    },
    paths: {
        'bower_components': '../bower_components',
        'px-datasource': '../bower_components/px-datasource/dist/px-datasource.min',

        'ng-bind-polymer': '../bower_components/ng-bind-polymer/ng-bind-polymer',

        // Named References
        config: './config',
        app: './app',

        // angularjs + modules
        angular: '../bower_components/angular/angular',
        'angular-mocks': '../bower_components/angular-mocks/angular-mocks',
        'angular-resource': '../bower_components/angular-resource/angular-resource',
        'angular-route': '../bower_components/angular-route/angular-route',

        // angular ui router
        'angular-ui-router': '../bower_components/angular-ui-router/release/angular-ui-router.min',

        'bootstrap': '../bower_components/iids/components/bootstrap/js',
        // IIDx additions
        'accordion' : '../bower_components/iids/components/ge-bootstrap/js/ge-bootstrap/accordion',
        'bootstrap-affix' : '../bower_components/iids/components/bootstrap/js/bootstrap-affix',
        'bootstrap-alert' : '../bower_components/iids/components/bootstrap/js/bootstrap-alert',
        'bootstrap-button' : '../bower_components/iids/components/bootstrap/js/bootstrap-button',
        'bootstrap-carousel' : '../bower_components/iids/components/bootstrap/js/bootstrap-carousel',
        'bootstrap-collapse' : '../bower_components/iids/components/bootstrap/js/bootstrap-collapse',
        'bootstrap-dropdown' : '../bower_components/iids/components/bootstrap/js/bootstrap-dropdown',
        'bootstrap-modal' : '../bower_components/iids/components/bootstrap/js/bootstrap-modal',
        'bootstrap-scrollspy' : '../bower_components/iids/components/bootstrap/js/bootstrap-scrollspy',
        'bootstrap-tab' : '../bower_components/iids/components/bootstrap/js/bootstrap-tab',
        'bootstrap-tooltip' : '../bower_components/iids/components/bootstrap/js/bootstrap-tooltip',
        'bootstrap-popover' : '../bower_components/iids/components/bootstrap/js/bootstrap-popover',
        'bootstrap-transition' : '../bower_components/iids/components/bootstrap/js/bootstrap-transition',
        'bootstrap-typeahead' : '../bower_components/iids/components/bootstrap/js/bootstrap-typeahead',

        'bar-declarative-visualizations' : '../bower_components/iids/components/declarative-visualizations/js/declarative-visualizations/bar',
        'donut-declarative-visualizations' : '../bower_components/iids/components/declarative-visualizations/js/declarative-visualizations/donut',
        'guagedeclarative-visualizations' : '../bower_components/iids/components/declarative-visualizations/js/declarative-visualizations/gauge',
        'spiderweb-declarative-visualizations' : '../bower_components/iids/components/declarative-visualizations/js/declarative-visualizations/spiderweb',
        'sortable' : '../bower_components/iids/components/jqueryui-sortable-amd/js/jquery-ui-1.10.2.custom',

        
        // Require JS Plugins
        text: '../bower_components/requirejs-plugins/lib/text',
        order: '../bower_components/requirejs-plugins/src/order',
        async: '../bower_components/requirejs-plugins/src/async',
        depend: '../bower_components/requirejs-plugins/src/depend',
        font: '../bower_components/requirejs-plugins/src/font',
        goog: '../bower_components/requirejs-plugins/src/goog',
        image: '../bower_components/requirejs-plugins/src/image',
        json: '../bower_components/requirejs-plugins/src/json',
        mdown: '../bower_components/requirejs-plugins/src/mdown',
        noext: '../bower_components/requirejs-plugins/src/noext',
        propertyParser: '../bower_components/requirejs-plugins/src/propertyParser',
        Markdown: '../bower_components/requirejs-plugins/lib/Markdown.Converter',
        css: '../bower_components/require-css/css',
        'css-builder': '../bower_components/require-css/css-builder',
        'normalize': '../bower_components/require-css/normalize',

        lodash: '../bower_components/lodash/dist/lodash.min',
        jquery: '../bower_components/jquery/dist/jquery.min',
        datatables: '../bower_components/datatables/media/js/jquery.dataTables',
        'col-reorder-amd': '../bower_components/col-reorder-amd/media/js/ColReorder', 
		datatablesNetMin:'../bower_components/datatables.net/js/jquery.dataTables.min',
		datatablesNet:'../bower_components/datatables.net/js/jquery.dataTables', 
		'fileSaver':'../bower_components/file-saver/FileSaver',
	    //highcharts: '../bower_components/iids/components/highcharts-amd/js/highcharts.src',
		highstock: '../bower_components/iids/components/highcharts-amd/js/highstock.src',
		highChartExport: '../bower_components/iids/components/highcharts-amd/js/modules/exporting.src',
		accordian:'../library/ui-bootstrap-tpls-1.3.3.min',
		'openlayer': '../bower_components/openLayers/ol',
        'openlayer-debug': '../bower_components/openLayers/ol-debug',

		'jqueryImageZoom': '../bower_components/jqueryZoom/jquery.zoom.min',
		'chosen' : '../bower_components/chosen/chosen.jquery',
		'slimscroll' : '../bower_components/slimscroll/jquery.slimscroll.min',
		'multiselectdrpdwn' : '../bower_components/MultiSelect/multiple-select',
		'jqueryMultiSelect' : '../library/jquery-multiselect/jquery.multiselect',
        'angular-openlayer-directive':'../bower_components/angular-openlayers-directive/dist/angular-openlayers-directive',
		 'bootstrapmin': '../bower_components/bootstrap/bootstrap.min',
		 highcharts: '../bower_components/highcharts/highcharts',
         'highcharts3d': '../bower_components/highcharts/highcharts-3d',
         'highchartsNoData': '../bower_components/highcharts/modules/no-data-to-display',
         'jquery-ui': '../library/jquery-ui',
         'html2canvas': '../library/html2canvas',
         'canvas2image': '../library/canvas2image',
         'datatablesNetRowReorder':'../bower_components/datatables.net/js/dataTables.rowReorder.min', 
         'datatablesNetResponsive':'../bower_components/datatables.net/js/dataTables.responsive.min',
         'uiSwitch':'../bower_components/angular-ui-switch/angular-ui-switch.min'
    },
    map : {	
        'ge-bootstrap' : {
            'bootstrap/bootstrap-affix' : 'bootstrap-affix',
            'bootstrap/bootstrap-alert' : 'bootstrap-alert',
            'bootstrap/bootstrap-button' : 'bootstrap-button',
            'bootstrap/bootstrap-carousel' : 'bootstrap-carousel',
            'bootstrap/bootstrap-collapse' : 'bootstrap-collapse',
            'bootstrap/bootstrap-dropdown' : 'bootstrap-dropdown',
            'bootstrap/bootstrap-modal' : 'bootstrap-modal',
            'bootstrap/bootstrap-popover' : 'bootstrap-popover',
            'bootstrap/bootstrap-scrollspy' : 'bootstrap-scrollspy',
            'bootstrap/bootstrap-tab' : 'bootstrap-tab',
            'bootstrap/bootstrap-tooltip' : 'bootstrap-tooltip',
            'bootstrap/bootstrap-transition' : 'bootstrap-transition',
            'bootstrap/bootstrap-typeahead' : 'bootstrap-typeahead'
        }
    },
    priority: [
        'jquery',
        'angular',
        'angular-resource',
        'angular-route',
        'bootstrap'
    ],
    shim: {
        'angular': {
            deps: ['jquery'],
            exports: 'angular'
        },
        'angular-route': ['angular'],
        'angular-resource': ['angular', 'angular-route', 'angular-ui-router'],
        'angular-sanitize': ['angular'],
        'angular-mocks': {
            deps: ['angular', 'angular-route', 'angular-resource', 'angular-ui-router'],
            exports: 'mock'
        },
        'angular-ui-router': ['angular'],
        underscore: {
            exports: '_'
        },
        'px-datasource': {
            deps: ['angular', 'lodash']
        },
        'app': {
            deps: ['angular']
        },
        'bootstrap-popover' : [ 'jquery', 'bootstrap-tooltip' ],

    }
});
