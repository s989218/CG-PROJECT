define(['angular', '../../sample-module', 'jquery', 'datatablesNetMin', 'datatablesNet', 'multiselectdrpdwn', 'jqueryMultiSelect','datatablesNetRowReorder','datatablesNetResponsive'],
    function(angular, controllers, datatablesNetMin, datatablesNet, datatablesNetRowReorder, datatablesNetResponsive) {
        'use strict';
        controllers.controller('combinedAnalysisCtrl', ['CombinedAnalysisChartService', 'LoaderService', '$rootScope', '$scope', '$state', 'NetworkCallService', 'CreateHighChartService', '$timeout', '$q', '$http', function(CombinedAnalysisChartService, LoaderService, $rootScope, $scope, $state, NetworkCallService, CreateHighChartService, $timeout, $q, $http) {
            $('#container2,#country_chart').css('min-width', $('section').innerWidth() - 50);
            jQuery.fn.center = function() {
                this.css({
                    top: ($(window).outerHeight()) / 2,
                    left: ($(window).outerWidth()) / 2
                });
                return this;
            };
            $(".loading").center();

            function loaderOps(state) {
                LoaderService.loaderOps(state);
            }

            loaderOps(true);
            $scope.safeApply = function(fn) {
                $timeout(fn);
            }
            $scope.selected = 0;
            window.addEventListener('px-tab-changed', function(event) {
                var selectedTab = parseInt(event.target.selected);
                Polymer.dom().querySelector('px-tab-pages').selected = selectedTab;
                if (selectedTab === 0) {
                    $('.rstFltr').show()
                } else {
                    $('.rstFltr').hide()
                }
            });
            var yearQData = getYearQuarter();
            $scope.ibo_equipmentquarteryear = yearQData.ibo_equipmentquarteryear;
            $scope.ibo_equipmentyear = yearQData.ibo_equipmentyear;
            $scope.ibo_orderquarteryear = yearQData.ibo_orderquarteryear;
            $scope.currentYearQuarter = yearQData.currentYearQuarter;
            var chartData = [];
            
            $timeout(function() {
                if (!$rootScope.accountManager && !$rootScope.marketIndustry) {
                    $rootScope.getCombinedAnalysisDropdownsData();
                    $rootScope.combinedAnalysisSearchData();
                }
            }, 5000);
            
            if ($rootScope.accountManager || $rootScope.marketIndustry) {
                $timeout(function() {
                    $rootScope.getCombinedAnalysisDropdownsData();
                    $rootScope.combinedAnalysisSearchData();
                }, 5000);   
            }
            
            $rootScope.getCombinedAnalysisDropdownsData = function() {
                var item = {};
                item["businessSegment"] = $rootScope.businessSegment;
                item["accountManager"]  = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"]  = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
                NetworkCallService.getCombinedAnalysisDropdownData(JSON.stringify(item)).then(function(response) {
                    $scope.safeApply(function() {
                        $scope.regionDropdownBean = response.regionDescription;
                        $scope.countryDropdownBean = response.countryDescription;
                        $scope.segmentDropdownBean = response.segment;
                        $scope.tier3DropdownBean = response.tier3;
                        $scope.techDropdownBean = response.technologyDescription;
                        $scope.siteCustomerDropdownBean = response.siteCustomerDescription;
                        $scope.geDunsDropdownBean = response.geDunsName;
                        $scope.yearQuarterDropdownBean = response.yearQtrDescription;
                    });
                    setTimeout(function() {
                        $("select:not(#srSearch,#marketIndustryDropdownBean)").multipleSelect({
                            filter: true
                        });
                        $("select#primaryCountrySearch").multipleSelect({
                            filter: true,
                            selectAll: false
                        });
                    }, 200);

                    resizeAll();

                    $timeout(function() {
                        if (typeof(Storage) !== "undefined") {
                            // Code for localStorage/sessionStorage.
                            if (localStorage.getItem("siteFilterCode") !== null && localStorage.getItem("regionFilterCode") !== null && localStorage.getItem("countryFilterCode") !== null && localStorage.getItem("yearQuarterFilterCode") !== null ) {

                                $scope.siteFilterCode        = localStorage.getItem("siteFilterCode");
                                $scope.regionFilterCode      = localStorage.getItem("regionFilterCode");
                                $scope.countryFilterCode     = localStorage.getItem("countryFilterCode");
                                $scope.yearQuarterFilterCode = localStorage.getItem("yearQuarterFilterCode");

                                if(localStorage.getItem("tier3FilterCode")) {
                                    $scope.tier3FilterCode       = localStorage.getItem("tier3FilterCode");
                                }

                                $("#regionSearch").multipleSelect();
                                $("#regionSearch").multipleSelect('setSelects', [$scope.regionFilterCode]);

                                $("#countrySearch").multipleSelect();
                                $("#countrySearch").multipleSelect('setSelects', [$scope.countryFilterCode]);

                                $("#siteCustomerSearch").multipleSelect();
                                $("#siteCustomerSearch").multipleSelect('setSelects', [$scope.siteFilterCode]);

                                if($scope.yearQuarterFilterCode !== "CURRENT") {
                                    $("#yearQuarterSearch").multipleSelect();
                                    $("#yearQuarterSearch").multipleSelect('setSelects', JSON.parse($scope.yearQuarterFilterCode));    
                                }

                                if(localStorage.getItem("tier3FilterCode")) {
                                    $scope.tier3FilterCodeArray = _.filter($scope.tier3DropdownBean, function(item) { 
                                                                    return item.indexOf($scope.tier3FilterCode) !== -1; 
                                                                 });

                                    $("#tier3Search").multipleSelect();
                                    $("#tier3Search").multipleSelect('setSelects', $scope.tier3FilterCodeArray);
                                }

                                localStorage.removeItem('siteFilterCode');
                                localStorage.removeItem('regionFilterCode');
                                localStorage.removeItem('countryFilterCode');
                                localStorage.removeItem('yearQuarterFilterCode');
                                localStorage.removeItem('tier3FilterCode');

                                delete $scope.siteFilterCode;
                                delete $scope.regionFilterCode;
                                delete $scope.countryFilterCode;
                                delete $scope.yearQuarterFilterCode;
                                delete $scope.tier3FilterCode;
                                delete $scope.tier3FilterCodeArray;
                                
                                $rootScope.combinedAnalysisSearchData();
                            }
                        } else {
                            // Sorry! No Web Storage support..
                        }
                    });
                });
            }

            $('table[data-table-name="CA-Equipment"]').DataTable({
                "bPaginate": true,
                "bSort": true,
                "bFilter": true,
                "aLengthMenu": [
                    [10, 20, 50, 100, -1],
                    [10, 20, 50, 100, "All"]
                ],
                "iDisplayLength": 10,
                "bAutoWidth": false
            });

            $rootScope.combinedAnalysisSearchData = function() {
                loaderOps(true);
                $scope.caibo_equipmentquarteryear = "(" + $scope.ibo_equipmentquarteryear + ")";
                $scope.caibo_equipmentyear = "(" + $scope.ibo_equipmentyear + ")";
                $scope.caibo_orderquarteryear = "(" + $scope.ibo_orderquarteryear + ")";
                $scope.cacurrentYearQuarter = "(" + $scope.currentYearQuarter + ")";
                $scope.caserviceYearQuarter = "(All)";
                var jsonData = [],
                    item = {},
                    total = 0;

                item["regionDescription"] = ($("#regionSearch").val() === undefined || !$("#regionSearch").val()) ? "" : '^' + $("#regionSearch").val().join("$|^") + '$';
                item["countryDescription"] = ($("#countrySearch").val() === undefined || !$("#countrySearch").val()) ? "" : '^' + $("#countrySearch").val().join("$|^") + '$';
                item["siteCustomerDescription"] = ($("#siteCustomerSearch").val() === undefined || !$("#siteCustomerSearch").val()) ? "" : '^' + $("#siteCustomerSearch").val().join("$|^") + '$';
                item["technologyDescription"] = ($("#techSearch").val() === undefined || !$("#techSearch").val()) ? "" : '^' + $("#techSearch").val().join("$|^") + '$';
                item["segment"] = ($("#segmentSearch").val() === undefined || !$("#segmentSearch").val()) ? "" : '^' + $("#segmentSearch").val().join("$|^") + '$';
                item["geDunsName"] = ($("#geDunsSearch").val() === undefined || !$("#geDunsSearch").val()) ? "" : '^' + $("#geDunsSearch").val().join("$|^") + '$';
                item["tier3"] = ($("#tier3Search").val() === undefined || !$("#tier3Search").val()) ? "" : '^' + $("#tier3Search").val().join("$|^") + '$';
                item["serialNumber"] = $("#srSearch").val();
                item["yearQtrDescription"] = ($("#yearQuarterSearch").val() === undefined || !$("#yearQuarterSearch").val()) ? "" : '^' + $("#yearQuarterSearch").val().join("$|^") + '$';
                item["businessSegment"] = $rootScope.businessSegment;
                item["accountManager"]  = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"]  = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
                jsonData.push(item);

                $scope.searchItems = jsonData;

                NetworkCallService.getCombinedAnalysisMetricsData(jsonData).then(function(response) {
                    chartData = response.chart;
                    var temp, newVal;
                    for (var ct = 0; ct < chartData.length; ct++) {
                        if (chartData[ct].total >= 1000000) {
                            temp = chartData[ct].total;
                            if (chartData[ct].name === "IBO (Current Year)") {
                                newVal = temp / 1000;
                                chartData[ct].total = newVal;
                            } else {
                                newVal = temp / 1000000;
                                chartData[ct].total = newVal;
                            }
                            chartData[ct].dividend = 'M';
                            chartData[ct].y = parseFloat(chartData[ct].total);
                            chartData[ct].yDisplay = (parseFloat(chartData[ct].total)).toFixed(2);

                        } else if (chartData[ct].total >= 1000) {
                            temp = chartData[ct].total;
                            newVal = temp / 1000;
                            chartData[ct].total = newVal;
                            if (chartData[ct].name === "IBO (Current Year)") {
                                chartData[ct].dividend = 'M';
                            } else {
                                chartData[ct].dividend = 'K';
                            }
                            chartData[ct].y = parseFloat(chartData[ct].total);
                            chartData[ct].yDisplay = (parseFloat(chartData[ct].total)).toFixed(2);

                        } else {
                            if (chartData[ct].name === "IBO (Current Year)") {
                                chartData[ct].dividend = 'K';
                            } else {
                                chartData[ct].dividend = '';
                            }
                            chartData[ct].y = parseFloat(chartData[ct].total);
                            chartData[ct].yDisplay = (parseFloat(chartData[ct].total)).toFixed(2);


                        }
                        if ($("#yearQuarterSearch").val() !== null) {
                            chartData[ct].yearQuarter = "";
                        } else {
                            if (chartData[ct].name === 'IB') {
                                chartData[ct].yearQuarter = $scope.caibo_equipmentquarteryear;
                            } else if (chartData[ct].name === 'IBO') {
                                chartData[ct].yearQuarter = $scope.caibo_equipmentyear;
                            } else if (chartData[ct].name === 'Orders') {
                                chartData[ct].yearQuarter = $scope.caibo_orderquarteryear;
                            } else if (chartData[ct].name === 'DM' || chartData[ct].name === 'Outages') {
                                chartData[ct].yearQuarter = $scope.cacurrentYearQuarter;
                            } else if (chartData[ct].name === 'Service Request') {
                                chartData[ct].yearQuarter = $scope.caserviceYearQuarter;
                            }
                        }
                    }
                    for (var j = 0; j < chartData.length; j++) {
                        total += parseFloat(chartData[j].yDisplay);
                    }
                    if (total === 0) {
                        $('.regError').show(100).css('display', 'flex');
                        $('.regView').hide(100);
                    } else {
                        CombinedAnalysisChartService.createChart(chartData);
                        $('.regView').show(100);
                        $('.regError').hide(100);
                    }
                    $scope.searchFlag = null;
                    if ($("#regionSearch").val() !== null || $("#countrySearch").val() !== null || $("#siteCustomerSearch").val() !== null || $("#techSearch").val() !== null || $("#segmentSearch").val() !== null || $("#geDunsSearch").val() !== null || $("#tier3Search").val() !== null || $("#srSearch").val() !== '' || $("#yearQuarterSearch").val() !== null) {
                        if ($("#yearQuarterSearch").val() !== null) {
                            $scope.caibo_equipmentquarteryear = "";
                            $scope.caibo_equipmentyear = "";
                            $scope.caibo_orderquarteryear = "";
                            $scope.cacurrentYearQuarter = "";
                            $scope.caserviceYearQuarter = "";
                        }
                        $scope.searchFlag = true;
                    }
                    if ($scope.searchFlag === true) {
                        $('.combinedAnalysisTable').show();
                        $('.regionTableDiv').show();
                    } else {
                        $('.combinedAnalysisTable').hide();
                        $('.regionTableDiv').hide();
                    }
                    if ($scope.searchFlag === true) {
                        $scope.equipmentData = response.table[0].data;
                        $scope.ordersData = response.table[1].data;
                        $scope.dmData = response.table[2].data;
                        $scope.outageData = response.table[3].data;
                        $scope.serviceReqData = response.table[4].data;

                        $('table[data-table-name="CA-Equipment"]').dataTable().fnClearTable();
                        angular.forEach($scope.equipmentData, function(data) {
                            var newSum = '$' + data.sum + 'K';
                            $('table[data-table-name="CA-Equipment"]').dataTable().fnAddData([
                                data.region,
                                data.c_site_customer_name,
                                data.c_technology_desc_og,
                                data.c_gib_serial_number,
                                newSum,
                                data.c_unit_status_desc,
                                data.c_site_name_alias,
                                data.c_oem_location_desc,
                                data.c_site_customer_duns,
                                data.c_market_segment_desc,
                                data.c_site_customer_country
                            ], false);
                        });
                        $('table[data-table-name="CA-Equipment"]').dataTable().fnDraw(true);

                        $('table[data-table-name="CA-Orders"]').dataTable().fnClearTable();
                        angular.forEach($scope.ordersData, function(data) {
                            var newSum = '$' + data.n_order_val_op_rate + 'K';
                            $('table[data-table-name="CA-Orders"]').dataTable().fnAddData([
                                data.c_dts_region_name,
                                data.c_end_user_name,
                                data.pm_product_mapping,
                                newSum,
                                data.c_service_type_desc,
                                data.me_tier_4,
                                data.c_opportunity_id,
                                data.ge_duns_name,
                                data.sm_segment_mapping,
                                data.me_tier_3,
                                data.c_country_name
                            ], false);
                        });
                        $('table[data-table-name="CA-Orders"]').dataTable().fnDraw(true);

                        $('table[data-table-name="CA-DM"]').dataTable().fnClearTable();
                        angular.forEach($scope.dmData, function(data) {
                            var newSum = '$' + data.oppty_amount_usd + 'K';
                            $('table[data-table-name="CA-DM"]').dataTable().fnAddData([
                                data.primary_region,
                                data.site_cust_name,
                                data.ge_duns_name, //to be replaced with tech og description after mapping is done
                                data.oppty_external_id,
                                newSum,
                                data.forecast_category,
                                data.expected_order_date,
                                data.oppty_number,
                                data.technology_desc,
                                data.primary_industry,
                                data.business_tier_3,
                                data.primary_country
                            ], false);
                        });
                        $('table[data-table-name="CA-DM"]').dataTable().fnDraw(true);

                        $('table[data-table-name="CA-Outage"]').dataTable().fnClearTable();
                        angular.forEach($scope.outageData, function(data) {
                            $('table[data-table-name="CA-Outage"]').dataTable().fnAddData([
                                data.c_og_sales_region,
                                data.c_site_customer_name,
                                data.c_technology_desc_og,
                                data.c_gib_serial_number,
                                data.maint_level_desc,
                                data.c_event_status_desc,
                                data.d_event_date,
                                data.n_event_id,
                                data.ge_duns_name,
                                data.c_market_segment_desc,
                                data.c_site_customer_country
                            ], false);
                        });
                        $('table[data-table-name="CA-Outage"]').dataTable().fnDraw(true);

                        $('table[data-table-name="CA-ServiceReq"]').dataTable().fnClearTable();
                        angular.forEach($scope.serviceReqData, function(data) {
                            $('table[data-table-name="CA-ServiceReq"]').dataTable().fnAddData([
                                data.customer_name,
                                data.machine_technology_og,
                                data.current_type_of_issue,
                                data.state,
                                data.opened,
                                data.case_number,
                                data.ge_duns_name

                            ], false);
                        });
                        $('table[data-table-name="CA-ServiceReq"]').dataTable().fnDraw(true);
                    }
                    loaderOps(false); //added for development. to be removed once dev is done
                });
            }
            $scope.clearData = function() {
                loaderOps(true);
                $scope.safeApply(function() {
                    $scope.custChartExp = true;
                    $scope.custDataExp = true;
                });
                document.getElementById("srSearch").value = "";
                $('combinedanalysis-independent-filter').find('.ms-choice > span').html('');
                $('combinedanalysis-independent-filter').find('input[type="checkbox"]').attr('checked', false);
                $('combinedanalysis-independent-filter').find("select").val('')
                $('#depprimaryCountrySearch').empty();
                $('.regError').hide(100);
                $('.regView').show(100);
                $rootScope.combinedAnalysisSearchData();
                loaderOps(false);
            }

            /*Polymer Tab Initialization */
            var checkStatus = setInterval(function() {
                if (Polymer.dom().node.readyState === 'complete') {
                    Polymer.dom().querySelector('px-tab-pages').selected = 0;
                    Polymer.dom().querySelector('px-tab-set').selected = 0;
                    clearInterval(checkStatus);
                }
            }, 100);
            /* Default View */

            $scope.exportCharts = function(type) {
                CreateHighChartService.exportChartTech(type);
            };
            $scope.excelDownload = function(metrics) {
                var dataExport = {
                    'data': $scope.searchItems
                }
                download('/connect/fms/exportCombinedAnalytics/' + metrics, dataExport, 'CombinedAnalysis');
            };

            function download(url, data, defaultFileName) {
                var deferred = $q.defer();
                $http.post(url, data, {
                    responseType: "arraybuffer"
                }).success(
                    function(data, status, headers) {
                        var type = headers('Content-Type');
                        var disposition = headers('Content-Disposition');
                        if (disposition) {
                            var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                            if (match[1])
                                defaultFileName = match[1];
                        }
                        defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                        var blob = new Blob([data], {
                            type: type
                        });
                        saveAs(blob, defaultFileName);
                        deferred.resolve(defaultFileName);
                    }).error(function() {
                    var e;
                    deferred.reject(e);
                });
                return deferred.promise;
            }

            $scope.exportCharts = function(type) {
                CombinedAnalysisChartService.exportChart(type);
            };
        }]);
});