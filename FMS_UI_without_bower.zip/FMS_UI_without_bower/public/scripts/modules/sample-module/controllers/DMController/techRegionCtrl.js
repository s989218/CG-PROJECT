
define(['angular','../../sample-module','jquery', 'datatablesNetMin', 'datatablesNet', 'multiselectdrpdwn','jqueryMultiSelect'], 
function (angular,controllers) 
{
	'use strict';
	controllers.controller('DMTechnoRegionController', ['TechnologyRegionChart','TechnoRegionService','TopCustomerService','RegionChartService','LoaderService', '$rootScope','$scope','$state','NetworkCallService','DMTechnoRegionService','DMTableService','CreateHighChartService','$timeout','$http','$q', function (TechnologyRegionChart,TechnoRegionService,TopCustomerService, RegionChartService,LoaderService, $rootScope, $scope,$state,NetworkCallService,DMTechnoRegionService,DMTableService,CreateHighChartService,$timeout,$http,$q) 
    {	

		$scope.reg_Error = false;
		$scope.ctr_Error = false;
		var chart;
		$('#container2,#country_chart').css('min-width',$('section').innerWidth()-50);
		$('.backClass').click(function(){
			$state.go('NewMetrics');
		});
		jQuery.fn.center = function() {
			this.css({top: ($(window).outerHeight()) / 2,left: ($(window).outerWidth()) / 2});
			return this;
		};
		$(".loading").center();
		function loaderOps(state){
			LoaderService.loaderOps(state);
		}
		$scope.regionSelected = true;
		$('.errorIndicator').hide(100);
		loaderOps(true);
		$scope.safeApply =function(fn){
			$timeout(fn);
		}
		var defaultData = {};
		$scope.selected = 0;
		function checkParent(props){
			if(props.ngModel==='depSearch.regions'){
				if($scope.depSearch.regions.length > 0){
					$('select.dependentFilter[id="primaryCountrySearch"]').prop('disabled','false');
					$('select.dependentFilter[id="primaryCountrySearch"]').siblings().children().removeClass('disabled');
				}
				else{
					$('select.dependentFilter[id="primaryCountrySearch"]').prop('disabled','true');
					$('select.dependentFilter[id="primaryCountrySearch"]').siblings().children().addClass('disabled');
				}
			}

		}
		$scope.getCountries=function(){
			$('#depprimaryRegionSearch').removeClass('boxShadow');
			var country = $("select.dependentFilter[id='depprimaryRegionSearch']").val();
			var item = {};
			if(country!==null && country!=='Select Region'){
				item["regionName"]=country;
				item["type"]="dm";
				item["businessSegment"]=$rootScope.businessSegment;
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
				NetworkCallService.getDMCountry(JSON.stringify(item)).then(function(response){
					var selectOption='', countryName='';
					$timeout(function(){							
						$('.errorIndicator').hide(100);
						_.forEach(response, function(response){
							countryName = response.countryName;
							selectOption = selectOption + '<option value="'+countryName+'">'+countryName+'</option>'
						})
					})
					.then(function(){
						var scriptTag='<script>$("select#depprimaryCountrySearch").multipleSelect({filter: true, selectAll: false});</script>'
							$timeout(function(){
								/* Show Multiselect */
								$('#depprimaryCountrySearch').empty().append(selectOption).append(scriptTag);
								$('div.countrySelectBtn').show(100);
								$('select.dependentFilter[id="depprimaryCountrySearch"]').prop('disabled','false');
								$('select.dependentFilter[id="depprimaryCountrySearch"]').siblings().children().removeClass('disabled');
								$('button#placeboMultiSelect').hide(100);									
							});
					});
				});
			}
			else
			{
				$('select.dependentFilter[id="depprimaryCountrySearch"]').prop('disabled','true');
				$('select.dependentFilter[id="depprimaryCountrySearch"]').siblings().children().addClass('disabled');
				$timeout(function(){
					$scope.regionSelected = true;
				});
			}
		}
		function getSelectedValue(id){
			var selector = "select.dependentFilter[id='"+id+"']";
			if(id==='depprimaryRegionSearch' && $(selector).val() != null){
				return $(selector).val();
			}
			else
			{
				if($(selector).val()!==undefined){
					var values = [];
					_.forEach($(selector).val(), function(choice){
						values.push("^"+choice+"$");
					});
					return values.join("|");
				}
				else
					return "";
			}
		}

		var updateTopCustDatatable = function(response){
			$rootScope.testData = null;
			$rootScope.totalCount = null;
			var serviceData= null;
			var techRegionData=response.technologyDataBean;		
			var regionWithCount , chartId, dtData;
			if(arguments.length>1 && arguments[1] ===true){
				if(techRegionData.length>0){
					dtData = DMTechnoRegionService.processCountryTable(techRegionData);
					DMTableService.initTable(dtData['dataArr'],dtData['columns'],'DM-by-Top-Cust-Country-Data',dtData['regionCount']);
					serviceData = (DMTechnoRegionService.countryDataProcess(response.technologyDataBean));							
					chartId = 'country_chart';
					$scope.safeApply(function(){
						$scope.dep_testData = serviceData['testData'];
						$scope.dep_totalCount = serviceData['totalCount'];
					});
					$timeout(function(){
						$('#countryChart').outerWidth($('.ctrView').innerWidth());
						$('#country_chart').outerWidth($('#countryChart').innerWidth()-50);
						$scope.createColumnChart(serviceData['technology'],serviceData['highchartData'],chartId,serviceData['colorCode']);
					},500);
					$timeout(function(){
						$scope.safeApply(function(){
							$('.ctrError').hide(100);
							$('.ctrView').show(100);
							$scope.dep_custChartExp = true;
							$scope.dep_custDataExp = true;
						});
						$('#countryChart').height($('#country_chart').outerHeight()+50);
						$('#countryTable > #tableDivision').height($('#DM-by-Top-Cust-Country-Data_wrapper').outerHeight()+50);
						$('#countryChart > #techRegionChart').outerHeight($('#countryChart').height());
						$('#countryTable').outerHeight($('#countryTable > #tableDivision').outerHeight()+20);		
					},250);
					$('.countryTableDiv').show();
				}
				else{
					$('.ctrError').show(100).css('display','flex');
					$('.ctrView').hide(100);
				}
			}
			else{
				if(techRegionData.length>0){

					regionWithCount = DMTechnoRegionService.getRegionWithCount(techRegionData);
					serviceData = (DMTechnoRegionService.getTechnologyData($scope.techDropdownBean,techRegionData,regionWithCount));
					chartId = 'container2';
					$scope.safeApply(function(){
						$scope.testData = serviceData['testData'];
						$scope.totalCount = serviceData['totalCount'];
					});
					dtData = DMTechnoRegionService.processTable(techRegionData);
					DMTableService.initTable(dtData['dataArr'],dtData['columns'],'DM-by-Top-Cust-Data',dtData['regionCount']);
					$timeout(function(){
						$('#collapse3').height($('#container2').outerHeight()+50);
						$('#tableDivision').height($('#DM-by-Top-Cust-Data_wrapper').outerHeight()+50);
						$('#collapse3 > #techRegionChart').outerHeight($('#collapse3').height());
						$('#collapse4').outerHeight($('#collapse4 > #tableDivision').outerHeight()+20);
					},250);
					$scope.safeApply(function(){
						$('.regError').hide(100);
						$('.regView').show(100);
						$scope.custChartExp = true;
						$scope.custDataExp = true;
					});
					$scope.createColumnChart(serviceData['technology'],serviceData['chartData'],chartId,serviceData['colorCode']);
					$('#tableDiv').show();
				}
				else{
					$('.regError').show(100).css('display','flex');
					$('.regView').hide(100);
				}
			}
			loaderOps(false);					
		}
		$scope.resizeTable = function(){
			$('#tableDivision').height($('#DM-by-tech-reg-Data').height());
			$('#countryLevel > #tableDivision').height($('#DM-by-Top-Cust-Country-Data').height());
			$('#countryLevel > .headerDiv').width($('#DM-by-Top-Cust-Country-Data').outerWidth()+20)
		}
		window.addEventListener('px-tab-changed', function(event){
			var selectedTab = parseInt(event.target.selected);
			Polymer.dom().querySelector('px-tab-pages').selected = selectedTab;
			if(selectedTab===0){
				$('.rstFltr').show()
			}
			else{
				$('.rstFltr').hide()
			}
		});

		$rootScope.dep_dmTechnoCountrySearchData = function(){
			var jsonData = [];
			var item = {};
			item["primaryRegion"] = getSelectedValue('depprimaryRegionSearch');
			item["primaryCountry"]= getSelectedValue('depprimaryCountrySearch');
			item["forecastCategory"]= getSelectedValue('forcastCatSearch');
			item["businessTier3"]=getSelectedValue('businessTierSearch');
			item["cQtr"]= getSelectedValue('qtrSearch'); 
			item["accountName"]=getSelectedValue('custAccountNameSearch');
			item["riskPath"]=getSelectedValue('riskPathSearch');
			item["accountType"]=getSelectedValue('gAccTypeSearch');
			item["accountClass"]=getSelectedValue('gAccClassSearch');
			item["year"]=getSelectedValue('currentYearSearch');
			item["quarter"]=getSelectedValue('currentQtrSearch');
            item["stage"]=getSelectedValue('oSalesStageSearch');
			item["opptyExternalId"]=getSelectedValue('opptyExternalIdSearch');
			item["businessSegment"]=$rootScope.businessSegment;
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
			jsonData.push(item);
			if(!((item['primaryRegion'])==='') && (item['primaryRegion']).includes('undefined')===false && !((item['primaryRegion'])==='Select Region')){
				loaderOps(true);
				NetworkCallService.getDMMetricsCountryFilterData(jsonData).then(function(response){
					updateTopCustDatatable(response,true);
					resizeAll();
					$('#countryChart').height($('#country_chart').outerHeight()+50);					
					$('#countryChart > #techRegionChart').outerHeight($('#countryChart').height());					
					$('#countryTable, #countryChart').show();					
					loaderOps(false);
				});
			}
			else{
				$('#depprimaryRegionSearch').addClass("boxShadow");
				$('.errorIndicator').show(100);
			}
			// Raw data parameters
			$scope.regionDMRawData = [];
			$scope.countryDMRawData = [];
			$scope.flgRegionDMRawData = false;
			$scope.flgCountryDMRawData = false;
		}
        
        $timeout(function() {
            if (!$rootScope.accountManager && !$rootScope.marketIndustry) {
                $rootScope.dmTechnoRegionDropdownsData();
                $rootScope.getDMMetricsTechnoRegionData();
            }
        }, 5000);
         
        if ($rootScope.accountManager) {
            $timeout(function() {
                $rootScope.dmTechnoRegionDropdownsData();
                $rootScope.dmTechnoRegionSearchData();
            }, 5000);
        } else {
            $timeout(function() {
                $rootScope.dmTechnoRegionDropdownsData();
                $rootScope.getDMMetricsTechnoRegionData();
            }, 5000); 
        }
        
        $rootScope.dmTechnoRegionDropdownsData = function() {
            var item = {};
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            
            NetworkCallService.getDMDropdown(JSON.stringify(item)).then(function(response){
                $scope.safeApply(function(){
                    $scope.primaryregionDropdownBean = response.filter4; 	
                    $scope.primaryCountryDropdownBean = response.filter3;
                    $scope.forcastCatDropdownBean = response.filter1;
                    $scope.businessTierDropdownBean = response.filter2;
                    $scope.qtrDropdownBean = response.filter5;
                    $scope.accountNameDropdownBean = response.filter6;
                    $scope.riskPathDropdownBean = response.filter7;
                    $scope.accountTypeDropdownBean = response.filter9;
                    $scope.accountClassDropdownBean = response.filter8;
                    $scope.currentYearQtrDropdownBean = response.filter10;
                    $scope.opptySalesStageDropdownBean = response.filter11;
                    $scope.opptyexternalIdDropdownBean = response.filter12;
                    $scope.businessSegmentDropdownBean = response.businessSegment;
                });
                $timeout(function(){
                    $("select:not(#depprimaryRegionSearch,#depprimaryCountrySearch,#DM-by-Top-Cust-Data_length select,#marketIndustryDropdownBean)").multipleSelect({
                        filter: true
                    });
                    $("select#primaryCountrySearch").multipleSelect({
                        filter: true,
                        selectAll: false
                    });
                },200);						
                resizeAll();
            });
        }
        
		$rootScope.dmTechnoRegionSearchData = function(){
			loaderOps(true);
			var jsonData = [];
			var item = {};
			item["primaryRegion"] = ($("#primaryRegionSearch").val()===undefined||!$("#primaryRegionSearch").val())?"":'^'+$("#primaryRegionSearch").val().join("$|^")+'$';
			item["primaryCountry"]=($("#primaryCountrySearch").val()===undefined||!$("#primaryCountrySearch").val())?"":'^'+$("#primaryCountrySearch").val().join("$|^")+'$';
			item["forecastCategory"]= ($("#forcastCatSearch").val()===undefined||!$("#forcastCatSearch").val())?"":'^'+$("#forcastCatSearch").val().join("$|^")+'$';
			item["businessTier3"]=($("#businessTierSearch").val()===undefined||!$("#businessTierSearch").val())?"":'^'+$("#businessTierSearch").val().join("$|^")+'$';
			item["cQtr"]=($("#qtrSearch").val()===undefined||!$("#qtrSearch").val())?"":'^'+$("#qtrSearch").val().join("$|^")+'$';
			item["accountName"]=($("#custAccountNameSearch").val()===undefined||!$("#custAccountNameSearch").val())?"":'^'+$("#custAccountNameSearch").val().join("$|^")+'$';
			item["riskPath"]=($("#riskPathSearch").val()===undefined||!$("#riskPathSearch").val())?"":'^'+$("#riskPathSearch").val().join("$|^")+'$';
			item["accountType"]=($("#gAccTypeSearch").val()===undefined||!$("#gAccTypeSearch").val())?"":'^'+$("#gAccTypeSearch").val().join("$|^")+'$';
			item["accountClass"]=($("#gAccClassSearch").val()===undefined||!$("#gAccClassSearch").val())?"":'^'+$("#gAccClassSearch").val().join("$|^")+'$';
			item["year"]=($("#currentYearSearch").val()===undefined||!$("#currentYearSearch").val())?"":'^'+$("#currentYearSearch").val().join("$|^")+'$';
			item["quarter"]=($("#currentQtrSearch").val()===undefined||!$("#currentQtrSearch").val())?"":'^'+$("#currentQtrSearch").val().join("$|^")+'$';
            item["stage"]=($("#oSalesStageSearch").val()===undefined||!$("#oSalesStageSearch").val())?"":'^'+$("#oSalesStageSearch").val().join("$|^")+'$';
			item["opptyExternalId"]=($("#opptyExternalIdSearch").val()===undefined||!$("#opptyExternalIdSearch").val())?"":'^'+$("#opptyExternalIdSearch").val().join("$|^")+'$';
			item["businessSegment"]=$rootScope.businessSegment;
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
			jsonData.push(item);
			NetworkCallService.getDMMetricsFilterData(jsonData).then(function(response){							
				$scope.responseData=response;
				updateTopCustDatatable(response);
				resizeAll();
			});
			// Raw data parameters
			$scope.regionDMRawData = [];
			$scope.countryDMRawData = [];
			$scope.flgRegionDMRawData = false;
			$scope.flgCountryDMRawData = false;
		}
		function createDefaultChart(response){
			var techRegionData=response.technologyDataBean;		
			var techRegionChartData = DMTechnoRegionService.updateTechReg(techRegionData);						
			var dtData = DMTechnoRegionService.processTable(techRegionData);

			DMTableService.initTable(dtData['dataArr'],dtData['columns'],'DM-by-Top-Cust-Data',dtData['regionCount']);
			$timeout(function(){
				$('#collapse3').height($('#container2').outerHeight()+50);
				$('#tableDivision').height($('#DM-by-Top-Cust-Data_wrapper').outerHeight()+50);
				$('#collapse3 > #techRegionChart').outerHeight($('#collapse3').height());
				$('#collapse4').outerHeight($('#collapse4 > #tableDivision').outerHeight()+20);	
			},250);						
			$scope.createColumnChart(techRegionChartData['technology'],techRegionChartData['regionWithCount'],'container2',techRegionChartData['colorCode']);
			$('#tableDiv').show();
		}
		$scope.clearData = function(){
			loaderOps(true);
			$scope.safeApply(function(){
				$scope.custChartExp = true;
				$scope.custDataExp = true;
			});
			if(!defaultData['indep_filters'])
				NetworkCallService.getDMMetricsFilterData(TechnoRegionService.searchDataService()).then(function(response){
					defaultData['indep_filters'] = response;
					createDefaultChart(response);
				});
			else
			{
				createDefaultChart(defaultData['indep_filters']);
			}
			$('dm-independent-filter').find('.ms-choice > span').html('');
			$('dm-independent-filter').find('input[type="checkbox"]').attr('checked',false);
			$('dm-independent-filter').find("select").val('')
			$('#depprimaryCountrySearch').empty();
			$('.regError').hide(100);
			$('.regView').show(100);
			loaderOps(false);
			// Raw data parameters
			$scope.regionDMRawData = [];
			$scope.countryDMRawData = [];
			$scope.flgRegionDMRawData = false;
			$scope.flgCountryDMRawData = false;
		}
		$scope.dep_clearData = function(){
			$('dm-dependent-filter').find('.ms-choice > span').html('');
			$('dm-dependent-filter').find('input[type="checkbox"]').attr('checked',false);
			$('dm-dependent-filter').find("select").val('');
			$('#depprimaryCountrySearch').empty();
			$('#countryTable, #countryChart').hide();
			_.defer(function(){
				$('div.countrySelectBtn').hide(100);
				$('select.dependentFilter[id="depprimaryCountrySearch"]').prop('disabled','true');
				$('select.dependentFilter[id="depprimaryCountrySearch"]').siblings().children().addClass('disabled');
				$('button#placeboMultiSelect').show(100);	
				$('.ctrError').hide(100);
				$('.ctrView').show(100);
				$scope.dep_custChartExp = false;
				$scope.dep_custDataExp = false;
			});
			_.forEach(Object.keys($scope.depSearch), function(key){
				_.defer(function(){
					$scope[key] = null;
				});
			});
			$('#depprimaryRegionSearch').removeClass("boxShadow");
			$('.errorIndicator').hide();
			// Raw data parameters
			$scope.regionDMRawData = [];
			$scope.countryDMRawData = [];
			$scope.flgRegionDMRawData = false;
			$scope.flgCountryDMRawData = false;
		}


		/* Polymer Tab Initialization */
		var checkStatus = setInterval(function(){
			if(Polymer.dom().node.readyState==='complete'){
				Polymer.dom().querySelector('px-tab-pages').selected = 0;
				Polymer.dom().querySelector('px-tab-set').selected = 0;
				clearInterval(checkStatus);
			}
		},100);
        
        $rootScope.getDMMetricsTechnoRegionData = function() {
            /* Default View */
            NetworkCallService.getDMMetricsFilterData(DMTechnoRegionService.searchDataService()).then(function(response){
                createDefaultChart(response);
                $timeout(function(){
                    loaderOps(false);
                },500);
            });
        }
        
        $timeout(function(){
            $(document.body).off().on('change','#depprimaryRegionSearch',function(){
                $scope.getCountries();
            });
        },200);

		$scope.exportCharts = function(type) {
			$scope.exportChartOrder(type); 
		};
		$scope.excelDownload = function(id) {
			DMTableService.excelDownload(id); 
		};

		$scope.shwDMRawData = function (tableId, methodCall) {
			var jsonData = [];
			var item = {};
			item["primaryRegion"] = ($("#primaryRegionSearch").val()===undefined||!$("#primaryRegionSearch").val())?"":'^'+$("#primaryRegionSearch").val().join("$|^")+'$';
			item["primaryCountry"]=($("#primaryCountrySearch").val()===undefined||!$("#primaryCountrySearch").val())?"":'^'+$("#primaryCountrySearch").val().join("$|^")+'$';
			item["forecastCategory"]= ($("#forcastCatSearch").val()===undefined||!$("#forcastCatSearch").val())?"":'^'+$("#forcastCatSearch").val().join("$|^")+'$';
			item["businessTier3"]=($("#businessTierSearch").val()===undefined||!$("#businessTierSearch").val())?"":'^'+$("#businessTierSearch").val().join("$|^")+'$';
			item["cQtr"]=($("#qtrSearch").val()===undefined||!$("#qtrSearch").val())?"":'^'+$("#qtrSearch").val().join("$|^")+'$';
			item["accountName"]=($("#custAccountNameSearch").val()===undefined||!$("#custAccountNameSearch").val())?"":'^'+$("#custAccountNameSearch").val().join("$|^")+'$';
			item["riskPath"]=($("#riskPathSearch").val()===undefined||!$("#riskPathSearch").val())?"":'^'+$("#riskPathSearch").val().join("$|^")+'$';
			item["accountType"]=($("#gAccTypeSearch").val()===undefined||!$("#gAccTypeSearch").val())?"":'^'+$("#gAccTypeSearch").val().join("$|^")+'$';
			item["accountClass"]=($("#gAccClassSearch").val()===undefined||!$("#gAccClassSearch").val())?"":'^'+$("#gAccClassSearch").val().join("$|^")+'$';
			item["year"]=($("#currentYearSearch").val()===undefined||!$("#currentYearSearch").val())?"":'^'+$("#currentYearSearch").val().join("$|^")+'$';
			item["quarter"]=($("#currentQtrSearch").val()===undefined||!$("#currentQtrSearch").val())?"":'^'+$("#currentQtrSearch").val().join("$|^")+'$';
            item["stage"]=($("#oSalesStageSearch").val()===undefined||!$("#oSalesStageSearch").val())?"":'^'+$("#oSalesStageSearch").val().join("$|^")+'$';
			item["opptyExternalId"]=($("#opptyExternalIdSearch").val()===undefined||!$("#opptyExternalIdSearch").val())?"":'^'+$("#opptyExternalIdSearch").val().join("$|^")+'$';
			item["businessSegment"]=$rootScope.businessSegment;
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
			jsonData.push(item);

			if (methodCall === 'DMRegion') {
				if ($scope.regionDMRawData === undefined)
					$scope.regionDMRawData = [];

				$("#regDMRawData").attr('style', 'display: block');

				if ($scope.regionDMRawData === undefined || $scope.regionDMRawData.length === 0) {
					calDMRawService(jsonData, tableId, methodCall);
					$scope.flgRegionDMRawData = true;
				}

			} else {
				item["primaryRegion"] = getSelectedValue('depprimaryRegionSearch');
				item["primaryCountry"]= getSelectedValue('depprimaryCountrySearch');
				item["forecastCategory"]= getSelectedValue('forcastCatSearch');
				item["businessTier3"]=getSelectedValue('businessTierSearch');
				item["cQtr"]= getSelectedValue('qtrSearch'); 
				item["accountName"]=getSelectedValue('custAccountNameSearch');
				item["riskPath"]=getSelectedValue('riskPathSearch');
				item["accountType"]=getSelectedValue('gAccTypeSearch');
				item["accountClass"]=getSelectedValue('gAccClassSearch');
				item["year"]=getSelectedValue('currentYearSearch');
				item["quarter"]=getSelectedValue('currentQtrSearch');
                item["stage"]=getSelectedValue('oSalesStageSearch');
				item["opptyExternalId"]=getSelectedValue('opptyExternalIdSearch');
				item["businessSegment"]=$rootScope.businessSegment;
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";

				if((item['primaryRegion']) === '' || ((item['primaryRegion']).includes('undefined')===false && ((item['primaryRegion'])==='Select Region'))){
					$('#depprimaryRegionSearch').addClass("boxShadow");
					$('.errorIndicator').show(100);
					$("#flgCountryDMCollapse").attr("aria-expanded","false");
					$scope.flgCountryDMRawData = false;
					return false;
				}
				if ($scope.countryDMRawData === undefined)
					$scope.countryDMRawData = [];

				$("#cntryDMRawData").attr('style', 'display: block');

				if ($scope.countryDMRawData === undefined || $scope.countryDMRawData.length === 0) {
					calDMRawService(jsonData, tableId, methodCall);
					$scope.flgCountryDMRawData = true;
				}
			}
		};

		function calDMRawService (jsonData, tableId, methodCall) {
			loaderOps(true);
			$http.post("connect/fms/getRawDataIBOPage/"+"dmTechReg",JSON.stringify({"data":jsonData})).then(function(response){
				$scope.dmColumnHeaders = response.data.DMColumnHeaders;
				$scope.rawDMData = response.data.DMTechRawData;

				if (methodCall === 'DMRegion')
					$scope.regionDMRawData = $scope.rawDMData;
				else
					$scope.countryDMRawData = $scope.rawDMData;

				if ($.fn.DataTable.isDataTable( '#'+tableId ) ) {
					$('#'+tableId).dataTable().api().clear().draw();
					$('#'+tableId).dataTable().api().destroy();
					$('#'+tableId).empty(); 
				}

				$('#'+tableId).DataTable({
					data: $scope.rawDMData,
					"sPaginationType": "simple_numbers",
					"bFilter":true, 
					"retrieve": true, 
					"scrollX": false,
					"paging": true,
					columns:_.sortBy($scope.dmColumnHeaders,'row_id')

				});

				loaderOps(false);
			});
		}

		$scope.DMRawDataExcelDownload = function(methodCall) {
			var jsonData = [];
			var item = {};
			var fileName = "DM Technology data";

			item["primaryRegion"] = ($("#primaryRegionSearch").val()===undefined||!$("#primaryRegionSearch").val())?"":'^'+$("#primaryRegionSearch").val().join("$|^")+'$';
			item["primaryCountry"]=($("#primaryCountrySearch").val()===undefined||!$("#primaryCountrySearch").val())?"":'^'+$("#primaryCountrySearch").val().join("$|^")+'$';
			item["forecastCategory"]= ($("#forcastCatSearch").val()===undefined||!$("#forcastCatSearch").val())?"":'^'+$("#forcastCatSearch").val().join("$|^")+'$';
			item["businessTier3"]=($("#businessTierSearch").val()===undefined||!$("#businessTierSearch").val())?"":'^'+$("#businessTierSearch").val().join("$|^")+'$';
			item["cQtr"]=($("#qtrSearch").val()===undefined||!$("#qtrSearch").val())?"":'^'+$("#qtrSearch").val().join("$|^")+'$';
			item["accountName"]=($("#custAccountNameSearch").val()===undefined||!$("#custAccountNameSearch").val())?"":'^'+$("#custAccountNameSearch").val().join("$|^")+'$';
			item["riskPath"]=($("#riskPathSearch").val()===undefined||!$("#riskPathSearch").val())?"":'^'+$("#riskPathSearch").val().join("$|^")+'$';
			item["accountType"]=($("#gAccTypeSearch").val()===undefined||!$("#gAccTypeSearch").val())?"":'^'+$("#gAccTypeSearch").val().join("$|^")+'$';
			item["accountClass"]=($("#gAccClassSearch").val()===undefined||!$("#gAccClassSearch").val())?"":'^'+$("#gAccClassSearch").val().join("$|^")+'$';
			item["year"]=($("#currentYearSearch").val()===undefined||!$("#currentYearSearch").val())?"":'^'+$("#currentYearSearch").val().join("$|^")+'$';
			item["quarter"]=($("#currentQtrSearch").val()===undefined||!$("#currentQtrSearch").val())?"":'^'+$("#currentQtrSearch").val().join("$|^")+'$';
            item["stage"]=($("#oSalesStageSearch").val()===undefined||!$("#oSalesStageSearch").val())?"":'^'+$("#oSalesStageSearch").val().join("$|^")+'$';
			item["opptyExternalId"]=($("#opptyExternalIdSearch").val()===undefined||!$("#opptyExternalIdSearch").val())?"":'^'+$("#opptyExternalIdSearch").val().join("$|^")+'$';
			item["businessSegment"]=$rootScope.businessSegment;
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
			if (methodCall === 'DMCountry') {
				item["primaryRegion"] = getSelectedValue('depprimaryRegionSearch');
				item["primaryCountry"]= getSelectedValue('depprimaryCountrySearch');
				item["forecastCategory"]= getSelectedValue('forcastCatSearch');
				item["businessTier3"]=getSelectedValue('businessTierSearch');
				item["cQtr"]= getSelectedValue('qtrSearch'); 
				item["accountName"]=getSelectedValue('custAccountNameSearch');
				item["riskPath"]=getSelectedValue('riskPathSearch');
				item["accountType"]=getSelectedValue('gAccTypeSearch');
				item["accountClass"]=getSelectedValue('gAccClassSearch');
				item["year"]=getSelectedValue('currentYearSearch');
				item["quarter"]=getSelectedValue('currentQtrSearch');
                item["stage"]=getSelectedValue('oSalesStageSearch');
				item["opptyExternalId"]=getSelectedValue('opptyExternalIdSearch');
				item["businessSegment"]=$rootScope.businessSegment;
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
			}
			jsonData.push(item);
			download("/connect/fms/exportRawDataMetrics/" + "dmTechReg/" + fileName, jsonData, fileName);
		};

		function download(url,data ,defaultFileName) {
			var deferred = $q.defer();
			$http.post(url,JSON.stringify({"data":data}), { responseType: "arraybuffer" }).success(
					function (data, status, headers) {
						var type = headers('Content-Type');
						var disposition = headers('Content-Disposition');
						if (disposition) {
							var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
							if (match[1])
								defaultFileName = match[1];
						}
						defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
						var blob = new Blob([data], { type: type });
						saveAs(blob, defaultFileName);
						deferred.resolve(defaultFileName);                    
					}).error(function () {
						var e ;
						deferred.reject(e);
					});
			return deferred.promise;
		};

		$scope.createColumnChart = function(xSeries,ySeries,id,chartColors,state)
		{
			if(!state)
				state = null;
			Highcharts.setOptions({
				global: {
					useUTC: false,

				},
				lang: {
					decimalPoint: '.',
					thousandsSep: ','
				}
			});
			chart= new Highcharts.Chart({
				chart: {
					renderTo: id,
					type: 'column',
					events: {
						click: function () {
							if(state!==null)
								$state.go(state);
						}
					}
				},
				title: {
					text:''
				},
				colors: chartColors, 
				xAxis: {
					 labels: {
	                        rotation: -45,
	                        step: 1
	                    },
					categories: xSeries
				},
				yAxis: {
					min: 0,
					title: {
						text: '$K'
					}
				},
				tooltip: {
					pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>${point.y:,.0f}K</b>({point.percentage:.2f}%)<br/>',
					shared: true
				},
				legend: {
					itemStyle: {
						color: 'black',
						fontWeight: 'normal',
						fontSize: '12px',
					}
				},
				plotOptions: {
					series: {
						stacking: 'normal',
						borderWidth:0,
						point: {
							events: {
								click: function () {
									$scope.refreshDMMatrics(this.series.name, this.category, id);

								}
							}
						}
					}
				},
				credits: {
					enabled: false
				},
				series: ySeries
			});
		};


		$scope.refreshDMMatrics = function(name, category, id) {
			if(id === 'container2'){
				$('dm-independent-filter').find('.primaryRegionSearch .ms-choice > span').html(category);
				$('dm-independent-filter').find('.primaryRegionSearch input[value="'+category+'"]').attr('checked',true);
				$('dm-independent-filter').find("#primaryRegionSearch").val(category); 
				$('dm-independent-filter').find("#primaryRegionSearch").multipleSelect("refresh");
				$rootScope.dmTechnoRegionSearchData();
			} else if(id === 'country_chart'){
				$('dm-dependent-filter').find('.depprimaryCountrySearch .ms-choice > span').html(category);
				$('dm-dependent-filter').find('.depprimaryCountrySearch input[value="'+category+'"]').attr('checked',true);
				$('dm-dependent-filter').find("#depprimaryCountrySearch").val(category);
				$('dm-dependent-filter').find("#depprimaryCountrySearch").multipleSelect("refresh");
				$rootScope.dep_dmTechnoCountrySearchData();
			}
		}

		$scope.exportChartOrder = function(type){
			if(type === 'JPEG')
			{
				chart.exportChart({type: 'image/jpeg', filename: 'Techno Region'}, {subtitle: {text:''}});
			}
			if(type === 'XLS'){
				chart.exportChart({type: 'application/vnd.ms-excel', filename: 'my-excel'}, {subtitle: {text:''}});
			}
		}
		
	 }]);
});