define(['angular', '../sample-module','jquery','multiselectdrpdwn','jqueryMultiSelect','datatablesNet'], function(angular, controllers, jquery,multiselectdrpdwn,jqueryMultiSelect,datatablesNet) {
    'use strict';
    controllers.controller('DocumentsCtrl', ['$scope', '$http', '$q', '$timeout', '$location', '$state', '$rootScope', 'AdminDataNetworkService', function($scope, $http, $q, $timeout, $location, $state, $rootScope, AdminDataNetworkService) {

        $scope.adminLoader = true;
        $scope.documentData = {};

        var modalList = document.getElementById('addDocumentDataModal');
        var span = document.getElementsByClassName("addDocumentClose")[0];

        var modalAlert = document.getElementById('deleteDocumentAlertModal');
        var spanAlert = document.getElementsByClassName("deleteDocumentClose")[0];

        span.onclick = function(event) {
            if ($scope.successMsg === true) {
                $scope.adminLoader = true;
                $scope.loadDocumentsData();
                $scope.successMsg = false;
            }

            if ($scope.fnAddDocument === true) {
                $scope.resetDocumentData();
            }

            modalList.style.display = "none";
        }

        spanAlert.onclick = function(event) {
            $timeout(function() {
                $scope.successMsg = false;
                modalAlert.style.display = "none";
            }, 100);
        }

        window.onclick = function(event) {
            if (event.target === modalList) {
                if ($scope.successMsg === true) {
                    $scope.adminLoader = true;
                    $scope.loadDocumentsData();
                    $scope.successMsg = false;
                }

                if ($scope.fnAddDocument === true) {
                    $scope.resetDocumentData();
                }

                modalList.style.display = "none";
            }

            if (event.target === modalAlert) {
                $timeout(function() {
                    $scope.successMsg = false;
                    modalAlert.style.display = "none";
                }, 100);
            }
        }

        var dataTable;
        $scope.loadDocumentsData = function() {
            if ($.fn.DataTable.isDataTable('#documents')) {
                $("#documents").dataTable().api().clear().draw();
                $("#documents").dataTable().api().destroy();
                $('#documents').empty();
            }

            $scope.userData = {};
            $scope.userData['userSSO'] = $rootScope.userSSO;

            AdminDataNetworkService.getAllUserRolesData(JSON.stringify($scope.userData)).then(function(response) {
                $scope.objDocumentsRoleData = response.AllRoles;
                
                $timeout(function (){
                    $("select.multiSelect").multipleSelect({
                        filter: true
                    });
                },200);
            });

            AdminDataNetworkService.getAllDocuments(JSON.stringify($scope.userData)).then(function(response) {
                $scope.objDocumentsData        = response;
                $scope.documentData.fileAccess = 9;
                
                dataTable = $('#documents').DataTable({
                    rowReorder: {
                        selector: 'td:nth-child(2)'
                    },
                    responsive: true,
                    "order": [],
                    autoWidth: false,
                    data: $scope.objDocumentsData,
                    "columnDefs": [{
                            "targets": [4],
                            "visible": false,
                            "searchable": false
                        },
                        {
                            className: "dt-center",
                            "targets": [2, 3, 5]
                        },
                        {
                            className: "dt-left",
                            "targets": [0, 1]
                        }
                    ],
                    "columns": [{
                            data: "filename",
                            title: "Flie Name",
                            width: "30%"
                        },
                        {
                            data: "description",
                            title: "Description",
                            width: "30%"
                        },
                        {
                            data: "role_name",
                            title: "Assigned To (Roles)",
                            width: "10%"
                        },
                        {
                            data: "uploaded_by",
                            title: "Uploaded By",
                            width: "10%"
                        },
                        {
                            data: "id",
                            title: "File ID"
                        },
                        {
                            title: "Actions",
                            "bSortable": false,
                            "bSearchable": false,
                            width: "10%",
                            mRender: function(data, type, row) {
                                return '<a class="table-delete" title="Delete" data-id="' + row.document_id + '"><i class="fa fa-trash-o fa-2x" aria-hidden="true"></i></a>'
                            }
                        }
                    ]
                });

                $('body #documents tbody').on('click', 'a.table-delete', function() {
                    
                    var current_row = $(this).parents('tr');
                    if (current_row.hasClass('child')) {
                        current_row = current_row.prev();
                    }
                    var data = dataTable.row(current_row).data();
                    
                    $scope.deleteDocumentID     = data.id;
                    $scope.deleteDocumentSSO    = $rootScope.userSSO;

                    modalAlert.style.display = "block";
                    
                    $("#oDeleteDocument").prop("disabled", false);
                    $("#oDeleteDocument").css("background", "#22A2E3");
                });

                $scope.adminLoader = false;
            });
        }

        $scope.loadDocumentsData();

        $scope.addDocument = function() {
            $scope.successMsg = false;
            $scope.fnAddDocument = true;

            modalList.style.display = "block";
            $scope.resetDocumentData();
        }

        $scope.closeAlertBox = function() {
            $scope.successMsg = false;
            modalAlert.style.display = "none";
        }

        $scope.deleteDocumentData = function() {
            $scope.successMsg = false;
            $scope.failureMsg = false;

            if ($scope.deleteDocumentID === "" && $scope.deleteDocumentSSO === "") {
                $scope.successMsg = false;
                $scope.failureMsg = true;
                $scope.failureMessage = "Something went wrong! Please try again later."
            } else {
                $scope.documentData = {};
                $scope.documentData['userSSO'] = $scope.deleteDocumentSSO;
                $scope.documentData['fileId']  = $scope.deleteDocumentID;

                AdminDataNetworkService.deleteDocumentsData(JSON.stringify($scope.documentData)).then(function(response) {
                    $rootScope.safeApply(function() {
                        if (response === "SUCCESS") {
                            $scope.successMsg = true;
                            $scope.failureMsg = false;
                            $scope.successMessage = "Document Deleted Successfully.";

                            $scope.loadDocumentsData();
                        } else if (response === "FAILURE") {
                            $scope.successMsg = false;
                            $scope.failureMsg = true;
                            $scope.failureMessage = "Something went wrong! Please try again later.";
                        } else {
                            $scope.successMsg = false;
                            $scope.failureMsg = true;
                            $scope.failureMessage = "You are not authorized to delete this document.";
                        }

                        $("#oDeleteDocument").prop("disabled", true);
                        $("#oDeleteDocument").css("background", "#C0C0C0");
                        
                        $scope.deleteDocumentID  = "";
                        $scope.deleteDocumentSSO = "";
                    });
                });
            }
        }

        $scope.saveDocumentData = function(status) {
            $scope.successMsg = false;
            $scope.failureMsg = false;
            
            var file, fileName, index, strSubString;
            file = $scope.documentData['file'];
            
            if (!file) {
                $scope.documentData['file'] = null;
            } else {
                fileName     = $scope.documentData['file'].name;
                index        = fileName.lastIndexOf(".");
                strSubString = fileName.substring(index, fileName.length);
            }

            if ($('#aDocumentDescription').val().trim() === "") {
                $scope.documentData['fileDescription'] = null;
            } else {
                $scope.documentData['fileDescription'] = $('#aDocumentDescription').val().trim();
            }

            $timeout(function() {
                $scope.failureMsg = false;
            }, 5000);

            var dataReg      = /^[a-zA-Z][a-zA-Z0-9\'\s]/;
            if ($scope.documentData['file'] === null) {
                $scope.successMsg     = false;
                $scope.failureMsg     = true;
                $scope.failureMessage = "Please select file to upload!"
            } else if (strSubString !== '.pdf') {
                $scope.successMsg     = false;
                $scope.failureMsg     = true;
                $scope.failureMessage = "Please choose .pdf file!"
            } else if ($scope.documentData['fileDescription'] === null || !dataReg.test($scope.documentData['fileDescription'])) {
                $scope.successMsg     = false;
                $scope.failureMsg     = true;
                $scope.failureMessage = "Please enter valid document description"
            } else {
                $scope.documentData['userSSO']    = $rootScope.userSSO;
                $scope.documentData['fileAccess'] = $scope.documentData.fileAccess;
                
                var uploadUrl = "connect/fms/uploadDocuments";
                $scope.uploadDocumentData(file, uploadUrl, $scope.documentData);
                $scope.documentData.file = null;
            }
        };
        
        $scope.uploadDocumentData = function(file, uploadUrl, documentDataObj) {
                var fd = new FormData();
                fd.append('file', file);
                fd.append('fileDescription', documentDataObj.fileDescription);
                fd.append('userSSO', documentDataObj.userSSO);
                fd.append('fileAccess', documentDataObj.fileAccess);

                $.ajax({
                    url: uploadUrl,
                    data: fd,
                    cache: false,
                    processData: false,
                    contentType: false,
                    type: 'POST',
                    success: function(data, status, req) {
                        if (req.responseText === "SUCCESS") {
                            $rootScope.safeApply(function() {
                                $timeout(function() {
                                    $scope.successMsg = true;
                                    $scope.failureMsg = false;

                                    $scope.successMessage = "Added Successfully."

                                    $scope.resetDocumentData();
                                    $scope.loadDocumentsData();
                                }, 200);
                            });
                        } else {
                            $rootScope.safeApply(function() {
                                $timeout(function() {
                                    $scope.successMsg = false;
                                    $scope.failureMsg = true;
                                    $scope.failureMessage = "Something went wrong! Please try again later."

                                    $scope.resetDocumentData();
                                }, 200);
                            });
                        }
                    },
                    error: function(req, status, error) {
                        $rootScope.safeApply(function() {
                            $timeout(function() {
                                $scope.successMsg = false;
                                $scope.failureMsg = true;
                                $scope.failureMessage = "Something went wrong! Please try again later."

                                $scope.resetDocumentData();
                            }, 200);
                        });
                    }
                });
        }

        $scope.resetDocumentData = function() {
            angular.element("input[type='file']").val(null);
            $('#aDocumentDescription').val('');
            
            $scope.documentData.file       = null;
            $scope.documentData.fileAccess = 9;

            $("input").removeAttr("invalid");
            $("div").removeClass("label-is-floating is-invalid");
        }

        $scope.showDocumentsFiltersToggle = function(filterKey, showFilter) {
            if ($('.kd' + filterKey + 'Filter').is(':visible')) {
                $('.kd' + filterKey + 'Filter').slideUp(200);
                $scope[showFilter] = false;
            } else {
                $scope[showFilter] = true;
                $('.kd' + filterKey + 'Filter').slideDown(200);
            }
        }
    }]);
});