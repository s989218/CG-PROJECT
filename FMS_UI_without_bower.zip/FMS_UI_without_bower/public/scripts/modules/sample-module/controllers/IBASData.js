define(['angular', '../sample-module', 'jquery', 'datatablesNetMin', 'datatablesNet', 'bootstrap-popover', 'fileSaver', 'datatablesNetResponsive', 'datatablesNetRowReorder'], function(angular, controllers) {
    'use strict';
    controllers.controller('updateIBASDataCtrl', ['$scope', '$rootScope', '$http', '$location', '$state', '$q', '$timeout', 'fileUpload', function($scope, $rootScope, $http, $location, $state, $q, $timeout, fileUpload) {

        var deferredAbort;

        jQuery.fn.center = function() {
            this.css({
                top: ($(window).outerHeight()) / 2,
                left: ($(window).outerWidth()) / 2
            });
            return this;
        };
        
        $scope.flag = true;
        $scope.selectAll = false;
        $scope.updateSuccess = false;
        $scope.updateFailure = false;
        $rootScope.showUploadOption = false;
        $(".overlay").css("height", $(document).height());
        $(".loading").center();
        $(".loading").show();
        $(".overlay").show();

        var historyModal = document.getElementById('partsHistoryDataModal');
        var historySpan = document.getElementsByClassName("partsHistoryClose")[0];

        var modalAlert = document.getElementById('partsDataAlertModal');
        var spanAlert = document.getElementsByClassName("partsDataAlertClose")[0];

        historySpan.onclick = function() {
            historyModal.style.display = "none";
        }

        spanAlert.onclick = function(event) {
            modalAlert.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target === modalAlert) {
                modalAlert.style.display = "none";
            }

            if (event.target === historyModal) {
                historyModal.style.display = "none";
            }
        }

        $("body").on("change", "#checkAll", function() {
            var checkSelectAll = $('.popover .inline .showHideTitle input[type="checkbox"]').is(":checked");
            if (checkSelectAll === true) {
                $('.popover-content .innerShowHideTitle input[type="checkbox"]').prop('checked', true);
                $scope.selectAll = true;
            } else {
                $scope.selectAll = false;
                $('.popover-content .innerShowHideTitle input[type="checkbox"]').prop('checked', false);
                $('.popover-content .innerShowHideTitle input[type="checkbox"]').each(function(i) {
                    if (i < 16) {
                        $(this).prop('checked', true);
                    }
                });
            }
            $scope.$apply();
            resizeAll();
        });

        $scope.hideUpload = function(objButton) {
            $rootScope.mappingParam = objButton;
            if ($scope.showUploadOption) {
                $scope.showUploadOption = false;
                $rootScope.uploadMessage = "";
                angular.element("input[type='file']").val(null);
                $scope.myFile = null;
            } else {
                $scope.showUploadOption = true;
            }
        }

        $scope.uploadFile = function() {
            $rootScope.uploadStatus = "IN-PROGRESS";
            var file;
            file = $scope.myFile;

            if (file) {

                var filename = file.name;
                var index = filename.lastIndexOf(".");
                var strsubstring = filename.substring(index, filename.length);

                if (($rootScope.mappingParam === "GeDunsName" || $rootScope.mappingParam === "IboDataName") && strsubstring !== '.csv') {
                    $rootScope.safeApply(function() {
                        $timeout(function() {
                            $('.uploadMessage').removeClass("successMsg");
                            $('.uploadMessage').addClass("failureMsg");
                            $rootScope.uploadMessage = 'Please choose .csv file';
                        }, 200);
                        $rootScope.uploadStatus = true;
                    });
                } else {
                    var uploadUrl;
                    if ($rootScope.mappingParam === "GeDunsName") {
                        uploadUrl = "connect/fms/importCSV";
                    } else if ($rootScope.mappingParam === "IboDataName") {
                        uploadUrl = "connect/fms/importIBOData";
                    }
                    
                    $('.uploadMessage').removeClass("failureMsg");
                    $('.uploadMessage').addClass("successMsg");
                    $timeout(function() {
                        deferredAbort.resolve("User cancelled");
                        $rootScope.uploadStatus = "SUCCESS";
                    }, 60000);

                    $scope.uploadFileToUrl(file, uploadUrl)
                        .then(function(data) {
                            if (data === "SUCCESS") {
                                $rootScope.safeApply(function() {
                                    $timeout(function() {
                                        $('.uploadMessage').addClass("successMsg");
                                        $('.uploadMessage').removeClass("failureMsg");
                                        $rootScope.uploadMessage = "Upload Successful!";
                                        $rootScope.getOrdersYears();
                                        angular.element("input[type='file']").val(null);
                                    }, 200);
                                    $rootScope.uploadStatus = true;
                                });
                            } else {
                                if ($rootScope.uploadStatus === "IN-PROGRESS") {
                                    $rootScope.safeApply(function() {
                                        $timeout(function() {
                                            $('.uploadMessage').removeClass("failureMsg");
                                            $('.uploadMessage').addClass("successMsg");
                                        }, 200);
                                        $rootScope.uploadStatus = "IN-PROGRESS";
                                    });
                                } else if ($rootScope.uploadStatus === "SUCCESS") {
                                    $rootScope.safeApply(function() {
                                        $timeout(function() {
                                            $('.uploadMessage').removeClass("failureMsg");
                                            $('.uploadMessage').addClass("successMsg");
                                        }, 200);
                                        $rootScope.uploadStatus = "SUCCESS";
                                    });
                                } else {
                                    $rootScope.safeApply(function() {
                                        $timeout(function() {
                                            $('.uploadMessage').removeClass("successMsg");
                                            $('.uploadMessage').addClass("failureMsg");
                                            angular.element("input[type='file']").val(null);
                                        }, 200);
                                        $rootScope.uploadStatus = "FAILURE";
                                    });
                                }
                            }
                        }, function(error) {
                            if ($rootScope.uploadStatus === "IN-PROGRESS") {
                                $rootScope.safeApply(function() {
                                    $timeout(function() {
                                        $('.uploadMessage').removeClass("failureMsg");
                                        $('.uploadMessage').addClass("successMsg");
                                    }, 200);
                                    $rootScope.uploadStatus = "IN-PROGRESS";
                                });
                            } else {
                                $rootScope.safeApply(function() {
                                    $timeout(function() {
                                        $('.uploadMessage').removeClass("successMsg");
                                        $('.uploadMessage').addClass("failureMsg");
                                        angular.element("input[type='file']").val(null);
                                    }, 200);
                                    $rootScope.uploadStatus = "FAILURE";
                                });
                            }
                        }).finally(function() {
                            $scope.myFile = null;
                        });
                }
            } else {
                $('.uploadMessage').removeClass("successMsg");
                $('.uploadMessage').addClass("failureMsg");
                $rootScope.uploadMessageOrders = "Please select file to upload!";
            }
        };

        $scope.uploadFileToUrl = function(file, uploadUrl) {

            deferredAbort = $q.defer();

            var fd = new FormData();
            fd.append('file', file);
            fd.append('mappingParam', $rootScope.mappingParam);
            fd.append('userSSO', $rootScope.userSSO);

            var startTime = (new Date()).getTime();

            $scope.FileUploadStatus = 'Request submitted';

            $http.post(uploadUrl, fd, {
                    withCredentials: true,
                    headers: {
                        'Content-Type': undefined
                    },
                    transformRequest: angular.identity,
                    timeout: deferredAbort.promise
                })
                .success(function(data, status, headers, config) {
                    var endTime = (new Date()).getTime();
                    $scope.FileUploadStatus = 'Request response returned after ' + (endTime - startTime) + ' msec.';
                    deferredAbort.resolve(data);
                })
                .error(function(err, status) {
                    var endTime = (new Date()).getTime();
                    if (status === 0) {
                        $scope.FileUploadStatus = 'Request timed out after ' + (endTime - startTime) + ' msec.';
                        $rootScope.uploadStatus = "FAILURE";
                    } else {
                        $scope.FileUploadStatus = 'Request returned with error after ' + (endTime - startTime) + ' msec.';
                        //      					$rootScope.uploadStatus = "IN-PROGRESS";
                    }

                    deferredAbort.reject({
                        msg: err
                    });
                });

            return deferredAbort.promise;
        }

        $('input[name=myFile]').change(function() {
            $rootScope.uploadMessage = "";
        });

        $scope.closeDiv = function() {
            $rootScope.uploadStatus = false;
            $scope.showUploadOption = false;
            angular.element("input[type='file']").val(null);
            $scope.myFile = null;
            $rootScope.uploadMessage = "";
        }

        $scope.columnTitleList = [];

        $http.get("connect/fms/getChooseColumns").then(function(response) {
            $scope.equipmentColumns = response.data.EquipmentColumns;
            for (var cols = 0; cols < $scope.equipmentColumns.length; cols++) {
                if ($scope.equipmentColumns[cols].active === "Y") {
                    var item = {};
                    item["index"] = $scope.equipmentColumns[cols].displayOrder - 1;
                    item["title"] = $scope.equipmentColumns[cols].displayName;
                    item["name"] = $scope.equipmentColumns[cols].columnName;
                    if ($scope.equipmentColumns[cols].checked === 1)
                        item["checked"] = "YES";
                    else
                        item["checked"] = "NO";
                    $scope.columnTitleList.push(item);
                }
            }
        });

        $('#popover2').popover({
            html: true,
            placement: 'bottom',
            content: function() {
                if ($scope.selectAll) {
                    $('.popover .inline .showHideTitle input[type="checkbox"]').prop('checked', true);
                } else {
                    $('.popover .inline .showHideTitle input[type="checkbox"]').prop('checked', false);
                }
                return $('#popover2-content-wrapper').html();
            }
        }).on('click', function(e) {
            e.preventDefault();
        });

        $('body').on('click', '#colHideShowCancel', function() {
            $('.popover').css('display', 'none');
        });

        $('body').on('click', '#colHideShowApply', function() {
            $('.popover').css('display', 'none');
            $rootScope.safeApply(function() {
                for (var colIndex = 0; colIndex < $scope.columnTitleList.length; colIndex++) {

                    if (!($("#" + $scope.columnTitleList[colIndex].name).is(":checked"))) {
                        $scope.columnTitleList[colIndex].checked = "NO";
                        $('table[data-table-name="ibas-Data"]').DataTable().column([$scope.columnTitleList[colIndex].index]).visible(false);
                    } else {
                        $scope.columnTitleList[colIndex].checked = "YES";
                        $('table[data-table-name="ibas-Data"]').DataTable().column([$scope.columnTitleList[colIndex].index]).visible(true);
                    }
                }
            });

        });

        var iBasTable;
        $scope.updateData = {};
        $rootScope.equipmentSearchData = function(input) {
            $(".loading").center();
            $(".loading").show();
            $(".overlay").show();
            $http.post("connect/fms/getIbasDataWithFilter", JSON.stringify({
                "type": input,
                "businessSegment": $rootScope.businessSegment,
                "marketIndustry": $rootScope.marketIndustry ? $rootScope.marketIndustry : ""
            })).then(function(response) {
                $scope.updateData = response.data;
                updateIbasData();
            }).then(function() {
                resizeAll();
            });
        }

        if ($rootScope.marketIndustry) {
            $rootScope.equipmentSearchData('DEFAULT');
        } else {
            $timeout(function() {
                $rootScope.equipmentSearchData('DEFAULT');
            }, 5000);
        }

        $("body").off("change", "#AllData");
        $("body").on("change", "#AllData", function() {
            var flag = $(this).is(":checked");
            if (flag) {
                $rootScope.equipmentSearchData('ALL');
            } else {
                $rootScope.equipmentSearchData('DEFAULT');
            }
        });

        $('table[data-table-name="ibas-Data"] tfoot td').each(function() {
            var title = $(this).text();
            if (title !== '') {
                $(this).html('<input type="text" placeholder="Search ' + title + '" size="4" />');
            }
        });

        var $window = $(window);
        var windowsize = $window.width();
        var dtOptions;
        if (windowsize > 767) {
            dtOptions = {
                rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: false,
                "bPaginate": true,
                "bSort": true,
                "bFilter": true,
                "aLengthMenu": [
                    [10, 20, 50, 100, -1],
                    [10, 20, 50, 100, "All"]
                ],
                "iDisplayLength": 10,
                "bAutoWidth": false
            };
        } else {
            dtOptions = {
                rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: true,
                "bPaginate": true,
                "bSort": true,
                "bFilter": true,
                "aLengthMenu": [
                    [10, 20, 50, 100, -1],
                    [10, 20, 50, 100, "All"]
                ],
                "iDisplayLength": 10,
                "bAutoWidth": false
            };
        }

        iBasTable = $('table[data-table-name="ibas-Data"]').DataTable(dtOptions);

        // Apply the search
        iBasTable.columns().every(function() {
            var that = this;

            $('input', this.footer()).on('keyup change', function() {
                if (that.search() !== this.value) {
                    that
                        .search(this.value)
                        .draw();
                }
            });
        });

        function updateIbasData() {
            if ($scope.flag === true) {
                $(".loading").hide();
                $(".overlay").hide();
            } else {
                $(".overlay").css("height", $(document).height());
                $(".overlay").show();
            }
            $('table[data-table-name="ibas-Data"]').dataTable().fnClearTable();
            angular.forEach($scope.updateData, function(data) {
                $('table[data-table-name="ibas-Data"]').dataTable().fnAddData([
                    data.cGibSrNo,
                    data.siteCustomerName,
                    data.cServMgrLast,
                    data.cservMgrFirst,
                    data.ongRegion,
                    data.cUnitStatusDesc,
                    data.cSiteCustCntry,
                    data.cServRelnDescOng,
                    data.cTechDescOg,
                    data.cOemLocDesc,
                    data.cMktSegmentDesc,
                    data.geDunsName,
                    data.cMaintPolicyCode,
                    data.dEstSerStrtDate,
                    data.nEstServHrsCnt,
                    data.level,
                    data.nAvgRepairVal,
                    data.nAvgPartsVal,
                    data.nAvgSvcsVal,
                    data.avmanpow,
                    data.avaux,
                    data.avf2f,
                    data.avtot,
                    data.ibasCSiteNameAlias,
                    data.nMaintPolicyId,
                    data.cMaintPolicyDesc,
                    data.nInstallLtDays,
                    data.tOtherMaintPolicy,
                    data.dEstManufComplete,
                    data.dEstShipDate,
                    data.dEstServHrsDate,
                    data.nMaintYr,
                    data.cHqCustName,
                    data.cHqCustCntry,
                    data.cDomCustDuns,
                    data.cDomCustName,
                    data.cTechDesc,
                    data.cTechCodeOg,
                    data.cEquipCode,
                    data.cEquipDesc,
                    data.cEquipEngDes,
                    data.dUnitShipDate,
                    data.dUnitCodDate,
                    data.ibasCAccountMgrLast,
                    data.cMktIndustryDesc,
                    data.cSalesChannelDesc,
                    data.cServRelationDescGib,
                    data.cControlSystemDesc,
                    data.cServTypeDesc,
                    data.cDrivenEquipDesc,
                    data.cMkt,
                    data.cProdEscPl,
                    data.nFfhCnt,
                    data.cGloCustDuns,
                    data.cGloCustName,
                    data.geGlobalDuns,
                    data.ibasCSiteCustDuns,
                    data.ibasCSiteCustCity,
                    data.ibasCTierCod,
                    data.ibasCEngProjectRef,
                    data.ibasCOemSerialNumber,
                    data.ibasCParentSerialNumber,
                    data.ibasNServFactor
                ], false);
            });
            $('table[data-table-name="ibas-Data"]').dataTable().fnDraw(true);
            $('#colHideShowApply').click();

        }

        $scope.syncIBASData = function() {

            $timeout(function() {
                deferredAbort.resolve("User cancelled");
            }, 60000);

            deferredAbort = $q.defer();
            modalAlert = document.getElementById('partsDataAlertModal');
            modalAlert.style.display = "block";

            $http.post("connect/fms/getOracleIBASData", JSON.stringify({
                "sso": $rootScope.userSSO,
                "businessSegment": $rootScope.businessSegment
            }), {
                withCredentials: true,
                transformRequest: angular.identity,
                timeout: deferredAbort.promise
            });

            return deferredAbort.promise;
        }

        $scope.getIBASDataHistory = function() {

            $(".loading").center();
            $(".loading").show();
            $(".overlay").show();

            if ($.fn.DataTable.isDataTable('#ibsHistoryTable')) {
                $("#ibsHistoryTable").dataTable().api().clear().draw();
                $("#ibsHistoryTable").dataTable().api().destroy();
                $('#ibsHistoryTable').empty();
            }

            $http.post("connect/fms/getImportStatusHistory", JSON.stringify({
                "taskName": "getIBasData",
                "sso": $rootScope.userSSO
            })).then(function(response) {
                $rootScope.safeApply(function() {

                    $(".loading").hide();
                    $(".overlay").hide();

                    $scope.ibsHistoryData = response.data;

                    historyModal.style.display = "block";

                    $scope.arrIBSHistoryHeaders = [{
                        data: "created_date",
                        title: "Date",
                        width: "33%"
                    }, {
                        data: "task_name",
                        title: "Task Name",
                        width: "33%"
                    }, {
                        data: "status",
                        title: "Status",
                        width: "33%",
                        "fnCreatedCell": function(nTd, sData, oData, iRow, iCol) {
                            if (sData === "FAILURE") {
                                $(nTd).css('color', '#FF0000').css('font-weight', 'bold');
                            }
                        }
                    }];

                    $('#ibsHistoryTable').DataTable({
                        "order": [
                            ["0", "desc"]
                        ],
                        "bFilter": false,
                        "paging": false,
                        "responsive": true,
                        "columns": $scope.arrIBSHistoryHeaders,
                        "data": $scope.ibsHistoryData
                    });


                });
            });
        }

        $(".exportToExcelIbas").click(function() {
            var data;
            var flag = $("#AllData").is(":checked");
            if (flag) {
                data = 'ALL';
            } else {
                data = 'DEFAULT';
            }
            download('/connect/fms/exportEquipmentData', JSON.stringify({
                "type": data,
                "businessSegment": $rootScope.businessSegment,
                "marketIndustry": $rootScope.marketIndustry ? $rootScope.marketIndustry : ""
            }), 'Ibas Dtl');
        });

        function download(url, data, defaultFileName) {
            var deferred = $q.defer();
            $http.post(url, data, {
                responseType: "arraybuffer"
            }).success(
                function(data, status, headers) {
                    var type = headers('Content-Type');
                    var disposition = headers('Content-Disposition');
                    if (disposition) {
                        var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                        if (match[1])
                            defaultFileName = match[1];
                    }
                    defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                    var blob = new Blob([data], {
                        type: type
                    });
                    saveAs(blob, defaultFileName);
                    deferred.resolve(defaultFileName);
                }).error(function() {
                var e;
                deferred.reject(e);
            });
            return deferred.promise;
        }

        $scope.downloadTemplate = function(fileName) {
            var item = {};
            item["type"] = fileName;
            item["businessSegment"] = $rootScope.businessSegment;
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            download('/connect/fms/downloadFile', item, fileName);
        };


    }]);
});