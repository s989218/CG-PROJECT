
define(['angular','../../sample-module','jquery', 'datatablesNetMin', 'datatablesNet', 'multiselectdrpdwn','jqueryMultiSelect'], 
	function (angular,controllers) 
 {
    'use strict';
    controllers.controller('IPMParentCtrl', ['$rootScope','$scope','$timeout','$q','$http','IPMService','$state',function ($rootScope, $scope,$timeout,$q,$http,IPMService,$state) 
                {
                 
                    $('.iPMselectionFilterBody').slideUp();
                    var tempPandL;
                    $scope.showKeyDealsContent = true;
                    $scope.showIPMFilters= false;
                    $scope.iPMLoader =false;    
                    $scope.headerName = 'DashBoard';
                    $scope.showSelectionPanel = false; 
                    $rootScope.selectionFilterData ={};
                    $scope.searchPanel ={};
                    $scope.searchPanel.businessSegment = 'DTS'; 
                    $rootScope.selectionFilterData["businessSegment"]=$scope.searchPanel.businessSegment;
                    $scope.checkError = function (data){
                     $scope.showError= false;
                        if (!data) {
                         $scope.showError= true;
                        return true;
                        }
                       else {
                         $scope.showError= false;
                         return false; 
                       }
                    }
                    
    $scope.loadfilteredData = function (){
                  if ($scope.filterCode === "KeyDeals"){        
                        if (!$rootScope.selectionFilterData)
                             {
                               $rootScope.selectionFilterData ={};
                             }
                     
                      IPMService.getIPMKeyDealsData(JSON.stringify($rootScope.selectionFilterData)).then(function(response){  
                                                    $rootScope.safeApply(function(){
                                                    $rootScope.IPMKeyDealsData = response;
                                                    if(!$scope.checkError($rootScope.IPMKeyDealsData)){
                                                    $scope.headerName = 'Key Deals';
                                                    $scope.showSelectionPanel = false; 
                                                 $scope.showSelectionPanel= false;
                                    $scope.showKeyDeals =true;                                                         
                                    $scope.showRisks =false;    
                                    $scope.showOpps =false;
                                    $scope.showBObusiness =false;                                 
                                    $scope.showBOregion =false;
                                    $scope.showDataEntry = false;
                                    $scope.showPCTX = false;
                                    $scope.showPCCS = false;
                                    $scope.showPCINST = false;
                                    $scope.showPRCTX = false; 
                                    $scope.showPRCCS = false; 
                                    $scope.showPRCINST = false; 
                                    $scope.showWBF = false;   
                                                      if ($.fn.DataTable.isDataTable( '#KeyDealsTable' ) ) {
                                                               $("#KeyDealsTable").dataTable().api().clear().draw();
                                                               $("#KeyDealsTable").dataTable().api().destroy();
                                                               $('#KeyDealsTable').empty(); 
                                                          }
                                                    $scope.keyDealsTableDraw();   
                                                    }
                                                          $scope.iPMLoader =false; 
                                                    });
                                                   });
                        }
                      
                    if ($scope.filterCode === "Risks"){      
                        if (!$rootScope.selectionFilterData)
                             {
                               $rootScope.selectionFilterData ={};
                             }
                                                        IPMService.getIPMRisksData(JSON.stringify($rootScope.selectionFilterData)).then(function(response){  
                                                 $rootScope.safeApply(function(){
                                                 $rootScope.IPMRiskData = response; 
                                                 if(!$scope.checkError($rootScope.IPMRiskData)){     
                                                 $scope.headerName = 'Risks';   
                                                     $scope.showSelectionPanel= false;
                                    $scope.showKeyDeals =false;                                                         
                                    $scope.showRisks =true;    
                                    $scope.showOpps =false;
                                    $scope.showBObusiness =false;                                 
                                    $scope.showBOregion =false;
                                    $scope.showDataEntry = false;
                                    $scope.showPCTX = false;
                                    $scope.showPCCS = false;
                                    $scope.showPCINST = false;
                                    $scope.showPRCTX = false; 
                                    $scope.showPRCCS = false; 
                                    $scope.showPRCINST = false; 
                                    $scope.showWBF = false; 
                                                 $scope.showSelectionPanel = false; 
                                                    if ($.fn.DataTable.isDataTable( '#risksTable' ) ) {
                                                           $("#risksTable").dataTable().api().clear().draw();
                                                           $("#risksTable").dataTable().api().destroy();
                                                           $('#risksTable').empty(); 
                                                      }
                                                    $scope.risksTableDraw();   
                                                 }
                                                    $scope.iPMLoader =false;  
                                                 });
                                                   });
                        }
              
              
                      if ($scope.filterCode === "Opps"){   
                            
                        if (!$rootScope.selectionFilterData)
                             {
                               $rootScope.selectionFilterData ={};
                             }
                                                        IPMService.getIPMOppsData(JSON.stringify($rootScope.selectionFilterData)).then(function(response){  
                                                $rootScope.safeApply(function(){
                                                $rootScope.IPMOppsData = response;  
                                         if(!$scope.checkError($rootScope.IPMOppsData)){     
                        
                                                    $scope.headerName = 'Opps'; 
                                          $scope.showSelectionPanel= false;
                                    $scope.showKeyDeals =false;                                                         
                                    $scope.showRisks =false;    
                                    $scope.showOpps =true;
                                    $scope.showBObusiness =false;                                 
                                    $scope.showBOregion =false;
                                    $scope.showDataEntry = false;
                                    $scope.showPCTX = false;
                                    $scope.showPCCS = false;
                                    $scope.showPCINST = false;
                                    $scope.showPRCTX = false; 
                                    $scope.showPRCCS = false; 
                                    $scope.showPRCINST = false; 
                                    $scope.showWBF = false; 
                                                    $scope.showSelectionPanel = false;
                                                    if ($.fn.DataTable.isDataTable( '#oppsTable' ) ) {
                                                       $("#oppsTable").dataTable().api().clear().draw();
                                                       $("#oppsTable").dataTable().api().destroy();
                                                       $('#oppsTable').empty(); 
                                                  }
                                                $scope.oppsTableDraw(); 
                                         }
                                        $scope.iPMLoader =false;  
                                                });
                                                   });
                        }
                    
                       if ($scope.filterCode === "BOBB"){ 
                           if (!$rootScope.selectionFilterData)
                             {
                               $rootScope.selectionFilterData ={};
                             }
                           IPMService.getBObyBusinessData(JSON.stringify($rootScope.selectionFilterData)).then(function (response){
                                 $rootScope.safeApply(function(){
                                     $rootScope.BOBusinessData = response; 
                                        if(!$scope.checkError($rootScope.BOBusinessData)){             
                                     $scope.showSelectionPanel = false; 
                                                $scope.headerName = 'Business Overview (Walk by Business)'; 
                                              $scope.showSelectionPanel= false;
                                    $scope.showKeyDeals =false;                                                         
                                    $scope.showRisks =false;    
                                    $scope.showOpps =false;
                                    $scope.showBObusiness =true;                                 
                                    $scope.showBOregion =false;
                                    $scope.showDataEntry = false;
                                    $scope.showPCTX = false;
                                    $scope.showPCCS = false;
                                    $scope.showPCINST = false;
                                    $scope.showPRCTX = false; 
                                    $scope.showPRCCS = false; 
                                    $scope.showPRCINST = false; 
                                    $scope.showWBF = false; 
                                                if ($.fn.DataTable.isDataTable( '#BObyBusinessTable' ) ) {
                                                           $("#BObyBusinessTable").dataTable().api().clear().draw();
                                                           $("#BObyBusinessTable").dataTable().api().destroy();
                                                           $('#BObyBusinessTable').empty(); 
                                                      }
                                                $scope.drawBOBusiness();
                                        }
                                                $scope.iPMLoader =false; 
                                       });
                           });
                        }
                    
                         if ($scope.filterCode === "BOBR"){                             
                                                        
                             if (!$rootScope.selectionFilterData)
                                 {
                                   $rootScope.selectionFilterData ={};
                                 }
IPMService.getBObyRegionData(JSON.stringify($rootScope.selectionFilterData)).then(function (response){
                                                $rootScope.safeApply(function(){
                                                $rootScope.BORegionData = response;
                                               if(!$scope.checkError($rootScope.BORegionData)){     
                                                $scope.headerName = 'Business Overview (Walk by Region)';
                                                $scope.showSelectionPanel= false;
                                             $scope.showSelectionPanel= false;
                                    $scope.showKeyDeals =false;                                                         
                                    $scope.showRisks =false;    
                                    $scope.showOpps =false;
                                    $scope.showBObusiness =false;                                 
                                    $scope.showBOregion =true;
                                    $scope.showDataEntry = false;
                                    $scope.showPCTX = false;
                                    $scope.showPCCS = false;
                                    $scope.showPCINST = false;
                                    $scope.showPRCTX = false; 
                                    $scope.showPRCCS = false; 
                                    $scope.showPRCINST = false; 
                                    $scope.showWBF = false; 
                                                if ($.fn.DataTable.isDataTable( '#BObyRegionTable' ) ) {
                                                           $("#BObyRegionTable").dataTable().api().clear().draw();
                                                           $("#BObyRegionTable").dataTable().api().destroy();
                                                           $('#BObyRegionTable').empty(); 
                                                }
                                                $scope.drawBORegion ();
                                               }
                                                $scope.iPMLoader =false;  
                                                           });
                        });
              
                              
                        }
                    
                         if ($scope.filterCode === "DE"){  
                                if (!$rootScope.selectionFilterData)
                                 {
                                   $rootScope.selectionFilterData ={};
                                 }
                            var dataEntryObj = {};
                            dataEntryObj['businessSegment'] = $rootScope.selectionFilterData.businessSegment ;
                            $rootScope.safeApply(function(){
                                                    IPMService.getIPMDataEntryData(JSON.stringify(dataEntryObj)).then(function (response){
                                                    $rootScope.IPMDataEntryData = response; 
                                                    if(!$scope.checkError($rootScope.IPMDataEntryData)){
                                                    $scope.showSelectionPanel = false; 
                                                    $scope.headerName = 'Data Entry';
                                                $scope.showSelectionPanel= false;
                                    $scope.showKeyDeals =false;                                                         
                                    $scope.showRisks =false;    
                                    $scope.showOpps =false;
                                    $scope.showBObusiness =false;                                 
                                    $scope.showBOregion =false;
                                    $scope.showDataEntry = true;
                                    $scope.showPCTX = false;
                                    $scope.showPCCS = false;
                                    $scope.showPCINST = false;
                                    $scope.showPRCTX = false; 
                                    $scope.showPRCCS = false; 
                                    $scope.showPRCINST = false; 
                                    $scope.showWBF = false; 
                                                    }
                                                     $scope.iPMLoader =false;  
                                                    });
                                 
                                                });
                        }
        
                     if ($scope.filterCode === "PCTX"){                             
                                                        
                             if (!$rootScope.selectionFilterData)
                                 {
                                   $rootScope.selectionFilterData ={};
                                 }
                         
                          
                             else if($rootScope.selectionFilterData.pandL){
                                 tempPandL = $rootScope.selectionFilterData.pandL;
                             }
                               $rootScope.selectionFilterData.pandL = 'TX';
                                         
    IPMService.getPCData(JSON.stringify($rootScope.selectionFilterData)).then(function (response){
                                                $rootScope.safeApply(function(){
                                                $rootScope.PCTXData = response;  
                                                  if(!$scope.checkError($rootScope.PCTXData)){
                                                $scope.headerName = 'Project Controller - TX';
                                                if (tempPandL){
                                                    $rootScope.selectionFilterData.pandL  =  tempPandL;
                                                }
                                                else{
                                                    $rootScope.selectionFilterData.pandL  =  null;
                                                }
                                                $scope.showSelectionPanel= false;
                                              $scope.showSelectionPanel= false;
                                    $scope.showKeyDeals =false;                                                         
                                    $scope.showRisks =false;    
                                    $scope.showOpps =false;
                                    $scope.showBObusiness =false;                                 
                                    $scope.showBOregion =false;
                                    $scope.showDataEntry = false;
                                    $scope.showPCTX = true;
                                    $scope.showPCCS = false;
                                    $scope.showPCINST = false;
                                    $scope.showPRCTX = false; 
                                    $scope.showPRCCS = false; 
                                    $scope.showPRCINST = false; 
                                    $scope.showWBF = false; 
                                                if ($.fn.DataTable.isDataTable( '#PCTXTable' ) ) {
                                                           $("#PCTXTable").dataTable().api().clear().draw();
                                                           $("#PCTXTable").dataTable().api().destroy();
                                                           $('#PCTXTable').empty(); 
                                                }
                                                $scope.drawPCTX();
                                                  }
                                                $scope.iPMLoader =false;  
                                                           });
                        });
              
                              
                        }
               if ($scope.filterCode === "PCCS"){                             
                                                        
                             if (!$rootScope.selectionFilterData)
                                 {
                                   $rootScope.selectionFilterData ={};
                                 }
                             else if($rootScope.selectionFilterData.pandL){
                                tempPandL = $rootScope.selectionFilterData.pandL;
                             }
                               $rootScope.selectionFilterData.pandL = 'CS';
    IPMService.getPCData(JSON.stringify($rootScope.selectionFilterData)).then(function (response){
                                                $rootScope.safeApply(function(){
                                                $rootScope.PCCSData = response;  
                                               if(!$scope.checkError($rootScope.PCCSData)){
                                                $scope.headerName = 'Project Controller - CS';
                                                if (tempPandL){
                                                    $rootScope.selectionFilterData.pandL  =  tempPandL;
                                                }
                                                else{
                                                    $rootScope.selectionFilterData.pandL  =  null;
                                                }
                                                $scope.showSelectionPanel= false;
                                              $scope.showSelectionPanel= false;
                                    $scope.showKeyDeals =false;                                                         
                                    $scope.showRisks =false;    
                                    $scope.showOpps =false;
                                    $scope.showBObusiness =false;                                 
                                    $scope.showBOregion =false;
                                    $scope.showDataEntry = false;
                                    $scope.showPCTX = false;
                                    $scope.showPCCS = true;
                                    $scope.showPCINST = false;
                                    $scope.showPRCTX = false; 
                                    $scope.showPRCCS = false; 
                                    $scope.showPRCINST = false; 
                                    $scope.showWBF = false; 
                                                if ($.fn.DataTable.isDataTable( '#PCCSTable' ) ) {
                                                           $("#PCCSTable").dataTable().api().clear().draw();
                                                           $("#PCCSTable").dataTable().api().destroy();
                                                           $('#PCCSTable').empty(); 
                                                }
                                                $scope.drawPCCS();
                                               }
                                                $scope.iPMLoader =false;  
                                                           });
                        });
                     }
        
                    if ($scope.filterCode === "PCINST"){                             
                         if (!$rootScope.selectionFilterData)
                                 {
                                   $rootScope.selectionFilterData ={};
                                 }
                         else if($rootScope.selectionFilterData.pandL){
                                 tempPandL = $rootScope.selectionFilterData.pandL;
                             }
                               $rootScope.selectionFilterData.pandL = 'INST';
    IPMService.getPCData(JSON.stringify($rootScope.selectionFilterData)).then(function (response){
                                                $rootScope.safeApply(function(){
                                                $rootScope.PCINSTData = response;  
                                                if(!$scope.checkError($rootScope.PCINSTData)){
                                                $scope.headerName = 'Project Controller - INST';
                                                if (tempPandL){
                                                    $rootScope.selectionFilterData.pandL  =  tempPandL;
                                                }
                                                else{
                                                    $rootScope.selectionFilterData.pandL  =  null;
                                                }
                                                $scope.showSelectionPanel= false;
                                                  $scope.showSelectionPanel= false;
                                                $scope.showKeyDeals =false; 
                                                $scope.showRisks =false;    
                                                $scope.showOpps =false;
                                                $scope.showBObusiness =false;                                 
                                                $scope.showBOregion =false;
                                                $scope.showDataEntry = false;
                                                $scope.showPCTX = false;
                                                $scope.showPCCS = false;
                                                $scope.showPCINST = true;
                                                $scope.showPRCTX = false; 
                                                $scope.showPRCCS = false; 
                                                $scope.showPRCINST = false; 
                                                $scope.showWBF = false; 
                                                if ($.fn.DataTable.isDataTable( '#PCINSTTable' ) ) {
                                                           $("#PCINSTTable").dataTable().api().clear().draw();
                                                           $("#PCINSTTable").dataTable().api().destroy();
                                                           $('#PCINSTTable').empty(); 
                                                }
                                                $scope.drawPCINST();
                                                }
                                                $scope.iPMLoader =false;  
                                                           });
                        });
              
                              
                        }
        
                           if ($scope.filterCode === "PRCTX"){   
                               
                              if (!$rootScope.selectionFilterData)
                                 {
                                   $rootScope.selectionFilterData ={};
                                 }
                         
                             else if($rootScope.selectionFilterData.pandL){
                                 tempPandL = $rootScope.selectionFilterData.pandL;
                             }
                    
                               $rootScope.selectionFilterData.pandL = 'TX';
                                         
    IPMService.getPRCData(JSON.stringify($rootScope.selectionFilterData)).then(function (response){
                                                $rootScope.safeApply(function(){
                                                $rootScope.PRCTXData = response;  
                                               if(!$scope.checkError($rootScope.PRCTXData)){
                                                $scope.headerName = 'Walk By Product - TX';
                                                if (tempPandL){
                                                    $rootScope.selectionFilterData.pandL  =  tempPandL;
                                                }
                                                else{
                                                    $rootScope.selectionFilterData.pandL  =  null;
                                                }
                                                $scope.showSelectionPanel= false;
                                                     $scope.showSelectionPanel= false;
                                                    $scope.showKeyDeals =false;                                                         
                                                    $scope.showRisks =false;    
                                                    $scope.showOpps =false;
                                                    $scope.showBObusiness =false;                                 
                                                    $scope.showBOregion =false;
                                                    $scope.showDataEntry = false;
                                                    $scope.showPCTX = false;
                                                    $scope.showPCCS = false;
                                                    $scope.showPCINST = false;
                                                    $scope.showPRCTX = true; 
                                                    $scope.showPRCCS = false; 
                                                    $scope.showPRCINST = false; 
                                                    $scope.showWBF = false; 
                                                if ($.fn.DataTable.isDataTable( '#PRCTXTable' ) ) {
                                                           $("#PRCTXTable").dataTable().api().clear().draw();
                                                           $("#PRCTXTable").dataTable().api().destroy();
                                                           $('#PRCTXTable').empty(); 
                                                }
                                                $scope.drawPRCTX();
                                               }
                                                $scope.iPMLoader =false;  
                                                           });
                        });
              
                              
                        }
        
                        if ($scope.filterCode === "PRCCS"){                             
                                                        
                            if (!$rootScope.selectionFilterData) {
                               $rootScope.selectionFilterData ={};
                            } else 
                            if($rootScope.selectionFilterData.pandL) {
                                 tempPandL = $rootScope.selectionFilterData.pandL;
                            }
                            
                            $rootScope.selectionFilterData.pandL = 'CS';
                                         
                            IPMService.getPRCData(JSON.stringify($rootScope.selectionFilterData)).then(function (response){
                                $rootScope.safeApply(function(){
                                    $rootScope.PRCCSData = response;  
                                    if(!$scope.checkError($rootScope.PRCCSData)){
                                    $scope.headerName = 'Walk By Product - CS';
                                    if (tempPandL){
                                        $rootScope.selectionFilterData.pandL  =  tempPandL;
                                    }
                                    else{
                                        $rootScope.selectionFilterData.pandL  =  null;
                                    }
                                    $scope.showSelectionPanel= false;
                                    $scope.showSelectionPanel= false;
                                    $scope.showKeyDeals =false;                                                         
                                    $scope.showRisks =false;    
                                    $scope.showOpps =false;
                                    $scope.showBObusiness =false;                                 
                                    $scope.showBOregion =false;
                                    $scope.showDataEntry = false;
                                    $scope.showPCTX = false;
                                    $scope.showPCCS = false;
                                    $scope.showPCINST = false;
                                    $scope.showPRCTX = false; 
                                    $scope.showPRCCS = true; 
                                    $scope.showPRCINST = false; 
                                    $scope.showWBF = false; 

                                    if ($.fn.DataTable.isDataTable( '#PRCCSTable' ) ) {
                                        $("#PRCCSTable").dataTable().api().clear().draw();
                                        $("#PRCCSTable").dataTable().api().destroy();
                                        $('#PRCCSTable').empty(); 
                                    }
                                    $scope.drawPRCCS();
                                    }
                                    $scope.iPMLoader =false;  
                               });
                            });
                        }
        
                         if ($scope.filterCode === "PRCINST"){                             
                                                        
                            if (!$rootScope.selectionFilterData) {
                               $rootScope.selectionFilterData ={};
                            } else 
                            if($rootScope.selectionFilterData.pandL) {
                                 tempPandL = $rootScope.selectionFilterData.pandL;
                            }
                            
                            $rootScope.selectionFilterData.pandL = 'INST';
                                         
                            IPMService.getPRCData(JSON.stringify($rootScope.selectionFilterData)).then(function (response){
                                $rootScope.safeApply(function(){
                                    $rootScope.PRCINSTData = response;
                                    if(!$scope.checkError($rootScope.PRCINSTData)){
                                    $scope.headerName = 'Walk By Product - INST';
                                    if (tempPandL){
                                        $rootScope.selectionFilterData.pandL  =  tempPandL;
                                    }
                                    else{
                                        $rootScope.selectionFilterData.pandL  =  null;
                                    }
                                    $scope.showSelectionPanel= false;
                                    $scope.showKeyDeals =false;                                                         
                                    $scope.showRisks =false;    
                                    $scope.showOpps =false;
                                    $scope.showBObusiness =false;                                 
                                    $scope.showBOregion =false;
                                    $scope.showDataEntry = false;
                                    $scope.showPCTX = false;
                                    $scope.showPCCS = false;
                                    $scope.showPCINST = false;
                                    $scope.showPRCTX = false; 
                                    $scope.showPRCCS = false; 
                                    $scope.showPRCINST = true; 
                                    $scope.showWBF = false; 

                                    if ($.fn.DataTable.isDataTable( '#PRCINSTTable' ) ) {
                                        $("#PRCINSTTable").dataTable().api().clear().draw();
                                        $("#PRCINSTTable").dataTable().api().destroy();
                                        $('#PRCINSTTable').empty(); 
                                    }
                                    $scope.drawPRCINST();
                                    }
                                    $scope.iPMLoader =false;  
                               });
                            });
                        }
        
        
                        if ($scope.filterCode === "WBF"){                             
                                                        
                            if (!$rootScope.selectionFilterData) {
                               $rootScope.selectionFilterData ={};
                            } else 
             
                            IPMService.getWalkByFinanceData(JSON.stringify($rootScope.selectionFilterData)).then(function (response){
                                $rootScope.safeApply(function(){
                                    $rootScope.WBFData = response;  
                                    if(!$scope.checkError($rootScope.WBFData)){
                                    $scope.headerName = 'Walk By Finance';
                                    $scope.showSelectionPanel= false;
                                   
                                    $scope.showKeyDeals =false;                                                         
                                    $scope.showRisks =false;    
                                    $scope.showOpps =false;
                                    $scope.showBObusiness =false;                                 
                                    $scope.showBOregion =false;
                                    $scope.showDataEntry = false;
                                    $scope.showPCTX = false;
                                    $scope.showPCCS = false;
                                    $scope.showPCINST = false;
                                    $scope.showPRCTX = false; 
                                    $scope.showPRCCS = false; 
                                    $scope.showPRCINST = false; 
                                    $scope.showWBF = true; 

                                    if ($.fn.DataTable.isDataTable( '#WBFTable' ) ) {
                                        $("#WBFTable").dataTable().api().clear().draw();
                                        $("#WBFTable").dataTable().api().destroy();
                                        $('#WBFTable').empty(); 
                                    }
                                    $scope.drawWBF();
                                    }
                                    $scope.iPMLoader =false;  
                               });
                            });
                        }
    
    }
          
                            if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                
                                $scope.filterCode= sessionStorage.getItem("filterCode");
                                
                                $scope.loadfilteredData();
                            } else {
                                // Sorry! No Web Storage support..
                            }
    
    
                           $scope.getCurrentState = function (){
                        	   if(!($state.current.url === "/IPM")){
                              	 $state.go('IPM');
                              }
                    };
                    
 $scope.showIPMFiltersToggle = function (){
                    if ($('.iPMselectionFilterBody').is(':visible')) {
                       $('.iPMselectionFilterBody').slideUp(200);
                       $scope.showIPMFilters = false;
                    } else {
                       $scope.showIPMFilters = true;
                       $('.iPMselectionFilterBody').slideDown(200);
                    }   
                } 
 
    
                    $('.px-app-nav ul:eq(2) li:eq(0)').click(function(){
                         $scope.iPMLoader =true;    
                         $scope.filterCode = 'KeyDeals'; 
                             if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                sessionStorage.setItem("filterCode", $scope.filterCode);
                            } else {
                                // Sorry! No Web Storage support..
                            }
                         $scope.getCurrentState();
                         $scope.loadfilteredData();
                    });
                    $('.px-app-nav ul:eq(2) li:eq(1)').click(function(){
                         $scope.iPMLoader =true; 
                          $scope.filterCode = 'Risks'; 
                             if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                sessionStorage.setItem("filterCode", $scope.filterCode);
                            } else {
                                // Sorry! No Web Storage support..
                            }
                        $scope.getCurrentState();
                        $scope.loadfilteredData();
                    });

                    
                    $('.px-app-nav ul:eq(2) li:eq(2)').click(function(){
                                    $scope.iPMLoader =true;  
                                    $scope.filterCode = 'Opps'; 
                             if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                sessionStorage.setItem("filterCode", $scope.filterCode);
                            } else {
                                // Sorry! No Web Storage support..
                            }
                         $scope.getCurrentState();       
                        $scope.loadfilteredData();
                     });
                    
                    $('.px-app-nav ul:eq(2) li:eq(3)').click(function(){
                                  $scope.iPMLoader =true;  
                                  $scope.filterCode = 'BOBB';
                             if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                sessionStorage.setItem("filterCode", $scope.filterCode);
                            } else {
                                // Sorry! No Web Storage support..
                            }
                         $scope.getCurrentState();       
                        $scope.loadfilteredData();
                     });
                    
                    
                                      
                $('.px-app-nav ul:eq(2) li:eq(4)').click(function(){
                                    $scope.iPMLoader =true;
                                    $scope.filterCode = 'BOBR';
                         if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                sessionStorage.setItem("filterCode", $scope.filterCode);
                            } else {
                                // Sorry! No Web Storage support..
                            }
                     $scope.getCurrentState();          
                    $scope.loadfilteredData();
                     });
                 $('.px-app-nav ul:eq(2) li:eq(5)').click(function(){
                                  $scope.iPMLoader =true;  
                                  $scope.filterCode = 'DE';
                          if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                sessionStorage.setItem("filterCode", $scope.filterCode);
                            } else {
                                // Sorry! No Web Storage support..
                            }
                      $scope.getCurrentState();            
                     $scope.loadfilteredData();
                     });
                $('.px-app-nav ul:eq(2) li:eq(6)').click(function(){
                                  $scope.iPMLoader =true;  
                                  $scope.filterCode = 'PCTX';
                          if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                sessionStorage.setItem("filterCode", $scope.filterCode);
                            } else {
                                // Sorry! No Web Storage support..
                            }
                      $scope.getCurrentState();            
                     $scope.loadfilteredData();
                     });
                 $('.px-app-nav ul:eq(2) li:eq(7)').click(function(){
                                  $scope.iPMLoader =true;  
                                  $scope.filterCode = 'PCCS';
                          if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                sessionStorage.setItem("filterCode", $scope.filterCode);
                            } else {
                                // Sorry! No Web Storage support..
                            }
                      $scope.getCurrentState();            
                     $scope.loadfilteredData();
                     });
                 $('.px-app-nav ul:eq(2) li:eq(8)').click(function(){
                                  $scope.iPMLoader =true;  
                                  $scope.filterCode = 'PCINST';
                          if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                sessionStorage.setItem("filterCode", $scope.filterCode);
                            } else {
                                // Sorry! No Web Storage support..
                            }
                      $scope.getCurrentState();            
                     $scope.loadfilteredData();
                     });
                    
                    
                    
                 $('.px-app-nav ul:eq(2) li:eq(9)').click(function(){
                                  $scope.iPMLoader =true;  
                                  $scope.filterCode = 'PRCTX';
                          if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                sessionStorage.setItem("filterCode", $scope.filterCode);
                            } else {
                                // Sorry! No Web Storage support..
                            }
                      $scope.getCurrentState();            
                     $scope.loadfilteredData();
                     });
                    
                    
                 $('.px-app-nav ul:eq(2) li:eq(10)').click(function(){
                                  $scope.iPMLoader =true;  
                                  $scope.filterCode = 'PRCCS';
                          if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                sessionStorage.setItem("filterCode", $scope.filterCode);
                            } else {
                                // Sorry! No Web Storage support..
                            }
                      $scope.getCurrentState();            
                     $scope.loadfilteredData();
                     });
                    
                    
                 $('.px-app-nav ul:eq(2) li:eq(11)').click(function(){
                                  $scope.iPMLoader =true;  
                                  $scope.filterCode = 'PRCINST';
                          if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                sessionStorage.setItem("filterCode", $scope.filterCode);
                            } else {
                                // Sorry! No Web Storage support..
                            }
                      $scope.getCurrentState();            
                     $scope.loadfilteredData();
                     });
                 $('.px-app-nav ul:eq(2) li:eq(12)').click(function(){
                                  $scope.iPMLoader =true;  
                                  $scope.filterCode = 'WBF';
                          if (typeof(Storage) !== "undefined") {
                                // Code for localStorage/sessionStorage.
                                sessionStorage.setItem("filterCode", $scope.filterCode);
                            } else {
                                // Sorry! No Web Storage support..
                            }
                      $scope.getCurrentState();            
                     $scope.loadfilteredData();
                     });
                    
      
                    $scope.exportExcelIPM = function (){
                    var urldata;
                        
                        if (!$rootScope.selectionFilterData){
                        $rootScope.selectionFilterData={};
                        }
                        if ($scope.filterCode === "KeyDeals"){                        
                     urldata="connect/fms/exportIPMData/keydeals";
                     }
                    if ($scope.filterCode === "Risks"){   
                       
                     urldata="connect/fms/exportIPMData/risks";
                    }
                          if ($scope.filterCode === "Opps"){   
                       
                     urldata="connect/fms/exportIPMData/opps";
                    }
                                download(urldata,JSON.stringify($rootScope.selectionFilterData),'Ibas Dtl');
    	            }
  			function download(url,data ,defaultFileName) {
                var deferred = $q.defer();
			    $http.post(url,data, { responseType: "arraybuffer" }).success(
			        function (data, status, headers) {
			            var type = headers('Content-Type');
			            var disposition = headers('Content-Disposition');
			            if (disposition) {
			                var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
			                if (match[1])
			                    defaultFileName = match[1];
			            }
			            defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
			            var blob = new Blob([data], { type: type });
			            saveAs(blob, defaultFileName);
			            deferred.resolve(defaultFileName);                    
			        }).error(function () {
			            var e ;
			            deferred.reject(e);
			        });
			    return deferred.promise;
			}
  	}]);
});




