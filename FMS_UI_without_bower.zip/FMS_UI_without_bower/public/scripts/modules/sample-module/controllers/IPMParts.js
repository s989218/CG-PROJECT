define(['angular', '../sample-module'], function(angular, controllers, jquery, datatablesNet) {
    'use strict';

    controllers.controller('IPMPartsCtrl', ['$scope', '$http', '$q', '$timeout', '$location', '$state', '$rootScope', 'IPMService', 'fileUpload',
        function($scope, $http, $q, $timeout, $location, $state, $rootScope, IPMService, fileUpload) {
            
            var deferredAbort;

            $scope.updateSuccess = false;
            $scope.updateFailure = false;
            $rootScope.showUploadOption = false;
            $scope.iPMPartsLoader = true;
            $rootScope.uploadMessage = "UPDATING..";
            $scope.partsSearchPanel = {};
            $scope.ipmPartsFilterData = {};
            $rootScope.selectionIPMPartsFilterData = {};
            //setting role to get data according to DTS/TMS 
            $rootScope.selectionIPMPartsFilterData.roleId = $rootScope.roleId;
            $rootScope.selectionIPMPartsFilterData.roleName = $rootScope.roleName;
            IPMService.getIPMPartsDropdownData(JSON.stringify($rootScope.selectionIPMPartsFilterData)).then(function(response) {
                $scope.IPMPartsDropdownData = response;
            });

            $scope.hideUpload = function() {
                if ($scope.showUploadOption) {
                    $scope.showUploadOption = false;
                    $rootScope.uploadMessage = "";
                    angular.element("input[type='file']").val(null);
                    $scope.myFile = null;
                } else {
                    $scope.showUploadOption = true;
                }
            }

            $scope.showPartsFilters = function() {

                if ($('.partsFilterBody').is(':visible')) {
                    $('.partsFilterBody').slideUp(200);
                    $scope.filterOpen = false;
                } else {
                    $('.partsFilterBody').slideDown(200);
                    $scope.filterOpen = true;
                }
            }
            
            $scope.uploadFile = function() {
                var file;
                file = $scope.myFile;
                
                if (file) {
                    var filename     = file.name;
                    var index        = filename.lastIndexOf(".");
                    var strsubstring = filename.substring(index, filename.length);
                    
                    if (strsubstring !== '.csv') {
                        $rootScope.safeApply(function(){
                              $timeout(function (){
                                  $('.uploadMessage').addClass("successMsg");
                                  $('.uploadMessage').removeClass("failureMsg");
                              },200);
                              $rootScope.uploadStatus = "WARNING";
                        });
                    } else {
                        var uploadUrl = "connect/fms/importCSVToTable";

                        $('.uploadMessage').removeClass("failureMsg");
                        $('.uploadMessage').addClass("successMsg");
                        $rootScope.uploadStatus = "IN-PROGRESS";

                        $timeout(function() {
                            deferredAbort.resolve("User cancelled");
                        }, 60000);

                        $scope.uploadFileToUrl(file, uploadUrl)
                        .then(function(data) {
                            if (data === "SUCCESS") {
                                $rootScope.safeApply(function() {
                                    $timeout(function (){
                                        $('.uploadMessage').addClass("successMsg");
                                        $('.uploadMessage').removeClass("failureMsg");
                                        angular.element("input[type='file']").val(null);
                                    },200); 
                                    $rootScope.uploadStatus = "SUCCESS";
                                });
                            } else {
                               if ($rootScope.uploadStatus === "IN-PROGRESS") {
                                    $rootScope.safeApply(function(){
                                          $timeout(function (){
                                               $('.uploadMessage').removeClass("failureMsg");
                                               $('.uploadMessage').addClass("successMsg");
                                          },200);
                                          $rootScope.uploadStatus = "IN-PROGRESS";
                                    });  
                                } else {
                                    $rootScope.safeApply(function(){
                                          $timeout(function (){
                                               $('.uploadMessage').removeClass("successMsg");
                                               $('.uploadMessage').addClass("failureMsg");
                                               angular.element("input[type='file']").val(null);
                                          },200);
                                          $rootScope.uploadStatus = "FAILURE";
                                    });
                                }
                            }
                        }, function(error){
                            if ($rootScope.uploadStatus === "IN-PROGRESS") {
                                $rootScope.safeApply(function(){
                                      $timeout(function (){
                                           $('.uploadMessage').removeClass("failureMsg");
                                           $('.uploadMessage').addClass("successMsg");
                                      },200);
                                      $rootScope.uploadStatus = "IN-PROGRESS";
                                });  
                            } else {
                                $rootScope.safeApply(function(){
                                      $timeout(function (){
                                           $('.uploadMessage').removeClass("successMsg");
                                           $('.uploadMessage').addClass("failureMsg");
                                           angular.element("input[type='file']").val(null);
                                      },200);
                                      $rootScope.uploadStatus = "FAILURE";
                                });
                            }
                        }).finally(function(){
                            $scope.myFile = null;
                        });
                    }
                } else {
                    $('.uploadMessage').removeClass("successMsg");
                    $('.uploadMessage').addClass("failureMsg");
                    $rootScope.uploadStatus = "WARNING";
                }
            };
            
            $scope.uploadFileToUrl = function(file, uploadUrl) {

                deferredAbort = $q.defer();

                var fd = new FormData();
                fd.append('file', file);
                fd.append('mappingParam', $rootScope.mappingParam);
                fd.append('userSSO', $rootScope.userSSO);

                var startTime = (new Date()).getTime();

                $scope.FileUploadStatus = 'Request submitted';

                $http.post(uploadUrl, fd, 
                {
                    withCredentials: true,
                    headers: {'Content-Type': undefined },
                    transformRequest: angular.identity,
                    timeout: deferredAbort.promise 
                })
                .success(function (data, status, headers, config) {   
                    var endTime = (new Date()).getTime();
                    $scope.FileUploadStatus = 'Request response returned after ' + (endTime - startTime) + ' msec.';
                    deferredAbort.resolve(data);
                })
                .error(function (err, status) {
                    var endTime = (new Date()).getTime();
                    if(status === 0) {
                        $scope.FileUploadStatus = 'Request timed out after ' + (endTime - startTime) + ' msec.';
                        $rootScope.uploadStatus = "FAILURE";
                    } else {
                        $scope.FileUploadStatus = 'Request returned with error after ' + (endTime - startTime) + ' msec.';
                        $rootScope.uploadStatus = "IN-PROGRESS";
                    }

                    deferredAbort.reject({msg: err});
                });

                return deferredAbort.promise;
            }

            $('input[name=myFile]').change(function() {
                $rootScope.uploadMessage = "";
            });

            $scope.closeDiv = function() {
                $rootScope.uploadStatus = false;
                $scope.showUploadOption = false;
                angular.element("input[type='file']").val(null);
                $scope.myFile = null;
                $rootScope.uploadMessage = "";
            }

            var updateModal  = document.getElementById('myModal');
            var historyModal = document.getElementById('partsHistoryDataModal');
            
            var updateSpan   = document.getElementsByClassName("partsClose")[0];
            var historySpan  = document.getElementsByClassName("partsHistoryClose")[0];

            updateSpan.onclick = function() {
                updateModal.style.display = "none";
            }
            
            historySpan.onclick = function() {
                historyModal.style.display = "none";
            }

            window.onclick = function(event) {
                if (event.target === updateModal) {
                    updateModal.style.display = "none";
                }
                
                if (event.target === historyModal) {
                    historyModal.style.display = "none";
                }
            }

            $(function() {
                $("body").delegate("#p_new_date", "focusin", function() {
                    var localToday = new Date();
                    $(this).datepicker({
                        changeMonth: true,
                        changeYear: true,
                        dateFormat: 'mm-dd-yy',
                        localToday: localToday,
                        minDate: localToday,
                        inline: true,
                        dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
                        showOtherMonths: true,
                        showOn: "both",
                        showAnim: "slideDown",
                        duration: 'fast',
                        buttonImage: "images/calendar.png",
                        buttonImageOnly: true
                    });
                });
            });

            var table;
            $scope.headersName = null;

            function reduceObject(data, keys) {
                var dataArr = [];
                _.forEach(data, function(objData) {
                    var tempObj = {};
                    _.forEach(keys, function(keyObj) {
                        var key = keyObj.data;
                        tempObj[key] = objData[key];
                    });
                    dataArr.push(tempObj);
                });
                return dataArr;
            }
	    
            $scope.loadIPMPartsData = function() {
                if ($.fn.DataTable.isDataTable('#partsTable')) {
                    $("#partsTable").dataTable().api().clear().draw();
                    $("#partsTable").dataTable().api().destroy();
                    $('#partsTable').empty();
                }
                $scope.ipmPartsFilterData.roleId = $rootScope.roleId;
                $scope.ipmPartsFilterData.roleName = $rootScope.roleName;
                IPMService.getIPMPartsData(JSON.stringify($scope.ipmPartsFilterData)).then(function(response) {
                    $rootScope.safeApply(function() {
                        $scope.mainData = response;
                        $scope.customizedData = $scope.mainData.partsData;
                        $scope.defaultColumn = _.where($scope.mainData.partsColumnHeader, {
                            editable: "D"
                        });
                        $scope.customizedHeaders = _.where($scope.mainData.partsColumnHeader, {
                            editable: "Y"
                        });

                        $scope.invoiceNumberHeader = _.where($scope.mainData.partsColumnHeader, {
                            data: "invoice_number"
                        });
                        $scope.boxNumberHeader = _.where($scope.mainData.partsColumnHeader, {
                            data: "box_number"
                        });
                        $scope.partsStatusHeader = _.where($scope.mainData.partsColumnHeader, {
                            data: "parts_status"
                        });
                        $scope.salesDateYearQtrHeader = _.where($scope.mainData.partsColumnHeader, {
                            data: "sales_date_year_qtr"
                        });

                        $scope.customizedHeaders = $scope.customizedHeaders.concat($scope.defaultColumn);
                        $scope.customizedHeaders = $scope.customizedHeaders.concat($scope.invoiceNumberHeader);
                        $scope.customizedHeaders = $scope.customizedHeaders.concat($scope.boxNumberHeader);
                        $scope.customizedHeaders = $scope.customizedHeaders.concat($scope.partsStatusHeader);
                        $scope.customizedHeaders = $scope.customizedHeaders.concat($scope.salesDateYearQtrHeader);

                        $scope.customizedData = reduceObject($scope.mainData.partsData, $scope.customizedHeaders);
                        $scope.tempCustomizedHeader = $scope.customizedHeaders;
                        $scope.tempCustomizedData = $scope.customizedData;
                        dataTableIPM();
                    });
                });

            }

            $scope.loadIPMPartsData();

            $scope.selectPM = function(value) {
                $scope.partsSearchPanel.projectManager = value;
                $scope.showPMvalues = false;
            };
            $scope.searchIpmParts = function() {
                $scope.ipmPartsFilterData = $scope.partsSearchPanel;
                $scope.loadIPMPartsData();
            }

            $scope.hidePMvalues = function() {
                $timeout(function() {
                    $scope.showPMvalues = false;
                }, 200);
            };

            $scope.showColumnList = false;

            var redCircle = '<img src="../images/red.png">';
            var yellowCircle = '<img src="../images/yellow.png">';
            var greenCircle = '<img src="../images/green.png">';

            function dataTableIPM() {
                _.forEach($scope.customizedData, function(value) {
                    if (value.p_r_by_o) {
                        if ((value.p_r_by_o).toUpperCase() === 'RISK') {
                            if (!value.p_status) {
                                value.p_status = "";
                            } else if ((value.p_status).toUpperCase().trim() === 'LOW') {
                                value.p_status = greenCircle;
                            } else if ((value.p_status).toUpperCase().trim() === 'HIGH') {
                                value.p_status = redCircle;
                            } else if ((value.p_status).toUpperCase().trim() === 'MEDIUM') {
                                value.p_status = yellowCircle;
                            }
                        } else if ((value.p_r_by_o).toUpperCase() === 'OPPS') {
                            if (!value.p_status) {
                                value.p_status = "";
                            } else if ((value.p_status).toUpperCase().trim() === 'LOW') {
                                value.p_status = redCircle;
                            } else if ((value.p_status).toUpperCase().trim() === 'HIGH') {
                                value.p_status = greenCircle;
                            } else if ((value.p_status).toUpperCase().trim() === 'MEDIUM') {
                                value.p_status = yellowCircle;
                            }
                        }
                    } else {
                        if (!value.p_status) {
                            value.p_status = "";
                        } else if ((value.p_status).toUpperCase().trim() === 'LOW') {
                            value.p_status = redCircle;
                        } else if ((value.p_status).toUpperCase().trim() === 'HIGH') {
                            value.p_status = greenCircle;
                        } else if ((value.p_status).toUpperCase().trim() === 'MEDIUM') {
                            value.p_status = yellowCircle;
                        }
                    }
                });


                table = $('#partsTable').DataTable({
                    responsive: false,
                    data: $scope.customizedData,
                    "sPaginationType": "full_numbers",
                    "bFilter": true,
                    "retrieve": true,
                    "scrollX": false,
                    "paging": true,
                    columns: _.sortBy($scope.customizedHeaders, 'id'),
                    "columnDefs": [{
                        "targets": [17, 18, 19, 20],
                        "visible": false,
                        "searchable": false
                    }]
                });
                
                $('body #partsTable tbody').on('click', 'tr', function() {
                    var data = table.row(this).data(); 
                    var dataObject = {};
                    $scope.mainDataObject = [];
                    $scope.failureMessage = "";
                    _.forEach(data, function(value, key) {

                        if (_.where(_.where($scope.customizedHeaders, {
                                data: key
                            }), {
                                editable: "Y",
                                type: 'DropDown'
                            }).length > 0) {

                            _.forEach(_.where(_.where($scope.customizedHeaders, {
                                data: key
                            }), {
                                editable: "Y",
                                type: 'DropDown'
                            }), function(value) {
                                dataObject = {};
                                dataObject.id = value.id;
                                dataObject.key = value.data;
                                dataObject.value = value.title;
                                dataObject.editable = value.editable;
                                dataObject.type = value.type;
                                var str = value.values;
                                if (str) {
                                    dataObject.values = str.toString().split(",");
                                }
                                $scope.mainDataObject.push(dataObject);
                            });
                        }

                        if (_.where(_.where($scope.customizedHeaders, {
                                data: key
                            }), {
                                editable: "Y",
                                type: 'DATE'
                            }).length > 0) {

                            _.forEach(_.where(_.where($scope.customizedHeaders, {
                                data: key
                            }), {
                                editable: "Y",
                                type: 'DATE'
                            }), function(value) {
                                dataObject = {};
                                dataObject.id = value.id;
                                dataObject.key = value.data;
                                dataObject.value = value.title;
                                dataObject.editable = value.editable;
                                dataObject.type = value.type;
                                dataObject.values = value.values;
                                $scope.mainDataObject.push(dataObject);
                            });
                        }
                        if (_.where(_.where($scope.customizedHeaders, {
                                data: key
                            }), {
                                editable: "Y",
                                type: 'FreeField'
                            }).length > 0) {

                            _.forEach(_.where(_.where($scope.customizedHeaders, {
                                data: key
                            }), {
                                editable: "Y",
                                type: 'FreeField'
                            }), function(value) {
                                dataObject = {};
                                dataObject.id = value.id;
                                dataObject.key = value.data;
                                dataObject.value = value.title;
                                dataObject.editable = value.editable;
                                dataObject.type = value.type;
                                dataObject.values = value.values;
                                $scope.mainDataObject.push(dataObject);
                            });
                        }




                        if (_.where(_.where($scope.customizedHeaders, {
                                data: key
                            }), {
                                editable: "N"
                            }).length > 0) {

                            _.forEach(_.where(_.where($scope.customizedHeaders, {
                                data: key
                            }), {
                                editable: "N"
                            }), function(value) {
                                dataObject = {};
                                dataObject.id = value.id;
                                dataObject.key = value.data;
                                dataObject.value = value.title;
                                dataObject.editable = value.editable;
                                dataObject.type = value.type;
                                dataObject.values = value.values;
                                $scope.mainDataObject.push(dataObject);
                            });
                        }

                        if (_.where(_.where($scope.customizedHeaders, {
                                data: key
                            }), {
                                editable: "D"
                            }).length > 0) {

                            _.forEach(_.where(_.where($scope.customizedHeaders, {
                                data: key
                            }), {
                                editable: "D"
                            }), function(value) {
                                dataObject = {};
                                dataObject.id = value.id;
                                dataObject.key = value.data;
                                dataObject.value = value.title;
                                dataObject.editable = value.editable;
                                dataObject.type = value.type;
                                dataObject.values = value.values;
                                $scope.mainDataObject.push(dataObject);
                            });
                        }
                    });
                    
                    $scope.mainDataObject = _.sortBy($scope.mainDataObject, 'id');
                    
                    $rootScope.safeApply(function() {
                        if (data.p_r_by_o) {
                            if ((data.p_r_by_o).toUpperCase() === 'RISK') {
                                if (!data.p_status) {
                                    data.p_status = "";
                                } else if ((data.p_status).toUpperCase().includes("GREEN")) {
                                    data.p_status = 'Low';
                                } else if ((data.p_status).toUpperCase().includes("YELLOW")) {
                                    data.p_status = 'Medium';
                                } else if ((data.p_status).toUpperCase().includes("RED")) {
                                    data.p_status = 'High';
                                }
                            } else if ((data.p_r_by_o).toUpperCase() === 'OPPS') {

                                if (!data.p_status) {
                                    data.p_status = "";
                                } else if ((data.p_status).toUpperCase().includes("GREEN")) {
                                    data.p_status = 'High';
                                } else if ((data.p_status).toUpperCase().includes("YELLOW")) {
                                    data.p_status = 'Medium';
                                } else if ((data.p_status).toUpperCase().includes("RED")) {
                                    data.p_status = 'Low';
                                }
                            }
                        } else {
                            if (!data.p_status) {
                                data.p_status = "";
                            } else if ((data.p_status).toUpperCase().includes("GREEN")) {
                                data.p_status = 'High';
                            } else if ((data.p_status).toUpperCase().includes("YELLOW")) {
                                data.p_status = 'Medium';
                            } else if ((data.p_status).toUpperCase().includes("RED")) {
                                data.p_status = 'Low';
                            }
                        }
                        $scope.rowData = null;
                        $scope.rowData = [];
                        var dataObject = {};
                        _.forEach(data, function(value, key) {
                            dataObject['key'] = key;
                            dataObject['value'] = value;
                            $scope.rowData.push(dataObject);
                            dataObject = {};
                        });
                    });
                    
                    var updateModal = document.getElementById('myModal');
                    updateModal.style.display = "block";
                });

                $scope.iPMPartsLoader = false;
            }
            
            $scope.getImportHistory = function() {
                
                $scope.iPMPartsLoader = true;

                if ($.fn.DataTable.isDataTable( '#importHistoryTable' ) ) {
                    $("#importHistoryTable").dataTable().api().clear().draw();
                    $("#importHistoryTable").dataTable().api().destroy();
                    $('#importHistoryTable').empty(); 
                }

                $scope.importHistoryParams = {};
                $scope.importHistoryParams.taskName = "IPM Parts Import";
                $scope.importHistoryParams.sso      = $rootScope.userSSO;
                
                IPMService.getImportHistoryData(JSON.stringify($scope.importHistoryParams)).then(function (response){
                    $rootScope.safeApply(function(){

                        $scope.importHistoryData = response;
                        
                        historyModal.style.display = "block";
                        
                        $scope.arrImportHistoryHeaders = [
                            { data:"created_date", title:"Date", width:"25%" },
                            { data:"file_name", title:"File Name", width:"20%" },
                            { 
                                data:"status",
                                title:"Status",
                                width:"15%",
                                "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                                    if (sData === "FAILURE") { 
                                        $(nTd).css('color', '#FF0000').css('font-weight', 'bold'); 
                                    } 
                                }
                            },
                            { data:"invalid_record_count", title:"Invalid Record Count", width:"20%", },
                            {
                                title:"Download Invalid Data",
                                "bSortable": false,
                                "bSearchable": false,
                                width:"20%",
                                mRender: function (data, type, row, meta) {
                                     if (meta.row === 0){
                                        return '<a class="table-download"><i class="fa fa-download fa-2x download-history" aria-hidden="true"></i></a>';
                                     } else {
                                         return '';
                                     }
                                }
                            }
                        ];
                        
                        $('#importHistoryTable').DataTable({
                            rowReorder: {
                                selector: 'td:nth-child(2)'
                            },
                            responsive: true,
                            "order": [[ "0", "desc" ]],
                            "bFilter":false, 
                            "paging": false,
                            "columns": $scope.arrImportHistoryHeaders,
                            "data": $scope.importHistoryData
                        });
                        
                        $scope.iPMPartsLoader      = false;
                        
                        $('body #importHistoryTable tbody').on( 'click', 'a.table-download', function () { 
                                $scope.iPMPartsLoader = true;
                                var urldata;
                                var projectManager = $scope.partsSearchPanel.projectManager ? $scope.partsSearchPanel.projectManager : '';
                                var data = {
                                    'sso': $rootScope.userSSO,
                                    'projectManager':projectManager
                                };
                                urldata = "connect/fms/exportInvalidIPMData";
                                download(urldata, data, 'Invalid Record Count Data');
                        });
                    });
                });
            }
            
            $scope.selectAllParts = function() {
                $('div#partsSelection input[type=checkbox]').prop('checked', true);
                $scope.customizedData = $scope.mainData.partsData;
                $scope.customizedHeaders = $scope.mainData.partsColumnHeader;
                $("#partsTable").dataTable().api().clear().draw();
                $("#partsTable").dataTable().api().destroy();
                $('#partsTable').empty();
                dataTableIPM();
                $timeout(function() {
                    $('#partsTable tr th').css("min-width", "170px");
                }, 200);
            };

            $scope.clearAllParts = function() {
                $('div#partsSelection input[type=checkbox]').prop('checked', false);
                $scope.customizedData = $scope.tempCustomizedData;
                $scope.defaultColumn = _.where($scope.mainData.partsColumnHeader, {
                    editable: "D"
                });
                $scope.customizedHeaders = _.where($scope.mainData.partsColumnHeader, {
                    editable: "Y"
                });
                $scope.customizedHeaders = $scope.customizedHeaders.concat($scope.defaultColumn);
                
                $("#partsTable").dataTable().api().clear().draw();
                $("#partsTable").dataTable().api().destroy();
                $('#partsTable').empty();
                dataTableIPM();
                $timeout(function() {
                    $('#partsTable tr th').css("min-width", "170px");
                }, 20);
            };

            $scope.addColumn = function(title1, id) {
                if ($('#' + id).prop('checked')) {
                    $scope.newColumn = _.where($scope.mainData.partsColumnHeader, {
                        data: title1
                    });

                    _.forEach($scope.newColumn, function(column) {
                        $scope.customizedHeaders.push(column);
                    })

                    $scope.customizedData = reduceObject($scope.mainData.partsData, $scope.customizedHeaders);
                    $("#partsTable").dataTable().api().clear().draw();
                    $("#partsTable").dataTable().api().destroy();
                    $('#partsTable').empty();
                    dataTableIPM();
                } else {
                    $scope.customizedHeaders = _.without($scope.customizedHeaders, _.findWhere($scope.customizedHeaders, {
                        data: title1
                    }))
                    $scope.customizedData = reduceObject($scope.mainData.partsData, $scope.customizedHeaders);
                    $("#partsTable").dataTable().api().clear().draw();
                    $("#partsTable").dataTable().api().destroy();
                    $('#partsTable').empty();
                    dataTableIPM();
                }
            }

            $scope.showHideColumns = function() {
                if ($scope.showColumnList) {
                    $scope.showColumnList = false;
                } else {
                    $scope.showColumnList = true;
                }
            }

            $scope.updateData = function() {

                $scope.editedData = {};
                $scope.failureMessage = "";
                _.forEach($scope.rowData, function(data) {
                    if (!$('.' + data.key + '').val() || $('.' + data.key + '').val().startsWith("?")) {
                        $scope.editedData[data.key] = null;
                    } else {
                        if ($('#' + data.key + '').val().trim() === "") {
                            $scope.editedData[data.key] = null;
                        } else {
                            $scope.editedData[data.key] = $('#' + data.key + '').val().trim();
                        }
                    }
                });

                if ($scope.editedData['p_new_date'] != null && $scope.editedData['p_wb_comment'] == null) {
                    $scope.updateSuccess = false;
                    $scope.updateFailure = true;
                    $scope.failureMessage = "Please Select WB Comment."
                } else if (!$scope.editedData['p_status']) {
                    $scope.updateSuccess = false;
                    $scope.updateFailure = true;
                    $scope.failureMessage = "Please Select Status."
                } else {
                    IPMService.updateIPMPartsRow(JSON.stringify($scope.editedData)).then(function(response) {
                        $rootScope.safeApply(function() {
                            if (response === "UPDATED" || response === "SUCCESS") {
                                $scope.updateSuccess = true;
                                $scope.updateFailure = false;
                                $scope.loadIPMPartsData();
                            } else if (response === "FAILURE") {
                                $scope.updateSuccess = false;
                                $scope.updateFailure = true;
                                $scope.failureMessage = "Something went wrong! Please try again later."
                            }

                            $timeout(function() {
                                $scope.updateSuccess = false;
                                $scope.updateFailure = false;
                            }, 3000);
                        });

                    });
                }
            };

            $timeout(function() {
                $('#partsTable tr th').css("min-width", "170px");
            }, 200);
            
            $scope.exportExcelIPMparts = function() {
                $scope.iPMPartsLoader = true;
                var urldata;
                var projectManager = $scope.partsSearchPanel.projectManager ? $scope.partsSearchPanel.projectManager : '';
                var data = {
                    'projectManager': projectManager
                };
                urldata = "connect/fms/exportCSVFromTable";
                download(urldata, data, 'Ibas Dtl');
            }

            function download(url, data, defaultFileName) {
                var deferred = $q.defer();
                $http.post(url, data, {
                    responseType: "arraybuffer"
                }).success(
                    function(data, status, headers) {
                        var type = headers('Content-Type');
                        var disposition = headers('Content-Disposition');
                        if (disposition) {
                            var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                            if (match[1])
                                defaultFileName = match[1];
                        }
                        defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                        var blob = new Blob([data], {
                            type: type
                        });
                        saveAs(blob, defaultFileName);
                        deferred.resolve(defaultFileName);
                        $scope.iPMPartsLoader = false;
                    }).error(function() {
                    var e;
                    deferred.reject(e);
                });
                return deferred.promise;
            }
        }
    ]);
});