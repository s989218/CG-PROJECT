define(['angular', '../sample-module', 'jquery', 'datatablesNetMin', 'datatablesNet', 'fileSaver', 'datatablesNetRowReorder', 'datatablesNetResponsive'], function(angular, controllers) {
    'use strict';
    controllers.controller('updateMaintenanceDataCtrl', ['$scope', '$http', '$location', '$state', '$q','$rootScope', function($scope, $http, $location, $state, $q, $rootScope) {

    	$scope.tmsToggleStatus = true;
		if($rootScope.businessSegment === "TMS"){
			$("#mainDivSection").hide();
			$scope.tmsToggleStatus = false;
		}
        var parts, repairs, services, aux, curRowIndex;
        jQuery.fn.center = function() {
            this.css({
                top: ($(window).outerHeight()) / 2,
                left: ($(window).outerWidth()) / 2
            });
            return this;
        };
        
        var modal = document.getElementById('maintenanceModalID');
        // Get the button that opens the modal

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("maintenanceClose")[0];

        // When the user clicks the button, open the modal


        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        }

        $scope.flag = true;
        $(".overlay").css("height", $(document).height());
        $(".loading").center();
        $(".loading").show();
        $(".overlay").show();
        $scope.validationDismiss = function() {
            document.getElementById('maintenanceModalID').style.display = "none";
            $(".loading").hide();
            $(".overlay").hide();
        }
        $scope.updateData = {};
        $('#showAddEditor').hide();
        $http.get("connect/fms/getAllMaintenanceData").then(function(response) {
            $scope.updateData = response.data;
            $scope.updateMaintenanceData();
        }).then(function() {
            resizeAll();
        });
        $('table[data-table-name="update-Maintenance-Data"] tfoot td').each(function() {
            var title = $(this).text();
            if (title !== '') {
                $(this).html('<input type="text" placeholder="Search ' + title + '" size="8" />');
            }
        });
        var $window     = $(window);
        var windowsize  = $window.width();
        var dtOptions;
        if (windowsize > 767) {
            dtOptions = {
        		rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: false,
                "bPaginate": true,
                "bSort": true,
                "bFilter": true,
                "aLengthMenu": [
                    [10, 20, 50, 100, -1],
                    [10, 20, 50, 100, "All"]
                ],
                "iDisplayLength": 10,
                "aoColumns": [{
                    "bSortable": false,
                    "sWidth": "5%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "5%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "7%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "7%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "7%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "7%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "7%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "10%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "10%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "10%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "5%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "5%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "15%",
                    sClass: "tHeadMaintenance"
                } ] 
            };
        } else {
            dtOptions = {
        		rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: true,
                "bPaginate": true,
                "bSort": true,
                "bFilter": true,
                "aLengthMenu": [
                    [10, 20, 50, 100, -1],
                    [10, 20, 50, 100, "All"]
                ],
                "iDisplayLength": 10,
                "aoColumns": [{
                    "bSortable": false,
                    "sWidth": "5%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "5%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "7%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "7%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "7%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "7%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "7%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "10%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "10%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "10%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "5%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "5%",
                    sClass: "tHeadMaintenance"
                }, {
                    "bSortable": true,
                    "sWidth": "15%",
                    sClass: "tHeadMaintenance"
                } ]   
            };
        }
        
        var updateMaintenanceTable = $('table[data-table-name="update-Maintenance-Data"]').DataTable(dtOptions);

        // Apply the search
        updateMaintenanceTable.columns().every(function() {
            var that = this;

            $('input', this.footer()).on('keyup change', function() {
                if (that.search() !== this.value) {
                    that
                        .search(this.value)
                        .draw();
                }
            });
        });
        $scope.updateMaintenanceData = function() {
            if ($scope.flag === true) {
                $(".loading").hide();
                $(".overlay").hide();
            } else {
                $(".overlay").css("height", $(document).height());
                $(".overlay").show();
            }
            $('table[data-table-name="update-Maintenance-Data"]').dataTable().fnClearTable();
            angular.forEach($scope.updateData, function(data) {
                $('table[data-table-name="update-Maintenance-Data"]').dataTable().fnAddData([
                    "<input type='checkbox' style='width:20px;'>",
                    data.id,
                    data.policy,
                    data.policyAggr,
                    data.level,
                    data.hours,
                    data.age,
                    data.parts,
                    data.repairs,
                    data.services,
                    data.manpower,
                    data.aux,
                    data.total
                ], false);
            });
            $('table[data-table-name="update-Maintenance-Data"]').dataTable().fnDraw(true);
        };
        $('body').on("click", ".updateData", function() {
            var curRowIndex = $(this).parents("tr").index() + 1;
            parts = $("#update-Maintenance-Data").find("tr:nth-child(" + curRowIndex + ")").find("td:eq(6)").find("input[class='updateParts']").val();
            repairs = $("#update-Maintenance-Data").find("tr:nth-child(" + curRowIndex + ")").find("td:eq(7)").find("input[class='updateRepairs']").val();
            services = $("#update-Maintenance-Data").find("tr:nth-child(" + curRowIndex + ")").find("td:eq(8)").find("input[class='updateServices']").val();
            aux = $("#update-Maintenance-Data").find("tr:nth-child(" + curRowIndex + ")").find("td:eq(10)").text();
        });

        $('body').on("change", ".updateParts", function() {

            curRowIndex = $(this).parents("tr").index() + 1;
            parts = $("#update-Maintenance-Data").find("tr:nth-child(" + curRowIndex + ")").find("td:eq(6)").find("input[class='updateParts']").val();
            repairs = $("#update-Maintenance-Data").find("tr:nth-child(" + curRowIndex + ")").find("td:eq(7)").find("input[class='updateRepairs']").val();
            services = $("#update-Maintenance-Data").find("tr:nth-child(" + curRowIndex + ")").find("td:eq(8)").find("input[class='updateServices']").val();
            aux = $("#update-Maintenance-Data").find("tr:nth-child(" + curRowIndex + ")").find("td:eq(10)").text();
            total = parseFloat(parts) + parseFloat(repairs) + parseFloat(services) + parseFloat(aux);
        });

        $scope.addData = function(input) {
            var checkedNumber = 0;
            $('#showAlert').hide();
            $(".resetBtn").show();
            $scope.action = input;
            $(".headingM").html('Add Maintenance Data');
            var data = $("#update-Maintenance-Data").dataTable().fnGetNodes();
            $(data).each(function() {
                var checkData = $(this).find("td:eq(0)").find("input[type='checkbox']").prop("checked");
                if (checkData) {
                    checkedNumber = checkedNumber + 1;
                }
            });
            if (checkedNumber > 1) {
                $(".loading").hide();
                $scope.funcAlert("You can select only one row.");
                $(".okButton").show();
                $(".yesBtn").hide();
                $(".noBtn").hide();
                return;
            } else if (checkedNumber === 1) {
                $scope.dataClearAction = 'AE';
                $scope.clearData();
                $scope.test = false;
                $scope.hoursTest = true;
                var checkedInput = $(".updateMaintenanceDataTable #update-Maintenance-Data tbody tr").find('input[type="checkbox"]:checked');
                var policyNo = $(checkedInput).parents("tr").find("td:eq(2)").text();
                var policyAggr = $(checkedInput).parents("tr").find("td:eq(3)").text();
                $scope.policyNo = policyNo;
                $scope.policyAggr = policyAggr;
                document.getElementById('maintenanceModalID').style.display = "block";
            } else {
                $scope.dataClearAction = 'AN';
                $scope.clearData();
                $scope.test = true;
                $scope.hoursTest = true;
                document.getElementById('maintenanceModalID').style.display = "block";
            }
        };
        $scope.editData = function(input) {

            var checkedNumber = 0;
            $(".resetBtn").hide();
            $scope.action = input;
            $(".headingM").html('Update Maintenance Data');
            $scope.clearData();

            var data = $("#update-Maintenance-Data").dataTable().fnGetNodes();
            $(data).each(function() {
                var checkData = $(this).find("td:eq(0)").find("input[type='checkbox']").prop("checked");
                if (checkData) {
                    checkedNumber = checkedNumber + 1;
                }
            });
            if (checkedNumber > 1) {
                $(".loading").hide();
                $scope.funcAlert("You can select only one row.");
                $(".okButton").show();
                $(".yesBtn").hide();
                $(".noBtn").hide();
                return;
            } else if (checkedNumber === 1) {
                $scope.dataClearAction = 'U';
                $scope.test = false;
                $scope.hoursTest = false;
                var checkedInput = $(".updateMaintenanceDataTable #update-Maintenance-Data tbody tr").find('input[type="checkbox"]:checked');
                var policyNo = $(checkedInput).parents("tr").find("td:eq(2)").text();
                var policyAggr = $(checkedInput).parents("tr").find("td:eq(3)").text();
                var level = $(checkedInput).parents("tr").find("td:eq(4)").text();
                var hours = $(checkedInput).parents("tr").find("td:eq(5)").text();
                var age = $(checkedInput).parents("tr").find("td:eq(6)").text();
                var parts = $(checkedInput).parents("tr").find("td:eq(7)").text();
                var repairs = $(checkedInput).parents("tr").find("td:eq(8)").text();
                var services = $(checkedInput).parents("tr").find("td:eq(9)").text();
                var manpower = $(checkedInput).parents("tr").find("td:eq(10)").text();
                var aux = $(checkedInput).parents("tr").find("td:eq(11)").text();
                var total = $(checkedInput).parents("tr").find("td:eq(12)").text();
                $scope.policyNo = policyNo;
                $scope.policyAggr = policyAggr;
                $scope.level = level;
                $scope.hours = hours;
                $scope.age = age;
                $scope.parts = parts;
                $scope.repairs = repairs;
                $scope.services = services;
                $scope.manpower = manpower;
                $scope.aux = aux;
                $scope.total = total;
                document.getElementById('maintenanceModalID').style.display = "block";

            } else {
                $(".loading").hide();
                $scope.funcAlert("No row selected to edit.");
                $(".okButton").show();
                $(".yesBtn").hide();
                $(".noBtn").hide();
                return;
            }



        };

        $scope.funcAlert = function(input) {
            $(".lightBox").center();
            $(".lightBox,.overlay").show(500);
            $("#alertMsg b").text(input);
        }
        $scope.funcSave = function(input) {
            $(".saveBox").center();
            $(".saveBox,.overlay").show(500);
            $("#saveMsg b").text(input);
        }
        $(".closePop").click(function() {
            $(".lightBox,.overlay").hide(500);
            $(".saveBox,.overlay").hide(500);
        });

        $(".okButton").click(function() {
            $(".lightBox,.overlay").hide(500);
            $(".saveBox,.overlay").hide(500);
        });

        $scope.deleteData = function() {
            var finalData = [];
            $(".overlay").css("height", $(document).height());
            $(".overlay").show();
            $(".loading").show();
            var data = $("#update-Maintenance-Data").dataTable().fnGetNodes();
            $(data).each(function() {
                var checkData = $(this).find("td:eq(0)").find("input[type='checkbox']").prop("checked");
                if (checkData) {
                    var policy = $(this).find("td:eq(2)").text();
                    var hours = $(this).find("td:eq(5)").text();
                    finalData.push(policy + "~" + hours);
                }
            });
            if (finalData.length > 0) {
                $(".loading").hide();
                $(".yesBtn").attr("data-id", finalData);
                $scope.funcAlert("Do you really want to delete the data?");
                $(".yesBtn").show();
                $(".noBtn").show();
                $(".okButton").hide();
                return;
            } else {
                $(".loading").hide();
                $scope.funcAlert("No row selected to delete.");
                $(".okButton").show();
                $(".yesBtn").hide();
                $(".noBtn").hide();
                return;
            }
        };

        $(".noBtn").click(function() {
            $(".lightBox,.overlay").hide(500);
            $(".saveBox,.overlay").hide(500);
        });

        $(".yesBtn").click(function() {
            $(".lightBox,.overlay").hide(500);
            $(".saveBox,.overlay").hide(500);
            $(".overlay").show();
            $(".loading").show();
            var data = $(this).attr("data-id");
            var finalData = data.split(",");
            $http.post("connect/fms/deleteFromMaintenanceData", JSON.stringify({
                "data": finalData
            })).success(function(response) {
                var msg = response;
                if (msg.toUpperCase() === 'SUCCESS') {
                    $http.get("connect/fms/getAllMaintenanceData").then(function(response) {
                        $scope.flag = false;
                        $scope.updateData = response.data;
                        $(".showAddEditor").hide();
                        $(".overlay").hide();
                        $(".loading").hide();
                        $scope.funcSave("Data deleted successfully.");
                        $(".okButton").show();
                        $scope.updateMaintenanceData();
                    });
                } else {
                    $scope.funcSave("Error while performing the operation. Please try again.");
                    $(".okButton").show();
                    $(".loading").hide();
                }

            });
        });

        $scope.saveData = function() {
            $(".errMsg").html('');
            var jsonData = [];
            var item = {};



            if (isNullCheck($scope.policyNo, 'CHAR') === "" || isNullCheck($scope.hours, 'NUM') === "") {
                $(".errMsg").html('Please enter mandatory field');
                return;
            } else {
                if (!isAlphanumeric(isNullCheck($scope.policyNo, 'CHAR'))) {
                    $(".errMsg").html('Please enter valid Policy');
                    return;
                } else if (!isAlphanumeric(isNullCheck($scope.policyAggr, 'CHAR'))) {
                    $(".errMsg").html('Please enter valid Policy Aggr');
                    return;
                } else if (!isAlpha(isNullCheck($scope.level, 'CHAR'))) {
                    $(".errMsg").html('Please enter valid Level');
                    return;
                } else if (!isNumber(isNullCheck($scope.hours, 'NUM'))) {
                    $(".errMsg").html('Please enter valid Hours');
                    return;
                } else if (!isNumber(isNullCheck($scope.age, 'NUM'))) {
                    $(".errMsg").html('Please enter valid Age');
                    return;
                } else if (!isDecimal(isNullCheck($scope.parts, 'NUM'))) {
                    $(".errMsg").html('Please enter valid Parts');
                    return;
                } else if (!isDecimal(isNullCheck($scope.repairs, 'NUM'))) {
                    $(".errMsg").html('Please enter valid Repairs');
                    return;
                } else if (!isDecimal(isNullCheck($scope.services, 'NUM'))) {
                    $(".errMsg").html('Please enter valid Services');
                    return;
                } else if (!isDecimal(isNullCheck($scope.manpower, 'NUM'))) {
                    $(".errMsg").html('Please enter valid Manpower');
                    scrollTo(0, 0);
                    return;
                } else if (!isDecimal(isNullCheck($scope.aux, 'NUM'))) {
                    $(".errMsg").html('Please enter valid AUX');
                    scrollTo(0, 0);
                    return;
                } else {
                    var url;
                    if ($scope.action === 'E') {
                        url = "connect/fms/updateMaintenanaceData"
                    } else if ($scope.action === 'A') {
                        url = "connect/fms/insertToMaintenanceData";
                    } else {
                        $(".errMsg").html('Please select action to perform');
                        return false;
                    }
                    item["policy"] = isNullCheck($scope.policyNo, 'CHAR');
                    item["policyAggr"] = isNullCheck($scope.policyAggr, 'CHAR');
                    item["hrs"] = isNullCheck($scope.hours, 'NUM');
                    item["level"] = isNullCheck($scope.level, 'CHAR');
                    item["age"] = isNullCheck($scope.age, 'age');
                    item["parts"] = parseFloat(isNullCheck($scope.parts, 'NUM'));
                    item["repairs"] = parseFloat(isNullCheck($scope.repairs, 'NUM'));
                    item["services"] = parseFloat(isNullCheck($scope.services, 'NUM'));
                    item["manpower"] = parseFloat(isNullCheck($scope.manpower, 'NUM'));
                    item["aux"] = parseFloat(isNullCheck($scope.aux, 'NUM'));
                    var total = parseFloat(isNullCheck($scope.parts, 'NUM')) + parseFloat(isNullCheck($scope.repairs, 'NUM')) + parseFloat(isNullCheck($scope.services, 'NUM')) + parseFloat(isNullCheck($scope.manpower, 'NUM')) + parseFloat(isNullCheck($scope.aux, 'NUM'));
                    item["total"] = total;
                    $scope.flag = false;
                    $(".showAddEditor").hide();
                    $(".loading").center();
                    $(".overlay").css("height", $(document).height());
                    $(".overlay").show();
                    $(".loading").show();

                    jsonData.push(item);
                    $http.post(url, JSON.stringify({
                        "data": jsonData
                    })).success(function(response) {
                        var msg = response;
                        if (msg.toUpperCase() === 'SUCCESS') {
                            $http.get("connect/fms/getAllMaintenanceData").then(function(response) {

                                $scope.updateData = response.data;
                                $(".showAddEditor").hide();
                                $(".loading").hide();
                                $scope.funcSave("Data saved successfully.");
                                $(".okButton").show();
                                $scope.updateMaintenanceData();
                            });
                        } else {
                            $scope.funcSave("Error while performing the operation. Please try again.");
                            $(".loading").hide();
                            $(".okButton").show();
                        }
                    });
                }
            }
            $("#maintenanceModalID").hide();

        };

        $scope.calTotal = function() {
            var totalCheck = parseFloat(isNullCheck($scope.parts, 'NUM')) + parseFloat(isNullCheck($scope.repairs, 'NUM')) + parseFloat(isNullCheck($scope.services, 'NUM')) + parseFloat(isNullCheck($scope.manpower, 'NUM')) + parseFloat(isNullCheck($scope.aux, 'NUM'));
            $scope.total = (isNaN(totalCheck) === true) ? 0 : totalCheck;
        };

        $scope.clearData = function() {
            $(".errMsg").html('');
            if ($scope.dataClearAction === 'AE') {
                $scope.level = "";
                $scope.hours = "";
                $scope.age = "";
                $scope.parts = "";
                $scope.repairs = "";
                $scope.services = "";
                $scope.manpower = "";
                $scope.aux = "";
                $scope.total = "";
            } else {
                $scope.policyNo = "";
                $scope.policyAggr = "";
                $scope.level = "";
                $scope.hours = "";
                $scope.age = "";
                $scope.parts = "";
                $scope.repairs = "";
                $scope.services = "";
                $scope.manpower = "";
                $scope.aux = "";
                $scope.total = "";
            }

        };
        $(".exportToExcelMaintenance").click(function() {
            download('/connect/fms/exportMaintenanceData', 'Ibas Dtl');
        });

        function download(url, data, defaultFileName) {
            var deferred = $q.defer();
            $http.post(url, data, {
                responseType: "arraybuffer"
            }).success(
                function(data, status, headers) {
                    var type = headers('Content-Type');
                    var disposition = headers('Content-Disposition');
                    if (disposition) {
                        var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                        if (match[1])
                            defaultFileName = match[1];
                    }
                    defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                    var blob = new Blob([data], {
                        type: type
                    });
                    saveAs(blob, defaultFileName);
                    deferred.resolve(defaultFileName);
                }).error(function() {
                var e;
                deferred.reject(e);
            });
            return deferred.promise;
        }

    }]);
});