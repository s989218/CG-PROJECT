define(['angular','../sample-module','jquery','datatablesNet'], function  (angular,controllers,jquery,datatablesNet,exportToExcel,webAnimation) 
 {
    'use strict';
    controllers.controller('MetricsCtrl', ['$scope','$http', '$location','$state','$rootScope','$timeout','countryLevelDataNetworkService','LoaderService', function ($scope, $http, $location, $state,$rootScope,$timeout,countryLevelDataNetworkService,LoaderService) {
			$scope.selected = 0;
			jQuery.fn.center = function() {
	            this.css({top: ($(window).outerHeight()) / 2,left: ($(window).outerWidth()) / 2});
				return this;
			};
			
	    	$(".loading").center();
			function loaderOps(state){
				LoaderService.loaderOps(state);
			}
        
            $scope.navToggle = function () {
                var x = document.getElementById("vertical-tab-list");
                if (x.className === "layout__item vertical-tab-list") {
                    x.className += " responsive";
                    $('#pm_map').addClass('pm-map-margin');
                    $('.ol-button1').addClass('ol-button-margin');
                    $('.ol-button2').addClass('ol-button-margin');
                } else {
                    x.className = "layout__item vertical-tab-list";
                    $('#pm_map').removeClass('pm-map-margin');
                    $('.ol-button1').removeClass('ol-button-margin');
                    $('.ol-button2').removeClass('ol-button-margin');
                }
                
                if ($("#vertical-tab-list").hasClass("responsive")) {
                    $("button[name='g_list']").css("display", "none");
                } else {
                    $("button[name='g_list']").css("display", "block");
                }
            }
            
            $(document).ready(function () {
                if ($rootScope.isMobile === true) {
                    $('#project_phases_vertical_tabs').attr("bare","true");
                } else {
                    $('#project_phases_vertical_tabs').removeAttr("bare");  
                }
            })
        
			countryLevelDataNetworkService.getMetricsDropdownsData().then(function(response){
				$scope.safeApply(function(){
					$rootScope.regionDropdownBean = response; 
				});
				setTimeout(function(){
					$("select:not(#depRegionSearch,#depSiteCustCountrySearch,#techRegionSearch,#deptechSiteCustCountrySearch,#depsiteEntriesSearch,#siteRegionSearch,#depSitePenSearch,#penetration_report,#dunsRegionSearch,#depdunsSiteSearch,#depDunsEntriesSearch,#depSegmentCountrySearch,#segmentRegionSearch,#topSitesRegionSearch, .dataTables_length select,#ibo_percentage,#topSitesRegionSearch,#topSitesCountrySearch,#topSitesServiceManagerSearch,#topSitesAccountManagerSearch,#accountManagerDropdownBean,#marketIndustryDropdownBean)").multipleSelect({
						filter: true
					},200);
				});						
				resizeAll();
				loaderOps(false);
	    	});
        
            $rootScope.getGEDunsDropdownsData = function () {
                var item = {};
                item["marketIndustry"]  = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";

                countryLevelDataNetworkService.getDunsDropdownsData(JSON.stringify(item)).then(function(response){
                    $scope.safeApply(function(){
                        $scope.getdunsData(response);
                    });
                });
            }
            
            $timeout(function() {
                if (!$rootScope.marketIndustry) {
                    $rootScope.getGEDunsDropdownsData();
                }
            }, 5000); 
            
            if ($rootScope.marketIndustry) {
                $timeout(function() {
                    if($rootScope.marketIndustry === "^Industrial$" || $rootScope.marketIndustry === "^Onshore/Offshore Production$") {
                        $('#indep_segment').addClass('visuallyhidden');
                    } else {
                        $('#indep_segment').removeClass('visuallyhidden');
                    }
                    
                    $rootScope.iboByRegionData(false, false);
                    $rootScope.regionLevelSearchData();
                    $rootScope.getGEDunsDropdownsData();
                });   
            }
        
			window.addEventListener('px-tab-changed', pxTabCallback, false);
                                    
            function pxTabCallback(event){
				var selectedTab = parseInt(event.target.selected);
				Polymer.dom().querySelector('px-tab-pages').selected = selectedTab;
                
                if(selectedTab  !== 0 && selectedTab  !== 1) {
                    $("#switchHistory").show();
                    
                    if(selectedTab === 2) {
                       $rootScope.regionLevelSearchData();
                    }
                    
                    if(selectedTab === 7) {
                        $("#marketIndustryDropdownBean option[value*='Industrial']").prop('disabled',true);
                        $("#marketIndustryDropdownBean option[value*='Onshore/Offshore Production']").prop('disabled',true);
                    } else {
                        $("#marketIndustryDropdownBean option[value*='Industrial']").prop('disabled',false);
                        $("#marketIndustryDropdownBean option[value*='Onshore/Offshore Production']").prop('disabled',false);
                    }
                } else {
                    $("#switchHistory").hide();
                }
			}
        
            $("#tabtitle").on( "click", function() {
                $rootScope.iboByRegionData(false, true);
            });
        
            var checkStatus = setInterval(function() {
                if(Polymer.dom().node.readyState==='complete'){
                    Polymer.dom().querySelector('px-tab-pages').selected = 0;
                    Polymer.dom().querySelector('px-tab-set').selected = 0;
                    clearInterval(checkStatus);
                }
            },10); 
            
			
	}]);
});