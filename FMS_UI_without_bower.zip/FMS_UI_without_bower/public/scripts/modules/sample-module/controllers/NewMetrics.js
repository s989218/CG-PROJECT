define(['angular', '../sample-module', 'jquery', 'datatablesNetMin', 'datatablesNet', 'multiselectdrpdwn', 'jqueryMultiSelect'],
    function(angular, controllers, jquery, datatablesNetMin, datatablesNet, multiselectdrpdwn, jqueryMultiSelect) {
        'use strict';
        controllers.controller('NewMetricsCtrl', ['$scope', '$rootScope', '$timeout', function($scope, $rootScope, $timeout) {
            if ($rootScope.businessSegment === "TMS") {
                $("#serviceMetrics").hide();
            }
            if ($rootScope.roleId === '10' || $rootScope.roleId === '15' || $rootScope.roleId === '16') {
                $("#orderMetrics").hide();
            }

            var yearQData = getYearQuarter();
            $rootScope.ibo_equipmentquarteryear = yearQData.ibo_equipmentquarteryear;
            $rootScope.ibo_equipmentyear = yearQData.ibo_equipmentyear;
            $rootScope.ibo_orderquarteryear = yearQData.ibo_orderquarteryear;
            $rootScope.currentYearQuarter = yearQData.currentYearQuarter;
            
            $scope.safeApply = function(fn) {
                $rootScope.safeApply(fn);
            }
            
            $timeout(function() {
                if (!$rootScope.accountManager && !$rootScope.marketIndustry) {
                    $rootScope.ibMetricsSearchData();
                    $rootScope.iboMetricsSearchData();
                    $rootScope.orderMetricsSearchData();
                    $rootScope.dmMetricsSearchData();
                    $rootScope.outageMetricsSearchData();
                }
            }, 5000); 
            
            if ($rootScope.accountManager || $rootScope.marketIndustry) {
                $timeout(function() {
                    $rootScope.ibMetricsSearchData();
                    $rootScope.iboMetricsSearchData();
                    $rootScope.orderMetricsSearchData();
                    $rootScope.dmMetricsSearchData();
                    $rootScope.outageMetricsSearchData();
                }, 5000);   
            }

            /* Accordion Effects */
            $scope.resizeMetricCharts = function(metricDiv) {
                $('#' + metricDiv).siblings('#techReg').toggle(250, function() {
                    /* Scrolls to Top of Div */
                    if ($('#' + metricDiv).siblings('#techReg').is(':visible')) {
                        $(window).scrollTop($('#' + metricDiv).offset().top, 500);
                    }
                });
                $scope.safeApply(function() {
                    $scope[metricDiv + '_expanded'] = !$scope[metricDiv + '_expanded'];
                });
            }
            
            setTimeout(function() {
                if ($(window.location.hash).length === 1) {
                    $('html,body').animate({
                            scrollTop: $(window.location.hash).offset().top
                        },
                        'slow');
                }
            }, 1000);

        }]);
    });