
define(['angular','../../sample-module','jquery', 'datatablesNetMin', 'datatablesNet', 'multiselectdrpdwn','jqueryMultiSelect'], 
function (angular,controllers) 
{
	'use strict';
	controllers.controller('OrderTechnoRegionController', ['LoaderService', '$rootScope','$scope','$state','NetworkCallService','OrderTechnoRegionService','OrderTableService','CreateHighChartService','$timeout','$http','$q',
	function (LoaderService, $rootScope, $scope,$state,NetworkCallService,OrderTechnoRegionService,OrderTable,CreateHighChartService,$timeout,$http,$q) 
	{	
		var chart;
		$rootScope.ibo_orderquarteryear=sessionStorage.ibo_orderquarteryear;
		var orderKeys =['meTier4','meDMTier3','smSegmentMapping','countryName','pmProductMapping','serviceType','endUserName','region','geCustomerDunsName','state'];
		$('#container2,#country_chart').css('min-width',$('section').innerWidth()-50);
		$('.backClass').click(function(){
			$state.go('NewMetrics');
		});
		jQuery.fn.center = function() {
			this.css({top: ($(window).outerHeight()) / 2,left: ($(window).outerWidth()) / 2});
			return this;
		};
		$(".loading").center();
		function loaderOps(state){
			LoaderService.loaderOps(state);
		}
		$scope.regionSelected = true;
		$scope.errorIndicator = false;
		loaderOps(true);
		$scope.safeApply =function(fn){
			$timeout(fn);
		}
		var yearQData = getYearQuarter();
		$rootScope.ibo_orderquarteryear = yearQData.ibo_orderquarteryear;
		var defaultData = {};
		$scope.selected = 0;
		function checkParent(props){
			if(props.ngModel==='depSearch.regions'){
				if($scope.depSearch.regions.length > 0){
					$('select.dependentFilter[id="siteCustCountrySearch"]').prop('disabled','false');
					$('select.dependentFilter[id="siteCustCountrySearch"]').siblings().children().removeClass('disabled');
				}
				else{
					$('select.dependentFilter[id="siteCustCountrySearch"]').prop('disabled','true');
					$('select.dependentFilter[id="siteCustCountrySearch"]').siblings().children().addClass('disabled');
				}
			}

		}
		$scope.getCountries=function(){
			$('#depRegionSearch').removeClass('boxShadow');
			var country = $("select.dependentFilter[id='depRegionSearch'] option:selected").text();;
			if(country!==null && country!=='Select Region'){
                var item = {};
                item["regionName"]=country;
                item["businessSegment"]=$rootScope.businessSegment;
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
				NetworkCallService.getCountries(JSON.stringify(item)).then(function(response){
					var selectOption='', countryName='';
					$timeout(function(){							
						$('.errorIndicator').hide(100);
						_.forEach(response, function(response){
							countryName = response.countryName;
							selectOption = selectOption + '<option value="'+countryName+'">'+countryName+'</option>'
						})
					})
					.then(function(){
						var scriptTag='<script>$("select#depSiteCustCountrySearch").multipleSelect({filter: true, selectAll: false});</script>'
							$timeout(function(){
								/* Show Multiselect */
								$('#depSiteCustCountrySearch').empty().append(selectOption).append(scriptTag);
								$('div.countrySelectBtn').show(100);
								$('select.dependentFilter[id="depSiteCustCountrySearch"]').prop('disabled','false');
								$('select.dependentFilter[id="depSiteCustCountrySearch"]').siblings().children().removeClass('disabled');
								$('button#placeboMultiSelect').hide(100);									
							});
					});
				});
			}
			else
			{
				$('select.dependentFilter[id="depSiteCustCountrySearch"]').prop('disabled','true');
				$('select.dependentFilter[id="depSiteCustCountrySearch"]').siblings().children().addClass('disabled');
				$timeout(function(){
					$scope.regionSelected = true;
				});
			}
		}
		function getSelectedValue(id){
			var selector = "select.dependentFilter[id='"+id+"']";
			if(id==='depRegionSearch' && $(selector).val() != null){
				return ($(selector + " > option:eq("+$(selector).val()+")").text());
			}
			else
			{
				if($(selector).val()!==undefined){
					var values = [];
					_.forEach($(selector).val(), function(choice){
						values.push(choice);
					});
					return values.join("|");
				}
				else
					return "";
			}
		}
		function retrieveCountryFilterData(key){
			var selector = $("select.dependentFilter[name='"+key+"']");
			var selectorValue = selector.val();
			if(selectorValue===undefined||!selectorValue){
				selectorValue = "";
			}
			else if(Array.isArray(selectorValue)){
				selectorValue = '^'+(selectorValue.join("$|^"))+'$';
			}
			else if(!isNaN(selectorValue))
			{
				selectorValue = '^'+selectorValue+'$';
			}
			return selectorValue;
			
		}			


		var updateTopCustDatatable = function(response){
			$rootScope.testData = null;
			$rootScope.totalCount = null;
			var serviceData= null;
			var techRegionData=response.technologyDataBean;		
			var regionWithCount , chartId, dtData;
			if(arguments.length>1 && arguments[1] ===true){
				if(techRegionData.length>0){
					dtData = OrderTechnoRegionService.processCountryTable(techRegionData);
					OrderTechnoRegionService.initTable(dtData['dataArr'],dtData['columns'],'IB-by-Top-Cust-Country-Data',dtData['regionCount']);
					serviceData = (OrderTechnoRegionService.countryDataProcess(response.technologyDataBean));
					$('#country_chart').outerWidth($('main').width());
					chartId = 'country_chart';
					$scope.safeApply(function(){
						$scope.dep_testData = serviceData['testData'];
						$scope.dep_totalCount = serviceData['totalCount'];
					});
					$timeout(function(){
						$('#countryChart').outerWidth($('#countryLevel').innerWidth());
						$('#country_chart').outerWidth($('#countryChart').innerWidth()-50);
						$scope.createColumnChart(serviceData['technology'],serviceData['highchartData'],chartId,serviceData['colorCodes']);
					},500);
					$timeout(function(){
						$scope.safeApply(function(){
							$scope.dep_custChartExp = true;
							$scope.dep_custDataExp = true;
							$('.ctrError').hide(100);
							$('.ctrView').show(100);
						});
						$('#countryChart').height($('#country_chart').outerHeight()+50);
						$('#countryTable > #tableDivision').height($('#IB-by-Top-Cust-Country-Data_wrapper').outerHeight()+50);
						$('#countryChart > #techRegionChart').outerHeight($('#countryChart').height());
						$('#countryTable').outerHeight($('#countryTable > #tableDivision').outerHeight()+20);		
					},250);
					$('.countryTableDiv').show();
				}
				else{
					$('.ctrError').show(100).css('display','flex');
					$('.ctrView').hide(100);
				}
			}
			else{
				if(techRegionData.length>0){
					regionWithCount = OrderTechnoRegionService.getRegionWithCount(techRegionData);
					serviceData = (OrderTechnoRegionService.getTechnologyData($scope.productDropdownData,techRegionData,regionWithCount));
					chartId = 'container2';
					$scope.safeApply(function(){
						$scope.testData = serviceData['testData'];
						$scope.totalCount = serviceData['totalCount'];
					});
					dtData = OrderTechnoRegionService.processTable(techRegionData);
					OrderTechnoRegionService.initTable(dtData['dataArr'],dtData['columns'],'IB-by-Top-Cust-Data',dtData['regionCount']);
					$timeout(function(){
						$('#collapse3').height($('#container2').outerHeight()+50);
						$('#tableDivision').height($('#IB-by-Top-Cust-Data_wrapper').outerHeight()+50);
						$('#collapse3 > #techRegionChart').outerHeight($('#collapse3').height());
						$('#collapse4').outerHeight($('#collapse4 > #tableDivision').outerHeight()+20);
					},250);
					$scope.safeApply(function(){
						$scope.custChartExp = true;
						$('.regError').hide(100);
						$('.regView').show(100);
						$scope.custDataExp = true;
					});
					$('#collapse3,#collapse4').addClass('in');
					$scope.createColumnChart(serviceData['technology'],serviceData['chartData'],chartId,serviceData['colorCodes']);
					$('#tableDiv').show();
				}
				else{
					$('.regError').show(100).css('display','flex');
					$('.regView').hide(100);
				}
			}
			loaderOps(false);					
		}
		window.addEventListener('px-tab-changed', function(event){
			var selectedTab = parseInt(event.target.selected);
			Polymer.dom().querySelector('px-tab-pages').selected = selectedTab;
			if(selectedTab===0){
				$('.rstFltr').show()
			}
			else{
				$('.rstFltr').hide()
			}
		});

		$rootScope.dep_orderTechnoCountrySearchData = function(){
			var jsonData = [];
			var item = {};
			if((Object.keys($scope.depSearch)).indexOf('countryName')===-1){
				$scope.depSearch.countryName = ' ';
			}
			_.forEach(orderKeys, function(searchKey){
				item[searchKey] = retrieveCountryFilterData(searchKey);
			});
			item["businessSegment"]=$rootScope.businessSegment;
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
			jsonData.push(item);
			if(!((item['region'])==='') && !((item['region'])==='Select Region')){
				loaderOps(true);
				NetworkCallService.getOrdersCountry(jsonData).then(function(response){
					updateTopCustDatatable(response,true);
					resizeAll();				
					$('#countryTable, #countryChart').show();					
					loaderOps(false);
				});
			}
			else{
				$('#depRegionSearch').addClass("boxShadow");
				$('.errorIndicator').show(100);
			}
			// Raw data parameters
			$scope.regionOrderRawData = [];
			$scope.countryOrderRawData = [];
			$scope.flgOrderRegionRawData = false;
			$scope.flgCountryOrderRawData = false;
		}
		function setDropdowns(key, response){
			$scope.safeApply(function(){
				$scope[key] = response[key];
			});
		}
        
        $timeout(function() {
            if (!$rootScope.accountManager && !$rootScope.marketIndustry) {
                $rootScope.orderTechnoRegionDropdownsData();
                $rootScope.getOrderMetricsTechnoRegionData();
            }
        }, 5000);
         
        if ($rootScope.accountManager) {
            $timeout(function() {
                $rootScope.orderTechnoRegionDropdownsData();
                $rootScope.orderTechnoRegionSearchData();
            }, 5000);   
        } else {
            $timeout(function() {
                $rootScope.orderTechnoRegionDropdownsData();
                $rootScope.getOrderMetricsTechnoRegionData();
            }, 5000);
        }
        
        $rootScope.orderTechnoRegionDropdownsData = function() {
            var item = {};
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            
            NetworkCallService.getOrdersMetricsDropdownsData(JSON.stringify(item)).then(function(response){
                _.forEach(Object.keys(response), function(key){
                    setDropdowns(key, response)
                });
                $timeout(function(){
                    $("select:not(#depRegionSearch,#depSiteCustCountrySearch,#siteCustCountrySearch,#customerNameSearch,#IB-by-Top-Cust-Data_length select,#marketIndustryDropdownBean)").multipleSelect({
                        filter: true
                    });
                    $("select#siteCustCountrySearch,select#customerNameSearch").multipleSelect({
                        filter: true,
                        selectAll: false
                    });
                },200);
                resizeAll();
            });
        }

		function retrieveFilterData(key){
			var selector = $("select[name='"+key+"']");
			return (selector.val()===undefined||!selector.val())?"":'^'+selector.val().join("$|^")+'$';
		}

		$rootScope.orderTechnoRegionSearchData = function(){
			var item = {};
			_.forEach(orderKeys, function(searchKey){
				item[searchKey] = retrieveFilterData(searchKey);
			});
			loaderOps(true);
			var jsonData = [];	
			item["businessSegment"]=$rootScope.businessSegment;
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
			jsonData.push(item);
			NetworkCallService.getOrdersData(jsonData).then(function(response){
				$scope.responseData=response;
				updateTopCustDatatable(response);
				resizeAll();
			});
			// Raw data parameters
			$scope.regionOrderRawData = [];
			$scope.countryOrderRawData = [];
			$scope.flgOrderRegionRawData = false;
			$scope.flgCountryOrderRawData = false;
		}
        
		function createDefaultChart(response){
			var techRegionData=response.technologyDataBean;		
			var techRegionChartData = OrderTechnoRegionService.updateTechReg(techRegionData);
			var dtData = OrderTechnoRegionService.processTable(techRegionData);
			OrderTechnoRegionService.initTable(dtData['dataArr'],dtData['columns'],'IB-by-Top-Cust-Data',dtData['regionCount']);
			$timeout(function(){
				$('#collapse3').height($('#container2').outerHeight()+50);
				$('#tableDivision').height($('#IB-by-Top-Cust-Data_wrapper').outerHeight()+50);
				$('#collapse3 > #techRegionChart').outerHeight($('#collapse3').height());
				$('#collapse4').outerHeight($('#collapse4 > #tableDivision').outerHeight()+20);	
			},250);
			$scope.createColumnChart(techRegionChartData['technology'],techRegionChartData['regionWithCount'],'container2',techRegionChartData['colorCodes']);
			$('#tableDiv').show();
		}
		$scope.clearData = function(){
			loaderOps(true);
			$scope.safeApply(function(){
				$scope.custChartExp = true;
				$scope.custDataExp = true;
			});
			if(!defaultData['indep_filters'])
				NetworkCallService.getOrdersData(OrderTechnoRegionService.searchDataService()).then(function(response){
					defaultData['indep_filters'] = response;
					createDefaultChart(response);
				});
			else
			{
				createDefaultChart(defaultData['indep_filters']);
			}
			$('order-independent-filter').find('.ms-choice > span').html('');
			$('order-independent-filter').find('input[type="checkbox"]').attr('checked',false);
			$('order-independent-filter').find("select").val('')
			$('#depSiteCustCountrySearch').empty();
			$('.regError').hide(100);
			$('.regView').show(100);
			loaderOps(false);
			// Raw data parameters
			$scope.regionOrderRawData = [];
			$scope.countryOrderRawData = [];
			$scope.flgOrderRegionRawData = false;
			$scope.flgCountryOrderRawData = false;
		}
		$scope.dep_clearData = function(){
			$('order-dependent-filter').find('.ms-choice > span').html('');
			$('order-dependent-filter').find('input[type="checkbox"]').attr('checked',false);
			$('order-dependent-filter').find("select").val('');
			$('#depSiteCustCountrySearch').empty();
			$('#countryTable, #countryChart').hide();
			_.defer(function(){
				$('div.countrySelectBtn').hide(100);
				$('select.dependentFilter[id="depSiteCustCountrySearch"]').prop('disabled','true');
				$('select.dependentFilter[id="depSiteCustCountrySearch"]').siblings().children().addClass('disabled');
				$('button#placeboMultiSelect').show(100);	
				$('.ctrError').hide(100);
				$('.ctrView').show(100);
				$scope.dep_custChartExp = false;
				$scope.dep_custDataExp = false;
			});
			_.forEach(Object.keys($scope.depSearch), function(key){
				_.defer(function(){
					$scope[key] = null;
				});
			});
			$('#depRegionSearch').removeClass("boxShadow");
			$('.errorIndicator').hide();
			// Raw data parameters
			$scope.regionOrderRawData = [];
			$scope.countryOrderRawData = [];
			$scope.flgOrderRegionRawData = false;
			$scope.flgCountryOrderRawData = false;
		}


		/* Polymer Tab Initialization */
		var checkStatus = setInterval(function(){
			if(Polymer.dom().node.readyState==='complete'){
				Polymer.dom().querySelector('px-tab-pages').selected = 0;
				Polymer.dom().querySelector('px-tab-set').selected = 0;
				clearInterval(checkStatus);
			}
		},100);
		$scope.resizeTable = function(){
			$('#tableDivision').height($('#IB-by-tech-reg-Data').height());
			$('#countryLevel > #tableDivision').height($('#IB-by-Top-Cust-Country-Data').height());
			$('#countryLevel > .headerDiv').width($('#IB-by-Top-Cust-Country-Data').outerWidth()+20)
		}
        
        $rootScope.getOrderMetricsTechnoRegionData = function() {
            $timeout(function(){
                $scope.clearData();
                $timeout(function(){
                    loaderOps(false);
                },200);
            },500);    
        }
        
        $timeout(function(){
            $(document.body).off().on('change','#depRegionSearch',function(){
                $scope.getCountries();
            });
        },200);
		
		$scope.exportCharts = function(type) {
			$scope.exportChartOrder(type); 
		};
		$scope.excelDownload = function(id) {
			OrderTable.excelDownload(id); 
		};

		$scope.shwOrderRawData = function (tableId, methodCall) {
			var jsonData = [];
			var item = {};

			if (methodCall === 'OrderRegion') {
				_.forEach(orderKeys, function(searchKey){
					item[searchKey] = retrieveFilterData(searchKey);
				});

				if ($scope.regionOrderRawData === undefined)
					$scope.regionOrderRawData = [];

				$("#regOrderRawData").attr('style', 'display: block');
				item["businessSegment"]=$rootScope.businessSegment;
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
				jsonData.push(item);
				if ($scope.regionOrderRawData === undefined || $scope.regionOrderRawData.length === 0) {
					calOrderRawService(jsonData, tableId, methodCall);
					$scope.flgOrderRegionRawData = true;
				}

			} else {
				_.forEach(orderKeys, function(searchKey){
					item[searchKey] = retrieveCountryFilterData(searchKey);
				});

				if((item['region']) === '' || ((item['region']).includes('undefined')===false && ((item['region'])==='Select Region'))){
					$('#depRegionSearch').addClass("boxShadow");
					$('.errorIndicator').show(100);
					$("#flgCountryOrderCollapse").attr("aria-expanded","false");
					$scope.flgCountryOrderRawData = false;
					return false;
				}
				if ($scope.countryOrderRawData === undefined)
					$scope.countryOrderRawData = [];

				$("#cntryOrderRawData").attr('style', 'display: block');
				item["businessSegment"]=$rootScope.businessSegment;
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
				jsonData.push(item);
				if ($scope.countryOrderRawData === undefined || $scope.countryOrderRawData.length === 0) {
					calOrderRawService(jsonData, tableId, methodCall);
					$scope.flgCountryOrderRawData = true;
				}

			}
		};

		function calOrderRawService (jsonData, tableId, methodCall) {
			loaderOps(true);
			$http.post("connect/fms/getRawDataIBOPage/"+"ordersTechReg",JSON.stringify({"data":jsonData})).then(function(response){
				$scope.orderColumnHeaders = response.data.OrdersColumnHeaders;
				$scope.rawOrderData = response.data.OrdersTechRawData;

				if (methodCall === 'OrderRegion')
					$scope.regionOrderRawData = $scope.rawOrderData;
				else
					$scope.countryOrderRawData = $scope.rawOrderData;

				if ($.fn.DataTable.isDataTable( '#'+tableId ) ) {
					$('#'+tableId).dataTable().api().clear().draw();
					$('#'+tableId).dataTable().api().destroy();
					$('#'+tableId).empty(); 
				}
				$('#'+tableId).DataTable({
					data: $scope.rawOrderData,
					"sPaginationType": "simple_numbers",
					"bFilter":true, 
					"retrieve": true, 
					"scrollX": false,
					"paging": true,
					columns:_.sortBy($scope.orderColumnHeaders,'row_id')
                });

				loaderOps(false);
			});
		}

		$scope.OrderRawDataExcelDownload = function(methodCall) {
			var jsonData = [];
			var item = {};
			var fileName = "Orders Technology data";
			if (methodCall === 'OrderRegion'){
				_.forEach(orderKeys, function(searchKey){
					item[searchKey] = retrieveFilterData(searchKey);
				});
			} else {
				_.forEach(orderKeys, function(searchKey){
					item[searchKey] = retrieveCountryFilterData(searchKey);
				});
			}
			item["businessSegment"]=$rootScope.businessSegment;
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
			jsonData.push(item);
			download("/connect/fms/exportRawDataMetrics/"+"ordersTechReg/" + fileName, jsonData, fileName);
		};

		function download(url,data ,defaultFileName) {
			var deferred = $q.defer();
			$http.post(url,JSON.stringify({"data":data}), { responseType: "arraybuffer" }).success(
					function (data, status, headers) {
						var type = headers('Content-Type');
						var disposition = headers('Content-Disposition');
						if (disposition) {
							var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
							if (match[1])
								defaultFileName = match[1];
						}
						defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
						var blob = new Blob([data], { type: type });
						saveAs(blob, defaultFileName);
						deferred.resolve(defaultFileName);                    
					}).error(function () {
						var e ;
						deferred.reject(e);
					});
			return deferred.promise;
		}

		$scope.createColumnChart = function(xSeries,ySeries,id,chartColors,state)
		{
			if(!state)
				state = null;
			Highcharts.setOptions({
				global: {
					useUTC: false,

				},
				lang: {
					decimalPoint: '.',
					thousandsSep: ','
				}
			});
			chart= new Highcharts.Chart({
				chart: {
					renderTo: id,
					type: 'column',
					events: {
						click: function () {
							if(state!==null)
								$state.go(state);
						}
					}
				},
				title: {
					text:''
				},
				colors: chartColors, 
				xAxis: {
					categories: xSeries
				},
				yAxis: {
					min: 0,
					title: {
						text: '$K'
					}
				},
				tooltip: {
					pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>${point.y:,.0f}K</b>({point.percentage:.2f}%)<br/>',
					shared: true
				},
				legend: {
					itemStyle: {
						color: 'black',
						fontWeight: 'normal',
						fontSize: '12px',
					}
				},
				plotOptions: {
					series: {
						stacking: 'normal',
						borderWidth:0,
						point: {
							events: {
								click: function () {
									$scope.refreshOrderMatrics(this.series.name, this.category, id);

								}
							}
						}
					}
				},
				credits: {
					enabled: false
				},
				series: ySeries,
                responsive: {
                    rules: [{
                        condition: {
                            maxWidth: 500
                        },
                        chartOptions: {
                            legend: {
                                align: 'center',
                                verticalAlign: 'bottom',
                                layout: 'horizontal'
                            },
                            yAxis: {
                                labels: {
                                    align: 'left',
                                    x: 0,
                                    y: -5
                                },
                                title: {
                                    text: null
                                }
                            },
                            subtitle: {
                                text: null
                            },
                            credits: {
                                enabled: false
                            }
                        }
                    }]
                }
			});
		}

		$scope.refreshOrderMatrics = function(name, category, id) {

			if(id === 'container2'){    
                $('order-independent-filter').find('.regionSearch .ms-choice > span').html(category);
                var countryValue="";
                $.each($(".regionSearch ul").find("span"), function () {
                    if($(this).text()===category){
                        countryValue=$(this).parent().find("input").attr('value');
                    $(this).parent().find("input").attr("checked",true);
                        
                    }
                });
                $('order-independent-filter').find("#regionSearch").val(countryValue);
                $('order-independent-filter').find("#regionSearch").multipleSelect("refresh");
                
				$('order-independent-filter').find('.pmProductMapping .ms-choice > span').html(name);
				$('order-independent-filter').find('.pmProductMapping input[value="'+name+'"]').attr('checked',true);
				$('order-independent-filter').find("#pmProductMapping").val(name);
				$('order-independent-filter').find("#pmProductMapping").multipleSelect("refresh");
				$rootScope.orderTechnoRegionSearchData();
			} else if(id === 'country_chart'){
				$('order-dependent-filter').find('.countrySelectBtn .ms-choice > span').html(category);
				$('order-dependent-filter').find('.countrySelectBtn input[value="'+category+'"]').attr('checked',true);
				$('order-dependent-filter').find("#depSiteCustCountrySearch").val(category);
				$('order-dependent-filter').find("#depSiteCustCountrySearch").multipleSelect("refresh");

				$('order-dependent-filter').find('.pmProductMappingSearch .ms-choice > span').html(name);
				$('order-dependent-filter').find('.pmProductMappingSearch input[value="'+name+'"]').attr('checked',true);
				$('order-dependent-filter').find("#pmProductMappingSearch").val(name);
				$('order-dependent-filter').find("#pmProductMappingSearch").multipleSelect("refresh");
				$rootScope.dep_orderTechnoCountrySearchData();
			}
		}

		$scope.exportChartOrder = function(type){
			if(type === 'JPEG')
			{
				chart.exportChart({type: 'image/jpeg', filename: 'Techno Region'}, {subtitle: {text:''}});
			}
			if(type === 'XLS'){
				chart.exportChart({type: 'application/vnd.ms-excel', filename: 'my-excel'}, {subtitle: {text:''}});
			}
		}
      }]);
});