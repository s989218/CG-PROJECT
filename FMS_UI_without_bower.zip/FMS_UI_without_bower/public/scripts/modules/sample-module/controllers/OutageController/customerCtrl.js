define(['angular','../../sample-module','jquery', 'datatablesNetMin', 'datatablesNet', 'multiselectdrpdwn','jqueryMultiSelect'], 
function (angular,controllers) 
{
	'use strict';
	controllers.controller('OutageTopCustomerCtrl', ['OutageCustomerService','OutageTechnoRegionService','OutageTableService','OutageChartService','LoaderService', '$rootScope','$scope','NetworkCallService','CreateHighChartService','$timeout','$http','$q',
	function (OutageCustomerService,OutageTechnoRegionService,OutageTableService,OutageChartService,LoaderService, $rootScope, $scope,NetworkCallService,CreateHighChartService,$timeout,$http,$q) 
	{
		var chart;
		$rootScope.ibo_equipmentyear=sessionStorage.ibo_equipmentyear;
		$scope.reg_Error = false;
		$('#container2,#country_chart').css('min-width',$('section').innerWidth()-50);
		$('.backClass').click(function(){
			$state.go('NewMetrics');
		});
		jQuery.fn.center = function() {
			this.css({top: ($(window).outerHeight()) / 2,left: ($(window).outerWidth()) / 2});
			return this;
		};
		$(".loading").center();
		function loaderOps(state){
			LoaderService.loaderOps(state);
		}

		$scope.regionSelected = true;
		$('.errorIndicator').hide();
		loaderOps(true);
		/* To Get Rid of Apply Already In Progress Error */
		$scope.safeApply =function(fn){
			$timeout(fn);
		}
		var defaultData = {};
		$scope.selected = 0;
		function checkParent(props){

			if(props.ngModel==='depSearch.regions'){
				if($scope.depSearch.regions.length > 0){
					$('select.dependentFilter[id="primaryCountrySearch"]').prop('disabled','false');
					$('select.dependentFilter[id="primaryCountrySearch"]').siblings().children().removeClass('disabled');
				}
				else{
					$('select.dependentFilter[id="primaryCountrySearch"]').prop('disabled','true');
					$('select.dependentFilter[id="primaryCountrySearch"]').siblings().children().addClass('disabled');
				}
			}

		}
		$scope.getCountries=function(){
			$('#depsalesRegionSearch').removeClass('boxShadow');
			var country = $("select.dependentFilter[id='depsalesRegionSearch']").val();
			var item = {};
			if(country!==null && country!=='Select Region'){
				item["regionName"]=country;
				item["type"]="outage";
                item["businessSegment"]=$rootScope.businessSegment;
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = "";
				NetworkCallService.getDMCountry(JSON.stringify(item)).then(function(response){
					var selectOption='', countryName='';
					$timeout(function(){							
						$('.errorIndicator').hide();
						_.forEach(response, function(response){
							countryName = response.countryName;
							selectOption = selectOption + '<option value="'+countryName+'">'+countryName+'</option>'
						})
					})
					.then(function(){
						var scriptTag='<script>$("select#depsalesCountrySearch").multipleSelect({filter: true, selectAll: false});</script>'
							$timeout(function(){
								/* Show Multiselect */
								$('#depsalesCountrySearch').empty().append(selectOption).append(scriptTag);
								$('div.countrySelectBtn').show(100);
								$('select.dependentFilter[id="depsalesCountrySearch"]').prop('disabled','false');
								$('select.dependentFilter[id="depsalesCountrySearch"]').siblings().children().removeClass('disabled');
								$('button#placeboMultiSelect').hide(100);									
							});
					});
				});
			}
			else
			{
				$('select.dependentFilter[id="depsalesCountrySearch"]').prop('disabled','true');
				$('select.dependentFilter[id="depsalesCountrySearch"]').siblings().children().addClass('disabled');
				$timeout(function(){
					$scope.regionSelected = true;
				});
			}
		}
		function getSelectedValue(id){
			var selector = "select.dependentFilter[id='"+id+"']";
			if(id==='depsalesRegionSearch' && $(selector).val() != null){
				return $(selector).val();
			}
			else
			{
				if($(selector).val()!==undefined){
					var values = [];
					_.forEach($(selector).val(), function(choice){
						values.push("^"+choice+"$");
					});
					return values.join("|");
				}
				else
					return "";
			}
		}

		var tableCreate = function(custNameDataBean, serviceData){
			var dataObj;
			if(arguments.length>1 && arguments[2] ===true){
				dataObj = OutageTableService.customerCountryTableData(custNameDataBean);
				OutageTableService.initTable(dataObj['dataArr'],dataObj['columns'],'Outage-by-Top-Cust-Country-Data',dataObj['regionCount']);
				$('#countryTable').addClass('in');
				$timeout(function(){
					$('.countryTableDiv').show();
				},500); 
			}
			else{
				dataObj = OutageTableService.customerTableData(custNameDataBean);
				OutageTableService.initTable(dataObj['dataArr'],dataObj['columns'],'Outage-by-Top-Cust-Data',dataObj['regionCount']);
				$('#collapse4').addClass('in');
				$timeout(function(){
					$('.regionTableDiv').show();
				},500); 
			}
		}
		var updateTopCustDatatable = function(response){
			var serviceData;
			if(arguments.length>1 && arguments[1] ===true){
				serviceData = (OutageTableService.countryDataProcessing(response.outageCustomers));
			}
			else
				serviceData = (OutageCustomerService.processAllCustomerData(response.outageCustomers));
			$scope.custNameData=response.outageCustomers;
			var customers = serviceData['customers'], chartData = serviceData['chartData'];
			if(arguments.length>1 && arguments[1] ===true){
				if(response.outageCustomers.length>0){
					tableCreate(response.outageCustomers, serviceData,true);
					$scope.createOutageChart(customers,chartData,'country_chart');
					$('#countryChart').addClass('in');
					$scope.safeApply(function(){
						$scope.dep_custDataExp = true;
						$scope.dep_custChartExp = true;
						$('.ctrError').hide(100);
						$('.ctrView').show(100);
					});
					$timeout(function(){
						$timeout(function(){
							$('#countryChart').height($('#country_chart').outerHeight()+50);
							$('#countryTable > #tableDivision').height($('#Outage-by-Top-Cust-Country-Data_wrapper').outerHeight()+50);
							$('#countryChart > #techRegionChart').outerHeight($('#countryChart').height());
							$('#countryTable').outerHeight($('#countryTable > #tableDivision').outerHeight()+20);
						},250);
					},200);
				}
				else{
					$('.ctrError').show(100).css('display','flex');
					$('.ctrView').hide(100);
				}
			}
			else{
				if(response.outageCustomers.length>0){
					tableCreate(response.outageCustomers, serviceData);
					$scope.createOutageChart(customers,chartData,'container2');
					$('#collapse3').addClass('in');
					$scope.safeApply(function(){
						$scope.custDataExp = true;
						$scope.custChartExp = true;
						$('.regError').hide(100);
						$('.regView').show(100);
					});
					$timeout(function(){
						$timeout(function(){
							$('#collapse3').height($('#container2').outerHeight()+50);
							$('#collapse4 > #tableDivision').height($('#Outage-by-Top-Cust-Data_wrapper').outerHeight()+50);
							$('#collapse3 > #techRegionChart').outerHeight($('#collapse3').height());
							$('#collapse4').outerHeight($('#collapse4 > #tableDivision').outerHeight()+20);
						},250);
					},200);
				}
				else
				{
					$('.regError').show(100).css('display','flex');
					$('.regView').hide(100);
				}
			}

			loaderOps(false);					
		}
		window.addEventListener('px-tab-changed', function(event){
			var selectedTab = parseInt(event.target.selected);
			Polymer.dom().querySelector('px-tab-pages').selected = selectedTab;
			if(selectedTab===0){
				$('.rstFltr').show()
			}
			else{
				$('.rstFltr').hide()
			}
		});

		$rootScope.dep_outageTopCustomerCountrySearchData = function(){
			var jsonData = [];
			var item = {};
			item["region"] = getSelectedValue('depsalesRegionSearch');
			item["country"]= getSelectedValue('depsalesCountrySearch');
			item["unitStatus"]= getSelectedValue('unitStatusDescSearch');
			item["serviceRel"]=getSelectedValue('servRelDescSearch');
			item["technology"]= getSelectedValue('techDescSearch'); 
			item["equipment"]=getSelectedValue('equipDescSearch');
			item["segment"]=getSelectedValue('marketSegSearch');
			item["customerName"]=getSelectedValue('siteCustSearch');
			item["location"]=getSelectedValue('locationDescSearch');
			item["year"]=getSelectedValue('yearSearch');
			item["quarter"]=getSelectedValue('outageQtrSearch');
			item["dunsName"]=getSelectedValue('customerNameSearch');
			item["accMgrEmail"]=getSelectedValue('accMgrEmailSearch');
			item["serviceMgrEmail"]=getSelectedValue('serviceMgrEmailSearch');
			item["maintLvlDesc"]=getSelectedValue('maintLvlDescSearch');
			item["eventStatusDesc"]=getSelectedValue('eventStatusDescSearch');
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = "";
			jsonData.push(item);
			if(!((item['region'])==='') && (item['region']).includes('region')===false && !((item['region'])==='Select Region')){
				loaderOps(true);
				NetworkCallService.getOutageMetricsCountryFilterData(jsonData).then(function(response){
					updateTopCustDatatable(response,true);
					resizeAll();
					$('#countryChart').height($('#country_chart').outerHeight()+50);					
					$('#countryChart > #techRegionChart').outerHeight($('#countryChart').height());					
					$('#countryTable, #countryChart').show();					
					loaderOps(false);
				});
			}
			else{
				$('#depsalesRegionSearch').addClass("boxShadow");
				$('.errorIndicator').show();
			}
			// Raw data parameters
			$scope.regionOutageRawData = [];
			$scope.countryOutageRawData = [];
			$scope.flgRegionOutageRawData = false;
			$scope.flgCountryOutageRawData = false;
		}
		/* Create Chart When transferred from NewMetrics Page */
        
        $timeout(function() {
            if (!$rootScope.accountManager && !$rootScope.marketIndustry) {
                $rootScope.outageTopCustomerDropdownsData();
                $rootScope.getOutageMetricsTopCustomerData();
            }
        }, 5000);
        
        if ($rootScope.accountManager) {
            $timeout(function() {
                $rootScope.outageTopCustomerDropdownsData();
                $rootScope.outageTopCustomerRegionSearchData();
            }, 5000);   
        } else {
            $timeout(function() {
                $rootScope.outageTopCustomerDropdownsData();
                $rootScope.getOutageMetricsTopCustomerData();
            }, 5000);
        }
        
        $rootScope.outageTopCustomerDropdownsData = function() {
            var item = {};
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = "";
            
            NetworkCallService.getOutageDropdown(JSON.stringify(item)).then(function(response){

                $scope.safeApply(function(){

                    $scope.salesRegionDropdownBean = response.outageRegion; 	
                    $scope.salesCountryDropdownBean = response.outageCountry;
                    $scope.unitStatusDescDropdownBean = response.outageUnitStatus;
                    $scope.servRelDescDropdownBean = response.outageRelation;
                    $scope.techDescDropdownBean = response.outageTechnology;
                    $scope.equipDescDropdownBean = response.outageEquip;
                    $scope.marketSegDropdownBean = response.outageSegment;
                    $scope.siteCustDropdownBean = response.outageCustName;
                    $scope.locationDescDropdownBean = response.outageLocation;
                    $scope.outageYearQtrDropdownBean = response.outageYearQtr;
                    $scope.dunsDropdownBean = response.outageDunsName;
                    $scope.accMgrEmailDropdownBean = response.outageaccMgrEmail;
                    $scope.serviceMgrEmailDropdownBean = response.outageserviceMgrEmail;
                    $scope.serviceMaintLvlDescDropdownBean = response.maintLvlDescDTO;
                    $scope.serviceEventStatusDescDropdownBean = response.maintLvlStatus;
                });
                $timeout(function(){
                    $("select:not(#depsalesRegionSearch,#depsalesCountrySearch,#siteCustCountrySearch,#customerNameSearch,#Outage-by-Top-Cust-Data_length select,#marketIndustryDropdownBean)").multipleSelect({
                        filter: true
                    });
                    $("select#siteCustCountrySearch,select#customerNameSearch").multipleSelect({
                        filter: true,
                        selectAll: false
                    });
                },200);						
                resizeAll();
            });
        }

		$rootScope.outageTopCustomerRegionSearchData = function(){
			loaderOps(true);
			var jsonData = [];
			var item = {};
			item["region"] = ($("#salesRegionSearch").val()===undefined||!$("#salesRegionSearch").val())?"":'^'+$("#salesRegionSearch").val().join("$|^")+'$';
			item["country"]=($("#salesCountrySearch").val()===undefined||!$("#salesCountrySearch").val())?"":'^'+$("#salesCountrySearch").val().join("$|^")+'$';
			item["unitStatus"]= ($("#unitStatusDescSearch").val()===undefined||!$("#unitStatusDescSearch").val())?"":'^'+$("#unitStatusDescSearch").val().join("$|^")+'$';
			item["serviceRel"]=($("#servRelDescSearch").val()===undefined||!$("#servRelDescSearch").val())?"":'^'+$("#servRelDescSearch").val().join("$|^")+'$';
			item["technology"]=($("#techDescSearch").val()===undefined||!$("#techDescSearch").val())?"":'^'+$("#techDescSearch").val().join("$|^")+'$';
			item["equipment"]=($("#equipDescSearch").val()===undefined||!$("#equipDescSearch").val())?"":'^'+$("#equipDescSearch").val().join("$|^")+'$';
			item["segment"]=($("#marketSegSearch").val()===undefined||!$("#marketSegSearch").val())?"":'^'+$("#marketSegSearch").val().join("$|^")+'$';
			item["customerName"]=($("#siteCustSearch").val()===undefined||!$("#siteCustSearch").val())?"":'^'+$("#siteCustSearch").val().join("$|^")+'$';
			item["location"]=($("#locationDescSearch").val()===undefined||!$("#locationDescSearch").val())?"":'^'+$("#locationDescSearch").val().join("$|^")+'$';
			item["year"]=($("#yearSearch").val()===undefined||!$("#yearSearch").val())?"":'^'+$("#yearSearch").val().join("$|^")+'$';
			item["quarter"]=($("#outageQtrSearch").val()===undefined||!$("#outageQtrSearch").val())?"":'^'+$("#outageQtrSearch").val().join("$|^")+'$';
			item["dunsName"]=($("#customerNameSearch").val()===undefined||!$("#customerNameSearch").val())?"":'^'+$("#customerNameSearch").val().join("$|^")+'$';
			item["accMgrEmail"]=($("#accMgrEmailSearch").val()===undefined||!$("#accMgrEmailSearch").val())?"":'^'+$("#accMgrEmailSearch").val().join("$|^")+'$';
			item["serviceMgrEmail"]=($("#serviceMgrEmailSearch").val()===undefined||!$("#serviceMgrEmailSearch").val())?"":'^'+$("#serviceMgrEmailSearch").val().join("$|^")+'$';
			item["maintLvlDesc"]=($("#maintLvlDescSearch").val()===undefined||!$("#maintLvlDescSearch").val())?"":'^'+$("#maintLvlDescSearch").val().join("$|^")+'$';
			item["eventStatusDesc"]=($("#eventStatusDescSearch").val()===undefined||!$("#eventStatusDescSearch").val())?"":'^'+$("#eventStatusDescSearch").val().join("$|^")+'$';
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = "";
			jsonData.push(item);
			NetworkCallService.getOutageMetricsFilterData(jsonData).then(function(response){
				$scope.responseData=response;
				updateTopCustDatatable(response);
				resizeAll();
			});
			// Raw data parameters
			$scope.regionOutageRawData = [];
			$scope.countryOutageRawData = [];
			$scope.flgRegionOutageRawData = false;
			$scope.flgCountryOutageRawData = false;
		}
		function resizeCharts(){
			$('#tableDiv').show();
			$timeout(function(){
				$timeout(function(){
					$('#collapse3').height($('#container2').outerHeight()+50);
					$('#tableDivision').height($('#Outage-by-Top-Cust-Data_wrapper').outerHeight()+50);
					$('#collapse3 > #techRegionChart').outerHeight($('#collapse3').height());
					$('#collapse4').outerHeight($('#collapse4 > #tableDivision').outerHeight()+20);	
				},250);
			},200);
			resizeAll();
			loaderOps(false);
		}
		$scope.clearData = function(){
			loaderOps(true);
			$scope.safeApply(function(){
				$scope.custChartExp = true;
				$scope.custDataExp = true;
			});
			if(!defaultData['indep_filters'])
				NetworkCallService.getOutageMetricsFilterData(OutageTechnoRegionService.searchDataService()).then(function(response){
					defaultData['indep_filters'] = response;
					var serviceData = (OutageCustomerService.processCustomerData(response.outageCustomers));
					var customers = serviceData['customers'], chartData = serviceData['chartData'];
					$scope.createOutageChart(customers,chartData,'container2');
					var dataObj = (OutageTableService.topCustomerTableData(response.outageCustomers));
					$scope.safeApply(function(){
						OutageTableService.initTable(dataObj['dataArr'],dataObj['columns'],'Outage-by-Top-Cust-Data',dataObj['regionCount']);
						$scope.custDataExp = true;
						$scope.custChartExp = true;
						resizeCharts();
					});
				});
			else
			{
				var serviceData = (OutageCustomerService.processCustomerData(defaultData['indep_filters'].outageCustomers));
				var customers = serviceData['customers'], chartData = serviceData['chartData'];
				$scope.createOutageChart(customers,chartData,'container2');
				var dataObj = (OutageTableService.topCustomerTableData(defaultData['indep_filters'].outageCustomers));
				$scope.safeApply(function(){
					OutageTableService.initTable(dataObj['dataArr'],dataObj['columns'],'Outage-by-Top-Cust-Data',dataObj['regionCount']);
					$scope.custDataExp = true;
					$scope.custChartExp = true;
					resizeCharts();
				});
			}
			$('outage-independent-filter').find('.ms-choice > span').html('');
			$('outage-independent-filter').find('input[type="checkbox"]').attr('checked',false);
			$('outage-independent-filter').find("select").val('')
			$('#depsalesCountrySearch').empty();
			$('.regError').hide(100);
			$('.regView').show(100);
			loaderOps(false);	
			// Raw data parameters
			$scope.regionOutageRawData = [];
			$scope.countryOutageRawData = [];
			$scope.flgRegionOutageRawData = false;
			$scope.flgCountryOutageRawData = false;
		}
		$scope.dep_clearData = function(){
			$('outage-dependent-filter').find('.ms-choice > span').html('');
			$('outage-dependent-filter').find('input[type="checkbox"]').attr('checked',false);
			$('outage-dependent-filter').find("select").val('');
			$('#depsalesCountrySearch').empty();
			$('#countryTable, #countryChart').hide();
			_.defer(function(){
				$('div.countrySelectBtn').hide(100);
				$('select.dependentFilter[id="depsalesCountrySearch"]').prop('disabled','true');
				$('select.dependentFilter[id="depsalesCountrySearch"]').siblings().children().addClass('disabled');
				$('button#placeboMultiSelect').show(100);	
				$('.ctrError').hide(100);
				$('.ctrView').show(100);
				$scope.dep_custChartExp = false;
				$scope.dep_custDataExp = false;
			});
			_.forEach(Object.keys($scope.depSearch), function(key){
				_.defer(function(){
					$scope[key] = null;
				});
			});
			$('#depsalesRegionSearch').removeClass("boxShadow");
			$('.errorIndicator').hide();
			// Raw data parameters
			$scope.regionOutageRawData = [];
			$scope.countryOutageRawData = [];
			$scope.flgRegionOutageRawData = false;
			$scope.flgCountryOutageRawData = false;
		}

		/* Polymer Tab Initialization */
		var checkStatus = setInterval(function(){
			if(Polymer.dom().node.readyState==='complete'){
				Polymer.dom().querySelector('px-tab-pages').selected = 0;
				Polymer.dom().querySelector('px-tab-set').selected = 0;
				clearInterval(checkStatus);
			}
		},100);
		/* Creation of chart at start */
        
        $rootScope.getOutageMetricsTopCustomerData = function() {
            NetworkCallService.getOutageMetricsFilterData(OutageTechnoRegionService.searchDataService()).then(function(response){
                defaultData['indep_filters'] = response;
                var serviceData = (OutageCustomerService.processCustomerData(response.outageCustomers));

                var customers = serviceData['customers'], chartData = serviceData['chartData'];
                $scope.createOutageChart(customers,chartData,'container2');
                var dataObj = (OutageTableService.topCustomerTableData(response.outageCustomers));
                $scope.safeApply(function(){
                    OutageTableService.initTable(dataObj['dataArr'],dataObj['columns'],'Outage-by-Top-Cust-Data',dataObj['regionCount']);
                    $scope.custDataExp = true;
                    $scope.custChartExp = true;
                    resizeCharts();
                });
                $timeout(function(){
                    loaderOps(false);
                },500);
            });
        }
        
        $timeout(function(){
            $(document.body).off().on('change','#depsalesRegionSearch',function(){
                $scope.getCountries();
            });
        },500);

		$scope.exportCharts = function(type) {
			$scope.exportChart(type);
		};
		$scope.excelDownload = function(id) {
			OutageTableService.excelDownload(id); 
		};

		$scope.shwOutageRawData = function (tableId, methodCall) {
			var jsonData = [];
			var item = {};

			if (methodCall === 'OutageRegion') {
				item["region"] = ($("#salesRegionSearch").val()===undefined||!$("#salesRegionSearch").val())?"":'^'+$("#salesRegionSearch").val().join("$|^")+'$';
				item["country"]=($("#salesCountrySearch").val()===undefined||!$("#salesCountrySearch").val())?"":'^'+$("#salesCountrySearch").val().join("$|^")+'$';
				item["unitStatus"]= ($("#unitStatusDescSearch").val()===undefined||!$("#unitStatusDescSearch").val())?"":'^'+$("#unitStatusDescSearch").val().join("$|^")+'$';
				item["serviceRel"]=($("#servRelDescSearch").val()===undefined||!$("#servRelDescSearch").val())?"":'^'+$("#servRelDescSearch").val().join("$|^")+'$';
				item["technology"]=($("#techDescSearch").val()===undefined||!$("#techDescSearch").val())?"":'^'+$("#techDescSearch").val().join("$|^")+'$';
				item["equipment"]=($("#equipDescSearch").val()===undefined||!$("#equipDescSearch").val())?"":'^'+$("#equipDescSearch").val().join("$|^")+'$';
				item["segment"]=($("#marketSegSearch").val()===undefined||!$("#marketSegSearch").val())?"":'^'+$("#marketSegSearch").val().join("$|^")+'$';
				item["customerName"]=($("#siteCustSearch").val()===undefined||!$("#siteCustSearch").val())?"":'^'+$("#siteCustSearch").val().join("$|^")+'$';
				item["location"]=($("#locationDescSearch").val()===undefined||!$("#locationDescSearch").val())?"":'^'+$("#locationDescSearch").val().join("$|^")+'$';
				item["year"]=($("#yearSearch").val()===undefined||!$("#yearSearch").val())?"":'^'+$("#yearSearch").val().join("$|^")+'$';
				item["quarter"]=($("#outageQtrSearch").val()===undefined||!$("#outageQtrSearch").val())?"":'^'+$("#outageQtrSearch").val().join("$|^")+'$';
				item["dunsName"]=($("#customerNameSearch").val()===undefined||!$("#customerNameSearch").val())?"":'^'+$("#customerNameSearch").val().join("$|^")+'$';
				item["accMgrEmail"]=($("#accMgrEmailSearch").val()===undefined||!$("#accMgrEmailSearch").val())?"":'^'+$("#accMgrEmailSearch").val().join("$|^")+'$';
				item["serviceMgrEmail"]=($("#serviceMgrEmailSearch").val()===undefined||!$("#serviceMgrEmailSearch").val())?"":'^'+$("#serviceMgrEmailSearch").val().join("$|^")+'$';
				item["maintLvlDesc"]=($("#maintLvlDescSearch").val()===undefined||!$("#maintLvlDescSearch").val())?"":'^'+$("#maintLvlDescSearch").val().join("$|^")+'$';
				item["eventStatusDesc"]=($("#eventStatusDescSearch").val()===undefined||!$("#eventStatusDescSearch").val())?"":'^'+$("#eventStatusDescSearch").val().join("$|^")+'$';
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = "";
				jsonData.push(item);

				if ($scope.regionOutageRawData === undefined)
					$scope.regionOutageRawData = [];

				$("#regOutageRawData").attr('style', 'display: block');

				if ($scope.regionOutageRawData === undefined || $scope.regionOutageRawData.length === 0) {
					calOutageRawService(jsonData, tableId, methodCall);
					$scope.flgRegionOutageRawData = true;
				}

			} else {
				item["region"] = getSelectedValue('depsalesRegionSearch');
				item["country"]= getSelectedValue('depsalesCountrySearch');
				item["unitStatus"]= getSelectedValue('unitStatusDescSearch');
				item["serviceRel"]=getSelectedValue('servRelDescSearch');
				item["technology"]= getSelectedValue('techDescSearch'); 
				item["equipment"]=getSelectedValue('equipDescSearch');
				item["segment"]=getSelectedValue('marketSegSearch');
				item["customerName"]=getSelectedValue('siteCustSearch');
				item["location"]=getSelectedValue('locationDescSearch');
				item["year"]=getSelectedValue('yearSearch');
				item["quarter"]=getSelectedValue('outageQtrSearch');
				item["dunsName"]=getSelectedValue('customerNameSearch');
				item["accMgrEmail"]=getSelectedValue('accMgrEmailSearch');
				item["serviceMgrEmail"]=getSelectedValue('serviceMgrEmailSearch');
				item["maintLvlDesc"]=getSelectedValue('maintLvlDescSearch');
				item["eventStatusDesc"]=getSelectedValue('eventStatusDescSearch');
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = "";
				jsonData.push(item);

				if((item['region']) === '' || ((item['region']).includes('undefined')===false && ((item['region'])==='Select Region'))){
					$('#depsalesRegionSearch').addClass("boxShadow");
					$('.errorIndicator').show(100);
					$("#flgCountryOutageCollapse").attr("aria-expanded","false");
					$scope.flgCountryOutageRawData = false;
					return false;
				}
				if ($scope.countryOutageRawData === undefined)
					$scope.countryOutageRawData = [];

				$("#cntryOutageRawData").attr('style', 'display: block');

				if ($scope.countryOutageRawData === undefined || $scope.countryOutageRawData.length === 0) {
					calOutageRawService(jsonData, tableId, methodCall);
					$scope.flgCountryOutageRawData = true;
				}
			}
		};

		function calOutageRawService (jsonData, tableId, methodCall) {
			loaderOps(true);
			$http.post("connect/fms/getRawDataIBOPage/"+"outageTechReg",JSON.stringify({"data":jsonData})).then(function(response){
				$scope.outageColumnHeaders = response.data.OutageColumnHeaders;
				$scope.rawOutageData = response.data.OutageTechRawData;

				if (methodCall === 'OutageRegion')
					$scope.regionOutageRawData = $scope.rawOutageData;
				else
					$scope.countryOutageRawData = $scope.rawOutageData;

				if ($.fn.DataTable.isDataTable( '#'+tableId ) ) {
					$('#'+tableId).dataTable().api().clear().draw();
					$('#'+tableId).dataTable().api().destroy();
					$('#'+tableId).empty(); 
				}

				$('#'+tableId).DataTable({
					data: $scope.rawOutageData,
					"sPaginationType": "simple_numbers",
					"bFilter":true, 
					"retrieve": true, 
					"scrollX": false,
					"paging": true,
					columns:_.sortBy($scope.outageColumnHeaders,'row_id')

				});

				loaderOps(false);
			});
		}

		$scope.OutageRawDataExcelDownload = function(methodCall) {
			var jsonData = [];
			var item = {};
			var fileName = "Outage Top Customers data";

			if (methodCall === 'OutageRegion') {
				item["region"] = ($("#salesRegionSearch").val()===undefined||!$("#salesRegionSearch").val())?"":'^'+$("#salesRegionSearch").val().join("$|^")+'$';
				item["country"]=($("#salesCountrySearch").val()===undefined||!$("#salesCountrySearch").val())?"":'^'+$("#salesCountrySearch").val().join("$|^")+'$';
				item["unitStatus"]= ($("#unitStatusDescSearch").val()===undefined||!$("#unitStatusDescSearch").val())?"":'^'+$("#unitStatusDescSearch").val().join("$|^")+'$';
				item["serviceRel"]=($("#servRelDescSearch").val()===undefined||!$("#servRelDescSearch").val())?"":'^'+$("#servRelDescSearch").val().join("$|^")+'$';
				item["technology"]=($("#techDescSearch").val()===undefined||!$("#techDescSearch").val())?"":'^'+$("#techDescSearch").val().join("$|^")+'$';
				item["equipment"]=($("#equipDescSearch").val()===undefined||!$("#equipDescSearch").val())?"":'^'+$("#equipDescSearch").val().join("$|^")+'$';
				item["segment"]=($("#marketSegSearch").val()===undefined||!$("#marketSegSearch").val())?"":'^'+$("#marketSegSearch").val().join("$|^")+'$';
				item["customerName"]=($("#siteCustSearch").val()===undefined||!$("#siteCustSearch").val())?"":'^'+$("#siteCustSearch").val().join("$|^")+'$';
				item["location"]=($("#locationDescSearch").val()===undefined||!$("#locationDescSearch").val())?"":'^'+$("#locationDescSearch").val().join("$|^")+'$';
				item["year"]=($("#yearSearch").val()===undefined||!$("#yearSearch").val())?"":'^'+$("#yearSearch").val().join("$|^")+'$';
				item["quarter"]=($("#outageQtrSearch").val()===undefined||!$("#outageQtrSearch").val())?"":'^'+$("#outageQtrSearch").val().join("$|^")+'$';
				item["dunsName"]=($("#customerNameSearch").val()===undefined||!$("#customerNameSearch").val())?"":'^'+$("#customerNameSearch").val().join("$|^")+'$';
				item["accMgrEmail"]=($("#accMgrEmailSearch").val()===undefined||!$("#accMgrEmailSearch").val())?"":'^'+$("#accMgrEmailSearch").val().join("$|^")+'$';
				item["serviceMgrEmail"]=($("#serviceMgrEmailSearch").val()===undefined||!$("#serviceMgrEmailSearch").val())?"":'^'+$("#serviceMgrEmailSearch").val().join("$|^")+'$';
				item["maintLvlDesc"]=($("#maintLvlDescSearch").val()===undefined||!$("#maintLvlDescSearch").val())?"":'^'+$("#maintLvlDescSearch").val().join("$|^")+'$';
				item["eventStatusDesc"]=($("#eventStatusDescSearch").val()===undefined||!$("#eventStatusDescSearch").val())?"":'^'+$("#eventStatusDescSearch").val().join("$|^")+'$';
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = "";
			} else {
				item["region"] = getSelectedValue('depsalesRegionSearch');
				item["country"]= getSelectedValue('depsalesCountrySearch');
				item["unitStatus"]= getSelectedValue('unitStatusDescSearch');
				item["serviceRel"]=getSelectedValue('servRelDescSearch');
				item["technology"]= getSelectedValue('techDescSearch'); 
				item["equipment"]=getSelectedValue('equipDescSearch');
				item["segment"]=getSelectedValue('marketSegSearch');
				item["customerName"]=getSelectedValue('siteCustSearch');
				item["location"]=getSelectedValue('locationDescSearch');
				item["year"]=getSelectedValue('yearSearch');
				item["quarter"]=getSelectedValue('outageQtrSearch');
				item["dunsName"]=getSelectedValue('customerNameSearch');
				item["accMgrEmail"]=getSelectedValue('accMgrEmailSearch');
				item["serviceMgrEmail"]=getSelectedValue('serviceMgrEmailSearch');
				item["maintLvlDesc"]=getSelectedValue('maintLvlDescSearch');
				item["eventStatusDesc"]=getSelectedValue('eventStatusDescSearch');
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = "";
			}
			jsonData.push(item);
			download("/connect/fms/exportRawDataMetrics/" + "outageTechReg/" + fileName, jsonData, fileName);
		};

		function download(url,data ,defaultFileName) {
			var deferred = $q.defer();
			$http.post(url,JSON.stringify({"data":data}), { responseType: "arraybuffer" }).success(
					function (data, status, headers) {
						var type = headers('Content-Type');
						var disposition = headers('Content-Disposition');
						if (disposition) {
							var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
							if (match[1])
								defaultFileName = match[1];
						}
						defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
						var blob = new Blob([data], { type: type });
						saveAs(blob, defaultFileName);
						deferred.resolve(defaultFileName);                    
					}).error(function () {
						var e ;
						deferred.reject(e);
					});
			return deferred.promise;
		};

		$scope.createOutageChart = function(xSeries,ySeries,id,state)
		{
			if(!state)
				state = null;
			Highcharts.setOptions({
				global: {
					useUTC: false,

				},
				lang: {
					decimalPoint: '.',
					thousandsSep: ','
				}
			});
			chart= new Highcharts.Chart({
				chart: {
					renderTo: id,
					type: 'bar',
					events: {
						click: function () {
							if(state!==null)
								$state.go(state);
						}
					}
				},
				title: {
					text:''
				},
				xAxis: {
					categories: xSeries
				},
				yAxis: {
					min: 0,
					title: {
						text: 'Number of Outages'
					}
				},
				tooltip: {
					pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:,.0f}</b> ({point.percentage:.2f}%)<br/>',
					shared: true
				},
				legend: {
					itemStyle: {
						color: 'black',
						fontWeight: 'normal',
						fontSize: '12px',
					}
				},
				plotOptions: {
					series: {
						stacking: 'normal',
						borderWidth:0,
						point: {
							events: {
								click: function () {
									$scope.refreshOutageCustMetrics(this.series.name, this.category, id);

								}
							}
						}
					}
				},
				credits: {
					enabled: false
				},
				series: ySeries
			});

		};

		$scope.refreshOutageCustMetrics = function(name, category, id) {
			if(id === 'container2'){
				$('outage-independent-filter').find('.customerNameSearch .ms-choice > span').html(category);
				$('outage-independent-filter').find('.customerNameSearch input[value="'+category+'"]').attr('checked',true);
				$('outage-independent-filter').find("#customerNameSearch").val(category); 
				$('outage-independent-filter').find("#customerNameSearch").multipleSelect("refresh");

				$('outage-independent-filter').find('.salesRegionSearch .ms-choice > span').html(name);
				$('outage-independent-filter').find('.salesRegionSearch input[value="'+name+'"]').attr('checked',true);
				$('outage-independent-filter').find("#salesRegionSearch").val(name);
				$('outage-independent-filter').find("#salesRegionSearch").multipleSelect("refresh");
				$rootScope.outageTopCustomerRegionSearchData();
			} else if(id === 'country_chart'){
				$('outage-dependent-filter').find('.countrySelectBtn .ms-choice > span').html(name);
				$('outage-dependent-filter').find('.countrySelectBtn input[value="'+name+'"]').attr('checked',true);
				$('outage-dependent-filter').find("#depsalesCountrySearch").val(name);
				$('outage-dependent-filter').find("#depsalesCountrySearch").multipleSelect("refresh");

				$('outage-dependent-filter').find('.customerNameSearch .ms-choice > span').html(category);
				$('outage-dependent-filter').find('.customerNameSearch input[value="'+category+'"]').attr('checked',true);
				$('outage-dependent-filter').find("#customerNameSearch").val(category);
				$('outage-dependent-filter').find("#customerNameSearch").multipleSelect("refresh");
				$rootScope.dep_outageTopCustomerCountrySearchData();
			}
		};

		$scope.exportChart = function(type){
			if(type === 'JPEG') {
				chart.exportChart({type: 'image/jpeg', filename: 'Top Customer'}, {subtitle: {text:''}});
            }
            
			if(type === 'XLS') {
				chart.exportChart({type: 'application/vnd.ms-excel', filename: 'my-excel'}, {subtitle: {text:''}});
            }
	   }
    }]);
});