
define(['angular','../../sample-module','jquery','datatablesNetMin','datatablesNet','bootstrap-popover','fileSaver','datatablesNetRowReorder','datatablesNetResponsive'], function (angular,controllers) 
 {
    'use strict';
    controllers.controller('outageDataCtrl', ['$scope','$rootScope','$http', '$location', '$state','$q', '$timeout', function ($scope,$rootScope, $http, $location, $state, $q, $timeout) 
            {
		jQuery.fn.center = function() {
            this.css({top: ($(window).outerHeight()) / 2,left: ($(window).outerWidth()) / 2});
             return this;
 		};
			$scope.flag = true;
 		$scope.selectAll = false;
 		$(".overlay").css("height",$(document).height());
 		$(".loading").center();
 		$(".loading").show();
 		$(".overlay").show();
 		$("body").on("change","#checkAll",function(){
  		    var checkSelectAll=$('.popover .inline .showHideTitle input[type="checkbox"]').is(":checked");
  		    if(checkSelectAll===true)
  		    {
  		    	$('.popover-content .innerShowHideTitle input[type="checkbox"]').prop('checked',true);
  		    	$scope.selectAll = true;
  		    }
  		    else
  		    {
  		    	$scope.selectAll = false;
  		    	$('.popover-content .innerShowHideTitle input[type="checkbox"]').prop('checked',false);
  		    	$('.popover-content .innerShowHideTitle input[type="checkbox"]').each(function(i) {
  		    		 if(i<16)
  		    		 {
  		    			 $(this).prop('checked',true);
  		    		 }
  		    	});
  		    }
  		   $scope.$apply();
  		  resizeAll();
  		});
 		
 		$scope.columnTitleList=[];
		
		$http.get("connect/fms/getChooseColumns").then(function(response){        		
			$scope.outageColumns=response.data.OutageColumns;    	        		
    		for(var i = 0; i<$scope.outageColumns.length; i++){
    			if($scope.outageColumns[i].active === "Y"){    	    			
    				var item = {};
    			    item ["index"] = $scope.outageColumns[i].displayOrder-1;
    			    item ["title"] = $scope.outageColumns[i].displayName;
    			    item ["name"] = $scope.outageColumns[i].columnName;
    	   			if($scope.outageColumns[i].checked === 1)
	    				 item ["checked"] = "YES";
	    			else
	    				item ["checked"] = "NO";
	    			$scope.columnTitleList.push(item);
    			}
    		}        		
		}); 
 		
		$('#popover4').popover({
			  html: true,
			  placement: 'bottom',
			  content: function() {
				if($scope.selectAll)
				{
					$('.popover .inline .showHideTitle input[type="checkbox"]').prop('checked',true);
				}
				else
				{
					$('.popover .inline .showHideTitle input[type="checkbox"]').prop('checked',false);
				}
			    return $('#popover4-content-wrapper').html();
			  }
			}).on('click', function(e) {
			  e.preventDefault();
			});	

 		$('body').on('click','#colHideShowCancel', function () {
 			$('.popover').css('display', 'none');
 		});
			
		
 		$('body').on('click','#colHideShowApply',function(){
 			$('.popover').css('display', 'none');
				$rootScope.safeApply (function (){
 			for(var colIndex = 0;colIndex<$scope.columnTitleList.length;colIndex++){

	    			if(!($("#"+$scope.columnTitleList[colIndex].name).is(":checked"))){
						$scope.columnTitleList[colIndex].checked = "NO";
		    			$('table[data-table-name="Outage-Data"]').dataTable().fnSetColumnVis($scope.columnTitleList[colIndex].index, false);
					}
	    			else{
						$scope.columnTitleList[colIndex].checked = "YES";
	    				$('table[data-table-name="Outage-Data"]').dataTable().fnSetColumnVis($scope.columnTitleList[colIndex].index, true);
	    			}
 			}	
});				
 								
 			});
 		var outageTable;
 		$scope.updateData={};
        $rootScope.outageSearchData = function(input) {
 			$(".loading").center();
     		$(".loading").show();
     		$(".overlay").show();
 			$http.post("connect/fms/getOutageData",JSON.stringify({
                "type": input,
                "businessSegment":$rootScope.businessSegment,
                "marketIndustry":$rootScope.marketIndustry ? $rootScope.marketIndustry : ""
            })).then(function(response){
         		$scope.updateData = response.data;
         		updateOutageData();
         		}).then(function(){
         			resizeAll();
         	});
 		}
                
 		if ($rootScope.marketIndustry) {
            $rootScope.outageSearchData('DEFAULT');
        } else  {
            $timeout(function() {
                $rootScope.outageSearchData('DEFAULT');
            }, 5000); 
        }
                
 		$("body").off("change","#AllData");
 		$("body").on("change","#AllData",function(){
 			var flag = $(this).is(":checked");
 			if(flag) {
                $rootScope.outageSearchData('ALL');
 			} else {
 				$rootScope.outageSearchData('DEFAULT');
 			}
 		});
 		
 		$('table[data-table-name="Outage-Data"] tfoot td').each( function () {
 	        var title = $(this).text();
 	        if(title!=='')
 	        {
 	        	$(this).html( '<input type="text" placeholder="Search '+title+'" size="4" />' );
 	        }
 	    } );
 		var $window     = $(window);
        var windowsize  = $window.width();
        var dtOptions;
        if (windowsize > 767) {
            dtOptions = {
	    		rowReorder: {
	 				selector: 'td:nth-child(2)'
	 			},
	 			responsive: false,
	 			"bPaginate": true,
	 			"bSort": true,
	 			"bFilter": true,
	 			"aLengthMenu": [[10,20,50,100,-1], [10,20,50,100,"All"]],
	 			"iDisplayLength": 10,
	 			"bAutoWidth": false       
            };
        } else {
            dtOptions = {
				rowReorder: {
					selector: 'td:nth-child(2)'
				},
				responsive: true,
				"bPaginate": true,
				"bSort": true,
				"bFilter": true,
				"aLengthMenu": [[10,20,50,100,-1], [10,20,50,100,"All"]],
				"iDisplayLength": 10,
				"bAutoWidth": false         
            };
        }
 		outageTable = $('table[data-table-name="Outage-Data"]').DataTable(dtOptions);
 		
 		// Apply the search
 		outageTable.columns().every( function () {
 	        var that = this;
 	 
 	        $( 'input', this.footer() ).on( 'keyup change', function () {
 	            if ( that.search() !== this.value ) {
 	                that
 	                    .search( this.value )
 	                    .draw();
 	            }
 	        } );
 	    });
 		
 		function updateOutageData(){
				if($scope.flag===true)
				{
	    			$(".loading").hide();
	    			$(".overlay").hide();
 			}
 			else
 			{
 				$(".overlay").css("height",$(document).height());
 				$(".overlay").show();
 			}
 			$('table[data-table-name="Outage-Data"]').dataTable().fnClearTable();
 			angular.forEach($scope.updateData , function(data) {	
 				$('table[data-table-name="Outage-Data"]').dataTable().fnAddData([
						data.nEventId,
						data.cGibSerialNumber,
						data.cServiceMgrEmail,
						data.dEventDate,
						data.cOgSalesRegion,
						data.cSiteCustomerCountry,
						data.cUnitStatusDesc,
						data.cServiceRelationDescOg,
						data.cTechnologyDescOg,
						data.cEquipmentDesc,
						data.cMarketSegmentDesc,
						data.cSiteCustomerName,
						data.cOemLocationDesc,
						data.geDunsName,
						data.eventYear,
						data.eventQuarter,
						data.cMaintLvlDesc,
						data.ceventStatus,
						data.nMaintPolicyCyc,
						data.nMaintLevelSeq,
						data.tEventNotes,
						data.cDemSvcsStatus,
						data.cUsrIns,
						data.dIns,
						data.cEventDemStatusParts,
						data.cEventDemStatusSvcs,
						data.ceventDemStatusRepairs,
						data.fUnsolicedStatusFlag,
						data.dEstServiceStartDate,
						data.nEstServHoursCount,
						data.nMaintYear,
						data.cCustLoyaltyDescParts,
						data.cCustBehaviorDescParts,
						data.cSiteCustomerDuns,
						data.cSiteNameAlias,
						data.cSiteCustomerCity,
						data.cTechnologyDesc,
						data.cEngProjectRef,
						data.dUnitShipDate,
						data.dUnitCodDate,
						data.cAccountMgrEmail,
						data.cMainLvlCod
						],false);
 			});
 			$('table[data-table-name="Outage-Data"]').dataTable().fnDraw(true);
				  $('#colHideShowApply').click();
				
 		}
	
 		$(".exportOutageDataToExcel").click(function(){
 			var data;
             var flag = $("#AllData").is(":checked");
             if(flag)
 			{
 				data = 'ALL';
 			}
 			else
 			{
 				data = 'DEFAULT';
 			}
             download('/connect/fms/exportOutageData',JSON.stringify({
                "type": data,
                "businessSegment":$rootScope.businessSegment,
                "marketIndustry":$rootScope.marketIndustry ? $rootScope.marketIndustry : ""
            }),'OutageData Dtl');
 		});

			function download(url,data ,defaultFileName) {
			    var deferred = $q.defer();
			    $http.post(url,data, { responseType: "arraybuffer" }).success(
			        function (data, status, headers) {
			            var type = headers('Content-Type');
			            var disposition = headers('Content-Disposition');
			            if (disposition) {
			                var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
			                if (match[1])
			                    defaultFileName = match[1];
			            }
			            defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
			            var blob = new Blob([data], { type: type });
			            saveAs(blob, defaultFileName);
			            deferred.resolve(defaultFileName);                    
			        }).error(function () {
			            var e ;
			            deferred.reject(e);
			        });
			    return deferred.promise;
			}
			
 }]);
});