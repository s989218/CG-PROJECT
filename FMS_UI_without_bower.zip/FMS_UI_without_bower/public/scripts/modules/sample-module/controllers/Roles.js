define(['angular','../sample-module','jquery','datatablesNet'], function (angular,controllers,jquery,datatablesNet) 
 {
    'use strict';
    controllers.controller('RolesCtrl', ['$scope','$http','$q','$timeout', '$location','$state','$rootScope','AdminDataNetworkService', function ($scope, $http,$q,$timeout, $location, $state,$rootScope,AdminDataNetworkService) {
        
        $scope.adminLoader = true;
        $scope.roleData    = {};
        
        var modalList   = document.getElementById('addRoleDataModal');
        var span        = document.getElementsByClassName("addRoleClose")[0];
        
        var modalAlert  = document.getElementById('deleteRoleAlertModal');
        var spanAlert   = document.getElementsByClassName("deleteRoleClose")[0];
        
        var modalUsers  = document.getElementById('usersDataModal');
        var spanUsers   = document.getElementsByClassName("usersClose")[0];
        
        span.onclick = function(event) {
            if($scope.successMsg === true) {
                $scope.adminLoader = true;
                $scope.loadRolesData();  
                $scope.successMsg = false;
            }
            
            if($scope.fnAddRole === true) {
                $scope.resetRoleData();    
            }
            
            modalList.style.display = "none";
        }
        
        spanAlert.onclick = function(event) {
            $timeout(function () {
                $scope.successMsg  = false;
                modalAlert.style.display = "none";
            }, 100);
        }
        
        spanUsers.onclick = function(event) {
            modalUsers.style.display = "none";
        }
        
        window.onclick = function(event) {
            if (event.target === modalList) {
                if($scope.successMsg === true) {
                    $scope.adminLoader = true;
                    $scope.loadRolesData();  
                    $scope.successMsg = false;
                }
                
                if($scope.fnAddRole === true) {
                    $scope.resetRoleData();    
                }
                
                modalList.style.display = "none";
            }
            
            if (event.target === modalAlert) {
                $timeout(function () {
                    $scope.successMsg  = false;
                    modalAlert.style.display = "none";
                }, 100);
            }
            
            if (event.target === modalUsers) {
                modalUsers.style.display = "none";
            }
        }
        
        var dataTable;
        $scope.loadRolesData = function () {
            if ($.fn.DataTable.isDataTable( '#roles' ) ) {
                   $("#roles").dataTable().api().clear().draw();
                   $("#roles").dataTable().api().destroy();
                   $('#roles').empty(); 
            }
            
            AdminDataNetworkService.getAllRolesData().then(function(response) {
                $scope.objRolesData = response.RoleDetails;
                
                $scope.objRoleStatusData = [{ "value": 'Y', "text": "Active" }, { "value": 'N', "text": "In-Active" }];
                
                $scope.roleData.active   = 'Y';

                dataTable = $('#roles').DataTable({
                        rowReorder: {
                            selector: 'td:nth-child(2)'
                        },
                        responsive: true,
                        data: $scope.objRolesData,
                        "columnDefs": [
                            {
                                "targets": [ 3 ],
                                "visible": false,
                                "searchable": false
                            },
                            { className: "dt-center", "targets": [2,4] },
                            { className: "dt-left", "targets": [0,1] }
                        ],
                        "columns": [
                            { data:"role_name",title:"Role Name" },
                            { data:"role_name_desc",title:"Description" },
                            { 
                                data:"active",
                                title:"Status",
                                "mData": null,
                                "render": function (data, type, full, meta) {
                                    if (data) {
                                        if (data.active === "Y") {
                                           return "Active";
                                        } else {
                                           return "Inactive";
                                        }
                                    } else {
                                        return data;
                                    }
                                 }
                            },
                            { data:"role_id",title:"Role ID" },
                            {
                                title:"Actions",
                                "bSortable": false,
                                "bSearchable": false,
                                mRender: function (data, type, row) {
                                    return '<a class="table-edit" title="Edit" data-id="' + row.role_id + '"><i class="fa fa-pencil-square-o fa-2x" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class="table-delete" title="Delete" data-id="' + row.role_id + '"><i class="fa fa-trash-o fa-2x" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class="table-users" title="View assigned user details" data-id="' + row.role_id + '"><i class="fa fa-user fa-2x" aria-hidden="true"></i></a>'
                                }
                            }
                        ]
                });
                
                $('body #roles tbody').on( 'click', 'a.table-delete', function () { 
                    var current_row = $(this).parents('tr');
                    if (current_row.hasClass('child')) {
                        current_row = current_row.prev();
                    }
                    var data = dataTable.row(current_row).data();
                    
                    $scope.deleteRoleID   = data.role_id;
                    $scope.deleteRoleName = data.role_name;
                    
                    modalAlert.style.display = "block";
                    
                    $("#oDeleteRole").prop("disabled", false);
                    $("#oDeleteRole").css("background", "#22A2E3");
                });
                
                $('body #roles tbody').on( 'click', 'a.table-edit', function () { 
                    var current_row = $(this).parents('tr');
                    if (current_row.hasClass('child')) {
                        current_row = current_row.prev();
                    }
                    var data = dataTable.row(current_row).data();
                    
                    $scope.fnAddRole                = false;
                    $scope.fnEditRole               = true;
                    
                    $scope.dataObject              = {};
                    $scope.dataObject.roleId       = data.role_id;
                    $scope.dataObject.roleName     = data.role_name;
                    $scope.dataObject.roleNameDesc = data.role_name_desc;
                    $scope.dataObject.active       = data.active;
                    
                    $scope.roleData.active          = data.active;
                    
                    $timeout(function () {
                        modalList.style.display = "block";
                        
                        $("#oUpdateRole").prop("disabled", false);
                        $("#oUpdateRole").css("background", "#22A2E3");
                    }, 100);
                });
                
                $('body #roles tbody').on( 'click', 'a.table-users', function () { 
                    var current_row = $(this).parents('tr');
                    if (current_row.hasClass('child')) {
                        current_row = current_row.prev();
                    }
                    var data = dataTable.row(current_row).data();
                    
                    $timeout(function () {
                        modalUsers.style.display = "block";
                    }, 100);
                    
                    if ($.fn.DataTable.isDataTable( '#users' ) ) {
                        $("#users").dataTable().api().clear().draw();
                        $("#users").dataTable().api().destroy();
                        $('#users').empty(); 
                    }
                    
                    $scope.usersDataHeaderName = data.role_name;
                    
                    AdminDataNetworkService.getUserDetailsBasedOnRoleData(data.role_id).then(function(response) {
                        $scope.objUserDetailsData = response.userDetailsBasedOnRole;

                        $('#users').DataTable({
                                rowReorder: {
                                    selector: 'td:nth-child(2)'
                                },
                                responsive: true,
                                data: $scope.objUserDetailsData,
                                "columns": [
                                    { data:"user_id",title:"SSO" },
                                    { data:"first_name",title:"First Name" },
                                    { data:"last_name",title:"Last Name" }
                                ]
                        });

                    });
                });
                
                $scope.adminLoader = false;  
            });
        }
        
        $scope.loadRolesData();
        
        $scope.addRole = function () {
            $scope.successMsg       = false;
            $scope.fnAddRole        = true;
            $scope.fnEditRole       = false;
            
            modalList.style.display = "block";
            $scope.resetRoleData();
        }
        
        $scope.closeAlertBox = function () {
            $scope.successMsg  = false;
            modalAlert.style.display = "none";
        }
        
        $scope.deleteRoleData = function() {
            $scope.successMsg = false;
            $scope.failureMsg = false;
            
            if ($scope.deleteRoleID === "") {
                $scope.successMsg = false;
                $scope.failureMsg = true;
                $scope.failureMessage   = "Something went wrong! Please try again later."
            } else {
                $scope.roleData             = {};
                $scope.roleData['action']   = "deleteRole";
                $scope.roleData['roleId']   = $scope.deleteRoleID;
                $scope.roleData['roleName'] = $scope.deleteRoleName;
                
                AdminDataNetworkService.manageRolesData(JSON.stringify($scope.roleData)).then(function(response) {
                    $rootScope.safeApply(function() {
                        if (response === "SUCCESS") {
                            $scope.successMsg = true;
                            $scope.failureMsg = false;
                            $scope.successMessage = "Role Deleted Successfully.";
                            $scope.loadRolesData();
                        } else if (response==="FAILURE") {
                            $scope.successMsg = false;
                            $scope.failureMsg = true;
                            $scope.failureMessage   = "Something went wrong! Please try again later.";
                        } else {
                            $scope.successMsg = false;
                            $scope.failureMsg = true;
                            $scope.failureMessage   = response
                        }
                        
                        $("#oDeleteRole").prop("disabled", true);
                        $("#oDeleteRole").css("background", "#C0C0C0");
                        
                        $scope.deleteRoleID   = "";
                        $scope.deleteRoleName = "";
                    });
                });    
            }
        }
        
        $scope.saveRoleData = function(status) {
            $scope.successMsg = false;
            $scope.failureMsg = false;
            
            if($('#aRoleId').val().trim() === "") {
                $scope.roleData['roleId'] = null;
            } else {
                $scope.roleData['roleId'] = $('#aRoleId').val().trim();
            }
            
            if($('#aRoleName').val().trim() === "") {
                $scope.roleData['roleName'] = null;
            } else {
                $scope.roleData['roleName'] = $('#aRoleName').val().trim();
            }
        
            if($('#aRoleNameDesc').val().trim() === "") {
                $scope.roleData['roleNameDesc'] = null;
            } else {
                $scope.roleData['roleNameDesc'] = $('#aRoleNameDesc').val().trim();
            }
            
            $timeout(function () {
                $scope.failureMsg = false; 
            },5000);
            
            var nameReg = /^[a-zA-Z][a-zA-Z0-9\_\s]/;
            
            if ($scope.roleData['roleName']  === null || !nameReg.test($scope.roleData['roleName'])) {
                $scope.successMsg  = false;
                $scope.failureMsg  = true;
                $scope.failureMessage = "Please enter valid role name";
            } else if ($scope.roleData['roleNameDesc']  === null) {
                $scope.successMsg  = false;
                $scope.failureMsg  = true;
                $scope.failureMessage = "Please enter role description";
            } else {
                $scope.roleData['action']    = status;
                $scope.roleData['active']    = $scope.roleData.active;

                if(status === "addRole") {
                    $scope.roleData['createdBy'] = $rootScope.userSSO;
                } else {
                    $scope.roleData['createdBy'] = null;
                }
                
                $scope.roleData['updatedBy'] = $rootScope.userSSO;
                
                AdminDataNetworkService.manageRolesData(JSON.stringify($scope.roleData)).then(function(response) {
                    $rootScope.safeApply(function() {
                        if (response === "SUCCESS") {
                            $scope.successMsg = true;
                            $scope.failureMsg = false;
                            
                            if(status === "addRole") {
                                $scope.successMessage = "Added Successfully."
                            } else {
                                $scope.successMessage = "Updated Successfully."
                            }
                            $scope.loadRolesData();
                        } else if (response==="FAILURE") {
                            $scope.successMsg  = false;
                            $scope.failureMsg  = true;
                            $scope.failureMessage = "Something went wrong! Please try again later."
                        } else {
                            $scope.successMsg  = false;
                            $scope.failureMsg  = true;
                            $scope.failureMessage = response
                        }
                        
                        if(status === "addRole") {
                            $scope.resetRoleData();
                        } else {
                            $("#oUpdateRole").prop("disabled", true);
                            $("#oUpdateRole").css("background", "#C0C0C0");
                        }
                        
                    });
                });
            }
        };
        
        $scope.exportRoles = function () {
            $scope.adminLoader = true;
            
            var urldata;
            urldata="connect/fms/exportUserManagementData/rolesData";
            
            download(urldata,{},'FMS Roles');    
        }
        
        function download(url,data,defaultFileName) {
            var deferred = $q.defer();
            $http.post(url,data, { responseType: "arraybuffer" }).success(
                function (data, status, headers) {
                    var type = headers('Content-Type');
                    var disposition = headers('Content-Disposition');
                    if (disposition) {
                        var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                        if (match[1])
                            defaultFileName = match[1];
                    }
                    defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                    var blob = new Blob([data], { type: type });
                    saveAs(blob, defaultFileName);
                    deferred.resolve(defaultFileName);  
                    $scope.adminLoader = false;
                }).error(function () {
                    var e ;
                    deferred.reject(e);
                });
            return deferred.promise;
        } 
        
        $scope.resetRoleData = function() {
            $('#aRoleId').val('');
            $('#aRoleName').val('');
            $('#aRoleNameDesc').val('');
            $scope.roleData.active   = 'Y';
            
            $("input").removeAttr("invalid");
            $("div").removeClass("label-is-floating is-invalid");
        };
        
        $scope.showRolesFiltersToggle = function (filterKey, showFilter) {
            if ($('.kd'+filterKey+'Filter').is(':visible')) {
                $('.kd'+filterKey+'Filter').slideUp(200);
                $scope[showFilter] = false;
            } else {
                $scope[showFilter] = true;
                $('.kd'+filterKey+'Filter').slideDown(200);
            }   
        }
    }]);
});