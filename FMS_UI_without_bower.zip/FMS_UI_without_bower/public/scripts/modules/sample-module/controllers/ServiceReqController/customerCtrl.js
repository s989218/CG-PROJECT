define(['angular', '../../sample-module', 'jquery', 'datatablesNetMin', 'datatablesNet', 'multiselectdrpdwn', 'jqueryMultiSelect'],
    function(angular, controllers) {
        'use strict';
        controllers.controller('ServiceReqTopCustomerCtrl', ['ServiceReqCustomerService', 'ServiceReqTechnoRegionService', 'ServiceReqTableService', 'serviceReqChartService', 'LoaderService', '$rootScope', '$scope', 'NetworkCallService', 'CreateHighChartService', '$timeout', '$http', '$q',
            function(ServiceReqCustomerService, ServiceReqTechnoRegionService, ServiceReqTableService, serviceReqChartService, LoaderService, $rootScope, $scope, NetworkCallService, CreateHighChartService, $timeout, $http, $q) {

                $rootScope.ibo_equipmentyear = sessionStorage.ibo_equipmentyear;
                $scope.reg_Error = false;
                var chart;

                $('.backClass').click(function() {
                    $state.go('NewMetrics');
                });
                
                jQuery.fn.center = function() {
                    this.css({
                        top: ($(window).outerHeight()) / 2,
                        left: ($(window).outerWidth()) / 2
                    });
                    return this;
                };
                
                $(".loading").center();

                function loaderOps(state) {
                    LoaderService.loaderOps(state);
                }

                $scope.regionSelected = true;
                $('.errorIndicator').hide();
                loaderOps(true);
                
                /* To Get Rid of Apply Already In Progress Error */
                $scope.safeApply = function(fn) {
                    $timeout(fn);
                }
                var defaultData = {};
                $scope.selected = 0;

                function checkParent(props) {
                    if (props.ngModel === 'depSearch.regions') {
                        if ($scope.depSearch.regions.length > 0) {
                            $('select.dependentFilter[id="primaryCountrySearch"]').prop('disabled', 'false');
                            $('select.dependentFilter[id="primaryCountrySearch"]').siblings().children().removeClass('disabled');
                        } else {
                            $('select.dependentFilter[id="primaryCountrySearch"]').prop('disabled', 'true');
                            $('select.dependentFilter[id="primaryCountrySearch"]').siblings().children().addClass('disabled');
                        }
                    }

                }

                function getSelectedValue(id) {
                    var selector = "select.dependentFilter[id='" + id + "']";
                    if (id === 'depsalesRegionSearch' && $(selector).val() != null) {
                        return $(selector).val();
                    } else {
                        if ($(selector).val() !== undefined) {
                            var values = [];
                            _.forEach($(selector).val(), function(choice) {
                                values.push(choice);
                            });
                            return values.join("|");
                        } else
                            return "";
                    }
                }

                var tableCreate = function(custNameDataBean, serviceData) {
                    var dataObj;
                    if (arguments.length > 1 && arguments[2] === true) {
                        dataObj = ServiceReqTableService.customerCountryTableData(custNameDataBean);
                        ServiceReqTableService.initTable(dataObj['dataArr'], dataObj['columns'], 'ServiceReq-by-Top-Cust-Country-Data', dataObj['regionCount']);
                        $('#countryTable').addClass('in');
                        setTimeout(function() {
                            $('.countryTableDiv').show();
                        }, 500);
                    } else {
                        dataObj = ServiceReqTableService.customerTableData(custNameDataBean);
                        ServiceReqTableService.initTable(dataObj['dataArr'], dataObj['columns'], 'ServiceReq-by-Top-Cust-Data', dataObj['regionCount']);
                        $('#collapse4').addClass('in');
                        setTimeout(function() {
                            $('.regionTableDiv').show();
                        }, 500);
                    }
                }


                var updateTopCustDatatable = function(response) {
                    var serviceData;
                    if (arguments.length > 1 && arguments[1] === true) {
                        serviceData = (ServiceReqTableService.countryDataProcessing(response.TopCustomers));
                    } else
                        serviceData = (ServiceReqCustomerService.processAllCustomerData(response.TopCustomers));
                    $scope.custNameData = response.TopCustomers;
                    var customers = serviceData['customers'],
                        chartData = serviceData['chartData'];
                    if (arguments.length > 1 && arguments[1] === true) {
                        if (response.TopCustomers.length > 0) {
                            tableCreate(response.TopCustomers, serviceData, true);
                            $scope.createServiceReqChart(customers, chartData, 'country_chart');
                            $('#countryChart').addClass('in');
                            $scope.safeApply(function() {
                                $scope.dep_custDataExp = true;
                                $scope.dep_custChartExp = true;
                                $('.ctrError').hide(100);
                                $('.ctrView').show(100);
                            });
                            setTimeout(function() {
                                setTimeout(function() {
                                    $('#countryChart').height($('#country_chart').outerHeight() + 50);
                                    $('#countryTable > #tableDivision').height($('#Outage-by-Top-Cust-Country-Data_wrapper').outerHeight() + 50);
                                    $('#countryChart > #techRegionChart').outerHeight($('#countryChart').height());
                                    $('#countryTable').outerHeight($('#countryTable > #tableDivision').outerHeight() + 20);
                                }, 250);
                            }, 200);
                        } else {
                            $('.ctrError').show(100).css('display', 'flex');
                            $('.ctrView').hide(100);
                        }
                    } else {
                        if (response.TopCustomers.length > 0) {
                            tableCreate(response.TopCustomers, serviceData);
                            $scope.createServiceReqChart(customers, chartData, 'container2');
                            $('#collapse3').addClass('in');
                            $scope.safeApply(function() {
                                $scope.custDataExp = true;
                                $scope.custChartExp = true;
                                $('.regError').hide(100);
                                $('.regView').show(100);
                            });
                            setTimeout(function() {
                                setTimeout(function() {
                                    $('#collapse3').height($('#container2').outerHeight() + 50);
                                    $('#collapse4 > #tableDivision').height($('#ServiceReq-by-Top-Cust-Data_wrapper').outerHeight() + 50);
                                    $('#collapse3 > #techRegionChart').outerHeight($('#collapse3').height());
                                    $('#collapse4').outerHeight($('#collapse4 > #tableDivision').outerHeight() + 20);
                                }, 250);
                            }, 200);
                        } else {
                            $('.regError').show(100).css('display', 'flex');
                            $('.regView').hide(100);
                        }
                    }

                    loaderOps(false);
                }
                
                window.addEventListener('px-tab-changed', function(event) {
                    var selectedTab = parseInt(event.target.selected);
                    Polymer.dom().querySelector('px-tab-pages').selected = selectedTab;
                    if (selectedTab === 0) {
                        $('.rstFltr').show()
                    } else {
                        $('.rstFltr').hide()
                    }
                });

                /* Create Chart When transferred from NewMetrics Page */
                NetworkCallService.getServiceReqDropdown().then(function(response) {

                    $scope.safeApply(function() {
                        $scope.openedDropdownBean = response.ServiceRequestOpened;
                        $scope.currTypeOfIssueDropdownBean = response.ServiceRequestIssue;
                        $scope.projectPhaseDropdownBean = response.ServiceRequestProjectPhase;
                        $scope.stateDropdownBean = response.ServiceRequestState;
                        $scope.assignedGroupDropdownBean = response.ServiceRequestGroup;
                        $scope.statusDropdownBean = response.ServiceRequestStatus;
                        $scope.entryinCurStatusDropdownBean = response.ServiceRequestCurStatus;
                        $scope.jobTypeDropdownBean = response.ServiceRequestJob;
                        $scope.customerNameDropdownBean = response.ServiceRequestCustomerName;
                        $scope.machineTechDropdownBean = response.ServiceRequestMachineTechnology;
                        $scope.yearQtrDropdownBean = response.ServiceRequestYearQtr;
                    });
                    setTimeout(function() {
                        $("select:not(#depsalesRegionSearch,#depsalesCountrySearch,#ServiceReq-by-Top-Cust-Data_length select,#marketIndustryDropdownBean)").multipleSelect({
                            filter: true
                        });
                        $("select#primaryCountrySearch").multipleSelect({
                            filter: true,
                            selectAll: false
                        });
                    }, 200);
                    resizeAll();
                });

                $scope.searchData = function() {
                    loaderOps(true);
                    var jsonData = [];
                    var item = {};
                    item["case_number"] = $("#caseNumSearch").val();
                    item["opened"] = ($("#openedSearch").val() === undefined || !$("#openedSearch").val()) ? "" : '^' + $("#openedSearch").val().join("$|^") + '$';
                    item["current_type_of_issue"] = ($("#current_type_of_issueSearch").val() === undefined || !$("#current_type_of_issueSearch").val()) ? "" : '^' + $("#current_type_of_issueSearch").val().join("$|^") + '$';
                    item["project_phase"] = ($("#projectPhaseSearch").val() === undefined || !$("#projectPhaseSearch").val()) ? "" : '^' + $("#projectPhaseSearch").val().join("$|^") + '$';
                    item["state"] = ($("#stateSearch").val() === undefined || !$("#stateSearch").val()) ? "" : '^' + $("#stateSearch").val().join("$|^") + '$';
                    item["assigned_group"] = ($("#assignedGroupSearch").val() === undefined || !$("#assignedGroupSearch").val()) ? "" : '^' + $("#assignedGroupSearch").val().join("$|^") + '$';
                    item["status"] = ($("#statusSearch").val() === undefined || !$("#statusSearch").val()) ? "" : '^' + $("#statusSearch").val().join("$|^") + '$';
                    item["entry_in_the_cur_status"] = ($("#entry_in_the_cur_statusSearch").val() === undefined || !$("#entry_in_the_cur_statusSearch").val()) ? "" : '^' + $("#entry_in_the_cur_statusSearch").val().join("$|^") + '$';
                    item["job_type"] = ($("#jobTypeSearch").val() === undefined || !$("#jobTypeSearch").val()) ? "" : '^' + $("#jobTypeSearch").val().join("$|^") + '$';
                    item["customer_name"] = ($("#customerNameSearch").val() === undefined || !$("#customerNameSearch").val()) ? "" : '^' + $("#customerNameSearch").val().join("$|^") + '$';
                    item["machine_technology_og"] = ($("#machineTechnologyOgSearch").val() === undefined || !$("#machineTechnologyOgSearch").val()) ? "" : '^' + $("#machineTechnologyOgSearch").val().join("$|^") + '$';
                    item["year"] = ($("#yearSearch").val() === undefined || !$("#yearSearch").val()) ? "" : '^' + $("#yearSearch").val().join("$|^") + '$';
                    item["quarter"] = ($("#eventQuarterSearch").val() === undefined || !$("#eventQuarterSearch").val()) ? "" : '^' + $("#eventQuarterSearch").val().join("$|^") + '$';
                    jsonData.push(item);
                    NetworkCallService.getServiceReqMetricsFilterData(jsonData).then(function(response) {
                        $scope.responseData = response;
                        updateTopCustDatatable(response);
                        resizeAll();
                    });
                    // Raw data parameters
                    $scope.regionServReqRawData = [];
                    $scope.flgRegionServReqRawData = false;
                }

                function resizeCharts() {
                    $('#tableDiv').show();
                    setTimeout(function() {
                        setTimeout(function() {
                            $('#collapse3').height($('#container2').outerHeight() + 50);
                            $('#tableDivision').height($('#ServiceReq-by-Top-Cust-Data_wrapper').outerHeight() + 50);
                            $('#collapse3 > #techRegionChart').outerHeight($('#collapse3').height());
                            $('#collapse4').outerHeight($('#collapse4 > #tableDivision').outerHeight() + 20);
                        }, 250);
                    }, 200);
                    resizeAll();
                    loaderOps(false);
                }
                
                $scope.clearData = function() {
                    loaderOps(true);
                    $scope.safeApply(function() {
                        $scope.custChartExp = true;
                        $scope.custDataExp = true;
                    });
                    document.getElementById("caseNumSearch").value = "";
                    if (!defaultData['indep_filters'])
                        NetworkCallService.getServiceReqMetricsFilterData(ServiceReqTechnoRegionService.searchDataService()).then(function(response) {
                            defaultData['indep_filters'] = response;
                            var serviceData = (ServiceReqCustomerService.processCustomerData(response.TopCustomers));
                            var customers = serviceData['customers'],
                                chartData = serviceData['chartData'];
                            $scope.createServiceReqChart(customers, chartData, 'container2');
                            var dataObj = (ServiceReqTableService.topCustomerTableData(response.TopCustomers));
                            $scope.safeApply(function() {
                                ServiceReqTableService.initTable(dataObj['dataArr'], dataObj['columns'], 'ServiceReq-by-Top-Cust-Data', dataObj['regionCount']);
                                $scope.custDataExp = true;
                                $scope.custChartExp = true;
                                resizeCharts();
                            });
                        });
                    else {
                        var serviceData = (ServiceReqCustomerService.processCustomerData(defaultData['indep_filters'].TopCustomers));
                        var customers = serviceData['customers'],
                            chartData = serviceData['chartData'];
                        $scope.createServiceReqChart(customers, chartData, 'container2');
                        var dataObj = (ServiceReqTableService.topCustomerTableData(defaultData['indep_filters'].TopCustomers));
                        $scope.safeApply(function() {
                            ServiceReqTableService.initTable(dataObj['dataArr'], dataObj['columns'], 'ServiceReq-by-Top-Cust-Data', dataObj['regionCount']);
                            $scope.custDataExp = true;
                            $scope.custChartExp = true;
                            resizeCharts();
                        });
                    }
                    $('service-independent-filter').find('.ms-choice > span').html('');
                    $('service-independent-filter').find('input[type="checkbox"]').attr('checked', false);
                    $('service-independent-filter').find("select").val('')
                    $('#depsalesCountrySearch').empty();
                    $('.regError').hide(100);
                    $('.regView').show(100);
                    loaderOps(false);
                    // Raw data parameters
                    $scope.regionServReqRawData = [];
                    $scope.flgRegionServReqRawData = false;
                }

                /* Polymer Tab Initialization */
                var checkStatus = setInterval(function() {
                    if (Polymer.dom().node.readyState === 'complete') {
                        Polymer.dom().querySelector('px-tab-pages').selected = 0;
                        Polymer.dom().querySelector('px-tab-set').selected = 0;
                        clearInterval(checkStatus);
                    }
                }, 100);
                /* Creation of chart at start */
                NetworkCallService.getServiceReqMetricsFilterData(ServiceReqTechnoRegionService.searchDataService()).then(function(response) {
                    defaultData['indep_filters'] = response;
                    var serviceData = (ServiceReqCustomerService.processCustomerData(response.TopCustomers));
                    var customers = serviceData['customers'],
                        chartData = serviceData['chartData'];
                    $scope.createServiceReqChart(customers, chartData, 'container2');
                    var dataObj = (ServiceReqTableService.topCustomerTableData(response.TopCustomers));
                    $scope.safeApply(function() {
                        ServiceReqTableService.initTable(dataObj['dataArr'], dataObj['columns'], 'ServiceReq-by-Top-Cust-Data', dataObj['regionCount']);
                        $scope.custDataExp = true;
                        $scope.custChartExp = true;
                        resizeCharts();
                    });
                    setTimeout(function() {
                        loaderOps(false);
                        $('#depsalesRegionSearch').change(function() {
                            $scope.getCountries();
                        });
                    }, 500);
                });

                $scope.exportCharts = function(type) {
                    $scope.exportChart(type);
                };
                
                $scope.excelDownload = function(id) {
                    ServiceReqTableService.excelDownload(id);
                };

                $scope.shwServReqRawData = function(tableId, methodCall) {
                    var jsonData = [];
                    var item = {};
                    item["case_number"] = $("#caseNumSearch").val();
                    item["opened"] = ($("#openedSearch").val() === undefined || !$("#openedSearch").val()) ? "" : '^' + $("#openedSearch").val().join("$|^") + '$';
                    item["current_type_of_issue"] = ($("#current_type_of_issueSearch").val() === undefined || !$("#current_type_of_issueSearch").val()) ? "" : '^' + $("#current_type_of_issueSearch").val().join("$|^") + '$';
                    item["project_phase"] = ($("#projectPhaseSearch").val() === undefined || !$("#projectPhaseSearch").val()) ? "" : '^' + $("#projectPhaseSearch").val().join("$|^") + '$';
                    item["state"] = ($("#stateSearch").val() === undefined || !$("#stateSearch").val()) ? "" : '^' + $("#stateSearch").val().join("$|^") + '$';
                    item["assigned_group"] = ($("#assignedGroupSearch").val() === undefined || !$("#assignedGroupSearch").val()) ? "" : '^' + $("#assignedGroupSearch").val().join("$|^") + '$';
                    item["status"] = ($("#statusSearch").val() === undefined || !$("#statusSearch").val()) ? "" : '^' + $("#statusSearch").val().join("$|^") + '$';
                    item["entry_in_the_cur_status"] = ($("#entry_in_the_cur_statusSearch").val() === undefined || !$("#entry_in_the_cur_statusSearch").val()) ? "" : '^' + $("#entry_in_the_cur_statusSearch").val().join("$|^") + '$';
                    item["job_type"] = ($("#jobTypeSearch").val() === undefined || !$("#jobTypeSearch").val()) ? "" : '^' + $("#jobTypeSearch").val().join("$|^") + '$';
                    item["customer_name"] = ($("#customerNameSearch").val() === undefined || !$("#customerNameSearch").val()) ? "" : '^' + $("#customerNameSearch").val().join("$|^") + '$';
                    item["machine_technology_og"] = ($("#machineTechnologyOgSearch").val() === undefined || !$("#machineTechnologyOgSearch").val()) ? "" : '^' + $("#machineTechnologyOgSearch").val().join("$|^") + '$';
                    item["year"] = ($("#yearSearch").val() === undefined || !$("#yearSearch").val()) ? "" : '^' + $("#yearSearch").val().join("$|^") + '$';
                    item["quarter"] = ($("#eventQuarterSearch").val() === undefined || !$("#eventQuarterSearch").val()) ? "" : '^' + $("#eventQuarterSearch").val().join("$|^") + '$';

                    jsonData.push(item);

                    if (methodCall === 'ServReqRegion') {
                        if ($scope.regionServReqRawData === undefined)
                            $scope.regionServReqRawData = [];

                        $("#regServReqRawData").attr('style', 'display: block');

                        if ($scope.regionServReqRawData === undefined || $scope.regionServReqRawData.length === 0) {
                            calServReqRawService(jsonData, tableId, methodCall);
                            $scope.flgRegionServReqRawData = true;
                        }

                    }
                };

                function calServReqRawService(jsonData, tableId, methodCall) {
                    loaderOps(true);
                    $http.post("connect/fms/getRawDataIBOPage/" + "serviceTechReg", JSON.stringify({
                        "data": jsonData
                    })).then(function(response) {
                        $scope.servReqColumnHeaders = response.data.ServiceColumnHeaders;
                        $scope.rawServReqData = response.data.ServiceTechRawData;

                        if (methodCall === 'ServReqRegion')
                            $scope.regionServReqRawData = $scope.rawServReqData;


                        if ($.fn.DataTable.isDataTable('#' + tableId)) {
                            $('#' + tableId).dataTable().api().clear().draw();
                            $('#' + tableId).dataTable().api().destroy();
                            $('#' + tableId).empty();
                        }

                        $('#' + tableId).DataTable({
                            data: $scope.rawServReqData,
                            "sPaginationType": "simple_numbers",
                            "bFilter": true,
                            "retrieve": true,
                            "scrollX": false,
                            "paging": true,
                            columns: _.sortBy($scope.servReqColumnHeaders, 'row_id')

                        });
                        loaderOps(false);
                    });
                }

                $scope.ServReqRawDataExcelDownload = function(methodCall) {
                    var jsonData = [];
                    var item = {};
                    var fileName = "Service Request Top Customers data";

                    item["case_number"] = $("#caseNumSearch").val();
                    item["opened"] = ($("#openedSearch").val() === undefined || !$("#openedSearch").val()) ? "" : '^' + $("#openedSearch").val().join("$|^") + '$';
                    item["current_type_of_issue"] = ($("#current_type_of_issueSearch").val() === undefined || !$("#current_type_of_issueSearch").val()) ? "" : '^' + $("#current_type_of_issueSearch").val().join("$|^") + '$';
                    item["project_phase"] = ($("#projectPhaseSearch").val() === undefined || !$("#projectPhaseSearch").val()) ? "" : '^' + $("#projectPhaseSearch").val().join("$|^") + '$';
                    item["state"] = ($("#stateSearch").val() === undefined || !$("#stateSearch").val()) ? "" : '^' + $("#stateSearch").val().join("$|^") + '$';
                    item["assigned_group"] = ($("#assignedGroupSearch").val() === undefined || !$("#assignedGroupSearch").val()) ? "" : '^' + $("#assignedGroupSearch").val().join("$|^") + '$';
                    item["status"] = ($("#statusSearch").val() === undefined || !$("#statusSearch").val()) ? "" : '^' + $("#statusSearch").val().join("$|^") + '$';
                    item["entry_in_the_cur_status"] = ($("#entry_in_the_cur_statusSearch").val() === undefined || !$("#entry_in_the_cur_statusSearch").val()) ? "" : '^' + $("#entry_in_the_cur_statusSearch").val().join("$|^") + '$';
                    item["job_type"] = ($("#jobTypeSearch").val() === undefined || !$("#jobTypeSearch").val()) ? "" : '^' + $("#jobTypeSearch").val().join("$|^") + '$';
                    item["customer_name"] = ($("#customerNameSearch").val() === undefined || !$("#customerNameSearch").val()) ? "" : '^' + $("#customerNameSearch").val().join("$|^") + '$';
                    item["machine_technology_og"] = ($("#machineTechnologyOgSearch").val() === undefined || !$("#machineTechnologyOgSearch").val()) ? "" : '^' + $("#machineTechnologyOgSearch").val().join("$|^") + '$';
                    item["year"] = ($("#yearSearch").val() === undefined || !$("#yearSearch").val()) ? "" : '^' + $("#yearSearch").val().join("$|^") + '$';
                    item["quarter"] = ($("#eventQuarterSearch").val() === undefined || !$("#eventQuarterSearch").val()) ? "" : '^' + $("#eventQuarterSearch").val().join("$|^") + '$';

                    jsonData.push(item);
                    download("/connect/fms/exportRawDataMetrics/" + "serviceTechReg/" + fileName, jsonData, fileName);
                };

                function download(url, data, defaultFileName) {
                    var deferred = $q.defer();
                    $http.post(url, JSON.stringify({
                        "data": data
                    }), {
                        responseType: "arraybuffer"
                    }).success(
                        function(data, status, headers) {
                            var type = headers('Content-Type');
                            var disposition = headers('Content-Disposition');
                            if (disposition) {
                                var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                                if (match[1])
                                    defaultFileName = match[1];
                            }
                            defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                            var blob = new Blob([data], {
                                type: type
                            });
                            saveAs(blob, defaultFileName);
                            deferred.resolve(defaultFileName);
                        }).error(function() {
                        var e;
                        deferred.reject(e);
                    });
                    return deferred.promise;
                };

                $scope.createServiceReqChart = function(xSeries, ySeries, id, chartColors, state) {
                    if (!state)
                        state = null;
                    Highcharts.setOptions({
                        global: {
                            useUTC: false,

                        },
                        lang: {
                            decimalPoint: '.',
                            thousandsSep: ','
                        }
                    });
                    chart = new Highcharts.Chart({
                        chart: {
                            renderTo: id,
                            type: 'bar',
                            events: {
                                click: function() {
                                    if (state !== null)
                                        $state.go(state);
                                }
                            }
                        },
                        title: {
                            text: ''
                        },
                        colors: chartColors,
                        xAxis: {
                            categories: xSeries
                        },
                        yAxis: {
                            min: 0,
                            title: {
                                text: 'Number of Service Request'
                            }
                        },
                        tooltip: {
                            pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:,.0f}</b> ({point.percentage:.2f}%)<br/>',
                            shared: true
                        },
                        legend: {
                            itemStyle: {
                                color: 'black',
                                fontWeight: 'normal',
                                fontSize: '12px',
                            }
                        },
                        plotOptions: {
                            series: {
                                stacking: 'normal',
                                borderWidth: 0,
                                point: {
                                    events: {
                                        click: function() {
                                            $scope.refreshServiceCustMetrics(this.series.name, this.category, id);

                                        }
                                    }
                                }
                            }
                        },
                        credits: {
                            enabled: false
                        },
                        series: ySeries,
                        responsive: {
                            rules: [{
                                condition: {
                                    maxWidth: 500
                                },
                                chartOptions: {
                                    legend: {
                                        align: 'center',
                                        verticalAlign: 'bottom',
                                        layout: 'horizontal'
                                    },
                                    yAxis: {
                                        labels: {
                                            align: 'left',
                                            x: 0,
                                            y: -5
                                        },
                                        title: {
                                            text: null
                                        }
                                    },
                                    subtitle: {
                                        text: null
                                    },
                                    credits: {
                                        enabled: false
                                    }
                                }
                            }]
                        }
                    });

                };

                $scope.refreshServiceCustMetrics = function(name, category, id) {
                    if (id === 'container2') {
                        $('service-independent-filter').find('.customerNameSearch .ms-choice > span').html(category);
                        $('service-independent-filter').find('.customerNameSearch input[value="' + category + '"]').attr('checked', true);
                        $('service-independent-filter').find("#customerNameSearch").val(category);
                        $('service-independent-filter').find("#customerNameSearch").multipleSelect("refresh");

                        $('service-independent-filter').find('.stateSearch .ms-choice > span').html(name);
                        $('service-independent-filter').find('.stateSearch input[value="' + name + '"]').attr('checked', true);
                        $('service-independent-filter').find("#stateSearch").val(name);
                        $('service-independent-filter').find("#stateSearch").multipleSelect("refresh");
                        $scope.searchData();
                    } else if (id === 'country_chart') {
                        $('service-independent-filter').find('.customerNameSearch .ms-choice > span').html(name);
                        $('service-independent-filter').find('.customerNameSearch input[value="' + name + '"]').attr('checked', true);
                        $('service-independent-filter').find("#customerNameSearch").val(name);
                        $('service-independent-filter').find("#customerNameSearch").multipleSelect("refresh");

                        $('service-independent-filter').find('.stateSearch .ms-choice > span').html(category);
                        $('service-independent-filter').find('.stateSearch input[value="' + category + '"]').attr('checked', true);
                        $('service-independent-filter').find("#stateSearch").val(category);
                        $('service-independent-filter').find("#stateSearch").multipleSelect("refresh");
                        $scope.dep_searchData();
                    }
                };

                $scope.exportChart = function(type) {
                    if (type === 'JPEG') {
                        chart.exportChart({
                            type: 'image/jpeg',
                            filename: 'Top Customer'
                        }, {
                            subtitle: {
                                text: ''
                            }
                        });
                    }
                    
                    if (type === 'XLS') {
                        chart.exportChart({
                            type: 'application/vnd.ms-excel',
                            filename: 'my-excel'
                        }, {
                            subtitle: {
                                text: ''
                            }
                        });
                    }
                }
            }
    ]);
});