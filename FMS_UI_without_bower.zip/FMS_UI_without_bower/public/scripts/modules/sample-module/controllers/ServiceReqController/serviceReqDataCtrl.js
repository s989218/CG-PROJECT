define(['angular', '../../sample-module', 'jquery', 'datatablesNetMin', 'datatablesNet', 'bootstrap-popover', 'fileSaver', 'datatablesNetRowReorder', 'datatablesNetResponsive'], function(angular, controllers) {
    'use strict';
    controllers.controller('serviceReqDataCtrl', ['$scope', '$rootScope', '$http', '$location', '$state', '$q', function($scope, $rootScope, $http, $location, $state, $q) {
        jQuery.fn.center = function() {
            this.css({
                top: ($(window).outerHeight()) / 2,
                left: ($(window).outerWidth()) / 2
            });
            return this;
        };
        
    	$scope.tmsToggleStatus = true;
		if($rootScope.businessSegment === "TMS"){
			$("#mainDivSection").hide();
			$scope.tmsToggleStatus = false;
		}
        $scope.flag = true;
        $scope.selectAll = false;
        $(".overlay").css("height", $(document).height());
        $(".loading").center();
        $(".loading").show();
        $(".overlay").show();
        
        $("body").on("change", "#checkAll", function() {
            var checkSelectAll = $('.popover .inline .showHideTitle input[type="checkbox"]').is(":checked");
            if (checkSelectAll === true) {
                $('.popover-content .innerShowHideTitle input[type="checkbox"]').prop('checked', true);
                $scope.selectAll = true;
            } else {
                $scope.selectAll = false;
                $('.popover-content .innerShowHideTitle input[type="checkbox"]').prop('checked', false);
                $('.popover-content .innerShowHideTitle input[type="checkbox"]').each(function(i) {
                    if (i < 16) {
                        $(this).prop('checked', true);
                    }
                });
            }
            $scope.$apply();
            resizeAll();
        });

        $scope.columnTitleList = [];

        $http.get("connect/fms/getChooseColumns").then(function(response) {

            $scope.serviceReqColumns = response.data.ServiceReqColumns;
            for (var i = 0; i < $scope.serviceReqColumns.length; i++) {
                if ($scope.serviceReqColumns[i].active === "Y") {
                    var item = {};
                    item["index"] = $scope.serviceReqColumns[i].displayOrder - 1;
                    item["title"] = $scope.serviceReqColumns[i].displayName;
                    item["name"] = $scope.serviceReqColumns[i].columnName;
                    if ($scope.serviceReqColumns[i].checked === 1)
                        item["checked"] = "YES";
                    else
                        item["checked"] = "NO";
                    $scope.columnTitleList.push(item);
                }
            }
        });

        $('#popover3').popover({
            html: true,
            placement: 'bottom',
            content: function() {
                if ($scope.selectAll) {
                    $('.popover .inline .showHideTitle input[type="checkbox"]').prop('checked', true);
                } else {
                    $('.popover .inline .showHideTitle input[type="checkbox"]').prop('checked', false);
                }
                return $('#popover3-content-wrapper').html();
            }
        }).on('click', function(e) {
            e.preventDefault();
        });

        $('body').on('click', '#colHideShowCancel', function() {
            $('.popover').css('display', 'none');
        });

        $('body').on('click', '#colHideShowApply', function() {
            $('.popover').css('display', 'none');
            $rootScope.safeApply(function() {
                for (var colIndex = 0; colIndex < $scope.columnTitleList.length; colIndex++) {

                    if (!($("#" + $scope.columnTitleList[colIndex].name).is(":checked"))) {
                        $scope.columnTitleList[colIndex].checked = "NO";
                        $('table[data-table-name="ServiceReq-Data"]').dataTable().fnSetColumnVis($scope.columnTitleList[colIndex].index, false);
                    } else {
                        $scope.columnTitleList[colIndex].checked = "YES";
                        $('table[data-table-name="ServiceReq-Data"]').dataTable().fnSetColumnVis($scope.columnTitleList[colIndex].index, true);
                    }
                }
            });

        });
        
        var ServiceReqTable;
        $scope.updateData = {};

        function dataLoad(input) {
            $(".loading").center();
            $(".loading").show();
            $(".overlay").show();
            $http.post("connect/fms/getServiceReqData", JSON.stringify({
                "data": input
            })).then(function(response) {
                $scope.updateData = response.data;

                updateServiceReqData();
            }).then(function() {
                resizeAll();
            });
        }
        
        dataLoad('DEFAULT');
        $("body").off("change", "#AllData");
        $("body").on("change", "#AllData", function() {
            var flag = $(this).is(":checked");
            if (flag) {

                dataLoad('ALL');
            } else {
                dataLoad('DEFAULT');
            }
        });

        $('table[data-table-name="ServiceReq-Data"] tfoot td').each(function() {
            var title = $(this).text();
            if (title !== '') {
                $(this).html('<input type="text" placeholder="Search ' + title + '" size="4" />');
            }
        });
        
        var $window     = $(window);
        var windowsize  = $window.width();
        var dtOptions;
        if (windowsize > 767) {
            dtOptions = {
        		rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: false,
                "bPaginate": true,
                "bSort": true,
                "bFilter": true,
                "aLengthMenu": [
                    [10, 20, 50, 100, -1],
                    [10, 20, 50, 100, "All"]
                ],
                "iDisplayLength": 10,
                "bAutoWidth": false          
            };
        } else {
            dtOptions = {
        		rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: true,
                "bPaginate": true,
                "bSort": true,
                "bFilter": true,
                "aLengthMenu": [
                    [10, 20, 50, 100, -1],
                    [10, 20, 50, 100, "All"]
                ],
                "iDisplayLength": 10,
                "bAutoWidth": false          
            };
        }

        ServiceReqTable = $('table[data-table-name="ServiceReq-Data"]').DataTable(dtOptions);

        // Apply the search
        ServiceReqTable.columns().every(function() {
            var that = this;

            $('input', this.footer()).on('keyup change', function() {
                if (that.search() !== this.value) {
                    that
                        .search(this.value)
                        .draw();
                }
            });
        });

        function updateServiceReqData() {
            if ($scope.flag === true) {
                $(".loading").hide();
                $(".overlay").hide();
            } else {
                $(".overlay").css("height", $(document).height());
                $(".overlay").show();
            }
            $('table[data-table-name="ServiceReq-Data"]').dataTable().fnClearTable();
            angular.forEach($scope.updateData, function(data) {
                $('table[data-table-name="ServiceReq-Data"]').dataTable().fnAddData([
						data.caseNo,
						data.currentTypeofIssue,
						data.assignedGroup,
						data.state,
						data.opened,
						data.projectPhase,
						data.status,
						data.jobType,
						data.customerName,
						data.machineTechOg,
						data.sEventYear,
						data.sEventQuarter,
						data.originalTypeofIssue,
						data.issueEventDate,
						data.custAddReq,
						data.suggByRedFlgReview,
						data.rcaReqByCust,
						data.ehsImpact,
						data.category,
						data.curStaLastinActDate,
						data.entryInCurStatus,
						data.asRunningLastInDate,
						data.asRunningLastOutDate,
						data.techSoluType,
						data.swTeamNeeded,
						data.jobTypeDetails,
						data.business,
						data.expectedResolDate,
						data.machineType,
						data.machineTechnology,
						data.controlPanelType,
						data.cod,
						data.costingProjectCharged,
						data.projectManager,
						data.instaManagerCoordinator,
						data.problemDesc,
						data.cin,
						data.assignedFun,
						data.actVsSupMateSol,
						data.supplierNameMateSol,
						data.solDesc,
						data.asRunningNeeded,
						data.mateNeeded,
						data.supplierResp,
						data.wfcaTimeInvalid,
						data.wfcaTimeInSol,
						data.wfcaTimeInFulfSp,
						data.wfcaTimeInImple,
						data.wfcaTimeInAsBuilt,
						data.wfcaTimeInExpertAss,
                ], false);
            });
            $('table[data-table-name="ServiceReq-Data"]').dataTable().fnDraw(true);
            $('#colHideShowApply').click();
        }

        $(".exportServiceReqDataToExcel").click(function() {
            var data;
            var flag = $("#AllData").is(":checked");
            if (flag) {
                data = 'ALL';
            } else {
                data = 'DEFAULT';
            }
            download('/connect/fms/exportServiceReqData', data, 'ServiceReqData Dtl');
        });

        function download(url, data, defaultFileName) {
            var deferred = $q.defer();
            $http.post(url, data, {
                responseType: "arraybuffer"
            }).success(
                function(data, status, headers) {
                    var type = headers('Content-Type');
                    var disposition = headers('Content-Disposition');
                    if (disposition) {
                        var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                        if (match[1])
                            defaultFileName = match[1];
                    }
                    defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                    var blob = new Blob([data], {
                        type: type
                    });
                    saveAs(blob, defaultFileName);
                    deferred.resolve(defaultFileName);
                }).error(function() {
                var e;
                deferred.reject(e);
            });
            return deferred.promise;
        }
    }]);
});