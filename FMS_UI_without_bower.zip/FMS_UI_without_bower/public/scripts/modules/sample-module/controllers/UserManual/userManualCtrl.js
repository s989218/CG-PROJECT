define(['angular','../../sample-module'], function (angular,controllers,jquery,datatablesNet) 
		{
	'use strict';
	controllers.controller('userManualCtrl', ['$scope','$http','$q','$timeout', '$location','$state','$rootScope','AdminDataNetworkService', function ($scope, $http,$q,$timeout, $location, $state,$rootScope, AdminDataNetworkService) {


		$scope.userMLoader = true;
		var ssoData ={};
		var dataTable;
		$scope.loadUserManualData = function () {
			if ($.fn.DataTable.isDataTable( '#userM' ) ) {
				$("#userM").dataTable().api().clear().draw();
				$("#userM").dataTable().api().destroy();
				$('#userM').empty(); 
			}
			ssoData["userSSO"] = $rootScope.userSSO;
			AdminDataNetworkService.getAllDocuments(ssoData).then(function(response) {
				$scope.objRolesData = response;
				dataTable = $('#userM').DataTable({
                    rowReorder: {
                        selector: 'td:nth-child(2)'
                    },
                    responsive: true,
					"searching": false,
				    data: $scope.objRolesData,
					"columnDefs": [
					               {
					            	   "targets": [ 3],
					            	   "visible": false,
					            	   "searchable": false
					               },
					               { className: "dt-center", "targets": [2,4] },
					               { className: "dt-left", "targets": [0,1] }
					               ],
					               "columns": [
					                           { data:"filename",title:"Flie Name" },
					                           { data:"description",title:"Description" },
					                           { data:"uploaded_by",title:"Uploaded By" },
					                           { data:"id",title:"File Id" },
					                           {
					                        	   title:"Actions",
					                        	   "bSortable": false,
					                        	   "bSearchable": false,
					                        	   mRender: function (data, type, row) {
					                        		   return '<a class="table-download" title="Download"><i class="fa fa-download fa-2x" aria-hidden="true"></i></a>'
					                        	   }
					                           }
					                           ]
				});
			});

			$scope.userMLoader = false;
		}
		$scope.loadUserManualData();

		$('body #userM tbody').on( 'click', 'a.table-download', function () { 
			var current_row = $(this).parents('tr');
            if (current_row.hasClass('child')) {
                current_row = current_row.prev();
            }
            var data = dataTable.row(current_row).data();
			var urldata;
            $scope.dataObject              = {};
            $scope.dataObject.id     	   = data.id;
            urldata="connect/fms/downloadDocuments";
            
            download(urldata,$scope.dataObject,'FMS UserManual');
		});
		
		function download(url,data,defaultFileName) {
            var deferred = $q.defer();
            $http.post(url,data, { responseType: "arraybuffer" }).success(
                function (data, status, headers) {
                    var type = headers('Content-Type');
                    var disposition = headers('Content-Disposition');
                    if (disposition) {
                        var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                        if (match[1])
                            defaultFileName = match[1];
                    }
                    defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                    var blob = new Blob([data], { type: type });
                    saveAs(blob, defaultFileName);
                    deferred.resolve(defaultFileName);  
                    $scope.adminLoader = false;
                }).error(function () {
                    var e ;
                    deferred.reject(e);
                });
            return deferred.promise;
        } 

		$scope.showUserMFiltersToggle = function (filterKey, showFilter) {
			if ($('.kd'+filterKey+'Filter').is(':visible')) {
				$('.kd'+filterKey+'Filter').slideUp(200);
				$scope[showFilter] = false;
			} else {
				$scope[showFilter] = true;
				$('.kd'+filterKey+'Filter').slideDown(200);
			}   
		}

	}]);
		});