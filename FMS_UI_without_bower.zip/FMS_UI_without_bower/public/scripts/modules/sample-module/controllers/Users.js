
define(['angular','../sample-module','jquery','datatablesNet'], function (angular,controllers,jquery,datatablesNet) 
 {
    'use strict';
    controllers.controller('UsersCtrl', ['$scope','$http','$q','$timeout', '$location','$state','$rootScope','AdminDataNetworkService', function ($scope, $http,$q,$timeout, $location, $state,$rootScope,AdminDataNetworkService) {
        
        $scope.adminLoader = true;
        $scope.userData    = {};
        
        var modalList   = document.getElementById('addUserDataModal');
        var span        = document.getElementsByClassName("addUserClose")[0];
        
        var modalAlert  = document.getElementById('deleteUserAlertModal');
        var spanAlert   = document.getElementsByClassName("deleteUserClose")[0];
        

        span.onclick = function(event) {
            if($scope.successMsg === true) {
                $scope.adminLoader = true;
                $scope.loadUsersData();  
                $scope.successMsg = false;
            }
            
            if($scope.fnAddUser === true) {
                $scope.resetUserData();    
            }
            
            modalList.style.display = "none";
        }
        
        spanAlert.onclick = function(event) {
            $timeout(function () {
                $scope.successMsg  = false;
                modalAlert.style.display = "none";
            }, 100);
        }
        
        window.onclick = function(event) {
            if (event.target === modalList) {
                if($scope.successMsg === true) {
                    $scope.adminLoader = true;
                    $scope.loadUsersData();  
                    $scope.successMsg = false;
                }
                
                if($scope.fnAddUser === true) {
                    $scope.resetUserData();    
                }
                
                modalList.style.display = "none";
            }
            
            if (event.target === modalAlert) {
                $timeout(function () {
                    $scope.successMsg  = false;
                    modalAlert.style.display = "none";
                }, 100);
            }
        }
        
        function validateEmail(email) {
            var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }
        
        var dataTable;
        $scope.loadUsersData = function (){
            if ($.fn.DataTable.isDataTable( '#users' ) ) {
                   $("#users").dataTable().api().clear().draw();
                   $("#users").dataTable().api().destroy();
                   $('#users').empty(); 
            }
            
            AdminDataNetworkService.getAllUsersData().then(function(response) {
                $scope.objUsersData = response.UserDetails;
                
                $scope.objUsersRoleData  = response.RoleDetails;
                $scope.objUserStatusData = [{ "value": 'Y', "text": "Active" }, { "value": 'N', "text": "In-Active" }];
                
                $scope.userData.role     = 9;
                $scope.userData.active   = 'Y';

                dataTable = $('#users').DataTable({
                        rowReorder: {
                            selector: 'td:nth-child(2)'
                        },
                        responsive: true,
                        data: $scope.objUsersData,
                        "columns": [
                            { data:"first_name",title:"First Name" },
                            { data:"last_name",title:"Last Name" },
                            { data:"user_id",title:"SSO" },
                            { data:"email_id",title:"Email" },
                            { data:"role_name",title:"Role" },
                            { 
                                data:"active",
                                title:"Status",
                                "mData": null,
                                "render": function (data, type, full, meta) {
                                    if (data) {
                                        if (data.active === "Y") {
                                           return "Active";
                                        } else {
                                           return "Inactive";
                                        }
                                    } else {
                                        return data;
                                    }
                                 }
                            },
                            {
                                title:"Actions",
                                "bSortable": false,
                                "bSearchable": false,
                                mRender: function (data, type, row) {
                                    return '<a class="table-edit" title="Edit" data-id="' + row.user_id + '"><i class="fa fa-pencil-square-o fa-2x" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class="table-delete" title="Delete" data-id="' + row.user_id + '"><i class="fa fa-trash-o fa-2x" aria-hidden="true"></i></a>'
                                }
                            }
                        ]
                });
                
                $('body #users tbody').on( 'click', 'a.table-delete', function () { 
                    var current_row = $(this).parents('tr');
                    if (current_row.hasClass('child')) {
                        current_row = current_row.prev();
                    }
                    var data = dataTable.row(current_row).data();
                    
                    $scope.deleteUserSSO = data.user_id;
                    
                    modalAlert.style.display = "block";
                    
                    $("#oDeleteUser").prop("disabled", false);
                    $("#oDeleteUser").css("background", "#22A2E3");
                });
                
                $('body #users tbody').on( 'click', 'a.table-edit', function () { 
                    var current_row = $(this).parents('tr');
                    if (current_row.hasClass('child')) {
                        current_row = current_row.prev();
                    }
                    var data = dataTable.row(current_row).data();
                    
                    $scope.fnAddUser                = false;
                    $scope.fnEditUser               = true;
                    
                    $scope.dataObject               = {};
                    $scope.dataObject.user_id       = data.user_id;
                    $scope.dataObject.email_id      = data.email_id;
                    $scope.dataObject.first_name    = data.first_name;
                    $scope.dataObject.last_name     = data.last_name;
                    $scope.dataObject.role_id       = data.role_id;
                    $scope.dataObject.role_name     = data.role_name; 
                    $scope.dataObject.role_name_desc= data.role_name_desc;
                    $scope.dataObject.default_role  = data.default_role;                  
                    $scope.dataObject.active        = data.active;
                    $scope.dataObject.created_by    = data.created_by;
                    $scope.dataObject.created_date  = data.created_date;
                    $scope.dataObject.updated_by    = data.updated_by;
                    $scope.dataObject.updated_date  = data.updated_date;
                    
                    $scope.userData.role            = data.role_id;
                    $scope.userData.active          = data.active;
                    
                    $timeout(function () {
                        modalList.style.display = "block";
                        
                        $("#oUpdateUser").prop("disabled", false);
                        $("#oUpdateUser").css("background", "#22A2E3");
                    }, 100);
                });
                
                $scope.adminLoader = false;  
            });
        }
        
        $scope.loadUsersData();
        
        $scope.addUser = function () {
            $scope.successMsg       = false;
            $scope.fnAddUser        = true;
            $scope.fnEditUser       = false;
            
            modalList.style.display = "block";
            $scope.resetUserData();
        }
        
        $scope.closeAlertBox = function () {
            $scope.successMsg  = false;
            modalAlert.style.display = "none";
        }
        
        $scope.deleteUserData = function() {
            $scope.successMsg = false;
            $scope.failureMsg = false;
            
            if ($scope.deleteUserSSO === "") {
                $scope.successMsg = false;
                $scope.failureMsg = true;
                $scope.failureMessage   = "Something went wrong! Please try again later."
            } else {
                $scope.userData            = {};
                $scope.userData['action']  = "deleteUser";
                $scope.userData['sso']     = '^'+$scope.deleteUserSSO+'$';
                
                AdminDataNetworkService.manageUsersData(JSON.stringify($scope.userData)).then(function(response) {
                    $rootScope.safeApply(function() {
                        if (response === "SUCCESS") {
                            $scope.successMsg     = true;
                            $scope.failureMsg     = false;
                            $scope.successMessage = "User Deleted Successfully.";
                            
                            $scope.loadUsersData();
                        } else if (response==="FAILURE") {
                            $scope.successMsg     = false;
                            $scope.failureMsg     = true;
                            $scope.failureMessage = "Something went wrong! Please try again later.";
                        } else {
                            $scope.successMsg = false;
                            $scope.failureMsg = true;
                            $scope.failureMessage   = response;
                        }
                        
                        $("#oDeleteUser").prop("disabled", true);
                        $("#oDeleteUser").css("background", "#C0C0C0");
                        
                        $scope.deleteUserSSO = "";
                    });
                });    
            }
        }
        
        $scope.saveUserData = function(status) {
            $scope.successMsg = false;
            $scope.failureMsg = false;
            
            if($('#aUserSSO').val().trim() === "") {
                $scope.userData['sso'] = null;
            } else {
                $scope.userData['sso'] = $('#aUserSSO').val().trim();
            }
        
            if($('#aUserEmail').val().trim() === "") {
                $scope.userData['email'] = null;
            } else {
                $scope.userData['email'] = $('#aUserEmail').val().trim();
            }
            
            if($('#aUserFirstName').val().trim() === "") {
                $scope.userData['firstName'] = null;
            } else {
                $scope.userData['firstName'] = $('#aUserFirstName').val().trim();
            }
            
            if($('#aUserLastName').val().trim() === "") {
                $scope.userData['lastName'] = null;
            } else {
                $scope.userData['lastName'] = $('#aUserLastName').val().trim();
            }
            
            $timeout(function () {
                $scope.failureMsg = false; 
            },5000);
            
            var ssoReg   = /^[0-9]{9}$/;
            var nameReg = /^[a-zA-Z][a-zA-Z0-9\'\s]/;
            
            if ($scope.userData['sso'] === null || !ssoReg.test($scope.userData['sso'])) {
                $scope.successMsg  = false;
                $scope.failureMsg  = true;
                $scope.failureMessage = "Please enter valid user SSO"
            } else if ($scope.userData['email'] === null || !validateEmail($scope.userData['email'])) {
                $scope.successMsg  = false;
                $scope.failureMsg  = true;
                $scope.failureMessage = "Please enter valid user email address"
            } else if ($scope.userData['firstName']  === null || !nameReg.test($scope.userData['firstName'])) {
                $scope.successMsg  = false;
                $scope.failureMsg  = true;
                $scope.failureMessage = "Please enter valid user first name"
            } else if ($scope.userData['lastName']  === null || !nameReg.test($scope.userData['lastName'])) {
                $scope.successMsg  = false;
                $scope.failureMsg  = true;
                $scope.failureMessage = "Please enter valid user last name"
            } else {
                $scope.userData['action']    = status;
                $scope.userData['active']    = $scope.userData.active;
                $scope.userData['role']      = $scope.userData.role;

                if(status === "addUser") {
                    $scope.userData['createdBy'] = $rootScope.userSSO;
                } else {
                    $scope.userData['createdBy'] = null;
                }
                
                $scope.userData['updatedBy'] = $rootScope.userSSO;
                
                AdminDataNetworkService.manageUsersData(JSON.stringify($scope.userData)).then(function(response) {
                    $rootScope.safeApply(function() {
                        if (response === "SUCCESS") {
                            $scope.successMsg = true;
                            $scope.failureMsg = false;
                            
                            if(status === "addUser") {
                                $scope.successMessage = "Added Successfully."
                            } else {
                                $scope.successMessage = "Updated Successfully."
                            }
                            $scope.loadUsersData();
                        } else if (response==="FAILURE") {
                            $scope.successMsg  = false;
                            $scope.failureMsg  = true;
                            $scope.failureMessage = "Something went wrong! Please try again later."
                        } else {
                            $scope.successMsg  = false;
                            $scope.failureMsg  = true;
                            $scope.failureMessage = response
                        }
                        
                        if(status === "addUser") {
                            $scope.resetUserData();
                        } else {
                            $("#oUpdateUser").prop("disabled", true);
                            $("#oUpdateUser").css("background", "#C0C0C0");
                        }
                        
                    });
                });
            }
        };
        
        $scope.exportUsers = function () {
            $scope.adminLoader = true;
            
            var urldata;
            urldata="connect/fms/exportUserManagementData/userData";
            
            download(urldata,{},'FMS Users');    
        }
        
        function download(url,data,defaultFileName) {
            var deferred = $q.defer();
            $http.post(url,data, { responseType: "arraybuffer" }).success(
                function (data, status, headers) {
                    var type = headers('Content-Type');
                    var disposition = headers('Content-Disposition');
                    if (disposition) {
                        var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                        if (match[1])
                            defaultFileName = match[1];
                    }
                    defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                    var blob = new Blob([data], { type: type });
                    saveAs(blob, defaultFileName);
                    deferred.resolve(defaultFileName);  
                    $scope.adminLoader = false;
                }).error(function () {
                    var e ;
                    deferred.reject(e);
                });
            return deferred.promise;
        } 
        
        $scope.resetUserData = function() {
            $('#aUserSSO').val('');
            $('#aUserEmail').val('');
            $('#aUserFirstName').val('');
            $('#aUserLastName').val('');
            
            $scope.userData.role     = 9;
            $scope.userData.active   = 'Y';
            
            $("input").removeAttr("invalid");
            $("div").removeClass("label-is-floating is-invalid");
        };
        
        $scope.showUsersFiltersToggle = function (filterKey, showFilter) {
            if ($('.kd'+filterKey+'Filter').is(':visible')) {
                $('.kd'+filterKey+'Filter').slideUp(200);
                $scope[showFilter] = false;
            } else {
                $scope[showFilter] = true;
                $('.kd'+filterKey+'Filter').slideDown(200);
            }   
        }
    }]);
});