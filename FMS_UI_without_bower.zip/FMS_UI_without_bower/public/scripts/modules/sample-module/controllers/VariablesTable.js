
define(['angular','../sample-module'], function (angular,controllers,jquery,datatablesNet) 
 {
    'use strict';
    controllers.controller('VariablesTableCtrl', ['$scope','$http','$q','$timeout', '$location','$state','$rootScope','IPMService','fileUpload', function ($scope, $http,$q,$timeout, $location, $state,$rootScope,IPMService,fileUpload) {
        $scope.adminLoader = true;
    		
        $scope.loadVariablesTableData = function (){
            if ($.fn.DataTable.isDataTable( '#variablesTable' ) ) {
                   $("#variablesTable").dataTable().api().clear().draw();
                   $("#variablesTable").dataTable().api().destroy();
                   $('#variablesTable').empty(); 
            }
            
            $scope.customizedData = [
                {   
                    "TAG"         : "(SH)",
                    "Description" : "INVOICE DATE - ACTUAL SH DATE",
                    "Value"       : "3"
                },
                {   
                    "TAG"         : "(INV)",
                    "Description" : "ACTUAL SH DATE - BOX CLOSURE DATE",
                    "Value"       : "5"
                },
                {   
                    "TAG"         : "(PAT)",
                    "Description" : "BOX CLOSURE DATE - MOVE ORDER DATE",
                    "Value"       : "3"
                },
                {   
                    "TAG"         : "(PIT)",
                    "Description" : "MOVE ORDER DATE - MO REQUEST",
                    "Value"       : "1"
                },
                {   
                    "TAG"         : "(VAR)",
                    "Description" : "VALUE TO SET FD OUT OF QUARTER",
                    "Value"       : "107"
                },
                {   
                    "TAG"         : "(TT)",
                    "Description" : "INVOICE STATUS CHANG DATE - ACTUAL SH DA",
                    "Value"       : ""
                },
                {   
                    "TAG"         : "(FDTRIM_IN)",
                    "Description" : "VALUE TO SET RISK",
                    "Value"       : "15"
                },
                {   
                    "TAG"         : "(FDTRIM_OUT)",
                    "Description" : "VALUE TO SET OPTY",
                    "Value"       : "15"
                }
            ]
            dataTableVariablesTable();
        }
                    
        $scope.loadVariablesTableData();
  
        function dataTableVariablesTable() {
            $('#variablesTable').DataTable({
                    data: $scope.customizedData,
                    "sPaginationType": "full_numbers",
                    "bFilter":true, 
                    "retrieve": true, 
                    "scrollX": false,
                    "paging": true,
                    responsive: true,
                    "columns": [
                        { data:"TAG",title:"TAG" },
                        { data:"Description",title:"Description" },
                        { data:"Value", title:"Value" },
                        {
                            title:"Actions",
                            "bSortable": false,
                            "bSearchable": false,
                            mRender: function (data, type, row) {
                                return '<a class="table-edit" data-id="' + row[0] + '"><i class="fa fa-pencil-square-o fa-2x" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class="table-delete" data-id="' + row[0] + '"><i class="fa fa-trash-o fa-2x" aria-hidden="true"></i></a>'
                            }
                        }
                    ]
            });
            $scope.adminLoader = false;  
        }
        
        $scope.showVariablesTableFiltersToggle = function (filterKey, showFilter) {
            if ($('.kd'+filterKey+'Filter').is(':visible')) {
                $('.kd'+filterKey+'Filter').slideUp(200);
                $scope[showFilter] = false;
            } else {
                $scope[showFilter] = true;
                $('.kd'+filterKey+'Filter').slideDown(200);
            }   
        }
    }]);
});