define(['angular', '../sample-module', 'openlayer', 'multiselectdrpdwn', 'jqueryMultiSelect', 'jquery', 'datatablesNetMin', 'datatablesNet', 'datatablesNetRowReorder','datatablesNetResponsive','jqueryImageZoom', 'chosen', 'slimscroll'], function(angular, controllers, ol, multiselectdrpdwn, jqueryMultiSelect, jquery, datatablesNetMin, datatablesNet, datatablesNetRowReorder, datatablesNetResponsive) {
    'use strict';
    controllers.controller('installCtrl', ['InstalledbaseService', '$scope', '$rootScope', '$http', '$timeout', 'IBOMetricsService', function(InstalledbaseService, $scope, $rootScope, $http, $timeout, IBOMetricsService) {
        var displayFeatureInfo;
        resizeAll();
        $scope.search = [];
        $scope.InstallBaseLoader = false;
        $scope.search.siteSName = "";
        $scope.search.siteCustName = "";
        $scope.search.regions = "";
        $scope.search.siteNameAlias = "";
        $scope.search.serialNo = "";
        $scope.search.technology = "";
        $scope.search.market = "";
        $scope.search.oemLoc = "";
        $scope.search.servRelationDescOng = "";

        var mainDivHeight = window.innerHeight - angular.element("header").outerHeight() - angular.element("footer").outerHeight();
        angular.element("#mapContainer").outerHeight(mainDivHeight);
        $("#popup").hide();
        $("#SiteInfoContent").hide();
        $scope.searchFlag = false;
        $rootScope.map = [];
        var map;
        $scope.InstallBaseLoader = true;
        
        $timeout(function() {
            if (!$rootScope.accountManager) {
                $rootScope.getInstalledBaseDropdownsData();
            }
        }, 5000);    
        
        $rootScope.getInstalledBaseDropdownsData = function() {
            var item = {};
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            
            InstalledbaseService.getInstldBaseDropdownsData(JSON.stringify(item)).then(function(res) {
                $scope.regionDropdownBean = res.regionDropdownBean;
                $scope.siteDropdownBean = res.siteDropdownBean;
                $scope.technologyDropdownBean = res.technologyDropdownBean;
                $scope.marketDDBean = res.marketDDBean;
                $scope.installBaseSiteCustAliasDDBean = res.installBaseSiteCustAliasDDBean;
                $scope.installBaseOEMLocDDBean = res.installBaseOEMLocDDBean;
                $scope.installBaseSiteCustNameDDBean = res.installBaseSiteCustNameDDBean;
                $scope.installBaseServRelationDDBean = res.installBaseServRelationDDBean;
                $scope.countryDropdownBean = res.countryDropdownBean;
                $scope.accountManagerDropdownBean = res.accountManagerDropdownBean;
                $scope.geDunsNameDropdownBean = res.geDunsNameDropdownBean;

            }).then(function() {
                $timeout(function() {
                    $("select.multiSelect").multipleSelect({
                        filter: true
                    });
                }, 200);
                resizeAll();
                $scope.InstallBaseLoader = false;
            });
        }
        
        $timeout(function() {
            if (typeof(Storage) !== "undefined") {
                
                if (localStorage.getItem("siteFilterCode") !== null && localStorage.getItem("regionFilterCode") !== null && localStorage.getItem("countryFilterCode") !== null) {

                    $('#filterSearch').removeClass('panel-collapse collapse').addClass('panel-collapse collapse in');

                    $scope.siteFilterCode        = localStorage.getItem("siteFilterCode");
                    $scope.regionFilterCode      = localStorage.getItem("regionFilterCode");
                    $scope.countryFilterCode     = localStorage.getItem("countryFilterCode");

                    $scope.search.siteCustName   = localStorage.getItem("siteFilterCode");
                    $scope.search.regions        = localStorage.getItem("regionFilterCode");
                    $scope.search.country        = localStorage.getItem("countryFilterCode");

                    $("#regionSearch").multipleSelect();
                    $("#regionSearch").multipleSelect('setSelects', [$scope.regionFilterCode]);

                    $("#countryDropdownBean").multipleSelect();
                    $("#countryDropdownBean").multipleSelect('setSelects', [$scope.countryFilterCode]);

                    $("#siteCustNameSearch").multipleSelect();
                    $("#siteCustNameSearch").multipleSelect('setSelects', [$scope.siteFilterCode]);
                    
                    localStorage.removeItem('siteFilterCode');
                    localStorage.removeItem('regionFilterCode');
                    localStorage.removeItem('countryFilterCode');

                    delete $scope.siteFilterCode;
                    delete $scope.regionFilterCode;
                    delete $scope.countryFilterCode;
                    
                    $rootScope.ibSearchData();
                }
            } else {
                // Sorry! No Web Storage support..
            }
        }, 15000);
        
        var item = {};
        item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
        item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";

        InstalledbaseService.getLatLongByRegion(JSON.stringify(item)).then(function(res) {
            $scope.LatLongByRegion = res;
            UpdateLatLongByRegion();
            
            if ($rootScope.accountManager && localStorage.getItem("siteFilterCode") === null && localStorage.getItem("regionFilterCode") === null && localStorage.getItem("countryFilterCode") === null) {
                $rootScope.ibSearchData();
            }
        });
        
        var iconFeatures = [],
            originalRegiondata = [],
            originalSearchRegiondata = [],
            vectorLayer, iconStyle, sitevectorSource, vectorSource, view;

        function UpdateLatLongByRegion() {
            iconFeatures = [];
            for (var i = 0; i < $scope.LatLongByRegion.length; i++) {
                var item = $scope.LatLongByRegion[i];
                var longitude = item.longitude;
                var latitude = item.latitude;
                var region = item.ibDataRegion;
                if ((longitude && latitude) && (Math.abs(longitude) <= 180 && Math.abs(latitude) <= 90)) {
                    var iconFeature = new ol.Feature({
                        geometry: new ol.geom.Point(ol.proj.transform([parseFloat(longitude), parseFloat(latitude)], 'EPSG:4326',
                            'EPSG:3857')),
                        name: region,
                        nameM: 'R'
                    });
                    iconStyle = new ol.style.Style({
                        image: new ol.style.Icon(({
                            anchor: [0.5, 46],
                            anchorXUnits: 'fraction',
                            anchorYUnits: 'pixels',
                            opacity: 0.75,
                            src: 'images/icon_R.png',
                        })),
                        text: new ol.style.Text({
                            text: region,
                            fill: new ol.style.Fill({
                                color: 'black'
                            }),
                            offsetY: 5
                        })
                    });

                    iconFeature.setStyle(iconStyle);
                    iconFeatures.push(iconFeature);
                    originalRegiondata.push(iconFeature);
                }
            }
            
            var raster = new ol.layer.Tile({
                source: new ol.source.OSM()
            });
            
            if (sitevectorSource !== undefined) {
                sitevectorSource.clear();
            }

            if (vectorSource !== undefined) {
                vectorSource.clear();
            }

            vectorSource = new ol.source.Vector({
                features: iconFeatures //add an array of features
            });
            vectorLayer = new ol.layer.Vector({
                source: vectorSource,
                style: iconStyle
            });
            
            
            if($rootScope.isMobile === false) {
                if(screen.width === 1024 && screen.height === 768) {
                    view = new ol.View({
                        center: [0, 0],
                        zoom: 1.5,
                        minZoom: 1.5
                    });
                } if(screen.width === 1024 && screen.height > 768) {
                    view = new ol.View({
                        center: [0, 0],
                        zoom: 2.3,
                        minZoom: 2.3
                    });
                } else {
                    view = new ol.View({
                        center: [0, 0],
                        zoom: 2,
                        minZoom: 2
                    }); 
                }
            } else {
                if (screen.width === 768 && screen.height === 1024) {
                    view = new ol.View({
                        center: [0, 0],
                        zoom: 2,
                        minZoom: 2
                    });
                } else {
                    view = new ol.View({
                        center: [0, 0],
                        zoom: 1,
                        minZoom: 1
                    });
                }
            }
            
            if(!map) {
                map = new ol.Map({
                    layers: [raster, vectorLayer],
                    target: 'mapContainer',
                    controls: ol.control.defaults({
                        attributionOptions: ({
                            collapsible: true
                        })
                    }),
                    view: view
                });    
            } else {
                map.addLayer(vectorLayer);
            }
            
            map.on("singleclick", onPointerClickOne);
            map.un("singleclick", onPointerClickTwo);
            map.un("singleclick", onPointerClickThree);
            map.un("singleclick", onPointerClickFour);
        } //end of fun

        function onPointerClickOne(e1) {
            displayFeatureInfo(e1.pixel);
        }

        displayFeatureInfo = function(pixel) {
            var feature = map.forEachFeatureAtPixel(pixel, function(feature) {
                return feature;
            });
            if (feature) {
                var nameM = feature.get('nameM');
                if (nameM === 'R') {
                    $scope.region = feature.get('name');
                    $http.post("connect/fms/getLatLongBySite", JSON.stringify({
                        "region": $scope.region,
                        "siteName": null,
                        "businessSegment":$rootScope.businessSegment,
                        "accountManager":$rootScope.accountManager,
                        "marketIndustry":$rootScope.marketIndustry
                    })).success(function(response) {
                        $scope.LatLongBySite = response;
                        UpdateLatLongBySite();
                    }).then(function() {
                        resizeAll();
                    });
                }
            }
        };
        
        var displaySiteInfo;
        var iconFeaturesforSite = [];

        function UpdateLatLongBySite() {
            
            if (vectorSource) {
                vectorSource.clear();
            }
            iconFeaturesforSite = [];
            var elementno = $scope.LatLongBySite.length
            var avglat;
            var avglong;
            var totallat = 0.00;
            var totallong = 0.00;
            var srcImage;
            for (var i = 0; i < $scope.LatLongBySite.length; i++) {
                var item = $scope.LatLongBySite[i];
                var sitelongitude = item.longitude;
                var sitelatitude = item.latitude;
                var siteName = item.siteName;
                if ((sitelongitude && sitelatitude) && (Math.abs(sitelongitude) <= 180 && Math.abs(sitelatitude) <= 90)) {
                    var siteiconFeature = new ol.Feature({
                        geometry: new ol.geom.Point(ol.proj.transform([parseFloat(sitelongitude), parseFloat(sitelatitude)], 'EPSG:4326',
                            'EPSG:3857')),
                        siteName: siteName,
                        nameM: 'S'
                    });
                    
                    if (item.serviceRelationDesc === 'CONTRACTUAL') {
                        srcImage = 'images/icon_contractual.png';
                    } else if (item.serviceRelationDesc === 'TRANSACTIONAL') {
                        srcImage = 'images/icon_S.png';
                    }
                    var siteiconStyle = new ol.style.Style({
                        image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
                            anchor: [0.5, 46],
                            anchorXUnits: 'fraction',
                            anchorYUnits: 'pixels',
                            opacity: 0.75,
                            src: srcImage,
                        })),
                    });
                    siteiconFeature.setStyle(siteiconStyle);
                    iconFeaturesforSite.push(siteiconFeature);
                    totallat = totallat + parseFloat(item.latitude);
                    totallong = totallong + parseFloat(item.longitude);
                }
            }
            avglat = totallat / elementno;
            avglong = totallong / elementno;
            if (sitevectorSource !== undefined) {
                sitevectorSource.clear();
            }
            if (vectorSource !== undefined) {
                vectorSource.clear();
            }
            sitevectorSource = new ol.source.Vector({
                features: iconFeaturesforSite //add an array of features
            });
            var sitevectorLayer = new ol.layer.Vector({
                source: sitevectorSource,
                style: siteiconStyle
            });
            
            map.getView().setZoom(4);
            map.getView().setCenter(ol.proj.transform([avglong, avglat], 'EPSG:4326', 'EPSG:3857'));
            map.addLayer(sitevectorLayer);
            
            map.on("singleclick", onPointerClickTwo);
            map.un("singleclick", onPointerClickThree);
            map.un("singleclick", onPointerClickFour);

            map.on('moveend', onPointerMoveTwo);
        } //end of fun

        function onPointerClickTwo(e2) {
            displaySiteInfo(e2.pixel);
        }

        function onPointerMoveTwo(e2) {
            checknewzoom();
        }

        displaySiteInfo = function(pixel) {
            var feature = map.forEachFeatureAtPixel(pixel, function(feature) {
                return feature;
            });
            if (feature) {
                var nameM = feature.get('nameM');
                if (nameM === 'S') {
                    $scope.siteName = '\'' + feature.get('siteName') + '\'';
                    $scope.siteNameTitle = ($scope.siteName).replace(/['"]+/g, ''); 
                    
                    $http.post("connect/fms/getSiteInfoAndInstalledUnits", JSON.stringify({
                        "region": $scope.region,
                        "siteName": $scope.siteName,
                        "businessSegment":$rootScope.businessSegment,
                        "accountManager":$rootScope.accountManager,
                        "marketIndustry":$rootScope.marketIndustry
                    })).success(function(response) {
                        $scope.siteandUnitDetails = response;
                        $scope.siteandinstallUnitInfo();
                    }).then(function() {
                        resizeAll();
                    });
                    map.forEachFeatureAtPixel(pixel, function() {
                        $('#popup').show();
                    });
                }
            }
        };

        $scope.siteandinstallUnitInfo = function() {
            for (var i = 0; i < $scope.siteandUnitDetails.length; i++) {
                var item = $scope.siteandUnitDetails[i];
                $scope.custName = item.custName;
                $scope.city = item.siteCustCity;
                $scope.country = item.siteCustCountry;
                $scope.siteregion = item.ibDataRegion;
                $scope.productCompany = item.prodExcPL;
                $scope.market = item.marketSegmentDesc;
            }

            if ($.fn.DataTable.isDataTable('#Install_Units_Table')) {
                $("#Install_Units_Table").dataTable().api().clear().draw();
                $("#Install_Units_Table").dataTable().api().destroy();
                $('#Install_Units_Table').empty();
            }
            
            var $window     = $(window);
            var windowsize  = $window.width();
            var responsive;
            if (windowsize > 767) {
                responsive = false;
            } else {
                responsive = true;
            }
            
            $('#Install_Units_Table').DataTable({
                rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: responsive,
                data: $scope.siteandUnitDetails,
                "columns": [{
                        title: "Sr No",
                        "bSortable": false,
                        "bSearchable": false,
                        mRender: function(data, type, row) {
                            return '<a class="UnitserialNo" data-id="' + row.serialNumber + '">' + row.serialNumber + '</a>'
                        }
                    },
                    {
                        data: "technologyDescOG",
                        title: "Technology"
                    },
                    {
                        data: "unitShipData",
                        title: "Shipped Date"
                    },
                    {
                        data: "estServiceHrsCount",
                        title: "Service Hours"
                    },
                    {
                        data: "serviceRelationDesc",
                        title: "Relationship"
                    },
                    {
                        title: "Total IBO",
                        mRender: function(data, type, row) {
                            return '$'+row.avTot;
                        }
                    },
                    {
                        data: "equipmentModel",
                        title: "Equipment Model"
                    },
                    {
                        data: "unitCustomerName",
                        title: "Unit Customer Name"
                    },
                    {
                        data: "eventDate",
                        title: "Event Date"
                    },
                    {
                        data: "eventType",
                        title: "Type"
                    },
                    {
                        data: "eventStatus",
                        title: "Status"
                    },
                    {
                        data: "equipmentCode",
                        title: "Equipment Code"
                    },
                    {
                        data: "equipmentEngDesc",
                        title: "Equipment Desc"
                    }
                ],
                "bPaginate": true,
                "bSort": true,
                "bFilter": true,
                "aLengthMenu": [
                    [5, 10, 25, 50, -1],
                    [5, 10, 25, 50, "All"]
                ],
                "iDisplayLength": 5
            });
            $(".dataTables_scrollBody").slimScroll();
        };
        
        $('body').off('click', '.UnitserialNo');
        $('body').on('click', '.UnitserialNo', function() {
            $("#popup").hide();
            $("#SiteInfoContent").show();
            $scope.srno     = $(this).attr("data-id");
            $scope.siteName = ($scope.siteName).replace(/['"]+/g, '');
            
            $http.post("connect/fms/getSerialInfoData", JSON.stringify({
                "region": $scope.region,
                "siteName": $scope.siteName,
                "serialNumber": $scope.srno,
                "businessSegment":$rootScope.businessSegment,
                "accountManager":$rootScope.accountManager,
                "marketIndustry":$rootScope.marketIndustry
            })).success(function(response) {
                $scope.serialDetails = response;
                $scope.getserialdetails();
            }).then(function() {
                resizeAll();
            });
        });
        
        $scope.getserialdetails = function() {
            for (var i = 0; i < $scope.serialDetails.length; i++) {
                var item = $scope.serialDetails[i];
                $scope.serino = item.serialNumber;
                $scope.technology = item.technologyDescOG;
                $scope.description = item.techDesc;
                $scope.maintenancePolicy = item.maintPolicyCOD;
                $scope.oemlocation = item.oemLocationDesc;
                $scope.rating = item.unitRating;
                $scope.speed = item.unitSpeedRPM;
                $scope.cntrlSystem = item.controlSystemDesc;
                $scope.driven = item.drivenEquipDesc;
                $scope.combustionSystem = item.combustionSystemDesc;
                $scope.fueltype = item.primaryFuelTypeDesc;
            }
            $(".zoomImg").remove();
            $(".imageSrc").attr("src", "/images/" + $scope.technology + ".jpg");

            $('#imageinfo').hover(
                function() {
                    $(".txtHover").html('');
                },
                function() {
                    $(".txtHover").html('Hover');
                }
            );
            $('#imageinfo').zoom({
                url: '/images/' + $scope.technology + '.jpg',
                callback: function() {}
            });
        }

        function checknewzoom() {
            var newZoomLevel = map.getView().getZoom();
            if (newZoomLevel <= 2) {
                if (sitevectorSource !== undefined) {
                    sitevectorSource.clear();
                }
                if (vectorSource !== undefined) {
                    vectorSource.clear();
                }
                if ($scope.searchFlag) {
                    vectorSource = new ol.source.Vector({
                        features: originalSearchRegiondata //add an array of features
                    });
                } else {
                    vectorSource = new ol.source.Vector({
                        features: originalRegiondata //add an array of features
                    });
                }
                vectorLayer = new ol.layer.Vector({
                    source: vectorSource,
                    style: iconStyle
                });
                map.addLayer(vectorLayer);

                map.on("singleclick", onPointerClickOne);
                map.on("singleclick", onPointerClickTwo);
                map.on("singleclick", onPointerClickThree);
                map.on("singleclick", onPointerClickFour);

                map.on('moveend', onPointerMoveTwo);
            }
        }
        
        $scope.ibClearData = function() {
            $scope.search = {};
            $(".chzn-select").val('');
            $(".chzn-select").trigger("chosen:updated");
            $scope.search.serialNo = "";
            $('.multiSelect').find('.ms-choice > span').html('');
            $('.multiSelect').find('input[type="checkbox"]').attr('checked', false);
            $('.multiSelect').find('input[type="radio"]').attr('checked', false);
            $('.multiSelect').find("select").val('');

            $(".searchResultPopup").hide();
            $scope.searchFlag = false;
            if (sitevectorSource !== undefined) {
                sitevectorSource.clear();
            }
            
            if (vectorSource !== undefined) {
                vectorSource.clear();
            }
            
            if ($rootScope.accountManager) {
                $rootScope.ibSearchData();
            } else {
                var item = {};
                item["accountManager"] = "";
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
                InstalledbaseService.getLatLongByRegion(JSON.stringify(item)).then(function(res) {
                    $scope.LatLongByRegion = res;
                    UpdateLatLongByRegion();
                });
            }
            
            map.getView().setZoom(2);
            map.getView().setCenter(ol.proj.transform([0, 0], 'EPSG:4326', 'EPSG:3857'));
            
            setTimeout(function() {
                $rootScope.safeApply(function() {
                    $scope.InstallBaseLoader = false;
                });
            }, 20);
        }

        $(".searchFilterPopupClose").click(function() {
            $(".searchResultPopup").hide();
        });

        $rootScope.ibSearchData = function() {
            $scope.InstallBaseLoader = true;
            var item = {};
            item["siteName"] = getSelectedValue($scope.search.siteSName);
            item["siteCustName"] = getSelectedValue($scope.search.siteCustName);
            item["region"] = getSelectedValue($scope.search.regions);
            item["siteCustAlias"] = getSelectedValue($scope.search.siteNameAlias);
            item["serialNum"] = ($scope.search === undefined) ? "" : $scope.search.serialNo;
            item["technology"] = getSelectedValue($scope.search.technology);
            item["market"] = getSelectedValue($scope.search.market);
            item["oemLoc"] = getSelectedValue($scope.search.oemLoc);
            item["servRelationDescOng"] = getSelectedValue($scope.search.servRelationDescOng);
            //item["accountManager"] = getSelectedValue($scope.search.account_manager);
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager: "";
            item["country"] = getSelectedValue($scope.search.country);
            item["geDuns"] = getSelectedValue($scope.search.ge_duns);
            item["businessSegment"] = $rootScope.businessSegment;
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            
            if(item["siteName"] === "" && item["siteCustName"] === "" && item["region"] === "" && item["siteCustAlias"] === "" && item["serialNum"] === "" && item["technology"] === "" && item["market"] === "" && item["oemLoc"] === "" && item["servRelationDescOng"] === "" && item["country"] === "" && item["geDuns"] === "" && (item["accountManager"] === null || item["accountManager"] === "")) {
                $scope.ibClearData();    
            } else {
                $http.post("connect/fms/getIBSearchResultsData", JSON.stringify(item)).success(function(response) {
                    $rootScope.safeApply(function() {
                        $scope.regionDataBean = response.regionDataBean;
                        $scope.siteNameDataBean = response.siteNameDataBean;
                        $scope.installBaseNoOfUnitsData = response.installBaseNoOfUnitsData;

                    });
                    $(".searchResultPopup").show();
                    $scope.searchFlag = true;
                    var dataDisp = "";
                    $(".dataDisplay").html('');
                    if ($scope.regionDataBean.length > 0) {
                        dataDisp = dataDisp + "<li>Region : " + $scope.regionDataBean.length + "</li>";
                    }
                    if ($scope.siteNameDataBean.length > 0) {
                        dataDisp = dataDisp + "<li>Sites : " + $scope.siteNameDataBean.length + "</li>";
                    }
                    if ($scope.installBaseNoOfUnitsData.length > 0) {
                        dataDisp = dataDisp + "<li># of units/Serial Numbers : " + $scope.installBaseNoOfUnitsData.length + "</li>";
                    }
                    if ($scope.regionDataBean.length === 0 && $scope.siteNameDataBean.length === 0) {
                        $(".dataDisplay").html("No Result Found");

                    } else {
                        $(".dataDisplay").html(dataDisp);
                    }
                    searchRegionLoad();
                }).then(function() {
                    resizeAll();
                    setTimeout(function() {
                        $rootScope.safeApply(function() {
                            $scope.InstallBaseLoader = false;
                        });
                    }, 20);
                });
            }
        }

        function searchRegionLoad() {
            var iconFeaturesforSearchR = [];
            originalSearchRegiondata = [];
            var avglat;
            var avglong;
            var totallat = 0.00;
            var totallong = 0.00;
            var elementno = $scope.regionDataBean.length;
            $scope.searchFlag = true;
            for (var i = 0; i < $scope.regionDataBean.length; i++) {
                var item = $scope.regionDataBean[i];
                var searchRlongitude = item.ibLongitude;
                var searchRlatitude = item.ibLatitude;
                var region = item.ibRegion;
                if ((searchRlongitude && searchRlatitude) && (Math.abs(searchRlongitude) <= 180 && Math.abs(searchRlatitude) <= 90)) {
                    var searchRiconFeature = new ol.Feature({
                        geometry: new ol.geom.Point(ol.proj.transform([parseFloat(searchRlongitude), parseFloat(searchRlatitude)], 'EPSG:4326',
                            'EPSG:3857')),
                        region: region,
                        nameM: 'SR'
                    });
                    iconStyle = new ol.style.Style({
                        image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
                            anchor: [0.5, 46],
                            anchorXUnits: 'fraction',
                            anchorYUnits: 'pixels',
                            opacity: 0.75,
                            src: 'images/icon_R.png',
                        })),
                        text: new ol.style.Text({
                            text: region,
                            fill: new ol.style.Fill({
                                color: 'black'
                            }),
                            offsetY: -5
                        })
                    });
                    searchRiconFeature.setStyle(iconStyle);
                    iconFeaturesforSearchR.push(searchRiconFeature);
                    originalSearchRegiondata.push(searchRiconFeature);
                    totallat = totallat + parseFloat(item.ibLatitude);
                    totallong = totallong + parseFloat(item.ibLongitude);
                }
            }
            avglat = totallat / elementno;
            avglong = totallong / elementno;
            if (sitevectorSource !== undefined) {
                sitevectorSource.clear();
            }
            if (vectorSource !== undefined) {
                vectorSource.clear();
            }
            vectorSource = new ol.source.Vector({
                features: iconFeaturesforSearchR //add an array of features
            });


            vectorLayer = new ol.layer.Vector({
                source: vectorSource,
                style: iconStyle
            });

            map.getView().setZoom(3);
            if ((totallat === 0 || totallong === 0) && elementno === 0) {
                map.getView().setCenter(ol.proj.transform([0, 0], 'EPSG:4326', 'EPSG:3857'));
            } else {
                map.getView().setCenter(ol.proj.transform([avglong, avglat], 'EPSG:4326', 'EPSG:3857'));
            }
            map.addLayer(vectorLayer);

            map.on("singleclick", onPointerClickThree);
            map.un("singleclick", onPointerClickTwo);
            map.un("singleclick", onPointerClickFour);
        }

        function onPointerClickThree(e3) {
            displaySearchSite(e3.pixel);
        }

        function displaySearchSite(pixel) {
            var feature = map.forEachFeatureAtPixel(pixel, function(feature) {
                return feature;
            });

            if (feature) {
                var nameM = feature.get('nameM');
                if (nameM === 'SR') {
                    $scope.searchFlag = true;
                    var searchRegion = feature.get("region");
                    $scope.region = searchRegion;
                    iconFeaturesforSite = [];
                    var siteiconStyle;
                    var count = 0;
                    var avglat;
                    var avglong;
                    var totallat = 0.00;
                    var totallong = 0.00;
                    var srcImage;
                    angular.forEach($scope.siteNameDataBean, function(value) {
                        if (value.serviceRelationDesc === 'CONTRACTUAL') {
                            srcImage = 'images/icon_contractual.png';
                        } else if (value.serviceRelationDesc === 'TRANSACTIONAL') {
                            srcImage = 'images/icon_S.png';
                        }
                        if (value.region === searchRegion) {
                            var sitelongitude = value.longitude;
                            var sitelatitude = value.latitude;
                            var siteName = value.siteName;
                            if ((sitelongitude && sitelatitude) && (Math.abs(sitelongitude) <= 180 && Math.abs(sitelatitude) <= 90)) {
                                var siteiconFeature = new ol.Feature({
                                    geometry: new ol.geom.Point(ol.proj.transform([parseFloat(sitelongitude), parseFloat(sitelatitude)], 'EPSG:4326',
                                        'EPSG:3857')),
                                    siteName: siteName,
                                    nameM: 'S'
                                });
                                siteiconStyle = new ol.style.Style({
                                    image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
                                        anchor: [0.5, 46],
                                        anchorXUnits: 'fraction',
                                        anchorYUnits: 'pixels',
                                        opacity: 0.75,
                                        src: srcImage,
                                    }))
                                });
                                siteiconFeature.setStyle(siteiconStyle);
                                iconFeaturesforSite.push(siteiconFeature);
                                totallat = totallat + parseFloat(value.latitude);
                                totallong = totallong + parseFloat(value.longitude);
                                count++;
                            }
                        }
                    });
                    avglat = totallat / count;
                    avglong = totallong / count;
                    if (sitevectorSource !== undefined) {
                        sitevectorSource.clear();
                    }
                    if (vectorSource !== undefined) {
                        vectorSource.clear();
                    }
                    sitevectorSource = new ol.source.Vector({
                        features: iconFeaturesforSite //add an array of features
                    });
                    var sitevectorLayer = new ol.layer.Vector({
                        source: sitevectorSource,
                        style: siteiconStyle
                    });

                    map.getView().setZoom(4);
                    map.getView().setCenter(ol.proj.transform([avglong, avglat], 'EPSG:4326', 'EPSG:3857'));
                    map.addLayer(sitevectorLayer);

                    map.on("singleclick", onPointerClickFour);
                    map.un("singleclick", onPointerClickTwo);
                    map.un("singleclick", onPointerClickThree);

                    map.on('moveend', onPointerMoveFour);
                }
            }
        }

        function onPointerClickFour(e4) {
            displaySiteInfo(e4.pixel);
        }

        function onPointerMoveFour(e4) {
            checknewzoom();
        }

        $(".searchResultPopupClose").click(function() {
            $("#popup").hide();
        });
        $(".unitInfoPopupClose").click(function() {
            $("#SiteInfoContent").hide();
        });
        $(".validationDismiss").click(function() {
            $("#filterSearch").hide();
        });
        $scope.backtoSite = function() {
            $("#SiteInfoContent").hide();
            $("#popup").show();

        };
        $(".unitInfo").click(function() {
            $("#unitInfodiv").show();
            $("#popup").hide();
        });

        $('px-app-nav button').click(function() {
            setTimeout(function() {
                map.updateSize();
            }, 600);
        });
        $(".legend").unbind().click(function(e) {
            $(this).find('ul').slideToggle();
            $(this).find(".arrowCSS").toggleClass("control_down");
            e.stopPropagation();
        });
    }]);
});