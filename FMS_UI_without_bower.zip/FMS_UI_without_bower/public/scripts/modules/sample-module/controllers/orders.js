define(['angular', '../sample-module', 'jquery', 'datatablesNetMin', 'datatablesNet', 'bootstrap-popover', 'fileSaver', 'datatablesNetRowReorder', 'datatablesNetResponsive'], function(angular, controllers) {
    'use strict';
    controllers.controller('ordersCtrl', ['$scope', '$rootScope', '$http', '$location', '$state', '$q', '$timeout', function($scope, $rootScope, $http, $location, $state, $q, $timeout) {
        
        var deferredAbort;
        
        $rootScope.uploadMessageOrders = "Updating..";
        $scope.FileUploadStatus        = "Request not yet submitted";
        
        $rootScope.getOrdersYears = function() {
            $http.get("connect/fms/getOrdersYears").then(function(response) {
                $scope.yearObj = response.data;
            });
        };

        $rootScope.getOrdersYears();

        jQuery.fn.center = function() {
            this.css({
                top: ($(window).outerHeight()) / 2,
                left: ($(window).outerWidth()) / 2
            });
            return this;
        };

        $scope.flag = true;
        $scope.selectAllBox = false;
        $(".overlay").css("height", $(document).height());
        $(".loading").center();
        $(".loading").show();
        $(".overlay").show();

        var historyModal = document.getElementById('ordersHistoryDataModal');
        var historySpan = document.getElementsByClassName("ordersHistoryClose")[0];
        historySpan.onclick = function() {
            historyModal.style.display = "none";
        }
        window.onclick = function(event) {
            if (event.target === historyModal) {
                historyModal.style.display = "none";
            }
        }

        $("body").on("change", "#checkAll", function() {
            var checkSelectAll = $('.popover .inline .showHideTitle input[type="checkbox"]').is(":checked");
            if (checkSelectAll === true) {
                $('.popover-content .innerShowHideTitle input[type="checkbox"]').prop('checked', true);
                $scope.selectAllBox = true;
            } else {
                $scope.selectAllBox = false;
                $('.popover-content .innerShowHideTitle input[type="checkbox"]').prop('checked', false);
                $('.popover-content .innerShowHideTitle input[type="checkbox"]').each(function(i) {
                    if (i < 16) {
                        $(this).prop('checked', true);
                    }
                });
            }
            $scope.$apply();
            resizeAll();
        });

        $scope.columnTitleList = [];

        $http.get("connect/fms/getChooseColumns").then(function(response) {
            $scope.ordersColumns = response.data.OrdersColumns;
            for (var cols = 0; cols < $scope.ordersColumns.length; cols++) {
                if ($scope.ordersColumns[cols].active === "Y") {
                    var item = {};
                    item["index"] = $scope.ordersColumns[cols].displayOrder - 1;
                    item["title"] = $scope.ordersColumns[cols].displayName;
                    item["name"] = $scope.ordersColumns[cols].columnName;
                    if ($scope.ordersColumns[cols].checked === 1) {
                        item["checked"] = "YES";
                    } else
                        item["checked"] = "NO";
                    $scope.columnTitleList.push(item);
                }
            }
        });

        $('#ordersPopover').popover({
            html: true,
            placement: 'bottom',
            content: function() {
                if ($scope.selectAllBox) {
                    $('.popover .inline .showHideTitle input[type="checkbox"]').prop('checked', true);
                } else {
                    $('.popover .inline .showHideTitle input[type="checkbox"]').prop('checked', false);
                }
                return $('#ordersPopover-content-wrapper').html();
            }
        }).on('click', function(e) {
            e.preventDefault();
        });
        
        $('body').on('click', '#ordersColHideShowCancel', function() {
            $('.popover').css('display', 'none');
        });

        $('body').on('click', '#ordersColHideShowApply', function() {
            $('.popover').css('display', 'none');
            $rootScope.safeApply(function() {
                for (var colIndex = 0; colIndex < $scope.columnTitleList.length; colIndex++) {

                    if (!($("#" + $scope.columnTitleList[colIndex].name).is(":checked"))) {
                        $scope.columnTitleList[colIndex].checked = "NO";
                       $('table[data-table-name="orders-Data"]').dataTable().fnSetColumnVis($scope.columnTitleList[colIndex].index, false);
                    } else {
                        $scope.columnTitleList[colIndex].checked = "YES";
                       $('table[data-table-name="orders-Data"]').dataTable().fnSetColumnVis($scope.columnTitleList[colIndex].index, true);
                    }
                }
            });

        });
        var ordersTable;
        $scope.updateData = {};

        $rootScope.ordersSearchData = function(input) {
            $(".loading").center();
            $(".loading").show();
            $(".overlay").show();
            $http.post("connect/fms/getOrderDataWithFilter", JSON.stringify({
                "type": input,
                "businessSegment":$rootScope.businessSegment,
                "marketIndustry":$rootScope.marketIndustry ? $rootScope.marketIndustry : ""
            })).then(function(response) {
                $scope.updateData = response.data;
                updateOrdersData();
            }).then(function() {
                resizeAll();
            });
        }
        
        if ($rootScope.marketIndustry) {
            $rootScope.ordersSearchData('DEFAULT');
        } else  {
            $timeout(function() {
                $rootScope.ordersSearchData('DEFAULT');
            }, 5000); 
        }
        
        $("body").off("change", "#orderAllData");
        $("body").on("change", "#orderAllData", function() {
            var flag = $(this).is(":checked");
            if (flag) {
                $rootScope.ordersSearchData('ALL');
            } else {
                $rootScope.ordersSearchData('DEFAULT');
            }
        });

        $('table[data-table-name="orders-Data"] tfoot td').each(function() {
            var title = $(this).text();
            if (title !== '') {
                $(this).html('<input type="text" placeholder="Search ' + title + '" size="4" />');
            }
        });

        var $window     = $(window);
        var windowsize  = $window.width();
        var dtOptions;
        if (windowsize > 767) {
            dtOptions = {
        		rowReorder: {
            		selector: 'td:nth-child(2)'
            	},
            	responsive: false,
            	"bPaginate": true,
            	"bSort": true,
            	"bFilter": true,
            	"aLengthMenu": [
            	                [10, 20, 50, 100, -1],
            	                [10, 20, 50, 100, "All"]
            	                ],
            	                "iDisplayLength": 10,
            	                "bAutoWidth": false  
            };
        } else {
            dtOptions = {
        		rowReorder: {
            		selector: 'td:nth-child(2)'
            	},
            	responsive: true,
            	"bPaginate": true,
            	"bSort": true,
            	"bFilter": true,
            	"aLengthMenu": [
            	                [10, 20, 50, 100, -1],
            	                [10, 20, 50, 100, "All"]
            	                ],
            	                "iDisplayLength": 10,
            	                "bAutoWidth": false     
            };
        }
        ordersTable = $('table[data-table-name="orders-Data"]').DataTable(dtOptions);

        // Apply the search
        ordersTable.columns().every(function() {
            var that = this;

            $('input', this.footer()).on('keyup change', function() {
                if (that.search() !== this.value) {
                    that
                        .search(this.value)
                        .draw();
                }
            });
        });

        function updateOrdersData() {
            if ($scope.flag === true) {
                $(".loading").hide();
                $(".overlay").hide();
            } else {
                $(".overlay").css("height", $(document).height());
                $(".overlay").show();
            }
            $('table[data-table-name="orders-Data"]').dataTable().fnClearTable();
            angular.forEach($scope.updateData, function(data) {
                $('table[data-table-name="orders-Data"]').dataTable().fnAddData([
                       data.c_opportunity_id, 
                       data.c_project, 
                       data.c_submit_by_name,
                       data.d_book_date_src, 
                       data.c_og_region_name, 
                       data.c_country_name, 
                       data.c_state_name, 
                       data.pm_product_mapping,
                       data.n_service_type,
                       data.c_end_user_name, 
                       data.me_tier_4, 
                       data.me_dm_tier_3, 
                       data.sm_segment_mapping,
                       data.ge_duns_name,
                       data.n_ord_rec_id, 
                       data.c_source_system, 
                       data.c_category_desc, 
                       data.c_book_owner_sso, 
                       data.c_book_owner_name, 
                       data.d_submit_date, 
                       data.c_submit_by_sso, 
                       data.n_book_year, 
                       data.n_book_quarter, 
                       data.n_book_month, 
                       data.c_src_legal_entity, 
                       data.c_src_mgmt_entity, 
                       data.c_mgmt_entity_code, 
                       data.c_segment_type_code, 
                       data.c_product_type_desc, 
                       data.c_project_parent_no, 
                       data.c_contract_no, 
                       data.c_cust_order_no, 
                       data.c_src_currency_cod, 
                       data.n_src_order_val, 
                       data.n_fx_rate_eur, 
                       data.n_order_val_eur, 
                       data.n_fx_rate_usd, 
                       data.n_order_val_usd, 
                       data.n_order_val_op_rate, 
                       data.n_cm_perc_as_sold, 
                       data.n_cm_eur, 
                       data.n_cm_usd, 
                       data.n_cm_op_rate, 
                       data.c_buyer_duns_code, 
                       data.c_buyer_np_code, 
                       data.c_buyer_name, 
                       data.c_end_user_duns_code,
                       data.c_end_user_np_code, 
                       data.c_country_code, 
                       data.c_state_code, 
                       data.c_gge_region_name, 
                       data.c_ggo_region_name, 
                       data.c_csa_region_name, 
                       data.c_dts_region_name, 
                       data.c_last_update_by, 
                       data.c_last_update_name, 
                       data.d_last_update_date, 
                       data.d_delivery_date, 
                       data.d_order_date, 
                       data.c_agent_code, 
                       data.c_freight_terms_code, 
                       data.c_buyer_country_name, 
                       data.c_contract_type, 
                       data.f_initial_stock_tx, 
                       data.c_market, 
                       data.c_src_new_og_pl, 
                       data.c_tier2_cod_from_mgmt, 
                       data.c_project_name, 
                       data.c_plant, 
                       data.n_book_week, 
                       data.c_tier3_cod_from_mgmt, 
                       data.c_tier_3_p_l, 
                       data.c_tier_4_p_l, 
                       data.c_orders_view, 
                       data.me_mapping_incl_sc_corrections, 
                       data.me_p_and_l, 
                       data.me_svc_or_eq, 
                       data.me_tier_3, 
                       data.me_usage,
                       data.n_tier_3,
                       data.n_src_ref_no,
                       data.n_tms_region,
                       data.n_core_arev,
                       data.n_assignment,
                       data.n_train_config,
                       data.n_segment_nu,
                       data.n_change_order,
                       data.n_svc_or_eq,
                       data.n_comments,
                       data.n_me_tier_2,
                       data.n_num_units_new,
                       data.e_site_cust_name
                ], false);
            });
            $('table[data-table-name="orders-Data"]').dataTable().fnDraw(true);
            $('#ordersColHideShowApply').click();

        }

        function download(url, data, defaultFileName) {
            var deferred = $q.defer();
            $http.post(url, data, {
                responseType: "arraybuffer"
            }).success(
                function(data, status, headers) {
                    var type = headers('Content-Type');
                    var disposition = headers('Content-Disposition');
                    if (disposition) {
                        var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                        if (match[1])
                            defaultFileName = match[1];
                    }
                    defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                    var blob = new Blob([data], {
                        type: type
                    });
                    saveAs(blob, defaultFileName);
                    deferred.resolve(defaultFileName);
                }).error(function() {
                var e;
                deferred.reject(e);
            });
            return deferred.promise;
        }

        $scope.hideUpload = function(objButton) {
            $rootScope.mappingParam = objButton;
            if ($rootScope.mappingParam === "OrderCsvData" || $rootScope.mappingParam === "RevenueUpdate") {

                $('.fileUpload').attr('accept', '.csv');
            } else {
                $('.fileUpload').removeAttr('accept');
            }
            if ($scope.showUploadOption) {
                $scope.showUploadOption = false;
                $rootScope.uploadStatus = false;
                $rootScope.uploadMessageOrders = "";
                $rootScope.uploadMessage = "";
                angular.element("input[type='file']").val(null);
                $scope.myFile = null;
            } else {
                $scope.showUploadOption = true;
            }
        }

        $scope.closeDiv = function() {
            $rootScope.uploadStatus = false;
            $rootScope.orderUploadStatus = false;
            $scope.showUploadOption = false;
            angular.element("input[type='file']").val(null);
            $scope.myFile = null;
            $rootScope.uploadMessageOrders = "";
            $rootScope.uploadMessage = "";
        }
        $scope.uploadFile = function() {
            if ($rootScope.mappingParam === "OrderCsvData") {
                $rootScope.uploadStatus = "IN-PROGRESS";
            } else {
                $rootScope.orderUploadStatus = true;
            }
            
            var file;
            file = $scope.myFile;
            
            if (file) {
                
                var filename     = file.name;
                var index        = filename.lastIndexOf(".");
                var strsubstring = filename.substring(index, filename.length);
                
                if (($rootScope.mappingParam === "OrderCsvData" || $rootScope.mappingParam ==="RevenueUpdate") && strsubstring !== '.csv') {
                    if($rootScope.mappingParam === "OrderCsvData") {
                        $rootScope.safeApply(function(){
                              $timeout(function (){
                                  $('.uploadMessage').addClass("successMsg");
                                  $('.uploadMessage').removeClass("failureMsg");
                              },200);
                              $rootScope.uploadStatus = "WARNING";
                        });
                    } else {
                        $rootScope.safeApply(function(){
                              $timeout(function (){
                                  $('.uploadMessageOrders').removeClass("successMsg");
                                  $('.uploadMessageOrders').addClass("failureMsg");
                                  $rootScope.uploadMessageOrders = 'Please choose .csv file';
                              },200);
                              $rootScope.orderUploadStatus = true;
                        });
                    }
                } else {
                    var uploadUrl = "connect/fms/orderMappingExcelUpload";
                    
                    if ($rootScope.mappingParam === "OrderCsvData") {
                        $('.uploadMessage').removeClass("failureMsg");
                        $('.uploadMessage').addClass("successMsg");
                        $rootScope.uploadStatus = "IN-PROGRESS";
                    } else {
                        $('.uploadMessageOrders').removeClass("failureMsg");
                        $('.uploadMessageOrders').addClass("successMsg");
                        $rootScope.uploadMessageOrders = "UPDATING..";
                    }
                
                    $timeout(function() {
                        deferredAbort.resolve("User cancelled");
                    }, 60000);
                    
                    $scope.uploadFileToUrl(file, uploadUrl)
                    .then(function(data) {
                        if (data === "SUCCESS") {
                            if ($rootScope.mappingParam === "OrderCsvData"){
                                $rootScope.safeApply(function() {
                                    $timeout(function (){
                                        $('.uploadMessage').addClass("successMsg");
                                        $('.uploadMessage').removeClass("failureMsg");
                                        $rootScope.getOrdersYears();
                                        angular.element("input[type='file']").val(null);
                                    },200); 
                                    $rootScope.uploadStatus = "SUCCESS";
                                });
                            }else{
                                $rootScope.safeApply(function() {
                                    $timeout(function (){
                                        $('.uploadMessageOrders').addClass("successMsg");
                                        $('.uploadMessageOrders').removeClass("failureMsg");
                                        $rootScope.uploadMessageOrders = "Upload Successful!";
                                        $rootScope.getOrdersYears();
                                        angular.element("input[type='file']").val(null);
                                    },200);      
                                    $rootScope.orderUploadStatus = true;
                                });
                            }
                        } else {
                            if ($rootScope.mappingParam === "OrderCsvData"){
                               if ($rootScope.uploadStatus === "IN-PROGRESS") {
                                    $rootScope.safeApply(function(){
                                          $timeout(function (){
                                               $('.uploadMessage').removeClass("failureMsg");
                                               $('.uploadMessage').addClass("successMsg");
                                          },200);
                                          $rootScope.uploadStatus = "IN-PROGRESS";
                                    });  
                                } else {
                                    $rootScope.safeApply(function(){
                                          $timeout(function (){
                                               $('.uploadMessage').removeClass("successMsg");
                                               $('.uploadMessage').addClass("failureMsg");
                                               angular.element("input[type='file']").val(null);
                                          },200);
                                          $rootScope.uploadStatus = "FAILURE";
                                    });
                                }
                            } else {
                                $rootScope.safeApply(function(){
                                    $timeout(function (){
                                        $('.uploadMessageOrders').removeClass("successMsg");
                                        $('.uploadMessageOrders').addClass("failureMsg");
                                        $rootScope.uploadMessageOrders = "Upload Failure!";
                                        angular.element("input[type='file']").val(null);
                                    },200);
                                    $rootScope.orderUploadStatus = true;
                                });
                            }
                        }
                    }, function(error){
                        if ($rootScope.mappingParam === "OrderCsvData") {
                            if ($rootScope.uploadStatus === "IN-PROGRESS") {
                                $rootScope.safeApply(function(){
                                      $timeout(function (){
                                           $('.uploadMessage').removeClass("failureMsg");
                                           $('.uploadMessage').addClass("successMsg");
                                      },200);
                                      $rootScope.uploadStatus = "IN-PROGRESS";
                                });  
                            } else {
                                $rootScope.safeApply(function(){
                                      $timeout(function (){
                                           $('.uploadMessage').removeClass("successMsg");
                                           $('.uploadMessage').addClass("failureMsg");
                                           angular.element("input[type='file']").val(null);
                                      },200);
                                      $rootScope.uploadStatus = "FAILURE";
                                });
                            }
                        } else {
                            $rootScope.safeApply(function(){
                                  $timeout(function (){
                                       $('.uploadMessageOrders').removeClass("successMsg");
                                       $('.uploadMessageOrders').addClass("failureMsg");
                                       $rootScope.uploadMessageOrders = "Upload Failure!";
                                       angular.element("input[type='file']").val(null);
                                  },200);
                                $rootScope.orderUploadStatus = true;
                            });
                        }
                    }).finally(function(){
                        $scope.myFile = null;
                    });
                }
            } else {
                if ($rootScope.mappingParam === "OrderCsvData") {
                    $('.uploadMessage').removeClass("successMsg");
                    $('.uploadMessage').addClass("failureMsg");
                    $rootScope.uploadStatus = "WARNING";
                } else {
                    $('.uploadMessageOrders').removeClass("successMsg");
                    $('.uploadMessageOrders').addClass("failureMsg");
                    $rootScope.uploadMessageOrders = "Please select file to upload!";
                }
            }
        };
        
        $scope.uploadFileToUrl = function(file, uploadUrl) {

            deferredAbort = $q.defer();

            var fd = new FormData();
            fd.append('file', file);
            fd.append('mappingParam', $rootScope.mappingParam);
            fd.append('userSSO', $rootScope.userSSO);
            fd.append('businessSegment', $rootScope.businessSegment);
            fd.append('marketIndustry', $rootScope.marketIndustry ? $rootScope.marketIndustry : "");

            var startTime = (new Date()).getTime();

            $scope.FileUploadStatus = 'Request submitted';
            
            $http.post(uploadUrl, fd, 
            {
                withCredentials: true,
                headers: {'Content-Type': undefined },
                transformRequest: angular.identity,
                timeout: deferredAbort.promise 
            })
            .success(function (data, status, headers, config) {   
                var endTime = (new Date()).getTime();
                $scope.FileUploadStatus = 'Request response returned after ' + (endTime - startTime) + ' msec.';
                deferredAbort.resolve(data);
            })
            .error(function (err, status) {
                var endTime = (new Date()).getTime();
                if(status === 0) {
                    $scope.FileUploadStatus = 'Request timed out after ' + (endTime - startTime) + ' msec.';
                    $rootScope.uploadStatus = "FAILURE";
                } else {
                    $scope.FileUploadStatus = 'Request returned with error after ' + (endTime - startTime) + ' msec.';
                    $rootScope.uploadStatus = "IN-PROGRESS";
                }
                
                deferredAbort.reject({msg: err});
            });

            return deferredAbort.promise;
        }
        
        $('input[name=myFile]').change(function(ev) {
            $rootScope.uploadMessageOrders = "";
        });

        $scope.downloadTemplate = function(fileName, year) {
            var item = {};
            if (year === undefined) {
                item["type"] = fileName;
            } else {
                item["type"] = fileName;
                item["year"] = year;
            }
            item["businessSegment"] = $rootScope.businessSegment;
            item["marketIndustry"]  = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            download('/connect/fms/downloadFile', item, fileName);
        };
        $scope.downloadExcelFile = function(fileName) {
            download('/connect/fms/downloadExcelFile', fileName, fileName);
        };

        if ($rootScope.editAccess === "N") {
            $('.dropdown-submenu').addClass('pull-left');
        } else {
            $('.dropdown-submenu').removeClass('pull-left');
        }

        $scope.getImportHistory = function() {
            $(".loading").center();
            $(".loading").show();
            $(".overlay").show();

            if ($.fn.DataTable.isDataTable('#orderHistoryTable')) {
                $("#orderHistoryTable").dataTable().api().clear().draw();
                $("#orderHistoryTable").dataTable().api().destroy();
                $('#orderHistoryTable').empty();
            }

            $http.post("connect/fms/getImportStatusHistory", JSON.stringify({
                "taskName": "Orders Import"/**+$rootScope.businessSegment*/, 
                "sso": $rootScope.userSSO
            })).then(function(response) {
                $rootScope.safeApply(function() {

                    $(".loading").hide();
                    $(".overlay").hide();

                    $scope.ordersHistoryData = response.data;
                    historyModal.style.display = "block";

                    $scope.arrOrdersHistoryHeaders = [{
                            data: "created_date",
                            title: "Date",
                            width: "33%"
                        },
                        {
                            data: "task_name",
                            title: "Task Name",
                            width: "33%"
                        },
                        {
                            data: "status",
                            title: "Status",
                            width: "33%",
                            "fnCreatedCell": function(nTd, sData, oData, iRow, iCol) {
                                if (sData === "FAILURE") {
                                    $(nTd).css('color', '#FF0000').css('font-weight', 'bold');
                                }
                            }
                        }
                    ];

                    $('#orderHistoryTable').DataTable({
                        "order": [
                            ["0", "desc"]
                        ],
                        "bFilter": false,
                        "paging": false,
                        "responsive": true,
                        "columns": $scope.arrOrdersHistoryHeaders,
                        "data": $scope.ordersHistoryData
                    });


                });
            });
        }
    }]);
});