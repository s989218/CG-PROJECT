
define(['angular','../sample-module'], function (angular,controllers) 
 {
    'use strict';
    controllers.controller('techRegionCtrl', ['TechnologyRegionChart','NewMetricTechService','$scope', '$rootScope', '$http', '$location', '$state', 
	function (TechnologyRegionChart,NewMetricTechService,$scope,$rootScope, $http, $location, $state ) 
                {

	}]);
});




