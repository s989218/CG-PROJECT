define(['angular', '../sample-module', 'jquery', 'datatablesNetMin', 'datatablesNet', 'multiselectdrpdwn', 'jqueryMultiSelect'],
    function(angular, controllers) {
        'use strict';
        controllers.controller('topCustomerCtrl', ['CustomerChartService', 'TopCustomerService', 'LoaderService', '$rootScope', '$scope', '$state', '$timeout', '$http', '$q',
            function(CustomerChartService, TopCustomerService, LoaderService, $rootScope, $scope, $state, $timeout, $http, $q) {
                var chart;
                $rootScope.ibo_equipmentquarteryear = sessionStorage.ibo_equipmentquarteryear;

                $('.backClass').click(function() {
                    $state.go('NewMetrics');
                });

                jQuery.fn.center = function() {
                    this.css({
                        top: ($(window).outerHeight()) / 2,
                        left: ($(window).outerWidth()) / 2
                    });
                    return this;
                };

                $(".loading").center();

                function loaderOps(state) {
                    LoaderService.loaderOps(state);
                }

                var yearQData = getYearQuarter();
                $rootScope.ibo_equipmentquarteryear = yearQData.ibo_equipmentquarteryear;
                $scope.regionSelected = true;
                $('.errorIndicator').hide(100);
                loaderOps(true);

                /* To Get Rid of Apply Already In Progress Error */
                $scope.safeApply = function(fn) {
                    $timeout(fn);
                }

                var defaultData = {};
                $scope.selected = 0;

                function checkParent(props) {
                    if (props.ngModel === 'depSearch.regions') {
                        if ($scope.depSearch.regions.length > 0) {
                            $('select.dependentFilter[id="siteCustCountrySearch"]').prop('disabled', 'false');
                            $('select.dependentFilter[id="siteCustCountrySearch"]').siblings().children().removeClass('disabled');
                        } else {
                            $('select.dependentFilter[id="siteCustCountrySearch"]').prop('disabled', 'true');
                            $('select.dependentFilter[id="siteCustCountrySearch"]').siblings().children().addClass('disabled');
                        }
                    }
                }

                $scope.getCountries = function() {
                    $('#depRegionSearch').removeClass('boxShadow');
                    var country = $("select.dependentFilter[id='depRegionSearch']").val();
                    if (country !== null && country !== 'Select Region') {
                        var item = {};
                        item["regionName"]=country;
                        item["businessSegment"]=$rootScope.businessSegment;
                        item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                        item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
                        TopCustomerService.getCountries(JSON.stringify(item)).then(function(response) {
                            var selectOption = '',
                                countryName = '';
                            $timeout(function() {
                                    $('.errorIndicator').hide(100);
                                    _.forEach(response, function(response) {
                                        countryName = response.countryName;
                                        selectOption = selectOption + '<option value="' + countryName + '">' + countryName + '</option>'
                                    })
                                })
                                .then(function() {
                                    var scriptTag = '<script>$("select#depSiteCustCountrySearch").multipleSelect({filter: true, selectAll: false});</script>'
                                    $timeout(function() {
                                        /* Show Multiselect */
                                        $('#depSiteCustCountrySearch').empty().append(selectOption).append(scriptTag);
                                        $('div.countrySelectBtn').show(100);
                                        $('select.dependentFilter[id="depSiteCustCountrySearch"]').prop('disabled', 'false');
                                        $('select.dependentFilter[id="depSiteCustCountrySearch"]').siblings().children().removeClass('disabled');
                                        $('button#placeboMultiSelect').hide(100);
                                    });
                                });
                        });
                    } else {
                        $('select.dependentFilter[id="depSiteCustCountrySearch"]').prop('disabled', 'true');
                        $('select.dependentFilter[id="depSiteCustCountrySearch"]').siblings().children().addClass('disabled');
                    }
                }

                function getSelectedValue(id) {
                    var selector = "select.dependentFilter[id='" + id + "']";
                    if ((id === 'depRegionSearch' && $(selector).val() != null) || (id==='iboTypeDropdownSearch' && $(selector).val() != null)) {
                        return $(selector).val();
                    } else {
                        if ($(selector).val() !== undefined) {
                            var values = [];
                            _.forEach($(selector).val(), function(choice) {
                                values.push("^" + choice + "$");
                            });
                            return values.join("|");
                        } else
                            return "";
                    }
                }

                var tableCreate = function(custNameDataBean, serviceData) {
                    var dataObj;
                    if (arguments.length > 1 && arguments[2] === true) {
                        dataObj = TopCustomerService.customerCountryTableData(custNameDataBean);
                        TopCustomerService.initTable(dataObj['dataArr'], dataObj['columns'], 'IB-by-Top-Cust-Country-Data', dataObj['regionCount']);
                        $('#countryTable').addClass('in');
                        $timeout(function(){
                            $('.countryTableDiv').show();
                        }, 500);
                    } else {
                        dataObj = TopCustomerService.customerTableData(custNameDataBean);
                        TopCustomerService.initTable(dataObj['dataArr'], dataObj['columns'], 'IB-by-Top-Cust-Data', dataObj['regionCount']);
                        $('#collapse4').addClass('in');
                        $timeout(function(){
                            $('.regionTableDiv').show();
                        }, 500);
                    }
                }


                var updateTopCustDatatable = function(response) {
                    var serviceData;
                    if (arguments.length > 1 && arguments[1] === true) {
                        serviceData = (TopCustomerService.countryDataProcessing(response.custNameDataBean));
                    } else
                        serviceData = (TopCustomerService.processAllCustomerData(response.custNameDataBean));
                    $scope.custNameData = response.custNameDataBean;
                    var customers = serviceData['customers'],
                        chartData = serviceData['chartData'];
                    if (arguments.length > 1 && arguments[1] === true) {
                        if (response.custNameDataBean.length > 0) {
                            tableCreate(response.custNameDataBean, serviceData, true);
                            $scope.topCustChart(customers, chartData, 'country_chart');
                            $('.ctrError').hide(100);
                            $('.ctrView').show(100);
                            $scope.safeApply(function() {
                                $scope.dep_custDataExp = true;
                                $scope.dep_custChartExp = true;
                            });
                            $('#countryTable,#countryChart').addClass('in');
                            $timeout(function(){
                                $timeout(function(){
                                    $('#countryChart').height($('#country_chart').outerHeight() + 50);
                                    $('#countryTable > #tableDivision').height($('#IB-by-Top-Cust-Country-Data_wrapper').outerHeight() + 50);
                                    $('#countryChart > #techRegionChart').outerHeight($('#countryChart').height());
                                    $('#countryTable').outerHeight($('#countryTable > #tableDivision').outerHeight() + 20);
                                }, 250);
                            }, 200);
                        } else {
                            $('.ctrError').show(100).css('display', 'flex');
                            $('.ctrView').hide(100);
                        }
                    } else {
                        if (response.custNameDataBean.length > 0) {
                            tableCreate(response.custNameDataBean, serviceData);
                            $scope.topCustChart(customers, chartData, 'container2');
                            $('.regError').hide(100);
                            $('.regView').show(100);
                            $scope.safeApply(function() {
                                $scope.custDataExp = true;
                                $scope.custChartExp = true;
                            });
                            $timeout(function(){
                                $timeout(function(){
                                    $('#collapse3').height($('#container2').outerHeight() + 50);
                                    $('#collapse4 > #tableDivision').height($('#IB-by-Top-Cust-Data_wrapper').outerHeight() + 50);
                                    $('#collapse3 > #techRegionChart').outerHeight($('#collapse3').height());
                                    $('#collapse4').outerHeight($('#collapse4 > #tableDivision').outerHeight() + 20);
                                }, 250);
                            }, 200);
                        } else {
                            $('.regError').show(100).css('display', 'flex');
                            $('.regView').hide(100);
                        }
                    }

                    loaderOps(false);
                }

                window.addEventListener('px-tab-changed', function(event) {
                    var selectedTab = parseInt(event.target.selected);
                    Polymer.dom().querySelector('px-tab-pages').selected = selectedTab;
                    if (selectedTab === 0) {
                        $('.rstFltr').show()
                    } else {
                        $('.rstFltr').hide()
                    }
                });

                $rootScope.dep_ibTopCustomerCountrySearchData = function() {
                    var jsonData = [];
                    var item = {};
                    item["region"] = getSelectedValue('depRegionSearch');
                    item["unitStatusDesc"] = getSelectedValue('unitStatusSearch');
                    item["siteCustCountry"] = getSelectedValue('depSiteCustCountrySearch');
                    item["servRelationDescOng"] = getSelectedValue('serviceRelSearch');
                    item["technology"] = getSelectedValue('techSearch');
                    item["oemLoc"] = getSelectedValue('oemLocSearch');
                    item["marketSegmentDesc"] = getSelectedValue('marketSearch');
                    item["customerName"] = getSelectedValue('customerNameSearch');
                    item["siteCustDunsName"] = getSelectedValue('siteCustDunsNameSearch');
                    item["siteCustName"] = getSelectedValue('siteCustNameSearch');
                    item["siteNameAlias"] = getSelectedValue('siteNameAliasSearch');
                    item["equipmentCodeFilter"] = getSelectedValue('equipmentCodeDropdownSearch');
                    item["iboType"] = getSelectedValue('iboTypeDropdownSearch');
                    item["businessSegment"] =$rootScope.businessSegment;
                    item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                    item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
                    jsonData.push(item);
                    if (!((item['region']) === '') && (item['region']).includes('undefined') === false && !((item['region']) === 'Select Region')) {
                        loaderOps(true);
                        TopCustomerService.getIBCountryMetricsFilterData(jsonData).then(function(response) {
                            $scope.responseData = response;
                            updateTopCustDatatable(response, true);
                            resizeAll();
                            $('#countryTable, #countryChart').show();
                            loaderOps(false);
                        });
                    } else {
                        $('#depRegionSearch').addClass("boxShadow");
                        $('.errorIndicator').show(100);
                    }
                    // Raw data parameters
                    $scope.topCRegionIBRawData = [];
                    $scope.topCCountryIBRawData = [];
                    $scope.flgTopCRegionIBRawData = false;
                    $scope.flgTopCCountryIBRawData = false;
                }
                /* Create Chart When transferred from NewMetrics Page */
                
                $timeout(function() {
                    if (!$rootScope.accountManager && !$rootScope.marketIndustry) {
                        $rootScope.ibTopCustomerDropdownsData();
                        $rootScope.getIBMetricsTopCustomerData();
                    }
                }, 5000);
                
                if ($rootScope.accountManager) {
                    $timeout(function() {
                        $rootScope.ibTopCustomerDropdownsData();
                        $rootScope.ibTopCustomerRegionSearchData();
                    }, 5000);   
                } else {
                    $timeout(function() {
                        $rootScope.ibTopCustomerDropdownsData();
                        $rootScope.getIBMetricsTopCustomerData();
                    }, 5000);
                }

                $rootScope.ibTopCustomerDropdownsData = function() {
                    
                    var item = {};
                    item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                    item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
                    
                    TopCustomerService.getIBMetricsDropdownsData(JSON.stringify(item)).then(function(response) {
                        $scope.safeApply(function() {
                            $scope.regionDropdownBean = response.regionDropdownBean;
                            $scope.unitStatusDropdownBean = response.unitStatusDropdownBean;
                            $scope.siteCustCountryDropdownBean = response.siteCustCountryDropdownBean;
                            $scope.servRelationDropdownBean = response.servRelationDropdownBean;
                            $scope.techDropdownBean = response.techDropdownBean;
                            $scope.oemLocDDBean = response.oemLocationDDBean;
                            $scope.marketSegmentDropdownBean = response.marketSegmentDropdownBean;
                            $scope.custDropdownBean = response.custDropdownBean;
                            $scope.siteCustDunsNameDDBean = response.siteCustDunsNameDDBean;
                            /*newly added*/
                            $scope.siteCustomerNameDropdownBean = response.siteCustomerNameDropdownBean;
                            $scope.siteNameAliasDropdownBean = response.siteNameAliasDropdownBean;
                            $scope.equipmentCodeDropdown = response.equipmentCodeDropdown;
                            $scope.businessSegmentDropdown = response.businessSegmentDropdown;
                            $scope.iboTypeDropdown = response.iboTypeDropdown;
                        });
                        $timeout(function(){
                            $("select:not(#depRegionSearch,#depSiteCustCountrySearch,#siteCustCountrySearch,#customerNameSearch,#IB-by-Top-Cust-Data_length select,#marketIndustryDropdownBean,#iboTypeDropdownSearch)").multipleSelect({
                                filter: true
                            });
                            $("select#siteCustCountrySearch,select#customerNameSearch").multipleSelect({
                                filter: true,
                                selectAll: false
                            });
                            $scope.depSearch.iboType = $scope.iboTypeDropdown[1];
                        }, 500);
                        resizeAll();
                    });
                }

                $rootScope.ibTopCustomerRegionSearchData = function() {
                    loaderOps(true);
                    var jsonData = [];
                    var item = {};
                    item["region"] = ($("#regionSearch").val() === undefined || !$("#regionSearch").val()) ? "" : '^' + $("#regionSearch").val().join("$|^") + '$';
                    item["unitStatusDesc"] = ($("#unitStatusSearch").val() === undefined || !$("#unitStatusSearch").val()) ? "" : '^' + $("#unitStatusSearch").val().join("$|^") + '$';
                    item["siteCustCountry"] = ($("#siteCustCountrySearch").val() === undefined || !$("#siteCustCountrySearch").val()) ? "" : '^' + $("#siteCustCountrySearch").val().join("$|^") + '$';
                    item["servRelationDescOng"] = ($("#serviceRelSearch").val() === undefined || !$("#serviceRelSearch").val()) ? "" : '^' + $("#serviceRelSearch").val().join("$|^") + '$';
                    item["technology"] = ($("#techSearch").val() === undefined || !$("#techSearch").val()) ? "" : '^' + $("#techSearch").val().join("$|^") + '$';
                    item["oemLoc"] = ($("#oemLocSearch").val() === undefined || !$("#oemLocSearch").val()) ? "" : '^' + $("#oemLocSearch").val().join("$|^") + '$';
                    item["marketSegmentDesc"] = ($("#marketSearch").val() === undefined || !$("#marketSearch").val()) ? "" : '^' + $("#marketSearch").val().join("$|^") + '$';
                    item["customerName"] = ($("#customerNameSearch").val() === undefined || !$("#customerNameSearch").val()) ? "" : '^' + $("#customerNameSearch").val().join("$|^") + '$';
                    item["siteCustDunsName"] = ($("#siteCustDunsNameSearch").val() === undefined || !$("#siteCustDunsNameSearch").val()) ? "" : '^' + $("#siteCustDunsNameSearch").val().join("$|^") + '$';
                    item["siteCustName"] = ($("#siteCustNameSearch").val() === undefined || !$("#siteCustNameSearch").val()) ? "" : '^' + $("#siteCustNameSearch").val().join("$|^") + '$';
                    item["siteNameAlias"] = ($("#siteNameAliasSearch").val() === undefined || !$("#siteNameAliasSearch").val()) ? "" : '^' + $("#siteNameAliasSearch").val().join("$|^") + '$';
                    item["equipmentCodeFilter"] = ($("#equipmentCodeDropdownSearch").val() === undefined || !$("#equipmentCodeDropdownSearch").val()) ? "" : '^' + $("#equipmentCodeDropdownSearch").val().join("$|^") + '$';
                    item["iboType"]=($("#iboTypeDropdownSearch").val()===undefined||!$("#iboTypeDropdownSearch").val())?"":$("#iboTypeDropdownSearch").val();
                    item["businessSegment"] = $rootScope.businessSegment;
                    item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                    item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
                    jsonData.push(item);
                    TopCustomerService.getIBMetricsFilterData(jsonData).then(function(response) {
                        $scope.responseData = response;
                        updateTopCustDatatable(response);
                        resizeAll();
                    });

                    // Raw data parameters
                    $scope.topCRegionIBRawData = [];
                    $scope.topCCountryIBRawData = [];
                    $scope.flgTopCRegionIBRawData = false;
                    $scope.flgTopCCountryIBRawData = false;
                }

                function resizeCharts() {
                    $('#tableDiv').show();
                    $timeout(function(){
                        $timeout(function(){
                            $('#collapse3').height($('#container2').outerHeight() + 50);
                            $('#tableDivision').height($('#IB-by-Top-Cust-Data_wrapper').outerHeight() + 50);
                            $('#collapse3 > #techRegionChart').outerHeight($('#collapse3').height());
                            $('#collapse4').outerHeight($('#collapse4 > #tableDivision').outerHeight() + 20);
                        }, 250);
                    }, 200);
                    resizeAll();
                    loaderOps(false);
                }

                $scope.clearData = function() {
                    loaderOps(true);
                    $('independent-filter').find('.ms-choice > span').html('');
                    $('independent-filter').find('input[type="checkbox"]').attr('checked', false);
                    $('independent-filter').find("select").val('');
                    $('#depSiteCustCountrySearch').empty();
                    if (!defaultData['indep_filters'])
                        TopCustomerService.getIBMetricsFilterData(TopCustomerService.searchDataService()).then(function(response) {
                            defaultData['indep_filters'] = response;
                            var serviceData = (TopCustomerService.processCustomerData(response.custNameDataBean));
                            var customers = serviceData['customers'],
                                chartData = serviceData['chartData'];
                            $scope.topCustChart(customers, chartData, 'container2');
                            var dataObj = (TopCustomerService.topCustomerTableData(response.custNameDataBean));
                            $('.regError').hide(100);
                            $('.regView').show(100);
                            $scope.safeApply(function() {
                                TopCustomerService.initTable(dataObj['dataArr'], dataObj['columns'], 'IB-by-Top-Cust-Data', dataObj['regionCount']);
                                $scope.custDataExp = true;
                                $scope.custChartExp = true;
                                resizeCharts();
                            });
                        });
                    else {
                        var serviceData = (TopCustomerService.processCustomerData(defaultData['indep_filters'].custNameDataBean));
                        var customers = serviceData['customers'],
                            chartData = serviceData['chartData'];
                        $scope.topCustChart(customers, chartData, 'container2');
                        var dataObj = (TopCustomerService.topCustomerTableData(defaultData['indep_filters'].custNameDataBean));
                        $('.regError').hide(100);
                        $('.regView').show(100);
                        $scope.safeApply(function() {
                            TopCustomerService.initTable(dataObj['dataArr'], dataObj['columns'], 'IB-by-Top-Cust-Data', dataObj['regionCount']);
                            $scope.custDataExp = true;
                            $scope.custChartExp = true;
                            $scope.reg_Error = false;
                            resizeCharts();
                        });
                    }

                    // Raw data parameters
                    $scope.topCRegionIBRawData = [];
                    $scope.topCCountryIBRawData = [];
                    $scope.flgTopCRegionIBRawData = false;
                    $scope.flgTopCCountryIBRawData = false;
                }

                $scope.dep_clearData = function() {
                    $('dependent-filter').find('.ms-choice > span').html('');
                    $('dependent-filter').find('input[type="checkbox"]').attr('checked', false);
                    $('dependent-filter').find("select").val('');
                    $('#depSiteCustCountrySearch').empty();
                    $('#countryTable, #countryChart').hide();
                    _.defer(function() {
                        $('div.countrySelectBtn').hide(100);
                        $('select.dependentFilter[id="depSiteCustCountrySearch"]').prop('disabled', 'true');
                        $('select.dependentFilter[id="depSiteCustCountrySearch"]').siblings().children().addClass('disabled');
                        $('button#placeboMultiSelect').show(100);
                        $('.ctrError').hide(100);
                        $('.ctrView').show(100);
                        $scope.dep_custChartExp = false;
                        $scope.dep_custDataExp = false;
                    });
                    _.forEach(Object.keys($scope.depSearch), function(key) {
                        _.defer(function() {
                            $scope[key] = null;
                        });
                    });
                    $('#depRegionSearch').removeClass("boxShadow");
                    $('.errorIndicator').hide();

                    // Raw data parameters
                    $scope.topCRegionIBRawData = [];
                    $scope.topCCountryIBRawData = [];
                    $scope.flgTopCRegionIBRawData = false;
                    $scope.flgTopCCountryIBRawData = false;
                }

                var checkStatus = setInterval(function() {
                    if (Polymer.dom().node.readyState === 'complete') {
                        Polymer.dom().querySelector('px-tab-pages').selected = 0;
                        Polymer.dom().querySelector('px-tab-set').selected = 0;
                        clearInterval(checkStatus);
                    }
                }, 10);

                $rootScope.getIBMetricsTopCustomerData = function() {
                    TopCustomerService.getIBMetricsFilterData(TopCustomerService.searchDataService()).then(function(response) {
                        defaultData['indep_filters'] = response;
                        var serviceData = (TopCustomerService.processCustomerData(response.custNameDataBean));
                        var customers = serviceData['customers'],
                            chartData = serviceData['chartData'];
                        $scope.topCustChart(customers, chartData, 'container2');
                        var dataObj = (TopCustomerService.topCustomerTableData(response.custNameDataBean));
                        $scope.safeApply(function() {
                            TopCustomerService.initTable(dataObj['dataArr'], dataObj['columns'], 'IB-by-Top-Cust-Data', dataObj['regionCount']);
                            $scope.custDataExp = true;
                            $scope.custChartExp = true;
                            $scope.reg_Error = false;
                            resizeCharts();
                        });
                        $timeout(function(){
                            loaderOps(false);
                        }, 500);
                    });
                }
                
                $timeout(function(){
                    $(document.body).off().on('change','#depRegionSearch',function(){
                        $scope.getCountries();
                    });
                }, 200);

                $scope.exportCharts = function(type) {
                    $scope.exportChart(type);
                };

                $scope.excelDownload = function(id) {
                    TopCustomerService.excelDownload(id);
                };

                $scope.shwIBTopCRawData = function(tableId, methodCall) {
                    var jsonData = [];
                    var item = {};

                    if (methodCall === 'IBTopCRegion') {
                        item["region"] = ($("#regionSearch").val() === undefined || !$("#regionSearch").val()) ? "" : '^' + $("#regionSearch").val().join("$|^") + '$';
                        item["unitStatusDesc"] = ($("#unitStatusSearch").val() === undefined || !$("#unitStatusSearch").val()) ? "" : '^' + $("#unitStatusSearch").val().join("$|^") + '$';
                        item["siteCustCountry"] = ($("#siteCustCountrySearch").val() === undefined || !$("#siteCustCountrySearch").val()) ? "" : '^' + $("#siteCustCountrySearch").val().join("$|^") + '$';
                        item["servRelationDescOng"] = ($("#serviceRelSearch").val() === undefined || !$("#serviceRelSearch").val()) ? "" : '^' + $("#serviceRelSearch").val().join("$|^") + '$';
                        item["technology"] = ($("#techSearch").val() === undefined || !$("#techSearch").val()) ? "" : '^' + $("#techSearch").val().join("$|^") + '$';
                        item["oemLoc"] = ($("#oemLocSearch").val() === undefined || !$("#oemLocSearch").val()) ? "" : '^' + $("#oemLocSearch").val().join("$|^") + '$';
                        item["marketSegmentDesc"] = ($("#marketSearch").val() === undefined || !$("#marketSearch").val()) ? "" : '^' + $("#marketSearch").val().join("$|^") + '$';
                        item["customerName"] = ($("#customerNameSearch").val() === undefined || !$("#customerNameSearch").val()) ? "" : '^' + $("#customerNameSearch").val().join("$|^") + '$';
                        item["siteCustDunsName"] = ($("#siteCustDunsNameSearch").val() === undefined || !$("#siteCustDunsNameSearch").val()) ? "" : '^' + $("#siteCustDunsNameSearch").val().join("$|^") + '$';
                        item["siteCustName"] = ($("#siteCustNameSearch").val() === undefined || !$("#siteCustNameSearch").val()) ? "" : '^' + $("#siteCustNameSearch").val().join("$|^") + '$';
                        item["siteNameAlias"] = ($("#siteNameAliasSearch").val() === undefined || !$("#siteNameAliasSearch").val()) ? "" : '^' + $("#siteNameAliasSearch").val().join("$|^") + '$';
                        item["equipmentCodeFilter"] = ($("#equipmentCodeDropdownSearch").val() === undefined || !$("#equipmentCodeDropdownSearch").val()) ? "" : '^' + $("#equipmentCodeDropdownSearch").val().join("$|^") + '$';
                        item["iboType"]=($("#iboTypeDropdownSearch").val()===undefined||!$("#iboTypeDropdownSearch").val())?"":$("#iboTypeDropdownSearch").val();
                        item["businessSegment"] =$rootScope.businessSegment;
                        item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                        item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
                        jsonData.push(item);

                        if ($scope.topCRegionIBRawData === undefined)
                            $scope.topCRegionIBRawData = [];

                        $("#topCRegIBRawData").attr('style', 'display: block');

                        if ($scope.topCRegionIBRawData === undefined || $scope.topCRegionIBRawData.length === 0) {
                            calIBTopCRawService(jsonData, tableId, methodCall);
                            $scope.flgTopCRegionIBRawData = true;
                        }

                    } else {
                        item["region"] = getSelectedValue('depRegionSearch');
                        item["unitStatusDesc"] = getSelectedValue('unitStatusSearch');
                        item["siteCustCountry"] = getSelectedValue('depSiteCustCountrySearch');
                        item["servRelationDescOng"] = getSelectedValue('serviceRelSearch');
                        item["technology"] = getSelectedValue('techSearch');
                        item["oemLoc"] = getSelectedValue('oemLocSearch');
                        item["marketSegmentDesc"] = getSelectedValue('marketSearch');
                        item["customerName"] = getSelectedValue('customerNameSearch');
                        item["siteCustDunsName"] = getSelectedValue('siteCustDunsNameSearch');
                        item["siteCustName"] = getSelectedValue('siteCustNameSearch');
                        item["siteNameAlias"] = getSelectedValue('siteNameAliasSearch');
                        item["equipmentCodeFilter"] = getSelectedValue('equipmentCodeDropdownSearch');
                        item["iboType"]=getSelectedValue('iboTypeDropdownSearch');
                        item["businessSegment"] =$rootScope.businessSegment;
                        item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                        item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
                        jsonData.push(item);

                        if ((item['region']) === '' || ((item['region']).includes('undefined') === false && ((item['region']) === 'Select Region'))) {
                            $('#depRegionSearch').addClass("boxShadow");
                            $('.errorIndicator').show(100);
                            $("#flgCountryIBCollapse").attr("aria-expanded", "false");
                            $scope.flgTopCCountryIBRawData = false;
                            return false;
                        }
                        if ($scope.topCCountryIBRawData === undefined)
                            $scope.topCCountryIBRawData = [];

                        $("#topCustCountryIBRawData").attr('style', 'display: block');

                        if ($scope.topCCountryIBRawData === undefined || $scope.topCCountryIBRawData.length === 0) {
                            calIBTopCRawService(jsonData, tableId, methodCall);
                            $scope.flgTopCCountryIBRawData = true;
                        }

                    }
                };

                function calIBTopCRawService(jsonData, tableId, methodCall) {
                    loaderOps(true);
                    $http.post("connect/fms/getRawDataIBOPage/" + "ibTechReg", JSON.stringify({
                        "data": jsonData
                    })).then(function(response) {
                        $scope.ibColumnHeaders = response.data.IBColumnHeaders;
                        $scope.rawIBData = response.data.IBTechRawData;

                        if (methodCall === 'IBTopCRegion')
                            $scope.topCRegionIBRawData = $scope.rawIBData;
                        else
                            $scope.topCCountryIBRawData = $scope.rawIBData;

                        if ($.fn.DataTable.isDataTable('#' + tableId)) {
                            $('#' + tableId).dataTable().api().clear().draw();
                            $('#' + tableId).dataTable().api().destroy();
                            $('#' + tableId).empty();
                        }

                        $('#' + tableId).DataTable({
                            data: $scope.rawIBData,
                            "sPaginationType": "simple_numbers",
                            "bFilter": true,
                            "retrieve": true,
                            "scrollX": false,
                            "paging": true,
                            columns: _.sortBy($scope.ibColumnHeaders, 'row_id')
                        });

                        loaderOps(false);
                    });
                }

                $scope.IBTopCRawDataExcelDownload = function(methodCall) {
                    var jsonData = [];
                    var item = {};
                    var fileName = "IB Top Customers Data";

                    if (methodCall === 'IBTopCRegion') {
                        item["region"] = ($("#regionSearch").val() === undefined || !$("#regionSearch").val()) ? "" : '^' + $("#regionSearch").val().join("$|^") + '$';
                        item["unitStatusDesc"] = ($("#unitStatusSearch").val() === undefined || !$("#unitStatusSearch").val()) ? "" : '^' + $("#unitStatusSearch").val().join("$|^") + '$';
                        item["siteCustCountry"] = ($("#siteCustCountrySearch").val() === undefined || !$("#siteCustCountrySearch").val()) ? "" : '^' + $("#siteCustCountrySearch").val().join("$|^") + '$';
                        item["servRelationDescOng"] = ($("#serviceRelSearch").val() === undefined || !$("#serviceRelSearch").val()) ? "" : '^' + $("#serviceRelSearch").val().join("$|^") + '$';
                        item["technology"] = ($("#techSearch").val() === undefined || !$("#techSearch").val()) ? "" : '^' + $("#techSearch").val().join("$|^") + '$';
                        item["oemLoc"] = ($("#oemLocSearch").val() === undefined || !$("#oemLocSearch").val()) ? "" : '^' + $("#oemLocSearch").val().join("$|^") + '$';
                        item["marketSegmentDesc"] = ($("#marketSearch").val() === undefined || !$("#marketSearch").val()) ? "" : '^' + $("#marketSearch").val().join("$|^") + '$';
                        item["customerName"] = ($("#customerNameSearch").val() === undefined || !$("#customerNameSearch").val()) ? "" : '^' + $("#customerNameSearch").val().join("$|^") + '$';
                        item["siteCustDunsName"] = ($("#siteCustDunsNameSearch").val() === undefined || !$("#siteCustDunsNameSearch").val()) ? "" : '^' + $("#siteCustDunsNameSearch").val().join("$|^") + '$';
                        item["siteCustName"] = ($("#siteCustNameSearch").val() === undefined || !$("#siteCustNameSearch").val()) ? "" : '^' + $("#siteCustNameSearch").val().join("$|^") + '$';
                        item["siteNameAlias"] = ($("#siteNameAliasSearch").val() === undefined || !$("#siteNameAliasSearch").val()) ? "" : '^' + $("#siteNameAliasSearch").val().join("$|^") + '$';
                        item["equipmentCodeFilter"] = ($("#equipmentCodeDropdownSearch").val() === undefined || !$("#equipmentCodeDropdownSearch").val()) ? "" : '^' + $("#equipmentCodeDropdownSearch").val().join("$|^") + '$';
                        item["iboType"]=($("#iboTypeDropdownSearch").val()===undefined||!$("#iboTypeDropdownSearch").val())?"":$("#iboTypeDropdownSearch").val();
                        item["businessSegment"] =$rootScope.businessSegment;
                        item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                        item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
                    } else {
                        item["region"] = getSelectedValue('depRegionSearch');
                        item["unitStatusDesc"] = getSelectedValue('unitStatusSearch');
                        item["siteCustCountry"] = getSelectedValue('depSiteCustCountrySearch');
                        item["servRelationDescOng"] = getSelectedValue('serviceRelSearch');
                        item["technology"] = getSelectedValue('techSearch');
                        item["oemLoc"] = getSelectedValue('oemLocSearch');
                        item["marketSegmentDesc"] = getSelectedValue('marketSearch');
                        item["customerName"] = getSelectedValue('customerNameSearch');
                        item["siteCustDunsName"] = getSelectedValue('siteCustDunsNameSearch');
                        item["siteCustName"] = getSelectedValue('siteCustNameSearch');
                        item["siteNameAlias"] = getSelectedValue('siteNameAliasSearch');
                        item["equipmentCodeFilter"] = getSelectedValue('equipmentCodeDropdownSearch');
                        item["iboType"]=getSelectedValue('iboTypeDropdownSearch');
                        item["businessSegment"] =$rootScope.businessSegment;
                        item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                        item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
                    }
                    jsonData.push(item);
                    download("/connect/fms/exportRawDataMetrics/" + "ibTechReg/" + fileName, jsonData, fileName);
                };

                function download(url, data, defaultFileName) {
                    var deferred = $q.defer();
                    $http.post(url, JSON.stringify({
                        "data": data
                    }), {
                        responseType: "arraybuffer"
                    }).success(
                        function(data, status, headers) {
                            var type = headers('Content-Type');
                            var disposition = headers('Content-Disposition');
                            if (disposition) {
                                var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                                if (match[1])
                                    defaultFileName = match[1];
                            }
                            defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                            var blob = new Blob([data], {
                                type: type
                            });
                            saveAs(blob, defaultFileName);
                            deferred.resolve(defaultFileName);
                        }).error(function() {
                        var e;
                        deferred.reject(e);
                    });
                    return deferred.promise;
                };

                $scope.topCustChart = function(custName, regionWithCustCount, id) {
                    $('.backClass').on('click', function() {
                        $state.go('NewMetrics');
                    });
                    Highcharts.setOptions({
                        global: {
                            useUTC: false,

                        },
                        lang: {
                            decimalPoint: '.',
                            thousandsSep: ','
                        }
                    });
                    chart = new Highcharts.Chart({
                        chart: {
                            renderTo: id,
                            type: 'bar',
                            events: {
                                click: function() {
                                    $state.go('topCustomer');
                                }
                            }
                        },
                        title: {
                            text: ''
                        },
                        xAxis: {
                            categories: custName
                        },
                        yAxis: {
                            min: 0,
                            title: {
                                text: 'Count'
                            }
                        },
                        tooltip: {
                            pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:,.0f}</b> ({point.percentage:.2f}%)<br/>',
                            shared: true
                        },
                        legend: {
                            itemStyle: {
                                color: 'black',
                                fontWeight: 'normal',
                                fontSize: '12px',
                            }
                        },
                        plotOptions: {
                            series: {
                                stacking: 'normal',
                                borderWidth: 0,
                                point: {
                                    events: {
                                        click: function() {
                                            $scope.refreshIBMatrics(this.series.name, this.category, id);

                                        }
                                    }
                                }
                            }
                        },
                        credits: {
                            enabled: false
                        },
                        series: regionWithCustCount,
                        responsive: {
                            rules: [{
                                condition: {
                                    maxWidth: 500
                                },
                                chartOptions: {
                                    legend: {
                                        align: 'center',
                                        verticalAlign: 'bottom',
                                        layout: 'horizontal'
                                    },
                                    yAxis: {
                                        labels: {
                                            align: 'left',
                                            x: 0,
                                            y: -5
                                        },
                                        title: {
                                            text: null
                                        }
                                    },
                                    subtitle: {
                                        text: null
                                    },
                                    credits: {
                                        enabled: false
                                    }
                                }
                            }]
                        }
                    });

                };

                $scope.refreshIBMatrics = function(name, category, id) {
                    if (id === 'container2') {
                        $('independent-filter').find('.regionSearch .ms-choice > span').html(name);
                        $('independent-filter').find('.regionSearch input[value="' + name + '"]').attr('checked', true);
                        $('independent-filter').find("#regionSearch").val(name);
                        $('independent-filter').find("#regionSearch").multipleSelect("refresh");

                        $('independent-filter').find('.customerNameSearch .ms-choice > span').html(category);
                        $('independent-filter').find('.customerNameSearch input[value="' + category + '"]').attr('checked', true);
                        $('independent-filter').find("#customerNameSearch").val(category);
                        $('independent-filter').find("#customerNameSearch").multipleSelect("refresh");

                        $rootScope.ibTopCustomerRegionSearchData();
                    } else if (id === 'country_chart') {
                        $('dependent-filter').find('.countrySelectBtn .ms-choice > span').html(name);
                        $('dependent-filter').find('.countrySelectBtn input[value="' + name + '"]').attr('checked', true);
                        $('dependent-filter').find("#depSiteCustCountrySearch").val(name);
                        $('dependent-filter').find("#depSiteCustCountrySearch").multipleSelect("refresh");

                        $('dependent-filter').find('.customerNameSearch .ms-choice > span').html(category);
                        $('dependent-filter').find('.customerNameSearch input[value="' + category + '"]').attr('checked', true);
                        $('dependent-filter').find("#customerNameSearch").val(category);
                        $('dependent-filter').find("#customerNameSearch").multipleSelect("refresh");

                        $rootScope.dep_ibTopCustomerCountrySearchData();
                    }
                };
                $scope.exportChart = function(type) {
                    if (type === 'JPEG') {
                        chart.exportChart({
                            type: 'image/jpeg',
                            filename: 'Top-Customer'
                        }, {
                            subtitle: {
                                text: ''
                            }
                        });
                    }
                    if (type === 'XLS') {
                        chart.exportChart({
                            type: 'application/vnd.ms-excel',
                            filename: 'Top-Customer'
                        }, {
                            subtitle: {
                                text: ''
                            }
                        });
                    }
                };
            }
        ]);
    });