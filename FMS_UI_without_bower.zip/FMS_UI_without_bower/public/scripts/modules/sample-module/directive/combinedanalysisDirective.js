define(['angular', '../sample-module','multiselectdrpdwn'], function(angular, sampleModule,multiselectdrpdwn) {
	'use strict';
	sampleModule.directive('combinedanalysisSearch', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/combinedAnalysis/combinedanalysisSearch.html',
			controller: 'DrilldownPageCtrl'
		};
	}]);
	sampleModule.directive('regionLevel', [ function() {
		return { 
			restrict: 'E',
			templateUrl: 'views/directive-html/combinedAnalysis/combinedAnalysisDrilldown.html'
		};
	}]);
	sampleModule.directive('combinedanalysisIndependentFilter', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/combinedAnalysis/combinedAnalysisFilterDirective.html'
		};
	}]);
	return sampleModule;
});
