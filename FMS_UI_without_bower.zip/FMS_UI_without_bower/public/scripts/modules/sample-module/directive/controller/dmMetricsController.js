
define(['angular','../../sample-module','jquery'], function (angular,controllers,jquery) 
 {
    'use strict';
    controllers.controller('dmMetricsController', ['CreateHighChartService','$scope','$rootScope','DMMetricsService','NewMetricTechService','CustomerChartService','DMChartService','DMCustomerService','$state','$timeout',
	function (CreateHighChartService,$scope,$rootScope,DMMetricsService,NewMetricTechService,CustomerChartService,DMChartService,DMCustomerService,$state,$timeout){
		$('dm-metrics').find('#dm_technoRegion').click(function(){
			$state.go('dm/technoRegion');
		});
		$('dm-metrics').find('#dm_topCustomerChart1').click(function(){
			$state.go('dm/topCustomer');
		});
        
        $timeout(function() {
            if (!$rootScope.accountManager && !$rootScope.marketIndustry) {
                $rootScope.dmMetricsSearchData();
            }
        }, 5000);
        
        $rootScope.dmMetricsSearchData = function() {
            var item = {};
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            
            DMMetricsService.getDmMetricsDashboard(JSON.stringify(item)).then(function(response){
                var dm_techRegionChartData = (DMChartService.updateTechReg(response.technologyDetails));
                $('#dm_technoRegion,#dm_topCustomerChart1').outerHeight($('.iboChart').height());
                CreateHighChartService.createColumnChart(dm_techRegionChartData['technology'],dm_techRegionChartData['regionWithCount'],'dm_technoRegion',dm_techRegionChartData['colorCode'],'dm/technoRegion');
                var dm_totalcountNum=(dm_techRegionChartData['totalcount']).toFixed(0);
                $scope.dm_totalcount=numberWithCommas(dm_totalcountNum);
                var dmCustData=(DMCustomerService.getCustomerData(response.topCustomer));
                var dm_totalCustomerCountNum = (dmCustData['totalCustomerCount']).toFixed(0);
                $scope.dm_totalCustomerCount =numberWithCommas(dm_totalCustomerCountNum);
                CreateHighChartService.createChart(dmCustData['customers'],dmCustData['chartData'],'dm_topCustomerChart1','dm/topCustomer');
            });   
        }
   }]);
});