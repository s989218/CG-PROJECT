
define(['angular','../../sample-module','jquery'], function (angular,controllers,jquery) 
 {
    'use strict';
    controllers.controller('DrilldownPageCtrl', ['$scope','$state','$rootScope',
	function ($scope, $state,$rootScope){
	$scope.safeApply = function(fn){
		$rootScope.safeApply(fn);
	};
		$scope.typeRequest = ($state.params.typeRequest);
		jQuery.fn.center = function() {
				this.css({top: ($(window).outerHeight()) / 2,left: ($(window).outerWidth()) / 2});
				return this;
    		};
		$(".loading").center();
       }]);
});




