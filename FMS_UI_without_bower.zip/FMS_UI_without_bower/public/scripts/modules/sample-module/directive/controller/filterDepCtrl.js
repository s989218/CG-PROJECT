
define(['angular','../../sample-module','jquery'], function (angular,controllers,jquery) 
 {
    'use strict';
    controllers.controller('DependentFilterCtrl', ['$scope',function (ngScope){
       }]);
});




