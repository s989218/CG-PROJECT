define(['angular', '../../../sample-module', 'jquery', 'multiselectdrpdwn', 'jqueryMultiSelect'], function(angular, controllers, jquery, multiselectdrpdwn, jqueryMultiSelect) {
    'use strict';
    controllers.controller('BObyBusinessController', ['$scope', '$timeout', '$state', '$rootScope', 'IPMService',
        function($scope, $timeout, $state, $rootScope, IPMService) {
            
            var $window     = $(window);
            var windowsize  = $window.width();
            var responsive;
            if (windowsize > 767) {
                responsive = false;
            } else {
                responsive = true;
            }
            
            $scope.drawBOBusiness = function() {
                
                $scope.stackedTempBusinessLabels = _.findWhere($scope.BOBusinessData.Table, {
                    HEADER: "CE"
                });
                
                var tempStackBusinessObject = [];
                _.each($scope.BOBusinessData.TableHeaders, function(item) {
                    tempStackBusinessObject.push($scope.stackedTempBusinessLabels[item]);
                });

                $scope.BOBusinessCategories = $scope.BOBusinessData.TableHeaders;
                var chart;
                $(document).ready(function() {
                    chart = new Highcharts.Chart({
                            chart: {
                                renderTo: 'BObyBusinessChart',
                                type: 'column',
                                width: '900'
                            },

                            title: {

                                text: 'Walk by Business'

                            },
                             credits: {
                                enabled: false
                            },

                            xAxis: {

                                categories: $scope.BOBusinessCategories


                            },

                            yAxis: {
                                gridLineWidth: 0,

                                min: 0,

                                title: {

                                    text: 'Total'

                                },


                                stackLabels: {
                                    qTotals: tempStackBusinessObject,
                                    enabled: true,
                                    style: {
                                        fontWeight: 'bold'
                                    },
                                    formatter: function() {
                                        return this.options.qTotals[this.x];
                                    }
                                }

                            },

                            legend: {

                            },

                            tooltip: {

                                formatter: function() {

                                    return '<b>' + this.x + '</b><br/>' +

                                        this.series.name + ': ' + this.y + '<br/>' +

                                        'Total: ' + this.point.stackTotal;

                                }

                            },

                            plotOptions: {

                                column: {

                                    stacking: 'normal',
                                    shadow: false,

                                    dataLabels: {

                                        enabled: false,

                                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'

                                    }

                                }

                            },
                            series: _.sortBy($scope.BOBusinessData.Chart, 'id'),
                        
                            responsive: {
                                rules: [{
                                    condition: {
                                        maxWidth: 500
                                    },
                                    chartOptions: {
                                        legend: {
                                            align: 'center',
                                            verticalAlign: 'bottom',
                                            layout: 'horizontal'
                                        },
                                        yAxis: {
                                            labels: {
                                                align: 'left',
                                                x: 0,
                                                y: -5
                                            },
                                            title: {
                                                text: null
                                            }
                                        },
                                        subtitle: {
                                            text: null
                                        },
                                        credits: {
                                            enabled: false
                                        }
                                    }
                                }]
                            }
                        }
                    );
                    
                    $.each(chart.series[5].data, function(i, point) {
                        point.graphic.attr({
                            opacity: 0,
                            'stroke-width': 0
                        });
                    });

                    setTimeout(function() {
                        $rootScope.safeApply(function() {
                            $('#BObyBusinessChart').css("width", "80%");
                            $('#BObyBusinessChart').css("margin", "0 auto");
                        });
                    }, 1000);
                });

                $("#BObyBusinessTable").DataTable({
                    rowReorder: {
                        selector: 'td:nth-child(2)'
                    },
                    responsive: responsive,
                    data: $scope.BOBusinessData.Table,
                    "bInfo": false,
                    "bPaginate": false,
                    "bFilter": false,
                    "retrieve": true,
                    "order": [],
                    "aoColumnDefs": [{
                        "sClass": "header_class",
                        "aTargets": [0]
                    }],
                    "columns": [{
                        data: "HEADER",
                        title: "&nbsp"
                    }, {
                        data: "TX",
                        title: "TX"
                    }, {
                        data: "CS",
                        title: "CS"
                    }, {
                        data: "INST",
                        title: "INST"
                    }, {
                        data: "SC",
                        title: "SC"
                    }, {
                        data: "TOT",
                        title: "TOT"
                    }, {
                        data: "GAP",
                        title: "GAP"
                    }, {
                        data: "OP",
                        title: "OP"
                    }]
                });

                $scope.exportChartBObyBusiness = function() {
                    chart.exportChart({
                        type: 'image/jpeg',
                        filename: 'Walk By Business'
                    }, {
                        subtitle: {
                            text: ''
                        }
                    });
                };

                $scope.excelDownloadBObyBusiness = function() {
                    var tableToExcel = (function() {
                        var uri = 'data:application/vnd.ms-excel;base64,',
                            template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
                            base64 = function(s) {
                                return window.btoa(unescape(encodeURIComponent(s)))
                            },
                            format = function(s, c) {
                                return s.replace(/{(\w+)}/g, function(m, p) {
                                    return c[p];
                                })
                            }
                        return function(table) {
                            if (!table.nodeType)
                                table = document.getElementById('BObyBusinessTable');
                            var excelContent = '';


                            var header = "<tr><td colspan='8' style='text-align:center'>" +
                                "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center'>Fleet Mining System</span>" +
                                "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";

                            var columns = $scope.BOBusinessData.TableHeaders;
                            excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: ' + (new Date()).toLocaleString() + '</td></tr>';
                            var getDataFromDT = $('#BObyBusinessTable').dataTable().api().rows({
                                filter: "applied"
                            }).data().toArray();
                            var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
                            var tdNumber = "<td style='mso-number-format:0'>";

                            excelContent = excelContent + '<tr> <td colspan="7"> IPM Business Overview by Business</td> </tr>';
                            excelContent = excelContent + '<tr>';
                            excelContent = excelContent + th + '</th>';
                            _.forEach(columns, function(column) {
                                excelContent = excelContent + th + column + '</th>';
                            });
                            excelContent = excelContent + '</tr>';


                            _.forEach(getDataFromDT, function(row) {

                                excelContent = excelContent + '<tr>';
                                _.forEach(row, function(rowData) {
                                    if ((/^[0-9]{0,}$/).test(rowData))
                                        excelContent = excelContent + tdNumber + rowData + '</td>';
                                    else
                                        excelContent = excelContent + '<td>' + rowData + '</td>';
                                });
                                excelContent = excelContent + '</tr>';
                            });

                            var ctx = {
                                worksheet: 'IPMParts',
                                table: excelContent
                            };
                            document.getElementById('excelAnchorBOBB').href = (uri + base64(format(template, ctx)));
                            document.getElementById('excelAnchorBOBB').download = 'BObyBusiness_Report.xls';
                        }
                    })();
                    tableToExcel('BObyBusinessTable');
                };
                
                $timeout(function() {
                    $(window).trigger('resize');
                    $rootScope.safeApply(function() {
                        $('#BObyBusinessTable tbody tr:eq(3) td:eq(0)').addClass("RISK");
                        $('#BObyBusinessTable tbody tr:eq(4) td:eq(0)').addClass("OPP");
                        $('#BObyBusinessTable tbody tr:eq(2)').addClass("VPE");
                        $('#BObyBusinessTable tbody tr:eq(6)').addClass("VOP");
                        $('#BObyBusinessTable tbody tr:eq(0)').addClass("CE");
                    });
                    $scope.iPMLoader = false;

                }, 200);

                $scope.iPMLoader = false;
            };
        }
    ]);
});