define(['angular','../../../sample-module','jquery','multiselectdrpdwn','jqueryMultiSelect'], function (angular,controllers,jquery,multiselectdrpdwn,jqueryMultiSelect) 
 {
    'use strict';
    controllers.controller('BObyRegionController', ['$scope','$timeout','$state','$rootScope','IPMService',
	function ($scope,$timeout,$state,$rootScope,IPMService){
$scope.drawBORegion  = function (){
    
    var arrBORegionDataTableHeaders  = [];
    arrBORegionDataTableHeaders.push({data: "HEADER", title:"&nbsp"});
    _.each($scope.BORegionData.TableHeaders, function(item){
        arrBORegionDataTableHeaders.push({data: item, title:item});
    });
    $scope.arrBORegionDataTableHeaders = arrBORegionDataTableHeaders;
    
 $scope.stackedTempRegionLabels=  _.findWhere($scope.BORegionData.Table, {HEADER: "CE"});
    var tempStackRegionObject = [];
_.each($scope.BORegionData.TableHeaders, function(item){
    tempStackRegionObject.push($scope.stackedTempRegionLabels[item]);
});
    $scope.BORegionCategories = $scope.BORegionData.TableHeaders;
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'BObyRegionChart',
                type: 'column',
                width:'1000'
            },
            title: {
                text: 'Walk by Region'
            },
                 credits: {
                  enabled: false
              },
            xAxis: {
                categories: $scope.BORegionCategories
            },

            yAxis: {
                
                  gridLineWidth: 0,

                min: 0,

                title: {

                    text: 'Total'

                },

         stackLabels: {
                            qTotals: tempStackRegionObject,
                            enabled: true,
                            style: {
                                fontWeight: 'bold'
                            },
                            formatter: function() {
                                return this.options.qTotals[this.x];
                            }
                        }
            },

            legend: {

            },

            tooltip: {

                formatter: function() {
                    return '<b>'+ this.x +'</b><br/>'+
                        this.series.name +': '+ this.y +'<br/>'+
                        'Total: '+ this.point.stackTotal;
                }

            },

            plotOptions: {

                column: {

                    stacking: 'normal',
                    shadow: false,

                    dataLabels: {

                        enabled: false,

                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
                    }
                }
            },
           series: _.sortBy($scope.BORegionData.Chart,'id')
        
        });
      $.each(chart.series[9].data, function(i, point) {
        point.graphic.attr({opacity: 0, 'stroke-width': 0});
      });
    setTimeout(function (){
       $rootScope.safeApply (function (){
       });  
        },1000);
    });
    
    
            $("#BObyRegionTable").DataTable({ 
    		data:$scope.BORegionData.Table,
		    "bInfo" : false,
            "bPaginate": false, 
            "bFilter":false,
			"retrieve": true,
             "order": [],
             "aoColumnDefs": [
                              { "sClass": "header_class", "aTargets": [ 0 ] }
                            ],
            "columns": $scope.arrBORegionDataTableHeaders
                
  			 /*"columns": [{ data:"HEADER", title:"&nbsp"},
			             { data:"APANZ", title:"APANZ"},
			             { data:"CHINA",title:"CHINA"},
			             { data:"EUROPE",title:"EUROPE" },
			             { data:"INDIA", title:"INDIA"},
			             { data:"LATAM",title:"LATAM"},
			             { data:"MENAT",title:"MENAT"},
			             { data:"NAM",title:"NAM"},
                         { data:"RCIS", title:"RCIS"},
			             { data:"SSA", title:"SSA"},
			             { data:"SC",title:"SC"},
			             { data:"HQ",title:"HQ" },
			             { data:"RISK", title:"RISK"},
			             { data:"OPP",title:"OPP"},
			             { data:"TOT",title:"TOT"},
			             { data:"GAP",title:"GAP"},
			             { data:"OP",title:"OP"}]*/
			   });




    $scope.exportChartBObyRegion = function (){
                     chart.exportChart({type: 'image/jpeg', filename: 'Walk By Region'}, {subtitle: {text:''}});
                    };
    
    
         $scope.excelDownloadBObyRegion= function(){
                      var tableToExcel = (function() {
                      var uri = 'data:application/vnd.ms-excel;base64,'
                      , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
                                  , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
                                  , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
                           return function(table) {
                           if (!table.nodeType)
                                  table = document.getElementById('BObyRegionTable');
                           var excelContent = '';
                               
                             
                           var header = "<tr><td colspan='8' style='text-align:center'>" +
                                         "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center'>Fleet Mining System</span>"+
                                         "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
                        
                           var columns = $scope.BORegionData.TableHeaders;
                           excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
                           var getDataFromDT  = $('#BObyRegionTable').dataTable().api().rows( { filter: "applied" } ).data().toArray();
                           var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
                           var tdNumber = "<td style='mso-number-format:0'>";
                          
                                  excelContent = excelContent + '<tr> <td colspan="7"> IPM Business Overview by Region</td> </tr>';
                               
                              
                               
                               excelContent =excelContent + '<tr>';
                               excelContent = excelContent + th + '</th>';
                           _.forEach(columns, function(column){
                                         excelContent = excelContent + th + column + '</th>';
                           });
                           excelContent = excelContent + '</tr>';
                         
                               
                               _.forEach(getDataFromDT, function(row){
                                 
                                  excelContent =excelContent + '<tr>';
                                  _.forEach(row, function(rowData){
                                         if((/^[0-9]{0,}$/).test(rowData))
                                                excelContent = excelContent + tdNumber + rowData + '</td>';
                                         else
                                                excelContent = excelContent + '<td>' + rowData + '</td>';
                                  });
                                  excelContent =excelContent + '</tr>';
                           });
                              
                              
                              
                           var ctx = {worksheet: 'IPMParts' , table: excelContent};
                           document.getElementById('excelAnchorBOBR').href = (uri + base64(format(template, ctx)));
                           document.getElementById('excelAnchorBOBR').download = 'BObyRegion_Report.xls';
                     }
                     })();
                     tableToExcel('BObyRegionTable');
                    };
    
	$timeout(function (){
            $(window).trigger('resize');
               $rootScope.safeApply(function(){
            $('#BObyRegionTable thead tr th').css("min-width", "5px !important");
            $('#BObyRegionTable thead tr th').css("width", "5px !important");
            $('#BObyRegionTable thead tr th').css("font-size", "11px");
            $('#BObyRegionTable tbody tr:eq(4)').addClass("CE");
            $('#BObyRegionTable tbody tr:eq(6)').addClass("VPE");
            $('#BObyRegionTable tbody tr:eq(8)').addClass("VOP");
                });
     $scope.iPMLoader =false;      
    
    },500);

};  

       }]);
});

