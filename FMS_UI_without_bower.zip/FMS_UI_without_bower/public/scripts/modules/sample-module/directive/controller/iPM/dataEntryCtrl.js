define(['angular','../../../sample-module','jquery','multiselectdrpdwn','jqueryMultiSelect'], function (angular,controllers,jquery,multiselectdrpdwn,jqueryMultiSelect) 
 {
    'use strict';
    controllers.controller('dataEntryController', ['$scope','$timeout','$state','$rootScope','$parse','IPMService',
	function ($scope,$timeout,$state,$rootScope,$parse,IPMService){
   	
        
        $scope.updateDESuccess = false;
        $scope.updateDEFailure = false;

        $scope.sendData  = function () {
            var headers1 = Object.keys($rootScope.IPMDataEntryData);
            
            for(var i=0;i<headers1.length;i++) {
                $rootScope.IPMDataEntryData[headers1[i]].week = $rootScope.selectionFilterData.week;
  		    }
            
            IPMService.updateIPMDataEntryData(JSON.stringify($rootScope.IPMDataEntryData)).then(function(response) {
                $rootScope.safeApply(function() {
                    if (response==="UPDATED" || response==="SUCCESS") {
                        $scope.updateDESuccess=true;
                        $scope.updateDEFailure=false;   
                    } else if (response==="FAILURE") {
                        $scope.updateDESuccess=false;
                        $scope.updateDEFailure=true;
                    }

                    $timeout(function () {
                        $scope.updateDESuccess=false;
                        $scope.updateDEFailure=false;
                    },3000);  
                });
           });
        };

        $scope.sumB5E5  = function (data1) {
            
            if (!$rootScope.IPMDataEntryData['TX'].risk_val) {
        		$rootScope.IPMDataEntryData['TX'].risk_val = 0;
        	}
            
        	if (!$rootScope.IPMDataEntryData['CS'].risk_val) {
        		$rootScope.IPMDataEntryData['CS'].risk_val = 0;
            }
            
        	if (!$rootScope.IPMDataEntryData['INST'].risk_val) {
        		$rootScope.IPMDataEntryData['INST'].risk_val = 0;
            }
            
            if (!$rootScope.IPMDataEntryData['SC'].risk_val) {
        		$rootScope.IPMDataEntryData['SC'].risk_val = 0;
            }
            
            var sum =  parseFloat($rootScope.IPMDataEntryData['TX'].risk_val) + parseFloat($rootScope.IPMDataEntryData['CS'].risk_val) + parseFloat($rootScope.IPMDataEntryData['INST'].risk_val) +  parseFloat($rootScope.IPMDataEntryData['SC'].risk_val);
            
        	$parse(data1+'.risk_val').assign($rootScope.IPMDataEntryData, sum);
        };

        $scope.sumB6E6  = function (data1) {
        
            if (!$rootScope.IPMDataEntryData['TX'].opp_val) {
        		$rootScope.IPMDataEntryData['TX'].opp_val = 0;
        	}
            
        	if (!$rootScope.IPMDataEntryData['CS'].opp_val) {
        		$rootScope.IPMDataEntryData['CS'].opp_val = 0;
            }
            
        	if (!$rootScope.IPMDataEntryData['INST'].opp_val) {
        		$rootScope.IPMDataEntryData['INST'].opp_val = 0;
            }
            
            if (!$rootScope.IPMDataEntryData['SC'].opp_val) {
        		$rootScope.IPMDataEntryData['SC'].opp_val = 0;
            }
            
            var sum =  parseFloat($rootScope.IPMDataEntryData['TX'].opp_val) + parseFloat($rootScope.IPMDataEntryData['CS'].opp_val) + parseFloat($rootScope.IPMDataEntryData['INST'].opp_val) +  parseFloat($rootScope.IPMDataEntryData['SC'].opp_val);

            $parse(data1+'.opp_val').assign($rootScope.IPMDataEntryData, sum);
        }; 
        
        
        $scope.sum789 = function (data1) {

            if (!$rootScope.IPMDataEntryData[data1].tx_ce_val) {
        		$rootScope.IPMDataEntryData[data1].tx_ce_val = 0;
        	}
            
        	if (!$rootScope.IPMDataEntryData[data1].cs_ce_val) {
        		$rootScope.IPMDataEntryData[data1].cs_ce_val = 0;
            }
            
        	if (!$rootScope.IPMDataEntryData[data1].ins_ce_val) {
        		$rootScope.IPMDataEntryData[data1].ins_ce_val = 0;
            }

            var sum =  parseFloat($rootScope.IPMDataEntryData[data1].tx_ce_val) + parseFloat($rootScope.IPMDataEntryData[data1].cs_ce_val) + parseFloat($rootScope.IPMDataEntryData[data1].ins_ce_val);
            
        	$parse(data1+'.ce_val').assign($rootScope.IPMDataEntryData, sum);
        };
        
        $scope.sum101112 = function (data1) {
            
          	if (!$rootScope.IPMDataEntryData[data1].tx_op_val) {
          		$rootScope.IPMDataEntryData[data1].tx_op_val = 0;
        	}
            
        	if (!$rootScope.IPMDataEntryData[data1].cs_op_val) {
        		$rootScope.IPMDataEntryData[data1].cs_op_val = 0;
            }
            
        	if (!$rootScope.IPMDataEntryData[data1].ins_op_val) {
        		$rootScope.IPMDataEntryData[data1].ins_op_val = 0;
            }
        	
        	var sum = parseFloat($rootScope.IPMDataEntryData[data1].tx_op_val) + parseFloat($rootScope.IPMDataEntryData[data1].cs_op_val) + parseFloat($rootScope.IPMDataEntryData[data1].ins_op_val);
            
        	$parse(data1+'.op_val').assign($rootScope.IPMDataEntryData, sum);
        };
        
        $scope.dataEntryExcelDownload=function(id, type) {
            
            var headers = "";
            
            if(type === 'DTS') {
                headers = ["","TX","CS","INST","SC","HQ","STRETCH","OTHER GE LE","CT","COQ","PARTS","FIELD SERVICES","REPAIRS","APANZ","CHINA","EUROPE","INDIA","LATAM","MENAT","NAM","RCIS","SSA","RISK PE","OPPS PE","BACKLOG","EARLY","CONVERTIBLE","CONVTOGO","CE R/O","PE R/O","PE REGION GAP","OP REGION GAP"];
            }
            
            if(type === 'TMS') {
                headers = ["","TX","CS","INST","SC","HQ","STRETCH","OTHER GE LE","CT","COQ","PARTS","FIELD SERVICES","REPAIRS","APAC","AMERICAS","EUROPE","ATM","LATAM","MENAT","NORTH_AMERICA","MET","SSA","RISK PE","OPPS PE","BACKLOG","EARLY","CONVERTIBLE","CONVTOGO","CE R/O","PE R/O","PE REGION GAP","OP REGION GAP"];
            }
            
        	var columns = [];
		 
            _.forEach(headers, function(data){
                columns.push(data);
            });
            
		  var tableToExcel = (function() {
            var ctx,subHeader,columnHeader = ["OP","CE (No OPPs)","PE","RISK","OPP","TX CE","CS CE","INS CE","TX PE","CS PE","INS PE","TX OP","CS OP","INS OP","TX_PE_Backlog","CS_PE_Backlog","INS_PE_Backlog","CWD","Actuals","Unconfirmed"];
            
            var headerNames = "";
			 
            var uri = 'data:application/vnd.ms-excel;base64,', template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>', base64 = function(s) { 
                return window.btoa(unescape(encodeURIComponent(s))) 
            }, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
                return function(table) {
                    if (!table.nodeType) 
                        table = document.getElementById(id);
                  
                    var excelContent = '';
                    var header = "<tr><td colspan='8' style='text-align:center'>" +
                                "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
                                "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
                    
                  subHeader="<tr><td colspan='8' style='text-align:center'>" + "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>IPM Data Entry " + type + " Table</span>" + "</td></tr>";
                    
                  excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
                    
                  excelContent = excelContent + subHeader;

                  if(type === 'DTS') {
                    headerNames = ["TX", "CS", "INST", "SC", "HQ", "STRETCH", "OTHER_GE_LE", "CT", "COQ", "PARTS", "FIELD_SERVICES", "REPAIRS", "APANZ", "CHINA", "EUROPE", "INDIA", "LATIN_AMERICA", "MENAT", "NORTH_AMERICA", "RUSSIA_CIS", "SUB_SAHARAN_AFRICA", "RISK_PE", "OPPS_PE", "BACKLOG", "EARLY", "CONVERTIBLE", "CONVTOGO", "CE_R_BY_O", "PE_R_BY_O", "PE_REGION_GAP", "OP_REGION_GAP"];
                  }
                      
                  if(type === 'TMS') {
                    headerNames = ["TX", "CS", "INST", "SC", "HQ", "STRETCH", "OTHER_GE_LE", "CT", "COQ", "PARTS", "FIELD_SERVICES", "REPAIRS", "APAC", "AMERICAS", "EUROPE", "ATM", "LATAM", "MENAT", "NORTH_AMERICA", "MET", "SSA", "RISK_PE", "OPPS_PE", "BACKLOG", "EARLY", "CONVERTIBLE", "CONVTOGO", "CE_R_BY_O", "PE_R_BY_O", "PE_REGION_GAP", "OP_REGION_GAP"];
                  }
                      
  		        var dataKeys   = Object.keys(($rootScope.IPMDataEntryData)[headerNames[0]]);
  		        var dataValues = {};
                    
  		        _.forEach(dataKeys, function(dataKey){
  		        	dataValues[dataKey] = [];
  		        });
                    
  		        _.forEach(dataKeys, function(dataKey){
  		        	_.forEach(headerNames, function(countryName){
  		        		(dataValues[dataKey])[headerNames.indexOf(countryName)] = ($rootScope.IPMDataEntryData[countryName])[dataKey]; 
  		        		
  		        	});
  		        });
                    
                  var getDataFromDT  = dataValues;
                  var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
                  var tdNumber = "<td style='mso-number-format:0'>";
                    
                  excelContent =excelContent + '<tr>';
                  _.forEach(columns, function(column){
                        excelContent = excelContent + th + column + '</th>';
                  });
                  excelContent = excelContent + '</tr>';
                    
                  var count=0;
                  var temp;
                  _.each(getDataFromDT, function(row){
                	  temp = columnHeader[count]?columnHeader[count]:"";
                      excelContent =excelContent + '<tr>'+'<td>'+ temp;
                      
                      _.forEach(row, function(rowData) {
                         if(rowData === 'DTS' || rowData === 'TMS') {
                             excelContent = excelContent + "";
                         } else if((/^[0-9]{0,}$/).test(rowData)) {
                             excelContent = excelContent + tdNumber + rowData + '</td>';
                         } else {
                             excelContent = excelContent + '<td>' + rowData + '</td>';
                         }
                     });
                     excelContent =excelContent + '</tr>';
                    count++;
                 });
                 excelContent =excelContent + '<tr>';
                 excelContent =excelContent + '</tr>';
                    
                 ctx = {worksheet:'IPM Data Entry '+ type +' Table' , table: excelContent};
                 document.getElementById('excelAnchor'+type).href = (uri + base64(format(template, ctx)));
                 document.getElementById('excelAnchor'+type).download = 'IPM-Data-Entry-'+type+'-Table.xls';
            }
          })();
          tableToExcel(id, type);
          return null;
        }
    }]);
 });