
define(['angular','../../../sample-module','openlayer','jquery','datatablesNet'], function (angular,controllers,ol,jquery,datatablesNet,exportToExcel,webAnimation) 
 {
    'use strict';
    controllers.controller('keyDealsController', ['$scope','$http', '$location','$state','$rootScope','$timeout', 'InstalledbaseService',
                                       function ($scope, $http, $location, $state,$rootScope,$timeout,InstalledbaseService) 
                {

            
                  
          $scope.keyDealsTableDraw = function (){
	    var redCircle = '<img src="../images/red.png">';
    	var yellowCircle = '<img src="../images/yellow.png">';
    	var greenCircle = '<img src="../images/green.png">';
        var good = '<img src="../images/good.png">';
    	var flat = '<img src="../images/flat.png">';
    	var bad = '<img src="../images/critical.png">';
		var data;
        var test=[];
        var temp={};
        var flag;
          $scope.temp='';    
          $("#KeyDealsTable").DataTable({ 
                data:$rootScope.IPMKeyDealsData,
			"retrieve": true,
			 "order": [1, "desc"],
  			 "columns": [
			             { data:"cm_sum", title:"CM Total","render": function (data, type, full, meta) {
			          
                             
                             if(_.where(test, {cm_sum: data, region: full.final_region}).length>0)
                                 {   return "";                                          
                                 }
                             else{
                                temp.cm_sum=data;                         
                                temp.region=full.final_region;
                                test.push(temp);
                                temp={};
			            		return data;
                             }
                           
                             
			             }},
			             { data:"final_region",title:"Region"},
			             { data:"concatenate",title:"Concatenate" },
			             { data:"p_and_l", title:"P&L"},
			             { data:"product",title:"Product"},
			             { data:"enduser_cust_name",title:"End User Customer Name"},
			             { data:"p_cm_dollar_by_1000",title:"CM$/1000"},			             
			             {data:"p_status",title:"Status", "render": function (data, type, full, meta) {
                         
                             if (data){
                             if(data.toUpperCase().trim()==='LOW')
			            		 {
			            		 return greenCircle;
			            		 
			            		 }
                             else if(data.toUpperCase().trim()==='MEDIUM')
		            		 {
			            		 return yellowCircle;
		            		 
		            		 }
			            	 else if(data.toUpperCase().trim()==='HIGH')
		            		 {
			            		 return redCircle;
		            		 
		            		 }}
                             else{
                                return data;
                             }
			            	}},
                         {data:"p_rev_rev_needs",title:"Rev/Rec Needs"},
			             {data:"p_note",title:"Note"},
			             {data:"p_due_date",title:"Due Date"},
			             {data:"p_trend",title:"Trend", "render": function (data, type, full, meta) {
			            	 if (data){
                             if(data.toUpperCase().trim()==='GOOD')
			            		 {
			            		 return good;
			            		 
			            		 }
			            	 else if(data.toUpperCase().trim()==='FLAT')
		            		 {
			            		 return flat;
		            		 
		            		 }
			            	 else if(data.toUpperCase().trim()==='BAD')
		            		 {
			            		 return bad;
		            		 
		            		 }}
                             
                             else{
                                return data;
                             }
                        	}},
                         {data:"p_r_by_o",title:"R/O"}
			             ]
			   });
	   
              
            $scope.showKeyDealsMapView = false;    
            $scope.showKeyDealsMap = function() {
                InstalledbaseService.getLatLongByRegion().then(function(res){
                    $scope.LatLongByRegion =	res;
                    UpdateLatLongByRegion();
                });
            }
            
            // This code is comment out By Sanjay on 25/11/2016
            /*var map;
            var iconFeatures=[],originalRegiondata = [], originalSearchRegiondata, vectorLayer,iconStyle, sitevectorSource, vectorSource;
            function UpdateLatLongByRegion(){
                iconFeatures=[];
                for(var i=0;i< $scope.LatLongByRegion.length;i++)
                {
                    var item= $scope.LatLongByRegion[i];
                    var longitude = item.longitude;                         
                    var latitude = item.latitude;
                    var region = item.ibDataRegion;
                    if ((longitude && latitude) && (Math.abs(longitude)<= 180 && Math.abs(latitude)<= 90))
                    {
                    var iconFeature = new ol.Feature({
                          geometry: new ol.geom.Point(ol.proj.transform([parseFloat(longitude), parseFloat(latitude)], 'EPSG:4326',     
                          'EPSG:3857')),
                          name: region,
                          nameM:'R'
                        });
                        
                        iconStyle = new ol.style.Style({
                          image: new ol.style.Icon(({
                            anchor: [0.5, 46],
                            anchorXUnits: 'fraction',
                            anchorYUnits: 'pixels',
                            opacity: 0.75,
                            src: 'images/icon_R.png',
                          })),
                          text: new ol.style.Text({
                              text: region,
                              fill: new ol.style.Fill({color: 'black'}),
                              offsetY: 5
                          })
                        });
                        
                        // Vector layer to 
                        iconStyle = new ol.style.Style
                        ({	pointRadius: "${getRadius}", //24,
                            fillColor:"#369",

                            chart:"${values}",
                            chartType: "${getChartype}",
                            chartColor:"${getColor}",
                            chartBackcolor: "${get3d}",
                            chartMax: "${getMax}",
                            chartSuffix: "${getSuffix}",

                            strokeWidth:1,
                            stroke:true,
                            strokeColor:"#fff"
                        },
                        {	context:
                            {	getChartype: function(f) { return chartype; },
                                getRadius: function(f)
                                {	if (chartype==="bar" || !document.getElementById('relative').checked) return 24;
                                    return f.attributes.radius;
                                },
                                getSuffix: function(f)
                                {	return (chartype==="bar" ? "":"%");
                                },
                                getColor: function(f) { return ol.Renderer.colors[document.getElementById('color').value]; },
                                get3d: function(f) { return document.getElementById('set3d').checked ? "#666" : ""; },
                                getMax: function(f) { return document.getElementById('relative').checked ? max : 0; }
                            }
                        });

                        iconFeature.setStyle(iconStyle);
                        iconFeatures.push(iconFeature);
                        originalRegiondata.push(iconFeature);
                }
                }
                var raster =   new ol.layer.Tile({
                source: new ol.source.OSM()
                });

                vectorSource = new ol.source.Vector({
                  features: iconFeatures //add an array of features
                });
                
                vectorLayer = new ol.layer.Vector({
                  source: vectorSource,
                  style: iconStyle
                });
                
                vectorLayer = new ol.layer.Vector ("Markers",
                {	visibility:true,
                    rendererOptions: {yOrdering: false, zIndexing: true},
                    renderers: ["SVGCharts", "VMLCharts"],
                    styleMap: new ol.StyleMap
                    ({	"default": iconStyle,
                        "select": 
                        {	pointRadius: 32,
                            strokeWidth:2,
                            fontSize:12,
                            fontWeight:"bold",
                            fontColor:"#000",
                            zindex:1
                        }
                    })
                });
                
                
                $timeout(function(){
                    if ($scope.showKeyDealsMapView === false) {
                        map = new ol.Map({
                            layers: [raster,vectorLayer],
                            target: 'keyDealsMap',
                            controls: ol.control.defaults({
                              attributionOptions: ({
                                collapsible: true
                              })
                            }),
                            view: new ol.View({
                              center: [0, 0],
                              zoom: 2,
                              minZoom: 2
                            })
                        });
                        $scope.showKeyDealsMapView = true; 
                    }
                }, 100);
                map.on('singleclick', function(evt){
                    displayFeatureInfo(evt.pixel);
                });
            }//end of fun*/
              
              
       
		$timeout(function (){
        
            $(window).trigger('resize');
               $rootScope.safeApply(function(){
            $('#KeyDealsTable thead tr th:eq(2)').css("width", "250px");
            $('#KeyDealsTable thead tr th:eq(5)').css("width", "350px");                   
            $('#KeyDealsTable thead tr th:eq(9)').css("width", "200px");
           });
      
        $scope.iPMLoader =false;    
                    
        
        },200);
                    }
                   
		}]);
});


