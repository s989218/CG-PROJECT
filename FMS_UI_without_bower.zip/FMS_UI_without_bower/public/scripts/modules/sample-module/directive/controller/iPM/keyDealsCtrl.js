
define(['angular','../../../sample-module','openlayer','jquery','datatablesNet'], function (angular,controllers,ol,jquery,datatablesNet,exportToExcel,webAnimation) 
 {
    'use strict';
    controllers.controller('keyDealsController', ['$scope','$http', '$location','$state','$rootScope','$timeout','InstalledbaseService','IPMService', function ($scope, $http, $location, $state,$rootScope,$timeout,InstalledbaseService,IPMService) {
        
        var keyDealsModalUpdate = document.getElementById('keyDealsUpdateDataModal');          
        var keyDealsSpanUpdate  = document.getElementsByClassName("keyDealsUpdateClose")[0];
        
        keyDealsSpanUpdate.onclick = function(event) {
            keyDealsModalUpdate.style.display = "none";
        }
        
        window.onclick = function(event) {
            if (event.target === keyDealsModalUpdate) {
                keyDealsModalUpdate.style.display = "none";
            }
        }
        
        $(function() {
            $("body").delegate("#keydeals_p_new_date", "focusin", function(){
                var localToday = new Date();
                $(this).datepicker({
                    changeMonth: true,
                    changeYear: true,
                    dateFormat: 'mm-dd-yy',
                    localToday: localToday,
                    minDate: localToday,
                    inline: true,
                    dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
                    showOtherMonths: true,
                    showOn: "both",
                    showAnim: "slideDown",
                    duration: 'fast',
                    buttonImage: "images/calendar.png",
                    buttonImageOnly: true
                });
            });
        });
                  
        $scope.keyDealsTableDraw = function () {
            
            $scope.customizedKeyDealsData    = $rootScope.IPMKeyDealsData.keyDealsData;
            $scope.customizedKeyDealsHeaders = $rootScope.IPMKeyDealsData.keyDealsHeaders;
            $scope.getCurrentWeek            = $scope.getWeekNumber();
            $scope.regionDTS = ["APANZ", "China", "Europe", "India", "LatinAmerica", "MENAT", "NorthAmerica", "RussiaCIS", "SubsaharanAfrica"];
            $scope.regionTMS = ["APAC", "ATM", "Europe", "LATAM", "MENAT", "MET", "NorthAmerica", "SSA"];
            
            $scope.arrRegion = _.chain($scope.customizedKeyDealsData).map(function(item) { 
                return item.final_region 
            }).uniq().value();

            $scope.arrRegionKeys = _.chain($scope.customizedKeyDealsData).map(function(item) { 
                return item.final_region.replace(/[^A-Z0-9]/ig, ""); 
            }).uniq().value();
            
            $scope.objKeyDealsData = {};
            
            if ($scope.customizedKeyDealsData.length > 0) {
                
                _.each($scope.arrRegion, function(region) {
                    var arrRegionData = [];
                    var regionKey     = region.replace(/[^A-Z0-9]/ig, "");
                    
                    _.each($scope.customizedKeyDealsData, function(item) {
                        if (item.final_region === region) {
                            arrRegionData.push(item);
                        }
                    });

                    $scope.objKeyDealsData[regionKey] = arrRegionData;
                });

                if($scope.searchPanel.businessSegment === "DTS") {
                    _.each($scope.regionDTS, function(regionKey) {
                        
                        $('.kd'+regionKey+'Filter').slideDown(200);
                        
                        if ( $.inArray( regionKey, $scope.arrRegionKeys ) === -1 ) {
                            $scope['cmSum'+regionKey] = "0.00";
                            $scope.objKeyDealsData[regionKey] = [];
                        } else {
                            if($scope.objKeyDealsData[regionKey][0].p_sum_cm === null) {
                                $scope['cmSum'+regionKey] = "0.00";
                            } else {
                                $scope['cmSum'+regionKey] = $scope.objKeyDealsData[regionKey][0].p_sum_cm;
                            }
                        }
                    });
                } else {
                    _.each($scope.regionTMS, function(regionKey) {
                        
                       $('.kd'+regionKey+'Filter').slideDown(200);
                        
                       if ( $.inArray( regionKey, $scope.arrRegionKeys ) === -1 ) {
                            $scope['cmSum'+regionKey] = "0.00";
                            $scope.objKeyDealsData[regionKey] = [];
                       } else {
                            if($scope.objKeyDealsData[regionKey][0].p_sum_cm === null) {
                                $scope['cmSum'+regionKey] = "0.00";
                            } else {
                                $scope['cmSum'+regionKey] = $scope.objKeyDealsData[regionKey][0].p_sum_cm;
                            }
                       }
                    });
                }
            } else {
                if($scope.searchPanel.businessSegment === "DTS") {
                    _.each($scope.regionDTS, function(regionKey) {
                        $('.kd'+regionKey+'Filter').slideDown(200);
                        $scope['cmSum'+regionKey] = "0.00";
                        $scope.objKeyDealsData[regionKey] = [];
                    });
                } else {
                    _.each($scope.regionTMS, function(regionKey) {
                        $('.kd'+regionKey+'Filter').slideDown(200);
                        $scope['cmSum'+regionKey] = "0.00";
                        $scope.objKeyDealsData[regionKey] = [];
                    });
                }
            }
            
            _.each($scope.objKeyDealsData, function(regionData, regionKey) {
                if ($.fn.DataTable.isDataTable( "#keyDeals"+regionKey+"Table" ) ) {
                    $("#keyDeals"+regionKey+"Table").dataTable().api().clear().draw();
                    $("#keyDeals"+regionKey+"Table").dataTable().api().destroy();
                    $("#keyDeals"+regionKey+"Table").empty(); 
                }
                $scope.keyDealsDataTables(regionKey,regionData);
            });
            
            $timeout(function () {
                $(window).trigger('resize');
                $scope.iPMLoader = false;
            },200);
            
        }
        
        $scope.keyDealsDataTables = function (regionKey, regionData) {
            
            var redCircle    = '<img src="../images/red.png">';
            var yellowCircle = '<img src="../images/yellow.png">';
            var greenCircle  = '<img src="../images/green.png">';
            var good         = '<img src="../images/good.png">';
            var flat         = '<img src="../images/flat.png">';
            var bad          = '<img src="../images/critical.png">';
            var data;
            
            $("#keyDeals"+regionKey+"Table").DataTable({ 
                 data:regionData,
                 "retrieve": true,
                 "order": [],
                 "bPaginate": false,
                 "bFilter": false,
                 "bLengthChange": false,
                 "bInfo": false,
                 "columns": [
                     { data:"concatenate",title:"Concatenate" },
                     { data:"p_and_l", title:"P&L" },
                     { data:"product",title:"Product" },
                     { data:"enduser_cust_name",title:"End User Customer Name" },
                     { data:"p_cm_dollar_by_1000",title:"CM$/1000" },			             
                     { data:"p_status",title:"Status", "render": function (data, type, full, meta) {
                         if (data) {
                            if(data.toUpperCase().trim() === 'LOW') {
                                return greenCircle;
                            } else if(data.toUpperCase().trim() === 'MEDIUM') {
                                return yellowCircle;
                            } else if(data.toUpperCase().trim() === 'HIGH') {
                                return redCircle;
                            }
                         } else {
                             return data;
                         }
                     }},
                     { data:"p_wb_comment",title:"WB Comment" },
                     { data:"p_note",title:"Note" },
                     { data:"p_due_date",title:"Due Date" },
                     { data:"p_trend",title:"Trend", "render": function (data, type, full, meta) {
                         if (data) {
                            if(data.toUpperCase().trim()==='GOOD') {
                                return good;
                            } else if(data.toUpperCase().trim()==='FLAT') {
                                return flat;
                            } else if(data.toUpperCase().trim()==='BAD') {
                                return bad;
                            }
                         } else {
                             return data;
                         }
                     }},
                     { data:"p_r_by_o",title:"R/O" }
                ],
                "initComplete": function(settings, json){ 
                    var info = this.api().page.info();
                    
                    if ( info.recordsTotal > 0 ) {
                        $scope.keyDealsDataTablesUpdate(regionKey, regionData);
                    }
                }
            });
        }
	
        $scope.showKeyDealsMapView = false;    
        $scope.showKeyDealsMap = function() {
            InstalledbaseService.getLatLongByRegion().then(function(res){
                $scope.LatLongByRegion =	res;
                $scope.showKeyDealsMapView = true;
                
                $scope.updateLatLongByRegion();
            });
        }
        
        $scope.updateLatLongByRegion = function() {
            // Layers
            var raster =   new ol.layer.Tile({
                source: new ol.source.OSM()
            });
            
            new ol.layer.Tile({ source: new ol.source.Stamen({ layer: 'watercolor' }) });
		
            // The map
            var map = new ol.Map ({	
                target: 'keyDealsMap',
                view: new ol.View({
                    center: [0, 0],
                    zoom: 2,
                    minZoom: 2
                }),
                layers: [raster]
            });
            
            $scope.getChartStyle();
        
            $scope.getChartOrdering();
                
            var iconFeatures = [], originalRegiondata = [];
            for(var i=0;i< $scope.LatLongByRegion.length;i++)
            {
                var item= $scope.LatLongByRegion[i];
                var longitude = item.longitude;                         
                var latitude = item.latitude;
                
                if ((longitude && latitude) && (Math.abs(longitude)<= 180 && Math.abs(latitude)<= 90))
                {
                    
                    var n, nb=0, data=[];
                    for (var k=0; k<2; k++) 
                    {	n = Math.round(32*Math.random());
                        data.push(n);
                        nb += n;
                    }
                    
                    var iconFeature = new ol.Feature({
                      geometry: new ol.geom.Point(ol.proj.transform([parseFloat(longitude), parseFloat(latitude)], 'EPSG:4326',     
                      'EPSG:3857')),
                      data: data,
                      size: nb
                    });

                    iconFeatures.push(iconFeature);
                    originalRegiondata.push(iconFeature);
                }
            }
            
            var vector = new ol.layer.Vector(
            {	name: 'Vecteur',
                source: new ol.source.Vector({ features: iconFeatures }),
                // y ordering
                renderOrder: ol.ordering.yOrdering(),
                style: function(f) { return getFeatureStyle(f); }
            })

            map.addLayer(vector);
            
            doAnimate(vector);
        }
        
        $scope.getChartStyle = function() {
            
            ol.style.Chart = function(opt_options) 
            {	var options = opt_options || {};
                var strokeWidth = 0;
                if (opt_options.stroke) strokeWidth = opt_options.stroke.getWidth();
                ol.style.RegularShape.call (this,
                    {	radius: options.radius + strokeWidth, 
                        fill: new ol.style.Fill({color: [0,0,0]}),
                        rotation: options.rotation,
                        snapToPixel: options.snapToPixel
                    });
                if (options.scale) this.setScale(options.scale);

                this.stroke_ = options.stroke;
                this.radius_ = options.radius || 20;
                this.donutratio_ = options.donutRatio || 0.5;
                this.type_ = options.type;
                this.offset_ = [options.offsetX ? options.offsetX : 0, options.offsetY ? options.offsetY : 0];
                this.animation_ = (typeof(options.animation) === 'number') ? { animate:true, step:options.animation } : this.animation_ = { animate:false, step:1 };

                this.data_ = options.data;
                if (options.colors instanceof Array)
                {	this.colors_ = options.colors;
                }
                else 
                {	this.colors_ = ol.style.Chart.colors[options.colors];
                    if(!this.colors_) this.colors_ = ol.style.Chart.colors.classic;
                }

                this.renderChart_();
            };
            ol.inherits(ol.style.Chart, ol.style.RegularShape);

            /** Default color thems
            */
            ol.style.Chart.colors = 
            {	"classic":	["#ffa500","blue","red","green","cyan","magenta","yellow","#0f0"],
                "dark":		["#960","#003","#900","#060","#099","#909","#990","#090"],
                //"pale":	["#fd0","#369","#f64","#3b7","#880","#b5d","#666"],
                "pale":		["#3494FA","#E63B4B"],
                "pastel":	["#fb4","#79c","#f66","#7d7","#acc","#fdd","#ff9","#b9b"], 
                "neon":		["#ff0","#0ff","#0f0","#f0f","#f00","#00f"]
            }

            /** Get data associatied with the chart
            */
            ol.style.Chart.prototype.getData = function() 
            {	return this.data_;
            }
            /** Set data associatied with the chart
            *	@param {Array<number>}
            */
            ol.style.Chart.prototype.setData = function(data) 
            {	this.data_ = data;
                this.renderChart_();
            }

            /** Get symbol radius
            */
            ol.style.Chart.prototype.getRadius = function() 
            {	return this.radius_;
            }
            /** Set symbol radius
            *	@param {number} symbol radius
            *	@param {number} donut ratio
            */
            ol.style.Chart.prototype.setRadius = function(radius, ratio) 
            {	this.radius_ = radius;
                this.donuratio_ = ratio || this.donuratio_;
                this.renderChart_();
            }

            /** Set animation step 
            *	@param {false|number} false to stop animation or the step of the animation [0,1]
            */
            ol.style.Chart.prototype.setAnimation = function(step) 
            {	if (step===false) 
                {	if (this.animation_.animate === false) return;
                    this.animation_.animate = false;
                }
                else
                {	if (this.animation_.step === step) return;
                    this.animation_.animate = true;
                    this.animation_.step = step;
                }
                this.renderChart_();
            }


            /** @private
            */
            ol.style.Chart.prototype.renderChart_ = function(atlasManager) 
            {	var strokeStyle;
                var strokeWidth = 0;

                if (this.stroke_) 
                {	strokeStyle = ol.color.asString(this.stroke_.getColor());
                    strokeWidth = this.stroke_.getWidth();
                }

                // no atlas manager is used, create a new canvas
                var canvas = this.getImage();

                // draw the circle on the canvas
                var context = (canvas.getContext('2d'));
                context.clearRect(0, 0, canvas.width, canvas.height);
                context.lineJoin = 'round';

                var sum=0;
                for (var i=0; i<this.data_.length; i++)
                    sum += this.data_[i];

                // reset transform
                context.setTransform(1, 0, 0, 1, 0, 0);

                // then move to (x, y)
                context.translate(0,0);

                var step = this.animation_.animate ? this.animation_.step : 1;

                // Draw pie
                switch (this.type_)
                {	case "donut":
                    case "pie3D":
                    case "pie":
                    {	var a, a0 = Math.PI * (step-1.5);
                        var c = canvas.width/2;
                        context.strokeStyle = strokeStyle;
                        context.lineWidth = strokeWidth;
                        context.save();
                        if (this.type_ === "pie3D") 
                        {	context.translate(0, c*0.3);
                            context.scale(1, 0.7);
                            context.beginPath();
                            context.fillStyle = "#369";
                            context.arc ( c, c*1.4, this.radius_ *step, 0, 2*Math.PI);
                            context.fill();
                            context.stroke();
                        }
                        if (this.type_ === "donut")
                        {	context.save();
                            context.beginPath();
                            context.rect ( 0,0,2*c,2*c );
                            context.arc ( c, c, this.radius_ *step *this.donutratio_, 0, 2*Math.PI);
                            context.clip("evenodd");
                        }
                        for (var j=0; j<this.data_.length; j++)
                        {	context.beginPath();
                            context.moveTo(c,c);
                            context.fillStyle = this.colors_[j%this.colors_.length];
                            a = a0 + 2*Math.PI*this.data_[j]/sum *step;
                            context.arc ( c, c, this.radius_ *step, a0, a);
                            context.closePath();
                            context.fill();
                            context.stroke();
                            a0 = a;
                        }
                        if (this.type_ === "donut")
                        {	context.restore();
                            context.beginPath();
                            context.strokeStyle = strokeStyle;
                            context.lineWidth = strokeWidth;
                            context.arc ( c, c, this.radius_ *step *this.donutratio_, Math.PI * (step-1.5), a0);
                            context.stroke();
                        }
                        context.restore();
                        break;
                    }
                    case "bar":
                    default:
                    {	var max=0;
                        for (var k=0; k<this.data_.length; k++)
                        {	if (max < this.data_[k]) max = this.data_[k];
                        }
                        var s = Math.min(5,2*this.radius_/this.data_.length);
                        var cnv = canvas.width/2;
                        var b = canvas.width - strokeWidth;
                        var x, x0 = cnv - this.data_.length*s/2
                        context.strokeStyle = strokeStyle;
                        context.lineWidth = strokeWidth;
                        for (var l=0; l<this.data_.length; l++)
                        {	context.beginPath();
                            context.fillStyle = this.colors_[l%this.colors_.length];
                            x = x0 + s;
                            var h = this.data_[l]/max*2*this.radius_ *step;
                            context.rect ( x0, b-h, s, h);
                            context.closePath();
                            context.fill();
                            context.stroke();
                            x0 = x;
                        }

                    }
                }

                // Set Anchor
                var anc = this.getAnchor();
                anc[0] = c - this.offset_[0];
                anc[1] = c - this.offset_[1];

            };


            /**
             * @inheritDoc
             */
            ol.style.Chart.prototype.getChecksum = function() 
            {
                var strokeChecksum = (this.stroke_!==null) ?
                    this.stroke_.getChecksum() : '-';

                var recalculate = (this.checksums_===null) ||
                    (strokeChecksum !== this.checksums_[1] ||
                    fillChecksum !== this.checksums_[2] ||
                    this.radius_ !== this.checksums_[3] ||
                    this.data_.join('|') !== this.checksums_[4]);

                if (recalculate) {
                    var checksum = 'c' + strokeChecksum + fillChecksum 
                        + ((this.radius_ !== void 0) ? this.radius_.toString() : '-')
                        + this.data_.join('|');
                    this.checksums_ = [checksum, strokeChecksum, fillChecksum, this.radius_, this.data_.join('|')];
                }

                return this.checksums_[0];
            };
        }
        
        $scope.getChartOrdering = function() {
            ol.ordering = {}

            /** y-Ordering
            *	@return ordering function (f0,f1)
            */
            ol.ordering.yOrdering = function(options)
            {	return function(f0,f1)
                {	return f0.getGeometry().getExtent()[1] < f1.getGeometry().getExtent()[1] ;
                };
            }

            /** Order with a feature attribute
            *	@param option
            *		attribute: ordering attribute, default zIndex
            *		equalFn: ordering function for equal values
            *	@return ordering function (f0,f1)
            */
            ol.ordering.zIndex = function(options)
            {	if (!options) options = {};
                var attr = options.attribute || 'zIndex';
                if (option.equalFn)
                {	return function(f0,f1)
                    {	if (f0.get(attr) === f1.get(attr)) return option.equalFn(f0,f1);
                        return f0.get(attr) < f1.get(attr);
                    };
                }
                else
                {	return function(f0,f1)
                    {	return f0.get(attr) < f1.get(attr);
                    };
                }
            }   
        }
    
        // ol.style.Chart
        var animation  = false;
        var styleCache = {};

        function getFeatureStyle (feature, sel)
        {	var k = "donut-pale-"+(sel?"1-":"")+feature.get("data");
            var style = styleCache[k];
            if (!style) 
            {	var radius;
                // area proportional to data size: s=PI*r^2
                radius = 8* Math.sqrt (feature.get("size") / Math.PI);

                // Create chart style
                var c = 'pale';
                styleCache[k] = style = new ol.style.Style(
                {	image: new ol.style.Chart(
                    {	type: 'donut', 
                        radius: (sel?1.2:1)*radius, 
                        offsetY: (sel?-1.2:-1)*feature.get("radius"),
                        data: feature.get("data") || [10,30,20], 
                        colors: /,/.test(c) ? c.split(",") : c,
                        rotateWithView: true,
                        animation: animation,
                        stroke: new ol.style.Stroke(
                        {	color: "#fff",
                            width: 1
                        }),
                    })
                });
            }
            style.getImage().setAnimation(animation);
            return [style];
        }
        
        // Animate function 
        var listenerKey;
        function doAnimate(vector)
        {	if (listenerKey) return;
            var start = new Date().getTime();
            var duration = 1000;
            animation = 0;
            listenerKey = vector.on('precompose', function(event)
            {	var frameState = event.frameState;
                var elapsed = frameState.time - start;
                if (elapsed > duration) 
                {	ol.Observable.unByKey(listenerKey);
                    listenerKey = null;
                    animation = false;
                }	
                else
                {	animation = ol.easing.easeOut (elapsed / duration);
                    frameState.animate = true;
                }
                vector.changed();
            });
            // Force redraw
            vector.changed();
        }
        
        $scope.keyDealsDataTablesUpdate = function (regionKey, regionData) {
            
            $('body #keyDeals'+regionKey+'Table tbody').on( 'click', 'tr', function () {
                
                var data              = $("#keyDeals"+regionKey+"Table").dataTable().api().row(this).data();
                var dataObject        = {};
                $scope.mainDataObject = [];
                $scope.failureMessage = "";

                _.forEach (data, function(value,key) {

                    if (_.where(_.where($scope.customizedKeyDealsHeaders, {data: key}), {editable: "Y",type:'DropDown'}).length > 0) {

                        _.forEach (_.where(_.where($scope.customizedKeyDealsHeaders, {data: key}), {editable: "Y",type:'DropDown'}),         function(value) {
                            dataObject          = {};
                            dataObject.id       = value.id;   
                            dataObject.key      = value.data;                    
                            dataObject.value    = value.title;
                            dataObject.editable = value.editable;
                            dataObject.type     = value.type;

                            var str = value.values; 
                            if (str) {
                                dataObject.values = str.toString().split(",");
                            }
                            $scope.mainDataObject.push(dataObject);
                        });
                    }

                    if (_.where(_.where($scope.customizedKeyDealsHeaders, {data: key}), {editable: "Y",type:'DATE'}).length > 0) {

                        _.forEach (_.where(_.where($scope.customizedKeyDealsHeaders, {data: key}), {editable: "Y",type:'DATE'}), function(value) {
                            dataObject          = {};
                            dataObject.id       = value.id;
                            dataObject.key      = value.data;
                            dataObject.value    = value.title;
                            dataObject.editable = value.editable;
                            dataObject.type     = value.type;
                            dataObject.values   = value.values;
                            $scope.mainDataObject.push(dataObject);
                        });
                    }


                    if (_.where(_.where($scope.customizedKeyDealsHeaders, {data: key}), {editable: "Y",type:'FreeField'}).length > 0) {

                        _.forEach (_.where(_.where($scope.customizedKeyDealsHeaders, {data: key}), {editable: "Y",type:'FreeField'}), function(value) {
                            dataObject          = {};
                            dataObject.id       = value.id;
                            dataObject.key      = value.data;
                            dataObject.value    = value.title;
                            dataObject.editable = value.editable;
                            dataObject.type     = value.type;
                            dataObject.values   = value.values;
                            $scope.mainDataObject.push(dataObject);
                        });
                    }

                    if (_.where(_.where($scope.customizedKeyDealsHeaders, {data: key}), {editable: "N"}).length > 0) {

                        _.forEach (_.where(_.where($scope.customizedKeyDealsHeaders, {data: key}), {editable: "N"}), function(value) {
                            dataObject          = {};
                            dataObject.id       = value.id;
                            dataObject.key      = value.data;
                            dataObject.value    = value.title;
                            dataObject.editable = value.editable;
                            dataObject.type     = value.type;
                            dataObject.values   = value.values;
                            $scope.mainDataObject.push(dataObject);
                        });
                    }

                    if (_.where(_.where($scope.customizedKeyDealsHeaders, {data: key}), {editable: "D"}).length > 0) {

                        _.forEach (_.where(_.where($scope.customizedKeyDealsHeaders, {data: key}), {editable: "D"}), function(value) {
                            dataObject          = {};
                            dataObject.id       = value.id;
                            dataObject.key      = value.data;
                            dataObject.value    = value.title;
                            dataObject.editable = value.editable;
                            dataObject.type     = value.type;
                            dataObject.values   = value.values;
                            $scope.mainDataObject.push(dataObject);
                        });
                    }
                });
                
                $scope.mainDataObject = _.sortBy($scope.mainDataObject, 'id');
                
                $rootScope.safeApply(function() {
                    if (data.p_r_by_o) {
                        if ((data.p_r_by_o).toUpperCase()==='RISK') {
                            if (!data.p_status) {
                                data.p_status = "";
                            } else if ((data.p_status).toUpperCase().includes("GREEN")) {
                                data.p_status = 'Low';
                            } else if ((data.p_status).toUpperCase().includes("YELLOW")) {
                                data.p_status = 'Medium';
                            } else if ((data.p_status).toUpperCase().includes("RED")) {
                                data.p_status = 'High';
                            }
                        } else if ((data.p_r_by_o).toUpperCase()==='OPPS'){

                            if (!data.p_status){ 
                                data.p_status = "";
                            } else if ((data.p_status).toUpperCase().includes("GREEN")) {
                                data.p_status ='High';
                            } else if ((data.p_status).toUpperCase().includes("YELLOW")) {
                                data.p_status ='Medium';
                            } else if ((data.p_status).toUpperCase().includes("RED")) {
                                data.p_status ='Low';
                            }
                        }
                    } else {
                        if (!data.p_status) {
                            data.p_status = "";
                        } else if ((data.p_status).toUpperCase().includes("GREEN")) {
                            data.p_status ='High';
                        } else if ((data.p_status).toUpperCase().includes("YELLOW")) {
                            data.p_status ='Medium';
                        } else if ((data.p_status).toUpperCase().includes("RED")) {
                            data.p_status ='Low';
                        }
                    }

                    $scope.rowData = null;
                    $scope.rowData = [];
                    var dataObject = {};
                    _.forEach(data, function(value,key) {
                        dataObject['key']   = key;
                        dataObject['value'] = value;
                        $scope.rowData.push(dataObject);
                        dataObject = {};
                    });
                });

                if ( parseInt($scope.getCurrentWeek) === parseInt($rootScope.selectionFilterData.week) ) {
                    $scope.updateSuccess    = false;
                    $scope.updateFailure    = false;
                    
                    keyDealsModalUpdate     = document.getElementById('keyDealsUpdateDataModal');
                    keyDealsModalUpdate.style.display = "block";
                }
                
            });
        }
        
        $scope.updateKeyDealsData = function() {
            
            $scope.editedData     = {};
            $scope.failureMessage = "";
            
            _.forEach($scope.rowData, function(data){
                if( !$('.'+data.key+'').val() ){
                    if(data.key === 'p_new_date') {
                        if($('#keydeals_'+data.key+'').val().trim() === "") {
                            $scope.editedData[data.key] = null;
                        } else {
                            $scope.editedData[data.key] = $('#keydeals_'+data.key+'').val().trim(); 
                        }
                    } else {
                        $scope.editedData[data.key] = null;
                    }
                } else {    
                    if($('#'+data.key+'').val() === "") {
                        $scope.editedData[data.key] = null;
                    } else {
                        if(data.key === 'p_new_date') {
                            if($('#keydeals_'+data.key+'').val().trim() === "") {
                                $scope.editedData[data.key] = null;
                            } else {
                                $scope.editedData[data.key] = $('#keydeals_'+data.key+'').val().trim(); 
                            }
                        } else {
                            $scope.editedData[data.key] = $('#'+data.key+'').val();
                        }
                    }
                }
            });
            
            if ($scope.editedData['p_new_date'] !== null && $scope.editedData['p_wb_comment'] === null) {
                $scope.updateSuccess  = false;
                $scope.updateFailure  = true;
                $scope.failureMessage = "Please Select WB Comment."
            } else if (!$scope.editedData['p_status']) {
                $scope.updateSuccess  = false;
                $scope.updateFailure  = true;
                $scope.failureMessage = "Please Select Status."
            } else {
                
                IPMService.updateIPMPartsRow(JSON.stringify($scope.editedData)).then(function(response) {

                    $rootScope.safeApply(function() {
                        if (response === "UPDATED" || response === "SUCCESS") {
                            $scope.updateSuccess = true;
                            $scope.updateFailure = false;
                            $scope.loadfilteredData();
                        } else if (response==="FAILURE") {
                            $scope.updateSuccess  = false;
                            $scope.updateFailure  = true;
                            $scope.failureMessage = "Something went wrong! Please try again later."
                        }

                        $timeout(function () {
                            $scope.updateSuccess = false;
                            $scope.updateFailure = false;
                        },3000);  
                    });

                });
            }
        };
        
    }]);
});