define(['angular','../../../sample-module','jquery','multiselectdrpdwn','jqueryMultiSelect','highcharts3d','highchartsNoData','jquery-ui'], function(angular,controllers,jquery,multiselectdrpdwn,jqueryMultiSelect) 
 {
    'use strict';
    controllers.controller('pmoTrendController', ['$scope','$timeout','$state','$rootScope','IPMService','$http','$q',
	function ($scope,$timeout,$state,$rootScope,IPMService,$http,$q){
        
    $('.kdRawDataFilter').slideUp();
        
    var $window     = $(window);
    var windowsize  = $window.width();
    var responsive;
    if (windowsize > 767) {
        responsive = false;
    } else {
        responsive = true;
    }
        
    if ($.fn.DataTable.isDataTable( '#rawDataTable' ) ) {
        $("#rawDataTable").dataTable().api().clear().draw();
        $("#rawDataTable").dataTable().api().destroy();
        $('#rawDataTable').empty(); 
    }
        
    $scope.getHighestChartValue = function(pmoTrendChartObject) {

        var highestChartValue = 0; //keep track of highest value
        var millionFlag;

        //loop through array of objects
        for (var i=0, len = pmoTrendChartObject.length; i<len; i++) {
          var value = Number(pmoTrendChartObject[i]["sum_cm"]);
          if (value > highestChartValue) {
              highestChartValue = value;
          }
        }

        if (highestChartValue >= 1000000) {		
            millionFlag = true;	
        } else {
            millionFlag = false;
        }

        return millionFlag;
    }
    
    $scope.getHighestTableValue = function(pmoTrendTableObject) {

        var highestTableValue = 0; //keep track of highest value
        var millionFlag;

        //loop through array of objects
        for (var i=0, len = pmoTrendTableObject.length; i<len; i++) {
			  var value = Number(pmoTrendTableObject[i]["added"]);
			  if (value > highestTableValue) {
				  highestTableValue = value;
			  }
			  value = Number(pmoTrendTableObject[i]["forecasted"]);
			  if (value > highestTableValue) {
				  highestTableValue = value;
			  }
			  value = Number(pmoTrendTableObject[i]["new_forecast"]);
			  if (value > highestTableValue) {
				  highestTableValue = value;
			  }
			  value = Number(pmoTrendTableObject[i]["removed"]);
			  if (value > highestTableValue) {
				  highestTableValue = value;
			  }
        }

        if (highestTableValue >= 1000000) {		
            millionFlag = true;	
        } else {
            millionFlag = false;
        }

        return millionFlag;
    }
    
    $scope.getChartTitleText = function (millionFlag) {
        var titleText;
        if (millionFlag) {
            titleText = 'Total($M)';
        } else {
            titleText = 'Total($)';
        }
        return titleText;
    }
    
    var getChartData = function (chartData, millionFlag) {
        
        var createNestedObject = function( base, names, value ) {
            var lastName = arguments.length === 3 ? names.pop() : false;
            for( var i = 0; i < names.length; i++ ) {
                base = base[ names[i] ] = base[ names[i] ] || {};
            }
            if( lastName ) base = base[ lastName ] = value;
            return base;
        };
        
        var totalChartDataCount = 0, statusWithCountData = [], statusData = {}, legendText;
        
        var statuses = [], parts_statuses = [], summaryData = {}, totalCount = {}, _colorIndexes = "", _stack = "", _pointPadding = "", _pointWidth = "40", _dashStyle = "", _borderColor = "", _borderWidth = "";
        
        _.forEach (chartData, function(responseObj) {
            
            if (statuses.indexOf(responseObj.sales_year_qtr) === -1 && responseObj.sales_year_qtr !== null && responseObj.hasOwnProperty("sales_year_qtr")) {
                statuses.push(responseObj.sales_year_qtr);
            }
            
            if (statuses.indexOf(responseObj.caption) === -1 && responseObj.caption !== null && responseObj.hasOwnProperty("caption")) {
                statuses.push(responseObj.caption);
            }            
            if (parts_statuses.indexOf(responseObj.parts_status) === -1 && responseObj.hasOwnProperty("parts_status")) {
                parts_statuses.push(responseObj.parts_status);
                legendText = "Parts Status";
            }
            
            if (parts_statuses.indexOf(responseObj.day_range) === -1 && responseObj.hasOwnProperty("day_range")) {
                parts_statuses.push(responseObj.day_range);
                legendText = "Day Range";
            }
            
            if(parts_statuses.indexOf(responseObj.item_description) === -1 && responseObj.hasOwnProperty("item_description")){
                parts_statuses.push(responseObj.item_description);
                legendText = "Item Description";
            }
            
            if(parts_statuses.indexOf(responseObj.week) === -1 && responseObj.hasOwnProperty("week")){
                parts_statuses.push(responseObj.week);
                legendText = "Week";
            }
        });
        
        _.forEach (statuses, function(status) {
            statusData[status] = [];
            var count = 0;
            _.forEach (parts_statuses, function(parts_status) {
                if(status !== null){
                    (statusData[status])[count] = 0;
                    count ++;
                    createNestedObject(summaryData, [status, parts_status], 0);
                    createNestedObject(summaryData, [parts_status, status], 0);
                    createNestedObject(totalCount, [parts_status], 0);
                }
            });
        });
        
        _.forEach (chartData, function(responseObj) {
            if (responseObj.parts_status !== null && responseObj.hasOwnProperty("parts_status")) {
                if (millionFlag === true) {
                     createNestedObject(summaryData, [responseObj.sales_year_qtr, responseObj.parts_status],responseObj.sum_cm/1000000);
                } else {
                     createNestedObject(summaryData, [responseObj.sales_year_qtr, responseObj.parts_status],responseObj.sum_cm);
                }
                totalCount[responseObj.parts_status]=totalCount[responseObj.parts_status]+parseInt(responseObj.sum_cm);
                totalChartDataCount = totalChartDataCount + parseInt(responseObj.sum_cm);
            }
            
            if (responseObj.day_range !== null && responseObj.hasOwnProperty("day_range")) {
                if (millionFlag === true) {
                     createNestedObject(summaryData, [responseObj.sales_year_qtr, responseObj.day_range],responseObj.sum_cm/1000000);
                } else {
                     createNestedObject(summaryData, [responseObj.sales_year_qtr, responseObj.day_range],responseObj.sum_cm);
                }
                totalCount[responseObj.day_range]=totalCount[responseObj.day_range]+parseInt(responseObj.sum_cm);
                totalChartDataCount = totalChartDataCount + parseInt(responseObj.sum_cm);
            }
            
            if (responseObj.item_description !== null && responseObj.hasOwnProperty("item_description")) {
                if (millionFlag === true) {
                     createNestedObject(summaryData, [responseObj.sales_year_qtr, responseObj.item_description],responseObj.sum_cm/1000000);
                } else {
                     createNestedObject(summaryData, [responseObj.sales_year_qtr, responseObj.item_description],responseObj.sum_cm);
                }
                totalCount[responseObj.item_description] = totalCount[responseObj.item_description]+parseInt(responseObj.sum_cm);
                totalChartDataCount = totalChartDataCount + parseInt(responseObj.sum_cm);
            }
            
            if (responseObj.week !== null && responseObj.hasOwnProperty("week")) {
                if (millionFlag === true) {
                     createNestedObject(summaryData, [responseObj.caption, responseObj.week],responseObj.sum_cm/1000000);
                } else {
                     createNestedObject(summaryData, [responseObj.caption, responseObj.week],responseObj.sum_cm);
                }
                
                totalCount[responseObj.week] = totalCount[responseObj.week]+parseInt(responseObj.sum_cm);
                totalChartDataCount = totalChartDataCount + parseInt(responseObj.sum_cm);    
            }
        });
        
        totalCount = _.pairs(totalCount);
        
        var rankArray = [];
        _.forEach (totalCount, function(tech) {
            rankArray.push(tech[0]);
        });
        
        _.forEach (statuses, function(status) {
            
            if (legendText === "Parts Status") {
                _.forEach (rankArray, function(parts_status) {
                    ((statusData[status])[rankArray.indexOf(parts_status)]) = parseFloat(summaryData[status][parts_status]);
                });

                if (status === "CURRENT") {
                    _colorIndexes = "#9BBB5A";
                } else if (status === "FUTURE") {
                    _colorIndexes = "rgba(128, 128, 128, 0.50)";
                } 
            }
            
            if (legendText === "Day Range") {
                _.forEach (rankArray, function(day_range) {
                    ((statusData[status])[rankArray.indexOf(day_range)]) = parseFloat(summaryData[status][day_range]);
                });

                if (status === "CURRENT") {
                    _colorIndexes = "#FF3334";
                } else if (status === "FUTURE") {
                    _colorIndexes = "#2F75B5";
                } 
            }
            
            if (legendText === "Item Description") {
               _.forEach (rankArray, function(item_description) {
                    ((statusData[status])[rankArray.indexOf(item_description)]) = parseFloat(summaryData[status][item_description]);
                });

                if (status === "CURRENT") {
                    _colorIndexes = "#FF3334";
                } else if (status === "FUTURE") {
                    _colorIndexes = "#2F75B5";
                } 
            }
            
            if (legendText === "Week") {
                
               _.forEach (rankArray, function(week) {
                    if (status === "FORECASTED") { 
                        ((statusData[status])[rankArray.indexOf(week)]) = {y:parseFloat(summaryData[status][week]),dataLabels:{enabled:true}};
                    } else {
                        ((statusData[status])[rankArray.indexOf(week)]) = parseFloat(summaryData[status][week]);
                    }
                });
                
                if (status === "FORECASTED") {
                    _colorIndexes = "rgba(128, 128, 128, 0.50)";
                    _stack        = 1;
                    _pointPadding = 0.1;
                    _pointWidth   = 40;
                    _dashStyle    = "Dash";
                    _borderColor  = 'black';
                    _borderWidth  = 1;
                } else if (status === "CONFIRMED") {
                    _colorIndexes = "#FF3334";
                    _stack        = 0;
                    _pointPadding = 0.4;
                    _pointWidth   = 25;
                } else if (status === "UNCONFIRMED") {
                    _colorIndexes = "#2F75B5";
                    _stack        = 0;
                    _pointPadding = 0.4;
                    _pointWidth   = 25;
                } 
            }

            statusWithCountData.push({
                'data': statusData[status], 
                'name':status,
                'showInLegend': false,
                'color': _colorIndexes,
                'stack': _stack,
                'pointPadding': _pointPadding,
                'pointWidth': _pointWidth,
                'dashStyle': _dashStyle,
                'borderColor': _borderColor,
                'borderWidth': _borderWidth                
            });
        });
        
        var returnObj                      = {};
        returnObj['statusWithCount']       = statusWithCountData;
        returnObj['partStatus']            = rankArray;
        returnObj['totalChartDataCount']   = totalChartDataCount;
        
        return returnObj;
    }
    
    var getChartTableData = function (chartTableData, millionFlag) {
        
        var rowLabels = "", foreCastedSum = "", addedSum = "", removedSum = "", newForeCastSum = "", grandTotal = "";
        
        var arrPMTrendData = [];
        
        _.forEach(chartTableData, function(responseObj) {

            rowLabels       = responseObj.parts_status;
            
            if (millionFlag) {
                foreCastedSum   = (responseObj.forecasted / 1000000).toFixed(2).replace(/\.0$/, '');
                addedSum        = (responseObj.added / 1000000).toFixed(2).replace(/\.0$/, '');
                removedSum      = (responseObj.removed / 1000000).toFixed(2).replace(/\.0$/, '');
                newForeCastSum  = (responseObj.new_forecast / 1000000).toFixed(2).replace(/\.0$/, '');
            } else {
                 foreCastedSum   = (responseObj.forecasted).replace(/\.0$/, '');
                 addedSum        = (responseObj.added).replace(/\.0$/, '');
                 removedSum      = (responseObj.removed).replace(/\.0$/, '');
                 newForeCastSum  = (responseObj.new_forecast).replace(/\.0$/, '');
            }
            
            grandTotal      = 0.00;

            arrPMTrendData.push({
                'rowLabels'     : rowLabels,
                'foreCastedSum' : foreCastedSum,
                'addedSum'      : addedSum,
                'removedSum'    : removedSum,
                'newForeCastSum': newForeCastSum,
                'grandTotal'    : grandTotal
            });
        });
        
        return arrPMTrendData;
    }
    
var updatePMOTrend = function(pmoTrendData) {
    
    var pmoTrendChartData, boxOldDogsChartData, dummyCodesChartData, promiseDateChartData, cwdExpiredChartData, financialViewChartData ;
    
    var currentChartTableData, futureChartTableData;
    
    //Get Chart Million Flag
    $scope.chartDataMillionFlag     = $scope.getHighestChartValue(pmoTrendData.chartData);

    $scope.boxOldDogsMillionFlag    = $scope.getHighestChartValue(pmoTrendData.boxOldDogs);

    $scope.dummyCodesMillionFlag    = $scope.getHighestChartValue(pmoTrendData.dummyCodes);

    $scope.promiseDateMillionFlag   = $scope.getHighestChartValue(pmoTrendData.promiseDate);

    $scope.cwdExpiredMillionFlag    = $scope.getHighestChartValue(pmoTrendData.cwdExpired);
    
    $scope.financialViewMillionFlag = $scope.getHighestChartValue(pmoTrendData.financialView);
    
    //Get Chart Data
    pmoTrendChartData              = getChartData(pmoTrendData.chartData, $scope.chartDataMillionFlag);
    
    boxOldDogsChartData            = getChartData(pmoTrendData.boxOldDogs, $scope.boxOldDogsMillionFlag);
    
    dummyCodesChartData            = getChartData(pmoTrendData.dummyCodes, $scope.dummyCodesMillionFlag);
    
    promiseDateChartData           = getChartData(pmoTrendData.promiseDate, $scope.promiseDateMillionFlag);
    
    cwdExpiredChartData            = getChartData(pmoTrendData.cwdExpired, $scope.cwdExpiredMillionFlag);
    
    financialViewChartData         = getChartData(pmoTrendData.financialView, $scope.financialViewMillionFlag);
    
    //Get Current/Future DataTable Data
    currentChartTableData          = getChartTableData(pmoTrendData.tableData.CURRENT, $scope.chartDataMillionFlag);
    
    futureChartTableData           = getChartTableData(pmoTrendData.tableData.FUTURE, $scope.chartDataMillionFlag);
    
    var returnObj                      = {};
    
    returnObj['statusWithCount']       = pmoTrendChartData['statusWithCount'];
    returnObj['partStatus']            = pmoTrendChartData['partStatus'];
    returnObj['totalCount']            = pmoTrendChartData['totalChartDataCount'];
    
    returnObj['statusWithCountBox']    = boxOldDogsChartData['statusWithCount'];
    returnObj['partStatusBox']         = boxOldDogsChartData['partStatus'];
    returnObj['totalBoxCount']         = boxOldDogsChartData['totalChartDataCount'];
    
    returnObj['statusWithCountDummy']  = dummyCodesChartData['statusWithCount'];
    returnObj['partStatusDummy']       = dummyCodesChartData['partStatus'];
    returnObj['totalDummyCount']       = dummyCodesChartData['totalChartDataCount'];
    
    returnObj['statusWithCountPromise']= promiseDateChartData['statusWithCount'];
    returnObj['partStatusPromise']     = promiseDateChartData['partStatus'];
    returnObj['totalPromiseCount']     = promiseDateChartData['totalChartDataCount'];
    
    returnObj['statusWithCountCWD']    = cwdExpiredChartData['statusWithCount'];
    returnObj['partStatusCWD']         = cwdExpiredChartData['partStatus'];
    returnObj['totalCWDCount']         = cwdExpiredChartData['totalChartDataCount'];
    
    returnObj['statusWithCountFW']     = financialViewChartData['statusWithCount'];
    returnObj['partStatusFW']          = financialViewChartData['partStatus'];
    returnObj['totalFWCount']          = financialViewChartData['totalChartDataCount'];
    
    returnObj['arrPMTrendCurrentData'] = currentChartTableData;
    returnObj['arrPMTrendFutureData']  = futureChartTableData;
    
    return returnObj;
}

$scope.partsSearchPanel = {};
        
$scope.roCategories = [       
   { label: "- Select Risks/Opps -", value: "", disabled: true },
   { label: "NO RISK", value: "NULL_PRBYO", disabled: true },
   { label: "RISK", value: "RISK", disabled: false },
   { label: "OPPS", value: "OPPS", disabled: false }
];
        
var modalList   = document.getElementById('partsDataModal');
var span        = document.getElementsByClassName("partsClose")[0];
        
var modalUpdate = document.getElementById('partsUpdateDataModal');          
var spanUpdate  = document.getElementsByClassName("partsUpdateClose")[0];
        
var modalAlert  = document.getElementById('partsDataAlertModal');
var spanAlert   = document.getElementsByClassName("partsDataAlertClose")[0];
        
span.onclick = function(event) {
    
    if($scope.defaultPMSelection === false || $scope.defaultPMSelection === undefined) {
        $scope.partsSearchPanel.projectManager = "";
        $rootScope.selectionFilterData.projectManager = "";
        $rootScope.selectionFilterData.financial_parts_status = "";
        $scope.PMOPartsStatusDropdownData = undefined;
        $scope.hidePMvalues();
    }
    
    if($scope.updateSuccess === true) {
        $scope.iPMLoader    = true;
        $scope.loadfilteredData(); 
        $scope.updateSuccess = false;
    }
    
    modalList.style.display = "none";
}

spanUpdate.onclick = function(event) {
    modalUpdate.style.display = "none";
}

spanAlert.onclick = function(event) {
    modalAlert.style.display = "none";
}

window.onclick = function(event) {
    
    if (event.target === modalList) {
        
        if($scope.defaultPMSelection === false || $scope.defaultPMSelection === undefined) {
            $scope.partsSearchPanel.projectManager = "";
            $rootScope.selectionFilterData.projectManager = "";
            $rootScope.selectionFilterData.financial_parts_status = "";
            $scope.PMOPartsStatusDropdownData = undefined;
            $scope.hidePMvalues();
        }
        
        if($scope.updateSuccess === true) {
            $scope.iPMLoader    = true;
            $scope.loadfilteredData(); 
            $scope.updateSuccess = false;
        }
        
        modalList.style.display = "none";
    }
    
    if (event.target === modalUpdate) {
        modalUpdate.style.display = "none";
    }
    
    if (event.target === modalAlert) {
        modalAlert.style.display = "none";
    }
}

$(function() {
    $("body").delegate("#p_new_date", "focusin", function(){
        var localToday = new Date();
        $(this).datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: 'mm-dd-yy',
            localToday: localToday,
            minDate: localToday,
            inline: true,
            dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            showOtherMonths: true,
      		showOn: "both",
            showAnim: "slideDown",
            duration: 'fast',
      		buttonImage: "images/calendar.png",
      		buttonImageOnly: true
        });
    });
});

$scope.drawPMTREND = function (){

    var updatePMOTrendData        = updatePMOTrend($scope.PMTRENDData);
    
    $scope.PMTRENDCategories     = updatePMOTrendData.partStatus;
    $scope.Chart                 = _.sortBy(_.sortBy(updatePMOTrendData.statusWithCount,'sum').reverse(), function (name) {return name});
    
    $scope.boxOldDogsCategories  = updatePMOTrendData.partStatusBox;
    $scope.boxOldDogsChart       = _.sortBy(_.sortBy(updatePMOTrendData.statusWithCountBox,'sum').reverse(), function (name) {return name});
    
    //$scope.dummyCodesCategories  = updatePMOTrendData.partStatusDummy;
    $scope.dummyCodesCategories  = ["CTOB", "TOBEDEF", "ORDACK", "OTHER"];
    $scope.dummyCodesChart       = _.sortBy(_.sortBy(updatePMOTrendData.statusWithCountDummy,'sum').reverse(), function (name) {return name});
    
    $scope.promiseDateCategories = updatePMOTrendData.partStatusPromise;
    $scope.promiseDateChart      = _.sortBy(_.sortBy(updatePMOTrendData.statusWithCountPromise,'sum').reverse(), function (name) {return name});
    
    $scope.cwdExpiredCategories  = updatePMOTrendData.partStatusCWD;
    $scope.cwdExpiredChart       = _.sortBy(_.sortBy(updatePMOTrendData.statusWithCountCWD,'sum').reverse(), function (name) {return name});
    
    $scope.financialViewCategories  = updatePMOTrendData.partStatusFW;
    $scope.financialViewChart       = _.sortBy(_.sortBy(_.first(updatePMOTrendData.statusWithCountFW, 2),'sum').reverse(), function (name) {return name});
    $scope.financialViewChart1      = _.last(updatePMOTrendData.statusWithCountFW, 1);
    $scope.financialViewChart.push($scope.financialViewChart1[0]);     
    
    $scope.arrPMTrendCurrentData = updatePMOTrendData.arrPMTrendCurrentData;
    $scope.arrPMTrendFutureData  = updatePMOTrendData.arrPMTrendFutureData;
    $scope.getCurrentWeek        = $scope.getWeekNumber();
    
    var chart, boxChart, dummyChart, promiseChart, cwdChart, financialViewChart;
    
    $scope.chartDataTitleText   = $scope.getChartTitleText($scope.chartDataMillionFlag);
    
    $scope.boxOldDogsTitleText  = $scope.getChartTitleText($scope.boxOldDogsMillionFlag);
    
    $scope.dummyCodesTitleText  = $scope.getChartTitleText($scope.dummyCodesMillionFlag);
    
    $scope.promiseDateTitleText = $scope.getChartTitleText($scope.promiseDateMillionFlag);
    
    $scope.cwdExpiredTitleText  = $scope.getChartTitleText($scope.cwdExpiredMillionFlag);
    
    $scope.financialViewTitleText  = $scope.getChartTitleText($scope.financialViewMillionFlag);
    
    $(document).ready(function() {
        
         var windowWidth = $(window).width();
         
         if(windowWidth >= 1367 && windowWidth <= 1440) {
             $scope.lChartWidth = 335;
             $scope.lChartHeight = 200;
             $scope.rChartWidth = 825;
             $scope.rChartHeight = 440;
         } else if(windowWidth >= 1281 && windowWidth <= 1357) {
             $scope.lChartWidth = 300;
             $scope.lChartHeight = 200;
             $scope.rChartWidth = 775;
             $scope.rChartHeight = 440;
         } else if(windowWidth >= 1025 && windowWidth <= 1271) {
             $scope.lChartWidth = 300;
             $scope.lChartHeight = 200;
             $scope.rChartWidth = 690;
             $scope.rChartHeight = 440;
         } else if(windowWidth >= 768 && windowWidth <= 1015) {
             $scope.lChartWidth  = 335;
             $scope.lChartHeight = 200;
             $scope.rChartWidth  = 775;
             $scope.rChartHeight = 440;
         } else if(windowWidth >= 568 && windowWidth <= 736) {
             $scope.lChartWidth  = 335;
             $scope.lChartHeight = 200;
             $scope.rChartWidth  = 775;
             $scope.rChartHeight = 440;
         } else if(windowWidth >= 414) {
             $scope.lChartWidth  = 299;
             $scope.lChartHeight = 200;
             $scope.rChartWidth  = 775;
             $scope.rChartHeight = 440;
         } else if(windowWidth >= 412) {
             $scope.lChartWidth  = 297;
             $scope.lChartHeight = 200;
             $scope.rChartWidth  = 775;
             $scope.rChartHeight = 440;
         } else if(windowWidth >= 375) {
             $scope.lChartWidth  = 260;
             $scope.lChartHeight = 200;
             $scope.rChartWidth  = 775;
             $scope.rChartHeight = 440;
         } else if(windowWidth >= 360) {
             $scope.lChartWidth  = 250;
             $scope.lChartHeight = 200;
             $scope.rChartWidth  = 775;
             $scope.rChartHeight = 440;
         } else if(windowWidth >= 320) {
             $scope.lChartWidth  = 205;
             $scope.lChartHeight = 200;
             $scope.rChartWidth  = 775;
             $scope.rChartHeight = 440;
         }  else {
             $scope.lChartWidth  = null;
             $scope.lChartHeight = null;
             $scope.rChartWidth  = null;
             $scope.rChartHeight = null;
         }
        
        Highcharts.setOptions({lang: {noData: "No Data Available!"}, noData: {useHTML: true}});
        chart = new Highcharts.Chart({
            
            chart: {
                renderTo: 'PMTRENDChart',
                type: 'column',
                marginLeft: 10,
                marginRight: -30,
                marginTop: 30,
                marginBottom: 50,
                width: $scope.rChartWidth ? $scope.rChartWidth: "100%",
                height: $scope.rChartHeight ? $scope.rChartHeight: 440,
                options3d: {
                    enabled: true,
                    alpha: 13,
                    beta: 13,
                    viewDistance: 25,
                    depth: 120
                }
            },


            title: {
                useHTML: true,
                text: 'PMO - Trend'

            },
             
            credits: {
                
                  enabled: false
                
            },

            xAxis: {

                categories: $scope.PMTRENDCategories,
                labels: {
                    rotation: -45,
                    style: {
                        align: 'right',
                        color: '#7f8c8d',
                        fontFamily: 'Arial',
                        fontSize: '11px',
                        fontWeight: 'bold'
                    },
                    useHTML : true
                }
 
            },

            yAxis: {
                
                allowDecimals: true,
                
                gridLineWidth: 0,

                min: 0,
                
                labels: {
                    formatter: function () {
                    	var cFormat;
                        if ($scope.chartDataMillionFlag) {
                            cFormat = "M";
                            return this.value + cFormat;
                        } else {
                            cFormat = "k";
                            return (this.value / 1000) + cFormat;
                        }
                    },
                    useHTML : true,
                    style:{
                        color: '#7f8c8d',
                        fontFamily: 'Arial',
                        fontSize: '11px',
                        fontWeight: 'bold'
                    }
                },
                
                title: {
                         useHTML: true,
                		 text:  $scope.chartDataTitleText,
                         style: {
                            color: '#333333',
                            fontFamily: 'Arial',
                            fontSize: '11px',
                            fontWeight: 'bold'
                        }
                }
            },

            tooltip: {
                valueDecimals: 2,
                valueSuffix: '',
                formatter: function() {
                	var cFormat = "M", cValue = "$";
                    if ($scope.chartDataMillionFlag) {
                        return '<b>'+ this.x +'</b><br/>' + this.series.name +': '+ cValue + (this.y).toFixed(2)  + cFormat;
                    } else {
                    	return '<b>'+ this.x +'</b><br/>' + this.series.name +': '+ cValue + (this.y).toFixed(2);
                    }
                }

            },

            plotOptions: {
                
                series: {
                    
                    cursor: 'pointer',
                    
                    pointWidth: 40,
                    
                    pointPadding: 10,
                    
                    point: {
				        events: {
                            click: function () {
                            	if($scope.getCurrentWeek === parseInt($rootScope.selectionFilterData.week)) { 
                                    modalList.style.display = "block";
                                    $scope.tableFilter(this.series.name, this.category, chart.title.textStr, "NULL_DAY_RANGE", "NULL_PRBYO", "ALL");
                                }
                                
                            }
                        }
                    }
                    
			    },

                column: {
                    
                    size:'100%',
                    
                    stacking: true,
                    
                    grouping: false,
                    
                    groupZPadding: 100,
                    
                    shadow: false,
                    
                    depth: 40,

                    dataLabels: {

                        enabled: false,

                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
                        
                        formatter: function () {
                            if(this.y > 0) {
                                return Highcharts.numberFormat(this.y,2);
                            }
                        }

                    }

                }

            },
            
            series: $scope.Chart,
            
            responsive: {
                rules: [{
                    condition: {
                        maxWidth: 500
                    },
                    chartOptions: {
                        legend: {
                            align: 'center',
                            verticalAlign: 'bottom',
                            layout: 'horizontal'
                        },
                        yAxis: {
                            labels: {
                                align: 'left',
                                x: 0,
                                y: -5
                            },
                            title: {
                                text: null
                            }
                        },
                        subtitle: {
                            text: null
                        },
                        credits: {
                            enabled: false
                        }
                    }
                }]
            }
            
        });
        
        Highcharts.setOptions({lang: {noData: "No Data Available!"}, noData: {useHTML: true}});
        boxChart = new Highcharts.Chart({
            
            chart: {
                renderTo: 'boxOldDogsChart',
                type: 'column',
                marginLeft: 35,
                marginRight: -5,
                marginTop: 30,
                marginBottom: 10,
                width: $scope.lChartWidth,
                height: $scope.lChartHeight,
                options3d: {
                    enabled: true,
                    alpha: 13,
                    beta: 13,
                    viewDistance: 25,
                    depth: 120
                }
            },
            title: {
                useHTML: true,
                text: 'BOX OLD DOGS'
            },
            credits: {
                  enabled: false
            },
            xAxis: {
                categories: $scope.boxOldDogsCategories,
                labels: {
                    rotation: -45,
                    style: {
                        align: 'right',
                        color: '#7f8c8d',
                        fontFamily: 'Arial',
                        fontSize: '11px',
                        fontWeight: 'bold'
                    },
                    useHTML : true
                }
            },

            yAxis: {
                
                allowDecimals: true,
                
                gridLineWidth: 0,
                
                offset: -20,

                min: 0,
                
                labels: {
                    formatter: function () {
                    	var cFormat;
                        if ($scope.boxOldDogsMillionFlag) {
                            cFormat = "M";
                            return this.value + cFormat;
                        } else {
                            cFormat = "k";
                            return (this.value / 1000) + cFormat;
                        }
                    },
                    useHTML : true,
                    style:{
                        color: '#7f8c8d',
                        fontFamily: 'Arial',
                        fontSize: '11px',
                        fontWeight: 'bold'
                    }
                },
                
                title: {     
                         useHTML: true,
                		 text:  $scope.boxOldDogsTitleText,
                         style: {
                            color: '#333333',
                            fontFamily: 'Arial',
                            fontSize: '11px',
                            fontWeight: 'bold'
                        }                
                }
            },

            tooltip: {
                valueDecimals: 2,
                valueSuffix: '',
                useHTML: true,
                style : { opacity: 0.9 },
                formatter: function() {
                	var cFormat = "M", cValue = "$";
                    if ($scope.boxOldDogsMillionFlag) {
                        return '<b>'+ this.x +'</b><br/>' + this.series.name +': '+ cValue + (this.y).toFixed(2)  + cFormat; 
                    } else {
                    	 return '<b>'+ this.x +'</b><br/>' + this.series.name +': '+ cValue + (this.y).toFixed(2);
                    }

                }

            },

            plotOptions: {
                
                series: {
                    
                    cursor: 'pointer',
                    
                    pointWidth: 40,
                    
                    pointPadding: 10,
                    
                    point: {
				        events: {
                            click: function () {
                            	if($scope.getCurrentWeek === parseInt($rootScope.selectionFilterData.week)) { 
                                    modalList.style.display = "block";
                                    $scope.tableFilter(this.series.name, "SHIPPING", boxChart.title.textStr, this.category, "", "ALL");
                                }
                                
                            }
                        }
                    }
                    
			    },

                column: {
                    
                    size:'100%',
                    
                    stacking: true,
                    
                    grouping: false,
                    
                    groupZPadding: 100,
                    
                    shadow: false,
                    
                    depth: 40,

                    dataLabels: {

                        enabled: false,

                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
                        
                        formatter: function () {
                            if(this.y > 0) {
                                return Highcharts.numberFormat(this.y,2);
                            }
                        }

                    }

                }

            },
            
            series: $scope.boxOldDogsChart,
            
            responsive: {
                rules: [{
                    condition: {
                        maxWidth: 500
                    },
                    chartOptions: {
                        chart: {
                            width: '100%',
                            height: 440
                        },
                        legend: {
                            align: 'center',
                            verticalAlign: 'bottom',
                            layout: 'horizontal'
                        },
                        yAxis: {
                            labels: {
                                align: 'left',
                                x: 0,
                                y: -5
                            },
                            title: {
                                text: null
                            }
                        },
                        subtitle: {
                            text: null
                        },
                        credits: {
                            enabled: false
                        }
                    }
                }]
            }
            
        });
        
        Highcharts.setOptions({lang: {noData: "No Data Available!"}, noData: {useHTML: true}});
        dummyChart = new Highcharts.Chart({
            
            chart: {
                renderTo: 'dummyCodesChart',
                type: 'column',
                marginLeft: 25,
                marginRight: -5,
                marginTop: 30,
                marginBottom: 10,
                width: $scope.lChartWidth,
                height: $scope.lChartHeight,
                options3d: {
                    enabled: true,
                    alpha: 13,
                    beta: 13,
                    viewDistance: 25,
                    depth: 120
                }
            },


            title: {
                useHTML: true,
                text: 'DUMMY CODES'

            },
             
            credits: {
                
                  enabled: false
                
            },

            xAxis: {

                categories: $scope.dummyCodesCategories,
                labels: {
                    rotation: -45,
                    style: {
                        align: 'right',
                        color: '#7f8c8d',
                        fontFamily: 'Arial',
                        fontSize: '11px',
                        fontWeight: 'bold'
                    },
                    useHTML : true
                }
                
 
            },

            yAxis: {
                
                allowDecimals: true,
                
                gridLineWidth: 0,

                min: 0,
                
                offset: -30,
                
                labels: {
                    formatter: function () {
                    	var cFormat;
                        if ($scope.dummyCodesMillionFlag) {
                            cFormat = "M";
                            return this.value + cFormat;
                        } else {
                            cFormat = "k";
                            return (this.value / 1000) + cFormat;
                        }
                    },
                    useHTML : true,
                    style:{
                        color: '#7f8c8d',
                        fontFamily: 'Arial',
                        fontSize: '11px',
                        fontWeight: 'bold'
                    }
                },
                
                title: {     
                         useHTML: true,
                		 text:  $scope.dummyCodesTitleText,
                         style: {
                            color: '#333333',
                            fontFamily: 'Arial',
                            fontSize: '11px',
                            fontWeight: 'bold'
                        }                
                }
            },

            tooltip: {
                valueDecimals: 2,
                valueSuffix: '',
                useHTML: true,
                style : { opacity: 0.9 },
                formatter: function() {
                	var cFormat = "M", cValue = "$";
                    if ($scope.dummyCodesMillionFlag) {
                        return '<b>'+ this.x +'</b><br/>' + this.series.name +': '+ cValue + (this.y).toFixed(2)  + cFormat; 
                    } else {
                    	 return '<b>'+ this.x +'</b><br/>' + this.series.name +': '+ cValue + (this.y).toFixed(2);
                    }

                }

            },

            plotOptions: {
                
                series: {
                    
                    cursor: 'pointer',
                    
                    pointWidth: 40,
                    
                    pointPadding: 10,
                    
                    point: {
				        events: {
                            click: function () {
                            	if($scope.getCurrentWeek === parseInt($rootScope.selectionFilterData.week)) { 
                                    modalList.style.display = "block";
                                    if(this.category === "CTOB") {
                                        this.category = "CODE TO BE CREATED";
                                    } else if (this.category === "TOBEDEF") {
                                        this.category = "ITEM TO BE DEFINED";
                                    } else if (this.category === "ORDACK") {
                                        this.category = "ORDER ACKNOWLEDGEMENT";
                                    } 
                                    
                                    $scope.tableFilter(this.series.name, "INCOMING", dummyChart.title.textStr, this.category, "", "ALL");
                                }
                                
                            }
                        }
                    }
                    
			    },

                column: {
                    
                    size:'100%',
                    
                    stacking: true,
                    
                    grouping: false,
                    
                    groupZPadding: 100,
                    
                    shadow: false,
                    
                    depth: 40,

                    dataLabels: {

                        enabled: false,

                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
                        
                        formatter: function () {
                            if(this.y > 0) {
                                return Highcharts.numberFormat(this.y,2);
                            }
                        }

                    }

                }

            },
            
            series: $scope.dummyCodesChart,
            
            responsive: {
                rules: [{
                    condition: {
                        maxWidth: 245
                    },
                    chartOptions: {
                        chart: {
                            height: 200
                        },
                        column: {
                            size:'100%',
                            stacking: true,
                            grouping: false,
                            groupZPadding: 10,
                            shadow: false,
                            depth: 10
                        },
                        legend: {
                            align: 'center',
                            verticalAlign: 'bottom',
                            layout: 'horizontal'
                        },
                        yAxis: {
                            labels: {
                                align: 'left',
                                x: 0,
                                y: -5
                            },
                            title: {
                                text: null
                            }
                        },
                        subtitle: {
                            text: null
                        },
                        credits: {
                            enabled: false
                        }
                    }
                }]
            }
            
        });
        
        Highcharts.setOptions({lang: {noData: "No Data Available!"}, noData: {useHTML: true}});
        promiseChart = new Highcharts.Chart({
            
            chart: {
                renderTo: 'prmiseDateChart',
                type: 'column',
                marginLeft: 15,
                marginRight: -5,
                marginTop: 30,
                marginBottom: 10,
                width: $scope.lChartWidth,
                height: $scope.lChartHeight,
                options3d: {
                    enabled: true,
                    alpha: 13,
                    beta: 13,
                    viewDistance: 25,
                    depth: 120
                }
            },


            title: {
                useHTML: true,
                text: 'PROMISE DATE'

            },
             
            credits: {
                
                  enabled: false
                
            },

            xAxis: {

                categories: $scope.promiseDateCategories,
                labels: {
                    rotation: -45,
                    style: {
                        align: 'right',
                        color: '#7f8c8d',
                        fontFamily: 'Arial',
                        fontSize: '11px',
                        fontWeight: 'bold'
                    },
                    useHTML : true
                }
                
 
            },

            yAxis: {
                
                allowDecimals: true,
                
                gridLineWidth: 0,

                min: 0,
                
                offset: -30,
                
                labels: {
                    formatter: function () {
                    	var cFormat;
                        if ($scope.promiseDateMillionFlag) {
                            cFormat = "M";
                            return this.value + cFormat;
                        } else {
                            cFormat = "k";
                            return (this.value / 1000) + cFormat;
                        }
                    },
                    useHTML : true,
                    style:{
                        color: '#7f8c8d',
                        fontFamily: 'Arial',
                        fontSize: '11px',
                        fontWeight: 'bold'
                    }
                },
                
                title: {
                         useHTML: true,
                		 text:  $scope.promiseDateTitleText,
                         style: {
                            color: '#333333',
                            fontFamily: 'Arial',
                            fontSize: '11px',
                            fontWeight: 'bold'
                        }                
                }
            },

            tooltip: {
                valueDecimals: 2,
                valueSuffix: '',
                useHTML: true,
                style : { opacity: 0.9 },
                formatter: function() {
                	var cFormat = "M", cValue = "$";
                    if ($scope.promiseDateMillionFlag) {
                        return '<b>'+ this.x +'</b><br/>' + this.series.name +': '+ cValue + (this.y).toFixed(2)  + cFormat; 
                    } else {
                    	 return '<b>'+ this.x +'</b><br/>' + this.series.name +': '+ cValue + (this.y).toFixed(2);
                    }

                }

            },

            plotOptions: {
                
                series: {
                    
                    cursor: 'pointer',
                    
                    pointWidth: 40,
                    
                    pointPadding: 10,
                    
                    point: {
				        events: {
                            click: function () {
                            	if($scope.getCurrentWeek === parseInt($rootScope.selectionFilterData.week)) { 
                                    modalList.style.display = "block";
                                    $scope.tableFilter(this.series.name, "INCOMING", promiseChart.title.textStr, this.category, "", "ALL");
                                }
                                
                            }
                        }
                    }
                    
			    },

                column: {
                    
                    size:'100%',
                    
                    stacking: true,
                    
                    grouping: false,
                    
                    groupZPadding: 100,
                    
                    shadow: false,
                    
                    depth: 40,

                    dataLabels: {

                        enabled: false,

                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
                        
                        formatter: function () {
                            if(this.y > 0) {
                                return Highcharts.numberFormat(this.y,2);
                            }
                        }

                    }

                }

            },
            
            series: $scope.promiseDateChart,
            
            responsive: {
                rules: [{
                    condition: {
                        maxWidth: 240
                    },
                    chartOptions: {
                        chart: {
                            height: 200
                        },
                        subtitle: {
                            text: null
                        },
                        navigator: {
                            enabled: false
                        }
                    }
                }]
            }
            
        });
        
        Highcharts.setOptions({lang: {noData: "No Data Available!"}, noData: {useHTML: true}});
        cwdChart = new Highcharts.Chart({
            
            chart: {
                renderTo: 'cwdExpiredChart',
                type: 'column',
                marginLeft: 35,
                marginRight: -5,
                marginTop: 30,
                marginBottom: 10,
                width: $scope.lChartWidth,
                height: $scope.lChartHeight,
                options3d: {
                    enabled: true,
                    alpha: 13,
                    beta: 13,
                    viewDistance: 25,
                    depth: 120
                }
            },


            title: {
                useHTML: true,
                text: 'CWD EXPIRED'

            },
             
            credits: {
                
                  enabled: false
                
            },

            xAxis: {

                categories: $scope.cwdExpiredCategories,
                labels: {
                    rotation: -45,
                    style: {
                        align: 'right',
                        color: '#7f8c8d',
                        fontFamily: 'Arial',
                        fontSize: '11px',
                        fontWeight: 'bold'
                    },
                    useHTML : true
                }
                
 
            },

            yAxis: {
                
                allowDecimals: true,
                
                gridLineWidth: 0,

                min: 0,
                
                offset: -20,
                
                labels: {
                    formatter: function () {
                    	var cFormat;
                        if ($scope.cwdExpiredMillionFlag) {
                            cFormat = "M";
                            return this.value + cFormat;
                        } else {
                            cFormat = "k";
                            return (this.value / 1000) + cFormat;
                        }
                    },
                    useHTML : true,
                    style:{
                        color: '#7f8c8d',
                        fontFamily: 'Arial',
                        fontSize: '11px',
                        fontWeight: 'bold'
                    }
                },
                
                title: {
                         useHTML: true,    
                		 text:  $scope.cwdExpiredTitleText,
                         style: {
                            color: '#333333',
                            fontFamily: 'Arial',
                            fontSize: '11px',
                            fontWeight: 'bold'
                        }                
                }
            },

            tooltip: {
                valueDecimals: 2,
                valueSuffix: '',
                useHTML: true,
                style : { opacity: 0.9 },
                formatter: function() {
                	var cFormat = "M", cValue = "$";
                    if ($scope.cwdExpiredMillionFlag) {
                        return '<b>'+ this.x +'</b><br/>' + this.series.name +': '+ cValue + (this.y).toFixed(2)  + cFormat; 
                    } else {
                    	return '<b>'+ this.x +'</b><br/>' + this.series.name +': '+ cValue + (this.y).toFixed(2);
                    }

                }

            },

            plotOptions: {
                
                series: {
                    
                    cursor: 'pointer',
                    
                    pointWidth: 40,
                    
                    pointPadding: 10,
                    
                    point: {
				        events: {
                            click: function () {
                            	if($scope.getCurrentWeek === parseInt($rootScope.selectionFilterData.week)) {
                                    modalList.style.display = "block";
                                    $scope.tableFilter(this.series.name, "INCOMING", cwdChart.title.textStr, this.category, "", "ALL");
                                }
                                
                            }
                        }
                    }
                    
			    },

                column: {
                    
                    size:'100%',
                    
                    stacking: true,
                    
                    grouping: false,
                    
                    groupZPadding: 100,
                    
                    shadow: false,
                    
                    depth: 40,

                    dataLabels: {

                        enabled: false,

                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
                        
                        formatter: function () {
                            if(this.y > 0) {
                                return Highcharts.numberFormat(this.y,2);
                            }
                        }

                    }

                }

            },
            
            series: $scope.cwdExpiredChart,
            
            responsive: {
                rules: [{
                    condition: {
                        maxWidth: 240
                    },
                    chartOptions: {
                        chart: {
                            height: 200
                        },
                        subtitle: {
                            text: null
                        },
                        navigator: {
                            enabled: false
                        }
                    }
                }]
            }
            
        });
        
        Highcharts.seriesTypes.column.prototype.pointAttrToOptions.dashstyle = 'dashStyle';
        Highcharts.setOptions({lang: {noData: "No Data Available!"}, noData: {useHTML: true}});
        financialViewChart = new Highcharts.Chart({
            
            chart: {
                renderTo: 'financialViewChart',
                type: 'column',
                marginLeft: 10,
                marginRight: -30,
                marginTop: 30,
                marginBottom: 50,
                width: $scope.rChartWidth,
                height: $scope.rChartHeight,
                options3d: {
                    enabled: true,
                    alpha: 13,
                    beta: 13,
                    viewDistance: 25,
                    depth: 120
                }
            },

            title: {
                useHTML: true,
                text: 'Financial View'

            },
             
            credits: {
                
                  enabled: false
                
            },

            xAxis: {

                categories: $scope.financialViewCategories,
                labels: {
                    rotation: -45,
                    style: {
                        align: 'right',
                        color: '#7f8c8d',
                        fontFamily: 'Arial',
                        fontSize: '11px',
                        fontWeight: 'bold'
                    },
                    useHTML : true
                }
 
            },

            yAxis: {
                
                allowDecimals: true,
                
                gridLineWidth: 0,

                min: 0,
                
                labels: {
                    formatter: function () {
                    	var cFormat;
                        if ($scope.financialViewMillionFlag) {
                            cFormat = "M";
                            return this.value + cFormat;
                        } else {
                            cFormat = "k";
                            return (this.value / 1000) + cFormat;
                        }
                    },
                    useHTML : true,
                    style:{
                        color: '#7f8c8d',
                        fontFamily: 'Arial',
                        fontSize: '11px',
                        fontWeight: 'bold'
                    }
                },
                
                title: {
                         useHTML: true,
                		 text:  $scope.financialViewTitleText,
                         style: {
                            color: '#333333',
                            fontFamily: 'Arial',
                            fontSize: '11px',
                            fontWeight: 'bold'
                        }
                }
            },

            tooltip: {
                valueDecimals: 2,
                valueSuffix: '',
                useHTML: true,
                style : { opacity: 0.9 },
                formatter: function() {
                	var cFormat = "M", cValue = "$";
                    if ($scope.financialViewMillionFlag) {
                        return '<b>'+ this.x +'</b><br/>' + this.series.name +': '+ cValue + (this.y).toFixed(2)  + cFormat;
                    } else {
                    	 return '<b>'+ this.x +'</b><br/>'+
                         this.series.name +': '+ cValue + (this.y).toFixed(2);
                    }

                }

            },

            plotOptions: {
                
                series: {
                    
                    cursor: 'pointer',
                    
//                    pointWidth: 40,
//                    
//                    pointPadding: 10,
                    
                    dataLabels: {
                        overflow: false,
                        crop: false,
                        useHTML : true,
                        color: 'rgba(255, 255, 255, 0.7)',
                        borderRadius: 5,
                        backgroundColor: 'rgba(112, 48, 160, 0.7)',
                        borderWidth: 1,
                        borderColor: 'rgba(112, 48, 160, 1)',
                        verticalAlign: 'top',
                        y: -40,
                        formatter: function() {
                            if ($scope.financialViewMillionFlag) {
                                return (this.y).toFixed(2);
                            } else {
                                 
                                 return (this.y / 1000).toFixed(2);
                            }
                        },
                        style: {
                            fontFamily: 'Arial',
                            fontSize: '10px',
                            fontWeight: 'bold'
                        }
                    },
                    
                    point: {
				        events: {
                            click: function () {
                            	if($scope.getCurrentWeek === parseInt($rootScope.selectionFilterData.week)) { 
                                    modalList.style.display = "block";
                                    $scope.tableFilter(this.series.name, this.category, financialViewChart.title.textStr, "NULL_DAY_RANGE", "", "ALL");
                                }
                            }
                        }
                    }
                    
			    },

                column: {
                    
                    size:'100%',
                    
                    stacking: true,
                    
                    grouping: false,
                    
                    groupZPadding: 30,
                    
                    shadow: false,
                    
                    depth: 40,

                    dataLabels: {

                        enabled: false,

                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
                        
                        formatter: function () {
                            if(this.y > 0) {
                                return Highcharts.numberFormat(this.y,2);
                            }
                        }

                    }

                }

            },
            
            series: $scope.financialViewChart,
            
            responsive: {
                rules: [{
                    condition: {
                        maxWidth: 500
                    },
                    chartOptions: {
                        chart: {
                            height: 300
                        },
                        subtitle: {
                            text: null
                        },
                        navigator: {
                            enabled: false
                        }
                    }
                }]
            }
            
        });
        
    });
    
    $("#pmTrendCurrentTable").append('<tfoot><tr><th style="text-align:center">Total</th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th></tr></tfoot>');
    
    $("#pmTrendCurrentTable").DataTable({
        rowReorder: {
            selector: 'td:nth-child(2)'
        },
        responsive: responsive,
        data:$scope.arrPMTrendCurrentData,
        "bInfo" : false,
        "bPaginate": false, 
        "bFilter":false,
        "retrieve": true,
        "order":[],
        "aoColumnDefs": [
            { "sClass": "header_class", "aTargets": [ 0 ] },
            {
                "render": function ( data, type, row ) {
                    if(data !== "") {
                    	if($scope.chartDataMillionFlag)
                    		return '$'+ data +'M';
                    	else
                    		 return '$'+ data;
                    } else {
                        return '';
                    }
                },
                "aTargets": [ 1 ]
            },
            {
                "render": function ( data, type, row ) {
                    if(data !== "") {
                    	if($scope.chartDataMillionFlag)
                    		return '$'+ data +'M';
                    	else
                    		 return '$'+ data;
                    } else {
                        return '';
                    }
                },
                "aTargets": [ 2 ]
            },
            {
                "render": function ( data, type, row ) {
                    if(data !== "") {
                    	if($scope.chartDataMillionFlag)
                    		return '$'+ data +'M';
                    	else
                    		 return '$'+ data;
                    } else {
                        return '';
                    }
                },
                "aTargets": [ 3 ]
            },
            {
                "render": function ( data, type, row ) {
                    if(data !== "") {
                    	if($scope.chartDataMillionFlag)
                    		return '$'+ data +'M';
                    	else
                    		 return '$'+ data;
                    } else {
                        return '';
                    }
                },
                "aTargets": [ 4 ]
            },
            {
                "render": function ( data, type, row ) {
                    if(data !== "") {
                    	if($scope.chartDataMillionFlag)
                    		return '$'+ data +'M';
                    	else
                    		 return '$'+ data;
                    } else {
                        return '';
                    }
                },
                "aTargets": [ 5 ]
            }
        ],
         "columns": [{ data:"rowLabels",title:"Parts Status"},
                     { data:"foreCastedSum", title:"Forecasted"},
                     { data:"addedSum",title:"Added"},
                     { data:"removedSum",title:"Removed"},
                     { data:"newForeCastSum",title:"New Forecast"},
                     { data:"grandTotal",title:"Grand Total", "visible":false}],
        "footerCallback": function ( row, data, start, end, display ) {
            var api = this.api();

            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };

            var foreCastedTotal = api
                .column( 1 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );

            if($scope.chartDataMillionFlag){
	            $( api.column( 1 ).footer() ).html(
	                '$' + foreCastedTotal.toFixed(2) + 'M'
	            );
            }
            else{
            	$( api.column( 1 ).footer() ).html(
                        '$' + foreCastedTotal
                    );
            }
            	

            var addedTotal = api
                .column( 2 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            if($scope.chartDataMillionFlag){
	            $( api.column( 2 ).footer() ).html(
	                '$' + addedTotal.toFixed(2) + 'M'
	            );
            }else{
            	 $( api.column( 2 ).footer() ).html(
                         '$' + addedTotal
                     );
            }
            
            var removedTotal = api
                .column( 3 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            if($scope.chartDataMillionFlag){
	            $( api.column( 3 ).footer() ).html(
	                '$' + removedTotal.toFixed(2) + 'M'
	            );
            }else{
            	  $( api.column( 3 ).footer() ).html(
      	                '$' + removedTotal
      	            );
            }
            
            var newForeCastedTotal = api
                .column( 4 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            if($scope.chartDataMillionFlag){
		            $( api.column( 4 ).footer() ).html(
		                '$' + newForeCastedTotal.toFixed(2) + 'M'
		            );
            }else{  $( api.column( 4 ).footer() ).html(
                '$' + newForeCastedTotal
            );
            }

            var grandTotal = api
                .column( 5 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            if($scope.chartDataMillionFlag){
            	$( api.column( 5 ).footer() ).html(
                        '$' +grandTotal.toFixed(2) + 'M'
                 );
            }else{
            	$( api.column( 5 ).footer() ).html(
                        '$' +grandTotal
                    );
            }
            
        }
    });
    
    
    $("#pmTrendFutureTable").append('<tfoot><tr><th style="text-align:center">Total</th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th></tr></tfoot>');
    
    $("#pmTrendFutureTable").DataTable({
        rowReorder: {
            selector: 'td:nth-child(2)'
        },
        responsive: responsive,
        data:$scope.arrPMTrendFutureData,
        "bInfo" : false,
        "bPaginate": false, 
        "bFilter":false,
        "retrieve": true,
        "order":[],
        "aoColumnDefs": [
            { "sClass": "header_class", "aTargets": [ 0 ] },
            {
                "render": function ( data, type, row ) {
                    if(data !== "") {
                    	if($scope.chartDataMillionFlag)
                    		return '$'+ data +'M';
                    	else
                    		 return '$'+ data;
                    } else {
                        return '';
                    }
                },
                "aTargets": [ 1 ]
            },
            {
                "render": function ( data, type, row ) {
                    if(data !== "") {
                    	if($scope.chartDataMillionFlag)
                    		return '$'+ data +'M';
                    	else
                    		 return '$'+ data;
                    } else {
                        return '';
                    }
                },
                "aTargets": [ 2 ]
            },
            {
                "render": function ( data, type, row ) {
                    if(data !== "") {
                    	if($scope.chartDataMillionFlag)
                    		return '$'+ data +'M';
                    	else
                    		 return '$'+ data;
                    } else {
                        return '';
                    }
                },
                "aTargets": [ 3 ]
            },
            {
                "render": function ( data, type, row ) {
                    if(data !== "") {
                    	if($scope.chartDataMillionFlag)
                    		return '$'+ data +'M';
                    	else
                    		 return '$'+ data;
                    } else {
                        return '';
                    }
                },
                "aTargets": [ 4 ]
            },
            {
                "render": function ( data, type, row ) {
                    if(data !== "") {
                    	if($scope.chartDataMillionFlag)
                    		return '$'+ data +'M';
                    	else
                    		 return '$'+ data;
                    } else {
                        return '';
                    }
                },
                "aTargets": [ 5 ]
            }
        ],
         "columns": [{ data:"rowLabels",title:"Parts Status"},
                     { data:"foreCastedSum", title:"Forecasted"},
                     { data:"addedSum",title:"Added"},
                     { data:"removedSum",title:"Removed"},
                     { data:"newForeCastSum",title:"New Forecast"},
                     { data:"grandTotal",title:"Grand Total", "visible":false}],
        "footerCallback": function ( row, data, start, end, display ) {
            var api = this.api();

            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };

            var foreCastedTotal = api
                .column( 1 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            if($scope.chartDataMillionFlag){
	            $( api.column( 1 ).footer() ).html(
	                '$' + foreCastedTotal.toFixed(2) + 'M'
	            );
            }else{
            	 $( api.column( 1 ).footer() ).html(
                         '$' + foreCastedTotal
                     );
            }
            var addedTotal = api
                .column( 2 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            if($scope.chartDataMillionFlag){
	            $( api.column( 2 ).footer() ).html(
	                '$' + addedTotal.toFixed(2) + 'M'
	            );
            }else{
            	$( api.column( 2 ).footer() ).html(
                        '$' + addedTotal
                    );
            }
            var removedTotal = api
                .column( 3 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            if($scope.chartDataMillionFlag){
	            $( api.column( 3 ).footer() ).html(
	                '$' + removedTotal.toFixed(2) + 'M'
	            );
            }else{
            	   $( api.column( 3 ).footer() ).html(
                           '$' + removedTotal
                       );
            }
            var newForeCastedTotal = api
                .column( 4 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            if($scope.chartDataMillionFlag){
	            $( api.column( 4 ).footer() ).html(
	                '$' + newForeCastedTotal.toFixed(2) + 'M'
	            );
            }else{
            	 $( api.column( 4 ).footer() ).html(
     	                '$' + newForeCastedTotal
     	            );
            }

            var grandTotal = api
                .column( 5 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            if($scope.chartDataMillionFlag){
	            $( api.column( 5 ).footer() ).html(
	                '$' +grandTotal.toFixed(2) + 'M'
	            );
            }else{
            	$( api.column( 5 ).footer() ).html(
                        '$' +grandTotal
                    );
            }
        }
    });
    
    
    if($scope.hideForeCast === true) {
        $('#pmTrendCurrentTable').DataTable().columns( [ 1, 4 ] ).visible( false, true );
        $('#pmTrendCurrentTable').DataTable().columns.adjust().draw( false );
        
        $('#pmTrendFutureTable').DataTable().columns( [ 1, 4 ] ).visible( false, true );
        $('#pmTrendFutureTable').DataTable().columns.adjust().draw( false );
    } else {
        $('#pmTrendCurrentTable').DataTable().columns.adjust().draw( false );
        $('#pmTrendFutureTable').DataTable().columns.adjust().draw( false );
    }
    
    $scope.tableFilter = function (sales_year_qtr,parts_status,chart_type,day_range,p_r_by_o) {
        
        $scope.iPMLoader    = true;
        $scope.itemSelected = p_r_by_o;
        
        var tempPandL       = "";
        
        if ($.fn.DataTable.isDataTable( '#pmoPartsTable' ) ) {
            $("#pmoPartsTable").dataTable().api().clear().draw();
            $("#pmoPartsTable").dataTable().api().destroy();
            $('#pmoPartsTable').empty(); 
        }
        
        if (!$rootScope.selectionFilterData) {
            $rootScope.selectionFilterData ={};
        } else if($rootScope.selectionFilterData.pandL){
            tempPandL = $rootScope.selectionFilterData.pandL;
        }
        
        $rootScope.selectionFilterData.pandL          = "";
        $rootScope.selectionFilterData.Manager 		  = "";
        $rootScope.selectionFilterData.sales_year_qtr = sales_year_qtr;
        $rootScope.selectionFilterData.parts_status   = parts_status;
        $rootScope.selectionFilterData.chart_type     = chart_type;
        $rootScope.selectionFilterData.day_range      = day_range;
        $rootScope.selectionFilterData.p_r_by_o       = p_r_by_o;
        $rootScope.selectionFilterData.projectManager = $rootScope.selectionFilterData.projectManager ? $rootScope.selectionFilterData.projectManager : "";
        IPMService.getPMChartData(JSON.stringify($rootScope.selectionFilterData)).then(function (response){
        	
            $rootScope.safeApply(function(){
                $rootScope.PMTRENDChartData = response;  
                if(!$scope.checkError($rootScope.PMTRENDChartData)){
                    
                    if(day_range !== "NULL_DAY_RANGE") {
                        $scope.partsDataHeaderName = chart_type +' - '+ parts_status +' ('+day_range+')';
                    } else {
                        $scope.partsDataHeaderName = chart_type +' - '+ parts_status;
                    }
                    
                    $scope.chartType = chart_type;
                    
                    if (tempPandL) {
                        $rootScope.selectionFilterData.pandL  =  tempPandL;
                    } else {
                        $rootScope.selectionFilterData.pandL  =  null;
                    }
                    
                    $scope.customizedData          = $rootScope.PMTRENDChartData.tableData;
                    $scope.customizedColumnHeaders = $rootScope.PMTRENDChartData.tableColumnHeaders;
                    $scope.customizedHeaders       = $rootScope.PMTRENDChartData.tableColumnHeaders;
                    $scope.PMOPPartsDropdownData   = _.sortBy(_.uniq($rootScope.PMTRENDChartData.projectManager), 
                                                     function(projectManager) {
                                                        return projectManager;
                                                     });
                    
                    if(chart_type === "Financial View" && $scope.PMOPartsStatusDropdownData === undefined) {
                    	$scope.PMOPartsStatusDropdownData = _.sortBy($rootScope.PMTRENDChartData.parts_status);
                    }

                    var columns        = [];
                    var redCircle      = '<img src="../images/red.png">';
                    var yellowCircle   = '<img src="../images/yellow.png">';
                    var greenCircle    = '<img src="../images/green.png">';
                    var currentCircle  = '<div class="circle_normal circle_G" style="width:24px;height:24px;font-weight:bold;border-radius:50%;text-align:center;margin:auto!important;padding:2px;color:#9cba5b;font-size:13px;background:url(../images/current.png);cursor:pointer;background-repeat:no-repeat;">C</div>';
                    var futureCircle   = '<div class="circle_normal circle_G" style="width:24px;height:24px;font-weight:bold;border-radius:50%;text-align:center;margin:auto!important;padding:2px;color:#bfbfbf;font-size:13px;background:url(../images/future.png);cursor:pointer;background-repeat:no-repeat;">F</div>';
                    var good           = '<img src="../images/good.png">';
                    var flat           = '<img src="../images/flat.png">';
                    var bad            = '<img src="../images/critical.png">';
                    var exhWB          = '<img src="../images/green-check-mark.png">';
                    
                    $scope.arrPMTRENDDataTableHeaders = [{ data:"concatenate",title:"Concatenate" }];
                    
                    if(sales_year_qtr === "FORECASTED" || sales_year_qtr === "UNCONFIRMED" || sales_year_qtr === "CONFIRMED") {
                    	parts_status = $scope.selectionFilterData.financial_parts_status;
                	} 
                    
                    if (parts_status === "INCOMING" || parts_status === "AVAILABLE" || parts_status === "BLANK") {
                        $scope.arrPMTRENDDataTableHeaders.push(
                            { data:"line_id",title:"Line ID"},
                            { data:"item_code",title:"Item Code"},
                            { data:"item_description",title:"Item Description"},
                            { data:"po_promise_date",title:"Promise Date"}
                        );
                    } else if (parts_status === "PACKING") {
                        $scope.arrPMTRENDDataTableHeaders.push(
                            { data:"line_id",title:"Line ID"},
                            { data:"item_code",title:"Item Code"},
                            { data:"item_description",title:"Item Description"}
                        ); 
                    } else if (parts_status === "BILLING" || parts_status === "SHIPPING" || parts_status === "SHIPPED") {
                        $scope.arrPMTRENDDataTableHeaders.push(
                            { data:"box_number",title:"Box ID"},
                            { data:"enduser_cust_name",title:"End User Customer Name"}
                        );
                    } else if (parts_status === "SALES") {
                        $scope.arrPMTRENDDataTableHeaders.push(
                            { data:"invoice_number",title:"Invoice Number"},
                            { data:"enduser_cust_name",title:"End User Customer Name"}
                        ); 
                    }
                            
                    $scope.arrPMTRENDDataTableHeaders.push(
                        { data:"p_cm_dollar_by_1000",title:"CM$/1000", className: "defaultSort"},
                        { data:"p_r_by_o",title:"Risk/Opps","visible":false}
                    ); 
                    
                    $scope.arrPMTRENDDataTableHeaders.push({ 
                        data:"b_tool",
                        title:"BTOOL",
                        "mData": null,
                        "render": function (data, type, full, meta) {
                            if (data) {
                                if (data.b_tool === 'GREEN') {
                                   return currentCircle;
                                }
                                if(data.b_tool === 'GREY') {
                                   return futureCircle;
                                }
                            } else {
                                return data;
                            }
                         }
                    });
                    
                    $scope.arrPMTRENDDataTableHeaders.push({ 
                        data:"exh_wb",
                        title:"EXH. WB",
                        "mData": null,
                        "render": function (data, type, full, meta) {
                            if (data) {
                                if (data.p_new_date !== null) {
                                   return exhWB;
                                }
                            } else {
                                return data;
                            }
                         }
                    });
                    
                    if (p_r_by_o === "RISK") {
                        $scope.arrPMTRENDDataTableHeaders.push(
                            { 
                                data:"p_status",
                                title:"Status",
                                "visible":false,
                                "render": function (data, type, full, meta) {
                                    if (data) {
                                        if (data.toUpperCase().trim()==='LOW') {
			            		           return greenCircle;
                                        }
			            	            if(data.toUpperCase().trim()==='MEDIUM') {
			            		           return yellowCircle;
                                        }
			            	            if(data.toUpperCase().trim()==='HIGH') {
			            		           return redCircle;
                                        }
                                    } else {
                                        return data;
                                    }
			                     }
                            },
                            {
                                data:"p_trend",
                                title:"Trend",
                                "visible":false,
                                "render": function (data, type, full, meta) {
                                    if (data) {
                                        if (data.toUpperCase().trim()==='GOOD') {
			            		           return good;
                                        } else if (data.toUpperCase().trim()==='FLAT') {
			            		           return flat;
                                        } else if (data.toUpperCase().trim()==='BAD') {
			            		           return bad;
                                        }
                                    } else { 
                                        return data;
                                    }
                          	     }
                            }
                        );
                    } else if (p_r_by_o === "OPPS" || p_r_by_o === "NULL_PRBYO") {
                        $scope.arrPMTRENDDataTableHeaders.push(
                            {
                                data:"p_status",
                                title:"Status",
                                "visible":false,
                                "render": function (data, type, full, meta) {
                                    if (data) {
                                        if (data.toUpperCase().trim()==='LOW') {
                                           return redCircle;
                                        } 
                                        if (data.toUpperCase().trim()==='MEDIUM') {
                                           return yellowCircle;
                                        } 
                                        if (data.toUpperCase().trim()==='HIGH') {
                                           return greenCircle;
                                        }
                                    } else {
                                        return data;
                                    }
                                }
                            },
                            {
                                data:"p_trend",
                                title:"Trend",
                                "visible":false,
                                "render": function (data, type, full, meta) {
			            	        if (data) {
                                        if(data.toUpperCase().trim()==='GOOD') {
			            		           return good;
                                        } else if (data.toUpperCase().trim()==='FLAT') {
			            		           return flat;
                                        } else if (data.toUpperCase().trim()==='BAD') {
			            		           return bad;
                                        }
                                    } else {
                                        return data;
                                    }
                          	     }
                            }
                        );
                    }
                        
                    if (parts_status === "INCOMING" || parts_status === "AVAILABLE" || parts_status === "BLANK" || parts_status === "PACKING") {
                        $scope.arrPMTRENDDataTableHeaders.push(
                            { data:"p_note",title:"Note","visible":false},
                            { data:"p_due_date",title:"Due Date","visible":false},
                            { data:"p_status_aging",title:"Aging Days","visible":false}
                        );
                    } else if (parts_status === "BILLING" || parts_status === "SHIPPING" || parts_status === "SHIPPED" || parts_status === "SALES") {
                        $scope.arrPMTRENDDataTableHeaders.push(
                            { data:"p_note",title:"Note","visible":false},
                            { 
                                data:"p_status_aging",
                                title:"Aging Days",
                                "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                                    
                                    var agingDays = sData === null ? '' : sData.trim().split(" ");
                                    
                                    if (agingDays[0] < 7) { 
                                    $(nTd).css('background-color', '#008000').css('color', '#FFFFFF').css('font-weight', 'bold'); 
                                    } else if (agingDays[0] >= 7 && agingDays[0] <= 14) { 
                                    $(nTd).css('background-color', '#CCCC00').css('color', '#FFFFFF').css('font-weight', 'bold'); 
                                    } else if (agingDays[0] > 14) {
                                    $(nTd).css('background-color', '#FF0000').css('color', '#FFFFFF').css('font-weight', 'bold'); 
                                    }
                                }
                            }
                        );
                    } 
                    
                    $scope.arrPMTRENDDataTableHeaders.push(
                        { data:"p_exp_fw_revrec",title:"Exp FW RevRec","visible":false},
                        { data:"p_exp_fw_revrec_firts_pl",title:"Exp FW RevRec_FIRST_PL","visible":false},
                        { data:"p_financial_basket",title:"Financial Basket","visible":false},
                        { data:"p_flow_or_no_flow",title:"FLow / No-flow","visible":false},
                        { data:"p_keydeals",title:"Key Deals","visible":false},
                        { data:"p_operational_basket",title:"Operational Basket","visible":false},
                        { data:"p_new_date",title:"New Date"},
                        { data:"p_wb_comment",title:"WB Comment"},
                        { data:"p_sum_cm",title:"sum CM","visible":false},
                        { data:"p_sum_sales",title:"sum sales","visible":false}
                    );
                    
                    for (var i = 0; i < $scope.customizedColumnHeaders.length; i++) {
                        columns[i] = {
                            'title': $scope.customizedColumnHeaders[i],
                            'data': $scope.customizedColumnHeaders[i]
                        }
                    };
                    
                    var dataTable = $('#pmoPartsTable').DataTable({
                        rowReorder: {
                            selector: 'td:nth-child(2)'
                        },
                        responsive: responsive,
                        "order": [[ "5", "desc" ]],
                        "columnDefs": [{
                            "defaultContent": "",
                            "targets": "_all"
                        }],
                        "bLengthChange": false,
                        "autoWidth": false,
                        "bSortClasses": false,
                        "sPaginationType": "full_numbers",
      	   				"bFilter":true, 
      	   				"retrieve": true, 
      	   			    "scrollX": false,
      	   				"paging": true,
                        "columns": $scope.arrPMTRENDDataTableHeaders,
                        "data": $scope.customizedData
                    });
                    
                    if ( dataTable.data().count() > 0 ) {
                       
                        $('body #pmoPartsTable tbody').on( 'click', 'tr', function () {
                            
                            var data              = dataTable.row(this).data();
                            var dataObject        = {};
                            $scope.mainDataObject = [];
                            $scope.failureMessage = "";
                            
                            _.forEach (data, function(value,key) {
                                
                                if (_.where(_.where($scope.customizedHeaders, {data: key}), {editable: "Y",type:'DropDown'}).length > 0) {

                                    _.forEach (_.where(_.where($scope.customizedHeaders, {data: key}), {editable: "Y",type:'DropDown'}),         function(value) {
                                        dataObject          = {};
                                        dataObject.id       = value.id;   
                                        dataObject.key      = value.data;                    
                                        dataObject.value    = value.title;
                                        dataObject.editable = value.editable;
                                        dataObject.type     = value.type;

                                        var str = value.values; 
                                        if (str) {
                                            dataObject.values = str.toString().split(",");
                                        }
                                        $scope.mainDataObject.push(dataObject);
                                    });
                                }
                                
                                if (_.where(_.where($scope.customizedHeaders, {data: key}), {editable: "Y",type:'DATE'}).length > 0) {

                                    _.forEach (_.where(_.where($scope.customizedHeaders, {data: key}), {editable: "Y",type:'DATE'}), function(value) {
                                        dataObject          = {};
                                        dataObject.id       = value.id;
                                        dataObject.key      = value.data;
                                        dataObject.value    = value.title;
                                        dataObject.editable = value.editable;
                                        dataObject.type     = value.type;
                                        dataObject.values   = value.values;
                                        $scope.mainDataObject.push(dataObject);
                                    });
                                }


                                if (_.where(_.where($scope.customizedHeaders, {data: key}), {editable: "Y",type:'FreeField'}).length > 0) {

                                    _.forEach (_.where(_.where($scope.customizedHeaders, {data: key}), {editable: "Y",type:'FreeField'}), function(value) {
                                        dataObject          = {};
                                        dataObject.id       = value.id;
                                        dataObject.key      = value.data;
                                        dataObject.value    = value.title;
                                        dataObject.editable = value.editable;
                                        dataObject.type     = value.type;
                                        dataObject.values   = value.values;
                                        $scope.mainDataObject.push(dataObject);
                                    });
                                }

                                if (_.where(_.where($scope.customizedHeaders, {data: key}), {editable: "N"}).length > 0) {

                                    _.forEach (_.where(_.where($scope.customizedHeaders, {data: key}), {editable: "N"}), function(value) {
                                        dataObject          = {};
                                        dataObject.id       = value.id;
                                        dataObject.key      = value.data;
                                        dataObject.value    = value.title;
                                        dataObject.editable = value.editable;
                                        dataObject.type     = value.type;
                                        dataObject.values   = value.values;
                                        $scope.mainDataObject.push(dataObject);
                                    });
                                }

                                if (_.where(_.where($scope.customizedHeaders, {data: key}), {editable: "D"}).length > 0) {

                                    _.forEach (_.where(_.where($scope.customizedHeaders, {data: key}), {editable: "D"}), function(value) {
                                        dataObject          = {};
                                        dataObject.id       = value.id;
                                        dataObject.key      = value.data;
                                        dataObject.value    = value.title;
                                        dataObject.editable = value.editable;
                                        dataObject.type     = value.type;
                                        dataObject.values   = value.values;
                                        $scope.mainDataObject.push(dataObject);
                                    });
                                }
                            });
                            $scope.mainDataObject = _.sortBy($scope.mainDataObject, 'id');
                            
                            $rootScope.safeApply(function() {
                                if (data.p_r_by_o) {
                                    if ((data.p_r_by_o).toUpperCase()==='RISK') {
                                        if (!data.p_status) {
					    data.p_status = "";

                                        } else if ((data.p_status).toUpperCase().includes("GREEN")) {
                                            data.p_status = 'Low';
                                        } else if ((data.p_status).toUpperCase().includes("YELLOW")) {
                                            data.p_status = 'Medium';
                                        } else if ((data.p_status).toUpperCase().includes("RED")) {
                                            data.p_status = 'High';
                                        }
                                    } else if ((data.p_r_by_o).toUpperCase()==='OPPS'){

                                        if (!data.p_status){ 
					    data.p_status = "";

                                        } else if ((data.p_status).toUpperCase().includes("GREEN")) {
                                            data.p_status ='High';
                                        } else if ((data.p_status).toUpperCase().includes("YELLOW")) {
                                            data.p_status ='Medium';
                                        } else if ((data.p_status).toUpperCase().includes("RED")) {
                                            data.p_status ='Low';
                                        }
                                    }
                                } else {
                                    if (!data.p_status) {
					data.p_status = "";

                                    } else if ((data.p_status).toUpperCase().includes("GREEN")) {
                                        data.p_status ='High';
                                    } else if ((data.p_status).toUpperCase().includes("YELLOW")) {
                                        data.p_status ='Medium';
                                    } else if ((data.p_status).toUpperCase().includes("RED")) {
                                        data.p_status ='Low';
                                    }
                                }

                                $scope.rowData = null;
                                $scope.rowData = [];
                                var dataObject = {};
                                _.forEach(data, function(value,key) {
                                    dataObject['key']   = key;
                                    dataObject['value'] = value;
                                    $scope.rowData.push(dataObject);
                                    dataObject = {};
                                });
                            });
                            
                            modalUpdate = document.getElementById('partsUpdateDataModal');
                            modalUpdate.style.display = "block";
                        });

                    }
                }
                $scope.iPMLoader = false;  
            });
        });
    };
    
    $scope.drawRawDataTable = function() {
        
        var currentCircle  = '<div class="circle_normal circle_G" style="width:24px;height:24px;font-weight:bold;border-radius:50%;text-align:center;margin:auto!important;padding:2px;color:#9cba5b;font-size:13px;background:url(../images/current.png);cursor:pointer;background-repeat:no-repeat;">C</div>';
        var futureCircle   = '<div class="circle_normal circle_G" style="width:24px;height:24px;font-weight:bold;border-radius:50%;text-align:center;margin:auto!important;padding:2px;color:#bfbfbf;font-size:13px;background:url(../images/future.png);cursor:pointer;background-repeat:no-repeat;">F</div>';
        var exhWB          = '<img src="../images/green-check-mark.png">';
        
        $scope.arrPMRawDataHeaders = [
            {
                data: "p_qmi",
                title: "QMI", 
                width: "10%",
                render: function ( data, type, row ) {
                    if ( type === 'display' ) {
                        return '<input type="checkbox" class="editor-active">';
                    }
                    return data;
                },
                className: "dt-body-center"
            },
            { data:"p_and_l", title:"P&L", width: "10%" },
            { data:"site", title:"Site", width: "10%" },
            { data:"product", title:"Product", width: "10%" },
            { data:"enduser_cust_name", title:"End User Customer", width: "10%" },
            { data:"mother_job", title:"CS Mother Job", width: "10%" },
            { data:"costing_project", title:"Costing Project", width: "10%" },
            { data:"customer_po_number", title:"Customer PO Number", width: "10%" },
            { data:"customer_po_amount", title:"PO Amount", width: "10%" },
            { data:"item_code", title:"Item Code", width: "10%" },
            { data:"item_description", title:"Item Description", width: "10%" },
            { data:"parts_status", title:"Parts Status", width: "10%" },
            { data:"so_line", title:"Line Number", width: "10%" },
            { data:"ordered_quantity", title:"QTY", width: "10%" },
            { data:"box_number", title:"Box ID", width: "10%" },
            { data:"invoice_number", title:"Invoice Number", width: "10%" },
            { data:"line_id", title:"Line ID", width: "10%" },
            { data:"current", title:"Current (CM$/1000)", width: "10%" },
            { data:"future", title:"Future (CM$/1000)", width: "10%" },
            { data:"sales_date", title:"Sales Date", width: "10%" },
            { data:"promise_date", title:"Promise Date", width: "10%" },
            { data:"concatenate", title:"Concatenate", width: "10%" }
        ];
        
        $scope.arrPMRawDataHeaders.push({ 
            data:"b_tool",
            title:"BTOOL",
            "mData": null,
            width: "10%",
            "render": function (data, type, full, meta) {
                if (data) {
                    if (data.b_tool === 'GREEN') {
                       return currentCircle;
                    }
                    if(data.b_tool === 'GREY') {
                       return futureCircle;
                    }
                } else {
                    return data;
                }
             }
        });

        $scope.arrPMRawDataHeaders.push({ 
            data:"exh_wb",
            title:"EXH. WB",
            "mData": null,
            width: "10%",
            "render": function (data, type, full, meta) {
                if (data) {
                    if (data.p_new_date !== null) {
                       return exhWB;
                    }
                } else {
                    return data;
                }
             }
        });
        
        $scope.arrPMRawDataHeaders.push(
            { data:"p_new_date", title:"New Date", width: "10%" },
            { data:"p_wb_comment", title:"WB Comment", width: "10%" }
        );
        $("#rawDataTable").DataTable({
            rowReorder: {
                selector: 'td:nth-child(2)'
            },
            responsive: responsive,
            "columnDefs": [{
                "defaultContent": "",
                "targets": "_all"
            }],
            "aaSorting": [],
            data: $rootScope.arrPMRawData,
            "columns": $scope.arrPMRawDataHeaders,
            select: {
                style: 'os',
                selector: 'td:not(:first-child)' // no row selection on last column
            },
            rowCallback: function ( row, data ) {
                // Set the checked state of the checkbox in the table
                $('input.editor-active', row).prop( 'checked', data.p_qmi === true );
            }
        });
        
        $('#rawDataTable tbody').on( 'change', 'input.editor-active', function () {
            var p_qmi_val = $(this).prop( 'checked' ) ? true : false;
            var data = $("#rawDataTable").dataTable().api().row($(this).parents('tr')).data();
            
            data.p_qmi = p_qmi_val;
            $scope.iPMLoader  = true;
            $scope.updateIPMRawData(data);
        } );
    }
    
    
    $scope.updateIPMRawData = function(data) {
        
        $scope.editedIPMRawData                 = {};
        $scope.editedIPMRawData.qmi             = data.p_qmi;
        $scope.editedIPMRawData.parts_status    = data.parts_status;
        $scope.editedIPMRawData.concatenate     = data.concatenate;
        $scope.editedIPMRawData.box_id          = data.box_number;
        $scope.editedIPMRawData.invoice_number  = data.invoice_number;
        
        
        
        IPMService.updateIPMPartsQmi(JSON.stringify($scope.editedIPMRawData)).then(function(response){
            $rootScope.safeApply(function() {
                if (response === "SUCCESS") {
                    $scope.loadIPMRawData();
                } else if (response === "FAILURE") {
                    $("#rawDataTable_length").after( '<div class="alert alert-danger fade in" style="width: 500px;height: 40px;margin-left: 75px;display: inline;position: absolute;padding-top: 11px;"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Error!</strong> A problem has been occurred while submitting your data.</div>' );
                }
                
                $timeout(function () {
                    $('.alert-danger').fadeOut('fast');  
                },5000);  
            });
        });
    }
    
    $scope.updateData = function() {

        $scope.editedData     = {};
        $scope.failureMessage = "";
        
        _.forEach($scope.rowData, function(data){
            if( !$('.'+data.key+'').val() || $('.'+data.key+'').val().startsWith("?")){
                $scope.editedData[data.key] = null;
            } else {    
                if($('#'+data.key+'').val().trim() === "") {
                    $scope.editedData[data.key] = null;
                } else {
                    $scope.editedData[data.key] = $('#'+data.key+'').val().trim();
                }
            }
        });
        
        if ($scope.editedData['p_new_date'] !== null && $scope.editedData['p_wb_comment'] === null) {
            $scope.updateSuccess  = false;
            $scope.updateFailure  = true;
            $scope.failureMessage = "Please Select WB Comment."
        } else if (!$scope.editedData['p_status']) {
            $scope.updateSuccess  = false;
            $scope.updateFailure  = true;
            $scope.failureMessage = "Please Select Status."
        } else {
        	if($rootScope.selectionFilterData.sales_year_qtr === "FORECASTED" || $rootScope.selectionFilterData.sales_year_qtr === "UNCONFIRMED" || $rootScope.selectionFilterData.sales_year_qtr === "CONFIRMED") {
        		$scope.editedData['parts_status'] = $rootScope.selectionFilterData.financial_parts_status;
        	} else {
        		$scope.editedData['parts_status'] = $rootScope.selectionFilterData.parts_status;
        	}
        	
            IPMService.updateIPMPartsRow(JSON.stringify($scope.editedData)).then(function(response) {
                
                $rootScope.safeApply(function() {
                    if (response === "UPDATED" || response === "SUCCESS") {
                        $scope.updateSuccess = true;
                        $scope.updateFailure = false;
                        
                        $scope.tableFilter(
                            $rootScope.selectionFilterData.sales_year_qtr,
                            $rootScope.selectionFilterData.parts_status,
                            $rootScope.selectionFilterData.chart_type,
                            $rootScope.selectionFilterData.day_range,
                            $rootScope.selectionFilterData.p_r_by_o
                        );
                        
                    } else if (response==="FAILURE") {
                        $scope.updateSuccess  = false;
                        $scope.updateFailure  = true;
                        $scope.failureMessage = "Something went wrong! Please try again later."
                    }

                    $timeout(function () {
                        $scope.updateFailure = false;   
                    },3000);  
                });
                
            });
        }
    };
    
    $scope.getPartStatusManager = function() {
        if($scope.selectionFilterData.financial_parts_status !== "") {
            $scope.partsSearchPanel.projectManager = $rootScope.selectionFilterData.projectManager ? $rootScope.selectionFilterData.projectManager : '';
            $scope.searchPmoParts();    
        }
    }
    
    $scope.refreshPM = function (){
        $scope.partsSearchPanel.projectManager = '';
        $scope.searchPmoParts();
    }; 
    
    $scope.selectPM = function (value){
        $scope.partsSearchPanel.projectManager = value;
        $scope.showPMvalues = true;

        $scope.searchPmoParts();
    }; 
    
    $scope.searchPmoParts = function() {
        
        if($scope.partsSearchPanel.projectManager === "" && $scope.chartType === "PMO - Trend") {
            $rootScope.selectionFilterData.p_r_by_o = "NULL_PRBYO";
        }
        
        //if (_.contains($scope.PMOPPartsDropdownData, $scope.partsSearchPanel.projectManager) || $scope.partsSearchPanel.projectManager === "") {
        	var projectManager = $scope.partsSearchPanel.projectManager ? $scope.partsSearchPanel.projectManager : '';
            $rootScope.selectionFilterData.projectManager = projectManager;
            $scope.tableFilter(
                $rootScope.selectionFilterData.sales_year_qtr,
                $rootScope.selectionFilterData.parts_status,
                $rootScope.selectionFilterData.chart_type,
                $rootScope.selectionFilterData.day_range,
                $rootScope.selectionFilterData.p_r_by_o
            ); 
        //}
    }

    $scope.hidePMvalues = function (){
        $timeout(function (){
            $scope.showPMvalues = false;
        },200);
    };
    
    $scope.onCategoryChange = function (itemSelected, isPMSelected) {
        
        if (isPMSelected === false) {
           var projectManager = $scope.partsSearchPanel.projectManager ? $scope.partsSearchPanel.projectManager : '';
           $rootScope.selectionFilterData.projectManager = projectManager;
        } 
        
        $scope.itemSelected = itemSelected;
        
        if($rootScope.selectionFilterData.p_r_by_o !== $scope.itemSelected && $scope.itemSelected !== "") { 
            $scope.tableFilter(
                $rootScope.selectionFilterData.sales_year_qtr,
                $rootScope.selectionFilterData.parts_status,
                $rootScope.selectionFilterData.chart_type,
                $rootScope.selectionFilterData.day_range,
                $scope.itemSelected
            );
        }
    };
    
    $scope.exportExcelPMOParts = function (){
        
        if ($scope.partsSearchPanel.projectManager === "" || $scope.partsSearchPanel.projectManager === undefined) {
            modalAlert = document.getElementById('partsDataAlertModal');
            modalAlert.style.display = "block";
        } else {
            
            $scope.iPMLoader = true;
            var urldata;
            
            if (!$rootScope.selectionFilterData) {
                $rootScope.selectionFilterData = {};
            }

            $rootScope.selectionFilterData.pandL = '';

            var projectManager = $scope.partsSearchPanel.projectManager ? $scope.partsSearchPanel.projectManager : '';
            $rootScope.selectionFilterData.projectManager = projectManager;

            var data = $rootScope.selectionFilterData;
            urldata="connect/fms/exportPMODrilDownData";
            download(urldata,data,'Ibas Dtl');    
        }
        
    }
    
    $scope.exportExcelRawData = function (){
        
        $scope.iPMLoader = true;
        var urldata;

        if (!$rootScope.selectionFilterData) {
            $rootScope.selectionFilterData = {};
        }

        $rootScope.selectionFilterData.pandL = '';

        var data = $rootScope.selectionFilterData;
        urldata="connect/fms/exportIPMRawData";
        download(urldata,data,'IPM Raw Data');    
    }


    function download(url,data ,defaultFileName) {
        var deferred = $q.defer();
        $http.post(url,data, { responseType: "arraybuffer" }).success(
            function (data, status, headers) {
                var type = headers('Content-Type');
                var disposition = headers('Content-Disposition');
                if (disposition) {
                    var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                    if (match[1])
                        defaultFileName = match[1];
                }
                defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                var blob = new Blob([data], { type: type });
                saveAs(blob, defaultFileName);
                deferred.resolve(defaultFileName);  
                $scope.iPMLoader = false;
            }).error(function () {
                var e ;
                deferred.reject(e);
            });
        return deferred.promise;
    } 
    
    $scope.exportChartPMTREND1 = function (ids){
        //Highcharts.exportCharts([chart, boxChart, dummyChart, promiseChart, cwdChart]);
        //chart.exportChart({type: 'image/jpeg', filename: 'PMO - TREND'}, {subtitle: {text:''}});
        
        //        html2canvas(document.querySelector('.specific'), {
        //            onrendered: function(canvas) {
        //                // document.body.appendChild(canvas);
        //              return Canvas2Image.saveAsPNG(canvas);
        //            }
        //        });
    };
    
    function styleToSVGText  () {
        var SVGTextArr = $('svg span');
        SVGTextArr.each(function (i, item) {
            $(item).css({
                'text-rendering': 'optimizeLegibility',
                'font-weight': 'bold',
                'text-shadow': 'transparent'
            })
        });
    };
    
    $scope.exportChartPMTREND = function (){
        
        var targetElem = $("#pmo-html-content-holder");
        var nodesToRecover = [];
        var nodesToRemove = [];
        styleToSVGText();
        var svgElem = targetElem.find('svg');
        
        svgElem.each(function(index, node) {
            var parentNode = node.parentNode;
            var svg = parentNode.innerHTML;
            var canvas = document.createElement('canvas');

            canvg(canvas, svg);

            nodesToRecover.push({
                parent: parentNode,
                child: node
            });
            //parentNode.removeChild(node);

            nodesToRemove.push({
                parent: parentNode,
                child: canvas
            });

            parentNode.appendChild(canvas);
        });

        html2canvas(targetElem, {
            allowTaint: true,
            background :'#FFFFFF',
            onrendered: function(canvas) {
                Canvas2Image.saveAsPNG(canvas, '2400', '2400', 'PMO - TREND');
            }
        });
    }
    
    /**
     * Create a global getSVG method that takes an array of charts as an argument
     */
    Highcharts.getSVG = function(charts) {
        var svgArr = [],
            top = 0,
            width = 0;

        $.each(charts, function(i, chart) {
            var svg = chart.getSVG();
            svg = svg.replace('<svg', '<g transform="translate(0,' + top + ')" ');
            svg = svg.replace('</svg>', '</g>');
            svg = svg.replace('-9000000000', '-999'); // Bug in v4.2.6

            top += chart.chartHeight;
            width = Math.max(width, chart.chartWidth);

            svgArr.push(svg);
        });

        return '<svg height="'+ top +'" width="' + width + '" version="1.1" xmlns="http://www.w3.org/2000/svg">' + svgArr.join('') + '</svg>';
    };

    /**
     * Create a global exportCharts method that takes an array of charts as an argument,
     * and exporting options as the second argument
     */
    Highcharts.exportCharts = function(charts, options) {

        // Merge the options
        options = Highcharts.merge(Highcharts.getOptions().exporting, options);

        // Post to export server
        Highcharts.post(options.url, {
            filename: options.filename || 'PMO - TREND',
            type: 'image/jpeg',
            width: options.width,
            svg: Highcharts.getSVG(charts)
        });
    };
    
    $scope.excelDownloadPMTREND = function(ids, rFormat){
          var tableToExcel = (function() {
          var uri = 'data:application/vnd.ms-excel;base64,'
          , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
                      , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
                      , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
            return function(table) {
                if (!table.nodeType)
                    table = document.getElementById(ids);

                var excelContent = '';

                var header = "<tr><td colspan='7' style='text-align:left'>" +
                         "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center'>Fleet Mining System</span>"+
                         "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
                
                var columns;
                if($scope.hideForeCast === true) {
                    columns = ["PARTS STATUS", "ADDED", "REMOVED"];
                } else {
                    columns = ["PARTS STATUS", "FORECASTED", "ADDED", "REMOVED", "NEW FORECAST"];
                }
                
                excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';

                var getDataFromDT  = $("#"+ids).dataTable().api().rows( { filter: "applied" } ).data().toArray();

                var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";

                var tdNumber = "<td style='mso-number-format:0'>";

                excelContent = excelContent + '<tr> <td colspan="7"> PMO TREND - '+rFormat+' </td> </tr>';

                excelContent =excelContent + '<tr>';
                var flag = 0;
                _.forEach(columns, function(column){
                    if(columns[0]!== 'null' && flag === 0){
                           excelContent = excelContent + th + column + '</th>';
                           flag++;
                    }else {
                           excelContent = excelContent + th + column +'($M)' + '</th>';
                    }
                });
                excelContent = excelContent + '</tr>';

                _.forEach(getDataFromDT, function(row){

                    excelContent = excelContent + '<tr>';
                    
                    delete row.grandTotal;
                    
                    if($scope.hideForeCast === true) {
                        delete row.foreCastedSum;
                        delete row.newForeCastSum;
                    }
                    
                    _.forEach(row, function(rowData){
                        if((/^[0-9]{0,}$/).test(rowData)) {
                            excelContent = excelContent + tdNumber + rowData + '</td>';
                        } else {
                            excelContent = excelContent + '<td>' + rowData + '</td>';
                        }
                    });
                    excelContent =excelContent + '</tr>';
                });
                excelContent = excelContent + '<tr>' + $("#" + ids + ' tfoot').find('tr').eq(0).html().replace(/[$%M]/gi, '') + '</tr>';

                var ctx = {worksheet: 'PMO TREND - '+rFormat , table: excelContent};
                document.getElementById('excelAnchorPMTREND'+rFormat).href = (uri + base64(format(template, ctx)));
                document.getElementById('excelAnchorPMTREND'+rFormat).download = 'PMO TREND - '+rFormat+' - REPORT.xls';
            }
         })();
         tableToExcel(ids, rFormat);
    };
    
    $scope.iPMLoader =false; 
	};
    }]);
});