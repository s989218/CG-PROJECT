
define(['angular','../../../sample-module','jquery','multiselectdrpdwn','jqueryMultiSelect'], function (angular,controllers,jquery,multiselectdrpdwn,jqueryMultiSelect) 
 {
    'use strict';
    controllers.controller('productTXController', ['$scope','$timeout','$state','$rootScope','IPMService',
	function ($scope,$timeout,$state,$rootScope,IPMService){
$scope.drawPRCTX = function (){

$scope.stackedTempPRCTXLabels=  _.findWhere($scope.PRCTXData.Table, {HEADER: "CE"});
    var tempStackPRCTXObject = [];
_.each($scope.PRCTXData.TableHeaders, function(item){
    tempStackPRCTXObject.push($scope.stackedTempPRCTXLabels[item]);
});

    var tempVar = _.findWhere($scope.PRCTXData.Chart, {name: "OP"});
    tempStackPRCTXObject[tempStackPRCTXObject.length-1]=tempVar.data[tempVar.data.length-1];   
 
    $scope.PRCTXCategories = $scope.PRCTXData.TableHeaders;
    var chart;
     $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'PRCTXChart',
                type: 'column',
                width:'900'
            },

            title: {

                text: 'Walk By Product - TX'

            },
             credits: {
                  enabled: false
              },

            xAxis: {

                categories: $scope.PRCTXCategories
                
 
            },

            yAxis: {
                  gridLineWidth: 0,

                min: 0,

                title: {

                    text: 'Total'

                },

           
              stackLabels: {
                            qTotals: tempStackPRCTXObject,
                            enabled: true,
                            style: {
                                fontWeight: 'bold'
                            },
                            formatter: function() {
                                return this.options.qTotals[this.x];
                            }
                        }
            },

            legend: {
            },

            tooltip: {

                formatter: function() {

                    return '<b>'+ this.x +'</b><br/>'+

                        this.series.name +': '+ this.y +'<br/>'+

                        'Total: '+ this.point.stackTotal;

                }

            },

            plotOptions: {

                column: {

                    stacking: 'normal',
                    shadow: false,

                    dataLabels: {

                        enabled: false,

                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'

                    }

                }

            },
            series: _.sortBy($scope.PRCTXData.Chart,'id')

        }
                                    
            
       );
      $.each(chart.series[6].data, function(i, point) {
        point.graphic.attr({opacity: 0, 'stroke-width': 0});
      });
    
        setTimeout(function (){
       $rootScope.safeApply (function (){
       });  
        },1000);
         
         
         
    });
   $("#PRCTXTable").DataTable({ 
    		data:$scope.PRCTXData.Table,
            "bInfo" : false,
            "bPaginate": false, 
            "bFilter":false,
			"retrieve": true,
            "order":[],
            "aoColumnDefs": [
                             { "sClass": "header_class", "aTargets": [ 0 ] }
                           ],
     		 "columns": [{ data:"HEADER", title:"&nbsp"},
			             { data:"PARTS",title:"PARTS" },
			             { data:"FIELD SERVICES", title:"FIELD SERVICES"},
			             { data:"REPAIRS",title:"REPAIRS"},
			             { data:"OTHER GE LE",title:"OTHER GE LE"},
                         { data:"CT",title:"CT"},
			             { data:"HQ",title:"HQ"},
                         { data:"COQ", title:"COQ"},
                         { data:"CONVTOGO",title:"CONVTOGO"},
			             { data:"STRETCH", title:"STRETCH"},
			             { data:"RISK",title:"RISK"},
			             { data:"OPP",title:"OPP"},
                         { data:"TOT",title:"TOT"},
			             { data:"OP", title:"OP"}]
			   });
                    
    $scope.exportChartPRCTX = function (){
                     chart.exportChart({type: 'image/jpeg', filename: 'Walk By Product - TX'}, {subtitle: {text:''}});
                    };
    
    
         $scope.excelDownloadPRCTX= function(){
                      var tableToExcel = (function() {
                      var uri = 'data:application/vnd.ms-excel;base64,'
                      , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
                                  , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
                                  , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
                           return function(table) {
                           if (!table.nodeType)
                                  table = document.getElementById('PRCTXTable');
                           var excelContent = '';
                               
                             
                           var header = "<tr><td colspan='8' style='text-align:center'>" +
                                         "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center'>Fleet Mining System</span>"+
                                         "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
                        
                           var columns = $scope.PRCTXData.TableHeaders;
                           excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
                           var getDataFromDT  = $('#PRCTXTable').dataTable().api().rows( { filter: "applied" } ).data().toArray();
                           var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
                           var tdNumber = "<td style='mso-number-format:0'>";
                          
                                  excelContent = excelContent + '<tr> <td colspan="7"> IPM Walk By Product - TX</td> </tr>';
                               
                              
                               
                               excelContent =excelContent + '<tr>';
                               excelContent = excelContent + th + '</th>';
                           _.forEach(columns, function(column){
                                         excelContent = excelContent + th + column + '</th>';
                           });
                           excelContent = excelContent + '</tr>';
                         
                               
                               _.forEach(getDataFromDT, function(row){
                               
                                  excelContent =excelContent + '<tr>';
                                  _.forEach(row, function(rowData){
                                         if((/^[0-9]{0,}$/).test(rowData)) {
                                                excelContent = excelContent + tdNumber + rowData + '</td>';
                                         } else if(rowData === null) {
                                                excelContent = excelContent + '<td> &nbsp; </td>';
                                         } else {
                                                excelContent = excelContent + '<td>' + rowData + '</td>';
                                         }
                                  });
                                  excelContent =excelContent + '</tr>';
                           });
                               
                           excelContent = excelContent + '<tr><td colspan="14"></td></tr><tr><td colspan="14" align="left" style="padding-left:100px;">' + $("#PRCTXData span").eq(0).text() + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + $("#PRCTXData span").eq(1).text() + '</td></tr>';  
                               
                           var ctx = {worksheet: 'Walk By Product - TX' , table: excelContent};
                           document.getElementById('excelAnchorPRCTX').href = (uri + base64(format(template, ctx)));
                           document.getElementById('excelAnchorPRCTX').download = 'WalkByProduct_TX_Report.xls';
                     }
                     })();
                     tableToExcel('PRCTXTable');
                    };
    $timeout(function (){
            $(window).trigger('resize');
               $rootScope.safeApply(function(){
           });
     $scope.iPMLoader =false;      
    
    },200);
    
     $scope.iPMLoader =false; 
    
};

       }]);
});

