
define(['angular','../../../sample-module','jquery','multiselectdrpdwn','jqueryMultiSelect'], function (angular,controllers,jquery,multiselectdrpdwn,jqueryMultiSelect) 
 {
    'use strict';
    controllers.controller('projectCSController', ['$scope','$timeout','$state','$rootScope','IPMService',
	function ($scope,$timeout,$state,$rootScope,IPMService){
$scope.drawPCCS = function (){
    
    var arrPCCSDataTableHeaders  = [];
    arrPCCSDataTableHeaders.push({data: "HEADER", title:"&nbsp"});
    _.each($scope.PCCSData.TableHeaders, function(item){
        arrPCCSDataTableHeaders.push({data: item, title:item});
    });
    $scope.arrPCCSDataTableHeaders = arrPCCSDataTableHeaders;

  $scope.stackedTempPCCSLabels=  _.findWhere($scope.PCCSData.Table, {HEADER: "CE"});
    var tempStackPCCSObject = [];
_.each($scope.PCCSData.TableHeaders, function(item){
    tempStackPCCSObject.push($scope.stackedTempPCCSLabels[item]);
});

      var tempVar = _.findWhere($scope.PCCSData.Table, {HEADER: "OP"});
    tempStackPCCSObject[tempStackPCCSObject.length-1]=tempVar.OP;    
    
    
    $scope.PCCSCategories = $scope.PCCSData.TableHeaders;
    var chart;
     $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'PCCSChart',
                type: 'column',
                width:'900'
            },

            title: {

                text: 'Project Controller - CS'

            },
                 credits: {
                  enabled: false
              },

            xAxis: {

                categories: $scope.PCCSCategories
                
 
            },

            yAxis: {
                  gridLineWidth: 0,

                min: 0,

                title: {

                    text: 'Total'

                },

                
              stackLabels: {
                            qTotals: tempStackPCCSObject,
                            enabled: true,
                            style: {
                                fontWeight: 'bold'
                            },
                            formatter: function() {
                                return this.options.qTotals[this.x];
                            }
                        }

            },

            legend: {

            },

            tooltip: {

                formatter: function() {

                    return '<b>'+ this.x +'</b><br/>'+

                        this.series.name +': '+ this.y +'<br/>'+

                        'Total: '+ this.point.stackTotal;

                }

            },

            plotOptions: {

                column: {

                    stacking: 'normal',
                    shadow: false,

                    dataLabels: {

                        enabled: false,

                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'

                    }

                }

            },
            series: _.sortBy($scope.PCCSData.Chart,'id')

        }
                                    
            
       );
      $.each(chart.series[6].data, function(i, point) {
        point.graphic.attr({opacity: 0, 'stroke-width': 0});
      });
    
        setTimeout(function (){
       $rootScope.safeApply (function (){
       });  
        },1000);
         
         
         
    });
    
 
   $("#PCCSTable").DataTable({ 
    		data:$scope.PCCSData.Table,
            "bInfo" : false,
            "bPaginate": false, 
            "bFilter":false,
			"retrieve": true,
            "order":[],
            "aoColumnDefs": [
                             { "sClass": "header_class", "aTargets": [ 0 ] }
                           ],
            "columns": $scope.arrPCCSDataTableHeaders
       
     		 /*"columns": [{ data:"HEADER", title:"&nbsp"},
			             { data:"APANZ",title:"APANZ" },
			             { data:"CHINA", title:"CHINA"},
			             { data:"EUROPE",title:"EUROPE"},
			             { data:"INDIA",title:"INDIA"},
			             { data:"LATAM",title:"LATAM"},
                         { data:"MENAT",title:"MENAT" },
			             { data:"NAM", title:"NAM"},
                         { data:"RCIS", title:"RCIS"},
			             { data:"SSA", title:"SSA"},
			             { data:"HQ",title:"HQ"},
			             { data:"RISK",title:"RISK"},
			             { data:"OPP",title:"OPP"},
			             { data:"TOT", title:"TOT"},
			             { data:"OP",title:"OP"}]*/
			   });
    
                
    $scope.exportChartPCCS = function (){
                     chart.exportChart({type: 'image/jpeg', filename: 'Project Controller - CS'}, {subtitle: {text:''}});
                    };
    
    
         $scope.excelDownloadPCCS= function(){
                      var tableToExcel = (function() {
                      var uri = 'data:application/vnd.ms-excel;base64,'
                      , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
                                  , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
                                  , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
                           return function(table) {
                           if (!table.nodeType)
                                  table = document.getElementById('PCCSTable');
                           var excelContent = '';
                               
                             
                           var header = "<tr><td colspan='8' style='text-align:center'>" +
                                         "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center'>Fleet Mining System</span>"+
                                         "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
                        
                           var columns = $scope.PCCSData.TableHeaders;
                           excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
                           var getDataFromDT  = $('#PCCSTable').dataTable().api().rows( { filter: "applied" } ).data().toArray();
                           var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
                           var tdNumber = "<td style='mso-number-format:0'>";
                          
                                  excelContent = excelContent + '<tr> <td colspan="7"> IPM Project Controller - CS</td> </tr>';
                               
                              
                               
                               excelContent =excelContent + '<tr>';
                               excelContent = excelContent + th + '</th>';
                           _.forEach(columns, function(column){
                                         excelContent = excelContent + th + column + '</th>';
                           });
                           excelContent = excelContent + '</tr>';
                         
                               
                               _.forEach(getDataFromDT, function(row){
                               
                                  excelContent =excelContent + '<tr>';
                                  _.forEach(row, function(rowData){
                                         if((/^[0-9]{0,}$/).test(rowData))
                                                excelContent = excelContent + tdNumber + rowData + '</td>';
                                         else
                                                excelContent = excelContent + '<td>' + rowData + '</td>';
                                  });
                                  excelContent =excelContent + '</tr>';
                           });
                            
                           excelContent = excelContent + '<tr><td colspan="14"></td></tr><tr><td colspan="14" align="left" style="padding-left:100px;">' + $("#PCCSData span").eq(0).text() + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + $("#PCCSData span").eq(1).text() + '</td></tr>';
                               
                           var ctx = {worksheet: 'Project Controller - CS' , table: excelContent};
                           document.getElementById('excelAnchorPCCS').href = (uri + base64(format(template, ctx)));
                           document.getElementById('excelAnchorPCCS').download = 'ProjectControllerCS_Report.xls';
                     }
                     })();
                     tableToExcel('PCCSTable');
                    };
    $timeout(function (){
            $(window).trigger('resize');
               $rootScope.safeApply(function(){
           });
     $scope.iPMLoader =false;      
    
    },200);
    
     $scope.iPMLoader =false; 
    
};

       }]);
});

