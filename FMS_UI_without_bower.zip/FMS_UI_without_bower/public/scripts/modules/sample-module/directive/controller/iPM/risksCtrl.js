
define(['angular','../../../sample-module','jquery','datatablesNet'], function (angular,controllers,jquery,datatablesNet,exportToExcel,webAnimation) 
{
    'use strict';
    controllers.controller('risksController', ['$scope','$http', '$location','$state','$rootScope','$timeout','IPMService', function ($scope, $http, $location, $state, $rootScope, $timeout, IPMService) {
        
        var riskDealsModalUpdate = document.getElementById('riskDealsUpdateDataModal');
        var riskDealsSpanUpdate  = document.getElementsByClassName("riskDealsUpdateClose")[0];

        riskDealsSpanUpdate.onclick = function(event) {
            riskDealsModalUpdate.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target === riskDealsModalUpdate) {
                riskDealsModalUpdate.style.display = "none";
            }
        }
        
        $(function() {
            $("body").delegate("#riskdeals_p_new_date", "focusin", function() {
                var localToday = new Date();
                $(this).datepicker({
                    changeMonth: true,
                    changeYear: true,
                    dateFormat: 'mm-dd-yy',
                    localToday: localToday,
                    minDate: localToday,
                    inline: true,
                    dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
                    showOtherMonths: true,
                    showOn: "both",
                    showAnim: "slideDown",
                    duration: 'fast',
                    buttonImage: "images/calendar.png",
                    buttonImageOnly: true
                });
            });
        });
                    
        $scope.risksTableDraw = function () {
            
            $scope.customizedRiskDealsData    = $rootScope.IPMRiskData.risksDealsData;
            $scope.customizedRiskDealsHeaders = $rootScope.IPMRiskData.risksDealsHeaders;
            $scope.getCurrentWeek             = $scope.getWeekNumber();
            
            var redCircle       = '<img src="../images/red.png">';
            var yellowCircle    = '<img src="../images/yellow.png">';
            var greenCircle     = '<img src="../images/green.png">';
            var good            = '<img src="../images/good.png">';
            var flat            = '<img src="../images/flat.png">';
            var bad             = '<img src="../images/critical.png">';
            var data;
            var test            = [];
            var temp            = {};
            
            $("#risksTable").DataTable({
                data: $scope.customizedRiskDealsData,
                "retrieve": true,
                "order": [1, "desc"],
                "columns": [
                    { 
                        data:"p_sum_cm", title:"CM Total","render": function (data, type, full, meta) {
                            if (_.where(test, {cm_sum: data, region: full.final_region}).length>0) {
                                return "";
                            } else {
                                temp.cm_sum = data;                      
                                temp.region = full.final_region;
                                test.push(temp);
                                temp        = {};
                                return data;
                            }
                        }
                    },
                    { data:"final_region",title:"Region" },
                    { data:"concatenate",title:"Concatenate" },
                    { data:"p_and_l", title:"P&L" },
                    { data:"product",title:"Product" },
                    { data:"enduser_cust_name",title:"End User Customer Name" },
                    { data:"p_cm_dollar_by_1000",title:"CM$/1000" },            
                    {
                        data:"p_status",title:"Status", "render": function (data, type, full, meta) {
                            if (data) {
                                if (data.toUpperCase().trim()==='LOW') {
                                    return greenCircle;
                                }
                                
                                if (data.toUpperCase().trim()==='MEDIUM') {
                                    return yellowCircle;
                                }
                                
                                if (data.toUpperCase().trim()==='HIGH') {
                                    return redCircle;
                                }
                            } else {
                                return data;
                            }
                        }
                    },
                    { data:"p_wb_comment",title:"WB Comment" },
                    { data:"p_note",title:"Note" },
                    { data:"p_due_date",title:"Due Date" },
                    {
                        data:"p_trend",title:"Trend", "render": function (data, type, full, meta) {
                            if (data) {
                                if (data.toUpperCase().trim()==='GOOD') {
                                    return good;
                                } else if (data.toUpperCase().trim()==='FLAT') {
                                    return flat;
                                } else if (data.toUpperCase().trim()==='BAD') {
                                    return bad;
                                }
                            } else {
                                return data;
                            }
                        }
                    }
                ]
            });
            
            $('body #risksTable tbody').on( 'click', 'tr', function () {
                
                var data              = $("#risksTable").dataTable().api().row(this).data();
                var dataObject        = {};
                $scope.mainDataObject = [];
                $scope.failureMessage = "";

                _.forEach (data, function(value,key) {

                    if (_.where(_.where($scope.customizedRiskDealsHeaders, {data: key}), {editable: "Y",type:'DropDown'}).length > 0) {

                        _.forEach (_.where(_.where($scope.customizedRiskDealsHeaders, {data: key}), {editable: "Y",type:'DropDown'}),         function(value) {
                            dataObject          = {};
                            dataObject.id       = value.id;   
                            dataObject.key      = value.data;                    
                            dataObject.value    = value.title;
                            dataObject.editable = value.editable;
                            dataObject.type     = value.type;

                            var str = value.values; 
                            if (str) {
                                dataObject.values = str.toString().split(",");
                            }
                            $scope.mainDataObject.push(dataObject);
                        });
                    }

                    if (_.where(_.where($scope.customizedRiskDealsHeaders, {data: key}), {editable: "Y",type:'DATE'}).length > 0) {

                        _.forEach (_.where(_.where($scope.customizedRiskDealsHeaders, {data: key}), {editable: "Y",type:'DATE'}), function(value) {
                            dataObject          = {};
                            dataObject.id       = value.id;
                            dataObject.key      = value.data;
                            dataObject.value    = value.title;
                            dataObject.editable = value.editable;
                            dataObject.type     = value.type;
                            dataObject.values   = value.values;
                            $scope.mainDataObject.push(dataObject);
                        });
                    }


                    if (_.where(_.where($scope.customizedRiskDealsHeaders, {data: key}), {editable: "Y",type:'FreeField'}).length > 0) {

                        _.forEach (_.where(_.where($scope.customizedRiskDealsHeaders, {data: key}), {editable: "Y",type:'FreeField'}), function(value) {
                            dataObject          = {};
                            dataObject.id       = value.id;
                            dataObject.key      = value.data;
                            dataObject.value    = value.title;
                            dataObject.editable = value.editable;
                            dataObject.type     = value.type;
                            dataObject.values   = value.values;
                            $scope.mainDataObject.push(dataObject);
                        });
                    }

                    if (_.where(_.where($scope.customizedRiskDealsHeaders, {data: key}), {editable: "N"}).length > 0) {

                        _.forEach (_.where(_.where($scope.customizedRiskDealsHeaders, {data: key}), {editable: "N"}), function(value) {
                            dataObject          = {};
                            dataObject.id       = value.id;
                            dataObject.key      = value.data;
                            dataObject.value    = value.title;
                            dataObject.editable = value.editable;
                            dataObject.type     = value.type;
                            dataObject.values   = value.values;
                            $scope.mainDataObject.push(dataObject);
                        });
                    }

                    if (_.where(_.where($scope.customizedRiskDealsHeaders, {data: key}), {editable: "D"}).length > 0) {

                        _.forEach (_.where(_.where($scope.customizedRiskDealsHeaders, {data: key}), {editable: "D"}), function(value) {
                            dataObject          = {};
                            dataObject.id       = value.id;
                            dataObject.key      = value.data;
                            dataObject.value    = value.title;
                            dataObject.editable = value.editable;
                            dataObject.type     = value.type;
                            dataObject.values   = value.values;
                            $scope.mainDataObject.push(dataObject);
                        });
                    }
                });
                
                $scope.mainDataObject = _.sortBy($scope.mainDataObject, 'id');

                $rootScope.safeApply(function() {
                    if (data.p_r_by_o) {
                        if ((data.p_r_by_o).toUpperCase()==='RISK') {
                            if (!data.p_status) {
                                data.p_status = "";
                            } else if ((data.p_status).toUpperCase().includes("GREEN")) {
                                data.p_status = 'Low';
                            } else if ((data.p_status).toUpperCase().includes("YELLOW")) {
                                data.p_status = 'Medium';
                            } else if ((data.p_status).toUpperCase().includes("RED")) {
                                data.p_status = 'High';
                            }
                        } else if ((data.p_r_by_o).toUpperCase()==='OPPS') {

                            if (!data.p_status) { 
                                data.p_status = "";
                            } else if ((data.p_status).toUpperCase().includes("GREEN")) {
                                data.p_status ='High';
                            } else if ((data.p_status).toUpperCase().includes("YELLOW")) {
                                data.p_status ='Medium';
                            } else if ((data.p_status).toUpperCase().includes("RED")) {
                                data.p_status ='Low';
                            }
                        }
                    } else {
                        if (!data.p_status) {
                            data.p_status = "";
                        } else if ((data.p_status).toUpperCase().includes("GREEN")) {
                            data.p_status ='High';
                        } else if ((data.p_status).toUpperCase().includes("YELLOW")) {
                            data.p_status ='Medium';
                        } else if ((data.p_status).toUpperCase().includes("RED")) {
                            data.p_status ='Low';
                        }
                    }

                    $scope.rowData = null;
                    $scope.rowData = [];
                    var dataObject = {};
                    _.forEach(data, function(value,key) {
                        dataObject['key']   = key;
                        dataObject['value'] = value;
                        $scope.rowData.push(dataObject);
                        dataObject = {};
                    });
                });

                if ( parseInt($scope.getCurrentWeek) === parseInt($rootScope.selectionFilterData.week) ) {
                    $scope.updateSuccess    = false;
                    $scope.updateFailure    = false;
                    
                    riskDealsModalUpdate    = document.getElementById('riskDealsUpdateDataModal');
                    riskDealsModalUpdate.style.display = "block";
                }
                
            });
            
            $timeout(function () {
                $(window).trigger('resize');
                $rootScope.safeApply(function() {
                    $('#risksTable thead tr th:eq(2)').css("width", "250px");
                    $('#risksTable thead tr th:eq(5)').css("width", "350px");                   
                    $('#risksTable thead tr th:eq(9)').css("width", "200px");
                });
                $scope.iPMLoader =false; 
            },200);
        }
        
        $scope.updateRiskDealsData = function() {
            
            $scope.editedData     = {};
            $scope.failureMessage = "";
            
            _.forEach($scope.rowData, function(data) {
                if ( !$('.'+data.key+'').val() ) {
                    $scope.editedData[data.key] = null;
                } else {    
                    if (data.key === 'p_new_date') {
                        if ($('#riskdeals_'+data.key).val().trim() === "") {
                            $scope.editedData[data.key] = null;
                        } else {
                            $scope.editedData[data.key] = $('#riskdeals_'+data.key).val().trim(); 
                        }
                    } else {
                        if ($('#'+data.key+'').val() === "") {
                            $scope.editedData[data.key] = null;
                        } else {
                            $scope.editedData[data.key] = $('#'+data.key+'').val();
                        }
                    }
                }
            });

            if ($scope.editedData['p_new_date'] !== null && $scope.editedData['p_wb_comment'] === null) {
                $scope.updateSuccess  = false;
                $scope.updateFailure  = true;
                $scope.failureMessage = "Please Select WB Comment."
            } else if (!$scope.editedData['p_status']) {
                $scope.updateSuccess  = false;
                $scope.updateFailure  = true;
                $scope.failureMessage = "Please Select Status."
            } else {
                IPMService.updateIPMPartsRow(JSON.stringify($scope.editedData)).then(function(response) {

                    $rootScope.safeApply(function() {
                        if (response === "UPDATED" || response === "SUCCESS") {
                            $scope.updateSuccess = true;
                            $scope.updateFailure = false;
                            $scope.loadfilteredData();
                        } else if (response==="FAILURE") {
                            $scope.updateSuccess  = false;
                            $scope.updateFailure  = true;
                            $scope.failureMessage = "Something went wrong! Please try again later."
                        }

                        $timeout(function () {
                            $scope.updateSuccess = false;
                            $scope.updateFailure = false;
                        },3000);  
                    });

                });
            }
        };
   }]);
});