
define(['angular','../../../sample-module','jquery','multiselectdrpdwn','jqueryMultiSelect'], function (angular,controllers,jquery,multiselectdrpdwn,jqueryMultiSelect) 
 {
    'use strict';
    controllers.controller('selectionController', ['$scope','$state','$rootScope','IPMService','$timeout',
	function ($scope,$state,$rootScope,IPMService,$timeout){
              $scope.iPMFilterLoader = true;   
              $rootScope.selectionFilterData = {};
              $scope.searchPanel ={};
              $scope.searchPanel.businessSegment = 'DTS'; 
              $rootScope.selectionFilterData["businessSegment"]=$scope.searchPanel.businessSegment;
        
        IPMService.getIPMSelectionFiltersData().then(function (response){
                $rootScope.safeApply(function(){
      				$scope.IPMselectionPanelData = response;
                    $timeout(function (){
                            $("select.multiSelect").multipleSelect({
                            filter: true
                        });
                    $scope.iPMFilterLoader = false;   
                    },200);  
          		  });                           
        });
        
        $scope.clearData = function(){
            $scope.iPMLoader =true;  
						$('.iPMSelectionFilters').find('.ms-choice > span').html('');
						$('.iPMSelectionFilters').find('input[type="checkbox"]').attr('checked',false);
						$('.iPMSelectionFilters').find("select").val('')
						
                    $rootScope.safeApply(function(){
                         $rootScope.selectionFilterData={};
                         $scope.searchPanel ={};
                        setTimeout(function (){  $rootScope.safeApply(function(){$scope.searchPanel.businessSegment = 'DTS';
                                                                            $rootScope.selectionFilterData["businessSegment"]=$scope.searchPanel.businessSegment;
                                                      $scope.loadfilteredData ();     
                                                                                })
                                                                           
                                              
                                              },200); 
                        
                       
                    });
                
            }        
        
        $scope.search = function (){
          $scope.iPMLoader =true;  
              $rootScope.selectionFilterData = {};
              $rootScope.selectionFilterData["businessSegment"]=  $scope.searchPanel.businessSegment?$scope.searchPanel.businessSegment:"";            
              var filterArray =["businessSegment","product","ouName","pandL","ogRegion","region","subregion","endUserCountryDisc","motherJob","enduserCustName","costingProject","orderType"];
            _.each(filterArray, function (key){   
                if ($scope.searchPanel[key] !== '') {
                      if ($scope.searchPanel[key]) {
                     $rootScope.selectionFilterData[key]=  $scope.searchPanel[key].toString().replace(/,/g,"|");         
                      }
                    else{
                     $rootScope.selectionFilterData[key]= null;
                    }
                    
                }
                else{
                  $rootScope.selectionFilterData[key]=null;            
                }   
                
                
            });
                $scope.loadfilteredData ();
         }
       }]);
});

