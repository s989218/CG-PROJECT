
define(['angular','../../../sample-module','jquery','multiselectdrpdwn','jqueryMultiSelect'], function (angular,controllers,jquery,multiselectdrpdwn,jqueryMultiSelect) 
 {
    'use strict';
    controllers.controller('selectionController', ['$scope','$state','$rootScope','IPMService','$timeout',
	function ($scope,$state,$rootScope,IPMService,$timeout){
    	
            $scope.iPMFilterLoader 	            = true;
            $rootScope.selectionFilterData      = {};
            $rootScope.filterData               = {};
            $scope.searchPanel                  = {};
            
            // setting businessSegment based on role from app.js($rootScope.ipmBusinessSegment)
            $scope.searchPanel.businessSegment  = $rootScope.businessSegment;
            
            $scope.currentWeekNo                = $scope.getWeekNumber();
            $scope.searchPanel.week             = $scope.getWeekNumber();

            $scope.showDTSResult                = true;
            $scope.showTMSResult                = false;
        
            $rootScope.selectionFilterData["businessSegment"] = $rootScope.businessSegment;
            $rootScope.selectionFilterData["week"]            = $scope.searchPanel.week;
            
            $rootScope.filterData.roleId       = $rootScope.roleId;
            $rootScope.filterData.businessSegment = $rootScope.businessSegment;
            
            IPMService.getIPMSelectionFiltersData(JSON.stringify($rootScope.filterData)).then(function (response){
            $rootScope.safeApply(function(){
                $scope.IPMselectionPanelData = response;

                var weekIndex =  $scope.IPMselectionPanelData.week.indexOf($scope.currentWeekNo.toString());
                $scope.searchPanel.week = $scope.IPMselectionPanelData.week[weekIndex];
                
                $timeout(function (){
                    $("select.multiSelect").multipleSelect({
                        filter: true
                    });
                    $("select.singleSelect").multipleSelect({
                        filter: true,
                        single: true
                    });
                    $scope.iPMFilterLoader = false;
                },200);  
            });                           
            });
        
        $scope.clearData = function() {
            $scope.iPMLoader        = true;  
            $scope.showDTSResult    = true;
            $scope.showTMSResult    = false;
            $scope.defaultPMSelection = false;
            
            $('.kdRawDataFilter').slideUp();
            $scope.showRawDataFilters = false;
            
            if ($.fn.DataTable.isDataTable( '#rawDataTable' ) ) {
                $("#rawDataTable").dataTable().api().clear().draw();
                $("#rawDataTable").dataTable().api().destroy();
                $('#rawDataTable').empty(); 
            }
            
            $('.iPMSelectionFilters').find('.ms-choice > span').html('');
            $('.iPMSelectionFilters').find('input[type="checkbox"]').attr('checked',false);
            $('.iPMSelectionFilters').find('input[type="radio"]').attr('checked',false);
            $('.iPMSelectionFilters').find("select").val('');
                 
            $rootScope.safeApply(function(){
                $rootScope.selectionFilterData = {};
                $scope.searchPanel             = {};
                
                setTimeout(function () {  
                    $rootScope.safeApply(function() {
                    	$scope.searchPanel.businessSegment  = $rootScope.businessSegment;

                        var weekIndex =  $scope.IPMselectionPanelData.week.indexOf($scope.currentWeekNo.toString());
                        $scope.searchPanel.week = $scope.IPMselectionPanelData.week[weekIndex];
                        
                        $scope.disableDropdown();
                        
                        $rootScope.selectionFilterData["businessSegment"] = $scope.searchPanel.businessSegment;
                        $rootScope.selectionFilterData["week"]            = $scope.searchPanel.week;
                        
                        $scope.hideForeCast = false;

                        $scope.loadfilteredData();
                    });
                },200); 
            });
                
        }      
        
        $scope.search = function () {
            
            $scope.iPMLoader               = true;  
            $rootScope.selectionFilterData = {};
            $scope.hideForeCast            = false;
            
            $('.kdRawDataFilter').slideUp();
            $scope.showRawDataFilters = false;
            
            if ($.fn.DataTable.isDataTable( '#rawDataTable' ) ) {
                $("#rawDataTable").dataTable().api().clear().draw();
                $("#rawDataTable").dataTable().api().destroy();
                $('#rawDataTable').empty(); 
            }
            
            if($scope.searchPanel.businessSegment === "DTS") {
                $scope.showDTSResult                = true;
                $scope.showTMSResult                = false;
            } else {
                $scope.showDTSResult                = false;
                $scope.showTMSResult                = true;
            }
            
            $rootScope.selectionFilterData["businessSegment"] = $rootScope.businessSegment;
            $rootScope.selectionFilterData["week"] =  $scope.searchPanel.week ? $scope.searchPanel.week : "";
            if (typeof $scope.searchPanel.projectManager !== 'undefined' && $scope.searchPanel.projectManager.length > 0) {
                $scope.defaultPMSelection = true;    
            }
            
            var filterArray =["businessSegment","product","ouName","pandL","ogRegion","region","subregion","endUserCountryDisc","motherJob","enduserCustName","costingProject","orderType","week","projectManager"];
            
            _.each(filterArray, function (key){
                if ($scope.currentWeekNo.toString() !== $scope.searchPanel.week) {
                    
                    if ($scope.searchPanel[key] !== '' && (key === 'businessSegment' || key === 'week')) {
                        if ($scope.searchPanel[key]) {
                        	if(key !== 'businessSegment' && key !== 'week' && key !== 'motherJob' && key !== 'enduserCustName' && key !== 'costingProject'){
	                        	 $scope.searchPanelValue = _.chain($scope.searchPanel[key]).map(function(item) { 
	                                 return item;
	                             }).value();
	                        	 $rootScope.selectionFilterData[key] = $scope.searchPanelValue.join("|");
                        	}else{
                        		
                        		$rootScope.selectionFilterData[key] = $scope.searchPanel[key];
                        	}
                        } else {
                            $rootScope.selectionFilterData[key] = null;
                        }
                    } else {
                        $rootScope.selectionFilterData[key] = null;
                    }
                } else {
                    if ($scope.searchPanel[key] !== '') {
                        if ($scope.searchPanel[key]) {
                            if((key !== 'businessSegment' && key !== 'week') && $scope.searchPanel[key].length !== 0) {
                                $scope.hideForeCast = true;
                            }                                             
                            if(key !== 'businessSegment' && key !== 'week' && key !== 'motherJob' && key !== 'enduserCustName' && key !== 'costingProject'){
	                        	 $scope.searchPanelValue = _.chain($scope.searchPanel[key]).map(function(item) { 
	                                 return item;
	                             }).value();
	                        	 $rootScope.selectionFilterData[key] = $scope.searchPanelValue.join("|");
			               	}else{
			                      $rootScope.selectionFilterData[key] = $scope.searchPanel[key];
			                }
                        } else {
                            $rootScope.selectionFilterData[key] = null;
                        }
                    } else {
                        $rootScope.selectionFilterData[key] = null;       
                    }
                }
            });
            $scope.loadfilteredData();
         }
        	
        
        $scope.disableDropdown = function() {

            if ($scope.currentWeekNo.toString() !== $scope.searchPanel.week) {

                $('.toBeDisabled .ms-choice').attr('disabled','true');
                $('.toBeDisabledText').attr('disabled','true');
                $('.disableButton').attr('disabled','true');
                
                $('.toBeDisabled .ms-choice, .toBeDisabledText').css({
                   'background' : '#dddddd',
                   'opacity' : '0.6'
                });

            } else {
                
                $('.toBeDisabled .ms-choice').removeAttr('disabled','false');
                $('.toBeDisabledText').removeAttr('disabled','false');
                $('.disableButton').removeAttr('disabled','false');
                
                $('.toBeDisabled .ms-choice, .toBeDisabledText').css({
                   'background' : '#FFFFFF',
                   'opacity' : '1'
                });
            }

        };
       }]);
});

