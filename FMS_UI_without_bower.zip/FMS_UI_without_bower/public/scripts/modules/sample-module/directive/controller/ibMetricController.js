define(['angular', '../../sample-module', 'jquery'], function(angular, controllers, jquery) {
    'use strict';
    controllers.controller('IBMetricsController', ['NetworkCallService', '$scope', '$rootScope', 'TechnologyRegionChart', 'NewMetricTechService', 'CustomerChartService', '$state', 'LoaderService', '$timeout',
        function(NetworkCallService, $scope, $rootScope, TechnologyRegionChart, NewMetricTechService, CustomerChartService, $state, LoaderService, $timeout) {
            jQuery.fn.center = function() {
                this.css({
                    top: ($(window).outerHeight()) / 2,
                    left: ($(window).outerWidth()) / 2
                });
                return this;
            };
            
            $(".loading").center();

            function loaderOps(state) {
                LoaderService.loaderOps(state);
            }
            
            loaderOps(true);
            
            $('ib-metric').find('#techRegionChart1').click(function() {
                $state.go('ib/TechnoRegion');
            });
            
            $('ib-metric').find('#topCustomerChart1').click(function() {
                $state.go('ib/topCustomer');
            });
            
            $timeout(function() {
                if (!$rootScope.accountManager && !$rootScope.marketIndustry) {
                    $rootScope.ibMetricsSearchData();
                }
            }, 5000);
            
            $rootScope.ibMetricsSearchData = function() {
                var item = {};
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";

                NetworkCallService.getIBMetricsData(JSON.stringify(item)).then(function(responseData) {
                    $scope.techRegionData = responseData.technologyDataBean;
                    $scope.custNameData = responseData.custNameDataBean;
                    var techRegionChartData = TechnologyRegionChart.updateTechReg(responseData.technologyDataBean);
                    $scope.totalcount = numberWithCommas(techRegionChartData['totalcount']);
                    NewMetricTechService.technoRegChart(techRegionChartData['technology'], techRegionChartData['regionWithCount'], 'techRegionChart1', techRegionChartData['colorCode']);
                    UpdateTopCust();
                    resizeAll();
                });
            }
            
            function UpdateTopCust() {
                var serviceData = CustomerChartService.getCustomerData($scope.custNameData);
                var customers = serviceData['customers'],
                    chartData = serviceData['chartData'];
                $scope.totalCustomerCount = numberWithCommas(serviceData['totalCustomerCount']);
                CustomerChartService.topCustChart(customers, chartData, 'topCustomerChart1');
                loaderOps(false);
            }
        }
    ]);
});