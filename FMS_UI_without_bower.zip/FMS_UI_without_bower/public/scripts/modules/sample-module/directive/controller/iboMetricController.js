define(['angular', '../../sample-module', 'jquery'], function(angular, controllers, jquery) {
    'use strict';
    controllers.controller('IBOMetricsController', ['CreateHighChartService', '$scope', '$rootScope', 'IBOMetricsService', 'NewMetricTechService', 'CustomerChartService', 'IBOChartService', 'IBOCustomerService', '$state', '$timeout',
        function(CreateHighChartService, $scope, $rootScope, IBOMetricsService, NewMetricTechService, CustomerChartService, IBOChartService, IBOCustomerService, $state, $timeout) {
            
            $('ibo-metrics').find('#ibo_technoRegion').click(function() {
                $state.go('ibo/technoRegion');
            });
            
            $('ibo-metrics').find('#ibo_topCustomerChart1').click(function() {
                $state.go('ibo/topCustomer');
            });
            
            $timeout(function() {
                if (!$rootScope.accountManager && !$rootScope.marketIndustry) {
                    $rootScope.iboMetricsSearchData();
                }
            }, 5000);

            $rootScope.iboMetricsSearchData = function() {
                var item = {};
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";

                IBOMetricsService.getIBOMetricsDashboard(JSON.stringify(item)).then(function(response) {
                    var ibo_techRegionChartData = (IBOChartService.updateTechReg(response.iBTechnologyDataBean));
                    $('#ibo_technoRegion,#ibo_topCustomerChart1').outerHeight($('.iboChart').height());
                    CreateHighChartService.createIBOColumnChart(ibo_techRegionChartData['technology'], ibo_techRegionChartData['regionWithCount'], 'ibo_technoRegion', ibo_techRegionChartData['colorCode'], 'ibo/technoRegion');
                    var ibo_totalcountNum = (ibo_techRegionChartData['totalcount']).toFixed(0);
                    $scope.ibo_totalcount = numberWithCommas(ibo_totalcountNum);
                    var iboCustData = (IBOCustomerService.getCustomerData(response.iBCustNameDataBean));
                    var ibo_totalCustomerCountNum = (iboCustData['totalCustomerCount']).toFixed(0);
                    $scope.ibo_totalCustomerCount = numberWithCommas(ibo_totalCustomerCountNum);
                    CreateHighChartService.createIBOChart(iboCustData['customers'], iboCustData['chartData'], 'ibo_topCustomerChart1', 'ibo/topCustomer');
                });
            }
        }
    ]);
});