define(['angular','../../../sample-module','jquery', 'datatablesNetMin', 'datatablesNet','multiselectdrpdwn','jqueryMultiSelect'], function (angular,controllers) 
 {
    'use strict';
    controllers.controller('countrylevelMetricsController', ['$scope','$timeout','$state','$rootScope','LoaderService','countryLevelDataNetworkService','countryIBByRegionService',
                                                             'CountryIBbyRegionChart','CountryOpexpenetrationCurDataService','CountryOpexPenetrationChartService',
                                                             'CountryFleetpenetrationDataService','CountryFleetPenetrationChartService','CountryFleetcoverageDataService',
                                                             'CountryFleetCoverageChartService','CountryCaloricbyRegionCurDataService','CountryCaloricRegionChartService',
                                                             'CountryConversionIndexDataService','CountryConversionIndexChartService',
                                                             'TechnoOpexpenetrationCurDataService','TechnoOpexPenetrationChartService','TechnoFleetpenetrationDataService',
                                                             'TechnoFleetPenetrationChartService','TechnoFleetcoverageDataService','TechnoFleetCoverageChartService',
                                                             'TechnoCaloricbyRegionCurDataService','TechnoCaloricRegionChartService','siteCaloricbyRegionCurDataService','SiteCaloricRegionChartService',
                                                             'SiteOpexpenetrationCurDataService','SiteOpexPenetrationChartService','SiteFleetpenetrationDataService','SiteFleetPenetrationChartService',
                                                             'SiteFleetcoverageDataService','SiteFleetCoverageChartService','$http','$q','SiteDataService','SiteExportDataService','DunsCaloricbyRegionCurDataService',
                                                             'DunsOpexpenetrationCurDataService','DunsFleetpenetrationDataService','DunsFleetcoverageDataService','DunsCaloricRegionChartService','DunsOpexPenetrationChartService',
                                                             'DunsFleetPenetrationChartService','DunsFleetCoverageChartService','DunsDataService','DunsExportDataService','CountryPartsPenCurDataService','CountryPartsPenChartService',
                                                             'TechnoPartsPenDataService','TechnoPartsPenChartService','SegmentDataService','SegmentChartService',
	function ($scope,$timeout,$state,$rootScope,LoaderService,countryLevelDataNetworkService,countryIBByRegionService,CountryIBbyRegionChart,CountryOpexpenetrationCurDataService,
			CountryOpexPenetrationChartService,CountryFleetpenetrationDataService,CountryFleetPenetrationChartService,CountryFleetcoverageDataService,CountryFleetCoverageChartService,
			CountryCaloricbyRegionCurDataService,CountryCaloricRegionChartService,CountryConversionIndexDataService,CountryConversionIndexChartService,
			TechnoOpexpenetrationCurDataService,TechnoOpexPenetrationChartService,TechnoFleetpenetrationDataService,TechnoFleetPenetrationChartService,TechnoFleetcoverageDataService,TechnoFleetCoverageChartService,
			TechnoCaloricbyRegionCurDataService,TechnoCaloricRegionChartService,siteCaloricbyRegionCurDataService,SiteCaloricRegionChartService,SiteOpexpenetrationCurDataService,SiteOpexPenetrationChartService,
			SiteFleetpenetrationDataService,SiteFleetPenetrationChartService,SiteFleetcoverageDataService,SiteFleetCoverageChartService,$http,$q,SiteDataService,SiteExportDataService,DunsCaloricbyRegionCurDataService,
			DunsOpexpenetrationCurDataService,DunsFleetpenetrationDataService,DunsFleetcoverageDataService,DunsCaloricRegionChartService,DunsOpexPenetrationChartService,DunsFleetPenetrationChartService,
			DunsFleetCoverageChartService,DunsDataService,DunsExportDataService,CountryPartsPenCurDataService,CountryPartsPenChartService,TechnoPartsPenDataService,TechnoPartsPenChartService,SegmentDataService,SegmentChartService){
    	

		
		$('.errorIndicator,.techerrorIndicator, .techCountryerrorIndicator,.siteerrorIndicator,.siteEntryerrorIndicator, .siteCountryerrorIndicator,.dunserrorIndicator,.dunsSiteserrorIndicator,.dunsEntryerrorIndicator,.segmenterrorIndicator').hide(100);
    	$('#depdunsSiteSearch').hide(100);
    	$('.countryPanelHead').click(false);
    	$('.techPanelHead').click(false);
    	$('.sitePanelHead').click(false);
    	$('button#placeDunsboMultiSelect').show(100);
    	$scope.regionSelected = true;
    	jQuery.fn.center = function() {
            this.css({top: ($(window).outerHeight()) / 2,left: ($(window).outerWidth()) / 2});
			return this;
		};
		
    	$(".loading").center();
		function loaderOps(state){
			LoaderService.loaderOps(state);
		}
		loaderOps(true);
		$scope.safeApply =function(fn){
			$timeout(fn);
		}
     $('button#placeTechboMultiSelect').show(100);
    	 $('#deptechSiteCustCountrySearch').hide(100);
    	
    	 $('#depRegionSearch').off().on('change', function() {
			$scope.getCountries();
    	 });
    	
    	 $('#techRegionSearch').off().on('change', function(){
    		$('#deptechSiteCustCountrySearch').prop("disabled", false);
			$scope.getTechCountries();
    	 });
    	
    	 $scope.getCountries = function() {
        	var item = {};
    			$('#depRegionSearch').removeClass('boxShadow');
    			var selectedregionvalue = $("select.dependentFilter[id='depRegionSearch']").val();
    			item["region"] = selectedregionvalue;
                item["businessSegment"]=$rootScope.businessSegment;
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
    			if(selectedregionvalue!==null && selectedregionvalue!=='Select Region'){
    				countryLevelDataNetworkService.getPenetratinMetricsCountryDropdown(JSON.stringify(item)).then(function(response){
    					var selectOption='', countryName='';
    					$timeout(function(){							
    						 $('.errorIndicator').hide(100);
    						 _.forEach(response, function(response){
    							 countryName = response;
    							 selectOption = selectOption + '<option value="'+countryName+'">'+countryName+'</option>'
    						})
    					})
    					.then(function(){
    						var scriptTag='<script>$("select#depSiteCustCountrySearch").multipleSelect({filter: true, selectAll: false});</script>'
    						$timeout(function(){
    							/* Show Multiselect */
    							$('#depSiteCustCountrySearch').empty().append(selectOption).append(scriptTag);
    							$('div.countrySelectBtn').show(100);
    							$('select.dependentFilter[id="depSiteCustCountrySearch"]').prop('disabled','false');
    							$('select.dependentFilter[id="depSiteCustCountrySearch"]').siblings().children().removeClass('disabled');
    							$('button#placeboMultiSelect').hide(100);									
    						});
    					});
    				});
    			}
    			else
    			{
    				$('select.dependentFilter[id="depSiteCustCountrySearch"]').prop('disabled','true');
    				$('select.dependentFilter[id="depSiteCustCountrySearch"]').siblings().children().addClass('disabled');
    				$timeout(function(){
    					$scope.regionSelected = true;
    				});
    			}
        	};
        	
        	$scope.getTechCountries=function(){
            	var item = {};
            	$('#deptechSiteCustCountrySearch').val("");
        			$('#techRegionSearch').removeClass('boxShadow');
        			var techselectedregionvalue = $("select.dependentTechFilter[id='techRegionSearch']").val();
        			item["region"] = techselectedregionvalue;
                    item["businessSegment"]=$rootScope.businessSegment;
                    item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
        			if(techselectedregionvalue!==null && techselectedregionvalue!=='Select Region'){
        				countryLevelDataNetworkService.getPenetratinMetricsCountryDropdown(JSON.stringify(item)).then(function(response){
        					 $scope.countryDropdownBean = response;
        					$timeout(function(){		
        						$('div.techfilterSelect').show(100);
        						 $('.techerrorIndicator').hide(100);
        						 $('button#placeTechboMultiSelect').hide(100);
        						 $('#deptechSiteCustCountrySearch').show(100);
        					})
        				});
        			}
        			else
        			{
        				$('select.dependentTechFilter[id="deptechSiteCustCountrySearch"]').prop('disabled','true');
        				$('select.dependentTechFilter[id="deptechSiteCustCountrySearch"]').siblings().children().addClass('disabled');
        				$timeout(function(){
        					$scope.regionSelected = true;
        				});
        			}
            	};
    	
    	
    	function getSelectedValue(id){
			var selector = "select.dependentFilter[id='"+id+"']";
			if(id==='depRegionSearch' && $(selector).val() != null){
				return $(selector).val();
			}
			else
			{
				if($(selector).val()!==undefined){
					var values = [];
					_.forEach($(selector).val(), function(choice){
						values.push("^"+choice+"$");
					});
					return values.join("|");
				}
				else
					return "";
			}
		}
    	
    	$rootScope.countryLevelSearchData = function(){
			var item = {};
			item["region"]           = getSelectedValue('depRegionSearch');
			item["country"]          = getSelectedValue('depSiteCustCountrySearch');
			item["businessSegment"]  = $rootScope.businessSegment;
            item["timePeriodType"]   = $rootScope.cHistoryLegacySwitch;
            item["marketIndustry"]   = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            
			if(!((item['region'])==='') && (item['region']).includes('undefined')===false && !((item['region'])==='Select Region')){
			loaderOps(true);
			countryLevelDataNetworkService.getAllMetricsCountryTechData(JSON.stringify(item)).then(function(response){
				$scope.allCountryMetricsData=response;
				$scope.createtable();
				$('#countryIBbyRegion,#countryOpexPenetrationF2F,#countryPenetrationbyRegion,#countryFleetcoverage,#countryCaloricIndexByRegion,#countryConversionIndex,#countryPartsPen,#countryRepairsPen,#countryServicePen').removeClass('panel-collapse collapse').addClass('panel-collapse collapse in').css("height", "");	
				loaderOps(false);
			});
			}
			else{
				$('#depRegionSearch').addClass("boxShadow");
				$('.errorIndicator').show(100);
			}
			$('.countryPanelHead').unbind('click');
		}
    	
    	  function setScopeData(result, key){
  			var variableName = key
  			$scope[variableName+'1'] = result[variableName+'1'];
  			$scope[variableName+'2'] = result[variableName+'2'];		  
  		  }
    	
    	$scope.createtable = function(){
    		var responseData =$scope.allCountryMetricsData;
    		var updateIBbyRegionCurData = countryIBByRegionService.updateIBbyRegionCurData(responseData);
			setScopeData(updateIBbyRegionCurData,'countryIBbyRegionCurDataTable' );
			var updateIBbyRegionHistData = countryIBByRegionService.updateIBbyRegionHistData(responseData);
			setScopeData(updateIBbyRegionHistData,'countryIBbyRegionHistDataTable' );
			var updateOpexpenetrationCurData = CountryOpexpenetrationCurDataService.updateOpexpenetrationCurData(responseData);
			setScopeData(updateOpexpenetrationCurData,'countryOpexpenetrationF2FCurDataTable' );
			var updateOpexpenetrationHistData = CountryOpexpenetrationCurDataService.updateOpexpenetrationHistData(responseData);
			setScopeData(updateOpexpenetrationHistData,'countryOpexpenetrationF2FHistDataTable' );
			var updateFleetpenetrationData = CountryFleetpenetrationDataService.updateFleetpenetrationData(responseData);
			setScopeData(updateFleetpenetrationData,'countryFleetpenetrationCurDataTable' );
			var updateFleetpenetrationHistData = CountryFleetpenetrationDataService.updateFleetpenetrationHistData(responseData);
			setScopeData(updateFleetpenetrationHistData,'countryFleetpenetrationHistDataTable' );
			var updateFleetcoverageData = CountryFleetcoverageDataService.updateFleetcoverageData(responseData);
			setScopeData(updateFleetcoverageData,'countryFleetcoverageCurDataTable' );
			var updateFleetcoverageHistData = CountryFleetcoverageDataService.updateFleetcoverageHistData(responseData);
			setScopeData(updateFleetcoverageHistData,'countryFleetcoverageHistDataTable' );
			var updateCaloricbyRegionCurData = CountryCaloricbyRegionCurDataService.updateCaloricbyRegionCurData(responseData);
			setScopeData(updateCaloricbyRegionCurData,'countryCaloricIndexRegCurDataTable' );
			var updateCaloricbyRegionHistData = CountryCaloricbyRegionCurDataService.updateCaloricbyRegionHistData(responseData);
			setScopeData(updateCaloricbyRegionHistData,'countryCaloricIndexRegHistDataTable' );
			var updateConversionIndexCurData = CountryConversionIndexDataService.updateConversionIndexCurData(responseData);
			setScopeData(updateConversionIndexCurData,'countryConversionIndexCurDataTable' );
			var updateConversionIndexHistData = CountryConversionIndexDataService.updateConversionIndexHistData(responseData);
			setScopeData(updateConversionIndexHistData,'countryConversionIndexHistDataTable' );
            
            //Changes
			var updatePartsPenCurData = CountryPartsPenCurDataService.updatePartsPenCurData(responseData.CURRENT.parts_fleet_penetration,'country-PartsPen-Cur-Data','countryPartsPenCurHeader','countryPartsPenCurData','countryPartsPenCurDataTable','countryContainer8');
			setScopeData(updatePartsPenCurData,'countryPartsPenCurDataTable' );
            
			var updatePartsPenHistData = CountryPartsPenCurDataService.updatePartsPenHistData(responseData.HISTORY.parts_fleet_penetration,responseData.AVERAGE_BASED_ON_YEAR.parts_fleet_penetration,responseData.AVERAGE.parts_fleet_penetration,'country-PartsPen-His-Data','countryPartsPenHisHeader','countryPartsPenHisData','countryPartsPenHistDataTable','countryContainer8History');
			setScopeData(updatePartsPenHistData,'countryPartsPenHistDataTable' );
            
			var updateRepairsPenCurData = CountryPartsPenCurDataService.updatePartsPenCurData(responseData.CURRENT.repairs_fleet_penetration,'country-RepairsPen-Cur-Data','countryRepairsPenCurHeader','countryRepairsPenCurData','countryRepairsPenCurDataTable','countryContainer9');
			setScopeData(updateRepairsPenCurData,'countryRepairsPenCurDataTable' );
            
			var updateRepairsPenHistData = CountryPartsPenCurDataService.updatePartsPenHistData(responseData.HISTORY.repairs_fleet_penetration,responseData.AVERAGE_BASED_ON_YEAR.repairs_fleet_penetration,responseData.AVERAGE.repairs_fleet_penetration,'country-RepairsPen-His-Data','countryRepairsPenHisHeader','countryRepairsPenHisData','countryRepairsPenHistDataTable','countryContainer9History');
			setScopeData(updateRepairsPenHistData,'countryRepairsPenHistDataTable' );
            
			var updateServicePenCurData = CountryPartsPenCurDataService.updatePartsPenCurData(responseData.CURRENT.svcs_fleet_penetration,'country-ServicePen-Cur-Data','countryServicePenCurHeader','countryServicePenCurData','countryServicePenCurDataTable','countryContainer10');
			setScopeData(updateServicePenCurData,'countryServicePenCurDataTable' );
            
			var updateServicePenHistData = CountryPartsPenCurDataService.updatePartsPenHistData(responseData.HISTORY.svcs_fleet_penetration,responseData.AVERAGE_BASED_ON_YEAR.svcs_fleet_penetration,responseData.AVERAGE.svcs_fleet_penetration,'country-ServicePen-His-Data','countryServicePenHisHeader','countryServicePenHisData','countryServicePenHistDataTable','countryContainer10History');
			setScopeData(updateServicePenHistData,'countryServicePenHistDataTable' );
		}
    	
    	$scope.excelcountryDownloadIB = function(id) {
    		countryIBByRegionService.excelDownload(id); 
	 	};
	 	$scope.exportCountryChartIB = function(type) {
	 		CountryIBbyRegionChart.exportChartCur(type); 
	 	};
	 	$scope.exportCountryHistoryChartIB = function(type) {
	 		CountryIBbyRegionChart.exportChartHistory(type); 
	 	};
	 	$scope.excelcountryDownloadOpex = function(id) {
	 		CountryOpexpenetrationCurDataService.excelDownload(id); 
	 	};
	 	$scope.exportcountryChartOpex = function(type) {
	 		CountryOpexPenetrationChartService.exportChart(type); 
	 	};
	 	$scope.exportcountryChartOpexHist = function(type) {
	 		CountryOpexPenetrationChartService.exportChartHist(type); 
	 	};
	 	$scope.excelcountryDownloadFleetPen = function(id) {
	 		CountryFleetpenetrationDataService.excelDownload(id); 
	 	};
	 	$scope.exportcountryChartFeetPen = function(type) {
	 		CountryFleetPenetrationChartService.exportChart(type); 
	 	};
	 	$scope.exportcountryChartFeetPenHist = function(type) {
	 		CountryFleetPenetrationChartService.exportChartHistory(type); 
	 	};
		$scope.excelcountryDownloadFleetCov = function(id) {
			CountryFleetcoverageDataService.excelDownload(id); 
	 	};
	 	$scope.exportcountryChartFeetCov = function(type) {
	 		CountryFleetCoverageChartService.exportChart(type); 
	 	};
		$scope.exportcountryChartFeetCovHist = function(type) {
			CountryFleetCoverageChartService.exportChartHistory(type); 
	 	};
	 	$scope.excelcountryDownloadColoric = function(id) {
	 		CountryCaloricbyRegionCurDataService.excelDownload(id); 
	 	};
	 	$scope.exportcountryChartCaloric = function(type) {
	 		CountryCaloricRegionChartService.exportChart(type); 
	 	};
		$scope.exportcountryChartCaloricHist = function(type) {
			CountryCaloricRegionChartService.exportChartHistory(type); 
	 	};
	 	$scope.excelcountryDownloadConversion = function(id) {
	 		CountryConversionIndexDataService.excelDownload(id); 
	 	};
	 	$scope.exportcountryChartConversion = function(type) {
	 		CountryConversionIndexChartService.exportChart(type); 
	 	};
	 	$scope.exportcountryChartConversionHist = function(type) {
	 		CountryConversionIndexChartService.exportChartHistory(type); 
	 	};
	 	$scope.excelcountryDownloadPartsPen = function(id) {
	 		CountryPartsPenCurDataService.excelDownload(id); 
	 	};
	 	$scope.exportcountryChartPartsPen = function(type) {
	 		CountryPartsPenChartService.exportChart(type,'Parts-Penetration-Current-Chart','countryContainer8'); 
	 	};
	 	$scope.exportcountryChartPartsPenHist = function(type) {
	 		CountryPartsPenChartService.exportChartHist(type,'Parts-Penetration-History-Chart','countryContainer8History'); 
	 	};
	 	$scope.excelcountryDownloadRepairsPen = function(id) {
	 		CountryPartsPenCurDataService.excelDownload(id); 
	 	};
	 	$scope.exportcountryChartRepairsPen = function(type) {
	 		CountryPartsPenChartService.exportChart(type,'Repairs-Penetration-Current-Chart','countryContainer9'); 
	 	};
	 	$scope.exportcountryChartRepairsPenHist = function(type) {
	 		CountryPartsPenChartService.exportChartHist(type,'Repairs-Penetration-History-Chart','countryContainer9History'); 
	 	};
	 	$scope.excelcountryDownloadServicePen = function(id) {
	 		CountryPartsPenCurDataService.excelDownload(id); 
	 	};
	 	$scope.exportcountryChartServicePen = function(type) {
	 		CountryPartsPenChartService.exportChart(type,'Service-Penetration-Current-Chart','countryContainer10'); 
	 	};
	 	$scope.exportcountryChartServicePenHist = function(type) {
	 		CountryPartsPenChartService.exportChartHist(type,'Service-Penetration-History-Chart','countryContainer10History'); 
	 	};
    	
	 	
	 	function getTechSelectedValue(id){
			var selector = "select.dependentTechFilter[id='"+id+"']";
			if(id==='techRegionSearch' && $(selector).val() != null){
				return $(selector).val();
			}
			else
			{
				if($(selector).val()!==undefined){
					return $(selector).val();
				}
				else
					return "";
			}
		}
	 	
	 	$rootScope.technologyLevelSearchData = function(){
	 		var item = {};
	 		item["region"]          = getTechSelectedValue('techRegionSearch');
	 		item["country"]         = getTechSelectedValue('deptechSiteCustCountrySearch');
	 		item["businessSegment"] = $rootScope.businessSegment;
            item["timePeriodType"]  = $rootScope.cHistoryLegacySwitch;
            item["marketIndustry"]  = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";

	 		if(item["region"]==="ALL"){
	 			item["region"]='';
	 		}
	 		if(item["country"]==="Select Country"){
	 			item["country"]='';
	 		}
	 		loaderOps(true);
	 		countryLevelDataNetworkService.getAllMetricsTechnologyData(JSON.stringify(item)).then(function(response){
	 			$scope.allTechnologyMetricsData=response;
	 			$scope.createTechnoTable();
	 			$('#techOpexPenetrationF2F,#techPenetrationbyRegion,#techFleetcoverage,#techCaloricIndexByRegion,#techPartsPen,#techRepairsPen,#techServicePen').removeClass('panel-collapse collapse').addClass('panel-collapse collapse in').css("height", "");	
	 			loaderOps(false);
	 		});
	 		$('.techPanelHead').unbind('click');

	 	}
	 	
	 	$scope.createTechnoTable = function(){
    		var responseTechData =$scope.allTechnologyMetricsData;
			var updateOpexpenetrationCurData = TechnoOpexpenetrationCurDataService.updateOpexpenetrationCurData(responseTechData);
			setScopeData(updateOpexpenetrationCurData,'techOpexpenetrationF2FCurDataTable' );
			var updateOpexpenetrationHistData = TechnoOpexpenetrationCurDataService.updateOpexpenetrationHistData(responseTechData);
			setScopeData(updateOpexpenetrationHistData,'techOpexpenetrationF2FHistDataTable' );
			var updateFleetpenetrationData = TechnoFleetpenetrationDataService.updateFleetpenetrationData(responseTechData);
			setScopeData(updateFleetpenetrationData,'techFleetpenetrationCurDataTable' );
			var updateFleetpenetrationHistData = TechnoFleetpenetrationDataService.updateFleetpenetrationHistData(responseTechData);
			setScopeData(updateFleetpenetrationHistData,'techFleetpenetrationHistDataTable' );
			var updateFleetcoverageData = TechnoFleetcoverageDataService.updateFleetcoverageData(responseTechData);
			setScopeData(updateFleetcoverageData,'techFleetcoverageCurDataTable' );
			var updateFleetcoverageHistData = TechnoFleetcoverageDataService.updateFleetcoverageHistData(responseTechData);
			setScopeData(updateFleetcoverageHistData,'techFleetcoverageHistDataTable' );
			var updateCaloricbyRegionCurData = TechnoCaloricbyRegionCurDataService.updateCaloricbyRegionCurData(responseTechData);
			setScopeData(updateCaloricbyRegionCurData,'techCaloricIndexRegCurDataTable' );
			var updateCaloricbyRegionHistData = TechnoCaloricbyRegionCurDataService.updateCaloricbyRegionHistData(responseTechData);
			setScopeData(updateCaloricbyRegionHistData,'techCaloricIndexRegHistDataTable' );
            
            //Changes
			var updatePartsPenCurData = TechnoPartsPenDataService.updatePartsPenetrationCurData(responseTechData.CURRENT.parts_fleet_penetration,'tech-PartsPen-Cur-Data','techPartsPenCurHeader','techPartsPenCurData','techPartsPenCurDataTable','techContainer7');
			setScopeData(updatePartsPenCurData,'techPartsPenCurDataTable' );
            
			var updatePartsPenHistData = TechnoPartsPenDataService.updatePartsPenetrationHistData(responseTechData.HISTORY.parts_fleet_penetration,responseTechData.AVERAGE_BASED_ON_YEAR.parts_fleet_penetration,responseTechData.AVERAGE.parts_fleet_penetration,'tech-PartsPen-His-Data','techPartsPenHisHeader','techPartsPenHisData','techPartsPenHistDataTable','techContainer7History');
            setScopeData(updatePartsPenHistData,'techPartsPenHistDataTable' );
            
			var updateRepairsPenCurData = TechnoPartsPenDataService.updatePartsPenetrationCurData(responseTechData.CURRENT.repairs_fleet_penetration,'tech-RepairsPen-Cur-Data','techRepairsPenCurHeader','techRepairsPenCurData','techRepairsPenCurDataTable','techContainer8');
			setScopeData(updateRepairsPenCurData,'techRepairsPenCurDataTable' );
            
			var updateRepairsPenHistData = TechnoPartsPenDataService.updatePartsPenetrationHistData(responseTechData.HISTORY.repairs_fleet_penetration,responseTechData.AVERAGE_BASED_ON_YEAR.repairs_fleet_penetration,responseTechData.AVERAGE.repairs_fleet_penetration,'tech-RepairsPen-His-Data','techRepairsPenHisHeader','techRepairsPenHisData','techRepairsPenHistDataTable','techContainer8History');
			setScopeData(updateRepairsPenHistData,'techRepairsPenHistDataTable' );
            
			var updateServicePenCurData = TechnoPartsPenDataService.updatePartsPenetrationCurData(responseTechData.CURRENT.svcs_fleet_penetration,'tech-ServicePen-Cur-Data','techServicePenCurHeader','techServicePenCurData','techServicePenCurDataTable','techContainer9');
			setScopeData(updateServicePenCurData,'techServicePenCurDataTable' );
            
			var updateServicePenHistData = TechnoPartsPenDataService.updatePartsPenetrationHistData(responseTechData.HISTORY.svcs_fleet_penetration,responseTechData.AVERAGE_BASED_ON_YEAR.svcs_fleet_penetration,responseTechData.AVERAGE.svcs_fleet_penetration,'tech-ServicePen-His-Data','techServicePenHisHeader','techServicePenHisData','techServicePenHistDataTable','techContainer9History');
			setScopeData(updateServicePenHistData,'techServicePenHistDataTable' );
		}
	 	$scope.excelTechDownloadOpex = function(id) {
	 		TechnoOpexpenetrationCurDataService.excelDownload(id); 
	 	};
	 	$scope.exportTechChartOpex = function(type) {
	 		TechnoOpexPenetrationChartService.exportChart(type); 
	 	};
	 	$scope.exportTechChartOpexHist = function(type) {
	 		TechnoOpexPenetrationChartService.exportChartHist(type); 
	 	};
	 	$scope.excelTechDownloadFleetPen = function(id) {
	 		TechnoFleetpenetrationDataService.excelDownload(id); 
	 	};
	 	$scope.exportTechChartFeetPen = function(type) {
	 		TechnoFleetPenetrationChartService.exportChart(type); 
	 	};
	 	$scope.exportTechChartFeetPenHist = function(type) {
	 		TechnoFleetPenetrationChartService.exportChartHistory(type); 
	 	};
	 	$scope.excelTechDownloadFleetCov = function(id) {
			TechnoFleetcoverageDataService.excelDownload(id); 
	 	};
	 	$scope.exportTechChartFeetCov = function(type) {
	 		TechnoFleetCoverageChartService.exportChart(type); 
	 	};
		$scope.exportTechChartFeetCovHist = function(type) {
			TechnoFleetCoverageChartService.exportChartHistory(type); 
	 	};
	 	$scope.excelTechDownloadColoric = function(id) {
	 		TechnoCaloricbyRegionCurDataService.excelDownload(id); 
	 	};
	 	$scope.exportTechChartCaloric = function(type) {
	 		TechnoCaloricRegionChartService.exportChart(type); 
	 	};
		$scope.exportTechChartCaloricHist = function(type) {
			TechnoCaloricRegionChartService.exportChartHistory(type); 
	 	};
	 	$scope.excelTechDownloadPartsPen = function(id) {
	 		TechnoPartsPenDataService.excelDownload(id); 
	 	};
	 	$scope.exportTechChartPartsPen = function(type) {
	 		TechnoPartsPenChartService.exportChart(type,'Parts-Penetration-Current-Chart','techContainer7'); 
	 	};
		$scope.exportTechChartPartsPenHist = function(type) {
			TechnoPartsPenChartService.exportChartHist(type,'Parts-Penetration-History-Chart','techContainer7History'); 
	 	};
	 	$scope.excelTechDownloadRepairsPen = function(id) {
	 		TechnoPartsPenDataService.excelDownload(id); 
	 	};
	 	$scope.exportTechChartRepairsPen = function(type) {
	 		TechnoPartsPenChartService.exportChart(type,'Repairs-Penetration-Current-Chart','techContainer8'); 
	 	};
		$scope.exportTechChartRepairsPenHist = function(type) {
			TechnoPartsPenChartService.exportChartHist(type,'Repairs-Penetration-History-Chart','techContainer8History'); 
	 	};
	 	$scope.excelTechDownloadServicePen = function(id) {
	 		TechnoPartsPenDataService.excelDownload(id); 
	 	};
	 	$scope.exportTechChartServicePen = function(type) {
	 		TechnoPartsPenChartService.exportChart(type,'Service-Penetration-Current-Chart','techContainer9'); 
	 	};
		$scope.exportTechChartServicePenHist = function(type) {
			TechnoPartsPenChartService.exportChartHist(type,'Service-Penetration-History-Chart','techContainer9History'); 
	 	};
	 	
	 	
    	$scope.dep_clearData = function(){
    		$('#depRegionSearch').val("");
			$('#depSiteCustCountrySearch').empty();
			$('#deptechSiteCustCountrySearch').prop("disabled", false);
			_.defer(function(){
				$('div.countrySelectBtn').hide(100);
				$('select.dependentFilter[id="depSiteCustCountrySearch"]').prop('disabled','true');
				$('select.dependentFilter[id="depSiteCustCountrySearch"]').siblings().children().addClass('disabled');
				$('button#placeboMultiSelect').show(100);
			});
			
			$('.panel-heading').bind('click', function(e){
		        e.preventDefault();
			})
			$('.countryPanelHead').click(false);
			$('#depRegionSearch').removeClass("boxShadow");
			$('.errorIndicator').hide();
			$('#countryIBbyRegion,#countryOpexPenetrationF2F,#countryPenetrationbyRegion,#countryFleetcoverage,#countryCaloricIndexByRegion,#countryConversionIndex,#countryPartsPen,#countryRepairsPen,#countryServicePen').removeClass('panel-collapse collapse in').addClass('panel-collapse collapse');
			loaderOps(false);
    	}
    	
    	$scope.clearData = function(){
    		$('#techRegionSearch').val("ALL");
			$('#deptechSiteCustCountrySearch').val("");
			_.defer(function(){
				$('div.techfilterSelect').hide(100);
			    $('#deptechSiteCustCountrySearch').hide(100);
				$('button#placeTechboMultiSelect').show(100);
			});
			$('.techPanelHead').click(false);
			$('#techRegionSearch').removeClass("boxShadow");
			$('.techerrorIndicator').hide();
			$('.techCountryerrorIndicator').hide(100);	
			$('#techIBbyRegion,#techOpexPenetrationF2F,#techPenetrationbyRegion,#techFleetcoverage,#techCaloricIndexByRegion,#techConversionIndex,#techPartsPen,#techRepairsPen,#techServicePen').removeClass('panel-collapse collapse in').addClass('panel-collapse collapse');
			loaderOps(false);
    	}
    	
    	$scope.ShowHide22 = function(){
			$scope.IsVisible22 = $scope.IsVisible22 ? false : true;
			$scope.IsHidden22=$scope.IsHidden22 ? false : true;
		};		
		$scope.ShowHide33 = function(){
			$scope.IsVisible33 = $scope.IsVisible33 ? false : true;
			$scope.IsHidden33=$scope.IsHidden33 ? false : true;
		};	
		$scope.ShowHide44 = function(){
			$scope.IsVisible44 = $scope.IsVisible44 ? false : true;
			$scope.IsHidden44=$scope.IsHidden44 ? false : true;
		};
		$scope.ShowHide55 = function(){
			$scope.IsVisible55 = $scope.IsVisible55 ? false : true;
			$scope.IsHidden55=$scope.IsHidden55 ? false : true;
		};
		$scope.ShowHide66 = function(){
			$scope.IsVisible66 = $scope.IsVisible66 ? false : true;
			$scope.IsHidden66=$scope.IsHidden66 ? false : true;
		};
		$scope.ShowHide77 = function(){
			$scope.IsVisible77 = $scope.IsVisible77 ? false : true;
			$scope.IsHidden77=$scope.IsHidden77 ? false : true;
		};
		$scope.ShowHide88 = function(){
			$scope.IsVisible88 = $scope.IsVisible88 ? false : true;
			$scope.IsHidden88=$scope.IsHidden88 ? false : true;
		};
		$scope.ShowHide99 = function(){
			$scope.IsVisible99 = $scope.IsVisible99 ? false : true;
			$scope.IsHidden99=$scope.IsHidden99 ? false : true;
		};
		$scope.ShowHide71 = function(){
			$scope.IsVisible71 = $scope.IsVisible71 ? false : true;
			$scope.IsHidden71=$scope.IsHidden71 ? false : true;
		};
		$scope.ShowHide333 = function(){
			$scope.IsVisible333 = $scope.IsVisible333 ? false : true;
			$scope.IsHidden333=$scope.IsHidden333 ? false : true;
		};	
		$scope.ShowHide444 = function(){
			$scope.IsVisible444 = $scope.IsVisible444 ? false : true;
			$scope.IsHidden444=$scope.IsHidden444 ? false : true;
		};
		$scope.ShowHide555 = function(){
			$scope.IsVisible555 = $scope.IsVisible555 ? false : true;
			$scope.IsHidden555=$scope.IsHidden555 ? false : true;
		};
		$scope.ShowHide666 = function(){
			$scope.IsVisible666 = $scope.IsVisible666 ? false : true;
			$scope.IsHidden666=$scope.IsHidden666 ? false : true;
		};
		$scope.ShowHide777 = function(){
			$scope.IsVisible777 = $scope.IsVisible777 ? false : true;
			$scope.IsHidden777=$scope.IsHidden777 ? false : true;
		};
		$scope.ShowHide888 = function(){
			$scope.IsVisible888 = $scope.IsVisible888 ? false : true;
			$scope.IsHidden888=$scope.IsHidden888 ? false : true;
		};
		$scope.ShowHide999 = function(){
			$scope.IsVisible999 = $scope.IsVisible999 ? false : true;
			$scope.IsHidden999=$scope.IsHidden999 ? false : true;
		};
		$scope.getSiteCountries=function(){
        	var item = {};
        	$('#depSitePenSearch').val("");
        	$('#depsiteEntriesSearch').val("");
    			$('#siteRegionSearch').removeClass('boxShadow');
    			var siteSelectedregionvalue = $("select.dependentSiteFilter[id='siteRegionSearch']").val();
    			item["region"] = siteSelectedregionvalue;
    			item["state"] = 'site';
    			if(siteSelectedregionvalue!==null && siteSelectedregionvalue!=='Select Region'){
    				countryLevelDataNetworkService.getAllMetricsCountrySiteDropdown(JSON.stringify(item)).then(function(response){
    					 $scope.sitecountryDropdownBean = response;
    					$timeout(function(){		
    						$('div.sitefilterSelect').show(100);
    						 $('.siteerrorIndicator').hide(100);
    						 $('button#placeSiteboMultiSelect').hide(100);
    						 $('#depSitePenSearch').show(100);
    					})
    				});
    			}
    			else
    			{
    				$('select.dependentSiteFilter[id="depSitePenSearch"]').prop('disabled','true');
    				$('select.dependentSiteFilter[id="depSitePenSearch"]').siblings().children().addClass('disabled');
    				$timeout(function(){
    					$scope.regionSelected = true;
    				});
    			}
        	};
		
		$('#siteRegionSearch').off().on('change', function(){
    		$('#depSitePenSearch').prop("disabled", false);
			$scope.getSiteCountries();
		});
		
		$('#depSitePenSearch').off().on('change', function(){
    		$('#depsiteEntriesSearch').prop("disabled", false);
    		$timeout(function(){
    			$('#depsiteEntriesSearch').val("");
				$('div.sitefilterSelect').show(100);
				$("#depsiteEntriesSearch").val("top25");
				 $('.siteCountryerrorIndicator').hide(100);
				 $('button#placeSiteEntryboMultiSelect').hide(100);
				 $('#depsiteEntriesSearch').show(100);
				 $('#depSitePenSearch').removeClass("boxShadow");
			})
		});
    	
		function getSiteSelectedValue(id){
			var selector = "select.dependentSiteFilter[id='"+id+"']";
			if(id==='siteRegionSearch' && $(selector).val() != null){
				return $(selector).val();
			}
			else
			{
				if($(selector).val()!==undefined){
					return $(selector).val();
				}
				else
					return "";
			}
		}
		
		$rootScope.siteLevelSearchData = function(){
			var item = {};
			item["region"]          = getSiteSelectedValue('siteRegionSearch');
			item["country"]         = getSiteSelectedValue('depSitePenSearch');
			item["type"]            = getSiteSelectedValue('depsiteEntriesSearch');
			item["businessSegment"] = $rootScope.businessSegment;
            item["timePeriodType"]  = $rootScope.cHistoryLegacySwitch;
            item["marketIndustry"]  = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            
			if(!((item['region'])==='') && !((item['region'])===null) && (item['region']).includes('undefined')===false && !((item['region'])==='Select Region')){
				if(!((item['country'])==='') && !((item['country'])===null) && (item['country']).includes('undefined')===false && !((item['country'])==='Select Country')){
					if(!((item['type'])==='') && !((item['type'])===null) && (item['type']).includes('undefined')===false && !((item['type'])==='Select Type')){
							loaderOps(true);
							$('.siteEntryerrorIndicator').hide(100);
							$('#depsiteEntriesSearch').removeClass("boxShadow");
							countryLevelDataNetworkService.getAllMetricsSitesData(JSON.stringify(item)).then(function(response){
								$scope.allSiteMetricsData=response;
								$scope.createSiteTable();
									$('#siteOpexPenetrationF2F,#sitePenetrationbyRegion,#siteFleetcoverage,#siteCaloricIndexByRegion').removeClass('panel-collapse collapse').addClass('panel-collapse collapse in').css("height", "");	
								loaderOps(false);
						});
					}
					else{
						$('#depsiteEntriesSearch').addClass("boxShadow");
						$('.siteEntryerrorIndicator').show(100);		
					}
				}else{
				$('#depSitePenSearch').addClass("boxShadow");
				$('.siteCountryerrorIndicator').show(100);				
				}
			}else {
				$('#siteRegionSearch').addClass("boxShadow");
				$('.siteerrorIndicator').show(100);
			}
			$('.sitePanelHead').unbind('click');
			
		}
		
		$scope.createSiteTable = function(){
    		var responseSiteData =$scope.allSiteMetricsData;
			var updateOpexpenetrationCurData = SiteOpexpenetrationCurDataService.updateOpexpenetrationCurData(responseSiteData);
			setScopeData(updateOpexpenetrationCurData,'siteOpexpenetrationF2FCurDataTable' );
			var updateOpexpenetrationHistData = SiteOpexpenetrationCurDataService.updateOpexpenetrationHistData(responseSiteData);
			setScopeData(updateOpexpenetrationHistData,'siteOpexpenetrationF2FHistDataTable' );
			var updateFleetpenetrationData = SiteFleetpenetrationDataService.updateFleetpenetrationData(responseSiteData);
			setScopeData(updateFleetpenetrationData,'siteFleetpenetrationCurDataTable' );
			var updateFleetpenetrationHistData = SiteFleetpenetrationDataService.updateFleetpenetrationHistData(responseSiteData);
			setScopeData(updateFleetpenetrationHistData,'siteFleetpenetrationHistDataTable' );
			var updateFleetcoverageData = SiteFleetcoverageDataService.updateFleetcoverageData(responseSiteData);
			setScopeData(updateFleetcoverageData,'siteFleetcoverageCurDataTable' );
			var updateFleetcoverageHistData = SiteFleetcoverageDataService.updateFleetcoverageHistData(responseSiteData);
			setScopeData(updateFleetcoverageHistData,'siteFleetcoverageHistDataTable' );
			var updateCaloricbyRegionCurData = siteCaloricbyRegionCurDataService.updateCaloricbyRegionCurData(responseSiteData);
			setScopeData(updateCaloricbyRegionCurData,'siteCaloricIndexRegCurDataTable' );
			var updateCaloricbyRegionHistData = siteCaloricbyRegionCurDataService.updateCaloricbyRegionHistData(responseSiteData);
			setScopeData(updateCaloricbyRegionHistData,'siteCaloricIndexRegHistDataTable' );
		}
	 	
		
		$scope.siteclearData = function(){
    		$('#siteRegionSearch').val("");
			$('#depSitePenSearch').val("");
			$('#depsiteEntriesSearch').val("");
			_.defer(function(){
				$('div.sitefilterSelect').hide(100);
			    $('#depSitePenSearch').hide(100);
				$('button#placeSiteboMultiSelect').show(100);
				$('#depsiteEntriesSearch').hide(100);
				$('button#placeSiteEntryboMultiSelect').show(100);
			});
			$('.sitePanelHead').click(false);
			$('#siteRegionSearch').removeClass("boxShadow");
			$('.siteerrorIndicator').hide(100);	
			$('.siteCountryerrorIndicator').hide(100);
			$('#depSitePenSearch').removeClass("boxShadow");
			$('#siteOpexPenetrationF2F,#sitePenetrationbyRegion,#siteFleetcoverage,#siteCaloricIndexByRegion').removeClass('panel-collapse collapse in').addClass('panel-collapse collapse');
			loaderOps(false);
    	}
        
        var calData;
        $scope.getSiteData = function(id,period,report){
			 var  data = {};
             data["region"]          = getSiteSelectedValue('siteRegionSearch');
             data["country"]         = getSiteSelectedValue('depSitePenSearch');
             data["type"]            = getSiteSelectedValue('depsiteEntriesSearch');
             data["period"]          = period;
             data["report"]          = report;
             data["businessSegment"] = $rootScope.businessSegment;
             data["timePeriodType"]  = $rootScope.cHistoryLegacySwitch;
             data["marketIndustry"]  = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
             
             loaderOps(true);
             countryLevelDataNetworkService.getAllMetricsexportSitesData(JSON.stringify(data)).then(function(response){
					$scope.exportData = response;
		             if(period === "current"){
		            	 calData = SiteDataService.excelDownload($scope.exportData,id,$scope);
		             }
		             else{
		            	 calData = SiteDataService.downloadhist($scope.exportData,id,report);
		             };
					loaderOps(false);
					SiteExportDataService.excelHistoryDataDownload(calData['id'],calData['keysExcelHeaders'],calData['excelData'])
             });
		}
        
		$scope.excelSiteDownloadOpex = function(id,period,report,businessSegment) {
			$scope.getSiteData(id,period,report,businessSegment);
	 	};
        
	 	$scope.excelSiteDownloadFleetPen = function(id,period,report,businessSegment) {
	 		$scope.getSiteData(id,period,report,businessSegment);
	 	};
	 	
	 	$scope.excelSiteDownloadFleetCov = function(id,period,report,businessSegment) {
	 		$scope.getSiteData(id,period,report,businessSegment);
	 	};
	 	
	 	$scope.excelSiteDownloadColoric = function(id,period,report,businessSegment) {
	 		$scope.getSiteData(id,period,report,businessSegment);
			
	 	};
	 	
	 	$scope.exportSiteChartOpex = function(type) {
	 		SiteOpexPenetrationChartService.exportChart(type); 
	 	};
	 	$scope.exportSiteChartOpexHist = function(type) {
	 		SiteOpexPenetrationChartService.exportChartHist(type); 
	 	};
	 	$scope.exportSiteChartFeetPen = function(type) {
	 		SiteFleetPenetrationChartService.exportChart(type); 
	 	};
	 	$scope.exportSiteChartFeetPenHist = function(type) {
	 		SiteFleetPenetrationChartService.exportChartHistory(type); 
	 	};
	 	$scope.exportSiteChartFeetCov = function(type) {
	 		SiteFleetCoverageChartService.exportChart(type); 
	 	};
		$scope.exportSiteChartFeetCovHist = function(type) {
			SiteFleetCoverageChartService.exportChartHistory(type); 
	 	};
	 	$scope.exportSiteChartCaloric = function(type) {
	 		SiteCaloricRegionChartService.exportChart(type); 
	 	};
		$scope.exportSiteChartCaloricHist = function(type) {
			SiteCaloricRegionChartService.exportChartHistory(type); 
	 	};
		
		$scope.ShowHideSite1 = function(){
				
			$scope.IsVisibleSite1 = $scope.IsVisibleSite1 ? false : true;
			$scope.IsHiddenSite1=$scope.IsHiddenSite1 ? false : true;
		};
		$scope.ShowHideSite2 = function(){
				
			$scope.IsVisibleSite2 = $scope.IsVisibleSite2 ? false : true;
			$scope.IsHiddenSite2=$scope.IsHiddenSite2 ? false : true;
		};
		$scope.ShowHideSite3 = function(){
				
			$scope.IsVisibleSite3 = $scope.IsVisibleSite3 ? false : true;
			$scope.IsHiddenSite3=$scope.IsHiddenSite3 ? false : true;
		};
		$scope.ShowHideSite4 = function(){
				
			$scope.IsVisibleSite4 = $scope.IsVisibleSite4 ? false : true;
			$scope.IsHiddenSite4=$scope.IsHiddenSite4 ? false : true;
		};
			$(".chzn-select").chosen();
		$scope.getdunsData = function(response) {
			$scope.geDunsDropdownBean = response;
			setTimeout(function(){
				$(".chzn-select").trigger("chosen:updated");
			},200);
			resizeAll();
			loaderOps(false);
		};
		
		$('#dunsRegionSearch').on('change', function(){
			$('#depDunsEntriesSearch').prop("disabled", false);
    		$timeout(function(){
    			$('#depDunsEntriesSearch').val("");
				$('div.dunsfilterSelect').show(100);
				$("#depDunsEntriesSearch").val("top25");
				 $('.dunserrorIndicator').hide(100);
				 $('button#placeDunsEntryboMultiSelect').hide(100);
				 $('#depDunsEntriesSearch').show(100);
				 $('#dunsReg').removeClass("boxShadow");
			})
		});
		
		function getDunsSelectedValue(id){
			var selector = "select.dependentDunsFilter[id='"+id+"']";
			if(id==='dunsRegionSearch' && $(selector).val() != null){
				return $(selector).val();
			}
			else
			{
				if($(selector).val()!==undefined){
					return $(selector).val();
				}
				else
					return "";
			}
		}
    	
		$rootScope.geDunsLevelSearchData = function(){
			var item = {};
			item["geDunsname"]      = getDunsSelectedValue('dunsRegionSearch');
			item["type"]            = getDunsSelectedValue('depDunsEntriesSearch');
			item["businessSegment"] = $rootScope.businessSegment;
            item["timePeriodType"]  = $rootScope.cHistoryLegacySwitch;
            item["marketIndustry"]  = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            
			if(!((item['geDunsname'])==='') && !((item['geDunsname'])===null)&&(item['geDunsname']).includes('undefined')===false && !((item['geDunsname'])==='Select Duns Name')){
					loaderOps(true);
					$('.dunserrorIndicator').hide(100);
					$('#dunsReg').removeClass("boxShadow");
					countryLevelDataNetworkService.getDunsSiteDropdownData(JSON.stringify(item)).then(function(response){
						$scope.allDunsMetricsData=response;
						$scope.createDunsTable();
						$('#dunsOpexPenetrationF2F,#dunsPenetrationbyRegion,#dunsFleetcoverage,#dunsCaloricIndexByRegion').removeClass('panel-collapse collapse').addClass('panel-collapse collapse in').css("height", "");
						loaderOps(false);
						
					});
			}else{
				$('#dunsReg').addClass("boxShadow");
				$('.dunserrorIndicator').show(100);
			}
			$('.dunsPanelHead').unbind('click');
		}
		
		$scope.createDunsTable = function(){
    		var responseDunsData =$scope.allDunsMetricsData;
			var updateOpexpenetrationCurData = DunsOpexpenetrationCurDataService.updateOpexpenetrationCurData(responseDunsData);
			setScopeData(updateOpexpenetrationCurData,'dunsOpexpenetrationF2FCurDataTable' );
			var updateOpexpenetrationHistData = DunsOpexpenetrationCurDataService.updateOpexpenetrationHistData(responseDunsData);
			setScopeData(updateOpexpenetrationHistData,'dunsOpexpenetrationF2FHistDataTable' );
			var updateFleetpenetrationData = DunsFleetpenetrationDataService.updateFleetpenetrationData(responseDunsData);
			setScopeData(updateFleetpenetrationData,'dunsFleetpenetrationCurDataTable' );
			var updateFleetpenetrationHistData = DunsFleetpenetrationDataService.updateFleetpenetrationHistData(responseDunsData);
			setScopeData(updateFleetpenetrationHistData,'dunsFleetpenetrationHistDataTable' );
			var updateFleetcoverageData = DunsFleetcoverageDataService.updateFleetcoverageData(responseDunsData);
			setScopeData(updateFleetcoverageData,'dunsFleetcoverageCurDataTable' );
			var updateFleetcoverageHistData = DunsFleetcoverageDataService.updateFleetcoverageHistData(responseDunsData);
			setScopeData(updateFleetcoverageHistData,'dunsFleetcoverageHistDataTable' );
			var updateCaloricbyRegionCurData = DunsCaloricbyRegionCurDataService.updateCaloricbyRegionCurData(responseDunsData);
			setScopeData(updateCaloricbyRegionCurData,'dunsCaloricIndexRegCurDataTable' );
			var updateCaloricbyRegionHistData = DunsCaloricbyRegionCurDataService.updateCaloricbyRegionHistData(responseDunsData);
			setScopeData(updateCaloricbyRegionHistData,'dunsCaloricIndexRegHistDataTable' );
		}
	 	
		
		$scope.dunsClearData = function(){
			$(".chzn-select").val('');
			$(".chzn-select").trigger("chosen:updated");
    		$('#dunsRegionSearch').val("");
			$('#depDunsEntriesSearch').val("");
			$('#depdunsSiteSearch').prop("disabled", false);
			_.defer(function(){
				$('div.dunsSiteSelectBtn').hide(100);
				$('select.dependentDunsFilter[id="depdunsSiteSearch"]').prop('disabled','true');
				$('select.dependentDunsFilter[id="depdunsSiteSearch"]').siblings().children().addClass('disabled');
				$('button#placeDunsboMultiSelect').show(100);
				$('#depDunsEntriesSearch').hide(100);
				$('button#placeDunsEntryboMultiSelect').show(100);
			});
			$('.panel-heading').bind('click', function(e){
		        e.preventDefault();
			})
			$('.dunsPanelHead').click(false);
			$('#dunsReg').removeClass("boxShadow");
			$('.dunserrorIndicator').hide();
			$('#dunsOpexPenetrationF2F,#dunsPenetrationbyRegion,#dunsFleetcoverage,#dunsCaloricIndexByRegion').removeClass('panel-collapse collapse in').addClass('panel-collapse collapse');
			loaderOps(false);
    	}
		
		var calDunsData;
	    $scope.getDunsData = function(id,period,report){
            var  data = {};
            data["geDunsName"]      = getDunsSelectedValue('dunsRegionSearch');
            data["period"]          = period;
            data["report"]          = report;
            data["businessSegment"] = $rootScope.businessSegment;
            data["timePeriodType"]  = $rootScope.cHistoryLegacySwitch;
            data["marketIndustry"]  = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
             
            loaderOps(true);
            countryLevelDataNetworkService.getAllMetricsexportDunsData(JSON.stringify(data)).then(function(response){
					$scope.exportDunsData = response;
		             if(period === "current"){
		            	 calDunsData = DunsDataService.excelDownload($scope.exportDunsData,id,$scope);
		             }
		             else{
		            	 calDunsData = DunsDataService.downloadhist($scope.exportDunsData,id,report);
		             };
					loaderOps(false);
					DunsExportDataService.excelHistoryDataDownload(calDunsData['id'],calDunsData['keysExcelHeaders'],calDunsData['excelData'])
            });
		}
        
		$scope.excelDunsDownloadOpex = function(id,period,report,businessSegment) {
			$scope.getDunsData(id,period,report,businessSegment);
	 	}; 
       
	 	$scope.excelDunsDownloadFleetPen = function(id,period,report,businessSegment) {
	 		$scope.getDunsData(id,period,report,businessSegment);
	 	};
	 	
	 	$scope.excelDunsDownloadFleetCov = function(id,period,report,businessSegment) {
	 		$scope.getDunsData(id,period,report,businessSegment);
	 	};
	 	
	 	$scope.excelDunsDownloadColoric = function(id,period,report,businessSegment) {
	 		$scope.getDunsData(id,period,report,businessSegment);
			
	 	};
		
		
		$scope.exportDunsChartOpex = function(type) {
	 		DunsOpexPenetrationChartService.exportChart(type); 
	 	};
	 	$scope.exportDunsChartOpexHist = function(type) {
	 		DunsOpexPenetrationChartService.exportChartHist(type); 
	 	};
	 	$scope.exportDunsChartFeetPen = function(type) {
	 		DunsFleetPenetrationChartService.exportChart(type); 
	 	};
	 	$scope.exportDunsChartFeetPenHist = function(type) {
	 		DunsFleetPenetrationChartService.exportChartHistory(type); 
	 	};
	 	$scope.exportDunsChartFeetCov = function(type) {
	 		DunsFleetCoverageChartService.exportChart(type); 
	 	};
		$scope.exportdunsChartFeetCovHist = function(type) {
			DunsFleetCoverageChartService.exportChartHistory(type); 
	 	};
	 	$scope.exportDunsChartCaloric = function(type) {
	 		DunsCaloricRegionChartService.exportChart(type); 
	 	};
		$scope.exportDunsChartCaloricHist = function(type) {
			DunsCaloricRegionChartService.exportChartHistory(type); 
	 	};
		
		
		$scope.ShowHideDuns333 = function(){
			$scope.IsVisibleDuns333 = $scope.IsVisibleDuns333 ? false : true;
			$scope.IsHiddenDuns333=$scope.IsHiddenDuns333 ? false : true;
		};	
		$scope.ShowHideDuns444 = function(){
			$scope.IsVisibleDuns444 = $scope.IsVisibleDuns444 ? false : true;
			$scope.IsHiddenDuns444=$scope.IsHiddenDuns444 ? false : true;
		};
		$scope.ShowHideDuns555 = function(){
			$scope.IsVisibleDuns555 = $scope.IsVisibleDuns555 ? false : true;
			$scope.IsHiddenDuns555=$scope.IsHiddenDuns555 ? false : true;
		};
		$scope.ShowHideDuns666 = function(){
			$scope.IsVisibleDuns666 = $scope.IsVisibleDuns666 ? false : true;
			$scope.IsHiddenDuns666=$scope.IsHiddenDuns666 ? false : true;
		};
		function getSegSelectedValue(id){
			var selector = "select.dependentSegmentFilter[id='"+id+"']";
			if((id==='segmentRegionSearch' && $(selector).val() != null && $(selector).val()!==undefined) || (id === 'depSegmentCountrySearch' && $(selector).val() !== null && $(selector).val() !== 'Select Country' && $(selector).val()!==undefined)){
				return $(selector).val();
			}else{
					return "";
			}
		}
		$('#segmentRegionSearch').off().on('change', function(){
			$('#depSegmentCountrySearch').prop("disabled", false);
			$scope.getSegCountries();
		});
		
		$scope.getSegCountries=function(){
        	var item = {};
        	$('#depSegmentCountrySearch').val("");
    		$('#segmentRegionSearch').removeClass('boxShadow');
    		var segSelectedregionvalue = $("select.dependentSegmentFilter[id='segmentRegionSearch']").val();
    		item["region"] = segSelectedregionvalue;
    		item["state"] = 'segment';
    		if(segSelectedregionvalue!==null && segSelectedregionvalue!=='Select Region'){
    			countryLevelDataNetworkService.getAllMetricsCountrySiteDropdown(JSON.stringify(item)).then(function(response){
    				 $scope.segcountryDropdownBean = response;
    				$timeout(function(){		
    					$('div.segmentfilterSelect').show(100);
    					 $('.segmenterrorIndicator').hide(100);
    					 $('button#placeSegmentboMultiSelect').hide(100);
    					 $('#depSegmentCountrySearch').show(100);
    				})
    			});
    		}else{
    			$('select.dependentSegmentFilter[id="depSegmentCountrySearch"]').prop('disabled','true');
    			$('select.dependentSegmentFilter[id="depSegmentCountrySearch"]').siblings().children().addClass('disabled');
    			$timeout(function(){
    				$scope.regionSelected = true;
    			});
    		}
    	}
		
		$rootScope.segmentLevelSearchData = function(){
			var item = {};
			item["region"]          = getSegSelectedValue('segmentRegionSearch');
			item["country"]         = getSegSelectedValue('depSegmentCountrySearch');
			item["businessSegment"] = $rootScope.businessSegment;
            item["timePeriodType"]  = $rootScope.cHistoryLegacySwitch;
            item["marketIndustry"]  = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            
			if(item["region"]==="ALL"){
				item["region"]='';
			}
			if(item["country"]==="Select Country"){
				item["country"]='';
			}
			loaderOps(true);
			$('.segmenterrorIndicator').hide(100);
			$('#segmentRegionSearch').removeClass("boxShadow");
			//getAllMetricsSegmentData
			countryLevelDataNetworkService.getAllMetricsSegmentData(JSON.stringify(item)).then(function(response){
				$scope.allSegMetricsData=response;
				$scope.createSegmentTable();
				$('#segmentOpexPenetrationF2F,#segmentPenetrationbyRegion,#segmentFleetcoverage,#segmentCaloricIndexByRegion').removeClass('panel-collapse collapse').addClass('panel-collapse collapse in').css("height", "");
				loaderOps(false);

			});
			$('.segmentPanelHead').unbind('click');
		}
		
		$scope.segClearData = function(){
			$('#segmentRegionSearch').val("ALL");
			$('#depSegmentCountrySearch').val("");
			_.defer(function(){
				$('button#placeSegmentboMultiSelect').show(100);
				$('#depSegmentCountrySearch').hide(100);
			});
			$('.panel-heading').bind('click', function(e){
		        e.preventDefault();
			})
			$('.segmentPanelHead').click(false);
			$('#segmentRegionSearch').removeClass("boxShadow");
			$('.segmenterrorIndicator').hide();
			$('#segmentOpexPenetrationF2F,#segmentPenetrationbyRegion,#segmentFleetcoverage,#segmentCaloricIndexByRegion').removeClass('panel-collapse collapse in').addClass('panel-collapse collapse');
			loaderOps(false);
		}
		$scope.createSegmentTable = function(){
			var responseSegData =$scope.allSegMetricsData;
			var updateSegOpexPenCurData = SegmentDataService.updateSegCurData(responseSegData.CURRENT.fleet_pen_f2f,'segment-Opex-Penetration-F2F-Cur-Data','segmentOpexPenCurHeader','segmentOpexPenCurData','segmentOpexpenetrationF2FCurDataTable','segmentContainer3');
			setScopeData(updateSegOpexPenCurData,'segmentOpexpenetrationF2FCurDataTable' );
            
			var updateSegOpexPenHistData = SegmentDataService.updateSegHistData(responseSegData.HISTORY.fleet_pen_f2f,responseSegData.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f,responseSegData.AVERAGE.fleet_pen_f2f,'segment-Opex-Penetration-F2F-His-Data','segmentOpexPenHisHeader','segmentOpexPenHisData','segmentOpexpenetrationF2FHistDataTable','segmentContainer3Hist');
			setScopeData(updateSegOpexPenHistData,'segmentOpexpenetrationF2FHistDataTable' );
            
			var updateSegPenCurData = SegmentDataService.updateSegCurData(responseSegData.CURRENT.fleet_penetration,'segment-Fleet-Penetration-Cur-Data','segmentFleetPenCurHeader','segmentFleetPenCurData','segmentFleetpenetrationCurDataTable','segmentContainer4');
			setScopeData(updateSegPenCurData,'segmentFleetpenetrationCurDataTable' );
            
			var updateSegPenHistData = SegmentDataService.updateSegHistData(responseSegData.HISTORY.fleet_penetration,responseSegData.AVERAGE_BASED_ON_YEAR.fleet_penetration,responseSegData.AVERAGE.fleet_penetration,'segment-Fleet-Penetration-His-Data','segmentFleetPenHisHeader','segmentfleetPenHisData','segmentFleetpenetrationHistDataTable','segmentContainer4Hist');
			setScopeData(updateSegPenHistData,'segmentFleetpenetrationHistDataTable' );
            
			var updateSegFleetCovCurData = SegmentDataService.updateSegCurData(responseSegData.CURRENT.fleet_coverage,'segment-Fleet-coverage-Cur-Data','segmentFleetcoverageHeader','segmentFleetcoverageData','segmentFleetcoverageCurDataTable','segmentContainer5');
			setScopeData(updateSegFleetCovCurData,'segmentFleetcoverageCurDataTable' );
            
			var updateSegFleetCovHistData = SegmentDataService.updateSegHistData(responseSegData.HISTORY.fleet_coverage,responseSegData.AVERAGE_BASED_ON_YEAR.fleet_coverage,responseSegData.AVERAGE.fleet_coverage,'segment-Fleet-coverage-His-Data','segmentfleetCovHistTblHist','segmentfleetCovHistTblData','segmentFleetcoverageHistDataTable','segmentContainer5History');
			setScopeData(updateSegFleetCovHistData,'segmentFleetcoverageHistDataTable' );
			
			var updateSegCaloricCurData = SegmentDataService.updateSegCurData(responseSegData.CURRENT.caloric_index,'segment-CaloricIndexByRegion-Cur-Data','segmentCaloricRegCurHeader','segmentCaloricRegCurData','segmentCaloricIndexRegCurDataTable','segmentContainer6');
			setScopeData(updateSegCaloricCurData,'segmentCaloricIndexRegCurDataTable' );
            
			var updateSegCaloricHistData = SegmentDataService.updateSegHistData(responseSegData.HISTORY.caloric_index,responseSegData.AVERAGE_BASED_ON_YEAR.caloric_index,responseSegData.AVERAGE.caloric_index,'segment-CaloricIndexByRegion-His-Data','segmentCaloricRegHisHeader','segmentCaloricRegHisData','segmentCaloricIndexRegHistDataTable','segmentContainer6History');
			setScopeData(updateSegCaloricHistData,'segmentCaloricIndexRegHistDataTable' );
		}
		
		$scope.excelSegDownloadOpex = function(id) {
			SegmentDataService.excelDownload(id);
	 	};
	   
	 	$scope.excelSegDownloadFleetPen = function(id) {
	 		SegmentDataService.excelDownload(id);
	 	};
	 	
	 	$scope.excelSegDownloadFleetCov = function(id) {
	 		SegmentDataService.excelDownload(id);
	 	};
	 	
	 	$scope.excelSegDownloadColoric = function(id) {
	 		SegmentDataService.excelDownload(id);
	 	};
	 	
	 	$scope.exportSegChartOpex = function(type) {
	 		SegmentChartService.exportChart(type,'Opex Penetration Current Chart','segmentContainer3'); 
	 	};
	 	$scope.exportSegChartOpexHist = function(type) {
	 		SegmentChartService.exportChartHist(type,'Opex Penetration History Chart','segmentContainer3Hist'); 
	 	};
	 	$scope.exportSegChartFeetPen = function(type) {
	 		SegmentChartService.exportChart(type,'Fleet Penetration Current Chart','segmentContainer4'); 
	 	};
	 	$scope.exportSegChartFeetPenHist = function(type) {
	 		SegmentChartService.exportChartHist(type,'Fleet Penetration History Chart','segmentContainer4Hist'); 
	 	};
	 	$scope.exportSegChartFeetCov = function(type) {
	 		SegmentChartService.exportChart(type,'Fleet Coverage Current Chart','segmentContainer5'); 
	 	};
		$scope.exportSegChartFeetCovHist = function(type) {
			SegmentChartService.exportChartHist(type,'Fleet Coverage History Chart','segmentContainer5History'); 
	 	};
	 	$scope.exportSegChartCaloric = function(type) {
	 		SegmentChartService.exportChart(type,'Caloric Index Current Chart','segmentContainer6'); 
	 	};
		$scope.exportSegChartCaloricHist = function(type) {
			SegmentChartService.exportChartHist(type,'Caloric Index History Chart','segmentContainer6History'); 
	 	};
		$scope.ShowHideSeg3 = function(){
			$scope.IsVisibleSeg3 = $scope.IsVisibleSeg3 ? false : true;
			$scope.IsHiddenSeg3=$scope.IsHiddenSeg3 ? false : true;
		};	
		$scope.ShowHideSeg4 = function(){
			$scope.IsVisibleSeg4 = $scope.IsVisibleSeg4 ? false : true;
			$scope.IsHiddenSeg4=$scope.IsHiddenSeg4 ? false : true;
		};
		$scope.ShowHideSeg5 = function(){
			$scope.IsVisibleSeg5 = $scope.IsVisibleSeg5 ? false : true;
			$scope.IsHiddenSeg5=$scope.IsHiddenSeg5 ? false : true;
		};
		$scope.ShowHideSeg6 = function(){
			$scope.IsVisibleSeg6 = $scope.IsVisibleSeg6 ? false : true;
			$scope.IsHiddenSeg6=$scope.IsHiddenSeg6 ? false : true;
		};
    }]);
});