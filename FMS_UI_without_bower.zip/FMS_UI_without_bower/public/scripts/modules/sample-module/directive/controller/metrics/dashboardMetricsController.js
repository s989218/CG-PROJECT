define(['angular','../../../sample-module','openlayer','jquery','jqueryImageZoom'], function (angular,controllers,ol,jquery) 
 {
    'use strict';
    controllers.controller('dashboardMetricsController', ['$scope','$timeout','$state','$rootScope','$http','$q','RevenueDataNetworkService','$window',
	function ($scope,$timeout,$state,$rootScope,$http,$q,RevenueDataNetworkService,$window){
    	
            if (!$rootScope.selectionPenetrationFilterData) {
                $rootScope.selectionPenetrationFilterData = {};
            }
        
            var dtSites, dtUnMappedSites, installUnitsTable;
            var modalList   = document.getElementById('partsDataModal');
            var span        = document.getElementsByClassName("partsClose")[0];
        
            var installUnitModalList = document.getElementById('installUnitDataModal');
            var installUnitSpan      = document.getElementsByClassName("installUnitClose")[0];
        
            var siteInfoContentModalList = document.getElementById('siteInfoContentDataModal');
            var siteInfoContentSpan      = document.getElementsByClassName("siteInfoContentClose")[0];

            span.onclick = function() {
                delete $scope.siteInfo;
                modalList.style.display = "none";
                $rootScope.iboByRegionData(false, true);
            }
            
            installUnitSpan.onclick = function() {
                installUnitModalList.style.display = "none";
            }
            
            siteInfoContentSpan.onclick = function() {
                siteInfoContentModalList.style.display = "none";
            }

            window.onclick = function(event) {
                if (event.target === modalList) {
                    delete $scope.siteInfo;
                    modalList.style.display = "none";
                    $rootScope.iboByRegionData(false, true);
                }
                
                if (event.target === installUnitModalList) {
                    installUnitModalList.style.display = "none";
                }
                
                if (event.target === siteInfoContentModalList) {
                    siteInfoContentModalList.style.display = "none";
                }
            }
            
            $scope.penetrationFilterData          = {};
            $scope.penetrationFilterData.report   = "fleetPenetration";
            $scope.penetrationFilterData.quarter  = "Current";
            $scope.penetrationFilterData.value    = 30;
            $scope.selectedItem                   = "IBOByRegion";
        
            $scope.ibo_percentages = [{
                value: 10,
                displayName: '< 10%'
            }, {
                value: 20,
                displayName: '< 20%'
            }, {
                value: 30,
                displayName: '< 30%'
            }, {
                value: 40,
                displayName: '< 40%'
            }, {
                value: 50,
                displayName: '< 50%'
            }, {
                value: 60,
                displayName: '< 60%'
            }, {
                value: 70,
                displayName: '< 70%'
            }, {
                value: 80,
                displayName: '< 80%'
            }, {
                value: 90,
                displayName: '< 90%'
            }, {
                value: 100,
                displayName: '< 100%'
            }];
        
            $rootScope.selectionPenetrationFilterData.report       = $scope.penetrationFilterData.report;
            $rootScope.selectionPenetrationFilterData.quarter      = $scope.penetrationFilterData.quarter;
            $rootScope.selectionPenetrationFilterData.value        = $scope.penetrationFilterData.value;
            $rootScope.selectionPenetrationFilterData.changeReport = false;
            $rootScope.selectionPenetrationFilterData.state        = "";
        
            $('#radioBtn a').on('click', function(){
                var sel = $(this).data('title');
                var tog = $(this).data('toggle');
                $('#'+tog).prop('value', sel);
                
                $scope.penetrationFilterData.quarter  = sel;
                
                if(sel === "Over All") {
                    if($("#penetration_report option[value='fleetPenF2F']").length === 0) {
                        $("#penetration_report").append($('<option></option>').attr("value", 'fleetPenF2F').text('Opex Penetration F2F'));      
                    }
                }  else {
                    $('#penetration_report option[value="fleetPenF2F"]').remove();
                    $scope.penetrationFilterData.report = "fleetPenetration";
                }
                
                $scope.changeReportDashboard();
                
                $('a[data-toggle="'+tog+'"]').not('[data-title="'+sel+'"]').removeClass('active').addClass('notActive');
                $('a[data-toggle="'+tog+'"][data-title="'+sel+'"]').removeClass('notActive').addClass('active');
            })
        
            var map, view, raster, layer, regionVector, countryVector, siteVector;
            var regionVectorSource = null, countryVectorSource = null, siteVectorSource = null;
            var regionFeatures = [], countryFeatures = [], siteFeatures = [];
        
            var canvasHeight;
            var canvasWidthOne, canvasWidthTwo, canvasWidthThree;
            var marginOne, marginTwo, marginThree, marginFour, marginFive, marginSix;
        
            if ((screen.width>=1440) && (screen.height>=900)) {
                canvasHeight     = '634px';
                canvasWidthOne   = '56%';
                canvasWidthTwo   = '68.1%'; 
                canvasWidthThree = '80.5%';
                marginOne        = '39.5em';
                marginTwo        = '39.5em';
                marginThree      = '17.5em';
                marginFour       = '47.5em';
                marginFive       = '47.5em';
                marginSix        = '25.5em';
            } else if ( ((screen.width>=1366) && (screen.height>=1024)) || ((screen.width>=1360) && (screen.height>=1024)) ) {
                canvasHeight     = '864px';
                canvasWidthOne   = '57%';
                canvasWidthTwo   = '86.5%'; 
                canvasWidthThree = '81.6%';
                marginOne        = '38.7em';
                marginTwo        = '38.7em';
                marginThree      = '16.7em';
                marginFour       = '46.5em';
                marginFive       = '46.5em';
                marginSix        = '24.5em';
            } else if ( ((screen.width>=1366) && (screen.height>=768)) || ((screen.width>=1360) && (screen.height>=768)) ) {
                canvasHeight     = '478px';
                canvasWidthOne   = '57%';
                canvasWidthTwo   = '86.5%'; 
                canvasWidthThree = '81.6%';
                marginOne        = '38.7em';
                marginTwo        = '38.7em';
                marginThree      = '16.7em';
                marginFour       = '46.5em';
                marginFive       = '46.5em';
                marginSix        = '24.5em';
            } else if ( ((screen.width === 1280) && (screen.height === 1024)) ) {
                canvasHeight     = '734px';
                canvasWidthOne   = '54.7%';
                canvasWidthTwo   = '91.6%'; 
                canvasWidthThree = '81.1%';
                marginOne        = '38em';
                marginTwo        = '38em';
                marginThree      = '16em';
                marginFour       = '46em';
                marginFive       = '46em';
                marginSix        = '24em';
            } else if ( ((screen.width === 1280) && (screen.height === 960)) ) {
                canvasHeight     = '670px';
                canvasWidthOne   = '54.7%';
                canvasWidthTwo   = '91.6%'; 
                canvasWidthThree = '81.1%';
                marginOne        = '38em';
                marginTwo        = '38em';
                marginThree      = '16em';
                marginFour       = '46em';
                marginFive       = '46em';
                marginSix        = '24em';
            } else if ( ((screen.width === 1280) && (screen.height === 800)) ) {
                canvasHeight     = '510px';
                canvasWidthOne   = '54.7%';
                canvasWidthTwo   = '91.6%'; 
                canvasWidthThree = '81.1%';
                marginOne        = '38em';
                marginTwo        = '38em';
                marginThree      = '16em';
                marginFour       = '46em';
                marginFive       = '46em';
                marginSix        = '24em';
            } else if ( ((screen.width === 1280) && (screen.height === 768)) || ((screen.width === 1280) && (screen.height === 720)) || ((screen.width === 1280) && (screen.height === 600))) {
                canvasHeight     = '478px';
                canvasWidthOne   = '54.7%';
                canvasWidthTwo   = '91.6%'; 
                canvasWidthThree = '81.1%';
                marginOne        = '38em';
                marginTwo        = '38em';
                marginThree      = '16em';
                marginFour       = '46em';
                marginFive       = '46em';
                marginSix        = '24em';
            } else if ((screen.width>=1152) && (screen.height>=864)) {
                canvasHeight     = '573px';
                canvasWidthOne   = '52.5%';
                canvasWidthTwo   = '59.3%'; 
                canvasWidthThree = '82%';
                marginOne        = '36em';
                marginTwo        = '36em';
                marginThree      = '14em';
                marginFour       = '44em';
                marginFive       = '44em';
                marginSix        = '22em';
            } else if ((screen.width>=1024) && (screen.height>=1366)) {
                canvasHeight     = '1194px';
                canvasWidthOne   = '47.3%';
                canvasWidthTwo   = '54%'; 
                canvasWidthThree = '80%';
                marginOne        = '36.1em';
                marginTwo        = '36.1em';
                marginThree      = '14em';
                marginFour       = '43.9em';
                marginFive       = '43.9em';
                marginSix        = '21.9em';
            } else if ((screen.width>=1024) && (screen.height>=768)) {
                //canvasHeight     = '479px';
                canvasHeight     = '612px';
                canvasWidthOne   = '47.3%';
                canvasWidthTwo   = '54%'; 
                canvasWidthThree = '80%';
                marginOne        = '36.1em';
                marginTwo        = '36.1em';
                marginThree      = '14em';
                marginFour       = '43.9em';
                marginFive       = '43.9em';
                marginSix        = '21.9em';
            }
        
            window.onresize = function() {
                setTimeout( function() { 
                    map.updateSize();
                }, 200);
            }
            
            function getFirstQuarterDate(year, quarter) {
                var quarterFirstDate;
                if (quarter === "1")
                    quarterFirstDate = year +" 01 01";
                else if (quarter === "2")
                    quarterFirstDate = year +" 04 01";
                else if (quarter === "3")
                    quarterFirstDate = year +" 07 01";
                else if (quarter === "4")
                    quarterFirstDate = year +" 10 01";

                return quarterFirstDate;
            }

            function getLastQuarterDate(year, quarter) {
                var quarterLastDate;
                if (quarter === "1")
                    quarterLastDate = year +" 03 31";
                else if (quarter === "2")
                    quarterLastDate = year +" 06 30";
                else if (quarter === "3")
                    quarterLastDate = year +" 09 30";
                else if (quarter === "4")
                    quarterLastDate = year +" 12 31";

                return quarterLastDate;
            }
        
            $timeout(function() {
                if (!$rootScope.marketIndustry) {
                    $rootScope.iboByRegionData(false, false);
                }
            }, 5000); 
            
            $rootScope.iboByRegionData = function (state, changeReport, level) {
                
                level = level || false;
                
                if(changeReport === true && level === false) {
                   $rootScope.selectionPenetrationFilterData              = {};
                   $rootScope.selectionPenetrationFilterData.report       = $scope.penetrationFilterData.report;
                   $rootScope.selectionPenetrationFilterData.quarter      = $scope.penetrationFilterData.quarter;
                   $rootScope.selectionPenetrationFilterData.value        = $scope.penetrationFilterData.value;
                   $rootScope.selectionPenetrationFilterData.changeReport = true; 
                }
                
                if(level === "underPeromingSites") {
                    $rootScope.selectionPenetrationFilterData              = {};
                    $rootScope.selectionPenetrationFilterData.report       = $scope.penetrationFilterData.report;
                    $rootScope.selectionPenetrationFilterData.quarter      = $scope.penetrationFilterData.quarter;
                    $rootScope.selectionPenetrationFilterData.value        = $scope.penetrationFilterData.value;
                    $rootScope.selectionPenetrationFilterData.level        = "worldSites";
                    $rootScope.selectionPenetrationFilterData.changeReport = true; 
                }
                
                if(level === "underPeromingCountry") {
                    $rootScope.selectionPenetrationFilterData              = {};
                    $rootScope.selectionPenetrationFilterData.report       = $scope.penetrationFilterData.report;
                    $rootScope.selectionPenetrationFilterData.quarter      = $scope.penetrationFilterData.quarter;
                    $rootScope.selectionPenetrationFilterData.value        = $scope.penetrationFilterData.value;
                    $rootScope.selectionPenetrationFilterData.level        = "worldCountries";
                    $rootScope.selectionPenetrationFilterData.changeReport = true; 
                }
                
                if (state !== false) {
                    $rootScope.selectionPenetrationFilterData.state       = state;
                }
                
                $rootScope.selectionPenetrationFilterData.marketIndustry  = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
                
                $scope.avglat  = 0;
                $scope.avglong = 0;
                RevenueDataNetworkService.getPenetrationDashboardData(JSON.stringify($rootScope.selectionPenetrationFilterData)).then(function(response){
                    var responseData = RevenueDataNetworkService.returnDashboardDataObjects(response);
                    
                    $scope.arrIBOByRegionData = [];
                    
                    _.forEach (responseData.IBOByReg, function(responseObj) {
                        $scope.objIBOByRegionData = {};
                        _.forEach (responseObj, function(val, key) {
                            if(key === "region") {
                                $scope.objIBOByRegionData['name'] = val;
                            }

                            if(key === "ibo_by_region") {
                                $scope.objIBOByRegionData['y']    = val;
                            }
                        });    
                        $scope.arrIBOByRegionData.push($scope.objIBOByRegionData);
                    });

                    $scope.LatLongByRegion                = responseData.StateCoordinates;
                    $scope.iboUnderPerformingRegionTotal  = responseData.UnperformingRegCount[0]['count'];
                    $scope.iboUnderPerformingCountryTotal = responseData.UnperformingCountryCount[0]['count'];
                    $scope.iboUnderPerformingSitesTotal   = responseData.UnperformingSitesCount[0]['count'];
                    $scope.iboUnmappedSitesTotal          = responseData.UnmappedSitesCount[0]['count'];
                    $scope.siteInfo                       = responseData.siteInfo;
                }).then(function(){
                    resizeAll();
                    
                    if(regionVectorSource){
                        regionVectorSource.clear(true);
                    }

                    if(countryVectorSource){
                        countryVectorSource.clear(true);
                    }

                    if(siteVectorSource){
                        siteVectorSource.clear(true);
                    }
                    
                    if(state === "unmappedSite") {
                        $timeout( function(){ $scope.updateLatLongByUnMappedSiteInfo(); });
                    } else {
                        if(level === "region") {
                            $timeout( function(){ $scope.updateLatLongByCountry(); });
                        } else if(level === "country") {
                            $timeout( function(){ $scope.updateLatLongBySite(); });
                        } else if(level === "site" || level === "worldSite") {
                            $timeout( function(){ $scope.updateLatLongBySiteInfo(); });
                        } else if(level === "underPeromingSites") {
                            $timeout( function(){ $scope.updateLatLongByWorldSite(); });
                        } else if(level === "underPeromingCountry") {
                            $timeout( function(){ $scope.updateLatLongByUnderPerformingCountry(); });
                        } else {
                            $timeout( function(){ $scope.updateLatLongByRegion(); });
                        }    
                    }
                    
                    if($scope.arrIBOByRegionData.length > 0) {
                        var objIBOByRegionTotal = _.first($scope.arrIBOByRegionData.reverse(), 1);
                        //$scope.iboByRegionTotal = objIBOByRegionTotal[0]['y'];
                        var x = Math.round(objIBOByRegionTotal[0]['y']);
                        $scope.iboByRegionTotal = ("$"+numberWithCommas(x)+"K");

                        $scope.arrIBOByRegionData = _.without($scope.arrIBOByRegionData.reverse(),    _.findWhere($scope.arrIBOByRegionData, { name: "Total" }));
                    }
                    
                    $scope.drawIBOByRegion();
                });
            }

            $scope.select = function(item) {
                $scope.selectedItem = item;
            }
            $scope.isSelected = function(item) {
                return $scope.selectedItem === item;
            }
            
            $(document).ready(function () {
                var trigger = $('.hamburger'),
                    isClosed = false;
                
                if($rootScope.isMobile === true) {
                    isClosed = true;
                    trigger.removeClass('is-closed');
                    trigger.addClass('is-open');
                    $('#wrapper').toggleClass('toggled');
                } else {
                    isClosed = false;    
                }
                
                $timeout( function(){ trigger.click(); }, 1000);

                trigger.click(function(e){
                    hamburger_cross();
                });
                
                function hamburger_cross() {
                    if (isClosed === true && $rootScope.isMobile === false) {
                        trigger.removeClass('is-open');
                        trigger.addClass('is-closed');
                        isClosed = false;
                        
                        if ( $( 'px-app-nav' ).hasClass( "navbar--collapsed" ) ) {
                            //$('#sidebar-wrapper').animate({ left: 440 });
                            $('#pm_map').css("height", canvasHeight);
                            $('#pm_map').css("width", canvasWidthOne);
                            $('.ol-button1').css( { 'right'  : marginFour } );
                            $('.ol-button2').css( { 'right'  : marginOne } );
                        } else {
                            //$('#sidebar-wrapper').animate({ left: 275 });
                            $('#pm_map').css("height", canvasHeight);
                            $('#pm_map').css("width", canvasWidthTwo);
                            $('.ol-button1').css( { 'right'  : marginFour } );
                            $('.ol-button2').css( { 'right'  : marginOne } );
                        }
                    } else if (isClosed === true && $rootScope.isMobile === true) {
                        trigger.removeClass('is-closed');
                        trigger.addClass('is-open');
                        $('.map-container').hide();
                        isClosed = false;
                    } else if (isClosed === false && $rootScope.isMobile === true) {
                        trigger.removeClass('is-open');
                        trigger.addClass('is-closed');
                        $('.map-container').show();
                        isClosed = true;
                    } else {
                        if(isClosed === true) {
                            trigger.removeClass('is-open');
                            trigger.addClass('is-closed');
                            isClosed = false;

                            if ( $( 'px-app-nav' ).hasClass( "navbar--collapsed" ) ) {
                                //$('#sidebar-wrapper').animate({ left: 440 });
                                $('#pm_map').css("height", canvasHeight);
                                $('#pm_map').css("width", canvasWidthOne);
                                $('.ol-button1').css( { 'right'  : marginFour } );
                                $('.ol-button2').css( { 'right'  : marginOne } );
                            } else {
                                //$('#sidebar-wrapper').animate({ left: 275 });
                                $('#pm_map').css("height", canvasHeight);
                                $('#pm_map').css("width", canvasWidthTwo);
                                $('.ol-button1').css( { 'right'  : marginFour } );
                                $('.ol-button2').css( { 'right'  : marginOne } );
                            } 
                        } else {
                            trigger.removeClass('is-closed');
                            trigger.addClass('is-open');

                            isClosed = true;
                            if ( $( 'px-app-nav' ).hasClass( "navbar--collapsed" ) ) {
                                $('#sidebar-wrapper').animate({ left: 275 });
                                $('#pm_map').css("height", canvasHeight);
                                $('#pm_map').css("width", canvasWidthTwo);   
                                $('.ol-button1').css( { 'right'  : marginFour } );
                                $('.ol-button2').css( { 'right'  : marginOne } );
                            } else {
                                $('#sidebar-wrapper').animate({ left: 440 });
                            }
                        }
                    }
                    
                    setTimeout( function() {
                        map.updateSize();
                        doAnimate($scope.mapVector);
                    }, 200);
                    
                    $scope.isClosed = isClosed;
                }
                
                $(":button.px-app-nav").click(function(){
                    if($scope.isClosed === true) {
                        if ( $( 'px-app-nav' ).hasClass( "navbar--collapsed" ) ) {
                            $('#sidebar-wrapper').animate({ left: 440 });
                            $('#pm_map').css("height", canvasHeight);
                            $('#pm_map').css("width", canvasWidthOne);
                            $('.ol-button1').css( { 'right'  : marginFour } );
                            $('.ol-button2').css( { 'right'  : marginOne } );
                        } else {
                            $('#sidebar-wrapper').animate({ left: 275 });
                            $('#pm_map').css("height", canvasHeight);
                            $('#pm_map').css("width", canvasWidthOne);
                            $('.ol-button1').css( { 'right'  : marginFive } );
                            $('.ol-button2').css( { 'right'  : marginTwo } );
                        }
                        
                        setTimeout( function() { 
                            map.updateSize();
                            doAnimate($scope.mapVector);
                        }, 200);
                        
                    }
                });

                $('[data-toggle="offcanvas"]').click(function () {
                    $('#wrapper').toggleClass('toggled');
                });
            });
        
            $scope.drawIBOByRegion = function (){
                
                Highcharts.setOptions({lang: {noData: "No Data Available!"}});
                
                Highcharts.chart('container', {
                    chart: {
                        center: ['50%', '50%'],
                        plotBackgroundColor: null,
                        plotBorderWidth: null,
                        plotShadow: false,
                        type: 'pie'
                    },
                    title: {
                        text: ''
                    },
                    credits: {
                        enabled: false
                    },
                    tooltip: {
                        pointFormat: '{series.name}: <b>${point.y:.0f}K</b>'
                    },
                    plotOptions: {
                        pie: {
                            //size: 140,
                            allowPointSelect: true,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: true,
                                connectorPadding: 0,
                                formatter: function () {
                                    var x=Math.round(this.y);
                                    return ("$"+numberWithCommas(x)+"K");
                                },
                                style: {
                                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                                }
                            },
                            animation: {
                                duration: 2000
                            },
                            showInLegend: true
                        }
                    },
                    series: [{
                        name: 'Value',
                        colorByPoint: true,
                        data: $scope.arrIBOByRegionData
                    }],
                    responsive: {
                      rules: [{
                        condition: {
                          maxWidth: 500
                        },
                        // Make the labels less space demanding on mobile
                        chartOptions: {
                          plotOptions: {
                            pie: {
                              size: 140,
                              dataLabels: {
                                //distance: -30
                              }
                            }
                          }
                        }
                      }]
                    }
                });
            }
            
            $scope.updateLatLongByRegion = function() {
                // Layers
                if($rootScope.selectionPenetrationFilterData.changeReport === false) {
                    raster =   new ol.layer.Tile({
                        source: new ol.source.OSM()
                    });

                    new ol.layer.Tile({ source: new ol.source.Stamen({ layer: 'watercolor' }) });
                    
                    if($rootScope.isMobile === false) {
                        if(screen.width === 1024 && screen.height === 768) {
                            view = new ol.View({
                                center: [0, 0],
                                zoom: 1.5,
                                minZoom: 1.5
                            });
                        } if(screen.width === 1024 && screen.height > 768) {
                            view = new ol.View({
                                center: [0, 0],
                                zoom: 2.3,
                                minZoom: 2.3
                            });
                        } else {
                            view = new ol.View({
                                center: [0, 0],
                                zoom: 2,
                                minZoom: 2
                            }); 
                        }
                    } else {
                        if (screen.width === 768 && screen.height === 1024) {
                            view = new ol.View({
                                center: [0, 0],
                                zoom: 2,
                                minZoom: 2
                            });
                        } else {
                            view = new ol.View({
                                center: [0, 0],
                                zoom: 1.5,
                                minZoom: 1.5
                            });
                        }
                    }

                    // The map
                    map = new ol.Map ({	
                        target: 'pm_map',
                        view: view,
                        layers: [raster]
                    }); 
                }
                
                setTimeout( function() { 
                    map.updateSize();
                }, 200);
                
                $scope.getChartStyle();

                $scope.getChartOrdering();
                
                var elementno = $scope.LatLongByRegion.length;
                var totallat  = 0.00;
                var totallong = 0.00;
                
                regionFeatures = [];
                for(var i=0;i< $scope.LatLongByRegion.length;i++)
                {
                    var item            = $scope.LatLongByRegion[i];
                    var longitude       = item.longitude;                         
                    var latitude        = item.latitude;
                    var state           = item.state;
                    var perform_status  = item.perform_status;
                    var ibo_percentage  = item.ibo_percentage;
                    
                    if ((longitude && latitude) && (Math.abs(longitude)<= 180 && Math.abs(latitude)<= 90))
                    {
                        var n, nb, data=[];
                        n = ibo_percentage * 2;
                        data.push(n);
                        nb =  n;

                        var iconFeature = new ol.Feature({
                          geometry: new ol.geom.Point(ol.proj.transform([parseFloat(longitude), parseFloat(latitude)], 'EPSG:4326',     
                          'EPSG:3857')),
                          data: data,
                          size: nb,
                          color: perform_status,
                          name: state,
                          nameM:'R'
                        });
                        
                        regionFeatures.push(iconFeature);
                        totallat  = totallat  + parseFloat(latitude);
                        totallong = totallong + parseFloat(longitude);
                    }
                }
                
                $scope.avglat  = totallat/elementno;
                $scope.avglong = totallong/elementno;
                
                if(siteVectorSource){
                    siteVectorSource.clear(true);
                }
                    
                if(countryVectorSource){
                    countryVectorSource.clear(true);
                }
                
                if(regionVectorSource){
                    regionVectorSource.clear(true);
                }
                
                regionVectorSource = new ol.source.Vector({
                    features: regionFeatures //add an array of features
                });

                regionVector = new ol.layer.Vector(
                {	name: 'Vecteur',
                    source: regionVectorSource,
                    // y ordering
                    renderOrder: ol.ordering.yOrdering(),
                    style: function(f) { return getFeatureStyle(f); }
                });
                
                if($rootScope.isMobile === false) {
                    if(screen.width === 1024 && screen.height === 768) {
                        map.getView().setZoom(1);
                    } else {
                        map.getView().setZoom(2.01);
                    }
                } else {
                    if(screen.width === 1024 && screen.height === 768) {
                        map.getView().setZoom(2.01);
                    } else {
                        map.getView().setZoom(1);
                    }
                }
                
                map.getView().setCenter(ol.proj.transform([0, 0], 'EPSG:4326', 'EPSG:3857')); 

                map.addLayer(regionVector);
                regionVector.changed();
                map.renderSync();
                $scope.mapVector = regionVector;

                doAnimate(regionVector);
                
                if($rootScope.selectionPenetrationFilterData.state === "") {
                    map.on("singleclick", onPointerClickOne);
                    map.un("singleclick", onPointerClickTwo);
                    map.un("singleclick", onPointerClickThree);
                    map.un("singleclick", onPointerClickFour);
                    map.un("singleclick", onPointerClickFive);
                }
                
                var target = $(map.getTargetElement()); //getTargetElement is experimental as of 01.10.2015
                map.on('pointermove', function (evt) {
                    if (map.hasFeatureAtPixel(evt.pixel)) { //hasFeatureAtPixel is experimental as of 01.10.2015
                        target.css('cursor', 'pointer');
                    } else {
                        target.css('cursor', '');
                    }
                });
            };
        
            function onPointerClickOne(e1) {
                $scope.displayCountryFeatureInfo(e1.pixel);
            }
        
            $scope.displayCountryFeatureInfo = function(pixel) {
                var feature = map.forEachFeatureAtPixel(pixel, function(feature) {
                    return feature;
                });
                
                if(feature){
                    var nameM = feature.get('nameM');
                    
                    if(nameM==='R')
                    {
                        
                        $rootScope.selectionPenetrationFilterData              = {};
                        $rootScope.selectionPenetrationFilterData.report       = $scope.penetrationFilterData.report;
                        $rootScope.selectionPenetrationFilterData.quarter      = $scope.penetrationFilterData.quarter;
                        $rootScope.selectionPenetrationFilterData.value        = $scope.penetrationFilterData.value;
                        $rootScope.selectionPenetrationFilterData.level        = "region";
                        $rootScope.selectionPenetrationFilterData.region       = feature.get('name');
                        $rootScope.selectionPenetrationFilterData.state        = "";
                        $rootScope.selectionPenetrationFilterData.changeReport = true; 
                        $rootScope.iboByRegionData(false, true, "region");
                    }
                }
            };
        
            $scope.updateLatLongByCountry = function() {
                
                var elementno = $scope.LatLongByRegion.length;
                var totallat  = 0.00;
                var totallong = 0.00;
                
                countryFeatures = [];
                for(var i=0;i< $scope.LatLongByRegion.length;i++)
                {
                    var item            = $scope.LatLongByRegion[i];
                    var longitude       = item.longitude;                         
                    var latitude        = item.latitude;
                    var state           = item.state;
                    var perform_status  = item.perform_status;
                    var ibo_percentage  = item.ibo_percentage;
                    
                    if ((longitude && latitude) && (Math.abs(longitude)<= 180 && Math.abs(latitude)<= 90))
                    {
                        var n, nb, data=[];
                        n = ibo_percentage * 2;
                        data.push(n);
                        nb =  n;

                        var iconFeature = new ol.Feature({
                          geometry: new ol.geom.Point(ol.proj.transform([parseFloat(longitude), parseFloat(latitude)], 'EPSG:4326',     
                          'EPSG:3857')),
                          data: data,
                          size: nb,
                          color: perform_status,
                          name: state,
                          nameM:'C'
                        });
                        
                        countryFeatures.push(iconFeature);
                        totallat  = totallat  + parseFloat(latitude);
                        totallong = totallong + parseFloat(longitude);
                    }
                }
                
                setTimeout( function() { 
                    map.updateSize();
                }, 200);
                
                $scope.avglat  = totallat/elementno;
                $scope.avglong = totallong/elementno;
                
                if(siteVectorSource){
                    siteVectorSource.clear(true);
                }

                if(countryVectorSource){
                    countryVectorSource.clear(true);
                }

                if(regionVectorSource){
                    regionVectorSource.clear(true);
                }
                
                countryVectorSource = new ol.source.Vector({
                    features: countryFeatures //add an array of features
                });

                countryVector = new ol.layer.Vector(
                {	name: 'Vecteur',
                    source: countryVectorSource,
                    // y ordering
                    renderOrder: ol.ordering.yOrdering(),
                    style: function(f) { return getFeatureStyle(f); }
                });

                map.getView().setZoom(3.21);
                map.getView().setCenter(ol.proj.transform([$scope.avglong, $scope.avglat], 'EPSG:4326', 'EPSG:3857'));
                
                map.addLayer(countryVector);
                
                countryVector.changed();
                map.renderSync();
                $scope.mapVector = countryVector;

                doAnimate(countryVector);
                
                if($rootScope.selectionPenetrationFilterData.state === "") {
                    map.on('moveend', onPointerMoveTwo);
                    map.on("singleclick", onPointerClickTwo);
                    map.un("singleclick", onPointerClickThree);
                    map.un("singleclick", onPointerClickFour);
                    map.un("singleclick", onPointerClickFive);
                }
                
            };
        
            function onPointerClickTwo(e2) {
                $scope.displaySitesFeatureInfo(e2.pixel);
            }
        
            function onPointerMoveTwo(e2) {
                checkMapZoom();
            }
        
            $scope.displaySitesFeatureInfo = function(pixel) {
                var feature = map.forEachFeatureAtPixel(pixel, function(feature) {
                    return feature;
                });
                
                if(feature){
                    var nameM = feature.get('nameM');
                    if(nameM==='C')
                    {
                        
                        $rootScope.selectionPenetrationFilterData              = {};
                        $rootScope.selectionPenetrationFilterData.report       = $scope.penetrationFilterData.report;
                        $rootScope.selectionPenetrationFilterData.quarter      = $scope.penetrationFilterData.quarter;
                        $rootScope.selectionPenetrationFilterData.value        = $scope.penetrationFilterData.value;
                        $rootScope.selectionPenetrationFilterData.level        = "country";
                        $rootScope.selectionPenetrationFilterData.country      = feature.get('name');
                        $rootScope.selectionPenetrationFilterData.state        = "";
                        $rootScope.selectionPenetrationFilterData.changeReport = true; 
                        $rootScope.iboByRegionData(false, true, "country");
                    }
                }
            };
        
            $scope.updateLatLongBySite = function() {
                
                var elementno = $scope.LatLongByRegion.length;
                var totallat  = 0.00;
                var totallong = 0.00;
                
                siteFeatures = [];
                for(var i=0;i< $scope.LatLongByRegion.length;i++)
                {
                    var item            = $scope.LatLongByRegion[i];
                    var longitude       = item.longitude;                         
                    var latitude        = item.latitude;
                    var state           = item.state;
                    var perform_status  = item.perform_status;
                    var ibo_percentage  = item.ibo_percentage;
                    
                    if ((longitude && latitude) && (Math.abs(longitude)<= 180 && Math.abs(latitude)<= 90))
                    {
                        var n, nb, data=[];
                        n = ibo_percentage * 7.5;
                        data.push(n);
                        nb =  n;

                        var iconFeature = new ol.Feature({
                          geometry: new ol.geom.Point(ol.proj.transform([parseFloat(longitude), parseFloat(latitude)], 'EPSG:4326',     
                          'EPSG:3857')),
                          data: data,
                          size: nb,
                          color: perform_status,
                          name: state,
                          nameM:'SI'
                        });
                        
                        siteFeatures.push(iconFeature);
                        totallat  = totallat  + parseFloat(latitude);
                        totallong = totallong + parseFloat(longitude);
                    }
                }
                
                setTimeout( function() { 
                    map.updateSize();
                }, 200);
                
                $scope.avglat  = totallat/elementno;
                $scope.avglong = totallong/elementno;
                
                if(siteVectorSource){
                    siteVectorSource.clear(true);
                }

                if(countryVectorSource){
                    countryVectorSource.clear(true);
                }

                if(regionVectorSource){
                    regionVectorSource.clear(true);
                }

                siteVectorSource = new ol.source.Vector({
                    features: siteFeatures //add an array of features
                });
                
                siteVector = new ol.layer.Vector(
                {	name: 'Vecteur',
                    source: siteVectorSource,
                    // y ordering
                    renderOrder: ol.ordering.yOrdering(),
                    style: function(f) { return getFeatureStyle(f); }
                });
                
                map.getView().setZoom(4);
                map.getView().setCenter(ol.proj.transform([$scope.avglong, $scope.avglat], 'EPSG:4326', 'EPSG:3857'));

                map.addLayer(siteVector);
                
                siteVector.changed();
                map.renderSync();
                $scope.mapVector = siteVector;
                doAnimate(siteVector);
                
                if($rootScope.selectionPenetrationFilterData.state === "") {
                    map.on('moveend', onPointerMoveThree);
                    map.on("singleclick", onPointerClickThree);
                    map.un("singleclick", onPointerClickTwo);
                    map.un("singleclick", onPointerClickFour);
                    map.un("singleclick", onPointerClickFive);
                }
            };
        
            function onPointerClickThree(e3) {
                $scope.displaySiteInfo(e3.pixel);
            }
        
        
            function onPointerMoveThree(e3) {
                checkMapZoom();
            }
        
            $scope.displaySiteInfo = function(pixel) {
                var feature = map.forEachFeatureAtPixel(pixel, function(feature) {
                    return feature;
                });
                
                if(feature){
                    var nameM = feature.get('nameM');
                    var country  = $rootScope.selectionPenetrationFilterData.country;
                    if(nameM==='SI')
                    {
                        $rootScope.selectionPenetrationFilterData              = {};
                        $rootScope.selectionPenetrationFilterData.report       = $scope.penetrationFilterData.report;
                        $rootScope.selectionPenetrationFilterData.quarter      = $scope.penetrationFilterData.quarter;
                        $rootScope.selectionPenetrationFilterData.value        = $scope.penetrationFilterData.value;
                        $rootScope.selectionPenetrationFilterData.level        = "site";
                        $rootScope.selectionPenetrationFilterData.country      = country;
                        $rootScope.selectionPenetrationFilterData.state        = "";
                        $rootScope.selectionPenetrationFilterData.changeReport = true;
                        
                        $scope.partsDataHeaderName                             = country +' - SITES';
                        
                        $rootScope.iboByRegionData(false, true, "site");
                    }
                }
            };
        
            $scope.updateLatLongByWorldSite = function() {
                
                var elementno = $scope.LatLongByRegion.length;
                var totallat  = 0.00;
                var totallong = 0.00;
                
                regionFeatures = [];
                for(var i=0;i< $scope.LatLongByRegion.length;i++)
                {
                    var item            = $scope.LatLongByRegion[i];
                    var longitude       = item.longitude;                         
                    var latitude        = item.latitude;
                    var state           = item.state;
                    var perform_status  = item.perform_status;
                    var ibo_percentage  = item.ibo_percentage;
                    
                    if ((longitude && latitude) && (Math.abs(longitude)<= 180 && Math.abs(latitude)<= 90))
                    {
                        var n, nb, data=[];
                        n = ibo_percentage * 2;
                        data.push(n);
                        nb =  n;

                        var iconFeature = new ol.Feature({
                          geometry: new ol.geom.Point(ol.proj.transform([parseFloat(longitude), parseFloat(latitude)], 'EPSG:4326',     
                          'EPSG:3857')),
                          data: data,
                          size: nb,
                          color: perform_status,
                          name: state,
                          nameM:'WS'
                        });
                        
                        regionFeatures.push(iconFeature);
                        totallat  = totallat  + parseFloat(latitude);
                        totallong = totallong + parseFloat(longitude);
                    }
                }
                
                setTimeout( function() { 
                    map.updateSize();
                }, 200);
                
                $scope.avglat  = totallat/elementno;
                $scope.avglong = totallong/elementno;
                
                if(siteVectorSource){
                    siteVectorSource.clear(true);
                }

                if(countryVectorSource){
                    countryVectorSource.clear(true);
                }

                if(regionVectorSource){
                    regionVectorSource.clear(true);
                }
                
                regionVectorSource = new ol.source.Vector({
                    features: regionFeatures //add an array of features
                });

                regionVector = new ol.layer.Vector(
                {	name: 'Vecteur',
                    source: regionVectorSource,
                    // y ordering
                    renderOrder: ol.ordering.yOrdering(),
                    style: function(f) { return getFeatureStyle(f); }
                });
                
                map.getView().setZoom(2.01);
                map.getView().setCenter(ol.proj.transform([0, 0], 'EPSG:4326', 'EPSG:3857')); 

                map.addLayer(regionVector);
                regionVector.changed();
                map.renderSync();
                $scope.mapVector = regionVector;

                doAnimate(regionVector);
                
                if($rootScope.selectionPenetrationFilterData.level === "worldSites") { 
                    map.on("singleclick", onPointerClickFour);
                    map.un("singleclick", onPointerClickTwo);
                    map.un("singleclick", onPointerClickThree);
                    map.un("singleclick", onPointerClickFive);
                }
                
            };
        
            function onPointerClickFour(e4) {
                $scope.displayWorldSitesFeatureInfo(e4.pixel);
            }
        
            $scope.displayWorldSitesFeatureInfo = function(pixel) {
                var feature = map.forEachFeatureAtPixel(pixel, function(feature) {
                    return feature;
                });
                
                if(feature){
                    var nameM = feature.get('nameM');
                    if(nameM==='WS')
                    {
                        
                        $rootScope.selectionPenetrationFilterData              = {};
                        $rootScope.selectionPenetrationFilterData.report       = $scope.penetrationFilterData.report;
                        $rootScope.selectionPenetrationFilterData.quarter      = $scope.penetrationFilterData.quarter;
                        $rootScope.selectionPenetrationFilterData.value        = $scope.penetrationFilterData.value;
                        $rootScope.selectionPenetrationFilterData.level        = "worldSite";
                        $rootScope.selectionPenetrationFilterData.state        = "";
                        $rootScope.selectionPenetrationFilterData.changeReport = true;
                        
                        $scope.partsDataHeaderName                             = 'UNDER PERFORMING SITES';
                        
                        $rootScope.iboByRegionData(false, true, "worldSite");
                    }
                }
            };
        
            $scope.updateLatLongByUnderPerformingCountry = function() {
                
                var elementno = $scope.LatLongByRegion.length;
                var totallat  = 0.00;
                var totallong = 0.00;
                
                countryFeatures = [];
                for(var i=0;i< $scope.LatLongByRegion.length;i++)
                {
                    var item            = $scope.LatLongByRegion[i];
                    var longitude       = item.longitude;                         
                    var latitude        = item.latitude;
                    var state           = item.state;
                    var perform_status  = item.perform_status;
                    var ibo_percentage  = item.ibo_percentage;
                    
                    if ((longitude && latitude) && (Math.abs(longitude)<= 180 && Math.abs(latitude)<= 90))
                    {
                        var n, nb, data=[];
                        n = ibo_percentage * 2;
                        data.push(n);
                        nb =  n;

                        var iconFeature = new ol.Feature({
                          geometry: new ol.geom.Point(ol.proj.transform([parseFloat(longitude), parseFloat(latitude)], 'EPSG:4326',     
                          'EPSG:3857')),
                          data: data,
                          size: nb,
                          color: perform_status,
                          name: state,
                          nameM:'UPC'
                        });
                        
                        countryFeatures.push(iconFeature);
                        totallat  = totallat  + parseFloat(latitude);
                        totallong = totallong + parseFloat(longitude);
                    }
                }
                
                setTimeout( function() { 
                    map.updateSize();
                }, 200);
                
                $scope.avglat  = totallat/elementno;
                $scope.avglong = totallong/elementno;
                
                if(siteVectorSource){
                    siteVectorSource.clear(true);
                }

                if(countryVectorSource){
                    countryVectorSource.clear();
                }

                if(regionVectorSource){
                    regionVectorSource.clear(true);
                }
                
                countryVectorSource = new ol.source.Vector({
                    features: countryFeatures //add an array of features
                });

                countryVector = new ol.layer.Vector(
                {	name: 'Vecteur',
                    source: countryVectorSource,
                    // y ordering
                    renderOrder: ol.ordering.yOrdering(),
                    style: function(f) { return getFeatureStyle(f); }
                });

                map.getView().setZoom(2.01);
                map.getView().setCenter(ol.proj.transform([0, 0], 'EPSG:4326', 'EPSG:3857'));
                
                map.addLayer(countryVector);
                
                countryVector.changed();
                map.renderSync();
                $scope.mapVector = countryVector;

                doAnimate(countryVector);

                if($rootScope.selectionPenetrationFilterData.level === "worldCountries") { 
                    map.un("moveend", onPointerMoveTwo);
                    map.un("moveend", onPointerMoveThree);
                    
                    map.on("singleclick", onPointerClickFive);
                    map.un("singleclick", onPointerClickTwo);
                    map.un("singleclick", onPointerClickThree);
                    map.un("singleclick", onPointerClickFour);
                }
            };
        
            function onPointerClickFive(e5) {
                $scope.displayUnderPerformingSitesFeatureInfo(e5.pixel);
            }
        
            $scope.displayUnderPerformingSitesFeatureInfo = function(pixel) {
                var feature = map.forEachFeatureAtPixel(pixel, function(feature) {
                    return feature;
                });
                
                if(feature){
                    var nameM = feature.get('nameM');
                    if(nameM==='UPC')
                    {
                        
                        $rootScope.selectionPenetrationFilterData              = {};
                        $rootScope.selectionPenetrationFilterData.report       = $scope.penetrationFilterData.report;
                        $rootScope.selectionPenetrationFilterData.quarter      = $scope.penetrationFilterData.quarter;
                        $rootScope.selectionPenetrationFilterData.value        = $scope.penetrationFilterData.value;
                        $rootScope.selectionPenetrationFilterData.level        = "country";
                        $rootScope.selectionPenetrationFilterData.country      = feature.get('name');
                        $rootScope.selectionPenetrationFilterData.state        = "";
                        $rootScope.selectionPenetrationFilterData.changeReport = true; 
                        $rootScope.iboByRegionData(false, true, "country");
                    }
                }
            };
        
            $scope.updateLatLongBySiteInfo = function() {
                modalList.style.display = "block";
                
                if ($.fn.DataTable.isDataTable( '#siteInfoTable' ) ) {
                    $("#siteInfoTable").dataTable().api().clear().draw();
                    $("#siteInfoTable").dataTable().api().destroy();
                    $('#siteInfoTable').empty(); 
                }

                $scope.arrSiteInfoDataTableHeaders = [
                    {
                        title:"Site",
                        width: "15%",
                        mRender: function (data, type, row) {
                            return '<a class="table-install-units" data-id="' + row.site + '" style="cursor: pointer;text-decoration: underline;">' + row.site + '</a>';
                        }
                    },
                    { data:"region",title:"Region", "width": "15%" },
                    { data:"country", title:"Country", "width": "15%" }
                ];
                
                if ($rootScope.selectionPenetrationFilterData.report === "fleetPenetration") {
                    $scope.arrSiteInfoDataTableHeaders.push(
                        { data:"fleet_penetration",title:"Fleet Penetration", "width": "10%" }
                    );
                } else if ($rootScope.selectionPenetrationFilterData.report === "fleetCoverage") {
                    $scope.arrSiteInfoDataTableHeaders.push(
                        { data:"fleet_coverage",title:"Fleet Coverage", "width": "10%" }
                    );
                }  else if ($rootScope.selectionPenetrationFilterData.report === "fleetPenF2F") {
                    $scope.arrSiteInfoDataTableHeaders.push(
                        { data:"fleet_pen_f2f",title:"Opex Penetration F2F", "width": "10%" }
                    );
                }
                
                $scope.arrSiteInfoDataTableHeaders.push(
                    { data:"ibo_value",title:"IBO Value", "width": "10%" }
                );
                
                if ($rootScope.selectionPenetrationFilterData.quarter === "Over All") {
                    $scope.arrSiteInfoDataTableHeaders.push(
                        { data:"year_quarter_min", title:"Year Quarter Min" },
                        { data:"year_quarter_max", title:"Year Quarter Max" }
                    );
                    
                    $scope.arrSiteInfoColumnDefs = [
                        {
                            "render": function ( data, type, row ) {
                                if(!isNaN(data) && angular.isNumber(+data)) {
                                    return data +'%';
                                } else {
                                    return data;
                                }
                            },
                            "aTargets": [ 3 ]
                        },
                        {
                            "targets": [ 5 ],
                            "visible": false,
                            "searchable": false
                        },
                        {
                            "targets": [ 6 ],
                            "visible": false,
                            "searchable": false
                        }
                    ];
                } else {
                    $scope.arrSiteInfoColumnDefs = [
                        {
                            "render": function ( data, type, row ) {
                                if(!isNaN(data) && angular.isNumber(+data)) {
                                    return data +'%';
                                } else {
                                    return data;
                                }
                            },
                            "aTargets": [ 3 ]
                        }
                    ];
                }
                
                $scope.arrSiteInfoDataTableHeaders.push(
                    {
                        title:"Link To Install Base",
                        width: "15%",
                        mRender: function (data, type, row) {
                            return '<a class="table-ib" data-id="' + row.site + '" style="cursor: pointer;text-decoration: underline;">Link To Install Base <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i></a>';
                        }
                     }
                );
                
                $scope.arrSiteInfoDataTableHeaders.push(
                    {
                        title:"Link To Combined Analysis",
                        width: "20%",
                        mRender: function (data, type, row) {
                            return '<a class="table-site" data-id="' + row.site + '" style="cursor: pointer;text-decoration: underline;">Link To Combined Analysis <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i></a>';
                        }
                     }
                );
                    
                dtSites = $("#siteInfoTable").DataTable({ 
                    "order": [],
                    data:$scope.siteInfo,
                    "bLengthChange": false,
                    "autoWidth": false,
                    "bSortClasses": false,
                    "bFilter":true, 
                    "retrieve": true, 
                    "scrollX": false,
                    "paging": true,
                    rowReorder: {
                        selector: 'td:nth-child(2)'
                    },
                    responsive: true,
                    "columns": $scope.arrSiteInfoDataTableHeaders,
                    "columnDefs": $scope.arrSiteInfoColumnDefs
                });
                
                $('body #siteInfoTable tbody').on( 'click', 'a.table-site', function () { 
                    var data = dtSites.row($(this).parents('tr')).data();

                    $rootScope.safeApply(function(){
                        if($rootScope.selectionPenetrationFilterData.quarter === "Over All") {
                            var min_range = data.year_quarter_min;
                            var max_range = data.year_quarter_max;

                            var arrMinRange  = min_range.slice(0,-1).split("-");
                            var arrMaxRange  = max_range.slice(0,-1).split("-");
                            
                            var getFirstDate = getFirstQuarterDate(arrMinRange[0], arrMinRange[1]);
                            var getLastDate  = getLastQuarterDate(arrMaxRange[0], arrMaxRange[1]);

                            var beginDate    = moment(getFirstDate);
                            var endDate      = moment(getLastDate);

                            var amount       = Math.floor(endDate.diff(beginDate, 'months') / 3) + 1;
                            var minYear      = parseInt(arrMaxRange[0]);
                            //var quarterStart = Math.ceil((parseInt(arrMaxRange[1]) + 1) / 3);
                            var quarterStart = parseInt(arrMaxRange[1]);
                            
                            var arrMinMaxRange = [];
                            for (var i = 0; i < amount; i++) {
                                arrMinMaxRange.push(minYear + '-' + quarterStart)

                                quarterStart--;
                                if (quarterStart <= 0) {
                                    minYear--;
                                    quarterStart = 4;
                                };
                            };
                        }
                        
                        if (typeof(Storage) !== "undefined") {
                            // Code for localStorage/sessionStorage.
                            localStorage.setItem("siteFilterCode", data.site);
                            localStorage.setItem("regionFilterCode", data.region);
                            localStorage.setItem("countryFilterCode", data.country);
                            if($rootScope.selectionPenetrationFilterData.quarter === "Current") {
                                localStorage.setItem("yearQuarterFilterCode", "CURRENT");    
                            } else {
                                localStorage.setItem("yearQuarterFilterCode", JSON.stringify(arrMinMaxRange));
                            }
                            localStorage.setItem("tier3FilterCode", "Opex");
                            
                         } else {
                            // Sorry! No Web Storage support..
                         }
                    });

                    var url = $state.href('CombinedAnalysis', {}, {absolute:true});
                    $window.open(url,'_blank');
                });
                
                $('body #siteInfoTable tbody').on( 'click', 'a.table-ib', function () { 
                    var data = dtSites.row($(this).parents('tr')).data();

                    $rootScope.safeApply(function(){
                        if (typeof(Storage) !== "undefined") {
                            // Code for localStorage/sessionStorage.
                            localStorage.setItem("siteFilterCode", data.site);
                            localStorage.setItem("regionFilterCode", data.region);
                            localStorage.setItem("countryFilterCode", data.country);
                            localStorage.setItem("tier3FilterCode", "Opex");
                         } else {
                            // Sorry! No Web Storage support..
                         }
                    });

                    var url = $state.href('InstalledBase', {}, {absolute:true});
                    $window.open(url,'_blank');
                });
                
                $('body #siteInfoTable tbody').on( 'click', 'a.table-install-units', function () { 
                    var data = dtSites.row($(this).parents('tr')).data();
                    $scope.siteName   = data.site;
                    $scope.regionName = data.region;
                    
                    $http.post("connect/fms/getLatLongBySite", JSON.stringify({
                        "region": $scope.regionName,
                        "siteName": $scope.siteName,
                        "businessSegment": $rootScope.businessSegment,
                        "accountManager": "",
                        "marketIndustry":$rootScope.marketIndustry ? $rootScope.marketIndustry : ""
                    })).success(function(response) {
                        $scope.LatLongBySite = response;
                        $scope.getSiteInfoAndInstalledUnitsData($scope.siteName);
                    }).then(function() {
                        resizeAll();
                    });
                });
            }
            
            $scope.updateLatLongByUnMappedSiteInfo = function() {
                modalList.style.display    = "block";
                
                if ($.fn.DataTable.isDataTable( '#siteInfoTable' ) ) {
                    $("#siteInfoTable").dataTable().api().clear().draw();
                    $("#siteInfoTable").dataTable().api().destroy();
                    $('#siteInfoTable').empty(); 
                }
                
                $scope.partsDataHeaderName = "UN-MAPPED SITES";
                $scope.arrSiteInfoDataTableHeaders = [
                    {
                        title:"Site",
                        width: "20%",
                        mRender: function (data, type, row) {
                            return '<a class="table-install-units" data-id="' + row.site + '" style="cursor: pointer;text-decoration: underline;">' + row.site + '</a>';
                        }
                    },
                    { data:"region",title:"Region", "width": "18%" },
                    { data:"country", title:"Country", "width": "18%" },
                ];
                
                $scope.arrSiteInfoDataTableHeaders.push(
                		{ 
                			title:"IBO Value",
                			"width": "10%",
                			mRender: function (data, type, row) {
                				return '$'+row.ibo_value;
                			}
                		}
                );
                
                if ($rootScope.selectionPenetrationFilterData.quarter === "Over All") {
                    $scope.arrSiteInfoDataTableHeaders.push(
                        { data:"year_quarter_min", title:"Year Quarter Min" },
                        { data:"year_quarter_max", title:"Year Quarter Max" }
                    );
                    
                    $scope.arrSiteInfoColumnDefs = [
                        {
                            "targets": [ 4 ],
                            "visible": false,
                            "searchable": false
                        },
                        {
                            "targets": [ 5 ],
                            "visible": false,
                            "searchable": false
                        }
                    ];
                } else {
                    $scope.arrSiteInfoColumnDefs = [];
                }
                
                $scope.arrSiteInfoDataTableHeaders.push(
                    {
                        title:"Link To Install Base",
                        width: "15%",
                        mRender: function (data, type, row) {
                            return '<a class="table-ib" data-id="' + row.site + '" style="cursor: pointer;text-decoration: underline;">Link To Install Base <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i></a>';
                        }
                     }
                );
                
                $scope.arrSiteInfoDataTableHeaders.push(
                    {
                        title:"Link To Combined Analysis",
                        width: "20%",
                        mRender: function (data, type, row) {
                            return '<a class="table-site" data-id="' + row.site + '" style="cursor: pointer;text-decoration: underline;">Link To Combined Analysis <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i></a>';
                        }
                     }
                );
                    
                dtUnMappedSites = $("#siteInfoTable").DataTable({ 
                    "order": [],
                    "columnDefs": $scope.arrSiteInfoColumnDefs,
                    data:$scope.siteInfo,
                    "bLengthChange": false,
                    "autoWidth": false,
                    "bSortClasses": false,
                    "bFilter":true, 
                    "retrieve": true, 
                    "scrollX": false,
                    "paging": true,
                    rowReorder: {
                        selector: 'td:nth-child(2)'
                    },
                    responsive: true,
                     "columns": $scope.arrSiteInfoDataTableHeaders
                });
                
                $('body #siteInfoTable tbody').on( 'click', 'a.table-site', function () { 
                    var data = dtUnMappedSites.row($(this).parents('tr')).data();

                    $rootScope.safeApply(function(){
                        if($rootScope.selectionPenetrationFilterData.quarter === "Over All") {
                            var min_range = data.year_quarter_min;
                            var max_range = data.year_quarter_max;
                            
                            var arrMinRange  = min_range.slice(0,-1).split("-");
                            var arrMaxRange  = max_range.slice(0,-1).split("-");
                            
                            var getFirstDate = getFirstQuarterDate(arrMinRange[0], arrMinRange[1]);
                            var getLastDate  = getLastQuarterDate(arrMaxRange[0], arrMaxRange[1]);

                            var beginDate    = moment(getFirstDate);
                            var endDate      = moment(getLastDate);
                            
                            var amount       = Math.floor(endDate.diff(beginDate, 'months') / 3) + 1;
                            var minYear      = parseInt(arrMaxRange[0]);
                            //var quarterStart = Math.ceil((parseInt(arrMaxRange[1]) + 1) / 3);
                            var quarterStart = parseInt(arrMaxRange[1]);
                            
                            var arrMinMaxRange = [];
                            for (var i = 0; i < amount; i++) {
                                arrMinMaxRange.push(minYear + '-' + quarterStart)

                                quarterStart--;
                                if (quarterStart <= 0) {
                                    minYear--;
                                    quarterStart = 4;
                                };
                            };
                        }
                        
                        if (typeof(Storage) !== "undefined") {
                            // Code for localStorage/sessionStorage.
                            localStorage.setItem("siteFilterCode", data.site);
                            localStorage.setItem("regionFilterCode", data.region);
                            localStorage.setItem("countryFilterCode", data.country);
                            if($rootScope.selectionPenetrationFilterData.quarter === "Current") {
                                localStorage.setItem("yearQuarterFilterCode", "CURRENT");    
                            } else {
                                localStorage.setItem("yearQuarterFilterCode", JSON.stringify(arrMinMaxRange));
                            }
                            localStorage.setItem("tier3FilterCode", "Opex");
                         } else {
                            // Sorry! No Web Storage support..
                         }
                    });

                    var url = $state.href('CombinedAnalysis', {}, {absolute:true});
                    $window.open(url,'_blank');
                });
                
                $('body #siteInfoTable tbody').on( 'click', 'a.table-ib', function () { 
                    var data = dtUnMappedSites.row($(this).parents('tr')).data();

                    $rootScope.safeApply(function(){
                        if (typeof(Storage) !== "undefined") {
                            // Code for localStorage/sessionStorage.
                            localStorage.setItem("siteFilterCode", data.site);
                            localStorage.setItem("regionFilterCode", data.region);
                            localStorage.setItem("countryFilterCode", data.country);
                            localStorage.setItem("tier3FilterCode", "Opex");
                         } else {
                            // Sorry! No Web Storage support..
                         }
                    });

                    var url = $state.href('InstalledBase', {}, {absolute:true});
                    $window.open(url,'_blank');
                });
                
                $('body #siteInfoTable tbody').on( 'click', 'a.table-install-units', function () { 
                    var data = dtUnMappedSites.row($(this).parents('tr')).data();
                    
                    $scope.siteName   = data.site;
                    $scope.regionName = data.region;
                    
                    $http.post("connect/fms/getLatLongBySite", JSON.stringify({
                        "region": $scope.regionName,
                        "siteName": $scope.siteName,
                        "businessSegment": $rootScope.businessSegment,
                        "accountManager": "",
                        "marketIndustry":$rootScope.marketIndustry ? $rootScope.marketIndustry : ""
                    })).success(function(response) {
                        $scope.LatLongBySite = response;
                        $scope.getSiteInfoAndInstalledUnitsData($scope.siteName);
                    }).then(function() {
                        resizeAll();
                    });
                });
            }
            
            $scope.updateMap = function (){
               
                if($scope.isClosed === true && !$( 'px-app-nav' ).hasClass( "navbar--collapsed" )) {
                    $('#pm_map').css("height", canvasHeight);
                    $('#pm_map').css("width", canvasWidthOne);
                    $('.ol-button1').css( { 'right'  : marginFour } );
                    $('.ol-button2').css( { 'right'  : marginOne } );
                } else if ($scope.isClosed === true) {
                    $('#pm_map').css("height", canvasHeight);
                    $('#pm_map').css("width", canvasWidthOne);
                    $('.ol-button1').css( { 'right'  : marginFive } );
                    $('.ol-button2').css( { 'right'  : marginTwo } );
                } else {
                    $('#pm_map').css("height", canvasHeight);
                    $('#pm_map').css("width", canvasWidthThree);
                    $('.ol-button1').css( { 'right'  : marginSix } );
                    $('.ol-button2').css( { 'right'  : marginThree } );
                }
                
                setTimeout( function() { 
                    map.updateSize();
                    doAnimate($scope.mapVector);
                }, 200);
                
            }
            
            $scope.changeReportDashboard = function() {
                $rootScope.selectionPenetrationFilterData         = {};
                $rootScope.selectionPenetrationFilterData.report   = $scope.penetrationFilterData.report;
                $rootScope.selectionPenetrationFilterData.quarter  = $scope.penetrationFilterData.quarter;
                $rootScope.selectionPenetrationFilterData.value    = $scope.penetrationFilterData.value;
                $rootScope.iboByRegionData(false, true);
            }
            
            $scope.getChartStyle = function() {
            
                ol.style.Chart = function(opt_options) 
                {	var options = opt_options || {};
                    var strokeWidth = 0;
                    if (opt_options.stroke) strokeWidth = opt_options.stroke.getWidth();
                    ol.style.RegularShape.call (this,
                        {	radius: options.radius + strokeWidth, 
                            fill: new ol.style.Fill({color: [0,0,0]}),
                            rotation: options.rotation,
                            snapToPixel: options.snapToPixel
                        });
                    if (options.scale) this.setScale(options.scale);

                    this.stroke_ = options.stroke;
                    this.radius_ = options.radius || 20;
                    this.donutratio_ = options.donutRatio || 0.5;
                    this.type_ = options.type;
                    this.offset_ = [options.offsetX ? options.offsetX : 0, options.offsetY ? options.offsetY : 0];
                    this.animation_ = (typeof(options.animation) === 'number') ? { animate:true, step:options.animation } : this.animation_ = { animate:false, step:1 };

                    this.data_ = options.data;
                    if (options.colors instanceof Array)
                    {	this.colors_ = options.colors;
                    }
                    else 
                    {	this.colors_ = ol.style.Chart.colors[options.colors];
                        if(!this.colors_) this.colors_ = ol.style.Chart.colors.classic;
                    }

                    this.renderChart_();
                };
                ol.inherits(ol.style.Chart, ol.style.RegularShape);

                /** Default color thems
                */
                ol.style.Chart.colors = 
                {	"classic":	["#ffa500","blue","red","green","cyan","magenta","yellow","#0f0"],
                    "dark":		["#960","#003","#900","#060","#099","#909","#990","#090"],
                    //"pale":	["#fd0","#369","#f64","#3b7","#880","#b5d","#666"],
                    "pale-green":		 ["#3b7"],
                    "pale-red": ["#E63B4B"],
                    "pale-yellow": ["#fd0"],
                    "pastel":	["#fb4","#79c","#f66","#7d7","#acc","#fdd","#ff9","#b9b"], 
                    "neon":		["#ff0","#0ff","#0f0","#f0f","#f00","#00f"]
                }

                /** Get data associatied with the chart
                */
                ol.style.Chart.prototype.getData = function() 
                {	return this.data_;
                }
                /** Set data associatied with the chart
                *	@param {Array<number>}
                */
                ol.style.Chart.prototype.setData = function(data) 
                {	this.data_ = data;
                    this.renderChart_();
                }

                /** Get symbol radius
                */
                ol.style.Chart.prototype.getRadius = function() 
                {	return this.radius_;
                }
                /** Set symbol radius
                *	@param {number} symbol radius
                *	@param {number} donut ratio
                */
                ol.style.Chart.prototype.setRadius = function(radius, ratio) 
                {	this.radius_ = radius;
                    this.donuratio_ = ratio || this.donuratio_;
                    this.renderChart_();
                }

                /** Set animation step 
                *	@param {false|number} false to stop animation or the step of the animation [0,1]
                */
                ol.style.Chart.prototype.setAnimation = function(step) 
                {	if (step===false) 
                    {	if (this.animation_.animate === false) return;
                        this.animation_.animate = false;
                    }
                    else
                    {	if (this.animation_.step === step) return;
                        this.animation_.animate = true;
                        this.animation_.step = step;
                    }
                    this.renderChart_();
                }


                /** @private
                */
                ol.style.Chart.prototype.renderChart_ = function(atlasManager) 
                {	var strokeStyle;
                    var strokeWidth = 0;

                    if (this.stroke_) 
                    {	strokeStyle = ol.color.asString(this.stroke_.getColor());
                        strokeWidth = this.stroke_.getWidth();
                    }

                    // no atlas manager is used, create a new canvas
                    var canvas = this.getImage();

                    // draw the circle on the canvas
                    var context = (canvas.getContext('2d'));
                    context.clearRect(0, 0, canvas.width, canvas.height);
                    context.lineJoin = 'round';

                    var sum=0;
                    for (var i=0; i<this.data_.length; i++)
                        sum += this.data_[i];

                    // reset transform
                    context.setTransform(1, 0, 0, 1, 0, 0);

                    // then move to (x, y)
                    context.translate(0,0);

                    var step = this.animation_.animate ? this.animation_.step : 1;

                    // Draw pie
                    switch (this.type_)
                    {	case "donut":
                        case "pie3D":
                        case "pie":
                        {	var a, a0 = Math.PI * (step-1.5);
                            var c = canvas.width/2;
                            context.strokeStyle = strokeStyle;
                            context.lineWidth = strokeWidth;
                            context.save();
                            if (this.type_ === "pie3D") 
                            {	context.translate(0, c*0.3);
                                context.scale(1, 0.7);
                                context.beginPath();
                                context.fillStyle = "#369";
                                context.arc ( c, c*1.4, this.radius_ *step, 0, 2*Math.PI);
                                context.fill();
                                context.stroke();
                            }
                            if (this.type_ === "donut")
                            {	context.save();
                                context.beginPath();
                                context.rect ( 0,0,2*c,2*c );
                                context.arc ( c, c, this.radius_ *step *this.donutratio_, 0, 2*Math.PI);
                                context.clip("evenodd");
                            }
                            for (var j=0; j<this.data_.length; j++)
                            {	context.beginPath();
                                context.moveTo(c,c);
                                context.fillStyle = this.colors_[j%this.colors_.length];
                                a = a0 + 2*Math.PI*this.data_[j]/sum *step;
                                context.arc ( c, c, this.radius_ *step, a0, a);
                                context.closePath();
                                context.fill();
                                context.stroke();
                                a0 = a;
                            }
                            if (this.type_ === "donut")
                            {	context.restore();
                                context.beginPath();
                                context.strokeStyle = strokeStyle;
                                context.lineWidth = strokeWidth;
                                context.arc ( c, c, this.radius_ *step *this.donutratio_, Math.PI * (step-1.5), a0);
                                context.stroke();
                            }
                            context.restore();
                            break;
                        }
                        case "bar":
                        default:
                        {	var max=0;
                            for (var k=0; k<this.data_.length; k++)
                            {	if (max < this.data_[k]) max = this.data_[k];
                            }
                            var s = Math.min(5,2*this.radius_/this.data_.length);
                            var cnv = canvas.width/2;
                            var b = canvas.width - strokeWidth;
                            var x, x0 = cnv - this.data_.length*s/2
                            context.strokeStyle = strokeStyle;
                            context.lineWidth = strokeWidth;
                            for (var l=0; l<this.data_.length; l++)
                            {	context.beginPath();
                                context.fillStyle = this.colors_[l%this.colors_.length];
                                x = x0 + s;
                                var h = this.data_[l]/max*2*this.radius_ *step;
                                context.rect ( x0, b-h, s, h);
                                
                                context.closePath();
                                context.fill();
                                context.stroke();
                                x0 = x;
                            }

                        }
                    }

                    // Set Anchor
                    var anc = this.getAnchor();
                    anc[0] = c - this.offset_[0];
                    anc[1] = c - this.offset_[1];

                };


                /**
                 * @inheritDoc
                 */
                ol.style.Chart.prototype.getChecksum = function() 
                {
                    var strokeChecksum = (this.stroke_!==null) ?
                        this.stroke_.getChecksum() : '-';

                    var recalculate = (this.checksums_===null) ||
                        (strokeChecksum !== this.checksums_[1] ||
                        fillChecksum !== this.checksums_[2] ||
                        this.radius_ !== this.checksums_[3] ||
                        this.data_.join('|') !== this.checksums_[4]);

                    if (recalculate) {
                        var checksum = 'c' + strokeChecksum + fillChecksum 
                            + ((this.radius_ !== void 0) ? this.radius_.toString() : '-')
                            + this.data_.join('|');
                        this.checksums_ = [checksum, strokeChecksum, fillChecksum, this.radius_, this.data_.join('|')];
                    }

                    return this.checksums_[0];
                };
            }
        
            $scope.getChartOrdering = function() {
                ol.ordering = {}

                /** y-Ordering
                *	@return ordering function (f0,f1)
                */
                ol.ordering.yOrdering = function(options)
                {	return function(f0,f1)
                    {	return f0.getGeometry().getExtent()[1] < f1.getGeometry().getExtent()[1] ;
                    };
                }

                /** Order with a feature attribute
                *	@param option
                *		attribute: ordering attribute, default zIndex
                *		equalFn: ordering function for equal values
                *	@return ordering function (f0,f1)
                */
                ol.ordering.zIndex = function(options)
                {	if (!options) options = {};
                    var attr = options.attribute || 'zIndex';
                    if (option.equalFn)
                    {	return function(f0,f1)
                        {	if (f0.get(attr) === f1.get(attr)) return option.equalFn(f0,f1);
                            return f0.get(attr) < f1.get(attr);
                        };
                    }
                    else
                    {	return function(f0,f1)
                        {	return f0.get(attr) < f1.get(attr);
                        };
                    }
                }   
            }
            
            // ol.style.Chart
            var animation  = false;
            var styleCache = {};

            function getFeatureStyle (feature, sel)
            {	
                var k = "donut-pale-"+(sel?"1-":"")+feature.get("data");
                var style;
                //if (!style) 
                {	
                    var radius, c;
                    // area proportional to data size: s=PI*r^2
                    
                    if($rootScope.isMobile === false) {
                        if(screen.width === 1024 && screen.height === 768) {
                            radius = 4 * Math.sqrt (feature.get("size") / Math.PI);
                        } else {
                            radius = 8 * Math.sqrt (feature.get("size") / Math.PI);
                        }
                    } else {
                        radius = 4 * Math.sqrt (feature.get("size") / Math.PI);    
                    }

                    // Create chart style
                    if (feature.get("color") === "GREEN") {
                        c = "pale-green"; 
                    } else if (feature.get("color") === "RED") {
                        c = "pale-red"; 
                    } else {
                        c = "pale-yellow"; 
                    }
                 
                    styleCache[k] = style = new ol.style.Style(
                    {	image: new ol.style.Chart(
                        {	type: 'donut', 
                            radius: (sel?1.2:1)*radius, 
                            offsetY: (sel?-1.2:-1)*feature.get("radius"),
                            data: feature.get("data") || [10,30,20], 
                            colors: /,/.test(c) ? c.split(",") : c,
                            rotateWithView: true,
                            animation: animation,
                            stroke: new ol.style.Stroke(
                            {	color: feature.get("color"),
                                width: 1
                            }),
                        })
                    });
                }
                style.getImage().setAnimation(animation);
                return [style];
            }

            // Animate function 
            var listenerKey;
            function doAnimate(vector)
            {	if (listenerKey) return;
                var start = new Date().getTime();
                var duration = 2000;
                animation = 0;
                listenerKey = vector.on('precompose', function(event)
                {	var frameState = event.frameState;
                    var elapsed = frameState.time - start;
                    if (elapsed > duration) 
                    {	ol.Observable.unByKey(listenerKey);
                        listenerKey = null;
                        animation = false;
                    }	
                    else
                    {	animation = ol.easing.easeOut (elapsed / duration);
                        frameState.animate = true;
                    }
                    vector.changed();
                });
             
                setTimeout( function() { 
                    map.updateSize();
                }, 200);
             
                // Force redraw
                vector.changed();
                map.renderSync();
            }
        
            function checkMapZoom() {
                var newZoomLevel = map.getView().getZoom();
                
                if(newZoomLevel >= 2.03 && newZoomLevel <= 3.11) {
                    if(siteVectorSource){
                        siteVectorSource.clear(true);
                    }
                    
                    if(countryVectorSource){
                        countryVectorSource.clear(true);
                    }
                    
                    if(regionVectorSource){
                        regionVectorSource.clear(true);
                    }
                    
                    setTimeout( function() { 
                        map.updateSize();
                    }, 200);
                    

                    countryVectorSource = new ol.source.Vector({
                        features: countryFeatures //add an array of features
                    });

                    countryVector = new ol.layer.Vector(
                    {	name: 'Vecteur',
                        source: countryVectorSource,
                        // y ordering
                        renderOrder: ol.ordering.yOrdering(),
                        style: function(f) { return getFeatureStyle(f); }
                    });

                    map.getView().setZoom(3.12);
                    map.getView().setCenter(ol.proj.transform([$scope.avglong, $scope.avglat], 'EPSG:4326', 'EPSG:3857'));
                    
                    
                    map.addLayer(countryVector);
                    countryVector.changed();
                    map.renderSync();
                    $scope.mapVector = countryVector;
                    
                    if($rootScope.selectionPenetrationFilterData.state === "") {
                        map.on('moveend', onPointerMoveTwo);
                        map.on("singleclick", onPointerClickTwo);
                        map.on("singleclick", onPointerClickFive);
                        map.un("singleclick", onPointerClickThree);
                        map.un("singleclick", onPointerClickFour);
                    }

                    doAnimate(countryVector);
                    
                } else if(newZoomLevel <= 2.01) {
                    
                    if(siteVectorSource){
                        siteVectorSource.clear(true);
                    }
                    
                    if(countryVectorSource){
                        countryVectorSource.clear(true);
                    }

                    if(regionVectorSource){
                        regionVectorSource.clear(true);
                    }
                    
                    if($rootScope.selectionPenetrationFilterData.level === "worldCountries") {
                        map.un('moveend', onPointerMoveTwo);
                        map.un('moveend', onPointerMoveThree);
                    }

                    setTimeout( function() { 
                        map.updateSize();
                    }, 200);
                    
                    
                    if ($rootScope.selectionPenetrationFilterData.state === "country") {
                        countryVectorSource = new ol.source.Vector({
                            features: countryFeatures //add an array of features
                        });

                        countryVector = new ol.layer.Vector(
                        {	name: 'Vecteur',
                            source: countryVectorSource,
                            // y ordering
                            renderOrder: ol.ordering.yOrdering(),
                            style: function(f) { return getFeatureStyle(f); }
                        });

                        map.getView().setZoom(2.01);
                        map.getView().setCenter(ol.proj.transform([0, 0], 'EPSG:4326', 'EPSG:3857'));

                        map.addLayer(countryVector);

                        countryVector.changed();
                        map.renderSync();
                        $scope.mapVector = countryVector;

                        doAnimate(countryVector);
                    } else {
                        regionVectorSource = new ol.source.Vector({
                            features: regionFeatures //add an array of features
                        });

                        regionVector = new ol.layer.Vector(
                        {	name: 'Vecteur',
                            source: regionVectorSource,
                            // y ordering
                            renderOrder: ol.ordering.yOrdering(),
                            style: function(f) { return getFeatureStyle(f); }
                        });

                        map.getView().setZoom(2.02);
                        map.getView().setCenter(ol.proj.transform([0, 0], 'EPSG:4326', 'EPSG:3857'));

                        map.addLayer(regionVector);
                        regionVector.changed();
                        map.renderSync();
                        $scope.mapVector = regionVector;

                        doAnimate(regionVector);
                    }
  
                } 
            }
            
            $scope.exportPenetrationDashboard = function(exportOption) {
                
                if (!$rootScope.selectionPenetrationFilterData) {
                    $rootScope.selectionPenetrationFilterData = {};
                }
                
                if(exportOption === "exportAll") {
                    $rootScope.selectionPenetrationFilterData = {};   
                    $rootScope.selectionPenetrationFilterData.quarter = $scope.penetrationFilterData.quarter;
                    $rootScope.selectionPenetrationFilterData.report  = $scope.penetrationFilterData.report;
                    $rootScope.selectionPenetrationFilterData.value   = $scope.penetrationFilterData.value;
                }
                
                $rootScope.selectionPenetrationFilterData.option = exportOption;
                
            	download('/connect/fms/exportPenetrationDashboard/'+$rootScope.businessSegment, $rootScope.selectionPenetrationFilterData, 'Penetration Dashboard');
            };
        
            $scope.siteAndInstallUnitInfo = function() {
                
                if ($.fn.DataTable.isDataTable('#installUnitsTable')) {
                    $("#installUnitsTable").dataTable().api().clear().draw();
                    $("#installUnitsTable").dataTable().api().destroy();
                    $('#installUnitsTable').empty();
                }
                
                
                var $window     = $(window);
                var windowsize  = $window.width();
                var responsive;
                if (windowsize > 767) {
                    responsive = false;
                } else {
                    responsive = true;
                }

                installUnitsTable = $('#installUnitsTable').DataTable({
                        rowReorder: {
                            selector: 'td:nth-child(2)'
                        },
                        responsive: responsive,
                        "order": [],
                        data: $scope.siteAndUnitDetails,
                        "columns": [{
                                title: "Sr No",
                                "bSortable": false,
                                "bSearchable": false,
                                mRender: function(data, type, row) {
                                    return '<a class="UnitSerialNo" data-id="' + row.serialNumber + '">' + row.serialNumber + '</a>'
                                }
                            },
                            {
                                data: "siteName",
                                title: "Site Name"
                            },
                            {
                                data: "custName",
                                title: "Customer Name"
                            },
                            {
                                data: "siteCustCountry",
                                title: "Country"
                            },
                            {
                                data: "prodExcPL",
                                title: "Product Company"
                            },
                            {
                                data: "marketSegmentDesc",
                                title: "Market"
                            },
                            {
                                data: "siteCustCity",
                                title: "City"
                            },
                            {
                                data: "ibDataRegion",
                                title: "Region"
                            },
                            {
                                data: "technologyDescOG",
                                title: "Technology"
                            },
                            {
                                data: "unitShipData",
                                title: "Shipped Date"
                            },
                            {
                                data: "estServiceHrsCount",
                                title: "Service Hours"
                            },
                            {
                                data: "serviceRelationDesc",
                                title: "Relationship"
                            },
                            {
                                title: "Total IBO",
                                mRender: function(data, type, row) {
                                    return '$'+row.avTot;
                                }
                            },
                            {
                                data: "equipmentModel",
                                title: "Equipment Model"
                            },
                            {
                                data: "unitCustomerName",
                                title: "Unit Customer Name"
                            },
                            {
                                data: "eventDate",
                                title: "Event Date"
                            },
                            {
                                data: "eventType",
                                title: "Type"
                            },
                            {
                                data: "eventStatus",
                                title: "Status"
                            },
                            {
                                data: "equipmentCode",
                                title: "Equipment Code"
                            },
                            {
                                data: "equipmentEngDesc",
                                title: "Equipment Desc"
                            },
                            {
                                title: "Sub-Business",
                                mRender: function(data, type, row) {
                                    return 'DP&S'
                                }
                            }
                        ],
                        "bSort": true,
                        "bFilter": true,
                        "aLengthMenu": [
                            [5, 10, 25, 50, -1],
                            [5, 10, 25, 50, "All"]
                        ],
                        "iDisplayLength": 5
                    });
                    $(".dataTables_scrollBody").slimScroll();
                };
        
            $('body').off( 'click', 'a.UnitSerialNo');
            $('body').on( 'click', 'a.UnitSerialNo', function () {
                var data = installUnitsTable.row($(this).parents('tr')).data();

                $scope.regionName = data.ibDataRegion;
                $scope.siteName   = data.siteName;
                $scope.serialNo   = data.serialNumber;

                $http.post("connect/fms/getSerialInfoData", JSON.stringify({
                    "region": $scope.regionName,
                    "siteName": $scope.siteName,
                    "serialNumber": $scope.serialNo,
                    "businessSegment":$rootScope.businessSegment,
                    "accountManager": "",
                    "marketIndustry":$rootScope.marketIndustry ? $rootScope.marketIndustry : ""
                })).success(function(response) {
                    siteInfoContentModalList.style.display = "block";
                    $scope.serialDetails = response;
                    $scope.getSerialDetails();
                }).then(function() {
                    resizeAll();
                });
            });
        
            $scope.getSerialDetails = function() {
                for (var i = 0; i < $scope.serialDetails.length; i++) {
                    var item                 = $scope.serialDetails[i];
                    $scope.serialNo          = item.serialNumber;
                    $scope.technology        = item.technologyDescOG;
                    $scope.description       = item.techDesc;
                    $scope.maintenancePolicy = item.maintPolicyCOD;
                    $scope.oemLocation       = item.oemLocationDesc;
                    $scope.rating            = item.unitRating;
                    $scope.speed             = item.unitSpeedRPM;
                    $scope.cntrlSystem       = item.controlSystemDesc;
                    $scope.driven            = item.drivenEquipDesc;
                    $scope.combustionSystem  = item.combustionSystemDesc;
                    $scope.fuelType          = item.primaryFuelTypeDesc;
                }
                
                $(".zoomImg").remove();
                $(".imageSrc").attr("src", "/images/" + $scope.technology + ".jpg");

                $('#imageinfo').hover(
                    function() {
                        $(".txtHover").html('');
                    },
                    function() {
                        $(".txtHover").html('Hover');
                    }
                );
                
                $('#imageinfo').zoom({
                    url: '/images/' + $scope.technology + '.jpg',
                    callback: function() {}
                });
            }
            
            $scope.backToSite = function() {
                siteInfoContentModalList.style.display = "none";
                installUnitModalList.style.display     = "block";
            };
        
            $scope.getSiteInfoAndInstalledUnitsData = function(siteNameTitle) {
                $scope.siteNameArr = _.pluck($scope.LatLongBySite, "siteName");
                $scope.siteName     = '\'' + ($scope.siteNameArr).join('\',\'') + '\'';
                $scope.siteNameTitle = siteNameTitle + ' - SITES'; 
                
                $http.post("connect/fms/getSiteInfoAndInstalledUnits", JSON.stringify({
                    "region": $scope.regionName,
                    "siteName": $scope.siteName,
                    "businessSegment":$rootScope.businessSegment,
                    "accountManager": "",
                    "marketIndustry":$rootScope.marketIndustry ? $rootScope.marketIndustry : ""
                })).success(function(response) {
                    installUnitModalList.style.display = "block";
                    $scope.siteAndUnitDetails = response;
                    $scope.siteAndInstallUnitInfo();
                }).then(function() {
                    resizeAll();
                });
            };
        
            $scope.excelDownload = function(id) {
                RevenueDataNetworkService.excelDownload(id); 
            };
        
    		function download(url,data ,defaultFileName) {
    			var deferred = $q.defer();
    			$http.post(url,data, { responseType: "arraybuffer" }).success(
                    function (data, status, headers) {
                        var type = headers('Content-Type');
                        var disposition = headers('Content-Disposition');
                        if (disposition) {
                            var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                            if (match[1])
                                defaultFileName = match[1];
                        }
                        defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                        var blob = new Blob([data], { type: type });
                        saveAs(blob, defaultFileName);
                        deferred.resolve(defaultFileName);                    
                    }).error(function () {
                        var e ;
                        deferred.reject(e);
                    });
    			return deferred.promise;
    		}
    }]);
});