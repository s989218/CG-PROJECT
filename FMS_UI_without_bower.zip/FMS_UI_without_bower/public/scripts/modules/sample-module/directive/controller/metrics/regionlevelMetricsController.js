define(['angular','../../../sample-module', 'jquery', 'datatablesNetMin', 'datatablesNet'], function (angular,controllers) 
 {
    'use strict';
    controllers.controller('regionlevelMetricsController', ['$scope', '$rootScope','$http','RegionRevenueCurrDataService','CreateChartService','RevenueDataNetworkService',
	'IBbyRegionCurDataService','IBbyRegionChart','OpexpenetrationCurDataService','OpexPenetrationChartService', 'FleetpenetrationDataService','FleetPenetrationChartService','FleetcoverageDataService','FleetCoverageChartService',
	'CaloricbyRegionCurDataService','CaloricRegionChartService','ConversionIndexDataService','ConversionIndexChartService','IBObyTechDataService','IBObyTechChartService','IBNbyRegionDataService','IBNbyRegionChartService','IBNbyTechDataService','IBNbyTechChartService',
	'PartsPenDataService','PartsPenChartService','LoaderService','$timeout',
	function ($scope,$rootScope,$http,RegionRevenueCurrDataService,CreateChartService,RevenueDataNetworkService,
	IBbyRegionCurDataService,IBbyRegionChart,OpexpenetrationCurDataService,OpexPenetrationChartService,FleetpenetrationDataService,FleetPenetrationChartService,FleetcoverageDataService,FleetCoverageChartService,
	CaloricbyRegionCurDataService,CaloricRegionChartService,ConversionIndexDataService,ConversionIndexChartService,IBObyTechDataService,IBObyTechChartService,IBNbyRegionDataService,IBNbyRegionChartService,IBNbyTechDataService,IBNbyTechChartService,PartsPenDataService,PartsPenChartService,LoaderService,$timeout) 
   {
		  
       
          $(".loading").center();
          function loaderOps(state){
            LoaderService.loaderOps(state);
          }
		  loaderOps(true);
       
          function setScopeData(result, key){
			var variableName = key
			$scope[variableName+'1'] = result[variableName+'1'];
			$scope[variableName+'2'] = result[variableName+'2'];		  
		  }
       
          $timeout(function() {
            if (!$rootScope.marketIndustry) {
                $rootScope.regionLevelSearchData();
            }
          }, 5000);
       
          $rootScope.regionLevelSearchData = function() {
              loaderOps(true);
              
              var item = {};
              item["timePeriodType"] = $rootScope.cHistoryLegacySwitch;
              item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
              
              RevenueDataNetworkService.getAllMetricsData(JSON.stringify(item)).then(function(response){
                var responseData = RevenueDataNetworkService.returnDataObjects(response);
                var updateIBObyRegionRevenueCurData = RegionRevenueCurrDataService.updateIBObyRegionRevenueCurData(responseData.IBObyRegionDataCur, responseData.revDollarbyRegionDataCur);
                setScopeData(updateIBObyRegionRevenueCurData,'IBObyRegRevCurDataTable' );					
                var updateIBObyRegionRevenueHistData = RegionRevenueCurrDataService.updateIBObyRegionRevenueHistData(responseData.IBObyRegionDataHis, responseData.revDollarbyRegionDataHis,responseData);
                setScopeData(updateIBObyRegionRevenueHistData,'IBObyRegRevHistDataTable' );
                var updateIBbyRegionCurData = IBbyRegionCurDataService.updateIBbyRegionCurData(responseData);
                setScopeData(updateIBbyRegionCurData,'IBbyRegionCurDataTable' );
                var updateIBbyRegionHistData = IBbyRegionCurDataService.updateIBbyRegionHistData(responseData);
                setScopeData(updateIBbyRegionHistData,'IBbyRegionHistDataTable' );
                var updateOpexpenetrationCurData = OpexpenetrationCurDataService.updateOpexpenetrationCurData(responseData);
                setScopeData(updateOpexpenetrationCurData,'OpexpenetrationF2FCurDataTable' );
                var updateOpexpenetrationHistData = OpexpenetrationCurDataService.updateOpexpenetrationHistData(responseData);
                setScopeData(updateOpexpenetrationHistData,'OpexpenetrationF2FHistDataTable' );
                var updateFleetpenetrationData = FleetpenetrationDataService.updateFleetpenetrationData(responseData);
                setScopeData(updateFleetpenetrationData,'FleetpenetrationCurDataTable' );
                var updateFleetpenetrationHistData = FleetpenetrationDataService.updateFleetpenetrationHistData(responseData);
                setScopeData(updateFleetpenetrationHistData,'FleetpenetrationHistDataTable' );
                var updateFleetcoverageData = FleetcoverageDataService.updateFleetcoverageData(responseData);
                setScopeData(updateFleetcoverageData,'FleetcoverageCurDataTable' );
                var updateFleetcoverageHistData = FleetcoverageDataService.updateFleetcoverageHistData(responseData);
                setScopeData(updateFleetcoverageHistData,'FleetcoverageHistDataTable' );
                var updateCaloricbyRegionCurData = CaloricbyRegionCurDataService.updateCaloricbyRegionCurData(responseData);
                setScopeData(updateCaloricbyRegionCurData,'CaloricIndexRegCurDataTable' );
                var updateCaloricbyRegionHistData = CaloricbyRegionCurDataService.updateCaloricbyRegionHistData(responseData);
                setScopeData(updateCaloricbyRegionHistData,'CaloricIndexRegHistDataTable' );
                var updateConversionIndexCurData = ConversionIndexDataService.updateConversionIndexCurData(responseData);
                setScopeData(updateConversionIndexCurData,'ConversionIndexCurDataTable' );
                var updateConversionIndexHistData = ConversionIndexDataService.updateConversionIndexHistData(responseData);
                setScopeData(updateConversionIndexHistData,'ConversionIndexHistDataTable' );
                var updateIBObyTechCurData = IBObyTechDataService.updateIBObyTechCurData(responseData);
                setScopeData(updateIBObyTechCurData,'IBObyTechCurDataTable' );
                var updateIBObyTechHistData = IBObyTechDataService.updateIBObyTechHistData(responseData);
                setScopeData(updateIBObyTechHistData,'IBObyTechHistDataTable' );
                var updateIBNbyRegionCurData = IBNbyRegionDataService.updateIBNbyRegionCurData(responseData);
                setScopeData(updateIBNbyRegionCurData,'IBNbyRegionCurDataTable' );
                var updateIBNbyRegionHistData = IBNbyRegionDataService.updateIBNbyRegionHistData(responseData);
                setScopeData(updateIBNbyRegionHistData,'IBNbyRegionHistDataTable' );
                var updateIBNbyTechCurData = IBNbyTechDataService.updateIBNbyTechCurData(responseData);
                setScopeData(updateIBNbyTechCurData,'IBNbyTechCurDataTable' );
                var updateIBNbyTechHistData = IBNbyTechDataService.updateIBNbyTechHistData(responseData);
                setScopeData(updateIBNbyTechHistData,'IBNbyTechHistDataTable' );
                var updatePartsPenCurData = PartsPenDataService.updatePartsPenCurData(responseData.partsPenetrationCur,'Parts-Pen-Cur-Data','PartsPenCurHeader','PartsPenCurtableData','PartsPenCurDataTable','container11');
                setScopeData(updatePartsPenCurData,'PartsPenCurDataTable' );
                var updatePartsPenHistData = PartsPenDataService.updatePartsPenHistData(responseData.partsPenetrationHis,responseData.partsPenYearAvgDTO,responseData.partsPenetrationAvg,'Parts-Pen-His-Data','PartsPenHisHeader','PartsPenHisTableData','PartsPenHistDataTable','container11History');
                setScopeData(updatePartsPenHistData,'PartsPenHistDataTable' );
                var updateRepairsPenCurData = PartsPenDataService.updatePartsPenCurData(responseData.repairsPenetrationCur,'Repairs-Pen-Cur-Data','RepairsPenCurHeader','RepairsPenCurtableData','RepairsPenCurDataTable','container12');
                setScopeData(updateRepairsPenCurData,'RepairsPenCurDataTable' );
                var updateRepairsPenHistData = PartsPenDataService.updatePartsPenHistData(responseData.repairsPenetrationHis,responseData.repairsPenYearAvgDTO,responseData.repairsPenetrationAvg,'Repairs-Pen-His-Data','RepairsPenHisHeader','RepairsPenHisTableData','RepairsPenHistDataTable','container12History');
                setScopeData(updateRepairsPenHistData,'RepairsPenHistDataTable' );
                var updateServicePenCurData = PartsPenDataService.updatePartsPenCurData(responseData.servicePenetrationCur,'Service-Pen-Cur-Data','ServicePenCurHeader','ServicePenCurtableData','ServicePenCurDataTable','container13');
                setScopeData(updateServicePenCurData,'ServicePenCurDataTable' );
                var updateServicePenHistData = PartsPenDataService.updatePartsPenHistData(responseData.servicePenetrationHis,responseData.servicePenYearAvgDTO,responseData.servicePenetrationAvg,'Service-Pen-His-Data','ServicePenHisHeader','ServicePenHisTableData','ServicePenHistDataTable','container13History');
                setScopeData(updateServicePenHistData,'ServicePenHistDataTable' );
              }).then(function(){
                resizeAll();
                loaderOps(false);
              });
        }
          
		angular.element(document.body).on('click','.scrollAnchor',function()
		{
					var child=$('#'+this.id);
					var parent=$('#mainDivSection');
					setTimeout (function (){
						document.getElementById('mainDivSection').scrollTop = child.offset().top-parent.offset().top;
					},200);
		});
		 	$scope.excelDownloadIB = function(id) {
		 		IBbyRegionCurDataService.excelDownload(id); 
		 	};
		 	$scope.exportChartIB = function(type) {
		 		IBbyRegionChart.exportChartCur(type); 
		 	};
		 	$scope.exportHistoryChartIB = function(type) {
		 		IBbyRegionChart.exportChartHistory(type); 
		 	};
		 	$scope.excelDownloadOpex = function(id) {
		 		OpexpenetrationCurDataService.excelDownload(id); 
		 	};
		 	$scope.exportChartOpex = function(type) {
		 		OpexPenetrationChartService.exportChart(type); 
		 	};
		 	$scope.exportChartOpexHist = function(type) {
		 		OpexPenetrationChartService.exportChartHist(type); 
		 	};
		 	$scope.excelDownloadFleetPen = function(id) {
		 		FleetpenetrationDataService.excelDownload(id); 
		 	};
		 	$scope.exportChartFeetPen = function(type) {
		 		FleetPenetrationChartService.exportChart(type); 
		 	};
		 	$scope.exportChartFeetPenHist = function(type) {
		 		FleetPenetrationChartService.exportChartHistory(type); 
		 	};
		 	$scope.excelDownloadFleetCov = function(id) {
		 		FleetcoverageDataService.excelDownload(id); 
		 	};
		 	$scope.exportChartFeetCov = function(type) {
		 		FleetCoverageChartService.exportChart(type); 
		 	};
			$scope.exportChartFeetCovHist = function(type) {
		 		FleetCoverageChartService.exportChartHistory(type); 
		 	};
			$scope.excelDownloadColoric = function(id) {
				CaloricbyRegionCurDataService.excelDownload(id); 
		 	};
		 	$scope.exportChartCaloric = function(type) {
		 		CaloricRegionChartService.exportChart(type); 
		 	};
			$scope.exportChartCaloricHist = function(type) {
		 		CaloricRegionChartService.exportChartHistory(type); 
		 	};
		 	$scope.excelDownloadConversion = function(id) {
		 		ConversionIndexDataService.excelDownload(id); 
		 	};
		 	$scope.exportChartConversion = function(type) {
		 		ConversionIndexChartService.exportChart(type); 
		 	};
		 	$scope.exportChartConversionHist = function(type) {
		 		ConversionIndexChartService.exportChartHistory(type); 
		 	};
		 	$scope.excelDownloadIBObyTech = function(id) {
		 		IBObyTechDataService.excelDownload(id); 
		 	};
		 	$scope.exportChartIBObyTech = function(type) {
		 		IBObyTechChartService.exportChart(type); 
		 	};
		 	$scope.exportChartIBObyTechHist = function(type) {
		 		IBObyTechChartService.exportChartHistory(type); 
		 	};
		 	$scope.excelDownloadIBNbyRegion = function(id) {
		 		IBNbyRegionDataService.excelDownload(id); 
		 	};
		 	$scope.exportChartIBNbyRegion = function(type) {
		 		IBNbyRegionChartService.exportChart(type); 
		 	};
			$scope.exportChartIBNbyRegionHist = function(type) {
		 		IBNbyRegionChartService.exportChartHistory(type); 
		 	};
		 	$scope.excelDownloadIBNbyTech = function(id) {
		 		IBNbyTechDataService.excelDownload(id); 
		 	};
		 	$scope.exportChartIBNbyTech = function(type) {
		 		IBNbyTechChartService.exportChart(type); 
		 	};
		 	$scope.exportChartIBNbyTechHist = function(type) {
		 		IBNbyTechChartService.exportChartHistory(type); 
		 	};
		 	$scope.excelDownloadIBOregrev = function(id) {
		 		RegionRevenueCurrDataService.excelDownload(id); 
		 	};
		 	$scope.exportChartIBORegRev = function(type) {
		 		CreateChartService.exportChart(type); 
		 	};
			$scope.exportChartIBORegRevHist = function(type) {
		 		CreateChartService.exportChartHistory(type); 
		 	};
			$scope.excelDownloadPartsPen = function(id) {
				PartsPenDataService.excelDownload(id); 
		 	};
		 	$scope.exportChartPartsPen = function(type) {
		 		PartsPenChartService.exportChart(type,'Parts-Penetration-Current-Chart','container11'); 
		 	};
			$scope.exportChartPartsPenHist = function(type) {
				PartsPenChartService.exportChartHistory(type,'Parts-Penetration-History-Chart','container11History'); 
		 	};
		 	$scope.excelDownloadRepairsPen = function(id) {
				PartsPenDataService.excelDownload(id); 
		 	};
		 	$scope.exportChartRepairsPen = function(type) {
		 		PartsPenChartService.exportChart(type,'Repairs-Penetration-Current-Chart','container12'); 
		 	};
			$scope.exportChartRepairsPenHist = function(type) {
				PartsPenChartService.exportChartHistory(type,'Repairs-Penetration-History-Chart','container12History'); 
		 	};
		 	$scope.excelDownloadServicePen = function(id) {
				PartsPenDataService.excelDownload(id); 
		 	};
		 	$scope.exportChartServicePen = function(type) {
		 		PartsPenChartService.exportChart(type,'Service-Penetration-Current-Chart','container13'); 
		 	};
			$scope.exportChartServicePenHist = function(type) {
				PartsPenChartService.exportChartHistory(type,'Service-Penetration-History-Chart','container13History'); 
		 	};
		 	
		 	$(document).ready(function(){
		 	    $('[data-toggle="collapse"]').tooltip();
		 	});
		 	
		 	$('#top-right').tooltip('show');
		 	
			$scope.ShowHide1 = function(){
				$scope.summary=true;
				$scope.IsVisible1 = $scope.IsVisible1 ? false : true;
				$scope.IsHidden1=$scope.IsHidden1 ? false : true;
			};	
			$scope.ShowHide2 = function(){
				$scope.summary=true;	
				$scope.IsVisible2 = $scope.IsVisible2 ? false : true;
				$scope.IsHidden2=$scope.IsHidden2 ? false : true;
			};		
			$scope.ShowHide3 = function(){
				$scope.summary=true;	
				$scope.IsVisible3 = $scope.IsVisible3 ? false : true;
				$scope.IsHidden3=$scope.IsHidden3 ? false : true;
			};	
			$scope.ShowHide4 = function(){
				$scope.summary=true;	
				$scope.IsVisible4 = $scope.IsVisible4 ? false : true;
				$scope.IsHidden4=$scope.IsHidden4 ? false : true;
			};
			$scope.ShowHide5 = function(){
				$scope.summary=true;	
				$scope.IsVisible5 = $scope.IsVisible5 ? false : true;
				$scope.IsHidden5=$scope.IsHidden5 ? false : true;
			};
			$scope.ShowHide6 = function(){
				$scope.summary=true;	
				$scope.IsVisible6 = $scope.IsVisible6 ? false : true;
				$scope.IsHidden6=$scope.IsHidden6 ? false : true;
			};
			$scope.ShowHide7 = function(){
				$scope.summary=true;	
				$scope.IsVisible7 = $scope.IsVisible7 ? false : true;
				$scope.IsHidden7=$scope.IsHidden7 ? false : true;
			};
			$scope.ShowHide8 = function(){
				$scope.summary=true;	
				$scope.IsVisible8 = $scope.IsVisible8 ? false : true;
				$scope.IsHidden8=$scope.IsHidden8 ? false : true;
			};
			$scope.ShowHide9 = function(){
				$scope.summary=true;	
				$scope.IsVisible9 = $scope.IsVisible9 ? false : true;
				$scope.IsHidden9=$scope.IsHidden9 ? false : true;
			};
			$scope.ShowHide10 = function(){
				$scope.summary=true;	
				$scope.IsVisible10 = $scope.IsVisible10 ? false : true;
				$scope.IsHidden10=$scope.IsHidden10 ? false : true;
			};
			$scope.ShowHide11 = function(){
				$scope.summary=true;	
				$scope.IsVisible11 = $scope.IsVisible11 ? false : true;
				$scope.IsHidden11=$scope.IsHidden11 ? false : true;
			};
			$scope.ShowHide12 = function(){
				$scope.summary=true;	
				$scope.IsVisible12 = $scope.IsVisible12 ? false : true;
				$scope.IsHidden12=$scope.IsHidden12 ? false : true;
			};
			$scope.ShowHide13 = function(){
				$scope.summary=true;	
				$scope.IsVisible13 = $scope.IsVisible13 ? false : true;
				$scope.IsHidden13=$scope.IsHidden13 ? false : true;
			};
	}]);
});