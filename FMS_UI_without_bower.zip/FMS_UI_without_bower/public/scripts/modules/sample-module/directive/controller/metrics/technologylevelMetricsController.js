
define(['angular','../../../sample-module','jquery', 'datatablesNetMin', 'datatablesNet','multiselectdrpdwn','jqueryMultiSelect'], function (angular,controllers) 
 {
    'use strict';
    controllers.controller('technologylevelMetricsController', ['$scope','$timeout','$state','$rootScope','LoaderService','countryLevelDataNetworkService',
	function ($scope,$timeout,$state,$rootScope,LoaderService,countryLevelDataNetworkService){
    	$('.errorIndicator').hide(100);
    	$scope.regionSelected = true;
    	jQuery.fn.center = function() {
            this.css({top: ($(window).outerHeight()) / 2,left: ($(window).outerWidth()) / 2});
			return this;
		};
    	$(".loading").center();
		function loaderOps(state){
			LoaderService.loaderOps(state);
		}
		loaderOps(true);
		$scope.safeApply =function(fn){
			$timeout(fn);
		}
		
		countryLevelDataNetworkService.getMetricsDropdownsData().then(function(response){
    		$scope.safeApply(function(){
				$scope.techregionDropdownBean = response; 
			});	
			resizeAll();
			loaderOps(false);
			resizeAll();
			loaderOps(false);
    	});
		
    }]);
});

