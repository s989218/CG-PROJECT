define(['angular','../../../sample-module', 'jquery', 'datatablesNetMin', 'datatablesNet'], function (angular,controllers) 
{
    'use strict';
    controllers.controller('topSitesController', ['$scope', '$timeout', '$state', '$rootScope', '$http', '$q', 'LoaderService', 'RevenueDataNetworkService','countryLevelDataNetworkService','$window',
	function ($scope, $timeout, $state, $rootScope, $http, $q, LoaderService, RevenueDataNetworkService,countryLevelDataNetworkService,$window) {
        
        var topSitesChart, dataTable;
        $scope.regionSelected = true;
        $('.topSiteErrorIndicator').hide(100);
        jQuery.fn.center = function() {
            this.css({top: ($(window).outerHeight()) / 2,left: ($(window).outerWidth()) / 2});
			return this;
		};
        
        $(".loading").center();
        
		function loaderOps(state){
			LoaderService.loaderOps(state);
		}
		$('select#topSitesServiceManagerSearch').hide(100);
		$('select#topSitesAccountManagerSearch').hide(100);
		loaderOps(true);
		
		 function getSiteSelectedValue(id) {
				var selector = "select.dependentFilter[id='"+id+"']";
				if (id === 'topSitesRegionSearch' && $(selector).val() !== null && $(selector).val() !== 'Select Region') {
	            	return $(selector).val();
				} else if ((id === 'topSitesCountrySearch' && $(selector).val() !== null && $(selector).val() !== 'Select Country')|| (id === 'topSitesServiceManagerSearch' && $(selector).val() !== null && $(selector).val()[0] !== 'Select Manager')||(id === 'topSitesAccountManagerSearch' && $(selector).val() !== null && $(selector).val()[0] !== 'Select Manager')){
					return '^'+$(selector).val()+'$';
				}else {
	                return "";
	            } 
			}
		 
        $scope.topSitesSearchData = function() {
            
			var item = {};
			item["region"] = getSiteSelectedValue('topSitesRegionSearch');
            item["country"]= getSiteSelectedValue('topSitesCountrySearch');
            item["serviceManagerDetails"]= getSiteSelectedValue('topSitesServiceManagerSearch');
            item["accountManagerDetails"]= getSiteSelectedValue('topSitesAccountManagerSearch');
            item["businessSegment"] = $rootScope.businessSegment;
            item["marketIndustry"]  = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
			if ( item['region'] !== '' && item['region'] !== 'Select Region' ) {
                loaderOps(true);
			    RevenueDataNetworkService.getPenetrationTopSitesData(JSON.stringify(item)).then(function(response){
                    
                    $scope.arrTopSitesIBOChartData         = response.chart.iboChart;
                    $scope.arrTopSitesPenetrationChartData = response.chart.penetrationChart;
                    $scope.arrTopSitesDMChartData          = response.chart.dmChart;
                    $scope.arrTopSitesOrdersChartData      = response.chart.ordersChart;
                    $scope.arrTopSitesOutageChartData      = response.chart.outageChart;
                    
                    $scope.arrTopSitesTableData            = response.table;
                    $scope.arrTableHeading				   = response.year_quarter_range;
                    // Top Site X-Axis
                    $scope.arrTopSitesXAxis = _.chain($scope.arrTopSitesIBOChartData).map(function(item) { 
                        return item.site 
                    }).uniq().value();
                    
                    // Top Site IBO Chart Y-Axis
                    $scope.arrIBOChartYAxis = _.chain($scope.arrTopSitesIBOChartData).map(function(item) { 
                        return parseFloat(item.val).toFixed(2); 
                    }).value();
                    
                    $scope.arrIBOChartYAxis = _.map($scope.arrIBOChartYAxis, parseFloat);
                    
                    // Top Site Penetration Chart Y-Axis
                    $scope.arrPenetrationChartYAxis = _.chain($scope.arrTopSitesPenetrationChartData).map(function(item) { 
                        return parseFloat(item.val).toFixed(2); 
                    }).value();
                    
                    $scope.arrPenetrationChartYAxis = _.map($scope.arrPenetrationChartYAxis, parseFloat);
                    
                    // Top Site DM Chart Y-Axis
                    $scope.arrDMChartYAxis = _.chain($scope.arrTopSitesDMChartData).map(function(item) { 
                        return parseFloat(item.val).toFixed(2); 
                    }).value();
                    
                    $scope.arrDMChartYAxis = _.map($scope.arrDMChartYAxis, parseFloat);
                    
                    // Top Site Orders Chart Y-Axis
                    $scope.arrOrdersChartYAxis = _.chain($scope.arrTopSitesOrdersChartData).map(function(item) { 
                        return parseFloat(item.val).toFixed(2); 
                    }).value();
                    
                    $scope.arrOrdersChartYAxis = _.map($scope.arrOrdersChartYAxis, parseFloat);
                    
                    // Top Site Outage Chart Y-Axis
                    $scope.arrOutageChartYAxis = _.chain($scope.arrTopSitesOutageChartData).map(function(item) { 
                        return parseFloat(item.val).toFixed(2); 
                    }).value();
                    
                    $scope.arrOutageChartYAxis = _.map($scope.arrOutageChartYAxis, parseFloat);
                    
                    $scope.createTopSitesView();
                    
				    loaderOps(false);
			     });
			} else {
				$('#topSitesRegionSearch').addClass("boxShadow");
				$('.topSiteErrorIndicator').show(100);
			}
			$('.countryPanelHead').unbind('click');
		}
        
        
        function getFirstQuarterDate(year, quarter) {
            var quarterFirstDate;
            if (quarter === "1")
                quarterFirstDate = year +" 01 01";
            else if (quarter === "2")
                quarterFirstDate = year +" 04 01";
            else if (quarter === "3")
                quarterFirstDate = year +" 07 01";
            else if (quarter === "4")
                quarterFirstDate = year +" 10 01";
            
            return quarterFirstDate;
        }

        function getLastQuarterDate(year, quarter) {
            var quarterLastDate;
            if (quarter === "1")
                quarterLastDate = year +" 03 31";
            else if (quarter === "2")
                quarterLastDate = year +" 06 30";
            else if (quarter === "3")
                quarterLastDate = year +" 09 30";
            else if (quarter === "4")
                quarterLastDate = year +" 12 31";

            return quarterLastDate;
        }
        
        $scope.createTopSitesView = function() {
            Highcharts.setOptions({lang: {noData: "No Data Available!"}});
            
            topSitesChart = new Highcharts.Chart({

                chart: {
                    renderTo: 'topSitesChart',
                    zoomType: 'xy'
                },

                title: {
                    useHTML: true,
                    text: 'Top IBO Customers Penetration'

                },

                credits: {

                      enabled: false

                },

                xAxis: {

                    categories: $scope.arrTopSitesXAxis,
                    crosshair: true,
                    lineColor:'#999',
                    lineWidth:1,
                    tickColor:'#666',
                    tickLength:3,
                    labels: {
                        rotation: -45,
                        style: {
                            align: 'right',
                            color: '#7f8c8d',
                            fontFamily: 'Arial',
                            fontSize: '11px',
                            fontWeight: 'bold'
                        },
                        useHTML : true
                    }

                },
                
                yAxis: [{ // Primary yAxis
                    lineColor:'#999',
                    lineWidth:1,
                    tickColor:'#666',
                    tickWidth:1,
                    tickLength:3,
                    gridLineColor:'#ddd',
                    labels: {
                        format: '${value}',
                    },
                    title: {
                        text: 'Overall IBO, Orders & DM',
                        
                    }
                }, { // Secondary yAxis
                    labels: {
                        format: '{value}%',
                        style: {
                            color: Highcharts.getOptions().colors[3]
                        }
                    },
                    title: {
                        text: 'Overall Penetration',
                        style: {
                            color: Highcharts.getOptions().colors[3]
                        }
                    },
                    opposite: true
                }, { // Tertiary yAxis
                    gridLineWidth: 0,
                    title: {
                        text: 'Overall Outage',
                        style: {
                            color: Highcharts.getOptions().colors[4]
                        }
                    },
                    labels: {
                        format: '{value}',
                        style: {
                            color: Highcharts.getOptions().colors[4]
                        }
                    },
                    opposite: true
                }],
                
                tooltip: {
                	formatter: function() {
                        var s = [],p;
                        s.push('<span style="font-size:10px">'+this.x+'</span><table>');
                        $.each(this.points, function(i, point) {
                        	 p = point.series.name;
                        	if(p === 'Overall IBO'){
                        		s.push('<tr><td style="color:'+point.series.color+';padding:0">'+point.series.name+': </td>' + '<td style="padding:0"><b>$'+point.y+'</b></td><td>'+$scope.arrTableHeading.overall_ibo_date_range+'</td></tr>');
                        	}else if(p === 'Overall Orders'){
                        		s.push('<tr><td style="color:'+point.series.color+';padding:0">'+point.series.name+': </td>' + '<td style="padding:0"><b>$'+Math.round(point.y)+'</b></td><td>'+$scope.arrTableHeading.orders_date_range+'</td></tr>');
                        	}else if(p === 'Overall DM'){
                        		s.push('<tr><td style="color:'+point.series.color+';padding:0">'+point.series.name+': </td>' + '<td style="padding:0"><b>$'+point.y+'</b></td><td>'+$scope.arrTableHeading.dm_date_range+'</td></tr>');
	                        }else if(p === 'Overall Penetration') {
	                        	s.push('<tr><td style="color:'+point.series.color+';padding:0">'+point.series.name+': </td>' + '<td style="padding:0"><b>'+point.y+'%</b></td><td>'+$scope.arrTableHeading.orders_date_range+'</td></tr>');
	                        }else if(p === 'Overall Outage'){
	                        	s.push('<tr><td style="color:'+point.series.color+';padding:0">'+point.series.name+': </td>' + '<td style="padding:0"><b>'+point.y+'</b></td><td>'+$scope.arrTableHeading.outage_date_range+'</td></tr>');
	                        }
                        });
                        s.push('</table>');
                        return s;
                    },
                    shared: true, 
                    useHTML: true
                },
                series: [
                    {
                            type: 'column',
                            name: 'Overall IBO',
                            data: $scope.arrIBOChartYAxis
                    }, 
                    {
                            type: 'column',
                            name: 'Overall Orders',
                            data: $scope.arrOrdersChartYAxis
                    },
                    {
                            type: 'spline',
                            name: 'Overall Penetration',
                            yAxis: 1,
                            data: $scope.arrPenetrationChartYAxis,
                            marker: {
                                lineWidth: 2,
                                lineColor: Highcharts.getOptions().colors[3],
                                fillColor: 'white'
                            },
                            dataLabels: {
                                enabled: true,
                                format: '{y}%'
                            },
                            enableMouseTracking: true
                    },
                    {
                        type: 'column',
                        name: 'Overall DM',
                        data: $scope.arrDMChartYAxis
                    },
                    {
                        name: 'Overall Outage',
                        type: 'spline',
                        yAxis: 2,
                        data: $scope.arrOutageChartYAxis,
                        "lineWidth": 0,
                        "marker": {
                            "enabled": "true",
                            "states": {
                                "hover": {
                                    "enabled": "true"
                                }
                            },
                            "radius": 5,
                            lineColor:  Highcharts.getOptions().colors[4]
                        },
                        "states": {
                            "hover": {
                                "lineWidthPlus": 0
                            }
                        },
                        dataLabels: {
                            enabled: true,
                            format: '{y}'
                        },
                        enableMouseTracking: true
                    }
                   ],
                
                exporting: {
                    sourceWidth: 1200,
                    sourceHeight: 800,
                    chartOptions: {
                        chart: {
                            events: {
                                load: function () {
                                    Highcharts.each(this.series, function (series) {
                                        series.update({
                                            dataLabels: {
                                                style: {
                                                    fontSize: '11px'
                                                }  
                                            } 
                                        }, false);

                                        series.xAxis.update({
                                            labels: {
                                                style: {
                                                    fontSize: '11px'
                                                }
                                            }
                                        });
                                        series.yAxis.update({
                                            labels: {
                                                style: {
                                                    fontSize: '11px'
                                                }
                                            },
                                            title: {
                                                style: {
                                                    fontSize: '11px'
                                                }
                                            }
                                        });
                                    });
                                    this.redraw(false);
                                }
                            }
                        },   
                        legend:{
                            enabled:true,
                            itemStyle: {
                                  fontSize: '11px'
                            }
                        }
                    }
                },
                responsive: {
                    rules: [{
                        condition: {
                            maxWidth: 500
                        },
                        chartOptions: {
                            legend: {
                                align: 'center',
                                verticalAlign: 'bottom',
                                layout: 'horizontal',
                                useHTML: true
                            },
                            yAxis: {
                                labels: {
                                    align: 'left',
                                    x: 0,
                                    y: -5
                                },
                                title: {
                                    text: null
                                }
                            },
                            subtitle: {
                                text: null
                            },
                            credits: {
                                enabled: false
                            }
                        }
                    }]
                }
            });
            
            if ($.fn.DataTable.isDataTable( '#topSitesTable' ) ) {
                $("#topSitesTable").dataTable().api().clear().draw();
                $("#topSitesTable").dataTable().api().destroy();
                $('#topSitesTable').empty(); 
            }
            
            $("#topSitesTable").append('<tfoot><tr style="background: #B6B7BC;color: #000000;font-weight: bold;"><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center">Grand Total</th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th><th style="text-align:center"></th></tr></tfoot>');
            $scope.titleArray = [
             { data:"region", title:"Region", width: "9%"},
             { data:"country", title:"Country", width: "9%"},
             {
                title:"Site",
                width: "19%",
                mRender: function (data, type, row) {
                    return '<a class="table-site" data-id="' + row.site + '" style="cursor: pointer;text-decoration: underline;">' + row.site + '</a>';
                }
             },
             { data:"ibo_curr", title:"Sum of Total Site IBO", width: "9%"},
             { data:"ibo_overall", title:"Overall IBO<br/>"+$scope.arrTableHeading.overall_ibo_date_range, width: "9%"},
             { data:"overall_orders", title:"Overall Orders<br/>"+$scope.arrTableHeading.orders_date_range, width: "9%"},
             { data:"overall_penetration", title:"Overall Penetration<br/>"+$scope.arrTableHeading.orders_date_range, width: "9%"},
             { data:"oppty_count", title:"Oppty Count<br/>"+$scope.arrTableHeading.dm_date_range, width: "9%"},
             { data:"oppty_sum", title:"Oppty Sum<br/>"+$scope.arrTableHeading.dm_date_range, width: "9%"},
             { data:"outage_count", title:"Outage Count<br/>"+$scope.arrTableHeading.outage_date_range, width: "9%"},
             { data:"event_status_confirmed", title:"Confirmed Outage Percentage<br/>"+$scope.arrTableHeading.outage_date_range, width: "9%"}
             
         ];
            
         dataTable = $("#topSitesTable").DataTable({ 
                data:$scope.arrTopSitesTableData,
                "bInfo" : false,
                "bPaginate": false, 
                "bFilter":false,
                "retrieve": true,
                "order":[],
                "aoColumnDefs": [
                    { "sClass": "header_class", "aTargets": [ 0 ] },
                    {
                        "render": function ( data, type, row ) {
                            if(data !== "") {
                                if (data !== "No Orders") {
                                    return '$' + Math.round(data) + 'K';
                                } else {
                                    return data;
                                }
                            } else {
                                return '';
                            }
                        },
                        "aTargets": [ 3 ]
                    },
                    {
                        "render": function ( data, type, row ) {
                            if(data !== "") {
                                if (data !== "No Orders") {
                                    return '$' + Math.round(data/1000)+ 'K';
                                } else {
                                    return data;
                                }
                            } else {
                                return '';
                            }
                        },
                        "aTargets": [ 4 ]
                    },
                    {
                        "render": function ( data, type, row ) {
                            if(data !== "") {
                                if (data !== "No Orders") {
                                    return '$' + Math.round(data/1000)+ 'K';
                                } else {
                                    return data;
                                }
                            } else {
                                return '';
                            }
                        },
                        "aTargets": [ 5 ]
                    },
                    {
                        "render": function ( data, type, row ) {
                            if(data !== "") {
                                if (data !== "No Orders") {
                                    return parseFloat(data).toFixed(2) + '%';
                                } else {
                                    return data;
                                }
                            } else {
                                return '';
                            }
                        },
                        "aTargets": [ 6 ]
                    },
                    {
                        "render": function ( data, type, row ) {
                            if( data ) {
                                if (data !== "No Orders") {
                                    return parseInt(data);
                                } else {
                                    return data;
                                }
                            } else {
                                return 0;
                            }
                        },
                        "aTargets": [ 7 ]
                    },
                    {
                        "render": function ( data, type, row ) {
                            if( data ) {
                                if (data !== "No Orders") {
                                    return '$' + Math.round(data/1000)+ 'K';
                                } else {
                                    return data;
                                }
                            } else {
                                return parseInt(0);
                            }
                        },
                        "aTargets": [ 8 ]
                    },
                    {
                        "render": function ( data, type, row ) {
                            if( data ) {
                                if (data !== "No Orders") {
                                    return parseInt(data);
                                } else {
                                    return data;
                                }
                            } else {
                                return 0;
                            }
                        },
                        "aTargets": [ 9 ]
                    },
                    {
                        "render": function ( data, type, row ) {
                            if( data ) {
                                if (data !== "No Orders") {
                                    return parseFloat(data).toFixed(2) + '%';
                                } else {
                                    return data;
                                }
                            } else {
                                return 0;
                            }
                        },
                        "aTargets": [ 10 ]
                    }
                ],
                "columns":$scope.titleArray, 
                "footerCallback": function ( row, data, start, end, display ) {
                    var api = this.api();

                    var intVal = function ( i ) {
                        return typeof i === 'string' ?
                            i.replace(/[\$,]/g, '')*1 :
                            typeof i === 'number' ?
                                i : 0;
                    };

                    var sumOfTotalSiteIBO = api
                        .column( 3 )
                        .data()
                        .reduce( function (a, b) {
                            a =  Math.round(a, 10);
                            if(isNaN(a)){ a = 0; }                   

                            b = Math.round(b, 10);
                            if(isNaN(b)){ b = 0; }

                            return intVal(a) + intVal(b);
                        }, 0 );


                        $( api.column( 3 ).footer() ).html(
                            '$' +sumOfTotalSiteIBO+ 'K'
                        );

                    var overAllIBOYears = api
                        .column( 4 )
                        .data()
                        .reduce( function (a, b) {
                        	a = Math.round(a, 10);
                        	if(isNaN(a)){ a = 0; }                   
                        	b = Math.round(b/1000, 10);
                        	if(isNaN(b)){ b = 0; }

                        	return intVal(a) + intVal(b);
                        }, 0 );

                    $( api.column( 4 ).footer() ).html(
                    		'$' + overAllIBOYears+ 'K'
                    );
                     
                    var overAllOrdersYears = api
                        .column( 5 )
                        .data()
                        .reduce( function (a, b) {
                            a =  Math.round(a, 10);
                            if(isNaN(a)){ a = 0; }                   

                            b =  Math.round(b/1000, 10);
                            if(isNaN(b)){ b = 0; }

                            return intVal(a) + intVal(b);
                        }, 0 );

                     $( api.column( 5 ).footer() ).html(
                        '$' + overAllOrdersYears+ 'K'
                     );

                    var overAllPenetration = api
                        .column( 6 )
                        .data()
                        .reduce( function (a, b) {
                            return (overAllOrdersYears / overAllIBOYears) * 100;
                        }, 0 );

                     $( api.column( 6 ).footer() ).html(
                        overAllPenetration.toFixed(2) + '%'
                     );
                    
                    var opptyCount = api
                        .column( 7 )
                        .data()
                        .reduce( function (a, b) {
                            a = parseFloat(a, 10);
                            if(isNaN(a)){ a = 0; }                   

                            b = parseFloat(b, 10);
                            if(isNaN(b)){ b = 0; }

                            return intVal(a) + intVal(b);
                        }, 0 );

                     $( api.column( 7 ).footer() ).html(opptyCount);
                    
                    var opptySum = api
                        .column( 8 )
                        .data()
                        .reduce( function (a, b) {
                            a =  Math.round(a, 10);
                            if(isNaN(a)){ a = 0; }                   

                            b =  Math.round(b/1000, 10);
                            if(isNaN(b)){ b = 0; }

                            return intVal(a) + intVal(b);
                        }, 0 );

                     $( api.column( 8 ).footer() ).html(
                        '$' + opptySum+ 'K'
                     );
                    
                    var outageCount = api
                        .column( 9 )
                        .data()
                        .reduce( function (a, b) {
                            a = parseFloat(a, 10);
                            if(isNaN(a)){ a = 0; }                   

                            b = parseFloat(b, 10);
                            if(isNaN(b)){ b = 0; }

                            return intVal(a) + intVal(b);
                        }, 0 );

                     $( api.column( 9 ).footer() ).html(outageCount);
                     
                     var countOutage = 0
                     var outageConfirmedPercentage = api
                     .column( 10 )
                     .data()
                     .reduce( function (a, b) {
                         a = parseFloat(a, 10);
                         if(isNaN(a)){ a = 0; }                   

                         b = parseFloat(b, 10);
                         if(isNaN(b)){ b = 0; }
                         
                         countOutage=countOutage+1
                         return intVal(a) + intVal(b);
                     }, 0 );

                  $( api.column( 10 ).footer() ).html((outageConfirmedPercentage/countOutage).toFixed(2)+ '%');
                }
           });
	    
	       $('body #topSitesTable tbody').on( 'click', 'a.table-site', function () { 
                var data = dataTable.row($(this).parents('tr')).data();
                
                $rootScope.safeApply(function(){
                    
                    var min_range = $scope.arrTableHeading.overall_ibo_date_range.replace(/\(|\)/g, "").split(" to ");
                    var max_range = $scope.arrTableHeading.outage_date_range.replace(/\(|\)/g, "").split(" to ");

                    var arrMinRange  = min_range[0].slice(0,-1).split("-");
                    var arrMaxRange  = max_range[1].slice(0,-1).split("-");
                    
                    var getFirstDate = getFirstQuarterDate(arrMinRange[0], arrMinRange[1]);
                    var getLastDate  = getLastQuarterDate(arrMaxRange[0], arrMaxRange[1]);
                    
                    var beginDate    = moment(getFirstDate);
                    var endDate      = moment(getLastDate);
                    
                    var amount       = Math.floor(endDate.diff(beginDate, 'months') / 3) + 1;
                    var minYear      = parseInt(arrMaxRange[0]);
                    var quarterStart = parseInt(arrMaxRange[1]);
                    
                    var arrMinMaxRange = [];
                    for (var i = 0; i < amount; i++) {
                        arrMinMaxRange.push(minYear + '-' + quarterStart)

                        quarterStart--;
                        if (quarterStart <= 0) {
                            minYear--;
                            quarterStart = 4;
                        };
                    };
                    
                    if (typeof(Storage) !== "undefined") {
                        // Code for localStorage/sessionStorage.
                        localStorage.setItem("siteFilterCode", data.site);
                        localStorage.setItem("regionFilterCode", data.region);
                        localStorage.setItem("countryFilterCode", data.country);
                        localStorage.setItem("yearQuarterFilterCode", JSON.stringify(arrMinMaxRange));
                        localStorage.setItem("tier3FilterCode", "Opex");
                     } else {
                        // Sorry! No Web Storage support..
                     }
                });
                
                var url = $state.href('CombinedAnalysis', {}, {absolute:true});
                $window.open(url,'_blank');
            });
             
        }
        
        $scope.exportChartTopSites = function (){
            topSitesChart.exportChart({type: 'image/jpeg', filename: 'Top-Sites'}, {subtitle: {text:''}});
        };
        
        
        $scope.excelDownloadTopSites = function() {
            var tableToExcel = (function() {
                var uri = 'data:application/vnd.ms-excel;base64,'
                , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
                          , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
                          , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
                   return function(table) {
                   if (!table.nodeType)
                          table = document.getElementById('topSitesTable');
                       
                   var excelContent = '';
                   var header = "<tr><td colspan='10' style='text-align:center'>" +
                                 "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center'>Fleet Mining System</span>"+
                                 "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
                       
                   var columns = ["REGION", "COUNTRY", "SITE", "SUM OF TOTAL SITE IBO ($K)", "OVERALL IBO<br/>"+$scope.arrTableHeading.orders_date_range+"($K)", "OVERALL ORDERS<br/>"+$scope.arrTableHeading.orders_date_range+"($K)", "OVERALL PENETATION<br/>"+$scope.arrTableHeading.orders_date_range+"(%)", "OPPTY COUNT<br/>"+$scope.arrTableHeading.dm_date_range, "OPPTY SUM<br/>"+$scope.arrTableHeading.dm_date_range+"($K)", "OUTAGE COUNT<br/>"+$scope.arrTableHeading.outage_date_range, "CONFIRMED OUTAGE PERCENTAGE<br/>"+$scope.arrTableHeading.outage_date_range+"(%)"];
                       
                   excelContent = excelContent + header + '<tr><td colspan="10" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
                       
                   var getDataFromDT  = $('#topSitesTable').dataTable().api().rows( { filter: "applied" } ).data().toArray();
                   var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
                       
                   excelContent = excelContent + '<tr> <td colspan="10" style="text-align:center; font-size: 15px">Top IBO Customers Penetration</td> </tr>';
                   excelContent = excelContent + '<tr>';
                   _.forEach(columns, function(column) {
                        excelContent = excelContent + th + column + '</th>';
                   });
                       
                   excelContent = excelContent + '</tr>';
                    
                   _.forEach(getDataFromDT, function(row){
                        excelContent = excelContent + '<tr>';
                        _.forEach(row, function(rowData, rowKey){
                            if((/^\-?\d+((\.|\,)\d+)?$/).test(rowData)) {
                                if(rowKey === "ibo_curr") {
                                    excelContent = excelContent + '<td style="text-align:center;">' + Math.round(rowData) + '</td>'; 
                                } else if((rowKey === "ibo_overall") || (rowKey === "overall_orders") || (rowKey === "oppty_sum")){
                                    excelContent = excelContent + '<td style="text-align:center;">' + Math.round(rowData/1000) + '</td>'; 
                                } else if(rowKey === "oppty_count") {
                                    excelContent = excelContent + '<td style="text-align:center;">' + parseInt(rowData) + '</td>'; 
                                } else {
                                    excelContent = excelContent + '<td style="text-align:center;">' + parseFloat(rowData).toFixed(2) + '</td>';    
                                }
                            } else {
                                excelContent = excelContent + '<td style="text-align:center;">' + rowData + '</td>';
                            }
                        });
                        excelContent = excelContent + '</tr>';
                   });
                   excelContent = excelContent + '<tr>' + $("#topSitesTable tfoot").find('tr').eq(0).html().replace(/[$%K]/gi, '') + '</tr>';

                   var ctx = {worksheet: 'Top Sites' , table: excelContent};
                   document.getElementById('excelAnchorTopSites').href = (uri + base64(format(template, ctx)));
                   document.getElementById('excelAnchorTopSites').download = 'Top-Sites.xls';
                }
            })();
            tableToExcel('topSitesTable');
        };

        $scope.getTopSiteCountries = function() {
        	var item = {};
        	$('#topSitesCountrySearch').val("");
            $('#topSitesRegionSearch').removeClass('boxShadow');
            var siteSelectedRegionvalue = $("select.dependentFilter[id='topSitesRegionSearch']").val();
            item["region"] = siteSelectedRegionvalue;
            item["state"] = 'site';
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            if(siteSelectedRegionvalue!==null && siteSelectedRegionvalue!=='Select Region') {
                countryLevelDataNetworkService.getAllMetricsCountrySiteDropdown(JSON.stringify(item)).then(function(response) {
                    $scope.siteCountryDropdownBean = response;
                    $timeout(function(){	
                        $('.topSiteErrorIndicator').hide(100);
                        $('button#placeTopSitesMultiSelect').hide(100);
                        $('#topSitesCountrySearch').show(100);
                    })
                });
            } else {
                $('select.dependentFilter[id="topSitesCountrySearch"]').prop('disabled','true');
                $('select.dependentFilter[id="topSitesCountrySearch"]').siblings().children().addClass('disabled');
                $timeout(function(){
                    $scope.regionSelected = true;
                });
            }
        };
        $scope.getTopSiteServiceManagers = function() {
        	var item = {};
        	
        	$('#topSitesServiceManagerSearch').val("");
            $('#topSitesRegionSearch').removeClass('boxShadow');
            
            var siteSelectedRegionvalue = $("select.dependentFilter[id='topSitesRegionSearch']").val();
            var siteSelectedCountryvalue = $("select.dependentFilter[id='topSitesCountrySearch']").val();
            
            item["region"] = siteSelectedRegionvalue;
            item["country"] = siteSelectedCountryvalue;
            item["managerType"] = 'serviceManagers';
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            item["accountManager"] = "";
            if(siteSelectedRegionvalue!==null && siteSelectedRegionvalue!=='Select Region') {
            	if(siteSelectedCountryvalue === 'Select Country'){
            		item["country"] = "";
            	}
            	RevenueDataNetworkService.getManagersForTopSites(JSON.stringify(item)).then(function(response) {
                    $scope.siteServiceManagerDropdownBean = response.serviceManagerDropdown;
                    $timeout(function(){	
                        $('.topSiteErrorIndicator').hide(100);
                        $('button#placeSerMngrMultiSelect').hide(100);
                        
                       $("select.singleSelectSM").multipleSelect({
                            filter: true,
                            single: true
                        });
                    })
                });
            } else {
                $('select.dependentFilter[id="topSitesServiceManagerSearch"]').prop('disabled','true');
                $('select.dependentFilter[id="topSitesServiceManagerSearch"]').siblings().children().addClass('disabled');
                $timeout(function(){
                    $scope.regionSelected = true;
                });
            }
        };
        
        $scope.getTopSiteAccountManagers = function() {
        	var item = {};
        	
        	$('#topSitesAccountManagerSearch').val("");
            $('#topSitesRegionSearch').removeClass('boxShadow');
            
            var siteSelectedRegionvalue = $("select.dependentFilter[id='topSitesRegionSearch']").val();
            var siteSelectedCountryvalue = $("select.dependentFilter[id='topSitesCountrySearch']").val();
            
            item["region"] = siteSelectedRegionvalue;
            item["country"] = siteSelectedCountryvalue;
            item["managerType"] = 'accountManagers';
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            item["accountManager"] = "";
            if(siteSelectedRegionvalue!==null && siteSelectedRegionvalue!=='Select Region') {
            	if(siteSelectedCountryvalue === 'Select Country'){
            		item["country"] = "";
            	}
            	RevenueDataNetworkService.getManagersForTopSites(JSON.stringify(item)).then(function(response) {
                    $scope.siteAccountManagerDropdownBean = response.accountManagerDropdown;
                    $timeout(function(){	
                        $('.topSiteErrorIndicator').hide(100);
                        $('button#placeAccMngrMultiSelect').hide(100);
                        
                        $("select.singleSelectAM").multipleSelect({
                            filter: true,
                            single: true
                        });
                    })
                });
            } else {
                $('select.dependentFilter[id="topSitesAccountManagerSearch"]').prop('disabled','true');
                $('select.dependentFilter[id="topSitesAccountManagerSearch"]').siblings().children().addClass('disabled');
                $timeout(function(){
                    $scope.regionSelected = true;
                });
            }
        };
        
        $('#topSitesRegionSearch').off().on('change', function() {
    		$('#topSitesCountrySearch').prop("disabled", false);
			$scope.getTopSiteCountries();
			$('#topSitesAccountManagerSearch').val("");
			$('#topSitesServiceManagerSearch').val("");
			$('div.singleSelectAM').hide();
        	$('div.singleSelectSM').hide();
        	$('button#placeSerMngrMultiSelect').show();
        	$('button#placeAccMngrMultiSelect').show();
        	$('#topSitesServiceManagerSearch').removeClass("managerBoxShadow");
        	$('#topSitesAccountManagerSearch').removeClass("managerBoxShadow");
			$scope.getManagers();
		});
        $('#topSitesCountrySearch').off().on('change', function() {
			$('#topSitesAccountManagerSearch').val("");
			$('#topSitesServiceManagerSearch').val("");
			$('div.singleSelectAM').hide();
        	$('div.singleSelectSM').hide();
        	$('button#placeSerMngrMultiSelect').show();
        	$('button#placeAccMngrMultiSelect').show();
        	$('#topSitesServiceManagerSearch').removeClass("managerBoxShadow");
        	$('#topSitesAccountManagerSearch').removeClass("managerBoxShadow");
			$scope.getManagers();
        });
        $scope.getManagers = function() {
        	 $('#placeSerMngrMultiSelect').off().on("click", function(){
        		 var siteSelectedRegionvalue = $("select.dependentFilter[id='topSitesRegionSearch']").val();
        		 if(siteSelectedRegionvalue!==null && siteSelectedRegionvalue!=='Select Region') {
	                	$scope.getTopSiteServiceManagers();
	                	$('#topSitesAccountManagerSearch').val("");
	                	$('button#placeSerMngrMultiSelect').hide();
	                	$('div.singleSelectAM').hide();
	                	$('div.singleSelectSM').show();
	                	$('button#placeAccMngrMultiSelect').show();
	                	$('#topSitesAccountManagerSearch').removeClass("managerBoxShadow");
	                	$('#topSitesServiceManagerSearch').addClass("managerBoxShadow");
        		 }
         	});
        	 $('#placeAccMngrMultiSelect').off().on("click", function(){
        		 var siteSelectedRegionvalue = $("select.dependentFilter[id='topSitesRegionSearch']").val();
        		 if(siteSelectedRegionvalue!==null && siteSelectedRegionvalue!=='Select Region') {
        			$scope.getTopSiteAccountManagers();
            		$('#topSitesServiceManagerSearch').val("");
            		$('button#placeAccMngrMultiSelect').hide();
            		$('div.singleSelectSM').hide();
            		$('div.singleSelectAM').show();
                	$('button#placeSerMngrMultiSelect').show();
                	$('#topSitesServiceManagerSearch').removeClass("managerBoxShadow");
    				$('#topSitesAccountManagerSearch').addClass("managerBoxShadow");
        		 }
          	});
        }
        
        $scope.topSitesClearData = function(){
    		$('#topSitesRegionSearch').val("");
			$('#topSitesCountrySearch').val("");
			
			_.defer(function(){
				$('input[name="Manager"]').removeAttr('checked');
				$('div.filterSelect').hide(100);
			    $('#topSitesCountrySearch').hide(100);
				$('button#placeTopSitesMultiSelect').show(100);
			    $('#topSitesServiceManagerSearch').hide(100);
			    $('select#topSitesServiceManagerSearch').hide(100);
				$('button#placeSerMngrMultiSelect').show(100);
				$('button#placeAccMngrMultiSelect').show(100);
			});
			$('#topSitesServiceManagerSearch').removeClass("managerBoxShadow");
        	$('#topSitesAccountManagerSearch').removeClass("managerBoxShadow");
			$('#topSitesRegionSearch').removeClass("boxShadow");
			$('.topSiteErrorIndicator').hide(100);	
			loaderOps(false);
    	}
        
    }]);
});