
define(['angular','../../sample-module','jquery'], function (angular,controllers,jquery) 
 {
    'use strict';
    controllers.controller('OrderMetricsController', ['CreateHighChartService','$scope','$rootScope','OrderMetricsService','NewMetricTechService','CustomerChartService','OrderChartService','OrderCustomerService','NetworkCallService','$state','$timeout',
	function (CreateHighChartService,$scope,$rootScope,OrderMetricsService,NewMetricTechService,CustomerChartService,OrderChartService,OrderCustomerService,NetworkCallService,$state,$timeout){
		$('order-metrics').find('#order_technoRegion').click(function(){
			$state.go('order/technoRegion');
		});
		$('order-metrics').find('#order_topCustomerChart1').click(function(){
			$state.go('order/topCustomer');
		});
        
        $timeout(function() {
            if (!$rootScope.accountManager && !$rootScope.marketIndustry) {
                $rootScope.orderMetricsSearchData();
            }
        }, 5000);
        
        $rootScope.orderMetricsSearchData = function() {
            var item = {};
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
            
            NetworkCallService.getOrderMetricsDashboardData(JSON.stringify(item)).then(function(response){
                    var order_techRegionChartData = (OrderChartService.updateTechReg(response.technologyDataBean));
                    $('#order_technoRegion,#order_topCustomerChart1').outerHeight($('.iboChart').height());
                    CreateHighChartService.createColumnChart(order_techRegionChartData['technology'],order_techRegionChartData['regionWithCount'],'order_technoRegion',order_techRegionChartData['colorCodes'],'order/technoRegion');
                    var order_totalcountNum=(order_techRegionChartData['totalcount']).toFixed(0);
                    $scope.order_totalcount=numberWithCommas(order_totalcountNum);
                    var orderCustData=(OrderCustomerService.getCustomerData(response.custNameDataBean));
                    var order_totalCustomerCountNum =(orderCustData['totalCustomerCount']).toFixed(0);
                    $scope.order_totalCustomerCount=numberWithCommas(order_totalCustomerCountNum);
                    CreateHighChartService.createChart(orderCustData['customers'],orderCustData['chartData'],'order_topCustomerChart1','order/topCustomer');
                });
        }
   }]);
});