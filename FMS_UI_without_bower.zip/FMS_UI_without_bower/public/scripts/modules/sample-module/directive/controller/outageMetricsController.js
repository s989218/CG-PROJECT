
define(['angular','../../sample-module','jquery'], function (angular,controllers,jquery) 
 {
    'use strict';
    controllers.controller('outageMetricsController', ['CreateHighChartService','$scope','$rootScope','OutageMetricsService','NewMetricTechService','CustomerChartService','OutageChartService','OutageCustomerService','$state','$timeout',function(CreateHighChartService,$scope,$rootScope,OutageMetricsService,NewMetricTechService,CustomerChartService,OutageChartService,OutageCustomerService,$state,$timeout){
		$('outage-metrics').find('#outage_technoRegion').click(function(){
			$state.go('outage/technoRegion');
		});
        
		$('outage-metrics').find('#outage_topCustomerChart1').click(function(){
			$state.go('outage/topCustomer');
		});
        
        $timeout(function() {
            if (!$rootScope.accountManager && !$rootScope.marketIndustry) {
                $rootScope.outageMetricsSearchData();
            }
        }, 5000);
        
        $rootScope.outageMetricsSearchData = function() {
            var item = {};
            item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
            item["marketIndustry"] = "";
            OutageMetricsService.getOutageMetricsData(JSON.stringify(item)).then(function(response){
                var outage_techRegionChartData = (OutageChartService.updateTechReg(response.technologyDetails));
                $('#outage_technoRegion,#outage_topCustomerChart1').outerHeight($('.iboChart').height());
                CreateHighChartService.createOutageColumnChart(outage_techRegionChartData['technology'],outage_techRegionChartData['regionWithCount'],'outage_technoRegion',outage_techRegionChartData['colorCode'],'outage/technoRegion');
                var outage_totalcountNum=(outage_techRegionChartData['totalcount']).toFixed(0);
                $scope.outage_totalcount=numberWithCommas(outage_totalcountNum);
                var outageCustData=(OutageCustomerService.getCustomerData(response.topCustomer));
                var outage_totalCustomerCountNum = (outageCustData['totalCustomerCount']).toFixed(0);
                $scope.outage_totalCustomerCount =numberWithCommas(outage_totalCustomerCountNum);
                CreateHighChartService.createOutageChart(outageCustData['customers'],outageCustData['chartData'],'outage_topCustomerChart1','outage/topCustomer');
            }); 
        }
   }]);
});