
define(['angular','../../sample-module','jquery'], function (angular,controllers,jquery) 
 {
    'use strict';
    controllers.controller('serviceReqMetricsController', ['CreateHighChartService','$scope','$rootScope','ServiceReqMetricsService','NewMetricTechService','CustomerChartService','serviceReqChartService','ServiceReqCustomerService','$state',
	function (CreateHighChartService,$scope,$rootScope,ServiceReqMetricsService,NewMetricTechService,CustomerChartService,serviceReqChartService,ServiceReqCustomerService,$state){
		$('service-metrics').find('#serviceReq_technoRegion').click(function(){
			$state.go('serviceReq/technology');
		});
		$('service-metrics').find('#serviceReq_topCustomerChart1').click(function(){
			$state.go('serviceReq/topCustomer');
		});
		ServiceReqMetricsService.getServiceRequestMetricsData().then(function(response){
				var serviceReq_techRegionChartData = (serviceReqChartService.updateTechReg(response.ServiceRequestTechMetricsData));
				$('#serviceReq_technoRegion,#serviceReq_topCustomerChart1').outerHeight($('.iboChart').height());
				CreateHighChartService.createServiceReqColumnChart(serviceReq_techRegionChartData['technology'],serviceReq_techRegionChartData['regionWithCount'],'serviceReq_technoRegion',serviceReq_techRegionChartData['colorCode'],'serviceReq/technology');
				var serviceReq_totalcount_totalcountNum=(serviceReq_techRegionChartData['totalcount']).toFixed(0);
				$scope.serviceReq_totalcount=numberWithCommas(serviceReq_totalcount_totalcountNum);
				var serviceReqCustData=(ServiceReqCustomerService.getCustomerData(response.ServiceRequestCustMetricsData));
			    var serviceReq_totalCustomerCountNum = (serviceReqCustData['totalCustomerCount']).toFixed(0);
				$scope.serviceReq_totalCustomerCount =numberWithCommas(serviceReq_totalCustomerCountNum);
				CreateHighChartService.createServiceReqChart(serviceReqCustData['customers'],serviceReqCustData['chartData'],'serviceReq_topCustomerChart1','serviceReq/topCustomer');
			});
		/*var currentQuarter = Math.ceil(( new Date().getMonth() + 1) / 3 );		
		var currentYear =new Date().getFullYear();		
		$rootScope.currentYearQuarter=currentQuarter+'Q-'+currentYear;
		sessionStorage.currentYearQuarter=currentQuarter+'Q-'+currentYear;*/
       }]);
});




