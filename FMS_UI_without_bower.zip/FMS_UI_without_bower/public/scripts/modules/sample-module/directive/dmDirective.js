define(['angular', '../sample-module','multiselectdrpdwn'], function(angular, sampleModule,multiselectdrpdwn) {
	'use strict';



	sampleModule.directive('dmMetrics', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/dmData/dmMetrics.html',
			controller: 'dmMetricsController'
		};
	}]);
	sampleModule.directive('dmSearch', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/dmData/dmSearch.html',
			controller: 'DrilldownPageCtrl'
		};
	}]);
	sampleModule.directive('regionLevel', [ function() {
		return { 
			restrict: 'E',
			templateUrl: 'views/directive-html/dmData/regionLevel.html'
		};
	}]);
	sampleModule.directive('countryLevel', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/dmData/countryLevel.html'
		};
	}]);
	sampleModule.directive('dmIndependentFilter', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/dmData/dmRegionFilterDirective.html'
		};
	}]);
	sampleModule.directive('dmDependentFilter', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/dmData/dmCountryFilterDirective.html'
		};
	}]);
	return sampleModule;
});
