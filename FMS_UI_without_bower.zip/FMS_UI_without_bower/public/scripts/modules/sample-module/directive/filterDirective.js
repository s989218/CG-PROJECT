define(['angular', '../sample-module','multiselectdrpdwn'], function(angular, sampleModule,multiselectdrpdwn) {
	'use strict';



	sampleModule.directive('dependentFilter', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/filterDirective.html'
		};
	}]);
	sampleModule.directive('errorMessage', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/errorMessage.html'
		};
	}]);
	sampleModule.directive('ibMetric', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/ibMetric.html',
			controller: 'IBMetricsController'
		};
	}]);
	sampleModule.directive('independentFilter', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/standardFiliterCard.html'
		};
	}]);
	sampleModule.directive('onFinishRender', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                element.ready(function () {
                    setTimeout(function(){
						$("select#depSiteCustCountrySearch").multipleSelect({filter: true});
						},400);
                });
				}
			}
		}
	});

	return sampleModule;
});
