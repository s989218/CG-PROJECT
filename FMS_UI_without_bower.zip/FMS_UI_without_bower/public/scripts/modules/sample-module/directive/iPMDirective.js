define(['angular', '../sample-module','multiselectdrpdwn'], function(angular, sampleModule,multiselectdrpdwn) {
	'use strict';


	sampleModule.directive('selectionPanel', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/selection.html',
			controller: 'selectionController'
		};
	}]);
	
	sampleModule.directive('keyDeals', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/keyDeals.html',
			controller: 'keyDealsController'
		};
	}]);
    
    sampleModule.directive('risksScreen', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/risks.html',
			controller: 'risksController'
		};
	}]);
	
    
    sampleModule.directive('oppsScreen', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/opps.html',
			controller: 'oppsController'
		};
	}]);
	
    
    sampleModule.directive('bobyRegion', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/BObyRegion.html',
			controller: 'BObyRegionController'
		};
	}]);
	
    
    sampleModule.directive('bobyBusiness', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/BObyBusiness.html',
			controller: 'BObyBusinessController'
		};
	}]);
	
	sampleModule.directive('dataentryScreen', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/dataEntry.html',
			controller: 'dataEntryController'
		};
	}]);
    sampleModule.directive('pctxScreen', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/projectCtrlTx.html',
			controller: 'projectTXController'
		};
	}]);
    sampleModule.directive('pccsScreen', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/projectCtrlCs.html',
			controller: 'projectCSController'
		};
	}]);
    sampleModule.directive('pcinstScreen', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/projectCtrlInst.html',
			controller: 'projectINSTController'
		};
	}]);
	
    sampleModule.directive('prctxScreen', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/productCtrlTx.html',
			controller: 'productTXController'
		};
	}]);
    
    sampleModule.directive('prccsScreen', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/productCtrlCs.html',
			controller: 'productCSController'
		};
	}]);
        sampleModule.directive('prcinstScreen', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/productCtrlInst.html',
			controller: 'productINSTController'
		};
	}]);
    sampleModule.directive('wbfScreen', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/walkByFinance.html',
			controller: 'walkByFinanceController'
		};
	}]);
    sampleModule.directive('pmtrendScreen', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/iPM/pmoCtrlTrend.html',
			controller: 'pmoTrendController'
		};
	}]);
	return sampleModule;
});
