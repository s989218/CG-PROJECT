define(['angular', '../sample-module','multiselectdrpdwn'], function(angular, sampleModule,multiselectdrpdwn) {
	'use strict';



	sampleModule.directive('iboMetrics', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/ibo/iboMetrics.html',
			controller: 'IBOMetricsController'
		};
	}]);
	sampleModule.directive('iboSearch', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/ibo/iboSearch.html',
			controller: 'DrilldownPageCtrl'
		};
	}]);
	sampleModule.directive('regionLevel', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/ibo/regionLevel.html'
		};
	}]);
	sampleModule.directive('countryLevel', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/ibo/countryLevel.html'
		};
	}]);
	return sampleModule;
});
