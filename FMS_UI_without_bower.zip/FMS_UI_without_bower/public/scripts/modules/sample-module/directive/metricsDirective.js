define(['angular', '../sample-module'], function(angular, sampleModule) {
	'use strict';
    
    sampleModule.directive('dashboardMetrics', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/metrics/dashboardMetrics.html',
			controller: 'dashboardMetricsController'
		};
	}]);
    
    sampleModule.directive('topSites', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/metrics/topSites.html',
			controller: 'topSitesController'
		};
	}]);
    
    sampleModule.directive('regionMetrics', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/metrics/regionMetrics.html',
			controller: 'regionlevelMetricsController'
		};
	}]);

	sampleModule.directive('countryMetrics', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/metrics/countryMetrics.html',
			controller: 'countrylevelMetricsController'
		};
	}]);
	
	sampleModule.directive('technologyMetrics', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/metrics/technologyMetrics.html',
			controller: 'countrylevelMetricsController'
		};
	}]);
	
	
	sampleModule.directive('siteMetrics', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/metrics/siteMetrics.html',
			controller: 'countrylevelMetricsController'
		};
	}]);
	
	sampleModule.directive('gedunsMetrics', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/metrics/geDunsMetrics.html',
			controller: 'countrylevelMetricsController'
		};
	}]);
	
	sampleModule.directive('segmentMetrics', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/metrics/segmentMetrics.html',
			controller: 'countrylevelMetricsController'
		};
	}]);
	
	return sampleModule;
});
