define(['angular', '../sample-module','multiselectdrpdwn'], function(angular, sampleModule,multiselectdrpdwn) {
	'use strict';



	sampleModule.directive('orderMetrics', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/orders/orderMetrics.html',
			controller: 'OrderMetricsController'
		};
	}]);
	sampleModule.directive('orderSearchPage', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/orders/orderSearchPage.html',
			controller: 'DrilldownPageCtrl'
		};
	}]);
	sampleModule.directive('orderIndependentFilter', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/orders/orderStandardFiliterCard.html'
		};
	}]);
	sampleModule.directive('orderDependentFilter', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/orders/orderFilterDirective.html'
		};
	}]);
	return sampleModule;
});
