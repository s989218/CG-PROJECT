define(['angular', '../sample-module','multiselectdrpdwn'], function(angular, sampleModule,multiselectdrpdwn) {
	'use strict';



	sampleModule.directive('outageMetrics', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/Outage/outageMetrics.html',
			controller: 'outageMetricsController'
		};
	}]);
	sampleModule.directive('outageSearch', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/Outage/outageSearch.html',
			controller: 'DrilldownPageCtrl'
		};
	}]);
	sampleModule.directive('regionLevel', [ function() {
		return { 
			restrict: 'E',
			templateUrl: 'views/directive-html/Outage/regionLevel.html'
		};
	}]);
	sampleModule.directive('countryLevel', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/Outage/countryLevel.html'
		};
	}]);
	sampleModule.directive('outageIndependentFilter', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/Outage/outageRegionFilterDirective.html'
		};
	}]);
	sampleModule.directive('outageDependentFilter', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/Outage/outageCountryFilterDirective.html'
		};
	}]);
	return sampleModule;
});
