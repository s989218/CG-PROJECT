define(['angular', '../sample-module','multiselectdrpdwn'], function(angular, sampleModule,multiselectdrpdwn) {
	'use strict';



	sampleModule.directive('serviceMetrics', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/serviceReqData/serviceMetrics.html',
			controller: 'serviceReqMetricsController'
		};
	}]);
	sampleModule.directive('serviceSearch', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/serviceReqData/serviceReqSearch.html',
			controller: 'DrilldownPageCtrl'
		};
	}]);
	sampleModule.directive('regionLevel', [ function() {
		return { 
			restrict: 'E',
			templateUrl: 'views/directive-html/serviceReqData/regionLevel.html'
		};
	}]);
	sampleModule.directive('countryLevel', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/Outage/countryLevel.html'
		};
	}]);
	sampleModule.directive('serviceIndependentFilter', [ function() {
		return {
			restrict: 'E',
			templateUrl: 'views/directive-html/serviceReqData/serviceReqRegionFilterDirective.html'
		};
	}]);
	return sampleModule;
});
