define([
	'./sample-module', 
	/* Controllers */
	'./controllers/dashboard-controller',
	'./controllers/installedBase',
	'./controllers/Maintenance',
	'./controllers/IBASData',
	'./controllers/Metrics',
	'./controllers/TechnoRegion',
	'./controllers/NewMetrics',
	'./controllers/topCustomer',
	'./controllers/techRegionCtrl',
	'./controllers/IPMParts',
	'./controllers/orders',
	/* IBO Controller */
	'./controllers/IBOController/customerCtrl',
	'./controllers/IBOController/techRegionCtrl',
	/* Order Controller */
	'./controllers/OrderController/customerCtrl',
	'./controllers/OrderController/techRegionCtrl',
	/* DM Controller */
	'./controllers/DMController/customerCtrl',
	'./controllers/DMController/techRegionCtrl',
	'./controllers/DMController/dealMachinesDataCtrl',
	/* Outage Controller */
	'./controllers/OutageController/customerCtrl',
	'./controllers/OutageController/techRegionCtrl',
	'./controllers/OutageController/outageDataCtrl',
	/*Serviec request Controller*/
	'./controllers/ServiceReqController/customerCtrl',
	'./controllers/ServiceReqController/techRegionCtrl',
	'./controllers/ServiceReqController/serviceReqDataCtrl',
	'./controllers/CombinedAnalysis/combinedAnalysisCtrl',
	/*User Manual Controller*/
	'./controllers/UserManual/userManualCtrl',
	/* IPM Controller */
	'./controllers/IPM/IPMMainCtrl',
    './directive/controller/iPM/keyDealsCtrl', 
    './directive/controller/iPM/risksCtrl',
    './directive/controller/iPM/oppsCtrl', 
    './directive/controller/iPM/selectionCtrl',
    './directive/controller/iPM/BObyBusinessCtrl',
    './directive/controller/iPM/BObyRegionCtrl',
    './directive/controller/iPM/dataEntryCtrl',
    './directive/controller/iPM/projectCtrlTx',
    './directive/controller/iPM/projectCtrlCs',
    './directive/controller/iPM/projectCtrlInst',
    './directive/controller/iPM/productCtrlTx',
    './directive/controller/iPM/productCtrlCs',
    './directive/controller/iPM/productCtrlInst',
    './directive/controller/iPM/walkByFinanceCtrl',
    './directive/controller/iPM/pmoCtrlTrend',
    /* VariablesTable Controller */
//  './controllers/VariablesTable',
    './controllers/Users',
    './controllers/Roles',
    './controllers/Documents',
	/* Services */
	'./services/main_service',
	/* Directives */
	'./directive/filterDirective',
	'./directive/iboDirective',
	'./directive/orderDirective',
	'./directive/dmDirective',
	'./directive/outageDirective',
	'./directive/serviceReqDirective',
	'./directive/fileUploadDirective',
	'./directive/iPMDirective',
	'./directive/combinedanalysisDirective',
	'./directive/metricsDirective',
    /* Directive Controllers */
	'./directive/controller/filterDepCtrl',
    './directive/controller/iboMetricController',
	'./directive/controller/drilldownpageController',
	'./directive/controller/orderMetricController',
	'./directive/controller/dmMetricsController',
	'./directive/controller/outageMetricsController',
	'./directive/controller/serviceMetricsController',
	'./directive/controller/ibMetricController',
	'./directive/controller/metrics/countrylevelMetricsController',
    './directive/controller/metrics/regionlevelMetricsController',
    './directive/controller/metrics/dashboardMetricsController',
    './directive/controller/metrics/topSitesController'
	], function() {

});
