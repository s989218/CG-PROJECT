define(['angular', '../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('AdminDataNetworkService', ['$q','$http',function($q, $http) {
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
				method: request.method,
				data: request.data,
				url: request.url,
				headers: request.headers,
			}).then(function (response) {
				deferred.resolve(response.data);
			}, function (status, error) {
				console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
				deferred.reject(error);
			});
			return deferred.promise;
		};
		return {
			/* Network Call */
			getAllUsersData: function(){
				var request = {
						'contentType':"application/json",
						'method': 'GET',
						'url': 'connect/fms/getUserManagementDetails',						
				};
				return networkCall(request);
			},
			returnUsersDataObjects: function(response){

				var userDataObj = {};
				userDataObj['UserDetails'] = response.UserDetails;

				return userDataObj;
			},
			manageUsersData : function(jsonData) {
				var request = {
						"dataType"    : "json",
						"method"      : "POST",
						"contentType" : "application/json",
						"data"        : jsonData,
						"url"         : "connect/fms/manageUsers"
				};
				return networkCall(request);
			},
			getAllRolesData: function(){
				var request = {
						'contentType':"application/json",
						'method': 'GET',
						'url': 'connect/fms/getUserManagementDetails',
				};
				return networkCall(request);
			},
			returnRolesDataObjects: function(response){

				var roleDataObj = {};
				roleDataObj['RoleDetails'] = response.RoleDetails;

				return roleDataObj;
			},
			manageRolesData : function(jsonData) {
				var request = {
						"dataType"    : "json",
						"method"      : "POST",
						"contentType" : "application/json",
						"data"        : jsonData,
						"url"         : "connect/fms/manageRoles"
				};
				return networkCall(request);
			},
			getUserDetailsBasedOnRoleData: function(roleId){
				var request = {
						'contentType':"application/json",
						'method': 'GET',
						'url': 'connect/fms/getUserDetailsBasedOnRole/'+roleId,
				};
				return networkCall(request);
			},
			returnUserDetailsDataObjects: function(response){

				var userDetailsDataObj = {};
				userDetailsDataObj['userDetailsBasedOnRole'] = response.userDetailsBasedOnRole;

				return userDetailsDataObj;
			},
			/*User Manual services*/
			getAllDocuments : function(jsonData) {
				var request = {
						"dataType"    : "json",
						"method"      : "POST",
						"contentType" : "application/json",
						"data"        : jsonData,
						"url"         : "connect/fms/getAllDocuments"
				};
				return networkCall(request);
			},
			downloadDocuments : function(jsonData) {
				var request = {
						"dataType"    : "json",
						"method"      : "POST",
						"contentType" : "application/json",
						"data"        : jsonData,
						"url"         : "connect/fms/downloadDocuments"
				};
				return networkCall(request);
			},
            getAllUserRolesData: function(jsonData){
				var request = {
						'contentType':"application/json",
						"method"      : "POST",
						"data"        : jsonData,
						'url': 'connect/fms/getAllRoles',						
				};
				return networkCall(request);
			},
            deleteDocumentsData : function(jsonData) {
				var request = {
						"dataType"    : "json",
						"method"      : "POST",
						"contentType" : "application/json",
						"data"        : jsonData,
						"url"         : "connect/fms/deleteDocument",
				};
				return networkCall(request);
			}
		};
	}]);
});