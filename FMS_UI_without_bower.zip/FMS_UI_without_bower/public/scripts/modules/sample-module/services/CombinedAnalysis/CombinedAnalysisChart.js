define(['angular', '../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('CombinedAnalysisChartService', [function() {
		var chart;
		return {
			createChart: function(chartData)
			{
				
				chart= new Highcharts.Chart({
					  chart: {
				            type: 'column',
				            renderTo:'container2'
				        },
				        title: {
				            text: 'Combined Analysis'
				        },
				        subtitle: {
				            text: ''
				        },
				        xAxis: {
				            type: 'category',
				             title: {
				                text: 'Metrics'
				            }
				        },
				        yAxis: {
				            title: {
				                text: 'Total'
				            }

				        },
				        legend: {
				            enabled: false
				        },
				        plotOptions: {
				            series: {
				                borderWidth: 0,
				                dataLabels: {
				                    enabled: true,
				                    format: '{point.unit}{point.yDisplay}{point.dividend}'
				                }
				            }
				        },

				        tooltip: {
				            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
				            pointFormat: '<span style="color:{point.color}">{point.name} {point.yearQuarter}</span>: <b>{point.unit}{point.yDisplay}{point.dividend}</b><br/>'
				        },
				        credits: {
							 enabled: false
						},
				        series: [{
				            name: 'Metrics',
				            colorByPoint: true,
				            data:chartData
				        }],
	                    responsive: {
	                        rules: [{
	                            condition: {
	                                maxWidth: 500
	                            },
	                            chartOptions: {
	                                legend: {
	                                    align: 'center',
	                                    verticalAlign: 'bottom',
	                                    layout: 'horizontal'
	                                },
	                                yAxis: {
	                                    labels: {
	                                        align: 'left',
	                                        x: 0,
	                                        y: -5
	                                    },
	                                    title: {
	                                        text: null
	                                    }
	                                },
	                                subtitle: {
	                                    text: null
	                                },
	                                credits: {
	                                    enabled: false
	                                }
	                            }
	                        }]
	                    }
				});
				return chart;
			},
			exportChart : function(type){
				if(type === 'JPEG')
					{
					 chart.exportChart({type: 'image/jpeg', filename: 'Combined Analysis'}, {subtitle: {text:''}});
					}
					if(type === 'XLS'){
					chart.exportChart({type: 'application/vnd.ms-excel', filename: 'my-excel'}, {subtitle: {text:''}});
					}
					
					}
			
		};
	}]);
});
