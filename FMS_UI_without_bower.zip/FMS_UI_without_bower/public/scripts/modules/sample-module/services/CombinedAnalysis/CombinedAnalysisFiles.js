define([
	'./CombinedAnalysisChart'
	], function() {

});
