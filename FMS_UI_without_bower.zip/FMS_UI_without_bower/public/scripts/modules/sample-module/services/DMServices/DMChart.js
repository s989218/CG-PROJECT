define(['angular', '../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('DMChartService', [function() {
		return {
			updateTechReg: function(techRegionData){
				var createNestedObject = function( base, names, value ) {
					var lastName = arguments.length === 3 ? names.pop() : false;
					for( var i = 0; i < names.length; i++ ) {
						base = base[ names[i] ] = base[ names[i] ] || {};
					}
					if( lastName ) base = base[ lastName ] = value;
					return base;
				};
				var totalcount = 0, regionData={}, techSummary ={}, techData={};                                                                      
				var regions = [], _colorIndexes = [], technologies = [], totalCount={};
				/* All Regions and Technologies */
				_.forEach(techRegionData, function(responseObj){
					if(regions.indexOf(responseObj.dTechRegion) === -1 && responseObj.dTechRegion!==null){
						regions.push(responseObj.dTechRegion);
					}
					if(technologies.indexOf(responseObj.dTechOpptyType) === -1){
						_colorIndexes.push(responseObj.dTechColorCode);
						technologies.push(responseObj.dTechOpptyType);
					}  
				});
				var techTotalCount = {};
				_.forEach(regions, function(region){
					regionData[region] = [];
					var count = 0;
					_.forEach(technologies, function(technology){
						if(region!==null){
							(regionData[region])[count] = 0;
							count ++;
							createNestedObject(techSummary, [technology, region], 0);
							createNestedObject(totalCount, [technology], 0);
							createNestedObject(techTotalCount, [region], 0);
						}
					});
				});                           
				_.forEach(technologies, function(technology){
					techData[technology] = [];
					var count = 0;
					_.forEach(regions, function(region){
						if(region!==null){
							(techData[technology])[count] = 0;
							count ++;
						}
					});
				});           
				_.forEach(techRegionData, function(responseObj){
					if(responseObj.dTechRegion!==null){
						totalCount[responseObj.dTechOpptyType]=totalCount[responseObj.dTechOpptyType]+parseFloat(responseObj.dTechDmAmount);
						techTotalCount[responseObj.dTechRegion]=techTotalCount[responseObj.dTechRegion]+parseFloat(responseObj.dTechDmAmount);
						createNestedObject(techSummary, [responseObj.dTechOpptyType, responseObj.dTechRegion], responseObj.dTechDmAmount);
						totalcount = totalcount + parseFloat(responseObj.dTechDmAmount);
					}
				});
				totalCount = _.sortBy(_.pairs(totalCount), function (item) { return item[1]; });
				techTotalCount = _.sortBy(_.pairs(techTotalCount), function (item) { return item[1]; });
				/* Descending Sort */
				totalCount = totalCount.reverse();
				techTotalCount = techTotalCount.reverse();
				var rankArray = [];
				_.forEach(totalCount, function(tech){
					rankArray.push(tech[0]);
				});
				var techRankArray = [];
				_.forEach(techTotalCount, function(region){
					techRankArray.push(region[0]);
				});
				var tempArr=[];
				_.forEach(technologies, function(technology){
					_.forEach(techRankArray, function(region){
						((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]/1000);
					});
					tempArr.push({'data': techData[technology], 'name':technology});
				});
			
				var returnObj = {};
				returnObj['regionWithCount'] = tempArr;
				returnObj['technology'] = techRankArray;
				returnObj['region'] = techRankArray;
				returnObj['totalcount'] = totalcount/1000;
				returnObj['colorCode'] = _colorIndexes;
				return returnObj;
				
			}
		};
	}]);
});
