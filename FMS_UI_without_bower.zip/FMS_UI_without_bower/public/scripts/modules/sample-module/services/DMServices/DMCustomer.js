define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('DMCustomerService', ['$q','$http','$state','URLService',function($q, $http,$state,URLService) {
		var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
		var dataProcessing = function(regionWithCustomerCount){
					var customerCounts = {}, colorCodes ={};
					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.dcRegion!==null){
							createNestedObject(customerCounts, [region.dcRegion,customerCount.dcUserAccountName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
						if(region.dcRegion!==null){
							createNestedObject(customerCounts, [region.dcRegion,region.dcUserAccountName], (customerCounts[region.dcRegion])[region.dcUserAccountName]+parseFloat(region.dcCustomerCount));
								totalCustomerCount = totalCustomerCount + parseFloat(region.dcCustomerCount);
								colorCodes[region.dcRegion] = region.dcRegionId - 1;
							}
						});
						var chartData = [], chartObj = {}, customers = [];
						_.forEach(Object.keys(customerCounts), function(data){
								chartObj ={};
								var keys = Object.keys(customerCounts[data]);
								var customerCountsObj = customerCounts[data];
								chartObj['data'] = [];
								chartObj['name'] = data;
								chartObj['_colorIndex']=colorCodes[data];
								_.forEach(keys, function(key){
										chartObj['data'].push((customerCountsObj[key])/1000);
								});
								customers = keys;
								chartData.push(chartObj);
						});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			};
			var processCountryTable = function(customerData){
				var dataObj = {};
				var customers=[], regions=[], tableData = {}, columns = [];
				columns = [{'title':'Customer'}];
				_.forEach(customerData, function(obj){
					if(customers.indexOf(obj.geDunsName)=== -1){
						customers.push(obj.geDunsName);
					}
					if(regions.indexOf(obj.iBCustRegion)=== -1 && obj.iBCustRegion!==null){
						var colObj = {'title':obj.iBCustRegion};
						columns.push(colObj);
						regions.push(obj.iBCustRegion);
					}
				});
				var dataArr = [[]], totalCount = {}, regionCount={};
				_.forEach(customers, function(customer){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [customer, region], 0);
						createNestedObject(totalCount, [customer], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[customers.indexOf(customer)] = [];
						(dataArr[customers.indexOf(customer)])[0] = customer;
						for(var index=1; index<=regions.length; index++)
							(dataArr[customers.indexOf(customer)])[index] = 0;
					}
					});
				});
				var total = 0;
				_.forEach(customerData, function(obj){
				if(obj.iBCustRegion!==null){
					createNestedObject(tableData, [obj.geDunsName, obj.iBCustRegion], obj.iBCustAvtotSum);
					(dataArr[customers.indexOf(obj.geDunsName)])[regions.indexOf(obj.iBCustRegion)+1] = parseFloat(obj.iBCustAvtotSum);
					createNestedObject(regionCount, [obj.iBCustRegion], regionCount[obj.iBCustRegion]+parseFloat(obj.iBCustAvtotSum));
					total = total + parseFloat(obj.iBCustAvtotSum);
					totalCount[obj.geDunsName]=totalCount[obj.geDunsName]+parseFloat(obj.iBCustAvtotSum);
				}
				});
				columns.push({'title':'Grand Total'});
				regionCount['Grand Total']=total;
				_.forEach(customers, function(customer){					
					(dataArr[customers.indexOf(customer)])[(dataArr[customers.indexOf(customer)]).length] = totalCount[customer];
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
        return {
			/* Network Call */
			getIBMetricsData: function(){
				var request = {
					'method': 'POST',
					'url': URLService.newMetrics.IBData,						
					};
				return networkCall(request);
			},
        	getCustomerData: function(customerNameData){
				/* Top 10 Customers */
					var regionWithCustomerCount = _.first(_.sortBy(customerNameData, function(custData){
						return parseFloat(custData.dmcCustomerCount)}).reverse(),10);
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var colorCodes ={};	
					var customerCounts = {};					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						createNestedObject(customerCounts, [region.dmcRegion,customerCount.dmcUserAccountName], 0);
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
						createNestedObject(customerCounts, [region.dmcRegion,region.dmcUserAccountName], (customerCounts[region.dmcRegion])[region.dmcUserAccountName]+parseFloat(region.dmcCustomerCount));
						totalCustomerCount = totalCustomerCount + parseFloat(region.dmcCustomerCount);
						colorCodes[region.dmcRegion] = region.dmcRegionId - 1;
					});
					var chartData = [], chartObj = {}, colorIndex = 0, customers = [];
					_.forEach(Object.keys(customerCounts), function(data){
							chartObj ={};
							var keys = Object.keys(customerCounts[data]);
							var customerCountsObj = customerCounts[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							chartObj['_colorIndex']= colorCodes[data];
							colorIndex++;
							_.forEach(keys, function(key){
									chartObj['data'].push((customerCountsObj[key])/1000);
							});
							customers = keys;
							chartData.push(chartObj);
					});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount/1000;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			},
			processCustomerData: function(customerData){
					var regionWithCustomerCount = _.first(_.sortBy(customerData, function(custData){
						return parseFloat(custData.dcCustomerCount)}).reverse(),10);
					return dataProcessing(regionWithCustomerCount);
			},
			processAllCustomerData: function(customerData){
					var regionWithCustomerCount = _.sortBy(customerData, function(custData){
						return parseFloat(custData.dmcCustomerCount)});
					return dataProcessing(regionWithCustomerCount);
			},
			customerCountryTableData: function(customerData){
				return processCountryTable(customerData);
			}
        };
    }]);
});
