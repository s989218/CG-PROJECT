define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('DMTableService', ['$q','$http','$state','URLService',function($q, $http,$state,URLService) {
		var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
		var countryDataProcess = function(regionWithCustomerCount){
					var customerCounts = {}, colorCodes ={};
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.dcCountry!=null){
							createNestedObject(customerCounts, [region.dcCountry,customerCount.dcUserAccountName], 0);
						}
						});
					});
					var totalCustomerCount = 0, count =0;
					_.forEach(regionWithCustomerCount, function(region){
						if(region.dcCountry!=null){
							createNestedObject(customerCounts, [region.dcCountry,region.dcUserAccountName], (customerCounts[region.dcCountry])[region.dcUserAccountName]+Math.round(region.dcCustomerCount));
								totalCustomerCount = totalCustomerCount + Math.round(region.dcCustomerCount);
								if(!colorCodes[region.dcCountry])
								{
									colorCodes[region.dcCountry] = count;
									count++;
								}
						}
						});
						var chartData = [], chartObj = {}, customers = [];
						_.forEach(Object.keys(customerCounts), function(data){
								chartObj ={};
								var keys = Object.keys(customerCounts[data]);
								var customerCountsObj = customerCounts[data];
								chartObj['data'] = [];
								chartObj['name'] = data;
								_.forEach(keys, function(key){
										chartObj['data'].push(customerCountsObj[key]/1000);
								});
								customers = keys;
								chartData.push(chartObj);
						});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			};
		var dataProcessing = function(regionWithCustomerCount){
					var customerCounts = {}, colorCodes ={};
					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.region!==null){
							createNestedObject(customerCounts, [region.region,customerCount.userAccountName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
						if(region.region!==null){
							createNestedObject(customerCounts, [region.region,region.userAccountName], (customerCounts[region.region])[region.userAccountName]+Math.round(region.customerCount));
								totalCustomerCount = totalCustomerCount + Math.round(region.customerCount);
								colorCodes[region.region] = region.regionId - 1;
							}
						});
						var chartData = [], chartObj = {}, customers = [];
						_.forEach(Object.keys(customerCounts), function(data){
								chartObj ={};
								var keys = Object.keys(customerCounts[data]);
								var customerCountsObj = customerCounts[data];
								chartObj['data'] = [];
								chartObj['name'] = data;
								chartObj['_colorIndex']=colorCodes[data];
								_.forEach(keys, function(key){
										chartObj['data'].push(customerCountsObj[key]);
								});
								customers = keys;
								chartData.push(chartObj);
						});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			};
			//IBO top customer country Level
			var processCountryTable = function(customerData){
				var dataObj = {};
				var customers=[], regions=[], tableData = {}, columns = [];
				columns = [{'title':'Customer'}];
				_.forEach(customerData, function(obj){
					if(customers.indexOf(obj.dcUserAccountName)=== -1){
						customers.push(obj.dcUserAccountName);
					}
					if(regions.indexOf(obj.dcCountry)=== -1 && obj.dcCountry!==null){
						var colObj = {'title':obj.dcCountry};
						columns.push(colObj);
						regions.push(obj.dcCountry);
					}
				});
				var dataArr = [[]], totalCount = {}, regionCount={};
				_.forEach(customers, function(customer){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [customer, region], 0);
						createNestedObject(totalCount, [customer], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[customers.indexOf(customer)] = [];
						(dataArr[customers.indexOf(customer)])[0] = customer;
						for(var index=1; index<=regions.length; index++)
							(dataArr[customers.indexOf(customer)])[index] = 0;
					}
					});
				});
				var total = 0;
				_.forEach(customerData, function(obj){
				if(obj.dcCountry!==null){
					createNestedObject(tableData, [obj.dcUserAccountName, obj.dcCountry], obj.dcCustomerCount);
					var dmCustAvtotSumNum = Math.round(obj.dcCustomerCount/1000);
					(dataArr[customers.indexOf(obj.dcUserAccountName)])[regions.indexOf(obj.dcCountry)+1] = numberWithCommas(Math.round(dmCustAvtotSumNum));
					createNestedObject(regionCount, [obj.dcCountry], regionCount[obj.dcCountry]+Math.round(obj.dcCustomerCount/1000));
					total = total + Math.round(obj.dcCustomerCount/1000);
					totalCount[obj.dcUserAccountName]=totalCount[obj.dcUserAccountName]+Math.round(obj.dcCustomerCount/1000);
				}
				});
				columns.push({'title':'Grand Total'});
				regionCount['Grand Total']=total;
				_.forEach(customers, function(customer){					
					(dataArr[customers.indexOf(customer)])[(dataArr[customers.indexOf(customer)]).length] = numberWithCommas(Math.round(totalCount[customer]));
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
			//DM top customer Region Level
			var processTable = function(customerData){
				var dataObj = {};
				var customers=[], regions=[], tableData = {}, columns = [];
				columns = [{'title':'Customer'}];
				_.forEach(customerData, function(obj){
					if(customers.indexOf(obj.dcUserAccountName)=== -1){
						customers.push(obj.dcUserAccountName);
					}
					if(regions.indexOf(obj.dcRegion)=== -1 && obj.dcRegion!==null){					
						var colObj = {'title':obj.dcRegion};
						columns.push(colObj);
						regions.push(obj.dcRegion);
					}
				});
				var dataArr = [[]], totalCount ={}, regionCount={};
				_.forEach(customers, function(customer){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [customer, region],0);
						createNestedObject(totalCount, [customer], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[customers.indexOf(customer)] = [];
						(dataArr[customers.indexOf(customer)])[0] = customer;
						for(var index=1; index<=regions.length; index++)
							(dataArr[customers.indexOf(customer)])[index] = 0;
					}
					});
				});
				var total = 0;
				_.forEach(customerData, function(obj){
					if(obj.dcRegion!==null){
						createNestedObject(tableData, [obj.dcUserAccountName, obj.dcRegion], obj.dcCustomerCount);
						createNestedObject(regionCount, [obj.dcRegion], regionCount[obj.dcRegion]+Math.round(obj.dcCustomerCount/1000));
						var dmCustAvtotSumNum=Math.round(obj.dcCustomerCount/1000);
						(dataArr[customers.indexOf(obj.dcUserAccountName)])[regions.indexOf(obj.dcRegion)+1] = numberWithCommas(Math.round(dmCustAvtotSumNum));
						totalCount[obj.dcUserAccountName]=totalCount[obj.dcUserAccountName]+Math.round(obj.dcCustomerCount/1000);
						total = total +Math.round(obj.dcCustomerCount/1000);
					}
				});
				columns.push({'title':'Grand Total'});
				regionCount['Grand Total']=total;
				_.forEach(customers, function(customer){					
					(dataArr[customers.indexOf(customer)])[(dataArr[customers.indexOf(customer)]).length] = numberWithCommas(Math.round(totalCount[customer]));
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['regionCount'] = regionCount;
				dataObj['columns'] = columns;
				return dataObj;
			};
        return {
			initTable(data,columns,id) { 
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
				if ($.fn.DataTable.isDataTable( '#'+id )) {
						$('#'+id).dataTable().fnDestroy();        
						$('#'+id).empty(); 
						 $('#'+id).append('<tfoot></tfoot>');
					}  
				dt = $('#'+id).DataTable({
					"columnDefs": [
									{
									"render": function ( data1, type, row ) {
										if(isNaN(Math.round(parseFloat(data1)))) {
											data=data1;
											return data;
										} else {
											data='$'+data1+'K';
											return data;
										}
									},
								         targets: '_all'
									}
									],
				   "order": [[ columns.length-1, "desc"]],
				   columns : columns,
                   data: data,
				   fnDrawCallback : function() {
					if(footer && data[0].length>0){
					   $('#'+id+ ' > tfoot').html('');
					   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					   _.forEach(columns, function(column){                          
							if(footer[column.title] !== undefined){
								var dataValue = Math.round(footer[column.title]);
								$('#'+id+ ' > tfoot').append('<th>$'+numberWithCommas(dataValue)+'K</th>');
							}
					   });
					}
					}
				});
				
				return dt;	
			},
			processAllCustomerData: function(customerData){
					var regionWithCustomerCount = _.sortBy(customerData, function(custData){
						return Math.round(custData.customerCount)}).reverse();
					return dataProcessing(regionWithCustomerCount);
			},
			customerTableData: function(customerData){
				return processTable(customerData);
			},
			excelDownload: function(id){
				var footer = document.getElementById(id).tFoot.innerText;
				footer=footer.split(/(\s+)/).filter( function(e) { return e.trim().length > 0; } );
			    var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 	});
				 var tableToExcel = (function() {
					 var ctx,subHeader;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
	                      if (!table.nodeType) 
	                             table = document.getElementById(id);
	                      var excelContent = '';
	                      var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                     
	                      if(id ==='DM-by-Top-Cust-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>DM Region Level</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='DM-by-Top-Cust-Country-Data')
                    	  {
	                    	  subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>DM Country Level</span>"+
	                          "</td></tr>";
                    	  }
	                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                      excelContent = excelContent + subHeader;
	                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
	                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                      var td = "<td style='width: auto; padding-right:5px; background-color:#111;color:white'>";
	                      var tdNumber = "<td style='mso-number-format:0'>";
	                      excelContent =excelContent + '<tr>';
	                      var flag = 0;
                            _.forEach(columns, function(column){
                                   if(columns[0]!== 'null' && flag === 0){
                                          excelContent = excelContent + th + column + '</th>';
                                          flag++;
                                   }else {
                                          excelContent = excelContent + th + column +'($K)' + '</th>';
                                   }
                            });
                            excelContent = excelContent + '</tr>';
                            _.forEach(getDataFromDT, function(row){

                                   excelContent =excelContent + '<tr>';
                                   _.forEach(row, function(rowData){
                                          if(isNaN(Math.round(rowData)))
                                          {
                                                 if((/^[0-9]{0,}$/).test(rowData))
                                                       excelContent = excelContent + tdNumber + rowData + '</td>';

                                                 else
                                                       excelContent = excelContent + '<td>' + ''+rowData + '</td>';

                                          }
                                          else
                                          {
                                                 if((/^[0-9]{0,}$/).test(rowData))
                                                       excelContent = excelContent + tdNumber + rowData + '</td>';
                                                 else
                                                       excelContent = excelContent + '<td>' +rowData + '</td>';
                                          }
                                   });
                                   excelContent =excelContent + '</tr>';
                            });
                            excelContent =excelContent + '<tr>';
                            _.forEach(footer, function(row){
                                   row = row.replace(/K/g, "");
                                   if (row.includes('$')){
                                          row = row.substring(1,row.length);
                                   }
                                    excelContent = excelContent + td + row + '</td>';
                                
                            });
	                      excelContent =excelContent + '</tr>';
	                      if(id === 'DM-by-Top-Cust-Country-Data')
	                      {
	                    	   ctx = {worksheet:'Techno Region Data Country' , table: excelContent};
		                      document.getElementById('dmTechnoRegionCountry').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('dmTechnoRegionCountry').download = 'DM_Country.xls';
	                     }
	                      if(id ==='DM-by-Top-Cust-Data'){
	                    	  ctx = {worksheet: 'Techno Region Data' , table: excelContent};
		                      document.getElementById('dmTechnoRegion').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('dmTechnoRegion').download = 'DM.xls';
	                      }
	                }
	                })();
	                tableToExcel(id);
				return null;
			},
			customerCountryTableData: function(customerData){
				return processCountryTable(customerData);
			},
			topCustomerTableData: function(customerData){
				var regionWithCustomerCount = _.first(_.sortBy(customerData, function(custData){
						return Math.round(custData.dcCustomerCount)}).reverse(),10);
				return processTable(regionWithCustomerCount);
			},
			countryDataProcessing: function(customerData){
				var regionWithCustomerCount = _.sortBy(customerData, function(custData){
						return Math.round(custData.dcCustomerCount)}).reverse();
				return countryDataProcess(regionWithCustomerCount);
			}
        };
    }]);
});
