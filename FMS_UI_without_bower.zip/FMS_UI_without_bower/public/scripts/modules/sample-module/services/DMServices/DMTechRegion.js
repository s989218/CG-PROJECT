define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('DMTechnoRegionService', ['$q','$http','$state','URLService','$rootScope',function($q, $http,$state,URLService,$rootScope) {
    	var regionDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, colorCodes ={}, totalCounts = {}, regions = [], regionData ={};
					_.forEach(regionWithTechCount, function(region){
						if(region.dmTechRegion!==null){
							regionData[region.dmTechRegion] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.dmTechRegion!==null){
							if(regions.indexOf(region.dmTechRegion)===-1)
								regions.push(region.dmTechRegion);
							createNestedObject(technologyCounts, [region.dmTechRegion,techCount.dmTechOpptyType], 0);
							createNestedObject(totalCounts, [techCount.dmTechOpptyType], 0);
						}
						});
					});
					var totalCount = 0, count;
					_.forEach(regionWithTechCount, function(region){
						createNestedObject(technologyCounts, [region.dmTechRegion,region.dmTechOpptyType], (technologyCounts[region.dmTechRegion])[region.dmTechOpptyType]+Math.round(region.dmTechDmAmount));
						totalCounts[region.dmTechOpptyType]=totalCounts[region.dmTechOpptyType]+Math.round(region.dmTechDmAmount);
						totalCount = totalCount + Math.round(region.dmTechDmAmount);
						colorCodes[region.dmTechRegion] = region.dmTechColorCode;
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							});
						});
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=
									Math.round((technologyCounts[region])[technology]); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region, '_colorIndex':colorCodes[region]});
						});
					var returnObj = {};
					returnObj['totalCount'] = totalCount;
					returnObj['technologies'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					return returnObj;
					
			};
			var countryDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, colorCodes =[], totalCounts = {}, regions = [], regionData ={}, testData = {},totalCount = {};
					_.forEach(regionWithTechCount, function(region){
						if(region.dmTechOpptyType!==null){
							regionData[region.dmTechOpptyType] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.dmTechOpptyType!==null){
							if(regions.indexOf(region.dmTechOpptyType)===-1){
								regions.push(region.dmTechOpptyType);
								colorCodes.push(region.dmTechColorCode);
							}								
							createNestedObject(technologyCounts, [region.dmTechOpptyType,techCount.dmTechCountry], 0);
							createNestedObject(testData, [techCount.dmTechCountry,region.dmTechOpptyType], -1);
							createNestedObject(testData, [techCount.dmTechCountry, '~Total'], 0);
							createNestedObject(totalCounts, [techCount.dmTechCountry], 0);
							createNestedObject(totalCount, [region.dmTechOpptyType , 'Total'] , 0);
						}
						});
					});
					
					totalCount['gTotal'] = 0;
					_.forEach(regionWithTechCount, function(region){
					
						if(region.dmTechCountry!==null){
							createNestedObject(technologyCounts, [region.dmTechOpptyType,region.dmTechCountry], (technologyCounts[region.dmTechOpptyType])[region.dmTechCountry]+Math.round(region.dmTechDmAmount));
							createNestedObject(testData, [region.dmTechCountry, region.dmTechOpptyType ] , Math.round(region.dmTechDmAmount));
							createNestedObject(testData, [region.dmTechCountry,'~Total'] , (testData[region.dmTechCountry])['~Total']+Math.round(region.dmTechDmAmount));
							createNestedObject(totalCount, [region.dmTechOpptyType , 'Total'] , (totalCount[region.dmTechOpptyType])['Total']+Math.round(region.dmTechDmAmount));
							totalCounts[region.dmTechCountry]=totalCounts[region.dmTechCountry]+Math.round(region.dmTechDmAmount);
							
							totalCount['gTotal']+=Math.round(region.dmTechDmAmount);
						}
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							var count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							}); 
						});
						var highchartData = [];
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=Math.round(((technologyCounts[region])[technology])/1000); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region});
							highchartData.push({'data': regionData[region], 'name':region});
						});
						_.forEach(testData, function(data){
								testData['regions'] = [];
								/* Sort Alphabetically */
								testData['regions'] = _.sortBy(Object.keys(data), function(o) { return o; });	
							return false;
						});
					var returnObj = {};
					returnObj['technology'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					returnObj['highchartData'] = highchartData;
					returnObj['testData'] = testData;
					returnObj['totalCount'] = totalCount;
					returnObj['colorCode'] = colorCodes;
					return returnObj;
					
			};
			//DM technology & region country level Table
			var processCountryTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Opportunity'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.dmTechOpptyType)=== -1){
						technologies.push(obj.dmTechOpptyType);
					}
					if(regions.indexOf(obj.dmTechCountry)=== -1 && obj.dmTechCountry !==null){
						var colObj = {'title':obj.dmTechCountry};
						columns.push(colObj);
						regions.push(obj.dmTechCountry);
					}
				});
				var dataArr = [[]], totalCount={}, regionCount= {};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
						if(!(region===null)){
							createNestedObject(tableData, [technology, region],0);
							createNestedObject(totalCount, [technology], 0);
							createNestedObject(regionCount, [region], 0);
							dataArr[technologies.indexOf(technology)] = [];
							(dataArr[technologies.indexOf(technology)])[0] = technology;
							for(var index=1; index<=regions.length; index++)
								(dataArr[technologies.indexOf(technology)])[index] = 0;
						}
					});					
				});		
				regionCount['Grand Total']=0;
				_.forEach(technologyData, function(obj){
					if(!(obj.dmTechCountry===null)){
						createNestedObject(tableData, [obj.dmTechOpptyType, obj.dmTechCountry], obj.dmTechDmAmount);
						var dmTechAvtotSumNum =Math.round(obj.dmTechDmAmount/1000);
						(dataArr[technologies.indexOf(obj.dmTechOpptyType)])[regions.indexOf(obj.dmTechCountry)+1] = numberWithCommas(Math.round(dmTechAvtotSumNum));
						totalCount[obj.dmTechOpptyType]=totalCount[obj.dmTechOpptyType]+Math.round(obj.dmTechDmAmount/1000);
						regionCount[obj.dmTechCountry]=regionCount[obj.dmTechCountry]+Math.round(obj.dmTechDmAmount/1000);
						regionCount['Grand Total'] = regionCount['Grand Total'] +Math.round(obj.dmTechDmAmount/1000);
					}
				});
              
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){					
					(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = numberWithCommas(Math.round(totalCount[technology]));
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['regionCount'] = regionCount;
				dataObj['columns'] = columns;
				return dataObj;
			};
			//DM technology & region Region level Table
			var processTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Opportunity'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.dmTechOpptyType)=== -1){
						technologies.push(obj.dmTechOpptyType);
					}
					if(regions.indexOf(obj.dmTechRegion)=== -1 && obj.dmTechRegion!==null){
						var colObj = {'title':obj.dmTechRegion};
						columns.push(colObj);
						regions.push(obj.dmTechRegion);
					}
				});

				var dataArr = [[]], totalCount={}, regionCount={};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [technology, region], 0);
						createNestedObject(totalCount, [technology], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[technologies.indexOf(technology)] = [];
						(dataArr[technologies.indexOf(technology)])[0] = technology;
						for(var index=1; index<=regions.length; index++)
							(dataArr[technologies.indexOf(technology)])[index] = 0;
					}
					});					
				});
				regionCount['Grand Total']=0;
				_.forEach(technologyData, function(obj){
				if(obj.dmTechRegion!==null){
					createNestedObject(tableData, [obj.dmTechOpptyType, obj.dmTechRegion], obj.dmTechDmAmount);
					var dmTechAvtotSumNum =Math.round(obj.dmTechDmAmount/1000);
					(dataArr[technologies.indexOf(obj.dmTechOpptyType)])[regions.indexOf(obj.dmTechRegion)+1] = numberWithCommas(Math.round(dmTechAvtotSumNum));
					totalCount[obj.dmTechOpptyType]=totalCount[obj.dmTechOpptyType]+Math.round(obj.dmTechDmAmount/1000);
					regionCount[obj.dmTechRegion]=regionCount[obj.dmTechRegion]+Math.round(obj.dmTechDmAmount/1000);
					regionCount['Grand Total'] = regionCount['Grand Total'] +Math.round(obj.dmTechDmAmount/1000);
				}
				});
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){
					(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = numberWithCommas(Math.round(totalCount[technology]));
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
        return {
			searchDataService: function(){
				var jsonData = [];
				var item = {};
				item["primaryRegion"] = "";
				item["primaryCountry"]="";
				item["forecastCategory"]= "";
				item["businessTier3"]="";
				item["cQtr"]="";
				item["accountName"]="";
				item["riskPath"]="";
				item["accountType"]="";
				item["accountClass"]="";
				item["year"]="";
				item["quarter"]="";
				item["opptyExternalId"]="";
				item["businessSegment"]=$rootScope.businessSegment;
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
				jsonData.push(item);
				return jsonData;
			},
			getRegionWithCount: function(techRegionData){	
					return regionDataProcess(techRegionData)['chartData']
			},
			processedData: function(techRegionData){	
					return regionDataProcess(techRegionData);
			},
			countryDataProcess: function(techRegionData){	
					return countryDataProcess(techRegionData);
			},
			processTable: function(technologyData){
				return processTable(technologyData);
			},
			processCountryTable: function(technologyData){
				return processCountryTable(technologyData);
			},
			initTable(data,columns,id) { 
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
				if ($.fn.DataTable.isDataTable( '#'+id )) {
						$('#'+id).dataTable().fnDestroy();        
						$('#'+id).empty(); 
						 $('#'+id).append('<tfoot></tfoot>');
					}  
				dt = $('#'+id).DataTable({
				   "order": [[ columns.length-1, "desc" ]],
				   columns : columns,
                   data: data,
				   "pageLength": 10,
				   fnDrawCallback : function() {
					if(footer && data[0].length>0){
					   $('#'+id+ ' > tfoot').html('');
					   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					   _.forEach(columns, function(column){
							if(footer[column.title]){
								$('#'+id+ ' > tfoot').append('<th>'+footer[column.title]+'</th>');
							}
					   });
					}
					}
				});
				return dt;				
			},
			getTechnologyData: function(technologyDropdown,regionDropdown,regionWithCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var testData = {}, countryCount = {}, totalCount = {}, technology= [], techTotal = {};
					_.forEach(regionWithCount, function(reg){
						_.forEach(regionDropdown, function(tech){
						createNestedObject(testData, [reg.name,tech.dmTechOpptyType], -1);
						createNestedObject(testData, [reg.name,'~Total'], 0);
						createNestedObject(techTotal, [reg.name], 0);
						createNestedObject(totalCount, [tech.dmTechOpptyType , 'Total'] , 0);
						createNestedObject(countryCount, [tech.dmTechOpptyType , reg.name] , 0);
					});
					});
					var colorCodes = [];
					totalCount['gTotal'] = 0;
					_.forEach(regionDropdown, function(respData){
						var tempObject = {};
						tempObject[respData.dmTechOpptyType]= respData.dmTechDmAmount ;
						createNestedObject(testData, [respData.dmTechRegion, respData.dmTechOpptyType ] , Math.round(respData.dmTechDmAmount));
						createNestedObject(countryCount, [respData.dmTechOpptyType , respData.dmTechRegion] , Math.round(respData.dmTechDmAmount));
						createNestedObject(totalCount, [respData.dmTechOpptyType , 'Total'] , (totalCount[respData.dmTechOpptyType])['Total']+Math.round(respData.dmTechDmAmount));
						createNestedObject(testData, [respData.dmTechRegion,'~Total'] , (testData[respData.dmTechRegion])['~Total']+Math.round(respData.dmTechDmAmount));
						createNestedObject(techTotal, [respData.dmTechRegion] , (techTotal[respData.dmTechRegion])+Math.round(respData.dmTechDmAmount));
						totalCount['gTotal']+=Math.round(respData.dmTechDmAmount);
						if(colorCodes.indexOf(respData.dmTechColorCode)===-1)
							colorCodes.push(respData.dmTechColorCode);
						});
					techTotal = _.sortBy(_.pairs(techTotal), function (item) { return item[1]; });
					/* Descending Sort */
					techTotal = techTotal.reverse();
					var rankArray = [];
					_.forEach(techTotal, function(tech){
						rankArray.push(tech[0]);
					});
					_.forEach(testData, function(data){
							testData['regions'] = [];
							/* Sort Alphabetically */
							testData['regions'] = _.sortBy(Object.keys(data), function(o) { return o; });	
						return false;
					});

					var chartData = [], chartObj = {};
					_.forEach(Object.keys(countryCount), function(data){
							chartObj ={};
							var countryCountObj = countryCount[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							_.forEach(rankArray, function(key){
									chartObj['data'].push((countryCountObj[key])/1000);
							});
							chartData.push(chartObj);
							technology = rankArray;
					});
					var returnObj = {};
					returnObj['testData'] = testData;
					returnObj['countryCount'] = countryCount;
					returnObj['chartData'] = chartData;
					returnObj['totalCount'] = totalCount;
					returnObj['technology'] = technology;
					returnObj['colorCode'] = colorCodes;
					return returnObj;
			},
        	getCustomerData: function(customerNameData){
				/* Top 10 Customers */
					var regionWithCustomerCount = _.first(_.sortBy(customerNameData, function(custData){
						return Math.round(custData.iBTechAvtotSum)}).reverse(),10);
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var customerCounts = {}, colorCodes ={};					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.iBTchRegion!==null){
							createNestedObject(customerCounts, [region.iBTchRegion,customerCount.custName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
					if(region.iBTchRegion!==null){	
						createNestedObject(customerCounts, [region.iBTchRegion,region.custName], (customerCounts[region.iBTchRegion])[region.custName]+Math.round(region.iBTechAvtotSum));
						totalCustomerCount = totalCustomerCount + Math.round(region.iBTechAvtotSum);
						colorCodes[region.iBTchRegion] = region.iBTechRegionId - 1;
					}
					});
					var chartData = [], chartObj = {}, customers = [];
					_.forEach(Object.keys(customerCounts), function(data){
							chartObj ={};
							var keys = Object.keys(customerCounts[data]);
							var customerCountsObj = customerCounts[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							chartObj['_colorIndex']=colorCodes[data];
							_.forEach(keys, function(key){
									chartObj['data'].push(customerCountsObj[key]);
							});
							customers = keys;
							chartData.push(chartObj);
					});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			},
			updateTechReg: function(techRegionData){
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var totalcount = 0,regionWithCountData=[], regionData={};					
					var regions = [], _colorIndexes = [], technologies = [], summaryData = {}, totalCount={};
					_.forEach(techRegionData, function(responseObj){
						if(regions.indexOf(responseObj.dmTechOpptyType) === -1 && responseObj.dmTechOpptyType!==null){
							regions.push(responseObj.dmTechOpptyType);
							_colorIndexes.push(responseObj.dmTechColorCode);
						}
						if(technologies.indexOf(responseObj.dmTechRegion) === -1){
							technologies.push(responseObj.dmTechRegion);
						}					
					});
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(summaryData, [region, technology], 0);
								createNestedObject(summaryData, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
							}
						});
					});		
		
					_.forEach(techRegionData, function(responseObj){
						if(responseObj.dmTechRegion!==null){
							createNestedObject(summaryData, [responseObj.dmTechOpptyType, responseObj.dmTechRegion],responseObj.dmTechDmAmount);
							totalCount[responseObj.dmTechRegion]=totalCount[responseObj.dmTechRegion]+Math.round(responseObj.dmTechDmAmount);
							totalcount = totalcount + Math.round(responseObj.dmTechDmAmount);
						}
					});
					totalCount = _.sortBy(_.pairs(totalCount), function (item) { return item[1]; });
					/* Descending Sort */
					totalCount = totalCount.reverse();
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					_.forEach(regions, function(region){
						_.forEach(rankArray, function(technology){
							((regionData[region])[rankArray.indexOf(technology)])=Math.round(((summaryData[region])[technology])/1000);
						});
						regionWithCountData.push({
							'data': regionData[region], 
							'name':region,
							});
					});
					
				var returnObj = {};
				returnObj['regionWithCount'] = regionWithCountData;
				returnObj['technology'] = rankArray;
				returnObj['totalcount'] = totalcount;
				returnObj['colorCode'] = _colorIndexes;
				return returnObj;
			}
			
        };
    }]);
});
