define([
	'./DMChart',
	'./DMCustomer',
	'./DMTable',
	'./DMMetricsService',
	'./DMTechRegion'
	], function() {

});
