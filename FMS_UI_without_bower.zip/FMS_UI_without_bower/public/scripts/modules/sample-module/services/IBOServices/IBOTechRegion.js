define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('IBOTechnoRegionService', ['$q','$http','$state','URLService','$rootScope',function($q, $http,$state,URLService,$rootScope) {
    	var regionDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, colorCodes ={}, totalCounts = {}, regions = [], regionData ={};
					_.forEach(regionWithTechCount, function(region){
						if(region.iBTchRegion!==null){
							regionData[region.iBTchRegion] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.iBTchRegion!==null){
							if(regions.indexOf(region.iBTchRegion)===-1)
								regions.push(region.iBTchRegion);
							createNestedObject(technologyCounts, [region.iBTchRegion,techCount.iBTechnologyDes], 0);
							createNestedObject(totalCounts, [techCount.iBTechnologyDes], 0);
						}
						});
					});
					var totalCount = 0, count;
					_.forEach(regionWithTechCount, function(region){
						createNestedObject(technologyCounts, [region.iBTchRegion,region.iBTechnologyDes], (technologyCounts[region.iBTchRegion])[region.iBTechnologyDes]+Math.round(region.iBTechAvtotSum));
						totalCounts[region.iBTechnologyDes]=totalCounts[region.iBTechnologyDes]+Math.round(region.iBTechAvtotSum);
						totalCount = totalCount + Math.round(region.iBTechAvtotSum);
						colorCodes[region.iBTchRegion] = Math.round(region.iBTechRegionId);
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							});
						});
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=
									Math.round((technologyCounts[region])[technology]); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region, '_colorIndex':colorCodes[region]});
						});
					var returnObj = {};
					returnObj['totalCount'] = totalCount;
					returnObj['technologies'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					return returnObj;
			};
			var countryDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, colorCodes =[], totalCounts = {}, regions = [], regionData ={}, testData = {},totalCount = {};
					_.forEach(regionWithTechCount, function(region){
						if(region.iBTechnologyDes!==null){
							regionData[region.iBTechnologyDes] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.iBTechnologyDes!==null){
							if(regions.indexOf(region.iBTechnologyDes)===-1){
								regions.push(region.iBTechnologyDes);
								colorCodes.push(region.iBColorCode);
							}								
							createNestedObject(technologyCounts, [region.iBTechnologyDes,techCount.iBTechCountry], 0);
							createNestedObject(testData, [techCount.iBTechCountry,region.iBTechnologyDes], -1);
							createNestedObject(testData, [techCount.iBTechCountry, '~Total'], 0);
							createNestedObject(totalCounts, [techCount.iBTechCountry], 0);
							createNestedObject(totalCount, [region.iBTechnologyDes , 'Total'] , 0);
						}
						});
					});
					
					totalCount['gTotal'] = 0;
					_.forEach(regionWithTechCount, function(region){
					
						if(region.iBTechCountry!==null){
							createNestedObject(technologyCounts, [region.iBTechnologyDes,region.iBTechCountry], (technologyCounts[region.iBTechnologyDes])[region.iBTechCountry]+Math.round(region.iBTechAvtotSum));
							createNestedObject(testData, [region.iBTechCountry, region.iBTechnologyDes ] , Math.round(region.iBTechAvtotSum));
							createNestedObject(testData, [region.iBTechCountry,'~Total'] , (testData[region.iBTechCountry])['~Total']+Math.round(region.iBTechAvtotSum));
							createNestedObject(totalCount, [region.iBTechnologyDes , 'Total'] , (totalCount[region.iBTechnologyDes])['Total']+Math.round(region.iBTechAvtotSum));
							totalCounts[region.iBTechCountry]=totalCounts[region.iBTechCountry]+Math.round(region.iBTechAvtotSum);
							
							totalCount['gTotal']+=Math.round(region.iBTechAvtotSum);
						}
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							var count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							}); 
						});
						var highchartData = [];
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=Math.round((technologyCounts[region])[technology]); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region});
							highchartData.push({'data': regionData[region], 'name':region});
						});
						_.forEach(testData, function(data){
								testData['regions'] = [];
								/* Sort Alphabetically */
								testData['regions'] = _.sortBy(Object.keys(data), function(o) { return o; });	
							return false;
						});
					var returnObj = {};
					returnObj['technology'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					returnObj['highchartData'] = highchartData;
					returnObj['testData'] = testData;
					returnObj['totalCount'] = totalCount;
					returnObj['colorCode'] = colorCodes;
					return returnObj;
					
			};
			//IBO technology & region country level Table
			var processCountryTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Technology'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.iBTechnologyDes)=== -1){
						technologies.push(obj.iBTechnologyDes);
					}
					if(regions.indexOf(obj.iBTechCountry)=== -1 && obj.iBTechCountry !==null){
						var colObj = {'title':obj.iBTechCountry};
						columns.push(colObj);
						regions.push(obj.iBTechCountry);
					}
				});
				var dataArr = [[]], totalCount={}, regionCount= {};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
						if(!(region===null)){
							createNestedObject(tableData, [technology, region], 0);
							createNestedObject(totalCount, [technology], 0);
							createNestedObject(regionCount, [region], 0);
							dataArr[technologies.indexOf(technology)] = [];
							(dataArr[technologies.indexOf(technology)])[0] = technology;
							for(var index=1; index<=regions.length; index++)
								(dataArr[technologies.indexOf(technology)])[index] = 0;
						}
					});					
				});		
				regionCount['Grand Total']=0;
				_.forEach(technologyData, function(obj){
					if(!(obj.iBTechCountry===null)){
						createNestedObject(tableData, [obj.iBTechnologyDes, obj.iBTechCountry], obj.iBTechAvtotSum);
						var iBTechAvtotSumNum =Math.round(obj.iBTechAvtotSum);
						(dataArr[technologies.indexOf(obj.iBTechnologyDes)])[regions.indexOf(obj.iBTechCountry)+1] = numberWithCommas(Math.round(iBTechAvtotSumNum));
						totalCount[obj.iBTechnologyDes]=totalCount[obj.iBTechnologyDes]+Math.round(obj.iBTechAvtotSum);
						regionCount[obj.iBTechCountry]=regionCount[obj.iBTechCountry]+Math.round(obj.iBTechAvtotSum);
						regionCount['Grand Total'] = regionCount['Grand Total'] +Math.round(obj.iBTechAvtotSum);
					}
				});
              
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){					
					(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = numberWithCommas(Math.round(totalCount[technology]));
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['regionCount'] = regionCount;
				dataObj['columns'] = columns;
				return dataObj;
			};
			//IBO technology & region Region level Table
			var processTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Technology'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.iBTechnologyDes)=== -1){
						technologies.push(obj.iBTechnologyDes);
					}
					if(regions.indexOf(obj.iBTchRegion)=== -1 && obj.iBTchRegion!==null){
						var colObj = {'title':obj.iBTchRegion};
						columns.push(colObj);
						regions.push(obj.iBTchRegion);
					}
				});
				var dataArr = [[]], totalCount={}, regionCount={};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [technology, region],0);
						createNestedObject(totalCount, [technology], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[technologies.indexOf(technology)] = [];
						(dataArr[technologies.indexOf(technology)])[0] = technology;
						for(var index=1; index<=regions.length; index++)
							(dataArr[technologies.indexOf(technology)])[index] = 0;
					}
					});					
				});
				regionCount['Grand Total']=0;
				_.forEach(technologyData, function(obj){
				if(obj.iBTchRegion!==null){
					createNestedObject(tableData, [obj.iBTechnologyDes, obj.iBTchRegion], obj.iBTechAvtotSum);
					 var iBTechAvtotSumNum=Math.round(obj.iBTechAvtotSum);
					(dataArr[technologies.indexOf(obj.iBTechnologyDes)])[regions.indexOf(obj.iBTchRegion)+1] =numberWithCommas(Math.round(iBTechAvtotSumNum));
					totalCount[obj.iBTechnologyDes]=totalCount[obj.iBTechnologyDes]+Math.round(obj.iBTechAvtotSum);
					regionCount[obj.iBTchRegion]=regionCount[obj.iBTchRegion]+Math.round(obj.iBTechAvtotSum);
					regionCount['Grand Total']=regionCount['Grand Total']+Math.round(obj.iBTechAvtotSum);
				}
				});
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){
					(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = numberWithCommas(Math.round(totalCount[technology]));
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
        return {
			searchDataService: function(){
				var jsonData = [];
				var item = {};
				item["region"] = "";
				item["unitStatusDesc"]="InService";
				item["siteCustCountry"]= "";
				item["servRelationDescOng"]="";
				item["technology"]="";
				item["equipCode"]="";
				item["marketSegmentDesc"]="";
				item["customerName"]="";
				item["maintPolicyCode"]="";
				item["siteCustName"]="";
				item["iboType"]="full_ibo";
				item["businessSegment"]=$rootScope.businessSegment;
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
				jsonData.push(item);
				return jsonData;
			},
			getRegionWithCount: function(techRegionData){	
					return regionDataProcess(techRegionData)['chartData']
			},
			processedData: function(techRegionData){	
					return regionDataProcess(techRegionData);
			},
			countryDataProcess: function(techRegionData){	
					return countryDataProcess(techRegionData);
			},
			processTable: function(technologyData){
				return processTable(technologyData);
			},
			processCountryTable: function(technologyData){
				return processCountryTable(technologyData);
			},
			initTable(data,columns,id) { 
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
				if ($.fn.DataTable.isDataTable( '#'+id )) {
						$('#'+id).dataTable().fnDestroy();        
						$('#'+id).empty(); 
						 $('#'+id).append('<tfoot></tfoot>');
					}  
				dt = $('#'+id).DataTable({
				   "order": [[ columns.length-1, "desc" ]],
				   columns : columns,
				   "pageLength": 10,
                   data: data,
				   fnDrawCallback : function() {
					if(footer && data[0].length>0){
					   $('#'+id+ ' > tfoot').html('');
					   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					   _.forEach(columns, function(column){
							if(footer[column.title]){
								$('#'+id+ ' > tfoot').append('<th>'+footer[column.title]+'</th>');
							}
					   });
					}
					}
				});
				return dt;				
			},
			getTechnologyData: function(technologyDropdown,regionDropdown,regionWithCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var testData = {}, countryCount = {}, totalCount = {}, technology= [], techTotal = {},technologiesList=[];
					_.forEach(regionWithCount, function(reg){
						_.forEach(regionDropdown, function(tech){
						createNestedObject(testData, [reg.name,tech.iBTechnologyDes], -1);
						createNestedObject(testData, [reg.name,'~Total'], 0);
						createNestedObject(techTotal, [reg.name], 0);
						createNestedObject(totalCount, [tech.iBTechnologyDes , 'Total'] , 0);
						createNestedObject(countryCount, [tech.iBTechnologyDes , reg.name] , 0);
					});
					});
					var colorCodes = [];
					totalCount['gTotal'] = 0;
					_.forEach(regionDropdown, function(respData){
						var tempObject = {};
						tempObject[respData.iBTechnologyDes]= respData.iBTechAvtotSum ;
						createNestedObject(testData, [respData.iBTchRegion, respData.iBTechnologyDes ] , Math.round(respData.iBTechAvtotSum));
						createNestedObject(countryCount, [respData.iBTechnologyDes , respData.iBTchRegion] , Math.round(respData.iBTechAvtotSum));
						createNestedObject(totalCount, [respData.iBTechnologyDes , 'Total'] , (totalCount[respData.iBTechnologyDes])['Total']+Math.round(respData.iBTechAvtotSum));
						createNestedObject(testData, [respData.iBTchRegion,'~Total'] , (testData[respData.iBTchRegion])['~Total']+Math.round(respData.iBTechAvtotSum));
						createNestedObject(techTotal, [respData.iBTchRegion] , (techTotal[respData.iBTchRegion])+Math.round(respData.iBTechAvtotSum));
						totalCount['gTotal']+=Math.round(respData.iBTechAvtotSum);
						if(technologiesList.indexOf(respData.iBTechnologyDes) === -1){
							technologiesList.push(respData.iBTechnologyDes);
							colorCodes.push(respData.iBColorCode);							
						}			
						});
					
					techTotal = _.sortBy(_.pairs(techTotal), function (item) { return item[1]; });
					/* Descending Sort */
					techTotal = techTotal.reverse();
					var rankArray = [];
					_.forEach(techTotal, function(tech){
						rankArray.push(tech[0]);
					});
					_.forEach(testData, function(data){
							testData['regions'] = [];
							/* Sort Alphabetically */
							testData['regions'] = _.sortBy(Object.keys(data), function(o) { return o; });	
						return false;
					});

					var chartData = [], chartObj = {};
					_.forEach(Object.keys(countryCount), function(data){
							chartObj ={};
							var countryCountObj = countryCount[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							_.forEach(rankArray, function(key){
									chartObj['data'].push(countryCountObj[key]);
							});
							chartData.push(chartObj);
							technology = rankArray;
					});
					var returnObj = {};
					returnObj['testData'] = testData;
					returnObj['countryCount'] = countryCount;
					returnObj['chartData'] = chartData;
					returnObj['totalCount'] = totalCount;
					returnObj['technology'] = technology;
					returnObj['colorCode'] = colorCodes;
					return returnObj;
			},
        	getCustomerData: function(customerNameData){
				/* Top 10 Customers */
					var regionWithCustomerCount = _.first(_.sortBy(customerNameData, function(custData){
						return Math.round(custData.iBTechAvtotSum)}).reverse(),10);
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var customerCounts = {}, colorCodes ={};					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.iBTchRegion!==null){
							createNestedObject(customerCounts, [region.iBTchRegion,customerCount.custName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
					if(region.iBTchRegion!==null){	
						createNestedObject(customerCounts, [region.iBTchRegion,region.custName], (customerCounts[region.iBTchRegion])[region.custName]+Math.round(region.iBTechAvtotSum));
						totalCustomerCount = totalCustomerCount + Math.round(region.iBTechAvtotSum);
						colorCodes[region.iBTchRegion] = region.iBTechRegionId - 1;
					}
					});
					var chartData = [], chartObj = {}, customers = [];
					_.forEach(Object.keys(customerCounts), function(data){
							chartObj ={};
							var keys = Object.keys(customerCounts[data]);
							var customerCountsObj = customerCounts[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							chartObj['_colorIndex']=colorCodes[data];
							_.forEach(keys, function(key){
									chartObj['data'].push(customerCountsObj[key]);
							});
							customers = keys;
							chartData.push(chartObj);
					});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			},
			updateTechReg: function(techRegionData){
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};

					var totalcount = 0,regionWithCountData=[], regionData={};					
					var regions = [], _colorIndexes = [], technologies = [], summaryData = {}, totalCount={};
					_.forEach(techRegionData, function(responseObj){
						if(regions.indexOf(responseObj.iBTechnologyDes) === -1 && responseObj.iBTechnologyDes!==null){
							regions.push(responseObj.iBTechnologyDes);
							_colorIndexes.push(responseObj.iBColorCode);
						}
						if(technologies.indexOf(responseObj.iBTchRegion) === -1){
							technologies.push(responseObj.iBTchRegion);
						}					
					});
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(summaryData, [region, technology], 0);
								createNestedObject(summaryData, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
							}
						});
					});		
		
					_.forEach(techRegionData, function(responseObj){
						if(responseObj.iBTchRegion!==null){
							createNestedObject(summaryData, [responseObj.iBTechnologyDes, responseObj.iBTchRegion],responseObj.iBTechAvtotSum);
							totalCount[responseObj.iBTchRegion]=totalCount[responseObj.iBTchRegion]+Math.round(responseObj.iBTechAvtotSum);
							totalcount = totalcount + Math.round(responseObj.iBTechAvtotSum);
						}
					});
					totalCount = _.sortBy(_.pairs(totalCount), function (item) { return item[1]; });
					/* Descending Sort */
					totalCount = totalCount.reverse();
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					_.forEach(regions, function(region){
						_.forEach(rankArray, function(technology){
							((regionData[region])[rankArray.indexOf(technology)])=Math.round((summaryData[region])[technology]);
						});
						regionWithCountData.push({
							'data': regionData[region], 
							'name':region,
							});
					});
				var returnObj = {};
				returnObj['regionWithCount'] = regionWithCountData;
				returnObj['technology'] = rankArray;
				returnObj['totalcount'] = totalcount;
				returnObj['colorCode'] = _colorIndexes;
				return returnObj;
			}
			
        };
    }]);
});
