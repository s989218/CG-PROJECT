define([
	'./IBOChart',
	'./IBOCustomer',
	'./IBOTable',
	'./IBOMetricsService',
	'./IBOTechRegion'
	], function() {

});
