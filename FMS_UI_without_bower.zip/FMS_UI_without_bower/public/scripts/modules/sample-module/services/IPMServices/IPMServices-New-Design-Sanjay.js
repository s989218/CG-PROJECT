define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('IPMService', ['URLService','$q','$http',function(URLService,$q,$http) {
		var IPMServiceFunction = function(request){
			var deferred  = $q.defer();            	
			$http({
                    dataType: request.dataType,
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
                    contentType: request.contentType,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
        return {
    		getIPMRisksData: function(jsonData){
        		var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data":jsonData,
					'url':"connect/fms/getIPMData/risks" ,					
					};
				return IPMServiceFunction(request);
			},
             getIPMKeyDealsData: function(jsonData){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/getIPMData/keydeals" ,					
					};
				return IPMServiceFunction(request);
			},
             getIPMOppsData: function(jsonData){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/getIPMData/opps" ,					
					};
				return IPMServiceFunction(request);
			},
            getBObyBusinessData: function(jsonData){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/walkByBusinessData" ,					
					};
				return IPMServiceFunction(request);
			},
            
            getBObyRegionData: function(jsonData){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/walkByRegionData" ,					
					};
				return IPMServiceFunction(request);
			},
            getIPMSelectionFiltersData: function(){
				var request = {
                    'dataType': "json",
					'method': 'GET',
                    'contentType':"application/json",
					"data": null,
					'url':"connect/fms/getIPMDropdownData" ,					
					};
				return IPMServiceFunction(request);
			},
            getIPMPartsDropdownData: function(){
				var request = {
                    'dataType': "json",
					'method': 'GET',
                    'contentType':"application/json",
					"data": null,
					'url':"connect/fms/getIPMPartsDropdownData" ,					
					};
				return IPMServiceFunction(request);
			},
          /*  getIPMPartsData: function(){
				var request = {
                    'dataType': "json",
					'method': 'GET',
                    'contentType':"application/json",
					"data": null,
					'url':"connect/fms/getIPMPartsData" ,					
					};
				return IPMServiceFunction(request);
			},
          */  
          getIPMPartsData: function(jsonData){
              	var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/getIPMPartsData" ,					
					};
				return IPMServiceFunction(request);
			},
           getIPMDataEntryData: function(jsonData){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/getIPMDataEntryData",					
					};
				return IPMServiceFunction(request);
			},
            
         getPCData: function(jsonData){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/projectController" ,					
					};
				return IPMServiceFunction(request);
			},
              /*  getPCCSData: function(jsonData){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/projectController" ,					
					};
				return IPMServiceFunction(request);
			},
                getPCINSTData: function(jsonData){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/projectController" ,					
					};
				return IPMServiceFunction(request);
			},
            */
             getPRCData: function(jsonData){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/walkByProduct" ,					
					};
				return IPMServiceFunction(request);
			},
            
          /*  getPRCCSData: function(jsonData){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/projectController" ,					
					};
				return IPMServiceFunction(request);
			},
            getPRCINSTData: function(jsonData){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/projectController" ,					
					};
				return IPMServiceFunction(request);
			},*/
            getWalkByFinanceData: function(jsonData){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/walkByFinance" ,					
					};
				return IPMServiceFunction(request);
			},
            
           updateIPMDataEntryData: function(jsonData){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/updateIPMDataEntryData",					
					};
				return IPMServiceFunction(request);
			},
            
            updateIPMPartsRow: function(jsonData){
                var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/updateIPMParts" ,					
					};
				return IPMServiceFunction(request);
			}/*,
			getDataimportCSVToTable: function(jsonData){
                var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": jsonData,
					'url':"connect/fms/importCSVToTable" ,					
					};
				return IPMServiceFunction(request);
			}*/
        };
    }]);
    
    module.factory('InstalledbaseService', ['$q','$http','URLService','NetworkCallService',
	function($q, $http,URLService,NetworkCallService) {
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: {'data' : request.data},
					url: request.url,
					headers: request.headers,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
        return {
			/* Network Call */
        	getLatLongByRegion: function(){
				var request = {
					'method': 'GET',
					'url': URLService.newMetrics.getLatLongByRegion
					};
				return networkCall(request);
			},

			getInstldBaseDropdownsData: function(){
				var request = {
					'method': 'GET',
					'url': URLService.newMetrics.getInstldBaseDropdownsData
					};
				return networkCall(request);
			},
        }
    }]);
});



 