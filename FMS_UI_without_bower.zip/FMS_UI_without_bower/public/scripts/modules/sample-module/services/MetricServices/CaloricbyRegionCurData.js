define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('CaloricbyRegionCurDataService', ['CaloricRegionChartService', function(CaloricRegionChartService) {
        return {
            updateCaloricbyRegionCurData: function($scope) {
                var valueData = [],
                    data = [],
                    item = {},
                    tmp, name = "",
                    curData, tdCHtml = "",
                    headerCurLst = [],
                    tmpCurLst = [],
                    total = [],
                    header = [],
                    endResult = {};
                for (var i = 0; i < $scope.CaloricbyRegionDataCur.length; i++) {
                    curData = $scope.CaloricbyRegionDataCur[i].quarter;
                    if (tmp == null && ($scope.CaloricbyRegionDataCur[i].region).toUpperCase() !== "TOTAL") {
                        tdCHtml = tdCHtml + "<tr><td class='centerTxt'>" + ($scope.CaloricbyRegionDataCur[i].year+ " - " + $scope.CaloricbyRegionDataCur[i].quarter) + "</td><td class='centerTxt'>" + $scope.CaloricbyRegionDataCur[i].value + "</td>";
                        tmp = $scope.CaloricbyRegionDataCur[i].quarter;
                        name = ($scope.CaloricbyRegionDataCur[i].year+ " - " + $scope.CaloricbyRegionDataCur[i].quarter);
                        tmpCurLst.push($scope.CaloricbyRegionDataCur[i].region);
                        data = [];
                        data.push(parseFloat($scope.CaloricbyRegionDataCur[i].value));
                    } else if (curData !== null && curData !== tmp) {
                        item["name"] = name;
                        item["data"] = data;
                        valueData.push(item);
                        if (headerCurLst.length === 0) {
                            headerCurLst = tmpCurLst.slice();
                        }
                        if (($scope.CaloricbyRegionDataCur[i].region).toUpperCase() !== "TOTAL") {
                            tdCHtml = tdCHtml + "</tr><tr><td class='centerTxt'>" + ($scope.CaloricbyRegionDataCur[i].year+ " - " + $scope.CaloricbyRegionDataCur[i].quarter) + "</td><td class='centerTxt'>" + $scope.CaloricbyRegionDataCur[i].value + "</td>";
                            tmp = $scope.CaloricbyRegionDataCur[i].quarter;
                            name = ($scope.CaloricbyRegionDataCur[i].year+ " - " + $scope.CaloricbyRegionDataCur[i].quarter);
                            data = [];
                            data.push(parseFloat($scope.CaloricbyRegionDataCur[i].value));
                        }
                    } else if (curData === tmp && ($scope.CaloricbyRegionDataCur[i].region).toUpperCase() !== "TOTAL") {
                        tdCHtml = tdCHtml + "<td class='centerTxt'>" + $scope.CaloricbyRegionDataCur[i].value + "</td>";
                        tmp = $scope.CaloricbyRegionDataCur[i].quarter;
                        name = ($scope.CaloricbyRegionDataCur[i].year+ " - " + $scope.CaloricbyRegionDataCur[i].quarter);
                        data.push(parseFloat($scope.CaloricbyRegionDataCur[i].value));
                        tmpCurLst.push($scope.CaloricbyRegionDataCur[i].region);
                    }
                    if (($scope.CaloricbyRegionDataCur[i].region).toUpperCase() === "TOTAL") {
                        header.push($scope.CaloricbyRegionDataCur[i].quarter);
                        total.push(parseFloat($scope.CaloricbyRegionDataCur[i].value));
                    }
                }
                tdCHtml = tdCHtml + "</tr>";
                if (data.length > 0) {
                    item["name"] = name;
                    item["data"] = data;
                    valueData.push(item);
                    if (headerCurLst.length === 0) {
                        headerCurLst = tmpCurLst.slice();
                    }
                }
                var thHtml = "<tr><th class='tHeadMaintenance'></th>";
                angular.forEach(headerCurLst, function(value) {
                    thHtml = thHtml + "<th class='tHeadMaintenance'>" + value + "</th>";
                });
                thHtml = thHtml + "</tr>";
                
                if ( $.fn.DataTable.isDataTable('#CaloricIndexByRegion-Cur-Data') ) {
                    $('#CaloricIndexByRegion-Cur-Data').DataTable().destroy();
                }

                $('#CaloricIndexByRegion-Cur-Data tbody').empty();
                
                $(".CaloricRegCurHeader").html(thHtml);
                $(".CaloricRegCurData").html(tdCHtml);
                
                CaloricRegionChartService.CaloricRegionChart(valueData, headerCurLst, header, total);
                
                $("#CaloricIndexByRegion-Cur-Data").DataTable({
                    "bPaginate": false,
                    "bAutoWidth": false,
                    "bSort": true,
                    "bFilter": false,
                    "iDisplayLength": 10,
                    "bInfo": false,
                    "aaSorting": [],
                    "lengthMenu": [
                        [5, 10, 25, 50, -1],
                        [5, 10, 25, 50, "All"]
                    ]
                });
                if (total > 0) {
                    endResult['CaloricIndexRegCurDataTable1'] = true;
                    endResult['CaloricIndexRegCurDataTable2'] = false;
                } else {
                    endResult['CaloricIndexRegCurDataTable1'] = false;
                    endResult['CaloricIndexRegCurDataTable2'] = true;
                }
                return endResult;
            },
            updateCaloricbyRegionHistData: function($scope) {
                var tmp, name = "",
                    curData, tdAHtml = "",
                    tdHtml = "",
                    valueDataHist = [],
                    dataHist = [],
                    itemHist = {},
                    headerLst = [],
                    tmpLst = [],
                    endResult = {},
                    tdAvghtml = "";
                if ($scope.CaloricbyRegionDataHis.length > 0) {
                    for (var i = 0; i < $scope.CaloricbyRegionDataHis.length; i++) {
                        curData = $scope.CaloricbyRegionDataHis[i].year+ " - " +$scope.CaloricbyRegionDataHis[i].quarter;
                        if (tmp == null) {
                            tdHtml = tdHtml + "<tr><td class='centerTxt'>" + ($scope.CaloricbyRegionDataHis[i].year+ " - " +$scope.CaloricbyRegionDataHis[i].quarter) + "</td><td class='centerTxt'>";

                            if ($scope.CaloricbyRegionDataHis[i].value === "-9999.00" && ($scope.CaloricbyRegionDataHis[i].region === "Asia Pacific" || $scope.CaloricbyRegionDataHis[i].region === "MENAT")) {
                                $scope.CaloricbyRegionDataHis[i].value = "";
                                tdHtml = tdHtml + $scope.CaloricbyRegionDataHis[i].value;
                            } else {
                                tdHtml = tdHtml + $scope.CaloricbyRegionDataHis[i].value;
                            }

                            tdHtml = tdHtml + "</td>";
                            tmp = $scope.CaloricbyRegionDataHis[i].year+ " - " +$scope.CaloricbyRegionDataHis[i].quarter;
                            name = ($scope.CaloricbyRegionDataHis[i].year+ " - " +$scope.CaloricbyRegionDataHis[i].quarter);
                            tmpLst.push($scope.CaloricbyRegionDataHis[i].region);
                            dataHist = [];
                            dataHist.push(parseFloat($scope.CaloricbyRegionDataHis[i].value));
                        } else if (curData !== null && curData !== tmp) {
                            itemHist["name"] = name;
                            itemHist["data"] = dataHist;
                            valueDataHist.push(itemHist);
                            if (headerLst.length === 0) {
                                headerLst = tmpLst.slice();
                            }
                            tdHtml = tdHtml + "</tr><tr><td class='centerTxt'>" + ($scope.CaloricbyRegionDataHis[i].year+ " - " +$scope.CaloricbyRegionDataHis[i].quarter) + "</td><td class='centerTxt'>";

                            if ($scope.CaloricbyRegionDataHis[i].value === "-9999.00" && ($scope.CaloricbyRegionDataHis[i].region === "Asia Pacific" || $scope.CaloricbyRegionDataHis[i].region === "MENAT")) {
                                $scope.CaloricbyRegionDataHis[i].value = "";
                                tdHtml = tdHtml + $scope.CaloricbyRegionDataHis[i].value;
                            } else {
                                tdHtml = tdHtml + $scope.CaloricbyRegionDataHis[i].value;
                            }

                            tdHtml = tdHtml + "</td>";
                            tmp = $scope.CaloricbyRegionDataHis[i].year+ " - " +$scope.CaloricbyRegionDataHis[i].quarter;
                            name = ($scope.CaloricbyRegionDataHis[i].year+ " - " +$scope.CaloricbyRegionDataHis[i].quarter);
                            dataHist = [];
                            dataHist.push(parseFloat($scope.CaloricbyRegionDataHis[i].value));
                        } else if (curData === tmp) {
                            tdHtml = tdHtml + "<td class='centerTxt'>";

                            if ($scope.CaloricbyRegionDataHis[i].value === "-9999.00" && ($scope.CaloricbyRegionDataHis[i].region === "Asia Pacific" || $scope.CaloricbyRegionDataHis[i].region === "MENAT")) {
                                $scope.CaloricbyRegionDataHis[i].value = "";
                                tdHtml = tdHtml + $scope.CaloricbyRegionDataHis[i].value;
                            } else {
                                tdHtml = tdHtml + $scope.CaloricbyRegionDataHis[i].value;
                            }

                            tdHtml = tdHtml + "</td>";

                            tmp = $scope.CaloricbyRegionDataHis[i].year+ " - " +$scope.CaloricbyRegionDataHis[i].quarter;
                            name = ($scope.CaloricbyRegionDataHis[i].year+ " - " +$scope.CaloricbyRegionDataHis[i].quarter);
                            tmpLst.push($scope.CaloricbyRegionDataHis[i].region);
                            dataHist.push(parseFloat($scope.CaloricbyRegionDataHis[i].value));
                        }
                    }
                    
                    if (headerLst.length === 0) {
                        headerLst = tmpLst.slice();
                    }

                    for (i = 0; i < $scope.caloricIndexAverage.length; i++) {
                        curData = $scope.caloricIndexAverage[i].year;
                        if (tmp == null) {
                            if ($scope.caloricIndexAverage[i].average === "-9999.00" && ($scope.caloricIndexAverage[i].region === "Asia Pacific" || $scope.caloricIndexAverage[i].region === "MENAT")) {
                                tdAHtml = tdAHtml + "<tr><td class='centerTxt'>" + ("Average" + " - " + $scope.caloricIndexAverage[i].year) + "</td><td class='centerTxt'> </td>";
                            } else {
                                tdAHtml = tdAHtml + "<tr><td class='centerTxt'>" + ("Average" + " - " + $scope.caloricIndexAverage[i].year) + "</td><td class='centerTxt'>" + $scope.caloricIndexAverage[i].average + "</td>";
                            }

                            tmp = $scope.caloricIndexAverage[i].year;
                        } else if (curData !== null && curData !== tmp) {
                            if ($scope.caloricIndexAverage[i].average === "-9999.00" && ($scope.caloricIndexAverage[i].region === "Asia Pacific" || $scope.caloricIndexAverage[i].region === "MENAT")) {
                                tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>" + ("Average" + " - " + $scope.caloricIndexAverage[i].year) + "</td><td class='centerTxt'> </td>";
                            } else {
                                tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>" + ("Average" + " - " + $scope.caloricIndexAverage[i].year) + "</td><td class='centerTxt'>" + $scope.caloricIndexAverage[i].average + "</td>";
                            }
                            tmp = $scope.caloricIndexAverage[i].year;
                        } else if (curData === tmp) {
                            if ($scope.caloricIndexAverage[i].average === "-9999.00" && ($scope.caloricIndexAverage[i].region === "Asia Pacific" || $scope.caloricIndexAverage[i].region === "MENAT")) {
                                tdAHtml = tdAHtml + "<td class='centerTxt'> </td>";
                            } else {
                                tdAHtml = tdAHtml + "<td class='centerTxt'>" + $scope.caloricIndexAverage[i].average + "</td>";
                            }
                            tmp = $scope.caloricIndexAverage[i].year;
                        }
                    }

                    for (i = 0; i < $scope.caloricIndexAverageDTO.length; i++) {
                        tdAvghtml = tdAvghtml + "<td class='centerTxt'>" + parseFloat($scope.caloricIndexAverageDTO[i].average).toFixed(2) + "</td>";
                    }
                    var avgHtml = "<tr>" + "<td class='centerTxt'>" + "Average" + tdAvghtml + "</tr>";
                    tdHtml = avgHtml + tdAHtml + tdHtml + "</tr>";
                    if (dataHist.length > 0) {
                        itemHist["name"] = name;
                        itemHist["data"] = itemHist;
                        valueDataHist.push(itemHist);
                    }
                    $(".CaloricRegHisHeader").html('');
                    var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
                    angular.forEach(headerLst, function(value) {
                        thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>" + value + "</th>";
                    });
                    thHtmlHist = thHtmlHist + "</tr>";
                    
                    if ( $.fn.DataTable.isDataTable('#CaloricIndexByRegion-His-Data') ) {
                        $('#CaloricIndexByRegion-His-Data').DataTable().destroy();
                    }

                    $('#CaloricIndexByRegion-His-Data tbody').empty();
                    
                    $(".CaloricRegHisHeader").html(thHtmlHist);
                    $(".CaloricRegHisData").html(tdHtml);

                    var createNestedObject = function(base, names, value) {
                        var lastName = arguments.length === 3 ? names.pop() : false;
                        for (var i = 0; i < names.length; i++) {
                            base = base[names[i]] = base[names[i]] || {};
                        }
                        if (lastName) base = base[lastName] = value;
                        return base;
                    };

                    var regionData = {},
                        techSummary = {},
                        techData = {};
                    var regions = [],
                        technologies = [],
                        totalCount = {};
                    /* All Regions and Technologies */
                    _.forEach($scope.CaloricbyRegionDataHis, function(responseObj) {
                        if (technologies.indexOf(responseObj.region) === -1 && responseObj.region !== null && responseObj.region !== 'Total') {
                            technologies.push(responseObj.region);
                        }
                        if (regions.indexOf(responseObj.year + "-" + responseObj.quarter) === -1) {
                            regions.push(responseObj.year + "-" + responseObj.quarter);
                        }
                    });

                    regions.reverse();

                    var techTotalCount = {};
                    _.forEach(regions, function(region) {
                        regionData[region] = [];
                        var count = 0;
                        _.forEach(technologies, function(technology) {
                            if (region !== null) {
                                (regionData[region])[count] = 0;
                                count++;
                                createNestedObject(techSummary, [technology, region], 0);
                                createNestedObject(totalCount, [technology], 0);
                                createNestedObject(techTotalCount, [region], 0);
                            }
                        });
                    });
                    _.forEach(technologies, function(technology) {
                        techData[technology] = [];
                        var count = 0;
                        _.forEach(regions, function(region) {
                            if (region !== null) {
                                (techData[technology])[count] = 0;
                                count++;
                            }
                        });
                    });
                    _.forEach($scope.CaloricbyRegionDataHis, function(responseObj) {
                        if (responseObj.year + "-" + responseObj.quarter !== null && responseObj.region !== 'Total') {
                            techTotalCount[responseObj.year + "-" + responseObj.quarter] = techTotalCount[responseObj.year + "-" + responseObj.quarter] + parseFloat(responseObj.value);
                            createNestedObject(techSummary, [responseObj.region, responseObj.year + "-" + responseObj.quarter], parseFloat(responseObj.value));
                        }
                    });
                    techTotalCount = _.pairs(techTotalCount);
                    var rankArray = [];
                    _.forEach(totalCount, function(tech) {
                        rankArray.push(tech[0]);
                    });
                    var techRankArray = [];
                    _.forEach(techTotalCount, function(region) {
                        techRankArray.push(region[0]);
                    });
                    var tempArr = [];
                    _.forEach(technologies, function(technology) {
                        _.forEach(techRankArray, function(region) {
                            ((techData[technology])[techRankArray.indexOf(region)]) = parseFloat((techSummary[technology])[region]);
                        });
                        tempArr.push({
                            'data': techData[technology],
                            'name': technology
                        });
                    });
                    var valueDataforChart = tempArr;
                    CaloricRegionChartService.CaloricRegionChartHistory(valueDataforChart, regions);
                    
                    $("#CaloricIndexByRegion-His-Data").DataTable({
                        "bPaginate": true,
                        "bAutoWidth": false,
                        "bSort": true,
                        "bFilter": true,
                        "iDisplayLength": 5,
                        "bInfo": true,
                        "aaSorting": [],
                        "lengthMenu": [
                            [5, 10, 25, 50, -1],
                            [5, 10, 25, 50, "All"]
                        ]
                    });

                    endResult['CaloricIndexRegHistDataTable1'] = true;
                    endResult['CaloricIndexRegHistDataTable2'] = false;
                } else {
                    endResult['CaloricIndexRegHistDataTable1'] = false;
                    endResult['CaloricIndexRegHistDataTable2'] = true;
                }
                return endResult;
            },

            excelDownload: function(id) {
                var columns = [];
                _.forEach($('#' + id + '').dataTable().api().columns().header(), function(data) {
                    columns.push(data.innerHTML);
                });
                var tableToExcel = (function() {
                    var ctx, subHeader;
                    var uri = 'data:application/vnd.ms-excel;base64,',
                        template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
                        base64 = function(s) {
                            return window.btoa(unescape(encodeURIComponent(s)))
                        },
                        format = function(s, c) {
                            return s.replace(/{(\w+)}/g, function(m, p) {
                                return c[p];
                            })
                        }
                    return function(table) {
                        if (!table.nodeType)
                            table = document.getElementById(id);
                        var excelContent = '';
                        var header = "<tr><td colspan='8' style='text-align:center'>" +
                            "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>" +
                            "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
                        if (id === 'CaloricIndexByRegion-Cur-Data') {
                            subHeader = "<tr><td colspan='8' style='text-align:center'>" +
                                "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Caloric Index By Region Current Data</span>" +
                                "</td></tr>";
                        }
                        if (id === 'CaloricIndexByRegion-His-Data') {
                            subHeader = "<tr><td colspan='8' style='text-align:center'>" +
                                "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Caloric Index By Region History Data</span>" +
                                "</td></tr>";
                        }
                        excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: ' + (new Date()).toLocaleString() + '</td></tr>';
                        excelContent = excelContent + subHeader;
                        var getDataFromDT = $('#' + id + '').dataTable().api().rows({
                            filter: "applied"
                        }).data().toArray();
                        var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
                        var tdNumber = "<td style='mso-number-format:0'>";
                        excelContent = excelContent + '<tr>';
                        _.forEach(columns, function(column) {
                            excelContent = excelContent + th + column + '</th>';
                        });
                        excelContent = excelContent + '</tr>';
                        _.forEach(getDataFromDT, function(row) {
                            excelContent = excelContent + '<tr>';
                            _.forEach(row, function(rowData) {
                                if ((/^[0-9]{0,}$/).test(rowData))
                                    excelContent = excelContent + tdNumber + rowData + '</td>';
                                else
                                    excelContent = excelContent + '<td>' + rowData + '</td>';
                            });
                            excelContent = excelContent + '</tr>';
                        });
                        excelContent = excelContent + '<tr>';
                        excelContent = excelContent + '</tr>';
                        if (id === 'CaloricIndexByRegion-Cur-Data') {
                            ctx = {
                                worksheet: 'CaloricIndexByReg Cur Data',
                                table: excelContent
                            };
                            document.getElementById('CaloricIndexByRegionCurData').href = (uri + base64(format(template, ctx)));
                            document.getElementById('CaloricIndexByRegionCurData').download = 'CaloricIndexByRegion-Cur-Data.xls';
                        }
                        if (id === 'CaloricIndexByRegion-His-Data') {
                            ctx = {
                                worksheet: 'CaloricIndexByReg Hist Data',
                                table: excelContent
                            };
                            document.getElementById('CaloricIndexByRegionHisData').href = (uri + base64(format(template, ctx)));
                            document.getElementById('CaloricIndexByRegionHisData').download = 'CaloricIndexByRegion-His-Data.xls';
                        }
                    }
                })();
                tableToExcel(id);
                return null;
            }
        }
    }]);
});