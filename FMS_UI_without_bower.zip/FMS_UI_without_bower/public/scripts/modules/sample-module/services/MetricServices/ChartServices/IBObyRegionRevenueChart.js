define(['angular', '../../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('CreateChartService', [function() {
    	var chart,chart2;
		return{
			IBObyRegRevChart: function (iboByRegion,revByRegion,headerCurLst,total1,total2,id){
				chart= new Highcharts.Chart({
				        chart: {
					       renderTo: id,
						   type: 'column'
						 },
						 title: {
							 text: ''
						 },
						 xAxis: {
							 categories: headerCurLst,
							  crosshair: true
								 },
						 yAxis: [{
									 title: {
									 text: '$K'
									 }
							 }],
						 legend: {
							 layout: 'horizontal',
							 align: 'right',
							 verticalAlign: 'bottom',
							 floating: false,
                             useHTML: true
						 },
						 tooltip: {
							 shared: true
						 },
						 plotOptions: {
							 column: {
								 grouping: false,
								 shadow: false,
								 borderWidth: 0,
								 dataLabels: {
					                    enabled: true,
					                    formatter: function () {
					                    	return ("$"+numberWithCommas(this.y)+"K");
					                    }
					             }
							 }
							 
						 },
						 credits: {
							 enabled: false
						 },
						 series: [{
							 name: 'IBO by Region',
							 color: '#3694f8',
							 data: iboByRegion,
							 pointPadding: 0.3,  
							 tooltip: {
					                valuePrefix: '$',
					                valueSuffix: ' K'
					            },
						 }, {
							 name: 'Rev $ by Region',
							 color: '#FF6347',
							 data: revByRegion,
							 pointPadding: 0.4,
							 tooltip: {
					                valuePrefix: '$',
					                valueSuffix: ' K'
					            },
					   
						 }],
                         responsive: {
                            rules: [{
                                condition: {
                                    maxWidth: 500
                                },
                                chartOptions: {
                                    legend: {
                                        align: 'center',
                                        verticalAlign: 'bottom',
                                        layout: 'horizontal',
                                        useHTML: true
                                    },
                                    yAxis: {
                                        labels: {
                                            align: 'left',
                                            x: 0,
                                            y: -5
                                        },
                                        title: {
                                            text: null
                                        }
                                    },
                                    subtitle: {
                                        text: null
                                    },
                                    credits: {
                                        enabled: false
                                    }
                                }
                            }]
                        }
					}, function(chart) {
							for(var t=0;t<total1.length&&t<total2.length;t++)
							{
							chart.renderer.label('<span id="iboTotal"><span style="color: rgb(124, 181, 236); font-weight:bold">IBO Total :</span><span style="color: black; font-weight:bold"> $'+total1[t]+'K</span></span>', 85, 375,null,null,null,true,null,"iboTotal")
					            .css({
					                fontSize: '12px',
                                    textAlign: 'center'
					            })
					            .add();
								chart.renderer.label('<span id="revenueTotal"><span style="color: rgb(124, 181, 236); font-weight:bold">Revenue Total :</span><span style="color: black; font-weight:bold"> $'+total2[t]+'K</span></span>', 350, 375,null,null,null,true,null,"revenueTotal")
					            .css({
					                fontSize: '12px',
                                    textAlign: 'center'
					            })
					            .add();
							}
					    });
			  
			},
			exportChart : function(type){
				if(type === 'JPEG')
				{
					chart.exportChart({type: 'image/jpeg', filename: 'IBO by Region & Revenue Current Data Chart'}, {subtitle: {text:''}});
				}
				if(type === 'XLS'){
					chart.exportChart({type: 'application/vnd.ms-excel', filename: 'IBO by Region & Revenue Current Data Chart'}, {subtitle: {text:''}});
				}
			},
			IBObyRegRevChartHistory: function (valueDataforChart, headerCurLst){
				chart2 =Highcharts.chart({
					 chart: {
					      renderTo: 'container1History'
					    },
			        title: {
			            text: ''
			        },
			        subtitle: {
			            text: ''
			        },
			        xAxis: {
			            categories: headerCurLst
			        },
			        yAxis: {
			            min: 0,
			            title: {
			                text: '$'
			            }
			        },
			        tooltip: {
			        	headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
			        	pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
			        	'<td style="padding:0"><b>${point.y:.0f}K</b></td></tr>',
			        	footerFormat: '</table>',
			        	shared: true,
			        	useHTML: true
			        },
			        plotOptions: {
			            column: {
			            	 stacking: 'normal'
			            }
			        },
			        credits: {
						enabled: false
					},
			        series:valueDataforChart,
                    responsive: {
                        rules: [{
                            condition: {
                                maxWidth: 500
                            },
                            chartOptions: {
                                legend: {
                                    align: 'center',
                                    verticalAlign: 'bottom',
                                    layout: 'horizontal'
                                },
                                yAxis: {
                                    labels: {
                                        align: 'left',
                                        x: 0,
                                        y: -5
                                    },
                                    title: {
                                        text: null
                                    }
                                },
                                subtitle: {
                                    text: null
                                },
                                credits: {
                                    enabled: false
                                }
                            }
                        }]
                    }
			    }); 
			},
			exportChartHistory : function(type){
				if(type === 'JPEG')
				{
					chart2.exportChart({type: 'image/jpeg', filename: 'IBO by Region & Revenue History Data Chart'}, {subtitle: {text:''}});
				}
					if(type === 'XLS'){
					chart2.exportChart({type: 'application/vnd.ms-excel', filename: 'IBO by Region & Revenue History Data Chart'}, {subtitle: {text:''}});
				}
			}
		}
    }]);
});
    