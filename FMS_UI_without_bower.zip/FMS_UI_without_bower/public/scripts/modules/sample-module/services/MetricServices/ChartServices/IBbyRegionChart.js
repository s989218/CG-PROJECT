define(['angular', '../../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('IBbyRegionChart', [function() {
    	var chart;
    	var chart2;
		return{
			IBbyRegionChart: function (valueData, headerCurLst,total,header){//$/IB by Region chart fun
				chart= new Highcharts.Chart({
					    chart: {
					      renderTo: 'container2',
						    type: 'column'
					    },	
								title: {
					            text: ''
					        },
					        subtitle: {
					            text: ''
					        },
					        xAxis: {
					            categories: headerCurLst,
					            crosshair: true
					        },
					        yAxis: {
					            title: {
					                text: '$'
					            }
					        },
							legend: {
								layout: 'horizontal',
								align: 'right',
								verticalAlign: 'bottom',
								floating: false
					        },
					       
					        tooltip: {
					            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
					            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
					                '<td style="padding:0"><b>${point.y:.0f}K</b></td></tr>',
					            footerFormat: '</table>',
					            shared: true,
					            useHTML: true
					        },
					        plotOptions: {
					            column: {
					                pointPadding: 0.2,
					                borderWidth: 0,
					                dataLabels: {
					                    enabled: true,
					                    formatter: function () {
					                    	return ("$"+this.y+"K");
					                    }
					                }
					            }
					        },
							credits: {
								enabled: false
							},
					        series: valueData
					    }, function(chart) {
							for(var t=0;t<header.length&&t<total.length;t++)
							{
							chart.renderer.text('<span><span1 style="color: rgb(124, 181, 236); font-weight:bold">'+header[t]+': </span1> <span2  style="color: black; font-weight:bold">$'+total[t]+'K</span2></span>', 70, 375)
					            .css({
					                fontSize: '12px',
					 
					            })
					            .add();
							}
					    });
			},
			exportChartCur : function(type){
				if(type === 'JPEG')
				{
					 chart.exportChart({type: 'image/jpeg', filename: 'IB-by-Region-Curent-Data-chart'}, {subtitle: {text:''}});
				}
					if(type === 'XLS'){
					chart.exportChart({type: 'application/vnd.ms-excel', filename: 'IB-by-Region-Curent-Data-chart'}, {subtitle: {text:''}});
				}
			},
			IBbyRegionChartHistory: function (valueDataforChart, headerCurLst){
				chart2 =Highcharts.chart({
					 chart: {
					      renderTo: 'container2History'
					    },
			        title: {
			            text: ''
			        },
			        subtitle: {
			            text: ''
			        },
			        xAxis: {
			            categories: headerCurLst,
			            crosshair: true
			        },
			        yAxis: {
			            min: 0,
			            title: {
			                text: '$'
			            }
			        },
			        tooltip: {
			            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
			            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
			                '<td style="padding:0"><b>${point.y:.0f}K</b></td></tr>',
			            footerFormat: '</table>',
			            shared: true,
			            useHTML: true
			        },
			        plotOptions: {
			            column: {
			            	 stacking: 'normal',
			                pointPadding: 0.2,
			                borderWidth: 0
			            }
			        },
			        credits: {
						enabled: false
					},
			        series:valueDataforChart
			    }); 
			},
			exportChartHistory : function(type){
				if(type === 'JPEG')
				{
					chart2.exportChart({type: 'image/jpeg', filename: 'IB-by-Region-History-Data-chart'}, {subtitle: {text:''}});
				}
					if(type === 'XLS'){
					chart2.exportChart({type: 'application/vnd.ms-excel', filename: 'IB-by-Region-History-Data-chart'}, {subtitle: {text:''}});
				}
			}
		}
    }]);
});
    