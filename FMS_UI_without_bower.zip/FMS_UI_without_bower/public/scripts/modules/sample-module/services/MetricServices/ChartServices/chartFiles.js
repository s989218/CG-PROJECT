define([
	'./IBObyRegionRevenueChart',
	'./IBbyRegionChart',
	'./OpexPenetrationChart',
	'./CaloricRegionChart',
	'./fleetPenetrationChart',
	'./fleetCoverageChart',
	'./conversionIndexChart',
	'./iBNbyRegionChart',
	'./iBNbyTechChart',
	'./iBObyTechChart',
	'./partsPenChart'
	], function() {

});
