define(['angular', '../../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('PartsPenChartService', [function() {
    	var chart,chart2,chart11,chart12,chart13,chart11Hist,chart12Hist,chart13Hist;
		return{
			partsPenChart:function(valueData, headerCurLst,header,total,id){
				
				chart= new Highcharts.Chart({
				    chart: {
				      renderTo: id,
					    type: 'column'
				    },	
							title: {
				            text: ''
				        },
				        subtitle: {
				            text: ''
				        },
				        xAxis: {
				            categories: headerCurLst,
				            crosshair: true
				        },
				        yAxis: {
				            title: {
				                text: '%'
				            }
				        },
						legend: {
							layout: 'horizontal',
							align: 'right',
							verticalAlign: 'bottom',
							floating: false
				        },
				        tooltip: {
				            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
				            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
				                '<td style="padding:0"><b>{point.y}%</b></td></tr>',
				            footerFormat: '</table>',
				            shared: true,
				            useHTML: true
				        },
				        plotOptions: {
				            column: {
				                pointPadding: 0.2,
				                borderWidth: 0,
				                dataLabels: {
				                    enabled: true,
				                    formatter: function () {
				                    	return (this.y+"%");
				                    }
				                }
				            }
				        },
						credits: {
							enabled: false
						},
				        series: valueData
				     },function(chart) {
							for(var t=0;t<header.length&&t<total.length;t++)
							{
							chart.renderer.text('<span><span1 style="color: rgb(124, 181, 236); font-weight:bold">'+header[t]+': </span1> <span2  style="color: black; font-weight:bold">'+total[t]+'</span2></span>', 70, 375)
					            .css({
					                fontSize: '12px',
					            })
					            .add();
							}
					    });
				if(id === 'container11'){
					 chart11 = chart
				}else if(id === 'container12'){
					 chart12 = chart
				}else if(id === 'container13'){
					 chart13 = chart
				}
			},
			exportChart : function(type,name,divId){
				if(type === 'JPEG')
				{
					if(divId === 'container11'){
						 chart11.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}
					else if(divId === 'container12'){
						 chart12.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}
					else if(divId === 'container13'){
						 chart13.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}
				}
			},
			partsPenChartHistory: function (valueDataforChart, headerCurLst,id){
				chart2 =Highcharts.chart({
					 chart: {
					      renderTo: id
					    },
			        title: {
			            text: ''
			        },
			        subtitle: {
			            text: ''
			        },
			        xAxis: {
			            categories: headerCurLst,
			            crosshair: true
			        },
			        yAxis: {
			            min: 0,
			            title: {
			                text: '%'
			            }
			        },
			        tooltip: {
			            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
			            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
			                '<td style="padding:0"><b>{point.y}%</b></td></tr>',
			            footerFormat: '</table>',
			            shared: true,
			            useHTML: true
			        },
			        plotOptions: {
			            column: {
			            	 stacking: 'normal',
			                pointPadding: 0.2,
			                borderWidth: 0
			            }
			        },
			        credits: {
						enabled: false
					},
			        series:valueDataforChart
			    });
				if(id === 'container11History'){
					 chart11Hist = chart2
				}else if(id === 'container12History'){
					 chart12Hist = chart2
				}else if(id === 'container13History'){
					 chart13Hist = chart2
				}
			},
			
			exportChartHistory : function(type,name,divId){
				if(type === 'JPEG')
				{
					if(divId === 'container11History'){
						chart11Hist.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}else if(divId === 'container12History'){
						chart12Hist.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}else if(divId === 'container13History'){
						chart13Hist.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}
					
					
				}
			}
			
		}
    }]);
});
    