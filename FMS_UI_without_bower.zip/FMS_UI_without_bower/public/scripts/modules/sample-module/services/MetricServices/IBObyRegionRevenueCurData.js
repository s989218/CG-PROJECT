define(['angular', '../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('RegionRevenueCurrDataService', ['CreateChartService','$rootScope',function(CreateChartService,$rootScope) {
		return{
			updateIBObyRegionRevenueCurData: function (IBObyRegionDataCur, revDollarbyRegionDataCur){
				var valueData = [], data = [], item , tmp, name = "", curData, tdCHtml = "", headerCurLst = [], tmpCurLst = [],
				iboByRegion = [], revByRegion = [], total1 = [], total2 = [], endResults={};
					for(var i=0;i<IBObyRegionDataCur.length &&i<revDollarbyRegionDataCur.length;i++)
					{
						curData = revDollarbyRegionDataCur[i].quarter;
						if(tmp==null && (revDollarbyRegionDataCur[i].region).toUpperCase()!=="TOTAL")
						{
							tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+(IBObyRegionDataCur[i].year+" - "+IBObyRegionDataCur[i].quarter)+"</td><td class='centerTxt'>$"+numberWithCommas(IBObyRegionDataCur[i].value)+"K</td>";
							tmp = IBObyRegionDataCur[i].quarter;
							name = (IBObyRegionDataCur[i].year+" - "+IBObyRegionDataCur[i].quarter);
							tmpCurLst.push(IBObyRegionDataCur[i].region);
							iboByRegion.push(parseFloat(IBObyRegionDataCur[i].value));
							revByRegion.push(parseFloat(revDollarbyRegionDataCur[i].value));
							data = [];
							data.push(parseFloat(IBObyRegionDataCur[i].value));
							tdCHtml = tdCHtml +"</td><td class='centerTxt'>$"+numberWithCommas(revDollarbyRegionDataCur[i].value)+"K</td>";
							data.push(parseFloat(revDollarbyRegionDataCur[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							item={};
							item["name"] = name;
							item["data"] = data;
							valueData.push(item);
							if(headerCurLst.length===0)
							{
								headerCurLst = tmpCurLst.slice();
							}
							if((revDollarbyRegionDataCur[i].region).toUpperCase()!=="TOTAL")
							{
								tdCHtml = tdCHtml + "</tr><tr><td class='centerTxt'>"+(IBObyRegionDataCur[i].year+" - "+IBObyRegionDataCur[i].quarter)+"</td><td class='centerTxt'>$"+numberWithCommas(IBObyRegionDataCur[i].value)+"K</td>";
								tmp = IBObyRegionDataCur[i].quarter;
								name = (IBObyRegionDataCur[i].year+" - "+IBObyRegionDataCur[i].quarter);
								data = [];
								data.push(parseFloat(IBObyRegionDataCur[i].value));
								tdCHtml = tdCHtml + "</tr><td class='centerTxt'>"+(revDollarbyRegionDataCur[i].quarter+" - "+revDollarbyRegionDataCur[i].year)+"</td><td class='centerTxt'>$"+numberWithCommas(revDollarbyRegionDataCur[i].value)+"K</td>";
								data.push(parseFloat(revDollarbyRegionDataCur[i].value));
								iboByRegion.push(parseFloat(IBObyRegionDataCur[i].value));
								revByRegion.push(parseFloat(revDollarbyRegionDataCur[i].value));
							}

						}
						else if(curData===tmp && (revDollarbyRegionDataCur[i].region).toUpperCase()!=="TOTAL")
						{
							tdCHtml = tdCHtml + "<td class='centerTxt'>$"+numberWithCommas(IBObyRegionDataCur[i].value)+"K</td>";
							tmp = IBObyRegionDataCur[i].quarter;
							name = (IBObyRegionDataCur[i].year+" - "+IBObyRegionDataCur[i].quarter);
							data.push(parseFloat(IBObyRegionDataCur[i].value));
							tdCHtml = tdCHtml + "<td class='centerTxt'>$"+numberWithCommas(revDollarbyRegionDataCur[i].value)+"K</td>";
							data.push(parseFloat(revDollarbyRegionDataCur[i].value));
							tmpCurLst.push(revDollarbyRegionDataCur[i].region);
							iboByRegion.push(parseFloat(IBObyRegionDataCur[i].value));
							revByRegion.push(parseFloat(revDollarbyRegionDataCur[i].value));								
						}
						if((IBObyRegionDataCur[i].region && revDollarbyRegionDataCur[i].region).toUpperCase()==="TOTAL")
						{	
							total1.push(parseFloat(IBObyRegionDataCur[i].value));
							total2.push(parseFloat(revDollarbyRegionDataCur[i].value));

						}
					}
					tdCHtml = tdCHtml + "</tr>";
					if(data.length>0)
					{
						item={};
						item["name"] = name;
						item["data"] = data;
						valueData.push(item);
						if(headerCurLst.length===0)
						{
							headerCurLst = tmpCurLst.slice();
						}
					}
					
					$rootScope.excelHeaders= headerCurLst;
					var thHtml = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerCurLst,function(value){

						thHtml = thHtml + "<th class='tHeadMaintenance' colspan='2'>"+value+"</th>";
					});
					thHtml = thHtml + "</tr><tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerCurLst,function(){
						thHtml = thHtml + "<th class='tHeadMaintenance'>IBO</th><th class='tHeadMaintenance'>Rev</th>";
					});
					thHtml = thHtml + "</tr>";
                
                    if ( $.fn.DataTable.isDataTable('#IB0-by-RegionRevenue-Cur-Data') ) {
                        $('#IB0-by-RegionRevenue-Cur-Data').DataTable().destroy();
                    }

                    $('#IB0-by-RegionRevenue-Cur-Data tbody').empty();
                    
					$(".IBObyRegRevCurHeader").html(thHtml);					
					$(".IBObyRegRevCurData").html(tdCHtml);
                
					CreateChartService.IBObyRegRevChart(iboByRegion,revByRegion,headerCurLst,total1,total2,'container1');
                
					$("#IB0-by-RegionRevenue-Cur-Data").DataTable( {
						"bPaginate": false,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": false,
						"iDisplayLength": 10,
						"bInfo":false,
						"aaSorting":[],
                        rowReorder: {
                            selector: 'td:nth-child(2)'
                        },
                        responsive: true,
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
				if(total1>0 ||total2>0)
				{
					endResults['IBObyRegRevCurDataTable1']=true;
					endResults['IBObyRegRevCurDataTable2']=false;
				}
				else
				{
					endResults['IBObyRegRevCurDataTable1']=false;
					endResults['IBObyRegRevCurDataTable2']=true
				}
				return endResults;
			},
			updateIBObyRegionRevenueHistData: function (IBObyRegionDataHis, revDollarbyRegionDataHis,responseData){
				var tmp, name = "", curData, tdAHtml = "",tdHtml = "", valueDataHist = [], dataHist = [], itemHist, headerLst = [], tmpLst = [], endResults={},tdAvghtml = "";
				if(IBObyRegionDataHis.length>0)
				{
					for(var i=0;i<IBObyRegionDataHis.length;i++)
					{	
						curData = IBObyRegionDataHis[i].year+" - "+IBObyRegionDataHis[i].quarter;
						if(tmp==null)
						{
							tdHtml = tdHtml + "<tr><td class='centerTxt'>"+(IBObyRegionDataHis[i].year+" - "+IBObyRegionDataHis[i].quarter)+"</td><td class='centerTxt'>$"+numberWithCommas(IBObyRegionDataHis[i].value)+"K</td>";
							tmp = IBObyRegionDataHis[i].year+" - "+IBObyRegionDataHis[i].quarter;
							name = (IBObyRegionDataHis[i].year+" - "+IBObyRegionDataHis[i].quarter);
                            
							tmpLst.push(IBObyRegionDataHis[i].region);
							dataHist = [];
							dataHist.push(parseFloat(IBObyRegionDataHis[i].value));
							tdHtml = tdHtml +"</td><td class='centerTxt'>$"+numberWithCommas(revDollarbyRegionDataHis[i].value)+"K</td>";
							dataHist.push(parseFloat(revDollarbyRegionDataHis[i].value));
						}
						else if(curData !== null && curData !== tmp)
						{
							itemHist={};
							itemHist["name"] = name;
							itemHist["data"] = dataHist;
							valueDataHist.push(itemHist);
							if(headerLst.length===0)
                            {
                                headerLst = tmpLst.slice();
                            }
							tdHtml = tdHtml + "</tr><tr><td class='centerTxt'>"+(IBObyRegionDataHis[i].year+" - "+IBObyRegionDataHis[i].quarter)+"</td><td class='centerTxt'>$"+numberWithCommas(IBObyRegionDataHis[i].value)+"K</td>";
							tmp = IBObyRegionDataHis[i].year+" - "+IBObyRegionDataHis[i].quarter;
							name = (IBObyRegionDataHis[i].year+" - "+IBObyRegionDataHis[i].quarter);
							dataHist = [];
							dataHist.push(parseFloat(IBObyRegionDataHis[i].value));
							tdHtml = tdHtml +"</td><td class='centerTxt'>$"+numberWithCommas(revDollarbyRegionDataHis[i].value)+"K</td>";
							dataHist.push(parseFloat(revDollarbyRegionDataHis[i].value));
						}
						else if(curData===tmp)
						{
							tdHtml = tdHtml + "<td class='centerTxt'>$"+numberWithCommas(IBObyRegionDataHis[i].value)+"K</td>";
							tmp = IBObyRegionDataHis[i].year+" - "+IBObyRegionDataHis[i].quarter;
							name = (IBObyRegionDataHis[i].year+" - "+IBObyRegionDataHis[i].quarter);
							tmpLst.push(IBObyRegionDataHis[i].region);
							dataHist.push(parseFloat(IBObyRegionDataHis[i].value));
							tdHtml = tdHtml + "<td class='centerTxt'>$"+numberWithCommas(revDollarbyRegionDataHis[i].value)+"K</td>";
							dataHist.push(parseFloat(revDollarbyRegionDataHis[i].value));							
						}
					}
                    
                    if(headerLst.length===0)
                    {
                        headerLst = tmpLst.slice();
                    }
                    
					for(i=0;i<responseData.iboByRegionAverage.length;i++)
					{	
						curData = responseData.iboByRegionAverage[i].year;
						if(tmp==null)
						{
							tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+responseData.iboByRegionAverage[i].year)+"</td><td class='centerTxt'>$"+numberWithCommas(responseData.iboByRegionAverage[i].average)+"K</td>";
							tmp = responseData.iboByRegionAverage[i].year;
							tdAHtml = tdAHtml +"</td><td class='centerTxt'>$"+numberWithCommas(responseData.revDollarByRegAverage[i].average)+"K</td>";
						}
						else if(curData!==null && curData!==tmp)
						{
							tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+responseData.iboByRegionAverage[i].year)+"</td><td class='centerTxt'>$"+numberWithCommas(responseData.iboByRegionAverage[i].average)+"K</td>";
							tmp = responseData.iboByRegionAverage[i].year;
							tdAHtml = tdAHtml +"</td><td class='centerTxt'>$"+numberWithCommas(responseData.revDollarByRegAverage[i].average)+"K</td>";
						}
						else if(curData===tmp)
						{
							tdAHtml = tdAHtml + "<td class='centerTxt'>$"+numberWithCommas(responseData.iboByRegionAverage[i].average)+"K</td>";
							tdAHtml = tdAHtml + "<td class='centerTxt'>$"+numberWithCommas(responseData.revDollarByRegAverage[i].average)+"K</td>";							
						}
					}
					for(i=0;i<responseData.iboByRegionAverageDTO.length;i++)
					{
						var iboreg = responseData.iboByRegionAverageDTO[i].average;
						var iborev = responseData.revDollarByRegAverageDTO[i].average;
						tdAvghtml=tdAvghtml + "<td class='centerTxt'>$" + numberWithCommas(iboreg) +"K</td>" + "<td class='centerTxt'>$" + numberWithCommas(iborev) +"K</td>";
					}
					var avgHtml = "<tr>"+ "<td class='centerTxt'>"+"Average"+tdAvghtml +"</tr>";
					tdHtml = avgHtml + tdAHtml + tdHtml + "</tr>";
					if(dataHist.length>0)
					{
						itemHist={};
						itemHist["name"] = name;
						itemHist["data"] = itemHist;
						valueDataHist.push(itemHist);
					}
					$rootScope.excelHistHeaders= headerLst;
					var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(value){

						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance' colspan='2'>"+value+"</th>";
					});
					thHtmlHist = thHtmlHist + "</tr><tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(){
						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>IBO</th><th class='tHeadMaintenance'>Rev</th>";
					});
					thHtmlHist = thHtmlHist + "</tr>";
                    
                    if ( $.fn.DataTable.isDataTable('#IB0-by-RegionRevenue-His-Data') ) {
                        $('#IB0-by-RegionRevenue-His-Data').DataTable().destroy();
                    }

                    $('#IB0-by-RegionRevenue-His-Data tbody').empty();
                    
					$(".IBObyRegRevHisHeader").html(thHtmlHist);

					$(".IBObyRegRevHisData").html(tdHtml);

					
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					
					var  regionData={}, techSummary ={}, techData={};                                                                      
					var regions = [], technologies = [], totalCount={} ;
					/* All Regions and Technologies */
					_.forEach(IBObyRegionDataHis, function(responseObj){
						if(technologies.indexOf(responseObj.region+ " IBO") === -1 && responseObj.region+ " IBO"!==null && responseObj.region!=='Total' ){
							technologies.push(responseObj.region+ " IBO");
						}
						if(regions.indexOf(responseObj.year+"-"+responseObj.quarter) === -1){
							regions.push(responseObj.year+"-"+responseObj.quarter);
						}  
					});
                    
                    regions.reverse();
                    
					var techTotalCount = {};
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(techSummary, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCount, [region], 0);
							}
						});
					});                           
					_.forEach(technologies, function(technology){
						techData[technology] = [];
						var count = 0;
						_.forEach(regions, function(region){
							if(region!==null){
								(techData[technology])[count] = 0;
								count ++;
							}
						});
					});
					_.forEach(IBObyRegionDataHis, function(responseObj){
						if(responseObj.year+"-"+responseObj.quarter!==null && responseObj.region!=='Total'){
							techTotalCount[responseObj.year+"-"+responseObj.quarter]=techTotalCount[responseObj.year+"-"+responseObj.quarter]+parseFloat(responseObj.value);
							createNestedObject(techSummary, [responseObj.region+" IBO", responseObj.year+"-"+responseObj.quarter], parseFloat(responseObj.value));
						}
					});
					techTotalCount =_.pairs(techTotalCount);
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					var techRankArray = [];
					_.forEach(techTotalCount, function(region){
						techRankArray.push(region[0]);
					});
					var tempArr=[];
					_.forEach(technologies, function(technology){
						_.forEach(techRankArray, function(region){
							((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]);
						});
						tempArr.push({'data': techData[technology], 'name':technology});
					});
					var  techSummaryHist ={}, techDataHist={};                                                                      
					var regionsHist = [],technologiesHist = [];
					/* All regionsHist and Technologies */
					_.forEach(revDollarbyRegionDataHis, function(responseObj){
						if(technologiesHist.indexOf(responseObj.region+" Rev") === -1 && responseObj.region+" Rev"!==null && responseObj.region!=='Total'){
							technologiesHist.push(responseObj.region+" Rev");
						}
						if(regionsHist.indexOf(responseObj.year+"-"+responseObj.quarter) === -1){
							regionsHist.push(responseObj.year+"-"+responseObj.quarter);
						}  
					});
                    
                    regionsHist.reverse();
                    
                    var techTotalCountHist = {};
					_.forEach(regionsHist, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologiesHist, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(techSummaryHist, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCountHist, [region], 0);
							}
						});
					});                           
					_.forEach(technologiesHist, function(technology){
						techDataHist[technology] = [];
						var count = 0;
						_.forEach(regionsHist, function(region){
							if(region!==null){
								(techDataHist[technology])[count] = 0;
								count ++;
							}
						});
					});
					_.forEach(revDollarbyRegionDataHis, function(responseObj){
						if(responseObj.year+"-"+responseObj.quarter!==null && responseObj.region!=='Total'){
							techTotalCountHist[responseObj.year+"-"+responseObj.quarter]=techTotalCountHist[responseObj.year+"-"+responseObj.quarter]+parseFloat(responseObj.value);
							createNestedObject(techSummaryHist, [responseObj.region+" Rev", responseObj.year+"-"+responseObj.quarter], parseFloat(responseObj.value));
						}
					});
					techTotalCountHist =_.pairs(techTotalCountHist);
					var rankArrayHist = [];
					_.forEach(totalCount, function(tech){
						rankArrayHist.push(tech[0]);
					});
					var techRankArrayHist = [];
					_.forEach(techTotalCountHist, function(region){
						techRankArrayHist.push(region[0]);
					});
					_.forEach(technologiesHist, function(technology){
						_.forEach(techRankArrayHist, function(region){
							((techDataHist[technology])[techRankArrayHist.indexOf(region)])=parseFloat((techSummaryHist[technology])[region]);
						});
						tempArr.push({'data': techDataHist[technology], 'name':technology});
					});
					var valueDataforChart = tempArr;
					CreateChartService.IBObyRegRevChartHistory(valueDataforChart,regions);
                    
					$("#IB0-by-RegionRevenue-His-Data").DataTable({
						"bPaginate": true,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": true,
						"iDisplayLength": 5,
						"bInfo":true,
						"aaSorting":[],
                        rowReorder: {
                            selector: 'td:nth-child(2)'
                        },
                        responsive: true,
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
					endResults['IBObyRegRevHistDataTable2']=false;
					endResults['IBObyRegRevHistDataTable1']=true
				}
				else
				{
					endResults['IBObyRegRevHistDataTabl']=false;
					endResults['IBObyRegRevHistDataTable2']=true
				}
				return endResults;
			},

			excelDownload: function(id){
			    	var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 });
				 var tableToExcel = (function() {
					 var  curData=$rootScope.excelHeaders,i;
					 var  histData= $rootScope.excelHistHeaders
					 var ctx,subHeader;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
	                      if (!table.nodeType) 
	                             table = document.getElementById(id);
	                      var excelContent = '';
	                      var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                      var  td1="<td style='width: auto;font-weight: bold; text-align:center;padding-left:25px; background-color:#00BCD4'></td><td class='centerTxt' colspan='2' style='width: auto;font-weight: bold; text-align:center;padding-left:25px; background-color:#00BCD4'>";
		                    var  td="<td class='centerTxt' colspan='2' style='width: auto;font-weight: bold;text-align:center; padding-left:5px; background-color:#00BCD4'>";
	                      if(id ==='IB0-by-RegionRevenue-Cur-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>IBO by Region & Revenue Current Data</span>"+
	                          "</td></tr>";
		                      subHeader=subHeader+'<tr>';
		                      for(i=0;i<curData.length;i++)
		                      {  
		                    	  if(i===0)
		                    	  {
		                    		  subHeader=subHeader + td1 + curData[i] +'</td>';
		                    	  }
		                    	  else
		                    	  {
		                    		  subHeader=subHeader + td + curData[i] +'</td>';
		                    	  }
		                      }
		                      subHeader=subHeader+'</tr>';
                    	  }
	                      if(id ==='IB0-by-RegionRevenue-His-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>IBO by Region & Revenue History Data</span>"+
	                          "</td></tr>";
			                      subHeader=subHeader+'<tr>';
			                      for(i=0;i<histData.length;i++)
			                      {  
			                    	  if(i===0)
			                    	  {
			                    		  subHeader=subHeader + td1 + histData[i] +'</td>';
			                    	  }
			                    	  else
			                    	  {
			                    		  subHeader=subHeader + td + histData[i] +'</td>';
			                    	  }
			                      }
			                      subHeader=subHeader+'</tr>';
                    	  }
	                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                      excelContent = excelContent + subHeader;
	                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
	                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                      var tdNumber = "<td style='mso-number-format:0'>";
	                      excelContent =excelContent + '<tr>';
	                      var flag = 0;
	                        _.forEach(columns, function(column){
	                               if(columns[0]!== 'null' && flag === 0){
	                                      excelContent = excelContent + th + column + '</th>';
	                                      flag++;
	                               }else {
	                                      excelContent = excelContent + th + column +'($K)' + '</th>';
	                               }
	                        });
	                      excelContent = excelContent + '</tr>';
	                      _.forEach(getDataFromDT, function(row){
	                             excelContent =excelContent + '<tr>';
	                             _.forEach(row, function(rowData){
	                            	 rowData = rowData.replace(/K/g, "");
	                                  if (rowData.includes('$')) {
	                                	  rowData = rowData.substring(1,rowData.length);
	                                  }
	                            	 if((/^[0-9]{0,}$/).test(rowData))
	                                           excelContent = excelContent + tdNumber + rowData + '</td>';
	                                    else
	                                           excelContent = excelContent + '<td>' + rowData + '</td>';
	                             });
	                             excelContent =excelContent + '</tr>';
	                      });
	                     excelContent =excelContent + '<tr>';
	                      excelContent =excelContent + '</tr>';
	                      if(id ==='IB0-by-RegionRevenue-Cur-Data')
                    	  { 
	                    	  ctx = {worksheet:'IB0 by RegionRevenue Cur Data' , table: excelContent};
		                      document.getElementById('IBObyRegRevCurData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('IBObyRegRevCurData').download = 'IB0-by-RegionRevenue-Cur-Data.xls';
                    	  }
                      if(id==='IB0-by-RegionRevenue-His-Data'){
	                    	  ctx = {worksheet: 'IB0 by RegionRevenue Hist Data' , table: excelContent};
		                      document.getElementById('IBObyRegRevHisData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('IBObyRegRevHisData').download = 'IB0-by-RegionRevenue-His-Data.xls';
                      }
	                }
	                })();
	                tableToExcel(id);
				return null;
			}
		}
	}]);
});
