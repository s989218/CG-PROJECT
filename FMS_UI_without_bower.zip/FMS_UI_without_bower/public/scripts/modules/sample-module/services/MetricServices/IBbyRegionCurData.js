define(['angular', '../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('IBbyRegionCurDataService', ['IBbyRegionChart',function(IBbyRegionChart) {
		return{
			updateIBbyRegionCurData: function ($scope){
				var valueData = [], data = [], item , tmp, name = "", curData, tdCHtml = "", headerCurLst = [], tmpCurLst = [],
				total = [], header = [], endResults={};
					for(var i=0;i<$scope.IBbyRegionDataCur.length;i++)
					{
						curData = $scope.IBbyRegionDataCur[i].quarter;
						if(tmp==null && ($scope.IBbyRegionDataCur[i].region).toUpperCase()!=="TOTAL")
						{
							tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.IBbyRegionDataCur[i].year+" - "+$scope.IBbyRegionDataCur[i].quarter)+"</td><td class='centerTxt'>$"+$scope.IBbyRegionDataCur[i].value+"K</td>";
							tmp = $scope.IBbyRegionDataCur[i].quarter;
							name = ($scope.IBbyRegionDataCur[i].year+" - "+$scope.IBbyRegionDataCur[i].quarter);
							tmpCurLst.push($scope.IBbyRegionDataCur[i].region);
							data = [];
							data.push(parseFloat($scope.IBbyRegionDataCur[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							item["name"] = name;
							item["data"] = data;
							valueData.push(item);
							if(headerCurLst.length===0)
							{
								headerCurLst = tmpCurLst.slice();
							}
							if(($scope.IBbyRegionDataCur[i].region).toUpperCase()!=="TOTAL")
							{
								tdCHtml = tdCHtml + "</tr><tr><td class='centerTxt'>"+($scope.IBbyRegionDataCur[i].year+" - "+$scope.IBbyRegionDataCur[i].quarter)+"</td><td class='centerTxt'>$"+$scope.IBbyRegionDataCur[i].value+"K</td>";
								tmp = $scope.IBbyRegionDataCur[i].quarter;
								name = ($scope.IBbyRegionDataCur[i].year+" - "+$scope.IBbyRegionDataCur[i].quarter);
								data = [];
								data.push(parseFloat($scope.IBbyRegionDataCur[i].value));
							}
						}
						else if(curData===tmp && ($scope.IBbyRegionDataCur[i].region).toUpperCase()!=="TOTAL")
						{
							tdCHtml = tdCHtml + "<td class='centerTxt'>$"+$scope.IBbyRegionDataCur[i].value+"K</td>";
							tmp = $scope.IBbyRegionDataCur[i].quarter;
							name = ($scope.IBbyRegionDataCur[i].year+" - "+$scope.IBbyRegionDataCur[i].quarter);
							data.push(parseFloat($scope.IBbyRegionDataCur[i].value));
							tmpCurLst.push($scope.IBbyRegionDataCur[i].region);
						}
						if(($scope.IBbyRegionDataCur[i].region).toUpperCase()==="TOTAL")
						{	
							header.push($scope.IBbyRegionDataCur[i].quarter);
							total.push(parseFloat($scope.IBbyRegionDataCur[i].value));
						}
					}
					tdCHtml = tdCHtml + "</tr>";
					if(data.length>0)
					{
						item={};
						item["name"] = name;
						item["data"] = data;
						valueData.push(item);
						if(headerCurLst.length===0)
						{
							headerCurLst = tmpCurLst.slice();
						}
					}
					var thHtml = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerCurLst,function(value){
						thHtml = thHtml + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtml = thHtml + "</tr>";
                
                    if ( $.fn.DataTable.isDataTable('#IB-by-Region-Cur-Data') ) {
                        $('#IB-by-Region-Cur-Data').DataTable().destroy();
                    }

                    $('#IB-by-Region-Cur-Data tbody').empty();
                
					$(".IBbyRegCurHeader").html(thHtml);
					$(".IBbyRegCurData").html(tdCHtml);
                
					IBbyRegionChart.IBbyRegionChart(valueData,headerCurLst,total,header);
                
					$("#IB-by-Region-Cur-Data").DataTable( {
						"bPaginate": false,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": false,
						"iDisplayLength": 10,
						"bInfo":false,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
				if(total>0)
				{
					endResults['IBbyRegionCurDataTable1']=true;
					endResults['IBbyRegionCurDataTable2']=false;
				}
				else
				{
					endResults['IBbyRegionCurDataTable1']=false;
					endResults['IBbyRegionCurDataTable2']=true;
				}
				return endResults;
			},
			
			updateIBbyRegionHistData: function ($scope){
				var tmp,name = "",curData,tdHtml = "",tdAHtml = "",valueDataHist = [], dataHist = [],itemHist = {},var1={},vararray=[], headerLst = [], tmpLst = [],endResult={}, tdAvghtml = "";
				if($scope.IBbyRegionDataHis.length>0)
				{	
					for(var i=0;i<$scope.IBbyRegionDataHis.length;i++)
					{
						curData = $scope.IBbyRegionDataHis[i].year+" - "+$scope.IBbyRegionDataHis[i].quarter;
						if(tmp==null)
						{
							tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.IBbyRegionDataHis[i].year+" - "+$scope.IBbyRegionDataHis[i].quarter)+"</td><td class='centerTxt'>$"+$scope.IBbyRegionDataHis[i].value+"K</td>";
							tmp = $scope.IBbyRegionDataHis[i].year+" - "+$scope.IBbyRegionDataHis[i].quarter;
							name = ($scope.IBbyRegionDataHis[i].year+" - "+$scope.IBbyRegionDataHis[i].quarter);
							tmpLst.push($scope.IBbyRegionDataHis[i].region);
							dataHist = [];
							dataHist.push($scope.IBbyRegionDataHis[i].value);
						}
						else if(curData!==null && curData!==tmp)
						{  
							
							itemHist["name"] = name;
							itemHist["data"] = dataHist;
							valueDataHist.push(itemHist);
							var1["name"]=name;
							var1["data"]=dataHist;
							vararray.push(var1);
							if(headerLst.length===0)
							{
								headerLst = tmpLst.slice();
							}
							
								tdHtml = tdHtml + "</tr><tr><td class='centerTxt'>"+($scope.IBbyRegionDataHis[i].year+" - "+$scope.IBbyRegionDataHis[i].quarter)+"</td><td class='centerTxt'>$"+$scope.IBbyRegionDataHis[i].value+"K</td>";
								tmp = $scope.IBbyRegionDataHis[i].year+" - "+$scope.IBbyRegionDataHis[i].quarter;
								name = ($scope.IBbyRegionDataHis[i].year+" - "+$scope.IBbyRegionDataHis[i].quarter);
								dataHist = [];
								dataHist.push($scope.IBbyRegionDataHis[i].value);
							
						}
						else if(curData===tmp )
						{
							tdHtml = tdHtml + "<td class='centerTxt'>$"+$scope.IBbyRegionDataHis[i].value+"K</td>";
							tmp = $scope.IBbyRegionDataHis[i].year+" - "+$scope.IBbyRegionDataHis[i].quarter;
							name = ($scope.IBbyRegionDataHis[i].year+" - "+$scope.IBbyRegionDataHis[i].quarter);
							tmpLst.push($scope.IBbyRegionDataHis[i].region);
							dataHist.push($scope.IBbyRegionDataHis[i].value);
						}
					}
                    
                    if(headerLst.length===0)
                    {
                        headerLst = tmpLst.slice();
                    }
                    
					for(i=0;i<$scope.dollarByIBAverage.length;i++)
					{
						curData = $scope.dollarByIBAverage[i].year;
						if(tmp==null)
						{
							tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+$scope.dollarByIBAverage[i].year)+"</td><td class='centerTxt'>$"+$scope.dollarByIBAverage[i].average+"K</td>";
							tmp = $scope.dollarByIBAverage[i].year;
						}
						else if(curData!==null && curData!==tmp)
						{  
							tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+$scope.dollarByIBAverage[i].year)+"</td><td class='centerTxt'>$"+$scope.dollarByIBAverage[i].average+"K</td>";
							tmp = $scope.dollarByIBAverage[i].year;
						}
						else if(curData===tmp )
						{
							tdAHtml = tdAHtml + "<td class='centerTxt'>$"+$scope.dollarByIBAverage[i].average+"K</td>";
							tmp = $scope.dollarByIBAverage[i].year;
						}
					}
					for(i=0;i<$scope.dollarByIBAverageDTO.length;i++)
					{
						tdAvghtml=tdAvghtml + "<td class='centerTxt'>$" + $scope.dollarByIBAverageDTO[i].average +"K</td>";
					}
					var avgHtml = "<tr>"+ "<td class='centerTxt'>"+"Average"+tdAvghtml +"K</tr>";
					tdHtml = avgHtml + tdAHtml + tdHtml + "</tr>";
					if(dataHist.length>0)
					{
						itemHist={};
						itemHist["name"] = name;
						itemHist["data"] = itemHist;
						valueDataHist.push(itemHist);
					}
					$(".IBbyRegHisHeader").html('');
					var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(value){
						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtmlHist = thHtmlHist + "</tr>";
                    
                    if ( $.fn.DataTable.isDataTable('#IB-by-Region-His-Data') ) {
                        $('#IB-by-Region-His-Data').DataTable().destroy();
                    }

                    $('#IB-by-Region-His-Data tbody').empty();
                    
					$(".IBbyRegHisHeader").html(thHtmlHist);
					$(".IBbyRegHisData").html(tdHtml);

						var createNestedObject = function( base, names, value ) {
							var lastName = arguments.length === 3 ? names.pop() : false;
							for( var i = 0; i < names.length; i++ ) {
								base = base[ names[i] ] = base[ names[i] ] || {};
							}
							if( lastName ) base = base[ lastName ] = value;
							return base;
						};
						var regionData={}, techSummary ={}, techData={};                                                                      
						var regions = [], technologies = [], totalCount={};
						/* All Regions and Technologies */
						_.forEach($scope.IBbyRegionDataHis, function(responseObj){
							if(technologies.indexOf(responseObj.region) === -1 && responseObj.region!==null && responseObj.region!=='Total'){
								technologies.push(responseObj.region);
							}
							if(regions.indexOf(responseObj.year+"-"+responseObj.quarter) === -1){
								regions.push(responseObj.year+"-"+responseObj.quarter);
							}  
						});
                    
                        regions.reverse();
                    
						var techTotalCount = {};
						_.forEach(regions, function(region){
							regionData[region] = [];
							var count = 0;
							_.forEach(technologies, function(technology){
								if(region!==null){
									(regionData[region])[count] = 0;
									count ++;
									createNestedObject(techSummary, [technology, region], 0);
									createNestedObject(totalCount, [technology], 0);
									createNestedObject(techTotalCount, [region], 0);
								}
							});
						});                           
						_.forEach(technologies, function(technology){
							techData[technology] = [];
							var count = 0;
							_.forEach(regions, function(region){
								if(region!==null){
									(techData[technology])[count] = 0;
									count ++;
								}
							});
						});        
						
						
						_.forEach($scope.IBbyRegionDataHis, function(responseObj){
							if(responseObj.year+"-"+responseObj.quarter!==null){
								techTotalCount[responseObj.year+"-"+responseObj.quarter]=techTotalCount[responseObj.year+"-"+responseObj.quarter]+parseFloat(responseObj.value);
								createNestedObject(techSummary, [responseObj.region, responseObj.year+"-"+responseObj.quarter], responseObj.value);
							}
						});
						techTotalCount =_.pairs(techTotalCount);
						var rankArray = [];
						_.forEach(totalCount, function(tech){
							rankArray.push(tech[0]);
						});
						var techRankArray = [];
						_.forEach(techTotalCount, function(region){
							techRankArray.push(region[0]);
						});
						var tempArr=[];
						_.forEach(technologies, function(technology){
							_.forEach(techRankArray, function(region){
								((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]);
							});
							tempArr.push({'data': techData[technology], 'name':technology});
						});
					var valueDataforChart = tempArr;
					IBbyRegionChart.IBbyRegionChartHistory(valueDataforChart,regions);
                    
					$("#IB-by-Region-His-Data").DataTable({
						"bPaginate": true,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": true,
						"iDisplayLength": 5,
						"bInfo":true,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});	
					endResult['IBbyRegionHistDataTable1']=true;
					endResult['IBbyRegionHistDataTable2']=false;
				}
				else
				{
					endResult['IBbyRegionHistDataTable1']=false;
					endResult['IBbyRegionHistDataTable2']=true;
				}
				return endResult;
			},
			

			excelDownload: function(id){
			    	var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 });
				 var tableToExcel = (function() {
					 var ctx,subHeader;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
	                      if (!table.nodeType) 
	                             table = document.getElementById(id);
	                      var excelContent = '';
	                      var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                      if(id ==='IB-by-Region-Cur-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>IB by Region Current Data</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='IB-by-Region-His-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>IB by Region History Data</span>"+
	                          "</td></tr>";
                    	  }
	                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                      excelContent = excelContent + subHeader;
	                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
	                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                      var tdNumber = "<td style='mso-number-format:0'>";
	                      excelContent =excelContent + '<tr>';
	                      var flag = 0;
	                        _.forEach(columns, function(column){
	                               if(columns[0]!== 'null' && flag === 0){
	                                      excelContent = excelContent + th + column + '</th>';
	                                      flag++;
	                               }else {
	                                      excelContent = excelContent + th + column +'($K)' + '</th>';
	                               }
	                        });
	                      excelContent = excelContent + '</tr>';
	                      _.forEach(getDataFromDT, function(row){
	                             excelContent =excelContent + '<tr>';
	                             _.forEach(row, function(rowData){
	                            	 rowData = rowData.replace(/K/g, "");
	                                  if (rowData.includes('$')) {
	                                	  rowData = rowData.substring(1,rowData.length);
	                                  }
	                                  if((/^[0-9]{0,}$/).test(rowData))
                                          excelContent = excelContent + tdNumber + rowData + '</td>';
                                   else
                                          excelContent = excelContent + '<td>' + rowData + '</td>';
	                             });
	                             excelContent =excelContent + '</tr>';
	                      });
	                     excelContent =excelContent + '<tr>';
	                      excelContent =excelContent + '</tr>';
	                      if(id ==='IB-by-Region-Cur-Data')
                    	  {
	                    	  ctx = {worksheet:'IB by Region Current Data' , table: excelContent};
		                      document.getElementById('IBbyRegionCurData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('IBbyRegionCurData').download = 'IB-by-Region-Cur-Data.xls';
                    	  }
                      if(id==='IB-by-Region-His-Data'){
	                    	  ctx = {worksheet: 'IB by Region History Data' , table: excelContent};
		                      document.getElementById('IBbyRegionHistData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('IBbyRegionHistData').download = 'IB-by-Region-His-Data.xls';
                      }
	                }
	                })();
	                tableToExcel(id);
				return null;
			}
		}
	}]);
});
