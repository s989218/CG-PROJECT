define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('RevenueDataNetworkService', ['$q','$http','$rootScope',function($q, $http,$rootScope) {
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
				}).then(function (response) {
					deferred.resolve(response.data);
				}, function (status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
        return {
			/* Network Call */
			getAllMetricsData: function(jsonData){
				var request = {
					"dataType"    : "json",
					"method"      : "POST",
                    "contentType" : "application/json",
					"data"        : jsonData,
					'url': 'connect/fms/getAllMetricsData/'+$rootScope.businessSegment,		
//					'url': 'connect/fms/getAllMetricsData/DTS',
					};
				return networkCall(request);
			},
			returnDataObjects: function(response){
                var regionDataObj = {};
                regionDataObj['IBObyRegionDataCur']         = response.currentData.ibo_by_region;
                regionDataObj['IBObyRegionDataHis']         = response.historyData.ibo_by_region;
                regionDataObj['revDollarbyRegionDataCur']   = response.currentData.rev_dollar_by_region;
                regionDataObj['revDollarbyRegionDataHis']   = response.historyData.rev_dollar_by_region;
                regionDataObj['IBbyRegionDataCur']          = response.currentData.dollar_by_ib;
                regionDataObj['IBbyRegionDataHis']          = response.historyData.dollar_by_ib;
                regionDataObj['OpexPenetrationDataCur']     = response.currentData.fleet_pen_f2f;
                regionDataObj['OpexPenetrationDataHis']     = response.historyData.fleet_pen_f2f;
                regionDataObj['fleetPenetrationDataCur']    = response.currentData.fleet_penetration;
                regionDataObj['fleetPenetrationDataHis']    = response.historyData.fleet_penetration;
                regionDataObj['fleetCoverageDataCur']       = response.currentData.fleet_coverage;
                regionDataObj['fleetCoverageDataHis']       = response.historyData.fleet_coverage;
                regionDataObj['CaloricbyRegionDataCur']     = response.currentData.caloric_index;
                regionDataObj['CaloricbyRegionDataHis']     = response.historyData.caloric_index;
                regionDataObj['ConversionIndexDataCur']     = response.currentData.conversion_index;
                regionDataObj['ConversionIndexDataHis']     = response.historyData.conversion_index;
                regionDataObj['IboByTechnologyDataCur']     = response.currentData.ibo_by_tech;
                regionDataObj['IboByTechnologyDataHis']     = response.historyData.ibo_by_tech;
                regionDataObj['IBNbyRegionDataCur']         = response.currentData.ib_by_region;
                regionDataObj['IBNbyRegionDataHis']         = response.historyData.ib_by_region;
                regionDataObj['IbNoByTechnologyDataCur']    = response.currentData.ib_by_tech;
                regionDataObj['IbNoByTechnologyDataHis']    = response.historyData.ib_by_tech;
                regionDataObj['fleetCoverageAverageDTO']    = response.averageData.fleet_coverage;
                regionDataObj['fleetPenetrationAverageDTO'] = response.averageData.fleet_penetration;
                regionDataObj['fltPentrtnF2FAverageDTO']    = response.averageData.fleet_pen_f2f;
                regionDataObj['dollarByIBAverageDTO']       = response.averageData.dollar_by_ib;
                regionDataObj['caloricIndexAverageDTO']     = response.averageData.caloric_index;
                regionDataObj['conversionIndexAverageDTO']  = response.averageData.conversion_index;
                regionDataObj['iboByRegionAverageDTO']      = response.averageData.ibo_by_region;
                regionDataObj['revDollarByRegAverageDTO']   = response.averageData.rev_dollar_by_region;
                regionDataObj['ibnByRegionAverageDTO']      = response.averageData.ib_by_region;
                regionDataObj['iboByTechnologyAverageDTO']  = response.averageData.ibo_by_tech;
                regionDataObj['ibNoByTechnologyAverageDTO'] = response.averageData.ib_by_tech;
                regionDataObj['dollarByIBAverage']          = response.averageBasedOnYear.dollar_by_ib;
                regionDataObj['opexPenF2FAverage']          = response.averageBasedOnYear.fleet_pen_f2f;
                regionDataObj['fleetPenAverage']            = response.averageBasedOnYear.fleet_penetration;
                regionDataObj['fleetCoverageAverage']       = response.averageBasedOnYear.fleet_coverage;
                regionDataObj['caloricIndexAverage']        = response.averageBasedOnYear.caloric_index;
                regionDataObj['conversionIndexAverage']     = response.averageBasedOnYear.conversion_index;
                regionDataObj['iboByTechAverage']           = response.averageBasedOnYear.ibo_by_tech;
                regionDataObj['ibByRegionAverage']          = response.averageBasedOnYear.ib_by_region;
                regionDataObj['ibByTechAverage']            = response.averageBasedOnYear.ib_by_tech;
                regionDataObj['iboByRegionAverage']         = response.averageBasedOnYear.ibo_by_region;
                regionDataObj['revDollarByRegAverage']      = response.averageBasedOnYear.rev_dollar_by_region;
                regionDataObj['partsPenetrationCur']        = response.currentData.parts_fleet_penetration;
                regionDataObj['partsPenetrationHis']        = response.historyData.parts_fleet_penetration;
                regionDataObj['partsPenetrationAvg']        = response.averageData.parts_fleet_penetration;
                regionDataObj['partsPenYearAvgDTO']     	= response.averageBasedOnYear.parts_fleet_penetration;
                regionDataObj['repairsPenetrationCur']      = response.currentData.repairs_fleet_penetration;
                regionDataObj['repairsPenetrationHis']      = response.historyData.repairs_fleet_penetration;
                regionDataObj['repairsPenetrationAvg']      = response.averageData.repairs_fleet_penetration;
                regionDataObj['repairsPenYearAvgDTO']     	= response.averageBasedOnYear.repairs_fleet_penetration;
                regionDataObj['servicePenetrationCur']      = response.currentData.svcs_fleet_penetration;
                regionDataObj['servicePenetrationHis']      = response.historyData.svcs_fleet_penetration;
                regionDataObj['servicePenetrationAvg']      = response.averageData.svcs_fleet_penetration;
                regionDataObj['servicePenYearAvgDTO']     	= response.averageBasedOnYear.svcs_fleet_penetration;
                return regionDataObj;
			},
            getPenetrationDashboardData : function(jsonData) {
                var request = {
                    "dataType"    : "json",
					"method"      : "POST",
                    "contentType" : "application/json",
					"data"        : jsonData,
					"url"         : "connect/fms/penetrationDashboard/"+ $rootScope.businessSegment
                };
				return networkCall(request);
			},
            returnDashboardDataObjects: function(response) {
				var dataObject = {};
                dataObject['StateCoordinates']          = response.StateCoordinates;
				dataObject['UnperformingRegCount']      = response.UnperformingRegCount;
	        	dataObject['UnperformingCountryCount']  = response.UnperformingCountryCount;
				dataObject['UnperformingSitesCount']    = response.UnperformingSitesCount;
	        	dataObject['UnmappedSitesCount']        = response.UnmappedSitesCount;
				dataObject['IBOByReg']                  = response.IBOByReg;
                dataObject['siteInfo']                  = response.siteInfo;
				return dataObject;
			},
            getPenetrationTopSitesData : function(jsonData) {
                var request = {
                    "dataType"    : "json",
					"method"      : "POST",
                    "contentType" : "application/json",
					"data"        : jsonData,
					"url"         : "connect/fms/getPenMetricsTopSitesByRegion"
                };
				return networkCall(request);
			},
			getManagersForTopSites : function(jsonData) {
                var request = {
                    "dataType"    : "json",
					"method"      : "POST",
                    "contentType" : "application/json",
					"data"        : jsonData,
					"url"         : "connect/fms/getManagersForTopSites/"+$rootScope.businessSegment
                };
				return networkCall(request);
			},
            excelDownload: function(id){
			    var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 });
				 var tableToExcel = (function() {
					 var ctx,subHeader;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
                              if (!table.nodeType) 
                                     table = document.getElementById(id);
                              var excelContent = '';
                              var header = "<tr><td colspan='21' style='text-align:center'>" +
                                            "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
                                            "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";

                                   subHeader="<tr><td colspan='21' style='text-align:center'>" +
                                  "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Installed Units</span>"+
                                  "</td></tr>";

                              excelContent = excelContent + header + '<tr><td colspan="21" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
                              excelContent = excelContent + subHeader;
                              var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
                              
                              var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
                              
                              excelContent =excelContent + '<tr>';
                              _.forEach(columns, function(column){
                            	  if(column === "Total IBO" || column !== "Sub-Business") {
                                      excelContent = excelContent + th + column + '</th>';      
                                  }
                              });
                              
                              excelContent = excelContent + th + 'Sub-Business' + '</th>'; 
                              excelContent = excelContent + '</tr>';
                              
                              var dataArr = [];
                              _.forEach(getDataFromDT, function(row, key){
                                  var dataObj = {};
                                 _.forEach(row, function(rowData, rowKey){
                                     if(rowKey === "serialNumber") {
                                         dataObj["1"] = rowData;
                                     } else if(rowKey === "siteName") {
                                         dataObj["2"] = rowData;
                                     } else if(rowKey === "custName") {
                                         dataObj["3"] = rowData;
                                     } else if(rowKey === "siteCustCountry") {
                                         dataObj["4"] = rowData;
                                     } else if(rowKey === "prodExcPL") {
                                         dataObj["5"] = rowData;
                                     } else if(rowKey === "marketSegmentDesc") {
                                         dataObj["6"] = rowData;
                                     } else if(rowKey === "siteCustCity") {
                                         dataObj["7"] = rowData;
                                     } else if(rowKey === "ibDataRegion") {
                                         dataObj["8"] = rowData;
                                     } else if(rowKey === "technologyDescOG") {
                                         dataObj["9"] = rowData;
                                     } else if(rowKey === "unitShipData") {
                                         dataObj["10"] = rowData;
                                     } else if(rowKey === "estServiceHrsCount") {
                                         dataObj["11"] = rowData;
                                     } else if(rowKey === "serviceRelationDesc") {
                                         dataObj["12"] = rowData;
                                     } else if(rowKey === "avTot") {
                                         dataObj["13"] = rowData;
                                     } else if(rowKey === "equipmentModel") {
                                         dataObj["14"] = rowData;
                                     } else if(rowKey === "unitCustomerName") {
                                         dataObj["15"] = rowData;
                                     } else if(rowKey === "eventDate") {
                                         dataObj["16"] = rowData;
                                     } else if(rowKey === "eventType") {
                                         dataObj["17"] = rowData;
                                     } else if(rowKey === "eventStatus") {
                                         dataObj["18"] = rowData;
                                     } else if(rowKey === "equipmentCode") {
                                         dataObj["19"] = rowData;
                                     } else if(rowKey === "equipmentEngDesc") {
                                         dataObj["20"] = rowData;
                                     } 
                                 });
                                 dataArr.push(dataObj);
                              });
                              
                              _.forEach(dataArr, function(row, key){
                                 excelContent =excelContent + '<tr>';
                                 _.forEach(row, function(rowData, rowKey){
                                     if(rowData !== null) {
                                        excelContent = excelContent + '<td>' + rowData + '</td>'; 
                                     } else {
                                        excelContent = excelContent + '<td>' + '' + '</td>'; 
                                     }
                                 });
                                 excelContent = excelContent + '<td>' + 'DP&S' + '</td>';    
                                 excelContent = excelContent + '</tr>';
                              });

                              ctx = {worksheet:'Installed Units' , table: excelContent};
                              document.getElementById('installUnitsData').href = (uri + base64(format(template, ctx)));
                              document.getElementById('installUnitsData').download = 'Installed-Units.xls';
                        }
	                })();
	                tableToExcel(id);
				return null;
			}
        };
    }]);
});
