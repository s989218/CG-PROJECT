define(['angular', '../../../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('SegmentChartService', [function() {
    	var chart,calChart,chart2,calChart2,chart8,chart9,chart10,chart11,chart8Hist,chart9Hist,chart11Hist,chart10Hist;
		return{
			SegmentPenetrationChart: function (valueData, headerCurLst,header,total,id){
				if(id === 'segmentContainer6'){
					calChart= new Highcharts.Chart({
					    chart: {
					      renderTo: id,
						    type: 'column'
					    },	
								title: {
					            text: ''
					        },
					        subtitle: {
					            text: ''
					        },
					        xAxis: {
					            categories: headerCurLst,
					            crosshair: true
					        },
					        yAxis: {
					            title: {
					                text: 'Caloric Index'
					            }
					        },
							legend: {
								layout: 'horizontal',
								align: 'right',
								verticalAlign: 'bottom',
								floating: false
					        },
					        tooltip: {
					            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
					            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
					                '<td style="padding:0"><b>{point.y}</b></td></tr>',
					            footerFormat: '</table>',
					            shared: true,
					            useHTML: true
					        },
					        plotOptions: {
					            column: {
					                pointPadding: 0.2,
					                borderWidth: 0,
					                dataLabels: {
					                    enabled: true,
					                    formatter: function () {
					                    	return (this.y);
					                    }
					                }
					            }
					        },
							credits: {
								enabled: false
							},
					        series: valueData,
					        exporting: {
				                chartOptions: {
				                    chart: {
				                        events: {
				                            load: function () {
				                                Highcharts.each(this.series, function (series) {
				                                    series.update({
				                                        dataLabels: {
				                                            enabled: true,				                                                 
				                                            style: {
				                                                fontSize: '6px'
				                                            }  
				                                        } 
				                                    }, false);
				                                    
				                                    series.xAxis.update({
				                                        labels: {
				                                            style: {
				                                                fontSize: '6px'
				                                            }
				                                        }
				                                    });
				                                    series.yAxis.update({
				                                        labels: {
				                                            style: {
				                                                fontSize: '6px'
				                                            }
				                                        }
				                                    });
				                                });
				                                this.redraw(false);
				                            }
				                        }
				                    },   
				                    legend:{
				                        enabled:true,
				                        itemStyle: {
				                        	fontSize: '6px'
				                        }
				                    }
				                }
				            }
					 }, function(chart) {
							for(var t=0;t<header.length&&t<total.length;t++)
							{
							chart.renderer.text('<span><span1 style="color: rgb(124, 181, 236); font-weight:bold">'+header[t]+': </span1> <span2  style="color: black; font-weight:bold">'+total[t]+'</span2></span>', 70, 375)
					            .css({
					                fontSize: '12px',
					            })
					            .add();
							}
					    });
				}else{
				chart= new Highcharts.Chart({
					    chart: {
					      renderTo: id,
						    type: 'column'
					    },	
								title: {
					            text: ''
					        },
					        subtitle: {
					            text: ''
					        },
					        xAxis: {
					            categories: headerCurLst,
					            crosshair: true
					        },
					        yAxis: {
					            title: {
					                text: '%'
					            }
					        },
							legend: {
								layout: 'horizontal',
								align: 'right',
								verticalAlign: 'bottom',
								floating: false
					        },
					        tooltip: {
					            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
					            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
					                '<td style="padding:0"><b>{point.y} %</b></td></tr>',
					            footerFormat: '</table>',
					            shared: true,
					            useHTML: true
					        },
					        plotOptions: {
					            column: {
					                pointPadding: 0.2,
					                borderWidth: 0,
					                dataLabels: {
					                    enabled: true,
					                    formatter: function () {
					                    	return (this.y+"%");
					                    }
					                }
					            }
					        },
							credits: {
								enabled: false
							},
					        series: valueData,
					        exporting: {
				                chartOptions: {
				                    chart: {
				                        events: {
				                            load: function () {
				                                Highcharts.each(this.series, function (series) {
				                                    series.update({
				                                        dataLabels: {
				                                            enabled: true,				                                                 
				                                            style: {
				                                                fontSize: '6px'
				                                            }  
				                                        } 
				                                    }, false);
				                                    
				                                    series.xAxis.update({
				                                        labels: {
				                                            style: {
				                                                fontSize: '6px'
				                                            }
				                                        }
				                                    });
				                                    series.yAxis.update({
				                                        labels: {
				                                            style: {
				                                                fontSize: '6px'
				                                            }
				                                        }
				                                    });
				                                });
				                                this.redraw(false);
				                            }
				                        }
				                    },   
				                    legend:{
				                        enabled:true,
				                        itemStyle: {
				                        	fontSize: '6px'
				                        }
				                    }
				                }
				            }
					 }, function(chart) {
							for(var t=0;t<header.length&&t<total.length;t++)
							{
							chart.renderer.text('<span><span1 style="color: rgb(124, 181, 236); font-weight:bold">'+header[t]+': </span1> <span2  style="color: black; font-weight:bold">'+total[t]+'%</span2></span>', 70, 375)
					            .css({
					                fontSize: '12px',
					            })
					            .add();
							}
					    });
				}
					if(id === 'segmentContainer3'){
						 chart8 = chart
					}else if(id === 'segmentContainer4'){
						 chart9 = chart
					}else if(id === 'segmentContainer5'){
						 chart10 = chart
					}else if(id === 'segmentContainer6'){
						chart11 = calChart
					}
				},
				
				
				exportChart : function(type,name,divId){
					if(type === 'JPEG'){
						if(divId === 'segmentContainer3'){
							chart8.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
						}
						else if(divId === 'segmentContainer4'){
							 chart9.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
						}
						else if(divId === 'segmentContainer5'){
							 chart10.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
						}
						else if(divId === 'segmentContainer6'){
							 chart11.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
						}
					}
			},
			segmentPenetrationHistoryChart: function (valueData, headerCurLst,id){
				if(id === 'segmentContainer6History'){
					calChart2= new Highcharts.Chart({
					    chart: {
					      renderTo: id
					    },	
								title: {
					            text: ''
					        },
					        subtitle: {
					            text: ''
					        },
					        xAxis: {
					            categories: headerCurLst,
					            crosshair: true
					        },
					        yAxis: {
					            title: {
					                text: 'Caloric Index'
					            }
					        },
							legend: {
								layout: 'horizontal',
								align: 'right',
								verticalAlign: 'bottom',
								floating: false
					        },
					        tooltip: {
					            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
					            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
					                '<td style="padding:0"><b>{point.y}</b></td></tr>',
					            footerFormat: '</table>',
					            shared: true,
					            useHTML: true
					        },
					        plotOptions: {
					            column: {
					            	 stacking: 'normal',
					                pointPadding: 0.2,
					                borderWidth: 0
					            }
					        },
							credits: {
								enabled: false
							},
					        series: valueData,
					        exporting: {
				                chartOptions: {
				                    chart: {
				                        events: {
				                            load: function () {
				                                Highcharts.each(this.series, function (series) {
				                                    series.update({
				                                        dataLabels: {
				                                            enabled: true,				                                                 
				                                            style: {
				                                                fontSize: '6px'
				                                            }  
				                                        } 
				                                    }, false);
				                                    
				                                    series.xAxis.update({
				                                        labels: {
				                                            style: {
				                                                fontSize: '6px'
				                                            }
				                                        }
				                                    });
				                                    series.yAxis.update({
				                                        labels: {
				                                            style: {
				                                                fontSize: '6px'
				                                            }
				                                        }
				                                    });
				                                });
				                                this.redraw(false);
				                            }
				                        }
				                    },   
				                    legend:{
				                        enabled:true,
				                        itemStyle: {
				                        	fontSize: '6px'
				                        }
				                    }
				                }
				            }
					 });
				}else{
					chart2= new Highcharts.Chart({
						    chart: {
						      renderTo: id
						    },	
									title: {
						            text: ''
						        },
						        subtitle: {
						            text: ''
						        },
						        xAxis: {
						            categories: headerCurLst,
						            crosshair: true
						        },
						        yAxis: {
						            title: {
						                text: '%'
						            }
						        },
								legend: {
									layout: 'horizontal',
									align: 'right',
									verticalAlign: 'bottom',
									floating: false
						        },
						        tooltip: {
						            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
						            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
						                '<td style="padding:0"><b>{point.y} %</b></td></tr>',
						            footerFormat: '</table>',
						            shared: true,
						            useHTML: true
						        },
						        plotOptions: {
						            column: {
						            	 stacking: 'normal',
						                pointPadding: 0.2,
						                borderWidth: 0
						            }
						        },
								credits: {
									enabled: false
								},
						        series: valueData,
						        exporting: {
					                chartOptions: {
					                    chart: {
					                        events: {
					                            load: function () {
					                                Highcharts.each(this.series, function (series) {
					                                    series.update({
					                                        dataLabels: {
					                                            enabled: true,				                                                 
					                                            style: {
					                                                fontSize: '6px'
					                                            }  
					                                        } 
					                                    }, false);
					                                    
					                                    series.xAxis.update({
					                                        labels: {
					                                            style: {
					                                                fontSize: '6px'
					                                            }
					                                        }
					                                    });
					                                    series.yAxis.update({
					                                        labels: {
					                                            style: {
					                                                fontSize: '6px'
					                                            }
					                                        }
					                                    });
					                                });
					                                this.redraw(false);
					                            }
					                        }
					                    },   
					                    legend:{
					                        enabled:true,
					                        itemStyle: {
					                        	fontSize: '6px'
					                        }
					                    }
					                }
					            }
						 });
					}
					if(id === 'segmentContainer3Hist'){
						 chart8Hist = chart2
					}else if(id === 'segmentContainer4Hist'){
						 chart9Hist = chart2
					}else if(id === 'segmentContainer5History'){
						 chart10Hist = chart2
					}else if(id === 'segmentContainer6History'){
						 chart11Hist = calChart2
					}
				},
				exportChartHist : function(type,name,divId){
				if(type === 'JPEG'){
					if(divId === 'segmentContainer3Hist'){
						chart8Hist.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}else if(divId === 'segmentContainer4Hist'){
						chart9Hist.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}else if(divId === 'segmentContainer5History'){
						chart10Hist.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}else if(divId === 'segmentContainer6History'){
						chart11Hist.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}
				}
			}
		}
    }]);
});
    