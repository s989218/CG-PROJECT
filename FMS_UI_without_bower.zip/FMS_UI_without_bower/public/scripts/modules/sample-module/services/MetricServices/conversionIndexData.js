define(['angular', '../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('ConversionIndexDataService', ['ConversionIndexChartService',function(ConversionIndexChartService) {
		return{
			updateConversionIndexCurData:function($scope){
				var valueData = [], data = [], item = {} , tmp, name = "", curData, tdCHtml = "", headerCurLst = [], tmpCurLst = [],
				total = [], header = [], endResults={};
					for(var i=0;i<$scope.ConversionIndexDataCur.length;i++)
					{	
						curData = $scope.ConversionIndexDataCur[i].quarter;
						if(tmp==null && ($scope.ConversionIndexDataCur[i].region).toUpperCase()!=="TOTAL")
						{	
							tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.ConversionIndexDataCur[i].year+" - "+$scope.ConversionIndexDataCur[i].quarter)+"</td><td class='centerTxt'>"+$scope.ConversionIndexDataCur[i].value+"%</td>";
							tmp = $scope.ConversionIndexDataCur[i].quarter;
							name = ($scope.ConversionIndexDataCur[i].year+" - "+$scope.ConversionIndexDataCur[i].quarter);
							tmpCurLst.push($scope.ConversionIndexDataCur[i].region);
							data = [];
							data.push(parseFloat($scope.ConversionIndexDataCur[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							item["name"] = name;
							item["data"] = data;
							valueData.push(item);
							if(headerCurLst.length===0)
							{
								headerCurLst = tmpCurLst.slice();
							}
							if(($scope.ConversionIndexDataCur[i].region).toUpperCase()!=="TOTAL")
							{
								tdCHtml = tdCHtml + "</tr><tr><td class='centerTxt'>"+($scope.ConversionIndexDataCur[i].year+" - "+$scope.ConversionIndexDataCur[i].quarter)+"</td><td class='centerTxt'>"+$scope.ConversionIndexDataCur[i].value+"%</td>";
								tmp = $scope.ConversionIndexDataCur[i].quarter;
								name = ($scope.ConversionIndexDataCur[i].year+" - "+$scope.ConversionIndexDataCur[i].quarter);
								data = [];
								data.push(parseFloat($scope.ConversionIndexDataCur[i].value));
							}
						}
						else if(curData===tmp && ($scope.ConversionIndexDataCur[i].region).toUpperCase()!=="TOTAL")
						{
							tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.ConversionIndexDataCur[i].value+"%</td>";
							tmp = $scope.ConversionIndexDataCur[i].quarter;
							name = ($scope.ConversionIndexDataCur[i].year+" - "+$scope.ConversionIndexDataCur[i].quarter);
							data.push(parseFloat($scope.ConversionIndexDataCur[i].value));
							tmpCurLst.push($scope.ConversionIndexDataCur[i].region);
						}
						if(($scope.ConversionIndexDataCur[i].region).toUpperCase()==="TOTAL")
						{	
							header.push($scope.ConversionIndexDataCur[i].quarter);
							total.push(parseFloat($scope.ConversionIndexDataCur[i].value));
						}
					}
					tdCHtml = tdCHtml + "</tr>";
					if(data.length>0)
					{
						item["name"] = name;
						item["data"] = data;
						valueData.push(item);
						if(headerCurLst.length===0)
						{
							headerCurLst = tmpCurLst.slice();
						}
					}
					var thHtml = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerCurLst,function(value){
						thHtml = thHtml + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtml = thHtml + "</tr>";
                
                    if ( $.fn.DataTable.isDataTable('#ConversionIndex-Cur-Data') ) {
                        $('#ConversionIndex-Cur-Data').DataTable().destroy();
                    }

                    $('#ConversionIndex-Cur-Data tbody').empty();
                
					$(".ConversionIndCurHeader").html(thHtml);
					$(".ConversionIndCurData").html(tdCHtml);
                
					ConversionIndexChartService.ConversionIndexChart(valueData,headerCurLst,header,total);
                
					$("#ConversionIndex-Cur-Data").DataTable( {
						"bPaginate": false,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": false,
						"iDisplayLength": 10,
						"bInfo":false,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
				if(total>0)
				{
					endResults['ConversionIndexCurDataTable1']=true;
					endResults['ConversionIndexCurDataTable2']=false;
				}
				else
				{
					endResults['ConversionIndexCurDataTable1']=false;
					endResults['ConversionIndexCurDataTable2']=true;
				}
				return endResults;
			},
			updateConversionIndexHistData:function($scope){
				var tmp,name = "",curData,tdAHtml = "",tdHtml = "",valueDataHist = [], dataHist = [],itemHist = {}, headerLst = [], tmpLst = [],endResult={}, tdAvghtml = "";
				if($scope.ConversionIndexDataHis.length>0)
				{
					for(var i=0;i<$scope.ConversionIndexDataHis.length;i++)
					{
						curData = $scope.ConversionIndexDataHis[i].year+" - "+$scope.ConversionIndexDataHis[i].quarter;
						if(tmp==null)
						{
							tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.ConversionIndexDataHis[i].year+" - "+$scope.ConversionIndexDataHis[i].quarter)+"</td><td class='centerTxt'>";
                            
                             if ($scope.ConversionIndexDataHis[i].value === "-9999" && ($scope.ConversionIndexDataHis[i].region === "Asia Pacific" || $scope.ConversionIndexDataHis[i].region === "MENAT")) {
                                $scope.ConversionIndexDataHis[i].value = "";
                                tdHtml = tdHtml + $scope.ConversionIndexDataHis[i].value;
                            } else {
                                tdHtml = tdHtml + $scope.ConversionIndexDataHis[i].value+"%";
                            }

                            tdHtml = tdHtml + "</td>";
							tmp = $scope.ConversionIndexDataHis[i].year+" - "+$scope.ConversionIndexDataHis[i].quarter;
							name = ($scope.ConversionIndexDataHis[i].year+" - "+$scope.ConversionIndexDataHis[i].quarter);
							tmpLst.push($scope.ConversionIndexDataHis[i].region);
							dataHist = [];
							dataHist.push(parseFloat($scope.ConversionIndexDataHis[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							itemHist["name"] = name;
							itemHist["data"] = dataHist;
							valueDataHist.push(itemHist);
							if(headerLst.length===0)
							{
								headerLst = tmpLst.slice();
							}
							tdHtml = tdHtml + "</tr><tr><td class='centerTxt'>"+($scope.ConversionIndexDataHis[i].year+" - "+$scope.ConversionIndexDataHis[i].quarter)+"</td><td class='centerTxt'>";
                            
                            if ($scope.ConversionIndexDataHis[i].value === "-9999" && ($scope.ConversionIndexDataHis[i].region === "Asia Pacific" || $scope.ConversionIndexDataHis[i].region === "MENAT")) {
                                $scope.ConversionIndexDataHis[i].value = "";
                                tdHtml = tdHtml + $scope.ConversionIndexDataHis[i].value;
                            } else {
                                tdHtml = tdHtml + $scope.ConversionIndexDataHis[i].value+"%";
                            }

                            tdHtml = tdHtml + "</td>";
							tmp = $scope.ConversionIndexDataHis[i].year+" - "+$scope.ConversionIndexDataHis[i].quarter;
							name = ($scope.ConversionIndexDataHis[i].year+" - "+$scope.ConversionIndexDataHis[i].quarter);
							dataHist = [];
							dataHist.push(parseFloat($scope.ConversionIndexDataHis[i].value));
						}
						else if(curData===tmp)
						{
							tdHtml = tdHtml + "<td class='centerTxt'>";
                            
                            if ($scope.ConversionIndexDataHis[i].value === "-9999" && ($scope.ConversionIndexDataHis[i].region === "Asia Pacific" || $scope.ConversionIndexDataHis[i].region === "MENAT")) {
                                $scope.ConversionIndexDataHis[i].value = "";
                                tdHtml = tdHtml + $scope.ConversionIndexDataHis[i].value;
                            } else {
                                tdHtml = tdHtml + $scope.ConversionIndexDataHis[i].value+"%";
                            }

                            tdHtml = tdHtml + "</td>";
							tmp = $scope.ConversionIndexDataHis[i].year+" - "+$scope.ConversionIndexDataHis[i].quarter;
							name = ($scope.ConversionIndexDataHis[i].year+" - "+$scope.ConversionIndexDataHis[i].quarter);
							tmpLst.push($scope.ConversionIndexDataHis[i].region);
							dataHist.push(parseFloat($scope.ConversionIndexDataHis[i].value));
						}
					}
                    
                    if(headerLst.length===0)
                    {
                        headerLst = tmpLst.slice();
                    }
                     
					for(i=0;i<$scope.conversionIndexAverage.length;i++)
					{
                       
						curData = $scope.conversionIndexAverage[i].year;
						if(tmp==null)
						{
                            if ($scope.conversionIndexAverage[i].average === "-9999.00" && ($scope.conversionIndexAverage[i].region === "Asia Pacific" || $scope.conversionIndexAverage[i].region === "MENAT")) {
                                tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+$scope.conversionIndexAverage[i].year)+"</td><td class='centerTxt'> </td>";
                            } else {
                                tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+$scope.conversionIndexAverage[i].year)+"</td><td class='centerTxt'>"+$scope.conversionIndexAverage[i].average+"%</td>";    
                            }
                            
							tmp = $scope.conversionIndexAverage[i].year;
						}
						else if(curData!==null && curData!==tmp)
						{ 
                            if ($scope.conversionIndexAverage[i].average === "-9999.00" && ($scope.conversionIndexAverage[i].region === "Asia Pacific" || $scope.conversionIndexAverage[i].region === "MENAT")) {
                                tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+$scope.conversionIndexAverage[i].year)+"</td><td class='centerTxt'> </td>";
                            } else {
                                tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+$scope.conversionIndexAverage[i].year)+"</td><td class='centerTxt'>"+$scope.conversionIndexAverage[i].average+"%</td>";    
                            }
							
							tmp = $scope.conversionIndexAverage[i].year;
						}
						else if(curData===tmp )
						{
                            if ($scope.conversionIndexAverage[i].average === "-9999.00" && ($scope.conversionIndexAverage[i].region === "Asia Pacific" || $scope.conversionIndexAverage[i].region === "MENAT")) {
                                tdAHtml = tdAHtml + "<td class='centerTxt'> </td>";
                            } else {
                                tdAHtml = tdAHtml + "<td class='centerTxt'>"+$scope.conversionIndexAverage[i].average+"%</td>";    
                            }
							
							tmp = $scope.conversionIndexAverage[i].year;
						}
					}
					for(i=0;i<$scope.conversionIndexAverageDTO.length;i++)
					{
						tdAvghtml=tdAvghtml + "<td class='centerTxt'>" + parseFloat($scope.conversionIndexAverageDTO[i].average).toFixed(2) +"%</td>";
					}
					var avgHtml = "<tr>"+ "<td class='centerTxt'>"+"Average"+tdAvghtml +"</tr>";
					tdHtml = avgHtml + tdAHtml + tdHtml + "</tr>";
					if(dataHist.length>0)
					{
						itemHist["name"] = name;
						itemHist["data"] = itemHist;
						valueDataHist.push(itemHist);
					}
					$(".ConversionIndHisHeader").html('');
					var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(value){

						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtmlHist = thHtmlHist + "</tr>";
                    
                    if ( $.fn.DataTable.isDataTable('#ConversionIndex-His-Data') ) {
                        $('#ConversionIndex-His-Data').DataTable().destroy();
                    }

                    $('#ConversionIndex-His-Data tbody').empty();
                    
					$(".ConversionIndHisHeader").html(thHtmlHist);
					$(".ConversionIndHisData").html(tdHtml);
					
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					
					var  regionData={}, techSummary ={}, techData={};                                                                      
					var regions = [],  technologies = [], totalCount={};
					/* All Regions and Technologies */
					_.forEach($scope.ConversionIndexDataHis, function(responseObj){
						if(technologies.indexOf(responseObj.region) === -1 && responseObj.region!==null && responseObj.region!=='Total'){
							technologies.push(responseObj.region);
						}
						if(regions.indexOf(responseObj.year+"-"+responseObj.quarter) === -1){
							regions.push(responseObj.year+"-"+responseObj.quarter);
						}  
					});
                    
                    regions.reverse();
                    
					var techTotalCount = {};
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(techSummary, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCount, [region], 0);
							}
						});
					});                           
					_.forEach(technologies, function(technology){
						techData[technology] = [];
						var count = 0;
						_.forEach(regions, function(region){
							if(region!==null){
								(techData[technology])[count] = 0;
								count ++;
							}
						});
					});           
					_.forEach($scope.ConversionIndexDataHis, function(responseObj){
						if(responseObj.year+"-"+responseObj.quarter!==null && responseObj.region!=='Total'){
							techTotalCount[responseObj.year+"-"+responseObj.quarter]=techTotalCount[responseObj.year+"-"+responseObj.quarter]+parseFloat(responseObj.value);
							createNestedObject(techSummary, [responseObj.region, responseObj.year+"-"+responseObj.quarter], parseFloat(responseObj.value));
						}
					});
					techTotalCount =_.pairs(techTotalCount);
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					var techRankArray = [];
					_.forEach(techTotalCount, function(region){
						techRankArray.push(region[0]);
					});
					var tempArr=[];
					_.forEach(technologies, function(technology){
						_.forEach(techRankArray, function(region){
							((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]);
						});
						tempArr.push({'data': techData[technology], 'name':technology});
					});
					var valueDataforChart = tempArr;
					ConversionIndexChartService.ConversionIndexChartHistory(valueDataforChart,regions);
					
					$("#ConversionIndex-His-Data").DataTable( {
						"bPaginate": true,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": true,
						"iDisplayLength": 5,
						"bInfo":true,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
					endResult['ConversionIndexHistDataTable1']=true;
					endResult['ConversionIndexHistDataTable2']=false;
				}
				else
				{
					endResult['ConversionIndexHistDataTable1']=false;
					endResult['ConversionIndexHistDataTable2']=true;
				}
				return endResult;
			},

			excelDownload: function(id){
			    	var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 });
				 var tableToExcel = (function() {
					 var ctx,subHeader;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
	                      if (!table.nodeType) 
	                             table = document.getElementById(id);
	                      var excelContent = '';
	                      var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                      if(id ==='ConversionIndex-Cur-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Conversion Index Current Data</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='ConversionIndex-His-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Conversion Index History Data</span>"+
	                          "</td></tr>";
                    	  }
	                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                      excelContent = excelContent + subHeader;
	                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
	                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                      var tdNumber = "<td style='mso-number-format:0'>";
	                      excelContent =excelContent + '<tr>';
	                      var flag = 0;
	                      _.forEach(columns, function(column){
                              if(columns[0]!== 'null' && flag === 0){
                                     excelContent = excelContent + th + column + '</th>';
                                     flag++;
                              }else {
                                     excelContent = excelContent + th + column +'(%)' + '</th>';
                              }
	                      });
	                      excelContent = excelContent + '</tr>';
	                      _.forEach(getDataFromDT, function(row){
	                             excelContent =excelContent + '<tr>';
	                             _.forEach(row, function(rowData){
	                            	 rowData = rowData.replace(/K/g, "");
	                                  if (rowData.includes('%')) {
	                                	  rowData = rowData.substring(0,rowData.length-1);
	                                  }
	                            	 if((/^[0-9]{0,}$/).test(rowData))
	                                           excelContent = excelContent + tdNumber + rowData + '</td>';
	                                    else
	                                           excelContent = excelContent + '<td>' + rowData + '</td>';
	                             });
	                             excelContent =excelContent + '</tr>';
	                      });
	                     excelContent =excelContent + '<tr>';
	                      excelContent =excelContent + '</tr>';
	                      if(id ==='ConversionIndex-Cur-Data')
                    	  {
	                    	  ctx = {worksheet:'Conversion Index Current Data' , table: excelContent};
		                      document.getElementById('ConversionIndexCurData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('ConversionIndexCurData').download = 'ConversionIndex-Cur-Data.xls';
                    	  }
                      if(id==='ConversionIndex-His-Data'){
	                    	  ctx = {worksheet: 'Conversion Index History Data' , table: excelContent};
		                      document.getElementById('ConversionIndexHisData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('ConversionIndexHisData').download = 'ConversionIndex-His-Data.xls';
                      }
	                }
	                })();
	                tableToExcel(id);
				return null;
			}
		}
	}]);
});
