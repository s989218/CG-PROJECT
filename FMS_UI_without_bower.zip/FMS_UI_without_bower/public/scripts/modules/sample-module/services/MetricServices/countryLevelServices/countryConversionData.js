define(['angular', '../../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('CountryConversionIndexDataService', ['CountryConversionIndexChartService',function(CountryConversionIndexChartService) {
		return{
			updateConversionIndexCurData:function($scope){
				var valueData = [], data = [], item = {} , tmp, name = "", curData, tdCHtml = "", headerCurLst = [], tmpCurLst = [],
				total = [], header = [], endResults={};
					if ($.fn.DataTable.isDataTable('#country-ConversionIndex-Cur-Data')) {
						$('#country-ConversionIndex-Cur-Data').dataTable().fnDestroy();      
					}  	
					for(var i=0;i<$scope.CURRENT.conversion_index.length;i++)
					{	
						curData = $scope.CURRENT.conversion_index[i].quarter;
						if(tmp==null && ($scope.CURRENT.conversion_index[i].country).toUpperCase()!=="ZZTOTAL")
						{
							if(!isNaN($scope.CURRENT.conversion_index[i].value))
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.conversion_index[i].year+" - "+$scope.CURRENT.conversion_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.conversion_index[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.conversion_index[i].year+" - "+$scope.CURRENT.conversion_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.conversion_index[i].value+"</td>";
							}
							tmp = $scope.CURRENT.conversion_index[i].quarter;
							name = ($scope.CURRENT.conversion_index[i].year+" - "+$scope.CURRENT.conversion_index[i].quarter);
							tmpCurLst.push($scope.CURRENT.conversion_index[i].country);
							data = [];
							data.push(parseFloat($scope.CURRENT.conversion_index[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							item["name"] = name;
							item["data"] = data;
							valueData.push(item);
							if(headerCurLst.length===0)
							{
								headerCurLst = tmpCurLst.slice();
							}
							if(($scope.CURRENT.conversion_index[i].country).toUpperCase()!=="ZZTOTAL")
							{
								if(!isNaN($scope.CURRENT.conversion_index[i].value))
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.conversion_index[i].year+" - "+$scope.CURRENT.conversion_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.conversion_index[i].value+"%</td>";
								}
								else
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.conversion_index[i].year+" - "+$scope.CURRENT.conversion_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.conversion_index[i].value+"</td>";
								}
								tmp = $scope.CURRENT.conversion_index[i].quarter;
								name = ($scope.CURRENT.conversion_index[i].year+" - "+$scope.CURRENT.conversion_index[i].quarter);
								data = [];
								data.push(parseFloat($scope.CURRENT.conversion_index[i].value));
							}
						}
						else if(curData===tmp && ($scope.CURRENT.conversion_index[i].country).toUpperCase()!=="ZZTOTAL")
						{
							if(!isNaN($scope.CURRENT.conversion_index[i].value))
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.conversion_index[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.conversion_index[i].value+"</td>";
							}
							tmp = $scope.CURRENT.conversion_index[i].quarter;
							name = ($scope.CURRENT.conversion_index[i].year+" - "+$scope.CURRENT.conversion_index[i].quarter);
							data.push(parseFloat($scope.CURRENT.conversion_index[i].value));
							tmpCurLst.push($scope.CURRENT.conversion_index[i].country);
						}
						if(($scope.CURRENT.conversion_index[i].country).toUpperCase()==="ZZTOTAL")
						{	
							header.push($scope.CURRENT.conversion_index[i].quarter);
							total.push(parseFloat($scope.CURRENT.conversion_index[i].value));
						}
					}
					tdCHtml = tdCHtml + "</tr>";
					if(data.length>0)
					{
						item["name"] = name;
						item["data"] = data;
						valueData.push(item);
						if(headerCurLst.length===0)
						{
							headerCurLst = tmpCurLst.slice();
						}
					}
					var thHtml = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerCurLst,function(value){
						thHtml = thHtml + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtml = thHtml + "</tr>";
					$(".countryConversionIndCurHeader").html(thHtml);
					$(".countryConversionIndCurData").html(tdCHtml);
					CountryConversionIndexChartService.ConversionIndexChart(valueData,headerCurLst,header,total);
					$("#country-ConversionIndex-Cur-Data").dataTable( {                                                       
						"bPaginate": false,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": false,
						"iDisplayLength": 10,
						"bInfo":false,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
				if(total>0)
				{
					endResults['countryConversionIndexCurDataTable1']=true;
					endResults['countryConversionIndexCurDataTable2']=false;
				}
				else
				{
					endResults['countryConversionIndexCurDataTable1']=false;
					endResults['countryConversionIndexCurDataTable2']=true;
				}
				return endResults;
			},
			updateConversionIndexHistData:function($scope){
				var tmp,name = "",curData,tdAHtml = "",tdHtml = "",valueDataHist = [], dataHist = [],itemHist = {}, headerLst = [], tmpLst = [],endResult={}, tdAvghtml = "";
				if ($.fn.DataTable.isDataTable('#country-ConversionIndex-His-Data')) {
					$('#country-ConversionIndex-His-Data').dataTable().fnDestroy();      
				}  		
				for(var i=0;i<$scope.HISTORY.conversion_index.length;i++)
					{
						curData = $scope.HISTORY.conversion_index[i].year+" - "+$scope.HISTORY.conversion_index[i].quarter;
						if(tmp==null)
						{
							if(!isNaN($scope.HISTORY.conversion_index[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.conversion_index[i].year+" - "+$scope.HISTORY.conversion_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.conversion_index[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.conversion_index[i].year+" - "+$scope.HISTORY.conversion_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.conversion_index[i].value+"</td>";
							}
							tmp = $scope.HISTORY.conversion_index[i].year+" - "+$scope.HISTORY.conversion_index[i].quarter;
							name = ($scope.HISTORY.conversion_index[i].year+" - "+$scope.HISTORY.conversion_index[i].quarter);
							if(($scope.HISTORY.conversion_index[i].country).toUpperCase()==='ZZTOTAL'){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.conversion_index[i].country);
							}
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.conversion_index[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							itemHist["name"] = name;
							itemHist["data"] = dataHist;
							valueDataHist.push(itemHist);
							if(headerLst.length===0)
							{
								headerLst = tmpLst.slice();
							}
							if(!isNaN($scope.HISTORY.conversion_index[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.conversion_index[i].year+" - "+$scope.HISTORY.conversion_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.conversion_index[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.conversion_index[i].year+" - "+$scope.HISTORY.conversion_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.conversion_index[i].value+"</td>";
							}
							tmp = $scope.HISTORY.conversion_index[i].year+" - "+$scope.HISTORY.conversion_index[i].quarter;
							name = ($scope.HISTORY.conversion_index[i].year+" - "+$scope.HISTORY.conversion_index[i].quarter);
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.conversion_index[i].value));
						}
						else if(curData===tmp)
						{
							if(!isNaN($scope.HISTORY.conversion_index[i].value))
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.conversion_index[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.conversion_index[i].value+"</td>";
							}
							tmp = $scope.HISTORY.conversion_index[i].year+" - "+$scope.HISTORY.conversion_index[i].quarter;
							name = ($scope.HISTORY.conversion_index[i].year+" - "+$scope.HISTORY.conversion_index[i].quarter);
							if(($scope.HISTORY.conversion_index[i].country).toUpperCase()==='ZZTOTAL'){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.conversion_index[i].country);
							}
							dataHist.push(parseFloat($scope.HISTORY.conversion_index[i].value));
						}
					}
					for(i=0;i<$scope.AVERAGE_BASED_ON_YEAR.conversion_index.length;i++)
					{
						curData = $scope.AVERAGE_BASED_ON_YEAR.conversion_index[i].year;
						if(tmp==null)
						{
							tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.conversion_index[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.conversion_index[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.conversion_index[i].year;
						}
						else if(curData!==null && curData!==tmp)
						{ 
							tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.conversion_index[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.conversion_index[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.conversion_index[i].year;
						}
						else if(curData===tmp )
						{
							tdAHtml = tdAHtml + "<td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.conversion_index[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.conversion_index[i].year;
						}
					}
					for(i=0;i<$scope.AVERAGE.conversion_index.length;i++)
					{
						tdAvghtml=tdAvghtml + "<td class='centerTxt'>" + parseFloat($scope.AVERAGE.conversion_index[i].average)+"%</td>";
						if(($scope.AVERAGE.conversion_index[i].country).toUpperCase()==='ZZTOTAL')
						{
							$scope.totalvalue=parseFloat($scope.AVERAGE.conversion_index[i].average);
						}
					}
					var avgHtml = "<tr>"+ "<td class='centerTxt'>"+"Average" + "</td>"+tdAvghtml +"</tr>";
					tdHtml = avgHtml + tdAHtml + tdHtml + "</tr>";
					if(dataHist.length>0)
					{
						itemHist["name"] = name;
						itemHist["data"] = itemHist;
						valueDataHist.push(itemHist);
						if(headerLst.length===0)
						{
							headerLst = tmpLst.slice();
						}
					}
					$(".countryConversionIndHisHeader").html('');
					var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(value){

						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtmlHist = thHtmlHist + "</tr>";
					$(".countryConversionIndHisHeader").html(thHtmlHist);
					$(".countryConversionIndHisData").html(tdHtml);
					
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					
					var  regionData={}, techSummary ={}, techData={};                                                                      
					var regions = [],  technologies = [], totalCount={};
					/* All Regions and Technologies */
					_.forEach($scope.HISTORY.conversion_index, function(responseObj){
						if(technologies.indexOf(responseObj.country) === -1 && responseObj.country!==null && (responseObj.country).toUpperCase()!=='ZZTOTAL'){
							technologies.push(responseObj.country);
						}
						if(regions.indexOf(responseObj.year+"-"+responseObj.quarter) === -1){
							regions.push(responseObj.year+"-"+responseObj.quarter);
						}  
					});
                
                    regions.reverse();
                
					var techTotalCount = {};
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(techSummary, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCount, [region], 0);
							}
						});
					});                           
					_.forEach(technologies, function(technology){
						techData[technology] = [];
						var count = 0;
						_.forEach(regions, function(region){
							if(region!==null){
								(techData[technology])[count] = 0;
								count ++;
							}
						});
					});           
					_.forEach($scope.HISTORY.conversion_index, function(responseObj){
						if(responseObj.year+"-"+responseObj.quarter!==null && (responseObj.country).toUpperCase()!=='ZZTOTAL'){
							techTotalCount[responseObj.year+"-"+responseObj.quarter]=techTotalCount[responseObj.year+"-"+responseObj.quarter]+parseFloat(responseObj.value);
							createNestedObject(techSummary, [responseObj.country, responseObj.year+"-"+responseObj.quarter], parseFloat(responseObj.value));
						}
					});
					techTotalCount =_.pairs(techTotalCount);
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					var techRankArray = [];
					_.forEach(techTotalCount, function(region){
						techRankArray.push(region[0]);
					});
					var tempArr=[];
					_.forEach(technologies, function(technology){
						_.forEach(techRankArray, function(region){
							((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]);
						});
						tempArr.push({'data': techData[technology], 'name':technology});
					});
					var valueDataforChart = tempArr;
					CountryConversionIndexChartService.ConversionIndexChartHistory(valueDataforChart,regions);
					
					$("#country-ConversionIndex-His-Data").dataTable( {                                                       
						"bPaginate": true,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": true,
						"iDisplayLength": 5,
						"bInfo":true,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
					if($scope.totalvalue>0){
					endResult['countryConversionIndexHistDataTable1']=true;
					endResult['countryConversionIndexHistDataTable2']=false;
				}
				else
				{
					endResult['countryConversionIndexHistDataTable1']=false;
					endResult['countryConversionIndexHistDataTable2']=true;
				}
				return endResult;
			},

			excelDownload: function(id){
			    	var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 });
				 var tableToExcel = (function() {
					 var ctx,subHeader;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
	                      if (!table.nodeType) 
	                             table = document.getElementById(id);
	                      var excelContent = '';
	                      var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                      if(id ==='country-ConversionIndex-Cur-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Conversion Index Current Data</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='country-ConversionIndex-His-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Conversion Index History Data</span>"+
	                          "</td></tr>";
                    	  }
	                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                      excelContent = excelContent + subHeader;
	                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
	                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                      var tdNumber = "<td style='mso-number-format:0'>";
	                      excelContent =excelContent + '<tr>';
	                      var flag = 0;
	                      _.forEach(columns, function(column){
                              if(columns[0]!== 'null' && flag === 0){
                                     excelContent = excelContent + th + column + '</th>';
                                     flag++;
                              }else {
                                     excelContent = excelContent + th + column +'(%)' + '</th>';
                              }
	                      });
	                      excelContent = excelContent + '</tr>';
	                      _.forEach(getDataFromDT, function(row){
	                             excelContent =excelContent + '<tr>';
	                             _.forEach(row, function(rowData){
	                            	 rowData = rowData.replace(/K/g, "");
	                                  if (rowData.includes('%')) {
	                                	  rowData = rowData.substring(0,rowData.length-1);
	                                  }
	                            	 if((/^[0-9]{0,}$/).test(rowData))
	                                           excelContent = excelContent + tdNumber + rowData + '</td>';
	                                    else
	                                           excelContent = excelContent + '<td>' + rowData + '</td>';
	                             });
	                             excelContent =excelContent + '</tr>';
	                      });
	                     excelContent =excelContent + '<tr>';
	                      excelContent =excelContent + '</tr>';
	                      if(id ==='country-ConversionIndex-Cur-Data')
                    	  {
	                    	  ctx = {worksheet:'Conversion Index Cur Data' , table: excelContent};
		                      document.getElementById('countryConversionIndexCurData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('countryConversionIndexCurData').download = 'ConversionIndex-Cur-Data.xls';
                    	  }
                      if(id==='country-ConversionIndex-His-Data'){
	                    	  ctx = {worksheet: 'Conversion Index Hist Data' , table: excelContent};
		                      document.getElementById('countryConversionIndexHisData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('countryConversionIndexHisData').download = 'ConversionIndex-His-Data.xls';
                      }
	                }
	                })();
	                tableToExcel(id);
				return null;
			}
		}
	}]);
});
