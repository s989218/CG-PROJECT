define([
	'./countryLevelIBChart',
	'./countryOpexPenChart',
	'./countryPenChart',
	'./countryfleetCovChart',
	'./countryCaloricChart',
	'./countryConversionChart',
	'./countryPartsPenChart'
	], function() {

});
