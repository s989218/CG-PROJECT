define(['angular', '../../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('countryIBByRegionService', ['$q','$http','$state','CountryIBbyRegionChart',function($q, $http,$state,CountryIBbyRegionChart) {
		return{
			updateIBbyRegionCurData: function ($scope){
				var valueData = [], data = [], item , tmp, name = "", curData, tdCHtml = "", headerCurLst = [], tmpCurLst = [],
				total = [], header = [], endResults={};
				if ($.fn.DataTable.isDataTable('#country-IB-by-Region-Cur-Data')) {
					$('#country-IB-by-Region-Cur-Data').dataTable().fnDestroy();      
				}  
				for(var i=0;i<$scope.CURRENT.dollar_by_ib.length;i++)
				{
					curData = $scope.CURRENT.dollar_by_ib[0].quarter;
					if(tmp==null && ($scope.CURRENT.dollar_by_ib[i].country).toUpperCase()!=="ZZTOTAL")
					{
						if(!isNaN($scope.CURRENT.dollar_by_ib[i].value))
						{
							tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.dollar_by_ib[i].year+" - "+$scope.CURRENT.dollar_by_ib[i].quarter)+"</td><td class='centerTxt'>$"+$scope.CURRENT.dollar_by_ib[i].value+"K</td>";
						}
						else
						{
							tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.dollar_by_ib[i].year+" - "+$scope.CURRENT.dollar_by_ib[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.dollar_by_ib[i].value+"</td>";
						}
						tmp = $scope.CURRENT.dollar_by_ib[i].quarter;
						name = ($scope.CURRENT.dollar_by_ib[i].year+" - "+$scope.CURRENT.dollar_by_ib[i].quarter);
						tmpCurLst.push($scope.CURRENT.dollar_by_ib[i].country);
						data = [];
						if(!isNaN($scope.CURRENT.dollar_by_ib[i].value)){
							data.push(parseFloat($scope.CURRENT.dollar_by_ib[i].value));
						}
						else{
							data.push($scope.CURRENT.dollar_by_ib[i].value);
						}						
					}
					else if(curData!==null && curData!==tmp)
					{
						item["name"] = name;
						item["data"] = data;
						valueData.push(item);
						if(headerCurLst.length===0)
						{
							headerCurLst = tmpCurLst.slice();
						}
						if(($scope.CURRENT.dollar_by_ib[i].country).toUpperCase()!=="ZZTOTAL")
						{
							if(!isNaN($scope.CURRENT.dollar_by_ib[i].value))
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.dollar_by_ib[i].year+" - "+$scope.CURRENT.dollar_by_ib[i].quarter)+"</td><td class='centerTxt'>$"+$scope.CURRENT.dollar_by_ib[i].value+"K</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.dollar_by_ib[i].year+" - "+$scope.CURRENT.dollar_by_ib[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.dollar_by_ib[i].value+"</td>";
							}
							tmp = $scope.CURRENT.dollar_by_ib[i].quarter;
							name = ($scope.CURRENT.dollar_by_ib[i].year+" - "+$scope.CURRENT.dollar_by_ib[i].quarter);
							data = [];
							if(!isNaN($scope.CURRENT.dollar_by_ib[i].value)){
								data.push(parseFloat($scope.CURRENT.dollar_by_ib[i].value));
							}
							else{
								data.push($scope.CURRENT.dollar_by_ib[i].value);
							}		
						}
					}
					else if(curData===tmp && ($scope.CURRENT.dollar_by_ib[i].country).toUpperCase()!=="ZZTOTAL")
					{
						if(!isNaN($scope.CURRENT.dollar_by_ib[i].value))
						{
							tdCHtml = tdCHtml + "<td class='centerTxt'>$"+$scope.CURRENT.dollar_by_ib[i].value+"K</td>";
						}
						else
						{
							tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.dollar_by_ib[i].value+"</td>";
						}
						tmp = $scope.CURRENT.dollar_by_ib[i].quarter;
						name = ($scope.CURRENT.dollar_by_ib[i].year+" - "+$scope.CURRENT.dollar_by_ib[i].quarter);
						if(!isNaN($scope.CURRENT.dollar_by_ib[i].value)){
							data.push(parseFloat($scope.CURRENT.dollar_by_ib[i].value));
						}
						else{
							data.push($scope.CURRENT.dollar_by_ib[i].value);
						}		
						tmpCurLst.push($scope.CURRENT.dollar_by_ib[i].country);
					}
					if(($scope.CURRENT.dollar_by_ib[i].country).toUpperCase()==="ZZTOTAL")
					{	
						header.push($scope.CURRENT.dollar_by_ib[i].quarter);
						total.push($scope.CURRENT.dollar_by_ib[i].value);
					}
				}
				tdCHtml = tdCHtml + "</tr>";
				if(data.length>0)
				{
					item={};
					item["name"] = name;
					item["data"] = data;
					valueData.push(item);
					if(headerCurLst.length===0)
					{
						headerCurLst = tmpCurLst.slice();
					}
				}
				var thHtml = "<tr><th class='tHeadMaintenance'></th>";
				angular.forEach(headerCurLst,function(value){
					thHtml = thHtml + "<th class='tHeadMaintenance'>"+value+"</th>";
				});
				thHtml = thHtml + "</tr>";
				$(".countryIBbyRegCurHeader").html(thHtml);
				$(".countryIBbyRegCurData").html(tdCHtml);
				CountryIBbyRegionChart.IBbyRegionChart(valueData,headerCurLst,total,header);
				$("#country-IB-by-Region-Cur-Data").dataTable( {                                                       
					"bPaginate": false,
					"bAutoWidth": false,
					"bSort": true,
					"bFilter": false,
					"iDisplayLength": 10,
					"bInfo":false,
					"aaSorting":[],
					"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
				});
				if(total>0){
					endResults['countryIBbyRegionCurDataTable1']=true;
					endResults['countryIBbyRegionCurDataTable2']=false;
				}
				else
				{
					endResults['countryIBbyRegionCurDataTable1']=false;
					endResults['countryIBbyRegionCurDataTable2']=true;
				}
				return endResults;
			},
			
			updateIBbyRegionHistData: function ($scope){
				var tmp,name = "",curData,tdAHtml = "",tdHtml = "",valueDataHist = [], dataHist = [],itemHist = {}, headerLst = [], tmpLst = [],endResult={}, tdAvghtml = "";
				if ($.fn.DataTable.isDataTable('#country-IB-by-Region-His-Data')) {
					$('#country-IB-by-Region-His-Data').dataTable().fnDestroy();        
				}
				for(var i=0;i<$scope.HISTORY.dollar_by_ib.length;i++)
					{
						curData = $scope.HISTORY.dollar_by_ib[i].year+" - "+$scope.HISTORY.dollar_by_ib[i].quarter;
						if(tmp==null)
						{ 
							if(!isNaN($scope.HISTORY.dollar_by_ib[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.dollar_by_ib[i].year+" - "+$scope.HISTORY.dollar_by_ib[i].quarter)+"</td><td class='centerTxt'>$"+$scope.HISTORY.dollar_by_ib[i].value+"K</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.dollar_by_ib[i].year+" - "+$scope.HISTORY.dollar_by_ib[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.dollar_by_ib[i].value+"</td>";
							}
							tmp = $scope.HISTORY.dollar_by_ib[i].year+" - "+$scope.HISTORY.dollar_by_ib[i].quarter;
							name = ($scope.HISTORY.dollar_by_ib[i].year+" - "+$scope.HISTORY.dollar_by_ib[i].quarter);
							if(($scope.HISTORY.dollar_by_ib[i].country).toUpperCase()==='ZZTOTAL'){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.dollar_by_ib[i].country);
							}
							dataHist = [];
							dataHist.push($scope.HISTORY.dollar_by_ib[i].value);
						}
						else if(curData!==null && curData!==tmp)
						{  
							
							itemHist["name"] = name;
							itemHist["data"] = dataHist;
							valueDataHist.push(itemHist);
							if(headerLst.length===0)
							{
								headerLst = tmpLst.slice();
							}
								if(!isNaN($scope.HISTORY.dollar_by_ib[i].value))
								{
									tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.dollar_by_ib[i].year+" - "+$scope.HISTORY.dollar_by_ib[i].quarter)+"</td><td class='centerTxt'>$"+$scope.HISTORY.dollar_by_ib[i].value+"K</td>";
								}
								else
								{
									tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.dollar_by_ib[i].year+" - "+$scope.HISTORY.dollar_by_ib[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.dollar_by_ib[i].value+"</td>";
								}
								tmp = $scope.HISTORY.dollar_by_ib[i].year+" - "+$scope.HISTORY.dollar_by_ib[i].quarter;
								name = ($scope.HISTORY.dollar_by_ib[i].year+" - "+$scope.HISTORY.dollar_by_ib[i].quarter);
								dataHist = [];
								dataHist.push($scope.HISTORY.dollar_by_ib[i].value);
							
						}
						else if(curData===tmp )
						{
							if(!isNaN($scope.HISTORY.dollar_by_ib[i].value))
							{
								tdHtml = tdHtml + "<td class='centerTxt'>$"+$scope.HISTORY.dollar_by_ib[i].value+"K</td>";
							}
							else
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.dollar_by_ib[i].value+"</td>";
							}
							tmp = $scope.HISTORY.dollar_by_ib[i].year+" - "+$scope.HISTORY.dollar_by_ib[i].quarter;
							name = ($scope.HISTORY.dollar_by_ib[i].year+" - "+$scope.HISTORY.dollar_by_ib[i].quarter);
							if(($scope.HISTORY.dollar_by_ib[i].country).toUpperCase()==='ZZTOTAL'){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.dollar_by_ib[i].country);
							}
							dataHist.push($scope.HISTORY.dollar_by_ib[i].value);
						}
					}
					for(i=0;i<$scope.AVERAGE_BASED_ON_YEAR.dollar_by_ib.length;i++)
					{
						curData = $scope.AVERAGE_BASED_ON_YEAR.dollar_by_ib[i].year;
						if(tmp==null)
						{
							tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.dollar_by_ib[i].year)+"</td><td class='centerTxt'>$"+$scope.AVERAGE_BASED_ON_YEAR.dollar_by_ib[i].average+"K</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.dollar_by_ib[i].year;
						}
						else if(curData!==null && curData!==tmp)
						{ 
							tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.dollar_by_ib[i].year)+"</td><td class='centerTxt'>$"+$scope.AVERAGE_BASED_ON_YEAR.dollar_by_ib[i].average+"K</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.dollar_by_ib[i].year;
						}
						else if(curData===tmp )
						{
							tdAHtml = tdAHtml + "<td class='centerTxt'>$"+$scope.AVERAGE_BASED_ON_YEAR.dollar_by_ib[i].average+"K</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.dollar_by_ib[i].year;
						}
					}
					for(i=0;i<$scope.AVERAGE.dollar_by_ib.length;i++)
					{
						tdAvghtml=tdAvghtml + "<td class='centerTxt'>$" + parseFloat($scope.AVERAGE.dollar_by_ib[i].average) +"K</td>";
						if(($scope.AVERAGE.dollar_by_ib[i].country).toUpperCase()==='ZZTOTAL')
						{
							$scope.totalvalue=parseFloat($scope.AVERAGE.dollar_by_ib[i].average);
						}
					}
					var avgHtml = "<tr>"+ "<td class='centerTxt'>"+"Average" + "</td>"+tdAvghtml +"</tr>";
					tdHtml = avgHtml + tdAHtml + tdHtml + "</tr>";
					if(dataHist.length>0)
					{
						itemHist={};
						itemHist["name"] = name;
						itemHist["data"] = itemHist;
						valueDataHist.push(itemHist);
						if(headerLst.length===0)
						{
							headerLst = tmpLst.slice();
						}
					}
					
					$(".countryIBbyRegHisHeader").html('');
					var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(value){
						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtmlHist = thHtmlHist + "</tr>";
					$(".countryIBbyRegHisHeader").html(thHtmlHist);
					$(".countryIBbyRegHisData").html(tdHtml);

						var createNestedObject = function( base, names, value ) {
							var lastName = arguments.length === 3 ? names.pop() : false;
							for( var i = 0; i < names.length; i++ ) {
								base = base[ names[i] ] = base[ names[i] ] || {};
							}
							if( lastName ) base = base[ lastName ] = value;
							return base;
						};
						var regionData={}, techSummary ={}, techData={};                                                                      
						var regions = [], technologies = [], totalCount={};
						/* All Regions and Technologies */
						_.forEach($scope.HISTORY.dollar_by_ib, function(responseObj){
							if(technologies.indexOf(responseObj.country) === -1 && responseObj.country!==null && (responseObj.country).toUpperCase()!=='ZZTOTAL'){
								technologies.push(responseObj.country);
							}
							if(regions.indexOf(responseObj.year+"-"+responseObj.quarter) === -1){
								regions.push(responseObj.year+"-"+responseObj.quarter);
							}  
						});
                
                        regions.reverse();
                
						var techTotalCount = {};
						_.forEach(regions, function(region){
							regionData[region] = [];
							var count = 0;
							_.forEach(technologies, function(technology){
								if(region!==null){
									(regionData[region])[count] = 0;
									count ++;
									createNestedObject(techSummary, [technology, region], 0);
									createNestedObject(totalCount, [technology], 0);
									createNestedObject(techTotalCount, [region], 0);
								}
							});
						});                           
						_.forEach(technologies, function(technology){
							techData[technology] = [];
							var count = 0;
							_.forEach(regions, function(region){
								if(region!==null){
									(techData[technology])[count] = 0;
									count ++;
								}
							});
						});        
						
						
						_.forEach($scope.HISTORY.dollar_by_ib, function(responseObj){
							if(responseObj.year+"-"+responseObj.quarter!==null){
								techTotalCount[responseObj.year+"-"+responseObj.quarter]=techTotalCount[responseObj.year+"-"+responseObj.quarter]+parseFloat(responseObj.value);
								createNestedObject(techSummary, [responseObj.country, responseObj.year+"-"+responseObj.quarter], responseObj.value);
							}
						});
						techTotalCount =_.pairs(techTotalCount);
						var rankArray = [];
						_.forEach(totalCount, function(tech){
							rankArray.push(tech[0]);
						});
						var techRankArray = [];
						_.forEach(techTotalCount, function(region){
							techRankArray.push(region[0]);
						});
						var tempArr=[];
						_.forEach(technologies, function(technology){
							_.forEach(techRankArray, function(region){
								((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]);
							});
							tempArr.push({'data': techData[technology], 'name':technology});
						});
					var valueDataforChart = tempArr;
					CountryIBbyRegionChart.IBbyRegionChartHistory(valueDataforChart,regions);
					$("#country-IB-by-Region-His-Data").DataTable({                                                       
						"bPaginate": true,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": true,
						"iDisplayLength": 5,
						"bInfo":true,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});	
				if($scope.totalvalue>0){
					endResult['countryIBbyRegionHistDataTable1']=true;
					endResult['countryIBbyRegionHistDataTable2']=false;
				}
				else
				{
					endResult['countryIBbyRegionHistDataTable1']=false;
					endResult['countryIBbyRegionHistDataTable2']=true;
				}
				return endResult;
			},
			
			excelDownload: function(id){
		    	var columns = [];
			 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                 columns.push(data.innerHTML);
			 });
			 var tableToExcel = (function() {
				 var ctx,subHeader;
                 var uri = 'data:application/vnd.ms-excel;base64,'
                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
                      return function(table) {
                      if (!table.nodeType) 
                             table = document.getElementById(id);
                      var excelContent = '';
                      var header = "<tr><td colspan='8' style='text-align:center'>" +
                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
                      if(id ==='country-IB-by-Region-Cur-Data')
                	  {
	                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>IB by Region Current Data</span>"+
                          "</td></tr>";
                	  }
                      if(id ==='country-IB-by-Region-His-Data')
                	  {
	                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>IB by Region History Data</span>"+
                          "</td></tr>";
                	  }
                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
                      excelContent = excelContent + subHeader;
                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
                      var tdNumber = "<td style='mso-number-format:0'>";
                      excelContent =excelContent + '<tr>';
                      var flag = 0;
                      _.forEach(columns, function(column){
                             if(columns[0]!== 'null' && flag === 0){
                                    excelContent = excelContent + th + column + '</th>';
                                    flag++;
                             }else {
                                    excelContent = excelContent + th + column +'($K)' + '</th>';
                             }
                      });
                      excelContent = excelContent + '</tr>';
                      _.forEach(getDataFromDT, function(row){
                             excelContent =excelContent + '<tr>';
                             _.forEach(row, function(rowData){
                            	 rowData = rowData.replace(/K/g, "");
                                 if (rowData.includes('$')) {
                               	  rowData = rowData.substring(1,rowData.length);
                                 }
                            	 if((/^[0-9]{0,}$/).test(rowData))
                                           excelContent = excelContent + tdNumber + rowData + '</td>';
                                    else
                                           excelContent = excelContent + '<td>' + rowData + '</td>';
                             });
                             excelContent =excelContent + '</tr>';
                      });
                     excelContent =excelContent + '<tr>';
                      excelContent =excelContent + '</tr>';
                      if(id ==='country-IB-by-Region-Cur-Data')
                	  {
                    	  ctx = {worksheet:'IB by Region cur Data' , table: excelContent};
	                      document.getElementById('countryIBbyRegionCurData').href = (uri + base64(format(template, ctx)));
	                      document.getElementById('countryIBbyRegionCurData').download = 'IB-by-Region-Cur-Data.xls';
                	  }
                  if(id==='country-IB-by-Region-His-Data'){
                    	  ctx = {worksheet: 'IB by Region hist Data' , table: excelContent};
	                      document.getElementById('countryIBbyRegionHistData').href = (uri + base64(format(template, ctx)));
	                      document.getElementById('countryIBbyRegionHistData').download = 'IB-by-Region-His-Data.xls';
                  }
                }
                })();
                tableToExcel(id);
			return null;
		}
		}
	}]);
});
