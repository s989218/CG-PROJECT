define(['angular', '../../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('countryLevelDataNetworkService', ['$q','$http','$rootScope',function($q,$http,$rootScope) {
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
        return {
        	getMetricsDropdownsData: function(){
				var request = {
					'method': 'GET',
					'url': 'connect/fms/getPenetratinMetricsRegionDropdown ',
					};
				return networkCall(request);
			},
			getPenetratinMetricsCountryDropdown: function(item){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": item,
					'url':"connect/fms/getPenetratinMetricsCountryDropdown/" + $rootScope.businessSegment,
				};
				return networkCall(request);
			},
			getAllMetricsCountrySiteDropdown: function(item){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": item,
					'url':"connect/fms/getAllMetricsCountrySiteDropdown/"+$rootScope.businessSegment ,					
				};
				return networkCall(request);
			},
			getAllMetricsCountryTechData: function(item){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": item,
					'url':"connect/fms/getAllMetricsCountryTechData/country" ,					
				};
				return networkCall(request);
			},
			getAllMetricsTechnologyData: function(item){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": item,
					'url':"connect/fms/getAllMetricsCountryTechData/technology" ,					
				};
				return networkCall(request);
			},
			/*Segment Level Service*/
			getAllMetricsSegmentData: function(item){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": item,
					'url':"connect/fms/getPenMetricsSegmentData/segment" ,					
				};
				return networkCall(request);
			},
			
			getAllMetricsSitesData: function(item){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": item,
					'url':"connect/fms/getAllMetricsCountrySiteData" ,					
				};
				return networkCall(request);
			},
			getAllMetricsexportSitesData: function(item){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": item,
					'url':"connect/fms/penetrationExportExcelData" ,					
				};
				return networkCall(request);
			},
			getDunsDropdownsData: function(item){
                var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": item,
					'url': "connect/fms/getPenetrationMetricsGEDunsNameDropdown/"+$rootScope.businessSegment,					
				};
				return networkCall(request);
			},
			getDunsSiteDropdownData: function(item){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": item,
					'url':"connect/fms/getAllMetricsGEDunsNameData" ,					
				};
				return networkCall(request);
			},
			getAllMetricsexportDunsData: function(item){
				var request = {
                    'dataType': "json",
					'method': 'POST',
                    'contentType':"application/json",
					"data": item,
					'url':"connect/fms/penetrationGEDunsExportExcelData " ,					
				};
				return networkCall(request);
			}
        };
    }]);
});
