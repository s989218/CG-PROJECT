define(['angular', '../../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('CountryOpexpenetrationCurDataService', ['CountryOpexPenetrationChartService',function(CountryOpexPenetrationChartService) {
		return{
			updateOpexpenetrationCurData : function($scope){
				var valueData = [], data = [], item , tmp, name = "", curData, tdCHtml = "", headerCurLst = [], tmpCurLst = [],
				total=[], header=[], endResults={};
				if ($.fn.DataTable.isDataTable('#country-Opex-Penetration-F2F-Cur-Data')) {
					$('#country-Opex-Penetration-F2F-Cur-Data').dataTable().fnDestroy();      
				}  
					for(var i=0;i<$scope.CURRENT.fleet_pen_f2f.length;i++)
					{
						curData = $scope.CURRENT.fleet_pen_f2f[i].quarter;
						if(tmp==null && ($scope.CURRENT.fleet_pen_f2f[i].country).toUpperCase()!=="ZZTOTAL")
						{
							if(!isNaN($scope.CURRENT.fleet_pen_f2f[i].value))
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_pen_f2f[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_pen_f2f[i].value+"</td>";
							}
							tmp = $scope.CURRENT.fleet_pen_f2f[i].quarter;
							name = ($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter);
							tmpCurLst.push($scope.CURRENT.fleet_pen_f2f[i].country);
							data = [];
							data.push(parseFloat($scope.CURRENT.fleet_pen_f2f[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							item["name"] = name; 
							item["data"] = data;
							valueData.push(item);
							if(headerCurLst.length===0)
							{
								headerCurLst = tmpCurLst.slice();
							}
							if(($scope.CURRENT.fleet_pen_f2f[i].country).toUpperCase()!=="ZZTOTAL")
							{
								if(!isNaN($scope.CURRENT.fleet_pen_f2f[i].value))
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_pen_f2f[i].value+"%</td>";
								}
								else
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_pen_f2f[i].value+"</td>";
								}
								tmp = $scope.CURRENT.fleet_pen_f2f[i].quarter;
								name = ($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter);
								data = [];
								data.push(parseFloat($scope.CURRENT.fleet_pen_f2f[i].value));
							}
						}
						else if(curData===tmp && ($scope.CURRENT.fleet_pen_f2f[i].country).toUpperCase()!=="ZZTOTAL")
						{
							if(!isNaN($scope.CURRENT.fleet_pen_f2f[i].value))
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.fleet_pen_f2f[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.fleet_pen_f2f[i].value+"</td>";
							}
							tmp = $scope.CURRENT.fleet_pen_f2f[i].quarter;
							name = ($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter);
							data.push(parseFloat($scope.CURRENT.fleet_pen_f2f[i].value));
							tmpCurLst.push($scope.CURRENT.fleet_pen_f2f[i].country);
						}
						if(($scope.CURRENT.fleet_pen_f2f[i].country).toUpperCase()==="ZZTOTAL")
						{	
							header.push($scope.CURRENT.fleet_pen_f2f[i].quarter);
							total.push(parseFloat($scope.CURRENT.fleet_pen_f2f[i].value));
						}
					}
					tdCHtml = tdCHtml + "</tr>";
					if(data.length>0)
					{
						item={};
						item["name"] = name;
						item["data"] = data;
						valueData.push(item);
						if(headerCurLst.length===0)
						{
							headerCurLst = tmpCurLst.slice();
						}
					}
					var thHtml = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerCurLst,function(value){
						thHtml = thHtml + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtml = thHtml + "</tr>";
					$(".countryOpexPenCurHeader").html(thHtml);
					$(".countryOpexPenCurData").html(tdCHtml);
					CountryOpexPenetrationChartService.OpexPenetrationChart(valueData,headerCurLst,header,total);				
					$("#country-Opex-Penetration-F2F-Cur-Data").dataTable( {                                                       
						"bPaginate": false,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": false,
						"iDisplayLength": 10,
						"bInfo":false,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
				if(total>0){
					endResults['countryOpexpenetrationF2FCurDataTable1']=true;
					endResults['countryOpexpenetrationF2FCurDataTable2']=false;
				}
				else
				{
					endResults['countryOpexpenetrationF2FCurDataTable2']=true;
					endResults['countryOpexpenetrationF2FCurDataTable1']=false;
				}
				return endResults;
			},
			updateOpexpenetrationHistData: function ($scope){
				var tmp,name = "",curData,tdAHtml = "",tdHtml = "",valueDataHist = [], dataHist = [],itemHist = {}, headerLst = [], tmpLst = [],endResults={},tdAvghtml = "";
				if ($.fn.DataTable.isDataTable('#country-Opex-Penetration-F2F-His-Data')) {
					$('#country-Opex-Penetration-F2F-His-Data').dataTable().fnDestroy();      
				}  	
				for(var i=0;i<$scope.HISTORY.fleet_pen_f2f.length;i++)
					{
						curData = $scope.HISTORY.fleet_pen_f2f[i].year+" - "+$scope.HISTORY.fleet_pen_f2f[i].quarter;
						if(tmp==null)
						{
							if(!isNaN($scope.HISTORY.fleet_pen_f2f[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_pen_f2f[i].year+" - "+$scope.HISTORY.fleet_pen_f2f[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_pen_f2f[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_pen_f2f[i].year+" - "+$scope.HISTORY.fleet_pen_f2f[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_pen_f2f[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_pen_f2f[i].year+" - "+$scope.HISTORY.fleet_pen_f2f[i].quarter;
							name = ($scope.HISTORY.fleet_pen_f2f[i].year+" - "+$scope.HISTORY.fleet_pen_f2f[i].quarter);
							if(($scope.HISTORY.fleet_pen_f2f[i].country).toUpperCase()==='ZZTOTAL'){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.fleet_pen_f2f[i].country);
							}
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.fleet_pen_f2f[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							itemHist["name"] = name;
							itemHist["data"] = dataHist;
							valueDataHist.push(itemHist);
							if(headerLst.length===0)
							{
								headerLst = tmpLst.slice();
							}
							if(!isNaN($scope.HISTORY.fleet_pen_f2f[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_pen_f2f[i].year+" - "+$scope.HISTORY.fleet_pen_f2f[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_pen_f2f[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_pen_f2f[i].year+" - "+$scope.HISTORY.fleet_pen_f2f[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_pen_f2f[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_pen_f2f[i].year+" - "+$scope.HISTORY.fleet_pen_f2f[i].quarter;
							name = ($scope.HISTORY.fleet_pen_f2f[i].year+" - "+$scope.HISTORY.fleet_pen_f2f[i].quarter);
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.fleet_pen_f2f[i].value));
						}
						else if(curData===tmp)
						{
							if(!isNaN($scope.HISTORY.fleet_pen_f2f[i].value))
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.fleet_pen_f2f[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.fleet_pen_f2f[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_pen_f2f[i].year+" - "+$scope.HISTORY.fleet_pen_f2f[i].quarter;
							name = ($scope.HISTORY.fleet_pen_f2f[i].year+" - "+$scope.HISTORY.fleet_pen_f2f[i].quarter);
							if(($scope.HISTORY.fleet_pen_f2f[i].country).toUpperCase()==='ZZTOTAL'){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.fleet_pen_f2f[i].country);
							}
							dataHist.push(parseFloat($scope.HISTORY.fleet_pen_f2f[i].value));

						}
					}
					for(i=0;i<$scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f.length;i++)
					{
						curData = $scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].year;
						if(tmp==null)
						{
							tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].year;
						}
						else if(curData!==null && curData!==tmp)
						{ 
							tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].year;
						}
						else if(curData===tmp )
						{
							tdAHtml = tdAHtml + "<td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].year;
						}
					}
					for(i=0;i<$scope.AVERAGE.fleet_pen_f2f.length;i++)
					{
						tdAvghtml=tdAvghtml + "<td class='centerTxt'>" + parseFloat($scope.AVERAGE.fleet_pen_f2f[i].average) +"%</td>";
						if(($scope.AVERAGE.fleet_pen_f2f[i].country).toUpperCase()==='ZZTOTAL')
						{
							$scope.totalvalue=parseFloat($scope.AVERAGE.fleet_pen_f2f[i].average);
						}
					}
					var avgHtml = "<tr>"+ "<td class='centerTxt'>"+"Average" + "</td>" +tdAvghtml +"</tr>";
					tdHtml = avgHtml + tdAHtml + tdHtml + "</tr>";
					if(dataHist.length>0)
					{
						itemHist["name"] = name;
						itemHist["data"] = itemHist;
						valueDataHist.push(itemHist);
						if(headerLst.length===0)
						{
							headerLst = tmpLst.slice();
						}
					}
					$(".countryOpexPenHisHeader").html('');
					var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(value){
						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtmlHist = thHtmlHist + "</tr>";
					$(".countryOpexPenHisHeader").html(thHtmlHist);	
					$(".countryOpexPenHisData").html(tdHtml);
					
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					
					var regionData={}, techSummary ={}, techData={};                                                                      
					var regions = [], technologies = [], totalCount={};
					// All Regions and Technologies 
					_.forEach($scope.HISTORY.fleet_pen_f2f, function(responseObj){
						if(technologies.indexOf(responseObj.country) === -1 && responseObj.country!==null && (responseObj.country).toUpperCase()!=='ZZTOTAL'){
							technologies.push(responseObj.country);
						}
						if(regions.indexOf(responseObj.year+"-"+responseObj.quarter) === -1){
							regions.push(responseObj.year+"-"+responseObj.quarter);
						}  
					});
                    
                    regions.reverse();
                
					var techTotalCount = {};
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(techSummary, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCount, [region], 0);
							}
						});
					});                           
					_.forEach(technologies, function(technology){
						techData[technology] = [];
						var count = 0;
						_.forEach(regions, function(region){
							if(region!==null){
								(techData[technology])[count] = 0;
								count ++;
							}
						});
					});           
					_.forEach($scope.HISTORY.fleet_pen_f2f, function(responseObj){
						if(responseObj.year+"-"+responseObj.quarter!==null && (responseObj.country).toUpperCase()!=='ZZTOTAL'){
							techTotalCount[responseObj.year+"-"+responseObj.quarter]=techTotalCount[responseObj.year+"-"+responseObj.quarter]+parseFloat(responseObj.value);
							createNestedObject(techSummary, [responseObj.country,responseObj.year+"-"+responseObj.quarter], parseFloat(responseObj.value));
						}
					});
					techTotalCount =_.pairs(techTotalCount);
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					var techRankArray = [];
					_.forEach(techTotalCount, function(region){
						techRankArray.push(region[0]);
					});
					var tempArr=[];
					_.forEach(technologies, function(technology){
						_.forEach(techRankArray, function(region){
							((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]);
						});
						tempArr.push({'data': techData[technology], 'name':technology});
					});
					var valueDataforChart = tempArr;
					CountryOpexPenetrationChartService.OpexPenetrationHistoryChart(valueDataforChart,regions);
					
					$("#country-Opex-Penetration-F2F-His-Data").dataTable( {                                                       
						"bPaginate": true,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": true,
						"iDisplayLength": 5,
						"bInfo":true,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
				if($scope.totalvalue>0){
					endResults['countryOpexpenetrationF2FHistDataTable1']=true;
					endResults['countryOpexpenetrationF2FHistDataTable2']=false;
				}
				else
				{
					endResults['countryOpexpenetrationF2FHistDataTable2']=true;
					endResults['countryOpexpenetrationF2FHistDataTable1']=false;
				}
				return endResults;
			},
			excelDownload: function(id){
			    	var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 });
				 var tableToExcel = (function() {
					 var subHeader,ctx ;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
	                      if (!table.nodeType) 
	                             table = document.getElementById(id);
	                      var excelContent = '';
	                      var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                      if(id ==='country-Opex-Penetration-F2F-Cur-Data')
                    	  {
		                       subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Opex Penetration F2F Current Data</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='country-Opex-Penetration-F2F-His-Data')
                    	  {
		                       subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Opex Penetration F2F History Data</span>"+
	                          "</td></tr>";
                    	  }
	                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                      excelContent = excelContent + subHeader;
	                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
	                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                      var tdNumber = "<td style='mso-number-format:0'>";
	                      excelContent =excelContent + '<tr>';
	                      var flag = 0;
	                      _.forEach(columns, function(column){
                              if(columns[0]!== 'null' && flag === 0){
                                     excelContent = excelContent + th + column + '</th>';
                                     flag++;
                              }else {
                                     excelContent = excelContent + th + column +'(%)' + '</th>';
                              }
	                      });
	                      excelContent = excelContent + '</tr>';
	                      _.forEach(getDataFromDT, function(row){
	                             excelContent =excelContent + '<tr>';
	                             _.forEach(row, function(rowData){
	                            	 rowData = rowData.replace(/K/g, "");
	                                  if (rowData.includes('%')) {
	                                	  rowData = rowData.substring(0,rowData.length-1);
	                                  }
	                            	 if((/^[0-9]{0,}$/).test(rowData))
	                                           excelContent = excelContent + tdNumber + rowData + '</td>';
	                                    else
	                                           excelContent = excelContent + '<td>' + rowData + '</td>';
	                             });
	                             excelContent =excelContent + '</tr>';
	                      });
	                     excelContent =excelContent + '<tr>';
	                      excelContent =excelContent + '</tr>';
	                      if(id ==='country-Opex-Penetration-F2F-Cur-Data')
                    	  {
	                    	  ctx = {worksheet:'Opex Pen F2F Cur Data' , table: excelContent};
		                      document.getElementById('countryOpexPenF2FCurData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('countryOpexPenF2FCurData').download = 'Opex-Penetration-F2F-Cur-Data.xls';
                    	  }
                      if(id==='country-Opex-Penetration-F2F-His-Data'){
	                    	  ctx = {worksheet: 'Opex Pen F2F Hist Data' , table: excelContent};
		                      document.getElementById('countryOpexPenF2FHisData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('countryOpexPenF2FHisData').download = 'Opex-Penetration-F2F-His-Data.xls';
                      }
	                }
	                })();
	                tableToExcel(id);
				return null;
			}
		}
	}]);
});
