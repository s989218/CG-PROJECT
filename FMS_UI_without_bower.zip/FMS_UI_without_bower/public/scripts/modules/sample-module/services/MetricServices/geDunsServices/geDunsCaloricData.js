define(['angular', '../../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('DunsCaloricbyRegionCurDataService', ['DunsCaloricRegionChartService',function(DunsCaloricRegionChartService) {
		return{
			updateCaloricbyRegionCurData: function ($scope){
				var valueData = [], data = [], item={}, tmp, name = "", curData, tdCHtml = "", headerCurLst = [], tmpCurLst = [],
				total = [], header = [], endResult={};
					if ($.fn.DataTable.isDataTable('#duns-CalIndexByReg-Cur-Data')) {
						$('#duns-CalIndexByReg-Cur-Data').dataTable().fnDestroy();      
					} 
					if($scope.CURRENT.caloric_index.length>0){
					for(var i=0;i<$scope.CURRENT.caloric_index.length;i++)
					{
						curData = $scope.CURRENT.caloric_index[i].quarter;
						if(tmp==null &&($scope.CURRENT.caloric_index[i].site_name)!==null)
						{
							tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.caloric_index[i].year+" - "+$scope.CURRENT.caloric_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.caloric_index[i].value+"</td>";
							tmp = $scope.CURRENT.caloric_index[i].quarter;
							name = ($scope.CURRENT.caloric_index[i].year+" - "+$scope.CURRENT.caloric_index[i].quarter);
							tmpCurLst.push($scope.CURRENT.caloric_index[i].site_name);
							data = [];
							data.push(parseFloat($scope.CURRENT.caloric_index[i].value));
						}
						else if((curData!==null && curData!==tmp)  && ($scope.CURRENT.caloric_index[i].site_name)!==null)
						{
							item["name"] = name;
							item["data"] = data;
							valueData.push(item);
							if(headerCurLst.length===0)
							{
								headerCurLst = tmpCurLst.slice();
							}
							if(($scope.CURRENT.caloric_index[i].site_name)!==null)
							{
								tdCHtml = tdCHtml + "</tr><tr><td class='centerTxt'>"+($scope.CURRENT.caloric_index[i].year+" - "+$scope.CURRENT.caloric_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.caloric_index[i].value+"</td>";
								tmp = $scope.CURRENT.caloric_index[i].quarter;
								name = ($scope.CURRENT.caloric_index[i].year+" - "+$scope.CURRENT.caloric_index[i].quarter);
								data = [];
								data.push(parseFloat($scope.CURRENT.caloric_index[i].value));
							}
						}
						else if(curData===tmp &&($scope.CURRENT.caloric_index[i].site_name)!==null)
						{
							tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.caloric_index[i].value+"</td>";
							tmp = $scope.CURRENT.caloric_index[i].quarter;
							name = ($scope.CURRENT.caloric_index[i].year+" - "+$scope.CURRENT.caloric_index[i].quarter);
							data.push(parseFloat($scope.CURRENT.caloric_index[i].value));
							tmpCurLst.push($scope.CURRENT.caloric_index[i].site_name);
						}
						if(($scope.CURRENT.caloric_index[i].site_name)===null)
						{	
							header.push($scope.CURRENT.caloric_index[i].quarter);
							total.push(parseFloat($scope.CURRENT.caloric_index[i].value).toFixed(2));
						}
					}
					tdCHtml = tdCHtml + "</tr>";
					if(data.length>0)
					{
						item["name"] = name;
						item["data"] = data;
						valueData.push(item);
						if(headerCurLst.length===0)
						{
							headerCurLst = tmpCurLst.slice();
						}
					}
					var thHtml = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerCurLst,function(value){
						thHtml = thHtml + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtml = thHtml + "</tr>";
					$(".dunsCaloricRegCurHeader").html(thHtml);
					$(".dunsCaloricRegCurData").html(tdCHtml);
					DunsCaloricRegionChartService.CaloricRegionChart(valueData,headerCurLst,header,total);
					$("#duns-CalIndexByReg-Cur-Data").dataTable( {                                                       
						"bPaginate": false,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": false,
						"iDisplayLength": 10,
						"bInfo":false,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
				
					endResult['dunsCaloricIndexRegCurDataTable1']=true;
					endResult['dunsCaloricIndexRegCurDataTable2']=false;
				}
				else
				{
					endResult['dunsCaloricIndexRegCurDataTable1']=false;
					endResult['dunsCaloricIndexRegCurDataTable2']=true;
				}
				return endResult;
			},
			updateCaloricbyRegionHistData: function($scope){
				var tmp,name = "",curData,tdHtml = "",tdAHtml = "",valueDataHist = [], dataHist = [],itemHist = {}, headerLst = [], tmpLst = [],endResult={},tdAvghtml = "";
				if ($.fn.DataTable.isDataTable('#duns-CalIndexByReg-His-Data')) {
					$('#duns-CalIndexByReg-His-Data').dataTable().fnDestroy();      
				} 
				if($scope.HISTORY.caloric_index.length>0){
					for(var i=0;i<$scope.HISTORY.caloric_index.length;i++)
						{
						curData = $scope.HISTORY.caloric_index[i].qtr_year;
						if(tmp==null)
						{
							tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.caloric_index[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.caloric_index[i].value+"</td>";
							tmp = $scope.HISTORY.caloric_index[i].qtr_year;
							name = ($scope.HISTORY.caloric_index[i].qtr_year);
							if($scope.HISTORY.caloric_index[i].site_name===null){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.caloric_index[i].site_name);
							}
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.caloric_index[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							itemHist["name"] = name;
							itemHist["data"] = dataHist;
							valueDataHist.push(itemHist);
							if(headerLst.length===0)
							{
								headerLst = tmpLst.slice();
							}
							tdHtml = tdHtml + "</tr><tr><td class='centerTxt'>"+($scope.HISTORY.caloric_index[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.caloric_index[i].value+"</td>";
							tmp = $scope.HISTORY.caloric_index[i].qtr_year;
							name = ($scope.HISTORY.caloric_index[i].qtr_year);
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.caloric_index[i].value));
						}
						else if(curData===tmp)
						{
							tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.caloric_index[i].value+"</td>";
							tmp = $scope.HISTORY.caloric_index[i].qtr_year;
							name = ($scope.HISTORY.caloric_index[i].qtr_year);
							if($scope.HISTORY.caloric_index[i].site_name===null){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.caloric_index[i].site_name);
							}
							dataHist.push(parseFloat($scope.HISTORY.caloric_index[i].value));
						}
					}
					for(i=0;i<$scope.AVERAGE_BASED_ON_YEAR.caloric_index.length;i++)
					{
						curData = $scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].year;
						if(tmp==null)
						{
							tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].average+"</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].year;
						}
						else if(curData!==null && curData!==tmp)
						{ 
							tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].average+"</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].year;
						}
						else if(curData===tmp )
						{
							tdAHtml = tdAHtml + "<td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].average+"</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].year;
						}
					}
					for(i=0;i<$scope.AVERAGE.caloric_index.length;i++)
					{
						tdAvghtml=tdAvghtml + "<td class='centerTxt'>" + parseFloat($scope.AVERAGE.caloric_index[i].average) +"</td>";
						
					}
					var avgHtml = "<tr>"+ "<td class='centerTxt'>"+"Average"+"</td>"+tdAvghtml +"</tr>";
					tdHtml = avgHtml + tdAHtml + tdHtml + "</tr>";
					if(dataHist.length>0)
					{
						itemHist["name"] = name;
						itemHist["data"] = itemHist;
						valueDataHist.push(itemHist);
						if(headerLst.length===0)
						{
							headerLst = tmpLst.slice();
						}
					}
					$(".dunsCaloricRegHisHeader").html('');
					var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(value){
						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtmlHist = thHtmlHist + "</tr>";
					$(".dunsCaloricRegHisHeader").html(thHtmlHist);

					$(".dunsCaloricRegHisData").html(tdHtml);

					
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					
					var  regionData={}, techSummary ={}, techData={};                                                                      
					var regions = [], technologies = [], totalCount={};
					// All Regions and Technologies 
					_.forEach($scope.HISTORY.caloric_index, function(responseObj){
						if(technologies.indexOf(responseObj.site_name) === -1 && responseObj.site_name!==null ){
							technologies.push(responseObj.site_name);
						}
						if(regions.indexOf(responseObj.qtr_year) === -1){
							regions.push(responseObj.qtr_year);
						}  
					});
                    
                    regions.reverse();
                    
					var techTotalCount = {};
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(techSummary, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCount, [region], 0);
							}
						});
					});                           
					_.forEach(technologies, function(technology){
						techData[technology] = [];
						var count = 0;
						_.forEach(regions, function(region){
							if(region!==null){
								(techData[technology])[count] = 0;
								count ++;
							}
						});
					});           
					_.forEach($scope.HISTORY.caloric_index, function(responseObj){
						if(responseObj.qtr_year!==null && responseObj.site_name!==null){
							techTotalCount[responseObj.qtr_year]=techTotalCount[responseObj.qtr_year]+parseFloat(responseObj.value);
							createNestedObject(techSummary, [responseObj.site_name, responseObj.qtr_year], parseFloat(responseObj.value));
						}
					});
					techTotalCount =_.pairs(techTotalCount);
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					var techRankArray = [];
					_.forEach(techTotalCount, function(region){
						techRankArray.push(region[0]);
					});
					var tempArr=[];
					_.forEach(technologies, function(technology){
						_.forEach(techRankArray, function(region){
							((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]);
						});
						tempArr.push({'data': techData[technology], 'name':technology});
					});
					var valueDataforChart = tempArr;
					DunsCaloricRegionChartService.CaloricRegionChartHistory(valueDataforChart,regions);
					
					$("#duns-CalIndexByReg-His-Data").dataTable( {                                                       
						"bPaginate": true,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": true,
						"iDisplayLength": 5,
						"bInfo":true,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
					
					endResult['dunsCaloricIndexRegHistDataTable1']=true;
					endResult['dunsCaloricIndexRegHistDataTable2']=false;
				}
				else
				{
					endResult['dunsCaloricIndexRegHistDataTable1']=false;
					endResult['dunsCaloricIndexRegHistDataTable2']=true;
				}
				return endResult;
			}
		}
	}]);
});
