define(['angular', '../../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('DunsDataService', [function() {
		return{
			downloadhist:function(data,id,report) {
                var site_name, average;
                var excelAverageData = [], keysExcelData = [], keysExcelHeaders = [], excelData = [];
                
                keysExcelHeaders.push("");
                var i=0;
                _.each(data.Average, function(data) {
                    if(data.site_name.toString().trim().replace(/ /g,"_").replace(/[\()]+/g, "")==="zzTotal"){
                    	keysExcelHeaders.push("Total");
                    	
                    }else{
                    	keysExcelHeaders.push(data.site_name);
                    }
                    site_name = data.site_name.trim().replace(/ /g,"_").replace(/[\()]+/g, "");
                    average   = data.average;
                    var objAverageData = {};
                    if(i===0){
                    	objAverageData[""] = "Average";
                    }
                    if(report !== "caloricIndex"){
                    	if(!isNaN(average)){
                    		 objAverageData[site_name] = average+"%";
                        }
                        else{
                        	 objAverageData[site_name] = average;
                        }
                    }
                    else{
                    	objAverageData[site_name] = average;
                    }
                    excelAverageData.push(objAverageData);
                });
                
                var resultAverageObject = excelAverageData.reduce(function(result, currentObject) {
                    for(var key in currentObject) {
                        if (currentObject.hasOwnProperty(key)) {
                            result[key] = currentObject[key];
                        }
                    }
                    return result;
                });
               
                excelData.push(resultAverageObject);
                
                _.each( resultAverageObject, function( val, key ) {
                    keysExcelData.push(key);
                });
                
                var countExcelData = (keysExcelData.length-1);
                var lists = _.groupBy(data.History, function(element, index){
                  return Math.floor(index/countExcelData);
                });
                lists = _.toArray(lists);
                var avgLists = _.groupBy(data.Average_Year, function(element, index){
                    return Math.floor(index/countExcelData);
                  });
                avgLists = _.toArray(avgLists);
                _.each(avgLists, function(data) {
                	var i = 0, excelAvgHistoryData = [], objAvgHistoryData = {};
                	_.each(data, function(list_data) {
                        if(list_data.site_name !== null) {
                            site_name = list_data.site_name.toString().trim().replace(/ /g,"_").replace(/[\()]+/g, "");
                        } else {
                            site_name = "zzTotal";   
                        }
                        
                        average   = list_data.average;
                        
                        if(i === 0) {
                        	objAvgHistoryData[""] = "Average-"+list_data.year;
                        }

                        if(_.contains(keysExcelData, site_name)) {
                        	if(report !== "caloricIndex"){
	                            if (!isNaN(average)) {
	                            	objAvgHistoryData[site_name] = average+"%";
	                            } else {
	                            	objAvgHistoryData[site_name] = average;
	                            }
                        	}else{
                        		objAvgHistoryData[site_name] = average;
                        	}
                        }
                        i++;
                    });
                	excelAvgHistoryData.push(objAvgHistoryData);
                	 var resultAvgHistoryObject = excelAvgHistoryData.reduce(function(result, currentObject) {
                         for(var key in currentObject) {
                             if (currentObject.hasOwnProperty(key)) {
                                 result[key] = currentObject[key];
                             }
                         }
                         return result;
                     });
                     excelData.push(resultAvgHistoryObject);
                });
                _.each(lists, function(data) {
                    var i = 0, excelHistoryData = [], objHistoryData = {};
                    if (report==="fleetPenF2F") {
                        _.each(data, function(list_data) {
                            if(list_data.site_name !== null) {
                                site_name = list_data.site_name.toString().trim().replace(/ /g,"_").replace(/[\()]+/g, "");
                            } else {
                                site_name = "zzTotal";   
                            }
                            
                            average   = list_data.value;
                            
                            if(i === 0) {
                                objHistoryData[""] = list_data.qtr_year;
                            }

                            if(_.contains(keysExcelData, site_name)) {
                                if (!isNaN(average)) {
                                	 objHistoryData[site_name] = average+"%";
                                } else {
                                	 objHistoryData[site_name] = average;
                                }
                            }
                            i++;
                        });
                        excelHistoryData.push(objHistoryData);
                    }
                    
                    if (report==="fleetPenetration") {
                    	  _.each(data, function(list_data) {
	                            if(list_data.site_name !== null) {
	                                site_name = list_data.site_name.toString().trim().replace(/ /g,"_").replace(/[\()]+/g, "");
	                            } else {
	                                site_name = "zzTotal";   
	                            }
	                            
	                            average   = list_data.value;
                              
                                if(i === 0) {
                                    objHistoryData[""] = list_data.qtr_year;
                                }
	                            
	                            if(_.contains(keysExcelData, site_name)) {
                                    if(!isNaN(average)){
                                	   objHistoryData[site_name] = average+"%";
                                    } else {
                                	   objHistoryData[site_name] = average;
                                    }
	                            }
	                            i++;
	                        });
                            excelHistoryData.push(objHistoryData);
                    }
                    
                     if(report==="fleetCoverage"){
                        _.each(data, function(list_data) {
                            if(list_data.site_name !== null) {
                                site_name = list_data.site_name.toString().trim().replace(/ /g,"_").replace(/[\()]+/g, "");
                            } else {
                                site_name = "zzTotal";   
                            }
                            
                            average   = list_data.value;
                            
                            if(i === 0) {
                                objHistoryData[""] = list_data.qtr_year;
                            }
                            
                            if(_.contains(keysExcelData, site_name)) {
                                if(!isNaN(average)) {
                                	 objHistoryData[site_name] = average+"%";
                                } else {
                                	 objHistoryData[site_name] = average;
                                }
                            }
                            i++;
                        });
                        excelHistoryData.push(objHistoryData);
                    }
                    
                     if(report==="caloricIndex") {
                        _.each(data, function(list_data) {
                            if(list_data.site_name !== null) {
                                site_name = list_data.site_name.toString().trim().replace(/ /g,"_").replace(/[\()]+/g, "");
                            } else {
                                site_name = "zzTotal";   
                            }
                            
                            average   = list_data.value;
                            
                            if(i === 0) {
                                objHistoryData[""] = list_data.qtr_year;
                            }
                            
                            if(_.contains(keysExcelData, site_name)) {
                                objHistoryData[site_name] = average;
                            }
                            i++;
                        });
                        excelHistoryData.push(objHistoryData);
                    }
                    var resultHistoryObject = excelHistoryData.reduce(function(result, currentObject) {
                        for(var key in currentObject) {
                            if (currentObject.hasOwnProperty(key)) {
                                result[key] = currentObject[key];
                            }
                        }
                        return result;
                    });
                    excelData.push(resultHistoryObject);
                });
                
                var returnObj = {};
				returnObj['id'] = id;
				returnObj['keysExcelHeaders'] = keysExcelHeaders;
				returnObj['excelData'] = excelData;
				return returnObj;
	},
    
    
     excelDownload:function(data,id,$scope) {
                var site_name, average;
                var excelAverageData = [], keysExcelHeaders = [], excelData = [];
                
                if(id === "duns-Opex-Pen-F2F-Cur-Data"){
                _.each(data.Current, function(data) {
                	if(data.site_name !== null){  
                	site_name = data.site_name;
                    average   = data.value;
                    var objAverageData = {};
                    if(!isNaN(average)){
                    	objAverageData[site_name] = average+"%";
                    }
                    else{
                    	objAverageData[site_name] = average;
                    }
                    excelAverageData.push(objAverageData);
                    $scope.qtryr=data.year+"-"+data.quarter;
                  }
                });
                }
                
                if(id=== "duns-Fleet-Penetration-Cur-Data"){
                    _.each(data.Current, function(data) {
                    	if(data.site_name!==null)
                        {
                        site_name = data.site_name;
                        average   = data.value;
                        var objAverageData = {};
                        if(!isNaN(average)){
                        	objAverageData[site_name] = average+"%";
                        }
                        else{
                        	objAverageData[site_name] = average;
                        }
                        
                        excelAverageData.push(objAverageData);
                        $scope.qtryr=data.year+"-"+data.quarter;
                        }
                    });
                    }
                
                if(id === "duns-Fleet-coverage-Data"){
                    _.each(data.Current, function(data) {
                    	if(data.site_name!==null)
                        {
                        site_name = data.site_name;
                        average   = data.value;
                        var objAverageData = {};
                        if(!isNaN(average)){
                        	objAverageData[site_name] = average+"%";
                        }
                        else{
                        	objAverageData[site_name] = average;
                        }
                        excelAverageData.push(objAverageData);
                        $scope.qtryr=data.year+"-"+data.quarter;
                        }
                    });
                    }
                
                
                if(id === "duns-CalIndexByReg-Cur-Data"){
                    _.each(data.Current, function(data) {
                    	if(data.site_name!==null)
                        {
                        site_name = data.site_name;
                        average   = data.value;
                        var objAverageData = {};
                        objAverageData[site_name] = average;
                        
                        excelAverageData.push(objAverageData);
                        $scope.qtryr=data.year+"-"+data.quarter;
                        }
                    });
                    }
                var resultAverageObject = excelAverageData.reduce(function(result, currentObject) {
                    result[''] = $scope.qtryr;
                    for(var key in currentObject) {
                        if (currentObject.hasOwnProperty(key)) {
                            result[key] = currentObject[key];
                        }
                    }
                    return result;
                }, {});
                
                excelData.push(resultAverageObject);
                _.each( resultAverageObject, function( val, key ) {
                	if(key==="zzTotal"){
                		keysExcelHeaders.push("Total");
                	}
                	else{
                		keysExcelHeaders.push(key);
                	}
                	
                });
                var returnObj = {};
				returnObj['id'] = id;
				returnObj['keysExcelHeaders'] = keysExcelHeaders;
				returnObj['excelData'] = excelData;
				return returnObj;
     		}
		}
	}]);
});