define(['angular', '../../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('DunsOpexpenetrationCurDataService', ['DunsOpexPenetrationChartService',function(DunsOpexPenetrationChartService) {
		return{
			updateOpexpenetrationCurData : function($scope){
				/* Opex Penetration F2F CURRENT Data fun */
				var valueData = [], data = [], item , tmp, name = "", curData, tdCHtml = "", headerCurLst = [], tmpCurLst = [],
				total=[], header=[], endResults={};
				if ($.fn.DataTable.isDataTable('#duns-Opex-Pen-F2F-Cur-Data')) {
					$('#duns-Opex-Pen-F2F-Cur-Data').dataTable().fnDestroy();      
				}  
				if($scope.CURRENT.fleet_pen_f2f.length>0){
					for(var i=0;i<$scope.CURRENT.fleet_pen_f2f.length;i++)
					{
						curData = $scope.CURRENT.fleet_pen_f2f[i].quarter;
						if(tmp==null && ($scope.CURRENT.fleet_pen_f2f[i].site_name)!==null)
						{
							if(!isNaN($scope.CURRENT.fleet_pen_f2f[i].value))
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_pen_f2f[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_pen_f2f[i].value+"</td>";
							}
							tmp = $scope.CURRENT.fleet_pen_f2f[i].quarter;
							name = ($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter);
							tmpCurLst.push($scope.CURRENT.fleet_pen_f2f[i].site_name);
							data = [];
							data.push(parseFloat($scope.CURRENT.fleet_pen_f2f[i].value));
						}
						else if((curData!==null && curData!==tmp) && ($scope.CURRENT.fleet_pen_f2f[i].site_name)!==null)
						{
							item["name"] = name; 
							item["data"] = data;
							valueData.push(item);
							if(headerCurLst.length===0)
							{
								headerCurLst = tmpCurLst.slice();
							}
							if(($scope.CURRENT.fleet_pen_f2f[i].site_name)!==null)
							{
								if(!isNaN($scope.CURRENT.fleet_pen_f2f[i].value))
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_pen_f2f[i].value+"%</td>";
								}
								else
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_pen_f2f[i].value+"</td>";
								}
								tmp = $scope.CURRENT.fleet_pen_f2f[i].quarter;
								name = ($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter);
								data = [];
								data.push(parseFloat($scope.CURRENT.fleet_pen_f2f[i].value));
							}
						}
						else if(curData===tmp && ($scope.CURRENT.fleet_pen_f2f[i].site_name)!==null)
						{
							if(!isNaN($scope.CURRENT.fleet_pen_f2f[i].value))
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.fleet_pen_f2f[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.fleet_pen_f2f[i].value+"</td>";
							}
							tmp = $scope.CURRENT.fleet_pen_f2f[i].quarter;
							name = ($scope.CURRENT.fleet_pen_f2f[i].year+" - "+$scope.CURRENT.fleet_pen_f2f[i].quarter);
							data.push(parseFloat($scope.CURRENT.fleet_pen_f2f[i].value));
							tmpCurLst.push($scope.CURRENT.fleet_pen_f2f[i].site_name);
						}
						if(($scope.CURRENT.fleet_pen_f2f[i].site_name) === null)
						{	
							header.push($scope.CURRENT.fleet_pen_f2f[i].quarter);
							total.push(parseFloat($scope.CURRENT.fleet_pen_f2f[i].value));
						}
					}
					tdCHtml = tdCHtml + "</tr>";
					if(data.length>0)
					{
						item={};
						item["name"] = name;
						item["data"] = data;
						valueData.push(item);
						if(headerCurLst.length===0)
						{
							headerCurLst = tmpCurLst.slice();
						}
					}
					var thHtml = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerCurLst,function(value){
						thHtml = thHtml + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtml = thHtml + "</tr>";
					$(".dunsOpexPenCurHeader").html(thHtml);
					$(".dunsOpexPenCurData").html(tdCHtml);
					DunsOpexPenetrationChartService.OpexPenetrationChart(valueData,headerCurLst,header,total);				
					$("#duns-Opex-Pen-F2F-Cur-Data").dataTable( {                                                       
						"bPaginate": false,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": false,
						"iDisplayLength": 10,
						"bInfo":false,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
					endResults['dunsOpexpenetrationF2FCurDataTable1']=true;
					endResults['dunsOpexpenetrationF2FCurDataTable2']=false;
				}
				else
				{
					endResults['dunsOpexpenetrationF2FCurDataTable2']=true;
					endResults['dunsOpexpenetrationF2FCurDataTable1']=false;
				}
				return endResults;
			},
			updateOpexpenetrationHistData: function ($scope){
				var tmp,name = "",curData,tdAHtml = "",tdHtml = "",valueDataHist = [], dataHist = [],itemHist = {}, headerLst = [], tmpLst = [],endResults={},tdAvghtml = "";
				if ($.fn.DataTable.isDataTable('#duns-Opex-Pen-F2F-His-Data')) {
					$('#duns-Opex-Pen-F2F-His-Data').dataTable().fnDestroy();      
				} 
				if($scope.HISTORY.fleet_pen_f2f.length>0){
					for(var i=0;i<$scope.HISTORY.fleet_pen_f2f.length;i++)
					{
						curData = $scope.HISTORY.fleet_pen_f2f[i].qtr_year;
						if(tmp==null)
						{
							if(!isNaN($scope.HISTORY.fleet_pen_f2f[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_pen_f2f[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_pen_f2f[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_pen_f2f[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_pen_f2f[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_pen_f2f[i].qtr_year;
							name = ($scope.HISTORY.fleet_pen_f2f[i].qtr_year);
							if(($scope.HISTORY.fleet_pen_f2f[i].site_name)===null){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.fleet_pen_f2f[i].site_name);
							}
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.fleet_pen_f2f[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							itemHist["name"] = name;
							itemHist["data"] = dataHist;
							valueDataHist.push(itemHist);
							if(headerLst.length===0)
							{
								headerLst = tmpLst.slice();
							}
							if(!isNaN($scope.HISTORY.fleet_pen_f2f[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_pen_f2f[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_pen_f2f[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_pen_f2f[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_pen_f2f[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_pen_f2f[i].qtr_year;
							name = ($scope.HISTORY.fleet_pen_f2f[i].qtr_year);
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.fleet_pen_f2f[i].value));
						}
						else if(curData===tmp)
						{
							if(!isNaN($scope.HISTORY.fleet_pen_f2f[i].value))
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.fleet_pen_f2f[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.fleet_pen_f2f[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_pen_f2f[i].qtr_year;
							name = ($scope.HISTORY.fleet_pen_f2f[i].qtr_year);
							if(($scope.HISTORY.fleet_pen_f2f[i].site_name)===null){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.fleet_pen_f2f[i].site_name);
							}
							dataHist.push(parseFloat($scope.HISTORY.fleet_pen_f2f[i].value));

						}
					}
					for(i=0;i<$scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f.length;i++)
					{
						curData = $scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].year;
						if(tmp==null)
						{
							tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].year;
						}
						else if(curData!==null && curData!==tmp)
						{ 
							tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].year;
						}
						else if(curData===tmp )
						{
							tdAHtml = tdAHtml + "<td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_pen_f2f[i].year;
						}
					}
					for(i=0;i<$scope.AVERAGE.fleet_pen_f2f.length;i++)
					{
						tdAvghtml=tdAvghtml + "<td class='centerTxt'>" + parseFloat($scope.AVERAGE.fleet_pen_f2f[i].average) +"%</td>";
						
					}
					var avgHtml = "<tr>"+ "<td class='centerTxt'>"+"Average"+"</td>"+tdAvghtml +"</tr>";
					tdHtml = avgHtml + tdAHtml + tdHtml + "</tr>";
					if(dataHist.length>0)
					{
						itemHist["name"] = name;
						itemHist["data"] = itemHist;
						valueDataHist.push(itemHist);
						if(headerLst.length===0)
						{
							headerLst = tmpLst.slice();
						}
					}
					$(".dunsOpexPenHisHeader").html('');
					var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(value){
						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtmlHist = thHtmlHist + "</tr>";
					$(".dunsOpexPenHisHeader").html(thHtmlHist);	
					$(".dunsOpexPenHisData").html(tdHtml);
					
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					
					var regionData={}, techSummary ={}, techData={};                                                                      
					var regions = [], technologies = [], totalCount={};
					// All Regions and Technologies 
					_.forEach($scope.HISTORY.fleet_pen_f2f, function(responseObj){
						if(technologies.indexOf(responseObj.site_name) === -1 && responseObj.site_name!==null){
							technologies.push(responseObj.site_name);
						}
						if(regions.indexOf(responseObj.qtr_year) === -1){
							regions.push(responseObj.qtr_year);
						}  
					});
                    
                    regions.reverse();
                    
					var techTotalCount = {};
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(techSummary, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCount, [region], 0);
							}
						});
					});                           
					_.forEach(technologies, function(technology){
						techData[technology] = [];
						var count = 0;
						_.forEach(regions, function(region){
							if(region!==null){
								(techData[technology])[count] = 0;
								count ++;
							}
						});
					});           
					_.forEach($scope.HISTORY.fleet_pen_f2f, function(responseObj){
						if(responseObj.qtr_year!==null && (responseObj.site_name)!==null){
							techTotalCount[responseObj.qtr_year]=techTotalCount[responseObj.qtr_year]+parseFloat(responseObj.value);
							createNestedObject(techSummary, [responseObj.site_name,responseObj.qtr_year], parseFloat(responseObj.value));
						}
					});
					techTotalCount =_.pairs(techTotalCount);
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					var techRankArray = [];
					_.forEach(techTotalCount, function(region){
						techRankArray.push(region[0]);
					});
					var tempArr=[];
					_.forEach(technologies, function(technology){
						_.forEach(techRankArray, function(region){
							((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]);
						});
						tempArr.push({'data': techData[technology], 'name':technology});
					});
					var valueDataforChart = tempArr;
					DunsOpexPenetrationChartService.OpexPenetrationHistoryChart(valueDataforChart,regions);
					$("#duns-Opex-Pen-F2F-His-Data").dataTable( {                                                       
						"bPaginate": true,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": true,
						"iDisplayLength": 5,
						"bInfo":true,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
					endResults['dunsOpexpenetrationF2FHistDataTable1']=true;
					endResults['dunsOpexpenetrationF2FHistDataTable2']=false;
				}
				else
				{
					endResults['dunsOpexpenetrationF2FHistDataTable2']=true;
					endResults['dunsOpexpenetrationF2FHistDataTable1']=false;
				}
				return endResults;
			}
		}
	}]);
});
