define(['angular', '../../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('DunsFleetpenetrationDataService', ['DunsFleetPenetrationChartService',function(DunsFleetPenetrationChartService) {
		return{
			updateFleetpenetrationData:function($scope){
				var valueData = [], data = [], item={}, tmp, name = "", curData, tdCHtml = "", headerCurLst = [], tmpCurLst = [],
				total = [], header = [], endResult={};
				if ($.fn.DataTable.isDataTable('#duns-Fleet-Penetration-Cur-Data')) {
					$('#duns-Fleet-Penetration-Cur-Data').dataTable().fnDestroy();      
				}  
				if($scope.CURRENT.fleet_penetration.length>0){	
					for(var i=0;i<$scope.CURRENT.fleet_penetration.length;i++)
					{	
						curData = $scope.CURRENT.fleet_penetration[i].quarter;
						if(tmp==null && ($scope.CURRENT.fleet_penetration[i].site_name)!==null)
						{
							if(!isNaN($scope.CURRENT.fleet_penetration[i].value))
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_penetration[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_penetration[i].value+"</td>";
							}
							tmp = $scope.CURRENT.fleet_penetration[i].quarter;
							name = ($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter);
							tmpCurLst.push($scope.CURRENT.fleet_penetration[i].site_name);
							data = [];
							data.push(parseFloat($scope.CURRENT.fleet_penetration[i].value));
						}
						else if((curData!==null && curData!==tmp) && ($scope.CURRENT.fleet_penetration[i].site_name)!==null)
						{
							item["name"] = name;
							item["data"] = data;
							valueData.push(item);
							if(headerCurLst.length===0)
							{
								headerCurLst = tmpCurLst.slice();
							}
							if(($scope.CURRENT.fleet_penetration[i].site_name)!== null)
							{
								if(!isNaN($scope.CURRENT.fleet_penetration[i].value))
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_penetration[i].value+"%</td>";
								}
								else
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_penetration[i].value+"</td>";
								}
								tmp = $scope.CURRENT.fleet_penetration[i].quarter;
								name = ($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter);
								data = [];
								data.push(parseFloat($scope.CURRENT.fleet_penetration[i].value));
							}
						}
						else if(curData===tmp && ($scope.CURRENT.fleet_penetration[i].site_name)!== null )
						{
							if(!isNaN($scope.CURRENT.fleet_penetration[i].value))
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.fleet_penetration[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.fleet_penetration[i].value+"</td>";
							}
							tmp = $scope.CURRENT.fleet_penetration[i].quarter;
							name = ($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter);
							data.push(parseFloat($scope.CURRENT.fleet_penetration[i].value));
							tmpCurLst.push($scope.CURRENT.fleet_penetration[i].site_name);
						}
						if(($scope.CURRENT.fleet_penetration[i].site_name)===null)
						{	
							header.push($scope.CURRENT.fleet_penetration[i].quarter);
							total.push(parseFloat($scope.CURRENT.fleet_penetration[i].value));
						}
					}
					tdCHtml = tdCHtml + "</tr>";
					if(data.length>0)
					{
						item["name"] = name;
						item["data"] = data;
						valueData.push(item);
						if(headerCurLst.length===0)
						{
							headerCurLst = tmpCurLst.slice();
						}
					}
					var thHtml = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerCurLst,function(value){
						thHtml = thHtml + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtml = thHtml + "</tr>";
					$(".dunsFleetPenCurHeader").html(thHtml);
					$(".dunsFleetPenCurData").html(tdCHtml);
					DunsFleetPenetrationChartService.fleetPenetrationChart(valueData,headerCurLst,header,total);
					$("#duns-Fleet-Penetration-Cur-Data").dataTable( {                                                       
						"bPaginate": false,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": false,
						"iDisplayLength": 10,
						"bInfo":false,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
					endResult['dunsFleetpenetrationCurDataTable1']=true;
					endResult['dunsFleetpenetrationCurDataTable2']=false;
				}
				else
				{
					endResult['dunsFleetpenetrationCurDataTable1']=false;
					endResult['dunsFleetpenetrationCurDataTable2']=true;
				}	
				return	endResult;			
			},
			updateFleetpenetrationHistData:function($scope){
				var tmp,name = "",curData,tdAHtml = "",tdHtml = "",valueDataHist = [], dataHist = [],itemHist = {}, headerLst = [], tmpLst = [],endResult={},tdAvghtml = "";
				if ($.fn.DataTable.isDataTable('#duns-Fleet-Penetration-His-Data')) {
					$('#duns-Fleet-Penetration-His-Data').dataTable().fnDestroy();      
				} 
				if($scope.HISTORY.fleet_penetration.length>0){
					for(var i=0;i<$scope.HISTORY.fleet_penetration.length;i++)
						{
							curData = $scope.HISTORY.fleet_penetration[i].qtr_year;
							if(tmp==null)
							{
							if(!isNaN($scope.HISTORY.fleet_penetration[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_penetration[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_penetration[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_penetration[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_penetration[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_penetration[i].qtr_year;
							name = ($scope.HISTORY.fleet_penetration[i].qtr_year);
							if(($scope.HISTORY.fleet_penetration[i].site_name)===null){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.fleet_penetration[i].site_name);
							}
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.fleet_penetration[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							itemHist["name"] = name;
							itemHist["data"] = dataHist;
							valueDataHist.push(itemHist);
							if(headerLst.length===0)
							{
								headerLst = tmpLst.slice();
							}
							if(!isNaN($scope.HISTORY.fleet_penetration[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_penetration[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_penetration[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_penetration[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_penetration[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_penetration[i].qtr_year;
							name = ($scope.HISTORY.fleet_penetration[i].qtr_year);
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.fleet_penetration[i].value));
						}
						else if(curData===tmp)
						{
							if(!isNaN($scope.HISTORY.fleet_penetration[i].value))
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.fleet_penetration[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.fleet_penetration[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_penetration[i].qtr_year;
							name = ($scope.HISTORY.fleet_penetration[i].qtr_year);
							if(($scope.HISTORY.fleet_penetration[i].site_name)===null){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.fleet_penetration[i].site_name);
							}
							dataHist.push(parseFloat($scope.HISTORY.fleet_penetration[i].value));
						}
					}
					for(i=0;i<$scope.AVERAGE_BASED_ON_YEAR.fleet_penetration.length;i++)
					{
						curData = $scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].year;
						if(tmp==null)
						{
							tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].year;
						}
						else if(curData!==null && curData!==tmp)
						{ 
							tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].year;
						}
						else if(curData===tmp )
						{
							tdAHtml = tdAHtml + "<td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].year;
						}
					}
					for(i=0;i<$scope.AVERAGE.fleet_penetration.length;i++)
					{
						tdAvghtml=tdAvghtml + "<td class='centerTxt'>" + parseFloat($scope.AVERAGE.fleet_penetration[i].average) +"%</td>";
					
					}
					var avgHtml = "<tr>"+ "<td class='centerTxt'>"+"Average"+"</td>"+tdAvghtml +"</tr>";
					tdHtml = avgHtml + tdAHtml + tdHtml + "</tr>";
					if(dataHist.length>0)
					{
						itemHist["name"] = name;
						itemHist["data"] = itemHist;
						valueDataHist.push(itemHist);
						if(headerLst.length===0)
						{
							headerLst = tmpLst.slice();
						}
					}
					$(".dunsFleetPenHisHeader").html('');
					var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(value){
						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtmlHist = thHtmlHist + "</tr>";
					$(".dunsFleetPenHisHeader").html(thHtmlHist);
					$(".dunsfleetPenHisData").html(tdHtml);
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					
					var regionData={}, techSummary ={}, techData={};                                                                      
					var regions = [],  technologies = [], totalCount={};
					/* All Regions and Technologies */
					_.forEach($scope.HISTORY.fleet_penetration, function(responseObj){
						if(technologies.indexOf(responseObj.site_name) === -1 && responseObj.site_name!==null){
							technologies.push(responseObj.site_name);
						}
						if(regions.indexOf(responseObj.qtr_year) === -1){
							regions.push(responseObj.qtr_year);
						}  
					});
                    
                    regions.reverse();
                    
					var techTotalCount = {};
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(techSummary, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCount, [region], 0);
							}
						});
					});                           
					_.forEach(technologies, function(technology){
						techData[technology] = [];
						var count = 0;
						_.forEach(regions, function(region){
							if(region!==null){
								(techData[technology])[count] = 0;
								count ++;
							}
						});
					});           
					_.forEach($scope.HISTORY.fleet_penetration, function(responseObj){
						if(responseObj.qtr_year!==null && (responseObj.site_name)!==null){
							techTotalCount[responseObj.qtr_year]=techTotalCount[responseObj.qtr_year]+parseFloat(responseObj.value);
							createNestedObject(techSummary, [responseObj.site_name, responseObj.qtr_year], parseFloat(responseObj.value));
						}
					});
					techTotalCount =_.pairs(techTotalCount);
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					var techRankArray = [];
					_.forEach(techTotalCount, function(region){
						techRankArray.push(region[0]);
					});
					var tempArr=[];
					_.forEach(technologies, function(technology){
						_.forEach(techRankArray, function(region){
							((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]);
						});
						tempArr.push({'data': techData[technology], 'name':technology});
					});
					var valueDataforChart = tempArr;
					DunsFleetPenetrationChartService.fleetPenetrationChartHistory(valueDataforChart,regions);
					
					$("#duns-Fleet-Penetration-His-Data").dataTable( {                                                       
						"bPaginate": true,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": true,
						"iDisplayLength": 5,
						"bInfo":true,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
					endResult['dunsFleetpenetrationHistDataTable1']=true;
					endResult['dunsFleetpenetrationHistDataTable2']=false;
				}
				else
				{
					endResult['dunsFleetpenetrationHistDataTable1']=false;
					endResult['dunsFleetpenetrationHistDataTable2']=true;
				}
				return	endResult;			
			}
		}
	}]);
});
