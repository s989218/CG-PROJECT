define([
	'./IBbyRegionCurData',
	'./NetworkService',
	'./IBObyRegionRevenueCurData',
	'./FleetpenetrationData',
	'./OpexpenetrationCurData',
	'./fleetcoverageData',
	'./CaloricbyRegionCurData',
	'./conversionIndexData',
	'./iBObyTechData',
	'./iBNbyRegionData',
	'./iBNbyTechData',
	'./partsPenCurData',
	'./ChartServices/chartFiles',
	'./countryLevelServices/countryLevelFiles',
	'./technologyLevelServices/techLevelFiles',
	'./siteLevelServices/siteLevelFiles',
	'./geDunsServices/geDunsLevelFiles',
	'./SegmentLevelServices/segmentLevelFiles'
	], function() {

});
