define(['angular', '../../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('SiteExportDataService', ['$timeout', function($timeout) {
		return{
			excelHistoryDataDownload:function(id, keysExcelHeaders, excelData){  
	            var columns = [];
	            _.forEach(keysExcelHeaders, function(data){
	                columns.push(data);
	            });

	            var tableToExcel = (function() {
	                var subHeader,ctx,href;
	                var uri = 'data:application/vnd.ms-excel;base64,'
	                , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                         , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                         , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                return function(table) {
	                    if (!table.nodeType) 
	                         table = document.getElementById(id);
	                    var excelContent = '';
	                    var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                    
	                    if(id ==='site-Opex-Pen-F2F-Cur-Data')
	                    {
		                       subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                        "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Opex Penetration F2F Current Data</span>"+
	                        "</td></tr>";
	                    }
	                    if(id ==='site-Opex-Pen-F2F-His-Data')
	                    {
		                       subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                        "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Opex Penetration F2F History Data</span>"+
	                        "</td></tr>";
	                    }
	                    if(id ==='site-Fleet-coverage-Data')
	                    {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                        "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Coverage Current Data</span>"+
	                        "</td></tr>";
	                    }
	                    if(id === "sitefleetCovTable")
	                    {
	                    	 subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                         "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Coverage History Data</span>"+
	                         "</td></tr>";

	                    }
	                    if(id ==='site-Fleet-Penetration-Cur-Data')
	                    {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                        "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Penetration Current Data</span>"+
	                        "</td></tr>";
	                    }
	                    if(id ==='site-Fleet-Penetration-His-Data')
	                    {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                        "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Penetration History Data</span>"+
	                        "</td></tr>";
	                    }
	                    if(id ==='site-CalIndexByReg-Cur-Data')
	                    {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                        "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Caloric Index By Region Current Data</span>"+
	                        "</td></tr>";
	                    }
	                    if(id ==='site-CalIndexByReg-His-Data')
	                    {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                        "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Caloric Index By Region History Data</span>"+
	                        "</td></tr>";
	                    }
	                   
	                    excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                    excelContent = excelContent + subHeader;
	              
	                    var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                    var tdNumber = "<td style='mso-number-format:0'>";
	                    excelContent =excelContent + '<tr>';
	                    var flag = 0;
	                      _.forEach(columns, function(column){
	                    	if(id ==='site-CalIndexByReg-Cur-Data' || id ==='site-CalIndexByReg-His-Data'){
	                    		excelContent = excelContent + th + column + '</th>';
	                    	}else{
	                    		 if(columns[0]!== 'null' && flag === 0){
	                                   excelContent = excelContent + th + column + '</th>';
	                                   flag++;
	                            }else {
	                                   excelContent = excelContent + th + column +'(%)' + '</th>';
	                            }
	                    	}
                           
	                      });
	                    excelContent = excelContent + '</tr>';
	                    _.forEach(excelData, function(row){
	                        excelContent =excelContent + '<tr>';
	                        if(id ==='site-CalIndexByReg-Cur-Data' || id ==='site-CalIndexByReg-His-Data'){
	                        	_.forEach(row, function(rowData){
		                            if((/^[0-9]{0,}$/).test(rowData))
		                                excelContent = excelContent + tdNumber + rowData + '</td>';
		                            else
		                                excelContent = excelContent + '<td>' + rowData + '</td>';
		                        });
	                        }else{
	                        	 _.forEach(row, function(rowData){
	 	                        	rowData = rowData.replace(/K/g, "");
	                                 if (rowData.includes('%')) {
	                               	  rowData = rowData.substring(0,rowData.length-1);
	                                 }
	 	                            if((/^[0-9]{0,}$/).test(rowData))
	 	                                excelContent = excelContent + tdNumber + rowData + '</td>';
	 	                            else
	 	                                excelContent = excelContent + '<td>' + rowData + '</td>';
	 	                        });
	                        }
	                       
	                        excelContent =excelContent + '</tr>';
	                    });
	                    excelContent =excelContent + '<tr>';
	                    excelContent =excelContent + '</tr>';
	                    
	                    $timeout(function(){
	                    	  ctx  = {worksheet: id , table: excelContent};
	                    	  href = (uri + base64(format(template, ctx)));
                               var link = document.createElement("a");
                               link.download = id+".xls";
                               link.href = href;
                               link.click(); 

	                      }, 100);
	                 
	                }
	                })();
	                tableToExcel(id, keysExcelHeaders, excelData);
	                return null;
			}
		}
	}]);
});
