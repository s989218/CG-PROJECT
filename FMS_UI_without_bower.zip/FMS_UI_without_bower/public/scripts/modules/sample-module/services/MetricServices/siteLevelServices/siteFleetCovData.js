define(['angular', '../../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('SiteFleetcoverageDataService', ['SiteFleetCoverageChartService',function(SiteFleetCoverageChartService) {
		return{
			updateFleetcoverageData:function ($scope){
				var valueData = [], data = [], item ={} , tmp, name = "", curData, tdCHtml = "", headerCurLst = [], tmpCurLst = [],
				total = [], header = [], endResults={};
					if ($.fn.DataTable.isDataTable('#site-Fleet-coverage-Data')) {
						$('#site-Fleet-coverage-Data').dataTable().fnDestroy();      
					} 
					for(var i=0;i<$scope.CURRENT.fleet_coverage.length;i++)
					{
						curData = $scope.CURRENT.fleet_coverage[i].quarter;
						if(tmp==null && ($scope.CURRENT.fleet_coverage[i].site_name)!==null)
						{ 
							if(!isNaN($scope.CURRENT.fleet_coverage[i].value))
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_coverage[i].year+" - "+$scope.CURRENT.fleet_coverage[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_coverage[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_coverage[i].year+" - "+$scope.CURRENT.fleet_coverage[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_coverage[i].value+"</td>";
							}
							tmp = $scope.CURRENT.fleet_coverage[i].quarter;
							name = ($scope.CURRENT.fleet_coverage[i].year+" - "+$scope.CURRENT.fleet_coverage[i].quarter);
							tmpCurLst.push($scope.CURRENT.fleet_coverage[i].site_name);
							data = [];
							data.push(parseFloat($scope.CURRENT.fleet_coverage[i].value));
						}
						else if((curData!==null && curData!==tmp) && ($scope.CURRENT.fleet_coverage[i].site_name)!==null)
						{ 
                            item["name"] = name;
							item["data"] = data;
							valueData.push(item);
							if(headerCurLst.length===0)
							{
								headerCurLst = tmpCurLst.slice();
							}
							if(($scope.CURRENT.fleet_coverage[i].site_name)!==null)
							{
								if(!isNaN($scope.CURRENT.fleet_coverage[i].value))
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_coverage[i].year+" - "+$scope.CURRENT.fleet_coverage[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_coverage[i].value+"%</td>";
								}
								else
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_coverage[i].year+" - "+$scope.CURRENT.fleet_coverage[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_coverage[i].value+"</td>";
								}
								tmp = $scope.CURRENT.fleet_coverage[i].quarter;
								name = ($scope.CURRENT.fleet_coverage[i].year+" - "+$scope.CURRENT.fleet_coverage[i].quarter);
								data = [];
								data.push(parseFloat($scope.CURRENT.fleet_coverage[i].value));
							}
						}
						else if(curData===tmp && ($scope.CURRENT.fleet_coverage[i].site_name)!==null)
						{
							if(!isNaN($scope.CURRENT.fleet_coverage[i].value))
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.fleet_coverage[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.fleet_coverage[i].value+"</td>";
							}
							tmp = $scope.CURRENT.fleet_coverage[i].quarter;
							name = ($scope.CURRENT.fleet_coverage[i].year+" - "+$scope.CURRENT.fleet_coverage[i].quarter);
							data.push(parseFloat($scope.CURRENT.fleet_coverage[i].value));
							tmpCurLst.push($scope.CURRENT.fleet_coverage[i].site_name);
						}
						if(($scope.CURRENT.fleet_coverage[i].site_name)===null)
						{	
							header.push($scope.CURRENT.fleet_coverage[i].quarter);
							total.push(parseFloat($scope.CURRENT.fleet_coverage[i].value));
						}
					}
                    
					tdCHtml = tdCHtml + "</tr>";
					if(data.length>0)
					{
						item["name"] = name;
						item["data"] = data;
						valueData.push(item);
						if(headerCurLst.length===0)
						{
							headerCurLst = tmpCurLst.slice();
						}
					}
					var thHtml = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerCurLst,function(value){                        
						thHtml = thHtml + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtml = thHtml + "</tr>";
					$(".siteFleetcoverageHeader").html(thHtml);
					$(".siteFleetcoverageData").html(tdCHtml);
					SiteFleetCoverageChartService.fleetCoverageChart(valueData,headerCurLst,header,total);
					$("#site-Fleet-coverage-Data").dataTable( {                                                       
						"bPaginate": false,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": false,
						"iDisplayLength": 10,
						"bInfo":false,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
				if(total>0){
					endResults['siteFleetcoverageCurDataTable1']=true;
					endResults['siteFleetcoverageCurDataTable2']=false;
				}
				else
				{
					endResults['siteFleetcoverageCurDataTable1']=false;
					endResults['siteFleetcoverageCurDataTable2']=true;
				}	
				return	endResults;		
			},
			updateFleetcoverageHistData:function($scope){
				var tmp,name = "",curData,tdAHtml = "",tdHtml = "",tdAvghtml = "",valueDataHist = [], dataHist = [],itemHist = {}, headerLst = [], tmpLst = [],endResult={};
				if ($.fn.DataTable.isDataTable('#sitefleetCovTable')) {
					$('#sitefleetCovTable').dataTable().fnDestroy();      
				} 	
				if($scope.HISTORY.fleet_coverage.length>0){
				for(var i=0;i<$scope.HISTORY.fleet_coverage.length;i++)
					{
						curData = $scope.HISTORY.fleet_coverage[i].qtr_year;
						if(tmp==null)
						{
							if(!isNaN($scope.HISTORY.fleet_coverage[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_coverage[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_coverage[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_coverage[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_coverage[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_coverage[i].qtr_year;
							name = ($scope.HISTORY.fleet_coverage[i].qtr_year);
							if(($scope.HISTORY.fleet_coverage[i].site_name)===null){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.fleet_coverage[i].site_name);
							}
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.fleet_coverage[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							itemHist["name"] = name;
							itemHist["data"] = dataHist;
							valueDataHist.push(itemHist);
							if(headerLst.length===0)
							{
								headerLst = tmpLst.slice();
							}
							if(!isNaN($scope.HISTORY.fleet_coverage[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_coverage[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_coverage[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_coverage[i].qtr_year)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_coverage[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_coverage[i].qtr_year;
							name = ($scope.HISTORY.fleet_coverage[i].qtr_year);
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.fleet_coverage[i].value));
						}
						else if(curData===tmp)
						{
							if(!isNaN($scope.HISTORY.fleet_coverage[i].value))
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.fleet_coverage[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.fleet_coverage[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_coverage[i].qtr_year;
							name = ($scope.HISTORY.fleet_coverage[i].qtr_year);
							if(($scope.HISTORY.fleet_coverage[i].site_name)===null){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.fleet_coverage[i].site_name);
							}
							dataHist.push(parseFloat($scope.HISTORY.fleet_coverage[i].value));
						}
					}
					for(i=0;i<$scope.AVERAGE_BASED_ON_YEAR.fleet_coverage.length;i++)
					{
						curData = $scope.AVERAGE_BASED_ON_YEAR.fleet_coverage[i].year;
						if(tmp==null)
						{
							tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.fleet_coverage[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_coverage[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_coverage[i].year;
						}
						else if(curData!==null && curData!==tmp)
						{ 
							tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.fleet_coverage[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_coverage[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_coverage[i].year;
						}
						else if(curData===tmp )
						{
							tdAHtml = tdAHtml + "<td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_coverage[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_coverage[i].year;
						}
					}
					for(i=0;i<$scope.AVERAGE.fleet_coverage.length;i++)
					{
						tdAvghtml=tdAvghtml + "<td class='centerTxt'>" + parseFloat($scope.AVERAGE.fleet_coverage[i].average) +"%</td>";
					
					}
					var avgHtml = "<tr>"+ "<td class='centerTxt'>"+"Average"+"</td>"+tdAvghtml +"</tr>";
					tdHtml =avgHtml + tdAHtml +tdHtml + "</tr>";
					if(dataHist.length>0)
					{
						itemHist["name"] = name;
						itemHist["data"] = itemHist;
						valueDataHist.push(itemHist);
						if(headerLst.length===0)
						{
							headerLst = tmpLst.slice();
						}
					}
					$(".sitefleetCovHistTblHist").html('');
					var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(value){
						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtmlHist = thHtmlHist + "</tr>";
					$(".sitefleetCovHistTblHist").html(thHtmlHist);
					$(".sitefleetCovHistTblData").html(tdHtml);
					
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					
					var  regionData={}, techSummary ={}, techData={};                                                                      
					var regions = [], technologies = [], totalCount={};
					/* All Regions and Technologies */
					_.forEach($scope.HISTORY.fleet_coverage, function(responseObj){
						if(technologies.indexOf(responseObj.site_name) === -1 && responseObj.site_name!==null){
							technologies.push(responseObj.site_name);
						}
						if(regions.indexOf(responseObj.qtr_year) === -1){
							regions.push(responseObj.qtr_year);
						}  
					});
                    
                    regions.reverse();
                    
					var techTotalCount = {};
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(techSummary, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCount, [region], 0);
							}
						});
					});                           
					_.forEach(technologies, function(technology){
						techData[technology] = [];
						var count = 0;
						_.forEach(regions, function(region){
							if(region!==null){
								(techData[technology])[count] = 0;
								count ++;
							}
						});
					});           
					_.forEach($scope.HISTORY.fleet_coverage, function(responseObj){
						if(responseObj.qtr_year!==null && (responseObj.site_name)!==null){
							techTotalCount[responseObj.qtr_year]=techTotalCount[responseObj.qtr_year]+parseFloat(responseObj.value);
							createNestedObject(techSummary, [responseObj.site_name, responseObj.qtr_year], parseFloat(responseObj.value));
						}
					});
					techTotalCount =_.pairs(techTotalCount);
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					var techRankArray = [];
					_.forEach(techTotalCount, function(region){
						techRankArray.push(region[0]);
					});
					var tempArr=[];
					_.forEach(technologies, function(technology){
						_.forEach(techRankArray, function(region){
							((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]);
						});
						tempArr.push({'data': techData[technology], 'name':technology});
					});
					var valueDataforChart = tempArr;
					SiteFleetCoverageChartService.fleetCoverageChartHistory(valueDataforChart,regions);
					
					$("#sitefleetCovTable").DataTable({                                                       
						"bPaginate": true,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": true,
						"iDisplayLength": 5,
						"bInfo":true,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
					endResult['siteFleetcoverageHistDataTable1']=true;
					endResult['siteFleetcoverageHistDataTable2']=false;
				}
				else
				{
					endResult['siteFleetcoverageHistDataTable1']=false;
					endResult['siteFleetcoverageHistDataTable2']=true;
				}
				return endResult;
			}
		}
	}]);
});
