define([
	'./siteOpexPenChart',
	'./sitePenChart',
	'./siteFleetCovChart',
	'./siteCaloricChart'
	], function() {

});
