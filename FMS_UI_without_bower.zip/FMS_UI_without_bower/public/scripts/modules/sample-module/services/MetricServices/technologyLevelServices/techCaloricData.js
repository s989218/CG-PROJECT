define(['angular', '../../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('TechnoCaloricbyRegionCurDataService', ['TechnoCaloricRegionChartService',function(TechnoCaloricRegionChartService) {
		return{
			updateCaloricbyRegionCurData: function ($scope){
				var valueData = [], data = [], item={}, tmp, name = "", curData, tdCHtml = "", headerCurLst = [], tmpCurLst = [],
				total = [], header = [], endResult={};
					if ($.fn.DataTable.isDataTable('#tech-CaloricIndexByRegion-Cur-Data')) {
						$('#tech-CaloricIndexByRegion-Cur-Data').dataTable().fnDestroy();      
					} 
					for(var i=0;i<$scope.CURRENT.caloric_index.length;i++)
					{
						curData = $scope.CURRENT.caloric_index[i].quarter;
						if(tmp==null && ($scope.CURRENT.caloric_index[i].tech).toUpperCase()!=="ZZTOTAL")
						{
							tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.caloric_index[i].year+" - "+$scope.CURRENT.caloric_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.caloric_index[i].value+"</td>";
							tmp = $scope.CURRENT.caloric_index[i].quarter;
							name = ($scope.CURRENT.caloric_index[i].year+" - "+$scope.CURRENT.caloric_index[i].quarter);
							tmpCurLst.push($scope.CURRENT.caloric_index[i].tech);
							data = [];
							data.push(parseFloat($scope.CURRENT.caloric_index[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							item["name"] = name;
							item["data"] = data;
							valueData.push(item);
							if(headerCurLst.length===0)
							{
								headerCurLst = tmpCurLst.slice();
							}
							if(($scope.CURRENT.caloric_index[i].tech).toUpperCase()!=="ZZTOTAL")
							{
								tdCHtml = tdCHtml + "</tr><tr><td class='centerTxt'>"+($scope.CURRENT.caloric_index[i].year+" - "+$scope.CURRENT.caloric_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.caloric_index[i].value+"</td>";
								tmp = $scope.CURRENT.caloric_index[i].quarter;
								name = ($scope.CURRENT.caloric_index[i].year+" - "+$scope.CURRENT.caloric_index[i].quarter);
								data = [];
								data.push(parseFloat($scope.CURRENT.caloric_index[i].value));
							}
						}
						else if(curData===tmp && ($scope.CURRENT.caloric_index[i].tech).toUpperCase()!=="ZZTOTAL")
						{
							tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.caloric_index[i].value+"</td>";
							tmp = $scope.CURRENT.caloric_index[i].quarter;
							name = ($scope.CURRENT.caloric_index[i].year+" - "+$scope.CURRENT.caloric_index[i].quarter);
							data.push(parseFloat($scope.CURRENT.caloric_index[i].value));
							tmpCurLst.push($scope.CURRENT.caloric_index[i].tech);
						}
						if(($scope.CURRENT.caloric_index[i].tech).toUpperCase()==="ZZTOTAL")
						{	
							header.push($scope.CURRENT.caloric_index[i].quarter);
							total.push(parseFloat($scope.CURRENT.caloric_index[i].value).toFixed(2));
						}
					}
					tdCHtml = tdCHtml + "</tr>";
					if(data.length>0)
					{
						item["name"] = name;
						item["data"] = data;
						valueData.push(item);
						if(headerCurLst.length===0)
						{
							headerCurLst = tmpCurLst.slice();
						}
					}
					var thHtml = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerCurLst,function(value){
						thHtml = thHtml + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtml = thHtml + "</tr>";
					$(".techCaloricRegCurHeader").html(thHtml);
					$(".techCaloricRegCurData").html(tdCHtml);
					TechnoCaloricRegionChartService.CaloricRegionChart(valueData,headerCurLst,header,total);
					$("#tech-CaloricIndexByRegion-Cur-Data").dataTable( {                                                       
						"bPaginate": false,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": false,
						"iDisplayLength": 10,
						"bInfo":false,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
				if(total>0){
					endResult['techCaloricIndexRegCurDataTable1']=true;
					endResult['techCaloricIndexRegCurDataTable2']=false;
				}
				else
				{
					endResult['techCaloricIndexRegCurDataTable1']=false;
					endResult['techCaloricIndexRegCurDataTable2']=true;
				}
				return endResult;
			},
			updateCaloricbyRegionHistData: function($scope){
				var tmp,name = "",curData,tdAHtml = "",tdHtml = "",valueDataHist = [], dataHist = [],itemHist = {}, headerLst = [], tmpLst = [],endResult={},tdAvghtml = "";
				if ($.fn.DataTable.isDataTable('#tech-CaloricIndexByRegion-His-Data')) {
					$('#tech-CaloricIndexByRegion-His-Data').dataTable().fnDestroy();      
				} 
				for(var i=0;i<$scope.HISTORY.caloric_index.length;i++)
					{
						curData = $scope.HISTORY.caloric_index[i].year+" - "+$scope.HISTORY.caloric_index[i].quarter;
						if(tmp==null)
						{
							tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.caloric_index[i].year+" - "+$scope.HISTORY.caloric_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.caloric_index[i].value+"</td>";
							tmp = $scope.HISTORY.caloric_index[i].year+" - "+$scope.HISTORY.caloric_index[i].quarter;
							name = ($scope.HISTORY.caloric_index[i].year+" - "+$scope.HISTORY.caloric_index[i].quarter);
							if(($scope.HISTORY.caloric_index[i].tech).toUpperCase()==='ZZTOTAL'){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.caloric_index[i].tech);
							}
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.caloric_index[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							itemHist["name"] = name;
							itemHist["data"] = dataHist;
							valueDataHist.push(itemHist);
							if(headerLst.length===0)
							{
								headerLst = tmpLst.slice();
							}
							tdHtml = tdHtml + "</tr><tr><td class='centerTxt'>"+($scope.HISTORY.caloric_index[i].year+" - "+$scope.HISTORY.caloric_index[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.caloric_index[i].value+"</td>";
							tmp = $scope.HISTORY.caloric_index[i].year+" - "+$scope.HISTORY.caloric_index[i].quarter;
							name = ($scope.HISTORY.caloric_index[i].year+" - "+$scope.HISTORY.caloric_index[i].quarter);
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.caloric_index[i].value));
						}
						else if(curData===tmp)
						{
							tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.caloric_index[i].value+"</td>";
							tmp = $scope.HISTORY.caloric_index[i].year+" - "+$scope.HISTORY.caloric_index[i].quarter;
							name = ($scope.HISTORY.caloric_index[i].year+" - "+$scope.HISTORY.caloric_index[i].quarter);
							if(($scope.HISTORY.caloric_index[i].tech).toUpperCase()==='ZZTOTAL'){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.caloric_index[i].tech);
							}
							dataHist.push(parseFloat($scope.HISTORY.caloric_index[i].value));
						}
					}
					for(i=0;i<$scope.AVERAGE_BASED_ON_YEAR.caloric_index.length;i++)
					{
						curData = $scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].year;
						if(tmp==null)
						{
							tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].average+"</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].year;
						}
						else if(curData!==null && curData!==tmp)
						{ 
							tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].average+"</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].year;
						}
						else if(curData===tmp )
						{
							tdAHtml = tdAHtml + "<td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].average+"</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.caloric_index[i].year;
						}
					}
					for(i=0;i<$scope.AVERAGE.caloric_index.length;i++)
					{
						tdAvghtml=tdAvghtml + "<td class='centerTxt'>" + parseFloat($scope.AVERAGE.caloric_index[i].average) +"</td>";
						if(($scope.AVERAGE.caloric_index[i].tech).toUpperCase()==='ZZTOTAL')
						{
							$scope.totalvalue=parseFloat($scope.AVERAGE.caloric_index[i].average);
						}
					}
					var avgHtml = "<tr>"+ "<td class='centerTxt'>"+"Average"+"</td>"+tdAvghtml +"</tr>";
					tdHtml = avgHtml + tdAHtml + tdHtml + "</tr>";
					if(dataHist.length>0)
					{
						itemHist["name"] = name;
						itemHist["data"] = itemHist;
						valueDataHist.push(itemHist);
						if(headerLst.length===0)
						{
							headerLst = tmpLst.slice();
						}
					}
					$(".techCaloricRegHisHeader").html('');
					var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(value){
						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtmlHist = thHtmlHist + "</tr>";
					$(".techCaloricRegHisHeader").html(thHtmlHist);

					$(".techCaloricRegHisData").html(tdHtml);

					
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					
					var  regionData={}, techSummary ={}, techData={};                                                                      
					var regions = [], technologies = [], totalCount={};
					/* All Regions and Technologies */
					_.forEach($scope.HISTORY.caloric_index, function(responseObj){
						if(technologies.indexOf(responseObj.tech) === -1 && responseObj.tech!==null && (responseObj.tech).toUpperCase()!=='ZZTOTAL'){
							technologies.push(responseObj.tech);
						}
						if(regions.indexOf(responseObj.year+"-"+responseObj.quarter) === -1){
							regions.push(responseObj.year+"-"+responseObj.quarter);
						}  
					});
                
                    regions.reverse();
                
					var techTotalCount = {};
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(techSummary, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCount, [region], 0);
							}
						});
					});                           
					_.forEach(technologies, function(technology){
						techData[technology] = [];
						var count = 0;
						_.forEach(regions, function(region){
							if(region!==null){
								(techData[technology])[count] = 0;
								count ++;
							}
						});
					});           
					_.forEach($scope.HISTORY.caloric_index, function(responseObj){
						if(responseObj.year+"-"+responseObj.quarter!==null && (responseObj.tech).toUpperCase()!=='ZZTOTAL'){
							techTotalCount[responseObj.year+"-"+responseObj.quarter]=techTotalCount[responseObj.year+"-"+responseObj.quarter]+parseFloat(responseObj.value);
							createNestedObject(techSummary, [responseObj.tech, responseObj.year+"-"+responseObj.quarter], parseFloat(responseObj.value));
						}
					});
					techTotalCount =_.pairs(techTotalCount);
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					var techRankArray = [];
					_.forEach(techTotalCount, function(region){
						techRankArray.push(region[0]);
					});
					var tempArr=[];
					_.forEach(technologies, function(technology){
						_.forEach(techRankArray, function(region){
							((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]);
						});
						tempArr.push({'data': techData[technology], 'name':technology});
					});
					var valueDataforChart = tempArr;
					TechnoCaloricRegionChartService.CaloricRegionChartHistory(valueDataforChart,regions);
					
					$("#tech-CaloricIndexByRegion-His-Data").dataTable( {                                                       
						"bPaginate": true,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": true,
						"iDisplayLength": 5,
						"bInfo":true,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
					if($scope.totalvalue>0){
					endResult['techCaloricIndexRegHistDataTable1']=true;
					endResult['techCaloricIndexRegHistDataTable2']=false;
				}
				else
				{
					endResult['techCaloricIndexRegHistDataTable1']=false;
					endResult['techCaloricIndexRegHistDataTable2']=true;
				}
				return endResult;
			},

			excelDownload: function(id){
			    	var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 });
				 var tableToExcel = (function() {
					 var ctx,subHeader;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
	                      if (!table.nodeType) 
	                             table = document.getElementById(id);
	                      var excelContent = '';
	                      var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                      if(id ==='tech-CaloricIndexByRegion-Cur-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Caloric Index By Region Current Data</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='tech-CaloricIndexByRegion-His-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Caloric Index By Region History Data</span>"+
	                          "</td></tr>";
                    	  }
	                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                      excelContent = excelContent + subHeader;
	                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
	                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                      var tdNumber = "<td style='mso-number-format:0'>";
	                      excelContent =excelContent + '<tr>';
	                      _.forEach(columns, function(column){
	                                    excelContent = excelContent + th + column + '</th>';
	                      });
	                      excelContent = excelContent + '</tr>';
	                      _.forEach(getDataFromDT, function(row){
	                             excelContent =excelContent + '<tr>';
	                             _.forEach(row, function(rowData){
	                            	 if((/^[0-9]{0,}$/).test(rowData))
	                                           excelContent = excelContent + tdNumber + rowData + '</td>';
	                                    else
	                                           excelContent = excelContent + '<td>' + rowData + '</td>';
	                             });
	                             excelContent =excelContent + '</tr>';
	                      });
	                     excelContent =excelContent + '<tr>';
	                      excelContent =excelContent + '</tr>';
	                      if(id ==='tech-CaloricIndexByRegion-Cur-Data')
                    	  {
	                    	  ctx = {worksheet:'CalIndexByReg Cur Data' , table: excelContent};
		                      document.getElementById('techCaloricIndexByRegionCurData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('techCaloricIndexByRegionCurData').download = 'CaloricIndexByRegion-TechnologyLevel-Cur-Data.xls';
                    	  }
                      if(id==='tech-CaloricIndexByRegion-His-Data'){
	                    	  ctx = {worksheet: 'CalIndexByReg Hist Data' , table: excelContent};
		                      document.getElementById('techCaloricIndexByRegionHisData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('techCaloricIndexByRegionHisData').download = 'CaloricIndexByRegion-TechnologyLevel-His-Data.xls';
                      }
	                }
	                })();
	                tableToExcel(id);
				return null;
			}
		}
	}]);
});
