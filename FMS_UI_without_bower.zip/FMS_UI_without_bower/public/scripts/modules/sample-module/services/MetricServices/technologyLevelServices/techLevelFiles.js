define([
        './technologyLevelChartServices/techChartFiles',
	'./techOpexPenData',
	'./techPenData',
	'./techFleetCovData',
	'./techCaloricData',
	'./techPartsPen'
	], function() {

});
