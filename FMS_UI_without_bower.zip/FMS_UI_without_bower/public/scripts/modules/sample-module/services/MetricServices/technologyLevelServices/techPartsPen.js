define(['angular', '../../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('TechnoPartsPenDataService', ['TechnoPartsPenChartService',function(TechnoPartsPenChartService) {
		return{
			updatePartsPenetrationCurData : function($scope,id,tableHeader,tableData,tableName,chartId){
				/* Parts Penetration F2F CURRENT Data fun */
				var valueData = [], data = [], item , tmp, name = "", curData, tdCHtml = "", headerCurLst = [], tmpCurLst = [],
				total=[], header=[], endResults={};
					if ($.fn.DataTable.isDataTable('#'+id)) {
						$('#'+id).dataTable().fnDestroy();      
					}  		
					for(var i=0;i<$scope.length;i++)
					{
						curData = $scope[i].quarter;
						if(tmp==null && ($scope[i].tech).toUpperCase()!=="ZZTOTAL")
						{
							if(!isNaN($scope[i].value))
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope[i].year+" - "+$scope[i].quarter)+"</td><td class='centerTxt'>"+$scope[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope[i].year+" - "+$scope[i].quarter)+"</td><td class='centerTxt'>"+$scope[i].value+"</td>";
							}
							tmp = $scope[i].quarter;
							name = ($scope[i].year+" - "+$scope[i].quarter);
							tmpCurLst.push($scope[i].tech);
							data = [];
							data.push(parseFloat($scope[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							item["name"] = name; 
							item["data"] = data;
							valueData.push(item);
							if(headerCurLst.length===0)
							{
								headerCurLst = tmpCurLst.slice();
							}
							if(($scope[i].tech).toUpperCase()!=="ZZTOTAL")
							{
								if(!isNaN($scope[i].value))
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope[i].year+" - "+$scope[i].quarter)+"</td><td class='centerTxt'>"+$scope[i].value+"%</td>";
								}
								else
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope[i].year+" - "+$scope[i].quarter)+"</td><td class='centerTxt'>"+$scope[i].value+"</td>";
								}
								tmp = $scope[i].quarter;
								name = ($scope[i].year+" - "+$scope[i].quarter);
								data = [];
								data.push(parseFloat($scope[i].value));
							}
						}
						else if(curData===tmp && ($scope[i].tech).toUpperCase()!=="ZZTOTAL")
						{
							if(!isNaN($scope[i].value))
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope[i].value+"</td>";
							}
							tmp = $scope[i].quarter;
							name = ($scope[i].year+" - "+$scope[i].quarter);
							data.push(parseFloat($scope[i].value));
							tmpCurLst.push($scope[i].tech);
						}
						if(($scope[i].tech).toUpperCase()==="ZZTOTAL")
						{	
							header.push($scope[i].quarter);
							total.push(parseFloat($scope[i].value));
						}
					}
					tdCHtml = tdCHtml + "</tr>";
					if(data.length>0)
					{
						item={};
						item["name"] = name;
						item["data"] = data;
						valueData.push(item);
						if(headerCurLst.length===0)
						{
							headerCurLst = tmpCurLst.slice();
						}
					}
					var thHtml = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerCurLst,function(value){
						thHtml = thHtml + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtml = thHtml + "</tr>";
					$("."+tableHeader).html(thHtml);
					$("."+tableData).html(tdCHtml);
					TechnoPartsPenChartService.partsPenetrationChart(valueData,headerCurLst,header,total,chartId);				
					$("#"+id).dataTable( {                                                       
						"bPaginate": false,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": false,
						"iDisplayLength": 10,
						"bInfo":false,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
				if(total>0){
					endResults[tableName+'1']=true;
					endResults[tableName+'2']=false;
				}
				else
				{
					endResults[tableName+'2']=true;
					endResults[tableName+'1']=false;
				}
				return endResults;
			},
			updatePartsPenetrationHistData: function ($scope,yearAverage,overallAvg,id,tableHeader,tableData,tableName,chartId){
				var tmp,name = "",curData,tdAHtml = "",tdHtml = "",valueDataHist = [], dataHist = [],itemHist = {}, headerLst = [], tmpLst = [],endResults={},tdAvghtml = "";
				if ($.fn.DataTable.isDataTable('#'+id)) {
					$('#'+id).dataTable().fnDestroy();      
				}  			
				for(var i=0;i<$scope.length;i++)
					{
						curData = $scope[i].year+" - "+$scope[i].quarter;
						if(tmp==null)
						{
							if(!isNaN($scope[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope[i].year+" - "+$scope[i].quarter)+"</td><td class='centerTxt'>"+$scope[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope[i].year+" - "+$scope[i].quarter)+"</td><td class='centerTxt'>"+$scope[i].value+"</td>";
							}
							tmp = $scope[i].year+" - "+$scope[i].quarter;
							name = ($scope[i].year+" - "+$scope[i].quarter);
							if(($scope[i].tech).toUpperCase()==='ZZTOTAL'){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope[i].tech);
							}
							dataHist = [];
							dataHist.push(parseFloat($scope[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							itemHist["name"] = name;
							itemHist["data"] = dataHist;
							valueDataHist.push(itemHist);
							if(headerLst.length===0)
							{
								headerLst = tmpLst.slice();
							}
							if(!isNaN($scope[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope[i].year+" - "+$scope[i].quarter)+"</td><td class='centerTxt'>"+$scope[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope[i].year+" - "+$scope[i].quarter)+"</td><td class='centerTxt'>"+$scope[i].value+"</td>";
							}
							tmp = $scope[i].year+" - "+$scope[i].quarter;
							name = ($scope[i].year+" - "+$scope[i].quarter);
							dataHist = [];
							dataHist.push(parseFloat($scope[i].value));
						}
						else if(curData===tmp)
						{
							if(!isNaN($scope[i].value))
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope[i].value+"</td>";
							}
							tmp = $scope[i].year+" - "+$scope[i].quarter;
							name = ($scope[i].year+" - "+$scope[i].quarter);
							if(($scope[i].tech).toUpperCase()==='ZZTOTAL'){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope[i].tech);
							}
							dataHist.push(parseFloat($scope[i].value));

						}
					}
					for(i=0;i<yearAverage.length;i++)
					{
						curData = yearAverage[i].year;
						if(tmp==null)
						{
							tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+yearAverage[i].year)+"</td><td class='centerTxt'>"+yearAverage[i].average+"%</td>";
							tmp = yearAverage[i].year;
						}
						else if(curData!==null && curData!==tmp)
						{ 
							tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+yearAverage[i].year)+"</td><td class='centerTxt'>"+yearAverage[i].average+"%</td>";
							tmp = yearAverage[i].year;
						}
						else if(curData===tmp )
						{
							tdAHtml = tdAHtml + "<td class='centerTxt'>"+yearAverage[i].average+"%</td>";
							tmp = yearAverage[i].year;
						}
					}
					for(i=0;i<overallAvg.length;i++)
					{
						tdAvghtml=tdAvghtml + "<td class='centerTxt'>" + parseFloat(overallAvg[i].average) +"%</td>";
						if((overallAvg[i].tech).toUpperCase()==='ZZTOTAL')
						{
							$scope.totalvalue=parseFloat(overallAvg[i].average);
						}
					}
					var avgHtml = "<tr>"+ "<td class='centerTxt'>"+"Average"+"</td>"+tdAvghtml +"</tr>";
					tdHtml = avgHtml + tdAHtml + tdHtml + "</tr>";
					if(dataHist.length>0)
					{
						itemHist["name"] = name;
						itemHist["data"] = itemHist;
						valueDataHist.push(itemHist);
						if(headerLst.length===0)
						{
							headerLst = tmpLst.slice();
						}
					}
					$("."+tableHeader).html('');
					var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(value){
						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtmlHist = thHtmlHist + "</tr>";
					$("."+tableHeader).html(thHtmlHist);	
					$("."+tableData).html(tdHtml);
					
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					
					var regionData={}, techSummary ={}, techData={};                                                                      
					var regions = [], technologies = [], totalCount={};
					// All Regions and Technologies 
					_.forEach($scope, function(responseObj){
						if(technologies.indexOf(responseObj.tech) === -1 && responseObj.tech!==null && (responseObj.tech).toUpperCase()!=='ZZTOTAL'){
							technologies.push(responseObj.tech);
						}
						if(regions.indexOf(responseObj.year+"-"+responseObj.quarter) === -1){
							regions.push(responseObj.year+"-"+responseObj.quarter);
						}  
					});
                
                    regions.reverse();
                
					var techTotalCount = {};
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(techSummary, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCount, [region], 0);
							}
						});
					});                           
					_.forEach(technologies, function(technology){
						techData[technology] = [];
						var count = 0;
						_.forEach(regions, function(region){
							if(region!==null){
								(techData[technology])[count] = 0;
								count ++;
							}
						});
					});           
					_.forEach($scope, function(responseObj){
						if(responseObj.year+"-"+responseObj.quarter!==null && (responseObj.tech).toUpperCase()!=='ZZTOTAL'){
							techTotalCount[responseObj.year+"-"+responseObj.quarter]=techTotalCount[responseObj.year+"-"+responseObj.quarter]+parseFloat(responseObj.value);
							createNestedObject(techSummary, [responseObj.tech,responseObj.year+"-"+responseObj.quarter], parseFloat(responseObj.value));
						}
					});
					techTotalCount =_.pairs(techTotalCount);
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					var techRankArray = [];
					_.forEach(techTotalCount, function(region){
						techRankArray.push(region[0]);
					});
					var tempArr=[];
					_.forEach(technologies, function(technology){
						_.forEach(techRankArray, function(region){
							((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]);
						});
						tempArr.push({'data': techData[technology], 'name':technology});
					});
					var valueDataforChart = tempArr;
					TechnoPartsPenChartService.partsPenetrationHistoryChart(valueDataforChart,regions,chartId);
					
					$("#"+id).dataTable( {                                                       
						"bPaginate": true,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": true,
						"iDisplayLength": 5,
						"bInfo":true,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
					if($scope.totalvalue>0){
					endResults[tableName+'1']=true;
					endResults[tableName+'2']=false;
				}
				else
				{
					endResults[tableName+'2']=true;
					endResults[tableName+'1']=false;
				}
				return endResults;
			},
			excelDownload: function(id){
			    	var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 });
				 var tableToExcel = (function() {
					 var subHeader,ctx ;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
	                      if (!table.nodeType) 
	                             table = document.getElementById(id);
	                      var excelContent = '';
	                      var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                      if(id ==='tech-PartsPen-Cur-Data')
                    	  {
		                       subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Parts Penetration Current Data</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='tech-PartsPen-His-Data')
                    	  {
		                       subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Parts Penetration History Data</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='tech-RepairsPen-Cur-Data')
                    	  {
		                       subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Repairs Penetration Current Data</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='tech-RepairsPen-His-Data')
                    	  {
		                       subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Repairs Penetration History Data</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='tech-ServicePen-Cur-Data')
                    	  {
		                       subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Service Penetration Current Data</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='tech-ServicePen-His-Data')
                    	  {
		                       subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Service Penetration History Data</span>"+
	                          "</td></tr>";
                    	  }
	                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                      excelContent = excelContent + subHeader;
	                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
	                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                      var tdNumber = "<td style='mso-number-format:0'>";
	                      excelContent =excelContent + '<tr>';
	                      var flag = 0;
	                      _.forEach(columns, function(column){
                              if(columns[0]!== 'null' && flag === 0){
                                     excelContent = excelContent + th + column + '</th>';
                                     flag++;
                              }else {
                                     excelContent = excelContent + th + column +'(%)' + '</th>';
                              }
	                      });
	                      excelContent = excelContent + '</tr>';
	                      _.forEach(getDataFromDT, function(row){
	                             excelContent =excelContent + '<tr>';
	                             _.forEach(row, function(rowData){
	                            	 rowData = rowData.replace(/K/g, "");
	                                  if (rowData.includes('%')) {
	                                	  rowData = rowData.substring(0,rowData.length-1);
	                                  }
	                            	 if((/^[0-9]{0,}$/).test(rowData))
	                                           excelContent = excelContent + tdNumber + rowData + '</td>';
	                                    else
	                                           excelContent = excelContent + '<td>' + rowData + '</td>';
	                             });
	                             excelContent =excelContent + '</tr>';
	                      });
	                     excelContent =excelContent + '<tr>';
	                      excelContent =excelContent + '</tr>';
	                      if(id ==='tech-PartsPen-Cur-Data')
                    	  {
	                    	  ctx = {worksheet:'Parts Pen Cur Data' , table: excelContent};
		                      document.getElementById('techPartsPenCurData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('techPartsPenCurData').download = 'Parts-Penetration-TechnologyLevel-Cur-Data.xls';
                    	  }
	                      if(id==='tech-PartsPen-His-Data'){
		                    	  ctx = {worksheet: 'Parts Pen Hist Data' , table: excelContent};
			                      document.getElementById('techPartsPenHisData').href = (uri + base64(format(template, ctx)));
			                      document.getElementById('techPartsPenHisData').download = 'Parts-Penetration-TechnologyLevel-His-Data.xls';
	                      }
	                      if(id ==='tech-RepairsPen-Cur-Data')
                    	  {
	                    	  ctx = {worksheet:'Repairs Pen Cur Data' , table: excelContent};
		                      document.getElementById('techRepairsPenCurData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('techRepairsPenCurData').download = 'Repairs-Penetration-TechnologyLevel-Cur-Data.xls';
                    	  }
	                      if(id==='tech-RepairsPen-His-Data'){
		                    	  ctx = {worksheet: 'Repairs Pen Hist Data' , table: excelContent};
			                      document.getElementById('techRepairsPenHisData').href = (uri + base64(format(template, ctx)));
			                      document.getElementById('techRepairsPenHisData').download = 'Repairs-Penetration-TechnologyLevel-His-Data.xls';
	                      }
	                      if(id ==='tech-ServicePen-Cur-Data')
                    	  {
	                    	  ctx = {worksheet:'Service Pen Cur Data' , table: excelContent};
		                      document.getElementById('techServicePenCurData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('techServicePenCurData').download = 'Service-Penetration-TechnologyLevel-Cur-Data.xls';
                    	  }
	                      if(id==='tech-ServicePen-His-Data'){
		                    	  ctx = {worksheet: 'Service Pen Hist Data' , table: excelContent};
			                      document.getElementById('techServicePenHisData').href = (uri + base64(format(template, ctx)));
			                      document.getElementById('techServicePenHisData').download = 'Service-Penetration-TechnologyLevel-His-Data.xls';
	                      }
	                   }
	                })();
	                tableToExcel(id);
				return null;
			}
		}
	}]);
});
