define(['angular', '../../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('TechnoFleetpenetrationDataService', ['TechnoFleetPenetrationChartService',function(TechnoFleetPenetrationChartService) {
		return{
			updateFleetpenetrationData:function($scope){
				var valueData = [], data = [], item={}, tmp, name = "", curData, tdCHtml = "", headerCurLst = [], tmpCurLst = [],
				total = [], header = [], endResult={};
					if ($.fn.DataTable.isDataTable('#tech-Fleet-Penetration-Cur-Data')) {
						$('#tech-Fleet-Penetration-Cur-Data').dataTable().fnDestroy();      
					}  	
					for(var i=0;i<$scope.CURRENT.fleet_penetration.length;i++)
					{	
						curData = $scope.CURRENT.fleet_penetration[i].quarter;
						if(tmp==null && ($scope.CURRENT.fleet_penetration[i].tech).toUpperCase()!=="ZZTOTAL")
						{
							if(!isNaN($scope.CURRENT.fleet_penetration[i].value))
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_penetration[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_penetration[i].value+"</td>";
							}
							tmp = $scope.CURRENT.fleet_penetration[i].quarter;
							name = ($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter);
							tmpCurLst.push($scope.CURRENT.fleet_penetration[i].tech);
							data = [];
							data.push(parseFloat($scope.CURRENT.fleet_penetration[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							item["name"] = name;
							item["data"] = data;
							valueData.push(item);
							if(headerCurLst.length===0)
							{
								headerCurLst = tmpCurLst.slice();
							}
							if(($scope.CURRENT.fleet_penetration[i].tech).toUpperCase()!=="ZZTOTAL")
							{
								if(!isNaN($scope.CURRENT.fleet_penetration[i].value))
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_penetration[i].value+"%</td>";
								}
								else
								{
									tdCHtml = tdCHtml + "<tr><td class='centerTxt'>"+($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter)+"</td><td class='centerTxt'>"+$scope.CURRENT.fleet_penetration[i].value+"</td>";
								}
								tmp = $scope.CURRENT.fleet_penetration[i].quarter;
								name = ($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter);
								data = [];
								data.push(parseFloat($scope.CURRENT.fleet_penetration[i].value));
							}
						}
						else if(curData===tmp && ($scope.CURRENT.fleet_penetration[i].tech).toUpperCase()!=="ZZTOTAL" )
						{
							if(!isNaN($scope.CURRENT.fleet_penetration[i].value))
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.fleet_penetration[i].value+"%</td>";
							}
							else
							{
								tdCHtml = tdCHtml + "<td class='centerTxt'>"+$scope.CURRENT.fleet_penetration[i].value+"</td>";
							}
							tmp = $scope.CURRENT.fleet_penetration[i].quarter;
							name = ($scope.CURRENT.fleet_penetration[i].year+" - "+$scope.CURRENT.fleet_penetration[i].quarter);
							data.push(parseFloat($scope.CURRENT.fleet_penetration[i].value));
							tmpCurLst.push($scope.CURRENT.fleet_penetration[i].tech);
						}
						if(($scope.CURRENT.fleet_penetration[i].tech).toUpperCase()==="ZZTOTAL")
						{	
							header.push($scope.CURRENT.fleet_penetration[i].quarter);
							total.push(parseFloat($scope.CURRENT.fleet_penetration[i].value));
						}
					}
					tdCHtml = tdCHtml + "</tr>";
					if(data.length>0)
					{
						item["name"] = name;
						item["data"] = data;
						valueData.push(item);
						if(headerCurLst.length===0)
						{
							headerCurLst = tmpCurLst.slice();
						}
					}
					var thHtml = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerCurLst,function(value){
						thHtml = thHtml + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtml = thHtml + "</tr>";
					$(".techFleetPenCurHeader").html(thHtml);
					$(".techFleetPenCurData").html(tdCHtml);
					TechnoFleetPenetrationChartService.fleetPenetrationChart(valueData,headerCurLst,header,total);
					$("#tech-Fleet-Penetration-Cur-Data").dataTable( {                                                       
						"bPaginate": false,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": false,
						"iDisplayLength": 10,
						"bInfo":false,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
				if(total>0){
					endResult['techFleetpenetrationCurDataTable1']=true;
					endResult['techFleetpenetrationCurDataTable2']=false;
				}
				else
				{
					endResult['techFleetpenetrationCurDataTable1']=false;
					endResult['techFleetpenetrationCurDataTable2']=true;
				}	
				return	endResult;			
			},
			updateFleetpenetrationHistData:function($scope){
				var tmp,name = "",curData,tdAHtml = "",tdHtml = "",valueDataHist = [], dataHist = [],itemHist = {}, headerLst = [], tmpLst = [],endResult={},tdAvghtml = "";
				if ($.fn.DataTable.isDataTable('#tech-Fleet-Penetration-His-Data')) {
					$('#tech-Fleet-Penetration-His-Data').dataTable().fnDestroy();      
				}  		
				for(var i=0;i<$scope.HISTORY.fleet_penetration.length;i++)
					{
						curData = $scope.HISTORY.fleet_penetration[i].year+" - "+$scope.HISTORY.fleet_penetration[i].quarter;
						if(tmp==null)
						{
							if(!isNaN($scope.HISTORY.fleet_penetration[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_penetration[i].year+" - "+$scope.HISTORY.fleet_penetration[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_penetration[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_penetration[i].year+" - "+$scope.HISTORY.fleet_penetration[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_penetration[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_penetration[i].year+" - "+$scope.HISTORY.fleet_penetration[i].quarter;
							name = ($scope.HISTORY.fleet_penetration[i].year+" - "+$scope.HISTORY.fleet_penetration[i].quarter);
							if(($scope.HISTORY.fleet_penetration[i].tech).toUpperCase()==='ZZTOTAL'){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.fleet_penetration[i].tech);
							}
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.fleet_penetration[i].value));
						}
						else if(curData!==null && curData!==tmp)
						{
							itemHist["name"] = name;
							itemHist["data"] = dataHist;
							valueDataHist.push(itemHist);
							if(headerLst.length===0)
							{
								headerLst = tmpLst.slice();
							}
							if(!isNaN($scope.HISTORY.fleet_penetration[i].value))
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_penetration[i].year+" - "+$scope.HISTORY.fleet_penetration[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_penetration[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<tr><td class='centerTxt'>"+($scope.HISTORY.fleet_penetration[i].year+" - "+$scope.HISTORY.fleet_penetration[i].quarter)+"</td><td class='centerTxt'>"+$scope.HISTORY.fleet_penetration[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_penetration[i].year+" - "+$scope.HISTORY.fleet_penetration[i].quarter;
							name = ($scope.HISTORY.fleet_penetration[i].year+" - "+$scope.HISTORY.fleet_penetration[i].quarter);
							dataHist = [];
							dataHist.push(parseFloat($scope.HISTORY.fleet_penetration[i].value));
						}
						else if(curData===tmp)
						{
							if(!isNaN($scope.HISTORY.fleet_penetration[i].value))
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.fleet_penetration[i].value+"%</td>";
							}
							else
							{
								tdHtml = tdHtml + "<td class='centerTxt'>"+$scope.HISTORY.fleet_penetration[i].value+"</td>";
							}
							tmp = $scope.HISTORY.fleet_penetration[i].year+" - "+$scope.HISTORY.fleet_penetration[i].quarter;
							name = ($scope.HISTORY.fleet_penetration[i].year+" - "+$scope.HISTORY.fleet_penetration[i].quarter);
							if(($scope.HISTORY.fleet_penetration[i].tech).toUpperCase()==='ZZTOTAL'){
								tmpLst.push("TOTAL");
							}
							else{
								tmpLst.push($scope.HISTORY.fleet_penetration[i].tech);
							}
							dataHist.push(parseFloat($scope.HISTORY.fleet_penetration[i].value));
						}
					}
					for(i=0;i<$scope.AVERAGE_BASED_ON_YEAR.fleet_penetration.length;i++)
					{
						curData = $scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].year;
						if(tmp==null)
						{
							tdAHtml = tdAHtml + "<tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].year;
						}
						else if(curData!==null && curData!==tmp)
						{ 
							tdAHtml = tdAHtml + "</tr><tr><td class='centerTxt'>"+("Average"+" - "+$scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].year)+"</td><td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].year;
						}
						else if(curData===tmp )
						{
							tdAHtml = tdAHtml + "<td class='centerTxt'>"+$scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].average+"%</td>";
							tmp = $scope.AVERAGE_BASED_ON_YEAR.fleet_penetration[i].year;
						}
					}
					for(i=0;i<$scope.AVERAGE.fleet_penetration.length;i++)
					{
						tdAvghtml=tdAvghtml + "<td class='centerTxt'>" + parseFloat($scope.AVERAGE.fleet_penetration[i].average) +"%</td>";
						if(($scope.AVERAGE.fleet_penetration[i].tech).toUpperCase()==='ZZTOTAL')
						{
							$scope.totalvalue=parseFloat($scope.AVERAGE.fleet_penetration[i].average);
						}
					}
					var avgHtml = "<tr>"+ "<td class='centerTxt'>"+"Average"+"</td>"+tdAvghtml +"</tr>";
					tdHtml = avgHtml + tdAHtml + tdHtml + "</tr>";
					if(dataHist.length>0)
					{
						itemHist["name"] = name;
						itemHist["data"] = itemHist;
						valueDataHist.push(itemHist);
						if(headerLst.length===0)
						{
							headerLst = tmpLst.slice();
						}
					}
					$(".techFleetPenHisHeader").html('');
					var thHtmlHist = "<tr><th class='tHeadMaintenance'></th>";
					angular.forEach(headerLst,function(value){
						thHtmlHist = thHtmlHist + "<th class='tHeadMaintenance'>"+value+"</th>";
					});
					thHtmlHist = thHtmlHist + "</tr>";
					$(".techFleetPenHisHeader").html(thHtmlHist);
					$(".techfleetPenHisData").html(tdHtml);
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					
					var regionData={}, techSummary ={}, techData={};                                                                      
					var regions = [],  technologies = [], totalCount={};
					/* All Regions and Technologies */
					_.forEach($scope.HISTORY.fleet_penetration, function(responseObj){
						if(technologies.indexOf(responseObj.tech) === -1 && responseObj.tech!==null && (responseObj.tech).toUpperCase()!=='ZZTOTAL'){
							technologies.push(responseObj.tech);
						}
						if(regions.indexOf(responseObj.year+"-"+responseObj.quarter) === -1){
							regions.push(responseObj.year+"-"+responseObj.quarter);
						}  
					});
                
                    regions.reverse();
                
					var techTotalCount = {};
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(techSummary, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCount, [region], 0);
							}
						});
					});                           
					_.forEach(technologies, function(technology){
						techData[technology] = [];
						var count = 0;
						_.forEach(regions, function(region){
							if(region!==null){
								(techData[technology])[count] = 0;
								count ++;
							}
						});
					});           
					_.forEach($scope.HISTORY.fleet_penetration, function(responseObj){
						if(responseObj.year+"-"+responseObj.quarter!==null && (responseObj.tech).toUpperCase()!=='ZZTOTAL'){
							techTotalCount[responseObj.year+"-"+responseObj.quarter]=techTotalCount[responseObj.year+"-"+responseObj.quarter]+parseFloat(responseObj.value);
							createNestedObject(techSummary, [responseObj.tech, responseObj.year+"-"+responseObj.quarter], parseFloat(responseObj.value));
						}
					});
					techTotalCount =_.pairs(techTotalCount);
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					var techRankArray = [];
					_.forEach(techTotalCount, function(region){
						techRankArray.push(region[0]);
					});
					var tempArr=[];
					_.forEach(technologies, function(technology){
						_.forEach(techRankArray, function(region){
							((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]);
						});
						tempArr.push({'data': techData[technology], 'name':technology});
					});
					var valueDataforChart = tempArr;
					TechnoFleetPenetrationChartService.fleetPenetrationChartHistory(valueDataforChart,regions);
					
					$("#tech-Fleet-Penetration-His-Data").dataTable( {                                                       
						"bPaginate": true,
						"bAutoWidth": false,
						"bSort": true,
						"bFilter": true,
						"iDisplayLength": 5,
						"bInfo":true,
						"aaSorting":[],
						"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
					});
					if($scope.totalvalue>0){
					endResult['techFleetpenetrationHistDataTable1']=true;
					endResult['techFleetpenetrationHistDataTable2']=false;
				}
				else
				{
					endResult['techFleetpenetrationHistDataTable1']=false;
					endResult['techFleetpenetrationHistDataTable2']=true;
				}
				return	endResult;			
			},

			excelDownload: function(id){
			    	var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 });
				 var tableToExcel = (function() {
					 var ctx,subHeader;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
	                      if (!table.nodeType) 
	                             table = document.getElementById(id);
	                      var excelContent = '';
	                      var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                      if(id ==='tech-Fleet-Penetration-Cur-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Penetration Current Data</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='tech-Fleet-Penetration-His-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Penetration History Data</span>"+
	                          "</td></tr>";
                    	  }
	                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                      excelContent = excelContent + subHeader;
	                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
	                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                      var tdNumber = "<td style='mso-number-format:0'>";
	                      excelContent =excelContent + '<tr>';
	                      var flag = 0;
	                      _.forEach(columns, function(column){
                              if(columns[0]!== 'null' && flag === 0){
                                     excelContent = excelContent + th + column + '</th>';
                                     flag++;
                              }else {
                                     excelContent = excelContent + th + column +'(%)' + '</th>';
                              }
	                      });
	                      excelContent = excelContent + '</tr>';
	                      _.forEach(getDataFromDT, function(row){
	                             excelContent =excelContent + '<tr>';
	                             _.forEach(row, function(rowData){
	                            	 rowData = rowData.replace(/K/g, "");
	                                  if (rowData.includes('%')) {
	                                	  rowData = rowData.substring(0,rowData.length-1);
	                                  }
	                                  if((/^[0-9]{0,}$/).test(rowData))
	                                           excelContent = excelContent + tdNumber + rowData + '</td>';
	                                   else
	                                           excelContent = excelContent + '<td>' + rowData + '</td>';
	                             });
	                             excelContent =excelContent + '</tr>';
	                      });
	                     excelContent =excelContent + '<tr>';
	                      excelContent =excelContent + '</tr>';
	                      if(id ==='tech-Fleet-Penetration-Cur-Data')
                    	  {
	                    	  ctx = {worksheet:'Fleet Pen Cur data' , table: excelContent};
		                      document.getElementById('techfleetPenCurrData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('techfleetPenCurrData').download = 'Fleet-Penetration-TechnologyLevel-Cur-Data.xls';
                    	  }
                      if(id==='tech-Fleet-Penetration-His-Data'){
	                    	  ctx = {worksheet: 'Fleet Pen Cur Data' , table: excelContent};
		                      document.getElementById('techfleetPenHisttData').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('techfleetPenHisttData').download = 'Fleet-Penetration-TechnologyLevel-His-Data.xls';
                      }
	                }
	                })();
	                tableToExcel(id);
				return null;
			}
		}
	}]);
});
