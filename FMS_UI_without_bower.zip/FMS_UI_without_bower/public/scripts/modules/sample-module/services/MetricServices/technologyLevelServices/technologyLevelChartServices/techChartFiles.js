define([
	'./techOpexPenChart',
	'./techPenChart',
	'./techFleetCovChart',
	'./techCaloricChart',
	'./techPartsPenChart'
	], function() {

});
