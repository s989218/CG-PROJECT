define(['angular', '../../../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('TechnoPartsPenChartService', [function() {
    	var chart,chart2,chart7,chart8,chart9,chart7Hist,chart8Hist,chart9Hist;
		return{
			partsPenetrationChart: function (valueData, headerCurLst,header,total,id){
				chart= new Highcharts.Chart({
					    chart: {
					      renderTo: id,
						    type: 'column'
					    },	
								title: {
					            text: ''
					        },
					        subtitle: {
					            text: ''
					        },
					        xAxis: {
					            categories: headerCurLst,
					            crosshair: true
					        },
					        yAxis: {
					            title: {
					                text: '%'
					            }
					        },
							legend: {
								layout: 'horizontal',
								align: 'right',
								verticalAlign: 'bottom',
								floating: false
					        },
					        tooltip: {
					            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
					            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
					                '<td style="padding:0"><b>{point.y} %</b></td></tr>',
					            footerFormat: '</table>',
					            shared: true,
					            useHTML: true
					        },
					        plotOptions: {
					            column: {
					                pointPadding: 0.2,
					                borderWidth: 0,
					                dataLabels: {
					                    enabled: true,
					                    formatter: function () {
					                    	return (this.y+"%");
					                    }
					                }
					            }
					        },
							credits: {
								enabled: false
							},
					        series: valueData,
					        exporting: {
				                chartOptions: {
				                    chart: {
				                        events: {
				                            load: function () {
				                                Highcharts.each(this.series, function (series) {
				                                    series.update({
				                                        dataLabels: {
				                                            enabled: true,				                                                 
				                                            style: {
				                                                fontSize: '6px'
				                                            }  
				                                        } 
				                                    }, false);
				                                    
				                                    series.xAxis.update({
				                                        labels: {
				                                            style: {
				                                                fontSize: '6px'
				                                            }
				                                        }
				                                    });
				                                    series.yAxis.update({
				                                        labels: {
				                                            style: {
				                                                fontSize: '6px'
				                                            }
				                                        }
				                                    });
				                                });
				                                this.redraw(false);
				                            }
				                        }
				                    },   
				                    legend:{
				                        enabled:true,
				                        itemStyle: {
				                        	fontSize: '6px'
				                        }
				                    }
				                }
				            }
					 }, function(chart) {
							for(var t=0;t<header.length&&t<total.length;t++)
							{
							chart.renderer.text('<span><span1 style="color: rgb(124, 181, 236); font-weight:bold">'+header[t]+': </span1> <span2  style="color: black; font-weight:bold">'+total[t]+'%</span2></span>', 70, 375)
					            .css({
					                fontSize: '12px',
					            })
					            .add();
							}
					    });
					if(id === 'techContainer7'){
						 chart7 = chart
					}else if(id === 'techContainer8'){
						 chart8 = chart
					}else if(id === 'techContainer9'){
						 chart9 = chart
					}
				},
				exportChart : function(type,name,divId){
				if(type === 'JPEG'){
					if(divId === 'techContainer7'){
						chart7.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}
					else if(divId === 'techContainer8'){
						 chart8.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}
					else if(divId === 'techContainer9'){
						 chart9.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}
				}
			},
			partsPenetrationHistoryChart: function (valueData, headerCurLst,id){
				chart2= new Highcharts.Chart({
					    chart: {
					      renderTo: id
					    },	
								title: {
					            text: ''
					        },
					        subtitle: {
					            text: ''
					        },
					        xAxis: {
					            categories: headerCurLst,
					            crosshair: true
					        },
					        yAxis: {
					            title: {
					                text: '%'
					            }
					        },
							legend: {
								layout: 'horizontal',
								align: 'right',
								verticalAlign: 'bottom',
								floating: false
					        },
					        tooltip: {
					            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
					            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
					                '<td style="padding:0"><b>{point.y} %</b></td></tr>',
					            footerFormat: '</table>',
					            shared: true,
					            useHTML: true
					        },
					        plotOptions: {
					            column: {
					            	 stacking: 'normal',
					                pointPadding: 0.2,
					                borderWidth: 0
					            }
					        },
							credits: {
								enabled: false
							},
					        series: valueData,
					        exporting: {
				                chartOptions: {
				                    chart: {
				                        events: {
				                            load: function () {
				                                Highcharts.each(this.series, function (series) {
				                                    series.update({
				                                        dataLabels: {
				                                            enabled: true,				                                                 
				                                            style: {
				                                                fontSize: '6px'
				                                            }  
				                                        } 
				                                    }, false);
				                                    
				                                    series.xAxis.update({
				                                        labels: {
				                                            style: {
				                                                fontSize: '6px'
				                                            }
				                                        }
				                                    });
				                                    series.yAxis.update({
				                                        labels: {
				                                            style: {
				                                                fontSize: '6px'
				                                            }
				                                        }
				                                    });
				                                });
				                                this.redraw(false);
				                            }
				                        }
				                    },   
				                    legend:{
				                        enabled:true,
				                        itemStyle: {
				                        	fontSize: '6px'
				                        }
				                    }
				                }
				            }
					 });
					if(id === 'techContainer7History'){
						 chart7Hist = chart2
					}else if(id === 'techContainer8History'){
						 chart8Hist = chart2
					}else if(id === 'techContainer9History'){
						 chart9Hist = chart2
					}
				},
				exportChartHist : function(type,name,divId){
				if(type === 'JPEG'){
					if(divId === 'techContainer7History'){
						chart7Hist.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}else if(divId === 'techContainer8History'){
						chart8Hist.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}else if(divId === 'techContainer9History'){
						chart9Hist.exportChart({type: 'image/jpeg', filename: name}, {subtitle: {text:''}});
					}
				}
			}
		}
    }]);
});
    