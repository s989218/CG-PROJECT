define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('NetworkCallService', ['URLService','$q','$http','$rootScope',function(URLService,$q,$http,$rootScope) {
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
		  return {
            /* Fetch Countries For a orders Region */
			getCountries: function(jsonData){
                var request = {
					"dataType"    : "json",
					"method"      : "POST",
                    "contentType" : "application/json",
					"data"        : jsonData,
					'url': URLService.newMetrics.getCountries,
					};
				return networkCall(request);
			},
           	/* Fetch Countries For a IBIBO Region */
            getIBIBOCountries: function(jsonData){
				var request = {
					"dataType"    : "json",
					"method"      : "POST",
                    "contentType" : "application/json",
					"data"        : jsonData,
					'url': URLService.newMetrics.getIBIBOCountries,
					};
				return networkCall(request);
			},
			/*newly created*/
			getIBMetricsData:function(jsonData){
                 var request = {
                    "dataType"    : "json",
					"method"      : "POST",
                    "contentType" : "application/json",
					"data"        : jsonData,
					"url"         : URLService.newMetrics.getIBMetricsData+'/'+$rootScope.businessSegment,
                };
				return networkCall(request);
			},
			/* Get Filtered IB Data */
			getIBData:function(jsonData){
				var request = {
					'method': 'POST',
					'data': {'data' : jsonData},
					'url':	URLService.newMetrics.IBData,					
					};
				return networkCall(request);
			},
			/* Get Filtered IB Data at Country Level */
			getIBCountryData:function(jsonData){
				var request = {
					'method': 'POST',
					'data': {'data' : jsonData},
					'url':	URLService.newMetrics.IBCountry,						
					};
				return networkCall(request);
			},
			/* Get IBO Data Filtered at Country Level */
			getIBOCountryData:function(jsonData){
				var request = {
					'method': 'POST',
					'data': {'data' : jsonData},
					'url':	URLService.newMetrics.IBOCountry					
					};
				return networkCall(request);
			},
			/* Get All Data for IBO on New Metrics Chart */
			getIBOMetricsDashboard:function(jsonData){
                var request = {
                    "dataType"    : "json",
					"method"      : "POST",
                    "contentType" : "application/json",
					"data"        : jsonData,
					"url"         : URLService.newMetrics.DashboardData,
                };
				return networkCall(request);
			},
			/* Get Filtered IBO Data */
			getIBOMetricsFilterData:function(jsonData){
				var request = {
					'method': 'POST',
					'data': {'data' : jsonData},
					'url': URLService.newMetrics.IBOData,						
					};
				return networkCall(request);
			},
			/* Get Country Level IBO Data, Filtered */
			getIBOCountry: function(jsonData){
				var request = {
					'method': 'POST',
					"data": {'data' : jsonData},
					'url': URLService.newMetrics.IBOCountry,						
					};
				return networkCall(request);
			},
			/* Get Dropdown Data for IBO */
			getIBODropdown:function(jsonData){
				var request = {
					"dataType"    : "json",
                    "method"      : "POST",
                    "contentType" : "application/json",
                    "data"        : jsonData,
					'url': URLService.newMetrics.IBODropdown+'/'+$rootScope.businessSegment						
					};
				return networkCall(request);
			},
			/* Get Dropdown Data for IB */
			getIBDropdown: function(){
				var request = {
					'method': 'GET',
					'url': URLService.newMetrics.IBDropdown+'/'+$rootScope.businessSegment,						
					};
				return networkCall(request);
			},
			/* Get Map Data */
            getLatLongByRegion: function(jsonData){
                var request = {
                    "dataType"    : "json",
                    "method"      : "POST",
                    "contentType" : "application/json",
                    "data"        : jsonData,
                    'url'         : URLService.newMetrics.getLatLongByRegion
                };
                return networkCall(request);
            },
			/* Get Map Filter Dropdown Data */
			getInstldBaseDropdownsData: function(jsonData){
                var request = {
                    "dataType"    : "json",
                    "method"      : "POST",
                    "contentType" : "application/json",
                    "data"        : jsonData,
                    'url'         : URLService.newMetrics.getInstldBaseDropdownsData,		
                };
                return networkCall(request);
			},
			getOrderMetricsDashboardData: function(jsonData){			
				var request = {
					"dataType"    : "json",
                    "method"      : "POST",
                    "contentType" : "application/json",
                    "data"        : jsonData,
					'url': URLService.newMetrics.OrderMetricsDashboard+'/'+$rootScope.businessSegment,
                };
				return networkCall(request);
			},
			getOrdersMetricsDropdownsData: function(jsonData){
				var request = {
					"dataType"    : "json",
                    "method"      : "POST",
                    "contentType" : "application/json",
                    "data"        : jsonData,
					'url': URLService.newMetrics.OrdersMetricsDropdownsData+'/'+$rootScope.businessSegment,
					};
				return networkCall(request);
			},
			getOrdersData: function(jsonData){
				var request = {
					'method': 'POST',
					"data": {'data' : jsonData},
					'url': URLService.newMetrics.OrdersData,					
					};
				return networkCall(request);
			},
			getOrdersCountry: function(jsonData){
				var request = {
					'method': 'POST',
					"data": {'data' : jsonData},
					'url': URLService.newMetrics.OrdersCountry,					
					};
				return networkCall(request);
			},
			/*DM Metrics Services*/
			getDMMetricsData: function(jsonData){
				var request = {
					'method': 'POST',
					"data": {'data' : jsonData},
					'url': URLService.newMetrics.getDMMetricsData,					
					};
				return networkCall(request);
			},
			/* Dm Metrics filter Data*/
			getDMDropdown: function(jsonData){
				var request = {
					"dataType"    : "json",
                    "method"      : "POST",
                    "contentType" : "application/json",
                    "data"        : jsonData,
					'url': URLService.newMetrics.DMDropdown+'/'+$rootScope.businessSegment,						
					};
				return networkCall(request);
			},
			
			/*DM Metrics filtered data*/
			getDMMetricsFilterData:function(jsonData){
				var request = {
					'method': 'POST',
					'data': {'data' : jsonData},
					'url': URLService.newMetrics.DMData,						
					};
				return networkCall(request);
			},
			
			getDMMetricsCountryFilterData:function(jsonData){
				var request = {
					'method': 'POST',
					'data': {'data' : jsonData},
					'url': URLService.newMetrics.DMCountry,						
					};
				return networkCall(request);
			},
			/*Fetch Countries For a DM Region*/
			getDMCountry: function(jsonData){
				var request = {
					"dataType"    : "json",
                    "method"      : "POST",
                    "contentType" : "application/json",
                    "data"        : jsonData,
					'url': URLService.newMetrics.getDMCountry,						
					};
				return networkCall(request);
			},
			/*outage metrics services*/
			getOutageMetricsData: function(jsonData){
				var request = {
					'method': 'POST',
					"data": {'data' : jsonData},
					'url': URLService.newMetrics.getOutageMetricsData,					
					};
				return networkCall(request);
			},
			/* outage Metrics filter Data*/
			getOutageDropdown: function(jsonData){
				var request = {
					"dataType"    : "json",
                    "method"      : "POST",
                    "contentType" : "application/json",
                    "data"        : jsonData,
					'url': URLService.newMetrics.OutageDropdown,						
					};
				return networkCall(request);
			},
			getOutageMetricsFilterData:function(jsonData){
				var request = {
					'method': 'POST',
					'data': {'data' : jsonData},
					'url': URLService.newMetrics.OutageData,						
					};
				return networkCall(request);
			},
			getOutageMetricsCountryFilterData:function(jsonData){
				var request = {
					'method': 'POST',
					'data': {'data' : jsonData},
					'url': URLService.newMetrics.OutageCountry,						
					};
				return networkCall(request);
			},
			/*Service Request metrics services*/
			getServiceRequestMetricsData: function(jsonData){
				var request = {
					'method': 'POST',
					"data": {'data' : jsonData},
					'url': URLService.newMetrics.getServiceRequestMetricsData,					
					};
				return networkCall(request);
			},
			getServiceReqDropdown: function(jsonData){
				var request = {
					'method': 'POST',
					//"data": {'data' : jsonData},
					'url': URLService.newMetrics.getServiceReqDropdown,						
					};
				return networkCall(request);
			},
			getServiceReqMetricsFilterData:function(jsonData){
				var request = {
					'method': 'POST',
					'data': {'data' : jsonData},
					'url': URLService.newMetrics.ServiceReqData,						
					};
				return networkCall(request);
			},			
			getCombinedAnalysisDropdownData: function(jsonData){
				var request = {
					'method': 'POST',
					"data": jsonData,
					'url': URLService.newMetrics.getCombinedAnalysisDropdownData,
					};
				return networkCall(request);
			},
			getCombinedAnalysisMetricsData: function(jsonData){
				var request = {
						'method': 'POST',
						'data': {'data' : jsonData},
						'url': URLService.newMetrics.getCombinedAnalysisMetricsData,
						};
                return networkCall(request);
			}
        };
    }]);
});
