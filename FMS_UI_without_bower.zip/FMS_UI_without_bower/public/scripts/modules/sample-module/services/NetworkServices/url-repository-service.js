define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('URLService', ['$rootScope', function($rootScope) {
        return {
        	newMetrics:{
				IBCountry: 'connect/fms/getMetricsData/IBCountry',
				IBData: 'connect/fms/getMetricsData/IBData',
				getIBMetricsData: 'connect/fms/getIBMetricsData',
				DashboardData: 'connect/fms/getIBOMetricsData',
				IBOData: 'connect/fms/getMetricsData/IBOData',
				IBOCountry: 'connect/fms/getMetricsData/IBOCountry',
				getIBIBOCountries: 'connect/fms/getCountryData',
				getCountries: 'connect/fms/getCountryData',
				IBODropdown: 'connect/fms/getIBOMetricsDropdownsData',
				IBDropdown: 'connect/fms/getIBMetricsDropdownsData',
				getLatLongByRegion: 'connect/fms/getLatLongByRegion/'+ $rootScope.businessSegment,
				getInstldBaseDropdownsData: 'connect/fms/getInstldBaseDropdownsData/' + $rootScope.businessSegment,
				OrderMetricsDashboard:'connect/fms/getOrdersMetricsData',
				OrdersMetricsDropdownsData: 'connect/fms/getOrdersMetricsDropdownsData',
				OrdersData:'connect/fms/getOrdersMetricsFilterData/OrdersData',
				OrdersCountry:'connect/fms/getOrdersMetricsFilterData/OrdersCountry',
				getQuarterYear:'connect/fms/getQuarterYear',
				getDMMetricsData:'connect/fms/getDMMetricsData',
				DMDropdown:'connect/fms/getDMMetricsDropdown',
				DMData: 'connect/fms/getDMNewMetricsFilterData/DMData',
				DMCountry: 'connect/fms/getDMNewMetricsFilterData/DMCountry',
			    getChooseColumns : 'connect/fms/getChooseColumns',
			    getDMCountry: 'connect/fms/getDMCountry',
			    getOutageMetricsData:'connect/fms/getOutageMetricsData',
			    OutageDropdown:'connect/fms/getOutageDropdown',
			    OutageData: 'connect/fms/getOutageMetricsFilterData/OutageData',
			    OutageCountry: 'connect/fms/getOutageMetricsFilterData/OutageCountry',
			    getServiceRequestMetricsData:'connect/fms/getServiceRequestMetricsData',
			   	getServiceReqDropdown:'connect/fms/getServiceRequestDropdown',
			    ServiceReqData: 'connect/fms/getServiceReqMetricsFilterData',
			    getCombinedAnalysisDropdownData:'connect/fms/getCombinedAnalysisDropdownData',
			    getCombinedAnalysisMetricsData:'connect/fms/getCombinedAnalysisMetrics'
			}
        };
    }]);
});
