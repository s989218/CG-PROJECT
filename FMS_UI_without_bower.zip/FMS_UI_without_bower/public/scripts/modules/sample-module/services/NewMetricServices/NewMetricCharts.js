define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('NewMetricChartService', ['NetworkCallService','IBOMetricsService','IBOCustomerService','CreateHighChartService','IBOTableService','IBOTechnoRegionService',
	function(NetworkCallService, IBOMetricsService,IBOCustomerService,CreateHighChartService,IBOTableService,IBOTechnoRegionService) {
		return {
			IBOTopCustomer: function($scope){
				function postNetworkCall(response){
				setTimeout(function(){
					var serviceData = (IBOCustomerService.processCustomerData(response.iBCustNameDataBean));
					var customers = serviceData['customers'], chartData = serviceData['chartData'];
					CreateHighChartService.createChart(customers,chartData,'container2','ibo/topCustomer');
					var dataObj = (IBOTableService.topCustomerTableData(response.iBCustNameDataBean));
					$scope.safeApply(function(){
						IBOTableService.initTable(dataObj['dataArr'],dataObj['columns'],'IB-by-Top-Cust-Data',dataObj['regionCount']);
						$scope.custDataExp = true;
						$scope.custChartExp = true;
						});
					$('#tableDiv').show()
					},500);
				}
				NetworkCallService.getIBOMetricsFilterData(IBOMetricsService.searchDataService()).then(function(response){
					postNetworkCall(response);
					});
				return $scope;
			},
			IBOTechnoRegion: function($scope){
				function postNetworkCall(response){
				setTimeout(function(){
					var techRegionChartData = IBOTechnoRegionService.updateTechReg(response.iBTechnologyDataBean);
					var dtData = IBOTechnoRegionService.processTable(response.iBTechnologyDataBean);
					CreateHighChartService.createColumnChart(techRegionChartData['technology'],techRegionChartData['regionWithCount'],'container2','ibo/technoRegion');
					$scope.safeApply(function(){
						IBOTableService.initTable(dtData['dataArr'],dtData['columns'],'IB-by-Top-Cust-Data',dtData['regionCount']);
						$scope.dep_custDataExp = true;
						$scope.dep_custChartExp = true;
						});
					$('#tableDiv').show()
					},500);
				}
				NetworkCallService.getIBOMetricsFilterData(IBOTechnoRegionService.searchDataService()).then(function(response){
					postNetworkCall(response);
					});
				return $scope;
			}
        };
    }]);
});
