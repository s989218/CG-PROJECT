define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('NewMetricOrderCharts', ['NetworkCallService','OrderMetricsService','OrderCustomerService','CreateHighChartService','OrderTableService','OrderTechnoRegionService',
	function(NetworkCallService, OrderMetricsService,OrderCustomerService,CreateHighChartService,OrderTableService,OrderTechnoRegionService) {
		return {
			OrderTopCustomer: function($scope){
				function postNetworkCall(response){
					var serviceData = (OrderCustomerService.processCustomerData(response.custNameDataBean));
					var customers = serviceData['customers'], chartData = serviceData['chartData'];
					setTimeout(function(){
					CreateHighChartService.createChart(customers,chartData,'container2','ibo/topCustomer');
					var dataObj = (OrderTableService.topCustomerTableData(response.custNameDataBean));
					$scope.safeApply(function(){
						OrderTableService.initTable(dataObj['dataArr'],dataObj['columns'],'IB-by-Top-Cust-Data',dataObj['regionCount']);
						$scope.custDataExp = true;
						$scope.custChartExp = true;
						});
					$('#tableDiv').show()
					},500);
				}
				NetworkCallService.getOrdersData(OrderMetricsService.searchDataService()).then(function(response){
					postNetworkCall(response);
					});
				return $scope;
			},
			OrderTechnoRegion: function($scope){
				function postNetworkCall(response){
					setTimeout(function(){
					var techRegionChartData = OrderTechnoRegionService.updateTechReg(response.technologyDataBean);
					var dtData = OrderTechnoRegionService.processTable(response.technologyDataBean);
					CreateHighChartService.createColumnChart(techRegionChartData['technology'],techRegionChartData['regionWithCount'],'container2','ibo/technoRegion');
					$scope.safeApply(function(){
						OrderTableService.initTable(dtData['dataArr'],dtData['columns'],'IB-by-Top-Cust-Data',dtData['regionCount']);
						$scope.dep_custDataExp = true;
						$scope.dep_custChartExp = true;
						});
					$('#tableDiv').show();
					},500);
				}
				NetworkCallService.getOrdersData(OrderTechnoRegionService.searchDataService()).then(function(response){
					postNetworkCall(response);
					});
				return $scope;
			}
        };
    }]);
});
