define([
	'./NewMetricCharts',
	'./NewMetricOrderCharts'
	], function() {

});
