define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('OrderChartService', [function() {
        return {
			updateTechReg: function(techRegionData){
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};

					var totalcount = 0,regionWithCountData=[], regionData={} , techSummary ={}, techData={}; ;					
					var regions = [], _colorIndexes = [], technologies = [], summaryData = {}, totalCount={};
					/* All Regions and Technologies */
					_.forEach(techRegionData, function(responseObj){
						if(regions.indexOf(responseObj.orderTechRegion) === -1 && responseObj.orderTechRegion!==null){
							regions.push(responseObj.orderTechRegion);
							
						}
						if(technologies.indexOf(responseObj.orderTechProduct) === -1){
							technologies.push(responseObj.orderTechProduct);
							_colorIndexes.push(responseObj.orderColorCode);							
						}					
					});
					var techTotalCount = {};
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(summaryData, [region, technology], 0);
								createNestedObject(summaryData, [technology, region], 0);
								createNestedObject(techSummary, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCount, [region], 0);
							}
						});
					});	
						_.forEach(technologies, function(technology){
						techData[technology] = [];
						var count = 0;
						_.forEach(regions, function(region){
							if(region!==null){
								(techData[technology])[count] = 0;
								count ++;
							}
						});
					}); 
					_.forEach(techRegionData, function(responseObj){
						if(responseObj.region!==null){
							createNestedObject(summaryData, [responseObj.orderTechRegion, responseObj.orderTechProduct],responseObj.orderTechOrdersSum);
							totalCount[responseObj.orderTechProduct]=totalCount[responseObj.orderTechProduct]+parseFloat(responseObj.orderTechOrdersSum);
							techTotalCount[responseObj.orderTechRegion]=techTotalCount[responseObj.orderTechRegion]+parseFloat(responseObj.orderTechOrdersSum);
							createNestedObject(techSummary, [responseObj.orderTechProduct, responseObj.orderTechRegion], responseObj.orderTechOrdersSum);
							totalcount = totalcount + parseFloat(responseObj.orderTechOrdersSum);
						}
					});
					totalCount = _.sortBy(_.pairs(totalCount), function (item) { return item[1]; });
					techTotalCount = _.sortBy(_.pairs(techTotalCount), function (item) { return item[1]; });
					/* Descending Sort */
					totalCount = totalCount.reverse();
					techTotalCount = techTotalCount.reverse();
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					var techRankArray = [];
				_.forEach(techTotalCount, function(region){
					techRankArray.push(region[0]);
				});
					_.forEach(regions, function(region){
						_.forEach(rankArray, function(technology){
							((regionData[region])[rankArray.indexOf(technology)])=parseFloat((summaryData[region])[technology]);
						});
						regionWithCountData.push({'data': regionData[region], 'name':region});
					});
					var tempArr=[];
				_.forEach(technologies, function(technology){
					_.forEach(techRankArray, function(region){
						((techData[technology])[techRankArray.indexOf(region)])=parseFloat((techSummary[technology])[region]/1000);
					});
					tempArr.push({'data': techData[technology], 'name':technology});
				});
				
				var returnObj = {};
				returnObj['regionWithCount'] = tempArr;
				returnObj['technology'] = techRankArray;
				returnObj['region'] = techRankArray;
				returnObj['totalcount'] = totalcount/1000;
				returnObj['colorCodes'] = _colorIndexes;
				return returnObj;
			}
        };
    }]);
});
