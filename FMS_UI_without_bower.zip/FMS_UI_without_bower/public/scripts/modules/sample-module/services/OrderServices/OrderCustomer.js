define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('OrderCustomerService', ['$q','$http','$state','URLService',function($q, $http,$state,URLService) {
		var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
		var dataProcessing = function(regionWithCustomerCount){
					var customerCounts = {}, colorCodes ={};
					
					_.forEach(regionWithCustomerCount, function(tech){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(tech.orderCustTechnology!==null){
							createNestedObject(customerCounts, [tech.orderCustTechnology,customerCount.orderCustEndUserName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(tech){
						if(tech.orderCustTechnology!==null){
							createNestedObject(customerCounts, [tech.orderCustTechnology,tech.orderCustEndUserName], (customerCounts[tech.orderCustTechnology])[tech.orderCustEndUserName]+parseFloat(tech.orderCustTechOrderSum));
								totalCustomerCount = totalCustomerCount + parseFloat(tech.orderCustTechOrderSum);
								colorCodes[tech.orderCustTechnology] = tech.orderCustColorCode;
							}
						});
						var chartData = [], chartObj = {}, customers = [];
						_.forEach(Object.keys(customerCounts), function(data){
								chartObj ={};
								var keys = Object.keys(customerCounts[data]);
								var customerCountsObj = customerCounts[data];
								chartObj['data'] = [];
								chartObj['name'] = data;
								chartObj['color']=colorCodes[data];
								_.forEach(keys, function(key){
										chartObj['data'].push(parseFloat((customerCountsObj[key])/1000));
								});
								customers = keys;
								chartData.push(chartObj);
						});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			};
			var processCountryTable = function(customerData){
				var dataObj = {};
				var customers=[], regions=[], tableData = {}, columns = [];
				columns = [{'title':'Customer'}];
				_.forEach(customerData, function(obj){
					if(customers.indexOf(obj.orderCustEndUserName)=== -1){
						customers.push(obj.orderCustEndUserName);
					}
					if(regions.indexOf(obj.orderCustRegion)=== -1 && obj.orderCustRegion!==null){
						var colObj = {'title':obj.orderCustRegion};
						columns.push(colObj);
						regions.push(obj.orderCustRegion);
					}
				});
				var dataArr = [[]], totalCount = {}, regionCount={};
				_.forEach(customers, function(customer){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [customer, region], 0);
						createNestedObject(totalCount, [customer], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[customers.indexOf(customer)] = [];
						(dataArr[customers.indexOf(customer)])[0] = customer;
						for(var index=1; index<=regions.length; index++)
							(dataArr[customers.indexOf(customer)])[index] = 0;
					}
					});
				});
				var total = 0;
				_.forEach(customerData, function(obj){
				if(obj.orderCustRegion!==null){
					createNestedObject(tableData, [obj.orderCustEndUserName, obj.orderCustRegion], obj.orderCustOrdersSum);
					(dataArr[customers.indexOf(obj.orderCustEndUserName)])[regions.indexOf(obj.orderCustRegion)+1] = parseFloat(obj.orderCustOrdersSum).toFixed(2);
					createNestedObject(regionCount, [obj.orderCustRegion], regionCount[obj.orderCustRegion]+parseFloat(obj.orderCustOrdersSum).toFixed(2));
					total = total + parseFloat(obj.orderCustOrdersSum).toFixed(2);
					totalCount[obj.orderCustEndUserName]=totalCount[obj.orderCustEndUserName]+parseFloat(obj.orderCustOrdersSum).toFixed(2);
				}
				});
				columns.push({'title':'Grand Total'});
				regionCount['Grand Total']=total;
				_.forEach(customers, function(customer){					
					(dataArr[customers.indexOf(customer)])[(dataArr[customers.indexOf(customer)]).length] = totalCount[customer];
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
        return {
			/* Network Call */
			getIBMetricsData: function(){
				var request = {
					'method': 'POST',
					'url': URLService.newMetrics.IBData,						
					};
				return networkCall(request);
			},
        	getCustomerData: function(customerNameData){
				/* Top 10 Customers */
					var regionWithCustomerCount =customerNameData;
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var colorCodes ={};	
					var customerCounts = {};					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						createNestedObject(customerCounts, [region.orderCustTechnology,customerCount.orderCustEndUserName], 0);
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(tech){
						createNestedObject(customerCounts, [tech.orderCustTechnology,tech.orderCustEndUserName], (customerCounts[tech.orderCustTechnology])[tech.orderCustEndUserName]+parseFloat(tech.orderCustTechOrderSum));
						totalCustomerCount = totalCustomerCount + parseFloat(tech.orderCustTechOrderSum);
						colorCodes[tech.orderCustTechnology] = tech.orderCustColorCode;
					});
					var chartData = [], chartObj = {}, colorIndex = 0, customers = [];
					_.forEach(Object.keys(customerCounts), function(data){
							chartObj ={};
							var keys = Object.keys(customerCounts[data]);
							var customerCountsObj = customerCounts[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							chartObj['color']= colorCodes[data];
							colorIndex++;
							_.forEach(keys, function(key){
									chartObj['data'].push((customerCountsObj[key])/1000);
							});
							customers = keys;
							chartData.push(chartObj);
					});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount/1000;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			},
			processCustomerData: function(customerData){
					return dataProcessing(customerData);
			},
			processAllCustomerData: function(customerData){
					return dataProcessing(customerData);
			},
			customerCountryTableData: function(customerData){
				return processCountryTable(customerData);
			}
        };
    }]);
});
