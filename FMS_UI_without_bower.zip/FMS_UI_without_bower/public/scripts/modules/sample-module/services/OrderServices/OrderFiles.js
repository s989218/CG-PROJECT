define([
	'./OrderChart',
	'./OrderCustomer',
	'./OrderTable',
	'./OrderMetricsService',
	'./OrderTechRegion'
	], function() {

});
