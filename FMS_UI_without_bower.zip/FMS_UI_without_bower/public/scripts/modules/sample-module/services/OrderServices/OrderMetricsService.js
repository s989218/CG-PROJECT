define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('OrderMetricsService', ['$q','$http','$state','URLService','$rootScope',function($q, $http,$state,URLService,$rootScope) {
		var regionDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, colorCodes ={}, totalCounts = {}, regions = [], regionData ={};
					_.forEach(regionWithTechCount, function(region){
						if(region.region!==null){
							regionData[region.region] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.region!==null){
							if(regions.indexOf(region.region)===-1)
								regions.push(region.region);
							createNestedObject(technologyCounts, [region.region,techCount.technology], 0);
							createNestedObject(totalCounts, [techCount.technology], 0);
						}
						});
					});
					var totalCount = 0, count;
					_.forEach(regionWithTechCount, function(region){
						createNestedObject(technologyCounts, [region.region,region.technology], (technologyCounts[region.region])[region.technology]+parseFloat(region.technologyCount).toFixed(2));
						totalCounts[region.technology]=totalCounts[region.technology]+parseFloat(region.technologyCount).toFixed(2);
						totalCount = totalCount + parseFloat(region.technologyCount).toFixed(2);
						colorCodes[region.region] = parseInt(region.regId);
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							});
						});
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=
									parseFloat((technologyCounts[region])[technology]).toFixed(2); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region, '_colorIndex':colorCodes[region]});
						});
					var returnObj = {};
					returnObj['totalCount'] = totalCount;
					returnObj['technologies'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					return returnObj;
			};
			var countryDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, colorCodes ={}, totalCounts = {}, regions = [], regionData ={}, testData = {},totalCount = {};
					_.forEach(regionWithTechCount, function(region){
						if(region.country!==null){
							regionData[region.country] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.country!==null){
							if(regions.indexOf(region.country)===-1)
								regions.push(region.country);
							createNestedObject(technologyCounts, [region.country,techCount.technology], 0);
							createNestedObject(testData, [techCount.technology,region.country], -1);
							createNestedObject(testData, [techCount.technology, '~Total'], 0);
							createNestedObject(totalCounts, [techCount.technology], 0);
							createNestedObject(totalCount, [region.country , 'Total'] , 0);
						}
						});
					});
					totalCount['gTotal'] = 0;
					_.forEach(regionWithTechCount, function(region){
						if(region.country!==null){
							createNestedObject(technologyCounts, [region.country,region.technology], (technologyCounts[region.country])[region.technology]+parseFloat(region.technologyCount).toFixed(2));
							createNestedObject(testData, [region.technology, region.country ] , parseFloat(region.technologyCount).toFixed(2));
							createNestedObject(testData, [region.technology,'~Total'] , (testData[region.technology])['~Total']+parseFloat(region.technologyCount).toFixed(2));
							createNestedObject(totalCount, [region.country , 'Total'] , (totalCount[region.country])['Total']+parseFloat(region.technologyCount).toFixed(2));
							totalCounts[region.technology]=totalCounts[region.technology]+parseFloat(region.technologyCount).toFixed(2);
							colorCodes[region.region] = parseInt(region.regId);
							totalCount['gTotal']+=parseFloat(region.technologyCount).toFixed(2);
						}
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							var count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							}); 
						});
						var highchartData = [];
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=parseFloat((technologyCounts[region])[technology]).toFixed(2); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region});
							highchartData.push({'data': regionData[region], 'name':region});
						});
						_.forEach(testData, function(data){
								testData['regions'] = [];
								/* Sort Alphabetically */
								testData['regions'] = _.sortBy(Object.keys(data), function(o) { return o; });	
							return false;
						});
					var returnObj = {};
					returnObj['technology'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					returnObj['highchartData'] = highchartData;
					returnObj['testData'] = testData;
					returnObj['totalCount'] = totalCount;
					return returnObj;
			};
			var processCountryTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Technology'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.technology)=== -1){
						technologies.push(obj.technology);
					}
					if(regions.indexOf(obj.country)=== -1 && obj.country !==null){
						var colObj = {'title':obj.country};
						columns.push(colObj);
						regions.push(obj.country);
					}
				});
				var dataArr = [[]], totalCount={}, regionCount= {};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
						if(!(region===null)){
							createNestedObject(tableData, [technology, region], 0);
							createNestedObject(totalCount, [technology], 0);
							createNestedObject(regionCount, [region], 0);
							dataArr[technologies.indexOf(technology)] = [];
							(dataArr[technologies.indexOf(technology)])[0] = technology;
							for(var index=1; index<=regions.length; index++)
								(dataArr[technologies.indexOf(technology)])[index] = 0;
						}
					});					
				});		
				regionCount['Grand Total']=0;
				_.forEach(technologyData, function(obj){
					if(!(obj.country===null)){
						createNestedObject(tableData, [obj.technology, obj.country], obj.technologyCount);
						(dataArr[technologies.indexOf(obj.technology)])[regions.indexOf(obj.country)+1] = parseFloat(obj.technologyCount).toFixed(2);
						totalCount[obj.technology]=totalCount[obj.technology]+parseFloat(obj.technologyCount).toFixed(2);
						regionCount[obj.country]=regionCount[obj.country]+parseFloat(obj.technologyCount).toFixed(2);
						regionCount['Grand Total'] = regionCount['Grand Total'] +parseFloat(obj.technologyCount).toFixed(2);
					}
				});
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){					
					(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = totalCount[technology];
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['regionCount'] = regionCount;
				dataObj['columns'] = columns;
				return dataObj;
			};
			var processTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Technology'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.technology)=== -1){
						technologies.push(obj.technology);
					}
					if(regions.indexOf(obj.region)=== -1 && obj.region!==null){
						var colObj = {'title':obj.region};
						columns.push(colObj);
						regions.push(obj.region);
					}
				});
				var dataArr = [[]], totalCount={}, regionCount={};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [technology, region], 0);
						createNestedObject(totalCount, [technology], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[technologies.indexOf(technology)] = [];
						(dataArr[technologies.indexOf(technology)])[0] = technology;
						for(var index=1; index<=regions.length; index++)
							(dataArr[technologies.indexOf(technology)])[index] = 0;
					}
					});					
				});
				regionCount['Grand Total']=0;
				_.forEach(technologyData, function(obj){
				if(obj.region!==null){
					createNestedObject(tableData, [obj.technology, obj.region], obj.technologyCount);
					(dataArr[technologies.indexOf(obj.technology)])[regions.indexOf(obj.region)+1] = parseFloat(obj.technologyCount).toFixed(2);
					totalCount[obj.technology]=totalCount[obj.technology]+parseFloat(obj.technologyCount).toFixed(2);
					regionCount[obj.region]=regionCount[obj.region]+parseFloat(obj.technologyCount).toFixed(2);
					regionCount['Grand Total']=regionCount['Grand Total']+parseFloat(obj.technologyCount).toFixed(2);
				}
				});
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){					
					(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = totalCount[technology];
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
        return {
			searchDataService: function(){
				var jsonData = [];
				var item = {};
				item["region"] = "";
				item["unitStatusDesc"]="InService";
				item["siteCustCountry"]= "";
				item["servRelationDescOng"]="";
				item["technology"]="";
				item["equipCode"]="";
				item["marketSegmentDesc"]="";
				item["customerName"]="";
				item["maintPolicyCode"]="";
				item["businessSegment"]=$rootScope.businessSegment;
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
				jsonData.push(item);
				return jsonData;
			},
			/* Network Call */
			getIBOMetricsFilterData:function(jsonData){
				var request = {
					'method': 'POST',
					'data': {'data' : jsonData},
					'url': URLService.newMetrics.IBOData,						
					};
				return networkCall(request);
			},
			getIBOMetricsDropdownsData:function(jsonData){
				var request = {
					'method': 'GET',
					'url': URLService.newMetrics.IBODropdown						
					};
				return networkCall(request);
			},
			getIBOMetricsDashboard:function(jsonData){
				var request = {
					'method': 'GET',
					'url': URLService.newMetrics.DashboardData						
					};
				return networkCall(request);
			},
			getIBOFilterDataCountry: function(jsonData){
				var request = {
					'method': 'POST',
					"data": {'data' : jsonData},
					'url': URLService.newMetrics.IBOCountry,						
					};
				return networkCall(request);
			},
			getRegionWithCount: function(techRegionData){	
					return regionDataProcess(techRegionData)['chartData']
			},
			processedData: function(techRegionData){	
					return regionDataProcess(techRegionData);
			},
			countryDataProcess: function(techRegionData){	
					return countryDataProcess(techRegionData);
			},
			processTable: function(technologyData){
				return processTable(technologyData);
			},
			processCountryTable: function(technologyData){
				return processCountryTable(technologyData);
			},
			initTable(data,columns,id) { 
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
				if ($.fn.DataTable.isDataTable( '#'+id )) {
						$('#'+id).dataTable().fnDestroy();        
						$('#'+id).empty(); 
						 $('#'+id).append('<tfoot></tfoot>');
                }  
				dt = $('#'+id).DataTable({
				   "order": [[ columns.length-1, "desc" ]],
				   columns : columns,
				   "pageLength": 10,
                   data: data,
				   fnDrawCallback : function() {
					if(footer && data[0].length>0){
					   $('#'+id+ ' > tfoot').html('');
					   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					   _.forEach(columns, function(column){
							if(footer[column.title]){
								$('#'+id+ ' > tfoot').append('<th>'+footer[column.title]+'</th>');
							}
					   });
					}
					}
				});
				return dt;				
			},
        	getCustomerData: function(customerNameData){
				/* Top 10 Customers */
					var regionWithCustomerCount = _.first(_.sortBy(customerNameData, function(custData){
						return parseFloat(custData.custNameCount)}).reverse(),10);
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var customerCounts = {}, colorCodes ={};					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.region!==null){
							createNestedObject(customerCounts, [region.region,customerCount.custName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
					if(region.region!==null){	
						createNestedObject(customerCounts, [region.region,region.custName], (customerCounts[region.region])[region.custName]+parseFloat(region.custNameCount).toFixed(2));
						totalCustomerCount = totalCustomerCount + parseFloat(region.custNameCount).toFixed(2);
						colorCodes[region.region] = region.regId - 1;
					}
					});
					var chartData = [], chartObj = {}, customers = [];
					_.forEach(Object.keys(customerCounts), function(data){
							chartObj ={};
							var keys = Object.keys(customerCounts[data]);
							var customerCountsObj = customerCounts[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							chartObj['_colorIndex']=colorCodes[data];
							_.forEach(keys, function(key){
									chartObj['data'].push(customerCountsObj[key]);
							});
							customers = keys;
							chartData.push(chartObj);
					});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			},
			getCountries: function(jsonData){
				var request = {
					"dataType"    : "json",
					"method"      : "POST",
                    "contentType" : "application/json",
					"data"        : jsonData,
					'url': 'connect/fms/getCountryData',						
					};
				return networkCall(request);
			},
			topCustChart: function(custName,regionWithCustCount,id)
			{
					return new Highcharts.Chart({
					chart: {
						  renderTo: id,
								type: 'bar',
								events: {
									click: function () {
										$state.go('topCustomer');
									}
								}
						  },
					title: {
						text:''
					},
					xAxis: {
						categories: custName
					},
					yAxis: {
						min: 0,
						title: {
							text: ''
						}
					},
					tooltip: {
						pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
						shared: true
					},
					legend: {
						itemStyle: {
							color: 'black',
							fontWeight: 'normal',
							fontSize: '12px',
						}
					},
					 plotOptions: {
							series: {
							stacking: 'normal',
							borderWidth:0
						}
					},
					credits: {
						 enabled: false
					},
					series: regionWithCustCount,
                    responsive: {
                        rules: [{
                            condition: {
                                maxWidth: 500
                            },
                            chartOptions: {
                                legend: {
                                    align: 'center',
                                    verticalAlign: 'bottom',
                                    layout: 'horizontal'
                                },
                                yAxis: {
                                    labels: {
                                        align: 'left',
                                        x: 0,
                                        y: -5
                                    },
                                    title: {
                                        text: null
                                    }
                                },
                                subtitle: {
                                    text: null
                                },
                                credits: {
                                    enabled: false
                                }
                            }
                        }]
                    }
				});
			}
        };
    }]);
});
