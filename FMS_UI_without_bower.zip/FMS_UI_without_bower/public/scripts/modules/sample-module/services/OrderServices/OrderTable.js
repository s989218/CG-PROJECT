define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('OrderTableService', ['$q','$http','$state','URLService',function($q, $http,$state,URLService) {
		var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
		var countryDataProcess = function(regionWithCustomerCount){
					var customerCounts = {}, colorCodes ={};
					_.forEach(regionWithCustomerCount, function(tech){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(tech.orderCustTechnology!=null){
							createNestedObject(customerCounts, [tech.orderCustTechnology,customerCount.orderCustEndUserName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(tech){
						if(tech.orderCustTechnology!=null){
							createNestedObject(customerCounts, [tech.orderCustTechnology,tech.orderCustEndUserName], (customerCounts[tech.orderCustTechnology])[tech.orderCustEndUserName]+Math.round(tech.orderCustTechOrderSum));
								totalCustomerCount = totalCustomerCount + Math.round(tech.orderCustTechOrderSum);
								colorCodes[tech.orderCustTechnology] = tech.orderCustColorCode;
						}
						});
						var chartData = [], chartObj = {}, customers = [];
						_.forEach(Object.keys(customerCounts), function(data){
								chartObj ={};
								var keys = Object.keys(customerCounts[data]);
								var customerCountsObj = customerCounts[data];
								chartObj['data'] = [];
								chartObj['name'] = data;
								chartObj['color']=colorCodes[data];
								_.forEach(keys, function(key){
										chartObj['data'].push(Math.round((customerCountsObj[key])/1000));
								});
								customers = keys;
								chartData.push(chartObj);
						});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			};
		var dataProcessing = function(regionWithCustomerCount){
					var customerCounts = {}, colorCodes ={};
					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.orderCustRegion!==null){
							createNestedObject(customerCounts, [region.orderCustRegion,customerCount.orderCustEndUserName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
						if(region.orderCustRegion!==null){
							createNestedObject(customerCounts, [region.orderCustRegion,region.orderCustEndUserName], (customerCounts[region.orderCustRegion])[region.orderCustEndUserName]+Math.round(region.orderCustOrdersSum));
								totalCustomerCount = totalCustomerCount + Math.round(region.orderCustOrdersSum);
								colorCodes[region.orderCustRegion] = region.orderCustRegionId - 1;
							}
						});
						var chartData = [], chartObj = {}, customers = [];
						_.forEach(Object.keys(customerCounts), function(data){
								chartObj ={};
								var keys = Object.keys(customerCounts[data]);
								var customerCountsObj = customerCounts[data];
								chartObj['data'] = [];
								chartObj['name'] = data;
								chartObj['_colorIndex']=colorCodes[data];
								_.forEach(keys, function(key){
										chartObj['data'].push(customerCountsObj[key]);
								});
								customers = keys;
								chartData.push(chartObj);
						});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			};
			//Order Top Customer Country level
			var processCountryTable = function(customerData){
				var dataObj = {},custCountry = [];
				var customers=[], technology=[], tableData = {}, columns = [],countryNames = [];
				columns = [{'title':'Customer'}];
				columns.push({'title':'Country'});
				_.forEach(customerData, function(obj){
					if(customers.indexOf(obj.orderCustEndUserName)=== -1 || countryNames.indexOf(obj.orderCustCountry)=== -1){
						customers.push(obj.orderCustEndUserName);
						countryNames.push(obj.orderCustCountry);
						custCountry.push(obj.orderCustEndUserName+obj.orderCustCountry);
					}
					if(technology.indexOf(obj.orderCustTechnology)=== -1 && obj.orderCustTechnology!==null){
						var colObj = {'title':obj.orderCustTechnology};
						columns.push(colObj);
						technology.push(obj.orderCustTechnology);
					}
				});
				var dataArr = [[]], totalCount = {}, regionCount={},i=0,j=0;
				_.forEach(customers, function(customer){
					_.forEach(technology, function(tech){
						if(tech!==null){
							createNestedObject(tableData, [customers[i], technology[j]], 0);
							createNestedObject(totalCount, [customers[i]+countryNames[i]],0);
							createNestedObject(regionCount, [tech], 0);
							dataArr[i] = [];
							(dataArr[i])[0] = customers[i];
							(dataArr[i])[1] = countryNames[i];
							for(var index=1; index<=technology.length; index++)
								(dataArr[i])[index+1] = 0;
						}
						j++;
					});
					i++;
				});
				var total = 0,p;
				_.forEach(customerData, function(obj){
					if(obj.orderCustTechnology!==null){
						createNestedObject(tableData, [obj.orderCustEndUserName, obj.orderCustTechnology], obj.orderCustTechOrderSum);
						createNestedObject(regionCount, [obj.orderCustTechnology], regionCount[obj.orderCustTechnology]+Math.round(obj.orderCustTechOrderSum/1000));
						var orderCustOrdersSumNum =Math.round(obj.orderCustTechOrderSum/1000);
						if( custCountry[custCountry.indexOf(obj.orderCustEndUserName+obj.orderCustCountry)] === obj.orderCustEndUserName+obj.orderCustCountry){
							p = custCountry.indexOf(obj.orderCustEndUserName+obj.orderCustCountry);
							(dataArr[p])[technology.indexOf(obj.orderCustTechnology)+2] =numberWithCommas(Math.round(orderCustOrdersSumNum));
							total = total + Math.round(obj.orderCustTechOrderSum/1000);
							totalCount[obj.orderCustEndUserName+obj.orderCustCountry]=totalCount[obj.orderCustEndUserName+obj.orderCustCountry]+Math.round(obj.orderCustTechOrderSum/1000);
						}
					}
				});
				columns.push({'title':'Grand Total'});
				regionCount['Grand Total']=total;
				_.forEach(custCountry, function(customer){		
					if((dataArr[custCountry.indexOf(customer)])!==undefined)
						(dataArr[custCountry.indexOf(customer)])[(dataArr[custCountry.indexOf(customer)]).length] = numberWithCommas(Math.round(totalCount[customer]));
				});
				if(columns.length<=2){
					tableData['regions'] = _.sortBy(technology,function(tech){return tech});
					dataObj['tableData'] = [[]];
					dataObj['dataArr'] = [[]];
					dataObj['columns'] = columns;
					dataObj['regionCount'] = regionCount;
				}
				else{
					tableData['regions'] = _.sortBy(technology,function(tech){return tech});
					dataObj['tableData'] = tableData;
					dataObj['dataArr'] = dataArr;
					dataObj['columns'] = columns;
					dataObj['regionCount'] = regionCount;
				}
				return dataObj;
			};
			//Order Top Customer Region level
			var processTable = function(customerData){
				var dataObj = {},regionNames = [],custRegion = [];
				var customers=[], technology=[], tableData = {}, columns = [];
				columns = [{'title':'Customer'}];
				columns.push({'title':'Region'});
				_.forEach(customerData, function(obj){
					if(customers.indexOf(obj.orderCustEndUserName)=== -1 || regionNames.indexOf(obj.orderCustRegion)=== -1){
						customers.push(obj.orderCustEndUserName);
						regionNames.push(obj.orderCustRegion);
						custRegion.push(obj.orderCustEndUserName+obj.orderCustRegion);
					}
					if(technology.indexOf(obj.orderCustTechnology)=== -1 && obj.orderCustTechnology!==null){					
						var colObj = {'title':obj.orderCustTechnology};
						columns.push(colObj);
						technology.push(obj.orderCustTechnology);
					}
				});
				var dataArr = [[]], totalCount ={}, regionCount={},i = 0,j = 0;
				_.forEach(customers, function(customer){
					_.forEach(technology, function(tech){
						if(tech!==null){
							createNestedObject(tableData, [customers[i], technology[j]],0);
							createNestedObject(totalCount, [customers[i]+regionNames[i]], 0);
							createNestedObject(regionCount, [tech], 0);
							dataArr[i] = [];
							(dataArr[i])[0] = customers[i];
							(dataArr[i])[1] = regionNames[i];
							for(var index=1; index<=technology.length; index++)
								(dataArr[i])[index+1] = 0;
						}
						j++;
					});
					i++;
				});
				var total = 0,p;
				_.forEach(customerData, function(obj){
					if(obj.orderCustTechnology!==null){
						createNestedObject(tableData, [obj.orderCustEndUserName, obj.orderCustTechnology], obj.orderCustTechOrderSum);
						createNestedObject(regionCount, [obj.orderCustTechnology], regionCount[obj.orderCustTechnology]+Math.round(obj.orderCustTechOrderSum/1000));
					    var orderCustOrdersSumNum =Math.round(obj.orderCustTechOrderSum/1000);
					    if( custRegion[custRegion.indexOf(obj.orderCustEndUserName+obj.orderCustRegion)] === obj.orderCustEndUserName+obj.orderCustRegion){
							p = custRegion.indexOf(obj.orderCustEndUserName+obj.orderCustRegion);
							(dataArr[p])[technology.indexOf(obj.orderCustTechnology)+2] =numberWithCommas(Math.round(orderCustOrdersSumNum)) ;
							totalCount[obj.orderCustEndUserName+obj.orderCustRegion]=totalCount[obj.orderCustEndUserName+obj.orderCustRegion]+Math.round(obj.orderCustTechOrderSum/1000);
							total = total +Math.round(obj.orderCustTechOrderSum/1000);
					    }
					}
				});
				columns.push({'title':'Grand Total'});
				regionCount['Grand Total']=total;
				_.forEach(custRegion, function(custRgn){					
					(dataArr[custRegion.indexOf(custRgn)])[(dataArr[custRegion.indexOf(custRgn)]).length] = numberWithCommas(Math.round(totalCount[custRgn]));
				});
				tableData['regions'] = _.sortBy(technology,function(tech){return tech});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['regionCount'] = regionCount;
				dataObj['columns'] = columns;
				return dataObj;
			};
        return {
			initTable(data,columns,id) { 
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
				if ($.fn.DataTable.isDataTable( '#'+id )) {
						$('#'+id).dataTable().fnDestroy();        
						$('#'+id).empty(); 
						 $('#'+id).append('<tfoot></tfoot>');
					}  
				dt = $('#'+id).DataTable({
					"columnDefs": [
									{
									"render": function ( data1, type, row ) {
										if(isNaN(Math.round(parseFloat(data1))))
										{
											data=data1;
											return data;
										}
										else {
											data='$'+data1+'K';
											return data;
										}
									},
								         targets: '_all'
									}
									],
				   "order": [[ columns.length-1, "desc" ]],
				   columns : columns,
                   data: data,
				   fnDrawCallback : function() {
					if(footer && data[0].length>0){
					   $('#'+id+ ' > tfoot').html('');
					   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					   $('#'+id+ ' > tfoot').append('<th> </th>');
					   _.forEach(columns, function(column){
                           if(footer[column.title] !== undefined){	
                        	  var dataValue = Math.round(footer[column.title]);
                        	 $('#'+id+ ' > tfoot').append('<th>$'+numberWithCommas(dataValue)+'K</th>');
							}
					   });
					}
					}
				});
				return dt;	
			},
			processAllCustomerData: function(customerData){
					var regionWithCustomerCount = _.sortBy(customerData, function(custData){
						return Math.round(custData.orderCustEndUserNameCount)}).reverse();
					return dataProcessing(regionWithCustomerCount);
			},
			customerTableData: function(customerData){
				return processTable(customerData);
			},
			excelDownload: function(id){
			var footer = document.getElementById(id).tFoot.innerText;
				footer=footer.split(/(\s+)/).filter( function(e) { return e.trim().length > 0; } );
			    var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 	});
				 var tableToExcel = (function() {
					 var ctx,subHeader;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
	                      if (!table.nodeType) 
	                             table = document.getElementById(id);
	                      var excelContent = '';
	                      var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                     
	                      if(id === 'IB-by-Top-Cust-Country-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Order Country Level</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='IB-by-Top-Cust-Data')
                    	  {
	                    	  subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Order Region Level</span>"+
	                          "</td></tr>";
                    	  }
	                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                      excelContent = excelContent + subHeader;
	                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
	                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                      var td = "<td style='width: auto; padding-right:5px; background-color:#111;color:white'>";
	                      var tdNumber = "<td style='mso-number-format:0'>";
	                      excelContent =excelContent + '<tr>';
	                      var flag = 0;
                            _.forEach(columns, function(column){
                                   if(columns[0]!== 'null' && flag === 0){
                                          excelContent = excelContent + th + column + '</th>';
                                          flag++;
                                   }else {
                                          excelContent = excelContent + th + column +'($K)' + '</th>';
                                   }
                            });
                            excelContent = excelContent + '</tr>';
                            _.forEach(getDataFromDT, function(row){
                                   excelContent =excelContent + '<tr>';
                                   _.forEach(row, function(rowData){
                                          if(isNaN(Math.round(rowData)))
                                          {
                                                 if((/^[0-9]{0,}$/).test(rowData))
                                                       excelContent = excelContent + tdNumber + rowData + '</td>';

                                                 else
                                                       excelContent = excelContent + '<td>' + ''+rowData + '</td>';

                                          }
                                          else
                                          {
                                                 if((/^[0-9]{0,}$/).test(rowData))
                                                       excelContent = excelContent + tdNumber + rowData + '</td>';
                                                 else
                                                       excelContent = excelContent + '<td>' +rowData + '</td>';
                                          }
                                   });
                                   excelContent =excelContent + '</tr>';
                            });
                            excelContent =excelContent + '<tr>';
                            if(columns[1]==="Region" || columns[1]==="Country"){
                           	 _.forEach(footer, function(row){
                                    row = row.replace(/K/g, "");
                                    if (row.includes('$')) {
                                           row = row.substring(1,row.length);
                                    }
                                    if(row === 'Total'){
     	                    	  		 excelContent = excelContent + td+ row + '</td>'+td + '&nbsp'+ '</td>'
     	                    	  	}else{
     	                    	  		excelContent = excelContent + td+ row + '</td>';
     	                    	  	}
                             });
                           }else{
                           	_.forEach(footer, function(row){
                                   row = row.replace(/K/g, "");
                                   if (row.includes('$')) {
                                          row = row.substring(1,row.length);
                                   }
    	                    	  	excelContent = excelContent + td+ row + '</td>';
                            });
                           }
                           
	                      excelContent =excelContent + '</tr>';
	                      if(id === 'IB-by-Top-Cust-Country-Data')
	                      {
	                    	  ctx = {worksheet:'Order country Data' , table: excelContent};
		                      document.getElementById('orderTechnoRegionCountry').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('orderTechnoRegionCountry').download = 'Order_TechnoRegion_Country.xls';
	                    }
	                      if(id ==='IB-by-Top-Cust-Data')
	                      {
	                    	  ctx = {worksheet: 'Order Data' , table: excelContent};
		                      document.getElementById('orderTechnoRegion').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('orderTechnoRegion').download = 'Order.xls';
	                      }
	                }
	                })();
	                tableToExcel(id);
				return null;
			},
			customerCountryTableData: function(customerData){
				return processCountryTable(customerData);
			},
			topCustomerTableData: function(customerData){
				return processTable(customerData);
			},
			countryDataProcessing: function(customerData){
				return countryDataProcess(customerData);
			}
        };
    }]);
});
