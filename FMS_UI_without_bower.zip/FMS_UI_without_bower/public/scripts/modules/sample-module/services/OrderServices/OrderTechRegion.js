define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('OrderTechnoRegionService', ['$q','$http','$state','URLService','$rootScope',function($q, $http,$state,URLService,$rootScope) {
		var regionDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, colorCodes ={}, totalCounts = {}, regions = [], regionData ={};
					_.forEach(regionWithTechCount, function(region){
						if(region.orderTechRegion!==null){
							regionData[region.orderTechRegion] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.orderTechRegion!==null){
							if(regions.indexOf(region.orderTechRegion)===-1)
								regions.push(region.orderTechRegion);
							createNestedObject(technologyCounts, [region.orderTechRegion,techCount.orderTechProduct], 0);
							createNestedObject(totalCounts, [techCount.orderTechProduct], 0);
						}
						});
					});
					var totalCount = 0, count;
					_.forEach(regionWithTechCount, function(region){
						createNestedObject(technologyCounts, [region.orderTechRegion,region.orderTechProduct], (technologyCounts[region.orderTechRegion])[region.orderTechProduct]+Math.round(region.orderTechOrdersSum));
						totalCounts[region.orderTechProduct]=totalCounts[region.orderTechProduct]+Math.round(region.orderTechOrdersSum);
						totalCount = totalCount + Math.round(region.orderTechOrdersSum);
						colorCodes[region.orderTechRegion] = parseInt(region.orderTechRegionId);
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							});
						});
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=
									Math.round((technologyCounts[region])[technology]); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region, '_colorIndex':colorCodes[region]});
						});
					var returnObj = {};
					returnObj['totalCount'] = totalCount;
					returnObj['technologies'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					return returnObj;
			};
			var countryDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, totalCounts = {}, regions = [], regionData ={}, testData = {},totalCount = {},_colorIndexes = [],technologiesList = [];
					_.forEach(regionWithTechCount, function(region){
						if(region.orderTechProduct!==null){
							regionData[region.orderTechProduct] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.orderTechProduct!==null){
							if(regions.indexOf(region.orderTechProduct)===-1)
								regions.push(region.orderTechProduct);
							createNestedObject(technologyCounts, [region.orderTechProduct,techCount.orderTechCountry], 0);
							createNestedObject(testData, [techCount.orderTechCountry,region.orderTechProduct], -1);
							createNestedObject(testData, [techCount.orderTechCountry, '~Total'], 0);
							createNestedObject(totalCounts, [techCount.orderTechCountry], 0);
							createNestedObject(totalCount, [region.orderTechProduct , 'Total'] , 0);
							if(technologiesList.indexOf(techCount.orderTechProduct) === -1){
								technologiesList.push(techCount.orderTechProduct);
								_colorIndexes.push(techCount.orderColorCode);							
							}	
						}
						});
					});
					totalCount['gTotal'] = 0;
					_.forEach(regionWithTechCount, function(region){
						if(region.orderTechCountry!==null){
							createNestedObject(technologyCounts, [region.orderTechProduct,region.orderTechCountry], (technologyCounts[region.orderTechProduct])[region.orderTechCountry]+Math.round(region.orderTechOrdersSum));
							createNestedObject(testData, [region.orderTechCountry, region.orderTechProduct ] , Math.round(region.orderTechOrdersSum));
							createNestedObject(testData, [region.orderTechCountry,'~Total'] , (testData[region.orderTechCountry])['~Total']+Math.round(region.orderTechOrdersSum));
							createNestedObject(totalCount, [region.orderTechProduct , 'Total'] , (totalCount[region.orderTechProduct])['Total']+Math.round(region.orderTechOrdersSum));
							totalCounts[region.orderTechCountry]=totalCounts[region.orderTechCountry]+Math.round(region.orderTechOrdersSum);
							totalCount['gTotal']+=Math.round(region.orderTechOrdersSum);
						}
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							var count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							}); 
						});
						var highchartData = [];
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=Math.round(((technologyCounts[region])[technology])/1000); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region});
							highchartData.push({'data': regionData[region], 'name':region});
						});
						_.forEach(testData, function(data){
								testData['regions'] = [];
								/* Sort Alphabetically */
								testData['regions'] = _.sortBy(Object.keys(data), function(o) { return o; });	
							return false;
						});
					var returnObj = {};
					returnObj['technology'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					returnObj['highchartData'] = highchartData;
					returnObj['testData'] = testData;
					returnObj['totalCount'] = totalCount;
					returnObj['colorCodes'] =_colorIndexes;
					return returnObj;
			};
			//Order Technology & Region Country level
			var processCountryTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Technology'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.orderTechProduct)=== -1){
						technologies.push(obj.orderTechProduct);
					}
					if(regions.indexOf(obj.orderTechCountry)=== -1 && obj.orderTechCountry !==null){
						var colObj = {'title':obj.orderTechCountry};
						columns.push(colObj);
						regions.push(obj.orderTechCountry);
					}
				});
				var dataArr = [[]], totalCount={}, regionCount= {};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
						if(!(region===null)){
							createNestedObject(tableData, [technology, region], 0);
							createNestedObject(totalCount, [technology], 0);
							createNestedObject(regionCount, [region], 0);
							dataArr[technologies.indexOf(technology)] = [];
							(dataArr[technologies.indexOf(technology)])[0] = technology;
							for(var index=1; index<=regions.length; index++)
								(dataArr[technologies.indexOf(technology)])[index] = 0;
						}
					});					
				});		
				regionCount['Grand Total']=0.00;
				_.forEach(technologyData, function(obj){
					if(!(obj.orderTechCountry===null)){
						createNestedObject(tableData, [obj.orderTechProduct, obj.orderTechCountry], obj.orderTechOrdersSum);
						var orderTechOrdersSumNum =Math.round(obj.orderTechOrdersSum/1000);
						(dataArr[technologies.indexOf(obj.orderTechProduct)])[regions.indexOf(obj.orderTechCountry)+1] =numberWithCommas(Math.round(orderTechOrdersSumNum));
						totalCount[obj.orderTechProduct]=totalCount[obj.orderTechProduct]+Math.round(obj.orderTechOrdersSum/1000);
						regionCount[obj.orderTechCountry]=regionCount[obj.orderTechCountry]+Math.round(obj.orderTechOrdersSum/1000);
						regionCount['Grand Total'] = regionCount['Grand Total'] +Math.round(obj.orderTechOrdersSum/1000);
					}
				});
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){					
					if((dataArr[technologies.indexOf(technology)])!==undefined)
						(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = numberWithCommas(Math.round(totalCount[technology]));
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['regionCount'] = regionCount;
				dataObj['columns'] = columns;
				return dataObj;
			};
			//Order Technology & Region Region level
			var processTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Technology'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.orderTechProduct)=== -1){
						technologies.push(obj.orderTechProduct);
					}
					if(regions.indexOf(obj.orderTechRegion)=== -1 && obj.orderTechRegion!==null){
						var colObj = {'title':obj.orderTechRegion};
						columns.push(colObj);
						regions.push(obj.orderTechRegion);
					}
				});
				var dataArr = [[]], totalCount={}, regionCount={};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [technology, region], 0);
						createNestedObject(totalCount, [technology], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[technologies.indexOf(technology)] = [];
						(dataArr[technologies.indexOf(technology)])[0] = technology;
						for(var index=1; index<=regions.length; index++)
							(dataArr[technologies.indexOf(technology)])[index] =0;
					}
					});					
				});
				regionCount['Grand Total']=0.00;
				_.forEach(technologyData, function(obj){
				if(obj.orderTechRegion!==null){
					createNestedObject(tableData, [obj.orderTechProduct, obj.orderTechRegion], obj.orderTechOrdersSum);
					var orderTechOrdersSumNum= Math.round(obj.orderTechOrdersSum/1000);
					(dataArr[technologies.indexOf(obj.orderTechProduct)])[regions.indexOf(obj.orderTechRegion)+1] = numberWithCommas(Math.round(orderTechOrdersSumNum));
					totalCount[obj.orderTechProduct]=totalCount[obj.orderTechProduct]+Math.round(obj.orderTechOrdersSum/1000);
					regionCount[obj.orderTechRegion]=regionCount[obj.orderTechRegion]+Math.round(obj.orderTechOrdersSum/1000);
					regionCount['Grand Total']=regionCount['Grand Total']+Math.round(obj.orderTechOrdersSum/1000);
				}
				});
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){					
					(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = numberWithCommas(Math.round(totalCount[technology]));
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
        return {
			searchDataService: function(){
				var jsonData = [];
				var item = {};
				item["region"] = "";
				item["unitStatusDesc"]="InService";
				item["siteCustCountry"]= "";
				item["servRelationDescOng"]="";
				item["technology"]="";
				item["equipCode"]="";
				item["marketSegmentDesc"]="";
				item["customerName"]="";
				item["maintPolicyCode"]="";
				item["businessSegment"]=$rootScope.businessSegment;
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
				jsonData.push(item);
				return jsonData;
			},
			getRegionWithCount: function(techRegionData){	
					return regionDataProcess(techRegionData)['chartData']
			},
			processedData: function(techRegionData){	
					return regionDataProcess(techRegionData);
			},
			countryDataProcess: function(techRegionData){	
					return countryDataProcess(techRegionData);
			},
			processTable: function(technologyData){
				return processTable(technologyData);
			},
			processCountryTable: function(technologyData){
				return processCountryTable(technologyData);
			},
			initTable(data,columns,id) {
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
				if ($.fn.DataTable.isDataTable( '#'+id )) {
						$('#'+id).dataTable().fnDestroy();        
						$('#'+id).empty(); 
						 $('#'+id).append('<tfoot></tfoot>');
					}  
				dt = $('#'+id).DataTable({
					"columnDefs": [
									{
									"render": function ( data1, type, row ) {
										if(isNaN(Math.round(parseFloat(data1))))
										{
											data=data1;
											return data;
										}
										else {
											data='$'+data1+'K';
											return data;
										}
									},
								         targets: '_all'
									}
									],
					"order": [[ columns.length-1, "desc" ]],
				   columns : columns,
                   data: data,
				   "pageLength": 10,
				   fnDrawCallback : function() {
					if(footer && data[0].length>0){
					   $('#'+id+ ' > tfoot').html('');
					   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					   _.forEach(columns, function(column){
							if(footer[column.title] !== undefined){
								var dataValue = Math.round(footer[column.title]);
								$('#'+id+ ' > tfoot').append('<th>$'+numberWithCommas(dataValue)+'K</th>');
							}
					   });
					}
					}
				});
				return dt;				
			},
			getTechnologyData: function(technologyDropdown,regionDropdown,regionWithCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var testData = {}, countryCount = {}, totalCount = {}, technology= [],technologiesList=[], techTotal = {},_colorIndexes = [];		
					_.forEach(regionWithCount, function(reg){
						_.forEach(regionDropdown, function(tech){
						createNestedObject(testData, [reg.name,tech.orderTechProduct], -1);
						createNestedObject(testData, [reg.name,'~Total'], 0);
						createNestedObject(techTotal, [reg.name], 0);
						createNestedObject(totalCount, [tech.orderTechProduct , 'Total'] , 0);
						createNestedObject(countryCount, [tech.orderTechProduct , reg.name] , 0);
					});
					});
					totalCount['gTotal'] = 0;
					_.forEach(regionDropdown, function(respData){
						var tempObject = {};
						tempObject[respData.orderTechProduct]= respData.orderTechOrdersSum ;
						createNestedObject(testData, [respData.orderTechRegion, respData.orderTechProduct ] , Math.round(respData.orderTechOrdersSum));
						createNestedObject(countryCount, [respData.orderTechProduct , respData.orderTechRegion] , Math.round(respData.orderTechOrdersSum));
						createNestedObject(totalCount, [respData.orderTechProduct , 'Total'] , (totalCount[respData.orderTechProduct])['Total']+Math.round(respData.orderTechOrdersSum));
						createNestedObject(testData, [respData.orderTechRegion,'~Total'] , (testData[respData.orderTechRegion])['~Total']+Math.round(respData.orderTechOrdersSum));
						createNestedObject(techTotal, [respData.orderTechRegion] , (techTotal[respData.orderTechRegion])+Math.round(respData.orderTechOrdersSum));
						totalCount['gTotal']+=Math.round(respData.orderTechOrdersSum);
						if(technologiesList.indexOf(respData.orderTechProduct) === -1){
							technologiesList.push(respData.orderTechProduct);
							_colorIndexes.push(respData.orderColorCode);							
						}			
							
						
						});
					techTotal = _.sortBy(_.pairs(techTotal), function (item) { return item[1]; });
					/* Descending Sort */
					techTotal = techTotal.reverse();
					var rankArray = [];
					_.forEach(techTotal, function(tech){
						rankArray.push(tech[0]);
					});
					_.forEach(testData, function(data){
							testData['regions'] = [];
							/* Sort Alphabetically */
							testData['regions'] = _.sortBy(Object.keys(data), function(o) { return o; });	
						return false;
					});

					var chartData = [], chartObj = {};
					_.forEach(Object.keys(countryCount), function(data){
							chartObj ={};
							var countryCountObj = countryCount[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							_.forEach(rankArray, function(key){
									chartObj['data'].push(Math.round((countryCountObj[key])/1000));
							});
							chartData.push(chartObj);
							technology = rankArray;
					});
					
					
					var returnObj = {};
					returnObj['testData'] = testData;
					returnObj['countryCount'] = countryCount;
					returnObj['chartData'] = chartData;
					returnObj['totalCount'] = totalCount;
					returnObj['technology'] = technology;
					returnObj['colorCodes'] = _colorIndexes;
					return returnObj;
			},
        	getCustomerData: function(customerNameData){
				/* Top 10 Customers */
					var regionWithCustomerCount = _.first(_.sortBy(customerNameData, function(custData){
						return Math.round(custData.orderTechOrdersSum)}).reverse(),10);
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var customerCounts = {}, colorCodes ={};					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.orderTechRegion!==null){
							createNestedObject(customerCounts, [region.orderTechRegion,customerCount.custName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
					if(region.orderTechRegion!==null){	
						createNestedObject(customerCounts, [region.orderTechRegion,region.custName], (customerCounts[region.orderTechRegion])[region.custName]+Math.round(region.orderTechOrdersSum));
						totalCustomerCount = totalCustomerCount + Math.round(region.orderTechOrdersSum);
						colorCodes[region.orderTechRegion] = region.orderTechRegionId - 1;
					}
					});
					var chartData = [], chartObj = {}, customers = [];
					_.forEach(Object.keys(customerCounts), function(data){
							chartObj ={};
							var keys = Object.keys(customerCounts[data]);
							var customerCountsObj = customerCounts[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							chartObj['_colorIndex']=colorCodes[data];
							_.forEach(keys, function(key){
									chartObj['data'].push(customerCountsObj[key]);
							});
							customers = keys;
							chartData.push(chartObj);
					});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			},
			updateTechReg: function(techRegionData){
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};

					var totalcount = 0,regionWithCountData=[], regionData={};					
					var regions = [], _colorIndexes = [], technologies = [], summaryData = {}, totalCount={};
					_.forEach(techRegionData, function(responseObj){
						if(regions.indexOf(responseObj.orderTechProduct) === -1 && responseObj.orderTechProduct!==null){
							regions.push(responseObj.orderTechProduct);
							_colorIndexes.push(responseObj.orderColorCode);	
						}
						if(technologies.indexOf(responseObj.orderTechRegion) === -1){
							technologies.push(responseObj.orderTechRegion);
						}					
					});
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(summaryData, [region, technology], 0);
								createNestedObject(summaryData, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
							}
						});
					});		
		
					_.forEach(techRegionData, function(responseObj){
						if(responseObj.orderTechRegion!==null){
							createNestedObject(summaryData, [responseObj.orderTechProduct, responseObj.orderTechRegion],responseObj.orderTechOrdersSum);
							totalCount[responseObj.orderTechRegion]=totalCount[responseObj.orderTechRegion]+Math.round(responseObj.orderTechOrdersSum);
							totalcount = totalcount + Math.round(responseObj.orderTechOrdersSum);
						}
					});
					totalCount = _.sortBy(_.pairs(totalCount), function (item) { return item[1]; });
					/* Descending Sort */
					totalCount = totalCount.reverse();
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					_.forEach(regions, function(region){
						_.forEach(rankArray, function(technology){
							((regionData[region])[rankArray.indexOf(technology)])=Math.round(((summaryData[region])[technology])/1000);
						});
						regionWithCountData.push({
							'data': regionData[region], 
							'name':region
						});
					});
				var returnObj = {};
				returnObj['regionWithCount'] = regionWithCountData;
				returnObj['technology'] = rankArray;
				returnObj['totalcount'] = totalcount;
				returnObj['colorCodes'] = _colorIndexes;
				return returnObj;
			}
        };
    }]);
});
