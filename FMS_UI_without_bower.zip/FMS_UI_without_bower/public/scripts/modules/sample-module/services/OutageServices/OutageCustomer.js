define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('OutageCustomerService', ['$q','$http','$state','URLService',function($q, $http,$state,URLService) {
		var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
		var dataProcessing = function(regionWithCustomerCount){
					var customerCounts = {}, colorCodes ={};
					
					_.forEach(regionWithCustomerCount, function(tech){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(tech.ofTechDesc!==null){
							createNestedObject(customerCounts, [tech.ofTechDesc,customerCount.ofCustomerName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(tech){
						if(tech.ofTechDesc!==null){
							createNestedObject(customerCounts, [tech.ofTechDesc,tech.ofCustomerName], (customerCounts[tech.ofTechDesc])[tech.ofCustomerName]+parseInt(tech.ofTechCount));
								totalCustomerCount = totalCustomerCount + parseInt(tech.ofTechCount);
								colorCodes[tech.ofTechDesc] = tech.ofColorCode;
							}
						});
						var chartData = [], chartObj = {}, customers = [];
						_.forEach(Object.keys(customerCounts), function(data){
								chartObj ={};
								var keys = Object.keys(customerCounts[data]);
								var customerCountsObj = customerCounts[data];
								chartObj['data'] = [];
								chartObj['name'] = data;
								chartObj['color']=colorCodes[data];
								_.forEach(keys, function(key){
										chartObj['data'].push(customerCountsObj[key]);
								});
								customers = keys;
								chartData.push(chartObj);
						});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			};
			var processCountryTable = function(customerData){
				var dataObj = {};
				var customers=[], regions=[], tableData = {}, columns = [];
				columns = [{'title':'Customer'}];
				_.forEach(customerData, function(obj){
					if(customers.indexOf(obj.geDunsName)=== -1){
						customers.push(obj.geDunsName);
					}
					if(regions.indexOf(obj.iBCustRegion)=== -1 && obj.iBCustRegion!==null){
						var colObj = {'title':obj.iBCustRegion};
						columns.push(colObj);
						regions.push(obj.iBCustRegion);
					}
				});
				var dataArr = [[]], totalCount = {}, regionCount={};
				_.forEach(customers, function(customer){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [customer, region], 0);
						createNestedObject(totalCount, [customer], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[customers.indexOf(customer)] = [];
						(dataArr[customers.indexOf(customer)])[0] = customer;
						for(var index=1; index<=regions.length; index++)
							(dataArr[customers.indexOf(customer)])[index] = 0;
					}
					});
				});
				var total = 0;
				_.forEach(customerData, function(obj){
				if(obj.iBCustRegion!==null){
					createNestedObject(tableData, [obj.geDunsName, obj.iBCustRegion], obj.iBCustAvtotSum);
					(dataArr[customers.indexOf(obj.geDunsName)])[regions.indexOf(obj.iBCustRegion)+1] = parseInt(obj.iBCustAvtotSum);
					createNestedObject(regionCount, [obj.iBCustRegion], regionCount[obj.iBCustRegion]+parseInt(obj.iBCustAvtotSum));
					total = total + parseInt(obj.iBCustAvtotSum);
					totalCount[obj.geDunsName]=totalCount[obj.geDunsName]+parseInt(obj.iBCustAvtotSum);
				}
				});
				columns.push({'title':'Grand Total'});
				regionCount['Grand Total']=total;
				_.forEach(customers, function(customer){					
					(dataArr[customers.indexOf(customer)])[(dataArr[customers.indexOf(customer)]).length] = totalCount[customer];
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
        return {
			/* Network Call */
			getIBMetricsData: function(){
				var request = {
					'method': 'POST',
					'url': URLService.newMetrics.IBData,						
					};
				return networkCall(request);
			},
        	getCustomerData: function(customerNameData){
        		
				/* Top 10 Customers */
        		var regionWithCustomerCount = customerNameData;
					
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var colorCodes ={};	
					var customerCounts = {};					
					_.forEach(regionWithCustomerCount, function(tech){
						_.forEach(regionWithCustomerCount, function(customerCount){
						createNestedObject(customerCounts, [tech.ocTechDesc,customerCount.ocCustomerName], 0);
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(tech){
						createNestedObject(customerCounts, [tech.ocTechDesc,tech.ocCustomerName], (customerCounts[tech.ocTechDesc])[tech.ocCustomerName]+parseInt(tech.ocTechCount));
						totalCustomerCount = totalCustomerCount + parseInt(tech.ocTechCount);
						colorCodes[tech.ocTechDesc] = tech.ocColorCode;
					});
					var chartData = [], chartObj = {}, colorIndex = 0, customers = [];
					_.forEach(Object.keys(customerCounts), function(data){
							chartObj ={};
							var keys = Object.keys(customerCounts[data]);
							var customerCountsObj = customerCounts[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							chartObj['color']= colorCodes[data];
							colorIndex++;
							_.forEach(keys, function(key){
									chartObj['data'].push(customerCountsObj[key]);
							});
							customers = keys;
							chartData.push(chartObj);
					});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			},
			processCustomerData: function(customerData){
					return dataProcessing(customerData);
			},
			processAllCustomerData: function(customerData){
					return dataProcessing(customerData);
			},
			customerCountryTableData: function(customerData){
				return processCountryTable(customerData);
			}
        };
    }]);
});
