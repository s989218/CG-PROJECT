define([
	'./OutageChart',
	'./OutageCustomer',
	'./OutageTable',
	'./OutageMetricsService',
	'./OutageTechRegion'
	], function() {

});
