define(['angular', '../../sample-module'], function(angular, module) {
	'use strict';
	module.factory('OutageTableService', ['$q','$http','$state','URLService',function($q, $http,$state,URLService) {
		var createNestedObject = function( base, names, value ) {
			var lastName = arguments.length === 3 ? names.pop() : false;
			for( var i = 0; i < names.length; i++ ) {
				base = base[ names[i] ] = base[ names[i] ] || {};
			}
			if( lastName ) base = base[ lastName ] = value;
			return base;
		};
		var countryDataProcess = function(regionWithCustomerCount){
			var customerCounts = {}, colorCodes ={};
			_.forEach(regionWithCustomerCount, function(tech){
				_.forEach(regionWithCustomerCount, function(customerCount){
					if(tech.ofTechDesc!=null){
						createNestedObject(customerCounts, [tech.ofTechDesc,customerCount.ofCustomerName], 0);
					}
				});
			});
			var totalCustomerCount = 0;
			_.forEach(regionWithCustomerCount, function(tech){
				if(tech.ofTechDesc!=null){
					createNestedObject(customerCounts, [tech.ofTechDesc,tech.ofCustomerName], (customerCounts[tech.ofTechDesc])[tech.ofCustomerName]+parseInt(tech.ofTechCount));
					totalCustomerCount = totalCustomerCount + parseInt(tech.ofTechCount);
					colorCodes[tech.ofTechDesc] = tech.ofColorCode;
				}
			});
			var chartData = [], chartObj = {}, customers = [];
			_.forEach(Object.keys(customerCounts), function(data){
				chartObj ={};
				var keys = Object.keys(customerCounts[data]);
				var customerCountsObj = customerCounts[data];
				chartObj['data'] = [];
				chartObj['name'] = data;
				chartObj['color']=colorCodes[data];
				_.forEach(keys, function(key){
					chartObj['data'].push(customerCountsObj[key]);
				});
				customers = keys;
				chartData.push(chartObj);
			});
			var returnObj = {};
			returnObj['totalCustomerCount'] = totalCustomerCount;
			returnObj['customers'] = customers;
			returnObj['chartData'] = chartData;
			return returnObj;
		};
		var dataProcessing = function(regionWithCustomerCount){
			var customerCounts = {}, colorCodes ={};

			_.forEach(regionWithCustomerCount, function(region){
				_.forEach(regionWithCustomerCount, function(customerCount){
					if(region.region!==null){
						createNestedObject(customerCounts, [region.ofRegion,customerCount.ofCustomerName], 0);
					}
				});
			});
			var totalCustomerCount = 0;
			_.forEach(regionWithCustomerCount, function(region){
				if(region.region!==null){
					createNestedObject(customerCounts, [region.ofRegion,region.ofCustomerName], (customerCounts[region.ofRegion])[region.ofCustomerName]+parseInt(region.ofOutages));
					totalCustomerCount = totalCustomerCount + parseInt(region.ofOutages);
					colorCodes[region.ofRegId] = region.ofRegId - 1;
				}
			});
			var chartData = [], chartObj = {}, customers = [];
			_.forEach(Object.keys(customerCounts), function(data){
				chartObj ={};
				var keys = Object.keys(customerCounts[data]);
				var customerCountsObj = customerCounts[data];
				chartObj['data'] = [];
				chartObj['name'] = data;
				chartObj['_colorIndex']=colorCodes[data];
				_.forEach(keys, function(key){
					chartObj['data'].push(customerCountsObj[key]);
				});
				customers = keys;
				chartData.push(chartObj);
			});
			var returnObj = {};
			returnObj['totalCustomerCount'] = totalCustomerCount;
			returnObj['customers'] = customers;
			returnObj['chartData'] = chartData;
			return returnObj;
		};
		//outage top customer country Level  
		var processCountryTable = function(customerData){
			var dataObj = {},custCountry = [];
			var customers=[], technology=[], tableData = {}, columns = [],countryNames = [];
			columns = [{'title':'Customer'}];
			columns.push({'title':'Country'});
			_.forEach(customerData, function(obj){
				if(customers.indexOf(obj.ofCustomerName)=== -1 || countryNames.indexOf(obj.ofCountry)=== -1){
					customers.push(obj.ofCustomerName);
					countryNames.push(obj.ofCountry);
					custCountry.push(obj.ofCustomerName+obj.ofCountry);
				}
				if(technology.indexOf(obj.ofTechDesc)=== -1 && obj.ofTechDesc!==null){
					var colObj = {'title':obj.ofTechDesc};
					columns.push(colObj);
					technology.push(obj.ofTechDesc);
				}
			});
			var dataArr = [[]], totalCount = {}, regionCount={},i=0,j=0;
			_.forEach(customers, function(customer){
				_.forEach(technology, function(tech){
					if(tech!==null){
						createNestedObject(tableData, [customers[i], technology[j]], 0);
						createNestedObject(totalCount, [customers[i]+countryNames[i]], 0);
						createNestedObject(regionCount, [tech], 0);
						dataArr[i] = [];
						(dataArr[i])[0] = customers[i];
						(dataArr[i])[1] = countryNames[i];
						for(var index=1; index<=technology.length; index++)
							(dataArr[i])[index+1] = 0;
					}
					j++;
				});
				i++;
			});
			var total = 0,p;
			_.forEach(customerData, function(obj){
				if(obj.ofCountry!==null){
					createNestedObject(tableData, [obj.ofCustomerName, obj.ofTechDesc], obj.ofTechCount);
					createNestedObject(regionCount, [obj.ofTechDesc], regionCount[obj.ofTechDesc]+parseInt(obj.ofTechCount));
					var dmCustAvtotSumNum = parseInt(obj.ofTechCount);
					if( custCountry[custCountry.indexOf(obj.ofCustomerName+obj.ofCountry)] === obj.ofCustomerName+obj.ofCountry){
						p = custCountry.indexOf(obj.ofCustomerName+obj.ofCountry);
						(dataArr[p])[technology.indexOf(obj.ofTechDesc)+2] = numberWithCommas(dmCustAvtotSumNum);
						total = total + parseInt(obj.ofTechCount);
						totalCount[obj.ofCustomerName+obj.ofCountry]=totalCount[obj.ofCustomerName+obj.ofCountry]+parseInt(obj.ofTechCount);
					}
				}
			});
			columns.push({'title':'Grand Total'});
			regionCount['Grand Total']=total;
			_.forEach(custCountry, function(custCntry){                                                                          
				(dataArr[custCountry.indexOf(custCntry)])[(dataArr[custCountry.indexOf(custCntry)]).length] = numberWithCommas(totalCount[custCntry]);
			});
			tableData['regions'] = _.sortBy(technology,function(region){return region});
			dataObj['tableData'] = tableData;
			dataObj['dataArr'] = dataArr;
			dataObj['columns'] = columns;
			dataObj['regionCount'] = regionCount;
			return dataObj;
		};
		//outage top customer Region Level
		var processTable = function(customerData){
			var dataObj = {},regionNames = [],custRegion = [];
			var customers=[], technology=[], tableData = {}, columns = [];
			columns = [{'title':'Customer'}];
			columns.push({'title':'Region'});
			_.forEach(customerData, function(obj){
				if(customers.indexOf(obj.ofCustomerName)=== -1 || regionNames.indexOf(obj.ofRegion)=== -1 ){
					customers.push(obj.ofCustomerName);
					regionNames.push(obj.ofRegion);
					custRegion.push(obj.ofCustomerName+obj.ofRegion);
				}
				if(technology.indexOf(obj.ofTechDesc)=== -1 && obj.ofTechDesc!==null){					
					var colObj = {'title':obj.ofTechDesc};
					columns.push(colObj);
					technology.push(obj.ofTechDesc);
				}
			});
			var dataArr = [[]], totalCount ={}, regionCount={},i=0,j=0;
			_.forEach(customers, function(customer){
				_.forEach(technology, function(tech){
					if(tech!==null){
						createNestedObject(tableData, [customers[i],technology[j]], 0);
						createNestedObject(totalCount, [customers[i]+regionNames[i]], 0);
						createNestedObject(regionCount, [tech], 0);
						dataArr[i] = [];
						(dataArr[i])[0] = customers[i];
						(dataArr[i])[1] = regionNames[i];
						for(var index=1; index<=technology.length; index++)
							(dataArr[i])[index+1] = 0;
					}
					j++;
				});
				i++;
			});
			var total = 0,p;
			_.forEach(customerData, function(obj){
				if(obj.ofTechDesc!==null){
					createNestedObject(tableData, [obj.ofCustomerName, obj.ofTechDesc], obj.ofTechCount);
					createNestedObject(regionCount, [obj.ofTechDesc], regionCount[obj.ofTechDesc]+parseInt(obj.ofTechCount));
					var dmCustAvtotSumNum=parseInt(obj.ofTechCount);
					if( custRegion[custRegion.indexOf(obj.ofCustomerName+obj.ofRegion)] === obj.ofCustomerName+obj.ofRegion){
						p = custRegion.indexOf(obj.ofCustomerName+obj.ofRegion);
						(dataArr[p])[technology.indexOf(obj.ofTechDesc)+2] = numberWithCommas(dmCustAvtotSumNum);
						totalCount[obj.ofCustomerName+obj.ofRegion]=totalCount[obj.ofCustomerName+obj.ofRegion]+parseInt(obj.ofTechCount);
						total = total +parseInt(obj.ofTechCount);
					}
				}
			});
			columns.push({'title':'Grand Total'});
			regionCount['Grand Total']=total;
			_.forEach(custRegion, function(custReg){					
				(dataArr[custRegion.indexOf(custReg)])[(dataArr[custRegion.indexOf(custReg)]).length] = numberWithCommas(totalCount[custReg]);
			});
			tableData['regions'] = _.sortBy(technology,function(tech){return tech});
			dataObj['tableData'] = tableData;
			dataObj['dataArr'] = dataArr;
			dataObj['regionCount'] = regionCount;
			dataObj['columns'] = columns;
			return dataObj;
		};
		return {
			initTable(data,columns,id) { 
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
				if ($.fn.DataTable.isDataTable( '#'+id )) {
					$('#'+id).dataTable().fnDestroy();        
					$('#'+id).empty(); 
					$('#'+id).append('<tfoot></tfoot>');
				}  
				dt = $('#'+id).DataTable({
					"columnDefs": [
					               {
					            	   "render": function ( data1, type, row ) {

					            		   data=data1;
					            		   return data;


					            	   },
					            	   targets: '_all'
					               }
					               ],
					               "order": [[ columns.length-1, "desc"]],
					               columns : columns,
                                   data: data,
					               fnDrawCallback : function() {
					            	   if(footer && data[0].length>0){
					            		   $('#'+id+ ' > tfoot').html('');
					            		   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					            		   $('#'+id+ ' > tfoot').append('<th>&nbsp</th>');
					            		   _.forEach(columns, function(column){                          
					            			   if(footer[column.title] !== undefined){
					            				   $('#'+id+ ' > tfoot').append('<th>'+numberWithCommas(footer[column.title])+'</th>');
					            			   }
					            		   });
					            	   }
					               }
				});
				return dt;	
			},
			
			initTechTable(data,columns,id) { 
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
				if ($.fn.DataTable.isDataTable( '#'+id )) {
					$('#'+id).dataTable().fnDestroy();        
					$('#'+id).empty(); 
					$('#'+id).append('<tfoot></tfoot>');
				}  
				dt = $('#'+id).DataTable({
					"columnDefs": [
					               {
					            	   "render": function ( data1, type, row ) {

					            		   data=data1;
					            		   return data;


					            	   },
					            	   targets: '_all'
					               }
					               ],
					               "order": [[ columns.length-1, "desc"]],
					               columns : columns,
                                   data: data,
					               fnDrawCallback : function() {
					            	   if(footer && data[0].length>0){
					            		   $('#'+id+ ' > tfoot').html('');
					            		   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					            		   _.forEach(columns, function(column){                          
					            			   if(footer[column.title] !== undefined){
					            				   $('#'+id+ ' > tfoot').append('<th>'+numberWithCommas(footer[column.title])+'</th>');
					            			   }
					            		   });
					            	   }
					               }
				});
				return dt;	
			},
			processAllCustomerData: function(customerData){
				var regionWithCustomerCount = _.sortBy(customerData, function(custData){
					return parseInt(custData.ofOutages)}).reverse();
				return dataProcessing(regionWithCustomerCount);
			},
			customerTableData: function(customerData){
				return processTable(customerData);
			},
			excelDownload: function(id){
				var footer = document.getElementById(id).tFoot.innerText;
				footer=footer.split(/(\s+)/).filter( function(e) { return e.trim().length > 0; } );
				var columns = [];
				_.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
					columns.push(data.innerHTML);
				});
				var tableToExcel = (function() {
					var ctx,subHeader;
					var uri = 'data:application/vnd.ms-excel;base64,'
						, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
							, base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
					, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
					return function(table) {
						if (!table.nodeType) 
							table = document.getElementById(id);
						var excelContent = '';
						var header = "<tr><td colspan='8' style='text-align:center'>" +
						"</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
						"<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";

						if(id ==='Outage-by-Top-Cust-Data')
						{
							subHeader="<tr><td colspan='8' style='text-align:center'>" +
							"</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Outage Region Level</span>"+
							"</td></tr>";
						}
						if(id ==='Outage-by-Top-Cust-Country-Data')
						{
							subHeader="<tr><td colspan='8' style='text-align:center'>" +
							"</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Outage Country Level</span>"+
							"</td></tr>";
						}
						excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
						excelContent = excelContent + subHeader;
						var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
						var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
						var td = "<td style='width: auto; padding-right:5px; background-color:#111;color:white'>";
						var tdNumber = "<td style='mso-number-format:0'>";
						excelContent =excelContent + '<tr>';
						_.forEach(columns, function(column){
							excelContent = excelContent + th + column + '</th>';
						});
						excelContent = excelContent + '</tr>';
						_.forEach(getDataFromDT, function(row){
							excelContent =excelContent + '<tr>';
							_.forEach(row, function(rowData){

								if((/^[0-9]{0,}$/).test(rowData))
									excelContent = excelContent + tdNumber + rowData + '</td>';
								else
									excelContent = excelContent + '<td>' + rowData + '</td>';


							});
							excelContent =excelContent + '</tr>';
						});
						excelContent =excelContent + '<tr>';
						 if(columns[1]==="Region" || columns[1]==="Country"){
							_.forEach(footer, function(row){
								if(row === 'Total'){
									excelContent = excelContent + td+ row + '</td>'+td + '&nbsp'+ '</td>'
								}else{
									excelContent = excelContent + td+ row + '</td>';
								}
							});
						 }else{
							 _.forEach(footer, function(row){
									excelContent = excelContent + td+ row + '</td>';
								});
						 }
						excelContent =excelContent + '</tr>';
						if(id === 'Outage-by-Top-Cust-Country-Data')
						{
							ctx = {worksheet:'Techno Region Data Country' , table: excelContent};
							document.getElementById('outageTechnoRegionCountry').href = (uri + base64(format(template, ctx)));
							document.getElementById('outageTechnoRegionCountry').download = 'Outage_Country.xls';
						}
						if(id ==='Outage-by-Top-Cust-Data'){
							ctx = {worksheet: 'Techno Region Data' , table: excelContent};
							document.getElementById('outageTechnoRegion').href = (uri + base64(format(template, ctx)));
							document.getElementById('outageTechnoRegion').download = 'Outage.xls';
						}
					}
				})();
				tableToExcel(id);
				return null;
			},
			customerCountryTableData: function(customerData){
				return processCountryTable(customerData);
			},
			topCustomerTableData: function(customerData){
				return processTable(customerData);
			},
			countryDataProcessing: function(customerData){
				return countryDataProcess(customerData);
			}
		};
	}]);
});
