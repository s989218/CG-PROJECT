define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('OutageTechnoRegionService', ['$q','$http','$state','URLService','$rootScope',function($q, $http,$state,URLService,$rootScope) {
    	var regionDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, colorCodes ={}, totalCounts = {}, regions = [], regionData ={};
					_.forEach(regionWithTechCount, function(region){
						if(region.otRegion!==null){
							regionData[region.otRegion] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.otRegion!==null){
							if(regions.indexOf(region.otRegion)===-1)
								regions.push(region.otRegion);
							createNestedObject(technologyCounts, [region.otRegion,techCount.otTech], 0);
							createNestedObject(totalCounts, [techCount.otTech], 0);
						}
						});
					});
					var totalCount = 0, count;
					_.forEach(regionWithTechCount, function(region){
						createNestedObject(technologyCounts, [region.otRegion,region.otTech], (technologyCounts[region.otRegion])[region.otTech]+parseInt(region.otOutages));
						totalCounts[region.otTech]=totalCounts[region.otTech]+parseInt(region.otOutages);
						totalCount = totalCount + parseInt(region.otOutages);
						colorCodes[region.otRegion] = region.otColorCode;
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							});
						});
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=
									parseInt((technologyCounts[region])[technology]); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region, '_colorIndex':colorCodes[region]});
						});
					var returnObj = {};
					returnObj['totalCount'] = totalCount;
					returnObj['technologies'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					return returnObj;
			};
			var countryDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, colorCodes =[], totalCounts = {}, regions = [], regionData ={}, testData = {},totalCount = {};
					_.forEach(regionWithTechCount, function(region){
						if(region.otTech!==null){
							regionData[region.otTech] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.otTech!==null){
							if(regions.indexOf(region.otTech)===-1){
								regions.push(region.otTech);
								colorCodes.push(region.otColorCode);
							}								
							createNestedObject(technologyCounts, [region.otTech,techCount.otCountry], 0);
							createNestedObject(testData, [techCount.otCountry,region.otTech], -1);
							createNestedObject(testData, [techCount.otCountry, '~Total'], 0);
							createNestedObject(totalCounts, [techCount.otCountry], 0);
							createNestedObject(totalCount, [region.otTech , 'Total'] , 0);
						}
						});
					});
					
					totalCount['gTotal'] = 0;
					_.forEach(regionWithTechCount, function(region){
					
						if(region.otCountry!==null){
							createNestedObject(technologyCounts, [region.otTech,region.otCountry], (technologyCounts[region.otTech])[region.otCountry]+parseInt(region.otOutages));
							createNestedObject(testData, [region.otCountry, region.otTech ] , parseInt(region.otOutages));
							createNestedObject(testData, [region.otCountry,'~Total'] , (testData[region.otCountry])['~Total']+parseInt(region.otOutages));
							createNestedObject(totalCount, [region.otTech , 'Total'] , (totalCount[region.otTech])['Total']+parseInt(region.otOutages));
							totalCounts[region.otCountry]=totalCounts[region.otCountry]+parseInt(region.otOutages);
							
							totalCount['gTotal']+=parseInt(region.otOutages);
						}
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							var count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							}); 
						});
						var highchartData = [];
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=parseInt((technologyCounts[region])[technology]); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region});
							highchartData.push({'data': regionData[region], 'name':region});
						});
						_.forEach(testData, function(data){
								testData['regions'] = [];
								/* Sort Alphabetically */
								testData['regions'] = _.sortBy(Object.keys(data), function(o) { return o; });	
							return false;
						});
					var returnObj = {};
					returnObj['technology'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					returnObj['highchartData'] = highchartData;
					returnObj['testData'] = testData;
					returnObj['totalCount'] = totalCount;
					returnObj['colorCode'] = colorCodes;
					
					return returnObj;
					
			};
			//IBO technology & region country level Table
			var processCountryTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Outages'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.otTech)=== -1){
						technologies.push(obj.otTech);
					}
					if(regions.indexOf(obj.otCountry)=== -1 && obj.otCountry !==null){
						var colObj = {'title':obj.otCountry};
						columns.push(colObj);
						regions.push(obj.otCountry);
					}
				});
				var dataArr = [[]], totalCount={}, regionCount= {};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
						if(!(region===null)){
							createNestedObject(tableData, [technology, region], 0);
							createNestedObject(totalCount, [technology], 0);
							createNestedObject(regionCount, [region], 0);
							dataArr[technologies.indexOf(technology)] = [];
							(dataArr[technologies.indexOf(technology)])[0] = technology;
							for(var index=1; index<=regions.length; index++)
								(dataArr[technologies.indexOf(technology)])[index] = 0;
						}
					});					
				});		
				regionCount['Grand Total']=0;
				_.forEach(technologyData, function(obj){
					if(!(obj.country===null)){
						createNestedObject(tableData, [obj.otTech, obj.otCountry], obj.otOutages);
						var dmTechAvtotSumNum =parseInt(obj.otOutages);
						(dataArr[technologies.indexOf(obj.otTech)])[regions.indexOf(obj.otCountry)+1] = numberWithCommas(dmTechAvtotSumNum);
						totalCount[obj.otTech]=totalCount[obj.otTech]+parseInt(obj.otOutages);
						regionCount[obj.otCountry]=regionCount[obj.otCountry]+parseInt(obj.otOutages);
						regionCount['Grand Total'] = regionCount['Grand Total'] +parseInt(obj.otOutages);
					}
				});
              
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){					
					(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = numberWithCommas(totalCount[technology]);
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['regionCount'] = regionCount;
				dataObj['columns'] = columns;
				return dataObj;
			};
			//outage technology & region Region level Table
			var processTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Outages'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.otTech)=== -1){
						technologies.push(obj.otTech);
					}
					if(regions.indexOf(obj.otRegion)=== -1 && obj.otRegion!==null){
						var colObj = {'title':obj.otRegion};
						columns.push(colObj);
						regions.push(obj.otRegion);
					}
				});

				var dataArr = [[]], totalCount={}, regionCount={};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [technology, region], 0);
						createNestedObject(totalCount, [technology], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[technologies.indexOf(technology)] = [];
						(dataArr[technologies.indexOf(technology)])[0] = technology;
						for(var index=1; index<=regions.length; index++)
							(dataArr[technologies.indexOf(technology)])[index] = 0;
					}
					});					
				});
				regionCount['Grand Total']=0;
				_.forEach(technologyData, function(obj){
				if(obj.region!==null){
					createNestedObject(tableData, [obj.otTech, obj.otRegion], obj.otOutages);
					var dmTechAvtotSumNum =parseInt(obj.otOutages);
					(dataArr[technologies.indexOf(obj.otTech)])[regions.indexOf(obj.otRegion)+1] = numberWithCommas(dmTechAvtotSumNum);
					totalCount[obj.otTech]=totalCount[obj.otTech]+parseInt(obj.otOutages);
					regionCount[obj.otRegion]=regionCount[obj.otRegion]+parseInt(obj.otOutages);
					regionCount['Grand Total'] = regionCount['Grand Total'] +parseInt(obj.otOutages);
				}
				});
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){
					(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = numberWithCommas(totalCount[technology]);
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
        return {
			searchDataService: function(){
				var jsonData = [];
				var item = {};
				item["region"] = "";
				item["country"]="";
				item["unitStatus"]= "";
				item["serviceRel"]="";
				item["technology"]="";
				item["equipment"]="";
				item["segment"]="";
				item["customerName"]="";
				item["location"]="";
				item["year"]="";
				item["quarter"]="";
				item["dunsName"]="";
				item["accMgrEmail"]="";
				item["serviceMgrEmail"]="";
				item["maintLvlDesc"]="";
				item["eventStatusDesc"]="";
                item["accountManager"] = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"] = "";
				jsonData.push(item);
				return jsonData;
			},
			getRegionWithCount: function(techRegionData){	
					return regionDataProcess(techRegionData)['chartData']
			},
			processedData: function(techRegionData){	
					return regionDataProcess(techRegionData);
			},
			countryDataProcess: function(techRegionData){	
					return countryDataProcess(techRegionData);
			},
			processTable: function(technologyData){
				return processTable(technologyData);
			},
			processCountryTable: function(technologyData){
				return processCountryTable(technologyData);
			},
			initTable(data,columns,id) { 
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
				if ($.fn.DataTable.isDataTable( '#'+id )) {
						$('#'+id).dataTable().fnDestroy();        
						$('#'+id).empty(); 
						 $('#'+id).append('<tfoot></tfoot>');
					}  
				dt = $('#'+id).DataTable({
				   "order": [[ columns.length-1, "desc" ]],
				   columns : columns,
                   data: data,
				   "pageLength": 10,
				   fnDrawCallback : function() {
					if(footer && data[0].length>0){
					   $('#'+id+ ' > tfoot').html('');
					   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					   _.forEach(columns, function(column){
							if(footer[column.title]){
								$('#'+id+ ' > tfoot').append('<th>'+footer[column.title]+'</th>');
							}
					   });
					}
					}
				});
				return dt;				
			},
			getTechnologyData: function(technologyDropdown,regionDropdown,regionWithCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var testData = {}, countryCount = {}, totalCount = {}, technology= [], techTotal = {};
					_.forEach(regionWithCount, function(reg){
						_.forEach(regionDropdown, function(tech){
						createNestedObject(testData, [reg.name,tech.otTech], -1);
						createNestedObject(testData, [reg.name,'~Total'], 0);
						createNestedObject(techTotal, [reg.name], 0);
						createNestedObject(totalCount, [tech.otTech , 'Total'] , 0);
						createNestedObject(countryCount, [tech.otTech , reg.name] , 0);
					});
					});
					var colorCodes = [];
					totalCount['gTotal'] = 0;
					_.forEach(regionDropdown, function(respData){
						var tempObject = {};
						tempObject[respData.opptyType]= respData.otOutages ;
						createNestedObject(testData, [respData.otRegion, respData.otTech ] , parseInt(respData.otOutages));
						createNestedObject(countryCount, [respData.otTech , respData.otRegion] , parseInt(respData.otOutages));
						createNestedObject(totalCount, [respData.otTech , 'Total'] , (totalCount[respData.otTech])['Total']+parseInt(respData.otOutages));
						createNestedObject(testData, [respData.otRegion,'~Total'] , (testData[respData.otRegion])['~Total']+parseInt(respData.otOutages));
						createNestedObject(techTotal, [respData.otRegion] , (techTotal[respData.otRegion])+parseInt(respData.otOutages));
						totalCount['gTotal']+=parseInt(respData.otOutages);
						if(colorCodes.indexOf(respData.otColorCode)===-1)
							colorCodes.push(respData.otColorCode);
						});
					techTotal = _.sortBy(_.pairs(techTotal), function (item) { return item[1]; });
					/* Descending Sort */
					techTotal = techTotal.reverse();
					var rankArray = [];
					_.forEach(techTotal, function(tech){
						rankArray.push(tech[0]);
					});
					_.forEach(testData, function(data){
							testData['regions'] = [];
							/* Sort Alphabetically */
							testData['regions'] = _.sortBy(Object.keys(data), function(o) { return o; });	
						return false;
					});

					var chartData = [], chartObj = {};
					_.forEach(Object.keys(countryCount), function(data){
							chartObj ={};
							var countryCountObj = countryCount[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							_.forEach(rankArray, function(key){
									chartObj['data'].push(countryCountObj[key]);
							});
							chartData.push(chartObj);
							technology = rankArray;
					});
					var returnObj = {};
					returnObj['testData'] = testData;
					returnObj['countryCount'] = countryCount;
					returnObj['chartData'] = chartData;
					returnObj['totalCount'] = totalCount;
					returnObj['technology'] = technology;
					returnObj['colorCode'] = colorCodes;
					return returnObj;
			},
        	getCustomerData: function(customerNameData){
				/* Top 10 Customers */
					var regionWithCustomerCount = _.first(_.sortBy(customerNameData, function(custData){
						return parseInt(custData.iBTechAvtotSum)}).reverse(),10);
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var customerCounts = {}, colorCodes ={};					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.iBTchRegion!==null){
							createNestedObject(customerCounts, [region.iBTchRegion,customerCount.custName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
					if(region.iBTchRegion!==null){	
						createNestedObject(customerCounts, [region.iBTchRegion,region.custName], (customerCounts[region.iBTchRegion])[region.custName]+parseInt(region.iBTechAvtotSum));
						totalCustomerCount = totalCustomerCount + parseInt(region.iBTechAvtotSum);
						colorCodes[region.iBTchRegion] = region.iBTechRegionId - 1;
					}
					});
					var chartData = [], chartObj = {}, customers = [];
					_.forEach(Object.keys(customerCounts), function(data){
							chartObj ={};
							var keys = Object.keys(customerCounts[data]);
							var customerCountsObj = customerCounts[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							chartObj['_colorIndex']=colorCodes[data];
							_.forEach(keys, function(key){
									chartObj['data'].push(customerCountsObj[key]);
							});
							customers = keys;
							chartData.push(chartObj);
					});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			},
			updateTechReg: function(techRegionData){
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var totalcount = 0,regionWithCountData=[], regionData={};					
					var regions = [], _colorIndexes = [], technologies = [], summaryData = {}, totalCount={};
					_.forEach(techRegionData, function(responseObj){
						if(regions.indexOf(responseObj.otTech) === -1 && responseObj.otTech!==null){
							regions.push(responseObj.otTech);
							_colorIndexes.push(responseObj.otColorCode);
						}
						if(technologies.indexOf(responseObj.otRegion) === -1){
							technologies.push(responseObj.otRegion);
						}					
					});
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(summaryData, [region, technology], 0);
								createNestedObject(summaryData, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
							}
						});
					});		
		
					_.forEach(techRegionData, function(responseObj){
						if(responseObj.region!==null){
							createNestedObject(summaryData, [responseObj.otTech, responseObj.otRegion],responseObj.otOutages);
							totalCount[responseObj.otRegion]=totalCount[responseObj.otRegion]+parseInt(responseObj.otOutages);
							totalcount = totalcount + parseInt(responseObj.otOutages);
						}
					});
					totalCount = _.sortBy(_.pairs(totalCount), function (item) { return item[1]; });
					/* Descending Sort */
					totalCount = totalCount.reverse();
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					_.forEach(regions, function(region){
						_.forEach(rankArray, function(technology){
							((regionData[region])[rankArray.indexOf(technology)])=parseInt((summaryData[region])[technology]);
						});
						regionWithCountData.push({
							'data': regionData[region], 
							'name':region,
							});
					});
					
				var returnObj = {};
				returnObj['regionWithCount'] = regionWithCountData;
				returnObj['technology'] = rankArray;
				returnObj['totalcount'] = totalcount;
				returnObj['colorCode'] = _colorIndexes;
				return returnObj;
			}
			
        };
    }]);
});
