define(['angular', '../sample-module'], function(angular, module) {
    'use strict';
    module.factory('CreateHighChartService', ['$q','$http','$state',function($q, $http,$state) {
    	var chart;
		return{
			createChart: function(xSeries,ySeries,id,state)
			{
				
				if(!state)
					state = null;
				Highcharts.setOptions({
			        global: {
			            useUTC: false,
			            
			        },
			        lang: {
			          decimalPoint: '.',
			          thousandsSep: ','
			        }
			    });
				chart= new Highcharts.Chart({
					chart: {
						  renderTo: id,
								type: 'bar',
								events: {
									click: function () {
										if(state!==null)
											$state.go(state);
									}
								}
						  },
					title: {
						text:''
					},
					xAxis: {
						categories: xSeries
					},
					yAxis: {
						min: 0,
						title: {
							text: '$K'
						}
					},
					tooltip: {
						pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>${point.y:,.0f}K</b> ({point.percentage:.2f}%)<br/>',
						shared: true
					},
					legend: {
						itemStyle: {
							color: 'black',
							fontWeight: 'normal',
							fontSize: '12px',
						}
					},
					 plotOptions: {
							series: {
							stacking: 'normal',
							borderWidth:0
						}
					},
					credits: {
						 enabled: false
					},
					series: ySeries,
                    responsive: {
                        rules: [{
                            condition: {
                                maxWidth: 500
                            },
                            chartOptions: {
                                legend: {
                                    align: 'center',
                                    verticalAlign: 'bottom',
                                    layout: 'horizontal'
                                },
                                yAxis: {
                                    labels: {
                                        align: 'left',
                                        x: 0,
                                        y: -5
                                    },
                                    title: {
                                        text: null
                                    }
                                },
                                subtitle: {
                                    text: null
                                },
                                credits: {
                                    enabled: false
                                }
                            }
                        }]
                    }
				});
				return chart;
			},
			createIBOChart: function(xSeries,ySeries,id,state)
			{
				
				if(!state)
					state = null;
				Highcharts.setOptions({
			        global: {
			            useUTC: false,
			            
			        },
			        lang: {
			          decimalPoint: '.',
			          thousandsSep: ','
			        }
			    });
				chart= new Highcharts.Chart({
					chart: {
						  renderTo: id,
								type: 'bar',
								events: {
									click: function () {
										if(state!==null)
											$state.go(state);
									}
								}
						  },
					title: {
						text:''
					},
					xAxis: {
						categories: xSeries
					},
					yAxis: {
						min: 0,
						title: {
							text: '$K'
						}
					},
					tooltip: {
						pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>${point.y:,.0f}K</b> ({point.percentage:.2f}%)<br/>',
						shared: true
					},
					legend: {
						itemStyle: {
							color: 'black',
							fontWeight: 'normal',
							fontSize: '12px',
						}
					},
					 plotOptions: {
							series: {
							stacking: 'normal',
							borderWidth:0
						}
					},
					credits: {
						 enabled: false
					},
					series: ySeries,
                    responsive: {
                        rules: [{
                            condition: {
                                maxWidth: 500
                            },
                            chartOptions: {
                                legend: {
                                    align: 'center',
                                    verticalAlign: 'bottom',
                                    layout: 'horizontal'
                                },
                                yAxis: {
                                    labels: {
                                        align: 'left',
                                        x: 0,
                                        y: -5
                                    },
                                    title: {
                                        text: null
                                    }
                                },
                                subtitle: {
                                    text: null
                                },
                                credits: {
                                    enabled: false
                                }
                            }
                        }]
                    }
				});
				return chart;
			},
				exportChartTech : function(type){
					if(type === 'JPEG')
						{
						 chart.exportChart({type: 'image/jpeg', filename: 'Technology'}, {subtitle: {text:''}});
						}
						if(type === 'XLS'){
						chart.exportChart({type: 'application/vnd.ms-excel', filename: 'my-excel'}, {subtitle: {text:''}});
						}
						},
			createColumnChart: function(xSeries,ySeries,id,chartColors,state)
			{
				if(!state)
					state = null;
				Highcharts.setOptions({
			        global: {
			            useUTC: false,
			            
			        },
			        lang: {
			          decimalPoint: '.',
			          thousandsSep: ','
			        }
			    });
				chart= new Highcharts.Chart({
					chart: {
						  renderTo: id,
								type: 'column',
								events: {
									click: function () {
										if(state!==null)
											$state.go(state);
									}
								}
						  },
					title: {
						text:''
					},
					colors: chartColors, 
					xAxis: {
						categories: xSeries
					},
					yAxis: {
						min: 0,
						title: {
							text: '$K'
						}
					},
					tooltip: {
						pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>${point.y:,.0f}K</b>({point.percentage:.2f}%)<br/>',
						shared: true
					},
					legend: {
						itemStyle: {
							color: 'black',
							fontWeight: 'normal',
							fontSize: '12px',
						}
					},
					 plotOptions: {
							series: {
							stacking: 'normal',
							borderWidth:0
						}
					},
					credits: {
						 enabled: false
					},
					series: ySeries,
                    responsive: {
                        rules: [{
                            condition: {
                                maxWidth: 500
                            },
                            chartOptions: {
                                legend: {
                                    align: 'center',
                                    verticalAlign: 'bottom',
                                    layout: 'horizontal'
                                },
                                yAxis: {
                                    labels: {
                                        align: 'left',
                                        x: 0,
                                        y: -5
                                    },
                                    title: {
                                        text: null
                                    }
                                },
                                subtitle: {
                                    text: null
                                },
                                credits: {
                                    enabled: false
                                }
                            }
                        }]
                    }
				});
			},
			
			createIBOColumnChart: function(xSeries,ySeries,id,chartColors,state)
			{
				if(!state)
					state = null;
				Highcharts.setOptions({
			        global: {
			            useUTC: false,
			            
			        },
			        lang: {
			          decimalPoint: '.',
			          thousandsSep: ','
			        }
			    });
				chart= new Highcharts.Chart({
					chart: {
						  renderTo: id,
								type: 'column',
								events: {
									click: function () {
										if(state!==null)
											$state.go(state);
									}
								}
						  },
					title: {
						text:''
					},
					colors: chartColors, 
					xAxis: {
						categories: xSeries
					},
					yAxis: {
						min: 0,
						title: {
							text: '$K'
						}
					},
					tooltip: {
						pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>${point.y:,.0f}K</b>({point.percentage:.2f}%)<br/>',
						shared: true
					},
					legend: {
						itemStyle: {
							color: 'black',
							fontWeight: 'normal',
							fontSize: '12px',
						}
					},
					 plotOptions: {
							series: {
							stacking: 'normal',
							borderWidth:0
						}
					},
					credits: {
						 enabled: false
					},
					series: ySeries,
                    responsive: {
                        rules: [{
                            condition: {
                                maxWidth: 500
                            },
                            chartOptions: {
                                legend: {
                                    align: 'center',
                                    verticalAlign: 'bottom',
                                    layout: 'horizontal'
                                },
                                yAxis: {
                                    labels: {
                                        align: 'left',
                                        x: 0,
                                        y: -5
                                    },
                                    title: {
                                        text: null
                                    }
                                },
                                subtitle: {
                                    text: null
                                },
                                credits: {
                                    enabled: false
                                }
                            }
                        }]
                    }
				});
			},
				
				createOutageChart: function(xSeries,ySeries,id,state)
				{
					if(!state)
						state = null;
					Highcharts.setOptions({
				        global: {
				            useUTC: false,
				            
				        },
				        lang: {
				          decimalPoint: '.',
				          thousandsSep: ','
				        }
				    });
					chart= new Highcharts.Chart({
						chart: {
							  renderTo: id,
									type: 'bar',
									events: {
										click: function () {
											if(state!==null)
												$state.go(state);
										}
									}
							  },
						title: {
							text:''
						},
						xAxis: {
							categories: xSeries
						},
						yAxis: {
							min: 0,
							title: {
								text: 'Number of Outages'
							}
						},
						tooltip: {
							pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:,.0f}</b> ({point.percentage:.2f}%)<br/>',
							shared: true
						},
						legend: {
							itemStyle: {
								color: 'black',
								fontWeight: 'normal',
								fontSize: '12px',
							}
						},
						 plotOptions: {
								series: {
								stacking: 'normal',
								borderWidth:0
							}
						},
						credits: {
							 enabled: false
						},
						series: ySeries,
                        responsive: {
                            rules: [{
                                condition: {
                                    maxWidth: 500
                                },
                                chartOptions: {
                                    legend: {
                                        align: 'center',
                                        verticalAlign: 'bottom',
                                        layout: 'horizontal'
                                    },
                                    yAxis: {
                                        labels: {
                                            align: 'left',
                                            x: 0,
                                            y: -5
                                        },
                                        title: {
                                            text: null
                                        }
                                    },
                                    subtitle: {
                                        text: null
                                    },
                                    credits: {
                                        enabled: false
                                    }
                                }
                            }]
                        }
					});
					return chart;
				},			
				createOutageColumnChart: function(xSeries,ySeries,id,chartColors,state)
				{
					if(!state)
						state = null;
					Highcharts.setOptions({
				        global: {
				            useUTC: false,
				            
				        },
				        lang: {
				          decimalPoint: '.',
				          thousandsSep: ','
				        }
				    });
					chart= new Highcharts.Chart({
						chart: {
							  renderTo: id,
									type: 'column',
									events: {
										click: function () {
											if(state!==null)
												$state.go(state);
										}
									}
							  },
						title: {
							text:''
						},
						colors: chartColors, 
						xAxis: {
							categories: xSeries
						},
						yAxis: {
							min: 0,
							title: {
								text: 'Number of Outages'
							}
						},
						tooltip: {
							pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:,.0f}</b>({point.percentage:.2f}%)<br/>',
							shared: true
						},
						legend: {
							itemStyle: {
								color: 'black',
								fontWeight: 'normal',
								fontSize: '12px',
							}
						},
						 plotOptions: {
								series: {
								stacking: 'normal',
								borderWidth:0
							}
						},
						credits: {
							 enabled: false
						},
						series: ySeries,
                        responsive: {
                            rules: [{
                                condition: {
                                    maxWidth: 500
                                },
                                chartOptions: {
                                    legend: {
                                        align: 'center',
                                        verticalAlign: 'bottom',
                                        layout: 'horizontal'
                                    },
                                    yAxis: {
                                        labels: {
                                            align: 'left',
                                            x: 0,
                                            y: -5
                                        },
                                        title: {
                                            text: null
                                        }
                                    },
                                    subtitle: {
                                        text: null
                                    },
                                    credits: {
                                        enabled: false
                                    }
                                }
                            }]
                        }
					});
				},
				
				createServiceReqChart: function(xSeries,ySeries,id,chartColors,state)
				{
					if(!state)
						state = null;
					Highcharts.setOptions({
				        global: {
				            useUTC: false,
				            
				        },
				        lang: {
				          decimalPoint: '.',
				          thousandsSep: ','
				        }
				    });
					chart= new Highcharts.Chart({
						chart: {
							  renderTo: id,
									type: 'bar',
									events: {
										click: function () {
											if(state!==null)
												$state.go(state);
										}
									}
							  },
						title: {
							text:''
						},
						colors: chartColors, 
						xAxis: {
							categories: xSeries
						},
						yAxis: {
							min: 0,
							title: {
								text: 'Number of Service Request'
							}
						},
						tooltip: {
							pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:,.0f}</b> ({point.percentage:.2f}%)<br/>',
							shared: true
						},
						legend: {
							itemStyle: {
								color: 'black',
								fontWeight: 'normal',
								fontSize: '12px',
							}
						},
						 plotOptions: {
								series: {
								stacking: 'normal',
								borderWidth:0
							}
						},
						credits: {
							 enabled: false
						},
						series: ySeries,
                        responsive: {
                            rules: [{
                                condition: {
                                    maxWidth: 500
                                },
                                chartOptions: {
                                    legend: {
                                        align: 'center',
                                        verticalAlign: 'bottom',
                                        layout: 'horizontal'
                                    },
                                    yAxis: {
                                        labels: {
                                            align: 'left',
                                            x: 0,
                                            y: -5
                                        },
                                        title: {
                                            text: null
                                        }
                                    },
                                    subtitle: {
                                        text: null
                                    },
                                    credits: {
                                        enabled: false
                                    }
                                }
                            }]
                        }
					});
					return chart;
				},			
				
				createServiceReqColumnChart: function(xSeries,ySeries,id,chartColors,state)
				{
					if(!state)
						state = null;
					Highcharts.setOptions({
				        global: {
				            useUTC: false,
				            
				        },
				        lang: {
				          decimalPoint: '.',
				          thousandsSep: ','
				        }
				    });
					chart= new Highcharts.Chart({
						chart: {
							  renderTo: id,
									type: 'column',
									events: {
										click: function () {
											if(state!==null)
												$state.go(state);
										}
									}
							  },
						title: {
							text:''
						},
						colors: chartColors, 
						xAxis: {
                            labels: {
                                rotation: -45,
                                step: 1
                            },
							categories: xSeries
						},
						yAxis: {
							min: 0,
							title: {
								text: 'Number of Service Request'
							}
						},
						tooltip: {
							pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:,.0f}</b>({point.percentage:.2f}%)<br/>',
							shared: true
						},
						legend: {
							itemStyle: {
								color: 'black',
								fontWeight: 'normal',
								fontSize: '12px',
							}
						},
						 plotOptions: {
								series: {
								stacking: 'normal',
								borderWidth:0
							}
						},
						credits: {
							 enabled: false
						},
						series: ySeries,
                        responsive: {
                            rules: [{
                                condition: {
                                    maxWidth: 500
                                },
                                chartOptions: {
                                    legend: {
                                        align: 'center',
                                        verticalAlign: 'bottom',
                                        layout: 'horizontal'
                                    },
                                    yAxis: {
                                        labels: {
                                            align: 'left',
                                            x: 0,
                                            y: -5
                                        },
                                        title: {
                                            text: null
                                        }
                                    },
                                    subtitle: {
                                        text: null
                                    },
                                    credits: {
                                        enabled: false
                                    }
                                }
                            }]
                        }
					});
				}			
		}
		
    }]);
});
    