define(['angular', '../sample-module'], function(angular, module) {
    'use strict';
    module.factory('CustomerChartService', ['$q','$http','$state','URLService',function($q, $http,$state,URLService) {
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
        return {
			searchDataService: function(){
				var jsonData = [];
				var item = {};
				item["region"] = "";
				item["unitStatusDesc"]="InService";
				item["siteCustCountry"]= "";
				item["servRelationDescOng"]="";
				item["technology"]="";
				item["equipCode"]="";
				item["marketSegmentDesc"]="";
				item["customerName"]="";
				item["maintPolicyCode"]="";
				jsonData.push(item);
				return jsonData;
			},
			/* Network Call */
			getIBMetricsData: function(){
				var request = {
					'method': 'POST',
					'url': URLService.newMetrics.IBData,					
					};
				return networkCall(request);
			},
			getIBMetricsFilterData:function(jsonData){
				var request = {
					'method': 'POST',
					'data': {'data' : jsonData},
					'url':	URLService.newMetrics.IBData,						
					};
				return networkCall(request);
			},
        	getCustomerData: function(customerNameData){
				/* Top 10 Customers */
					var regionWithCustomerCount = customerNameData;	
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var colorCodes ={};	
					var customerCounts = {};					
					_.forEach(regionWithCustomerCount, function(tech){
						_.forEach(regionWithCustomerCount, function(customerCount){
						createNestedObject(customerCounts, [tech.technologyIB,customerCount.custName], 0);
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(tech){
						createNestedObject(customerCounts, [tech.technologyIB,tech.custName], (customerCounts[tech.technologyIB])[tech.custName]+parseInt(tech.techCountIB));
						totalCustomerCount = totalCustomerCount + parseInt(tech.techCountIB);
						colorCodes[tech.technologyIB] = tech.custColorCodeIB;
					});
					var chartData = [], chartObj = {}, colorIndex = 0, customers = [];
					_.forEach(Object.keys(customerCounts), function(data){
							chartObj ={};
							var keys = Object.keys(customerCounts[data]);
							var customerCountsObj = customerCounts[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							chartObj['color']= colorCodes[data];
							colorIndex++;
							_.forEach(keys, function(key){
									chartObj['data'].push(customerCountsObj[key]);
							});
							customers = keys;
							chartData.push(chartObj);
					});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			},
			
			topCustChart: function(custName,regionWithCustCount,id){
				Highcharts.setOptions({
			        global: {
			            useUTC: false,
			            
			        },
			        lang: {
			          decimalPoint: '.',
			          thousandsSep: ','
			        }
			    });
				return new Highcharts.Chart({
					chart: {
						  renderTo: id,
								type: 'bar',
								events: {
									click: function () {
										$state.go('ib/topCustomer');
									}
								}
						  },
					title: {
						text:''
					},
					xAxis: {
						categories: custName
					},
					yAxis: {
						min: 0,
						title: {
							text: 'Count'
						}
					},
					tooltip: {
						pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:,.0f}</b> ({point.percentage:.2f}%)<br/>',
						shared: true
					},
					legend: {
						itemStyle: {
							color: 'black',
							fontWeight: 'normal',
							fontSize: '12px',
						}
					},
					 plotOptions: {
							series: {
							stacking: 'normal',
							borderWidth:0
						}
					},
					credits: {
						 enabled: false
					},
					series: regionWithCustCount,
                    responsive: {
                        rules: [{
                            condition: {
                                maxWidth: 500
                            },
                            chartOptions: {
                                legend: {
                                    align: 'center',
                                    verticalAlign: 'bottom',
                                    layout: 'horizontal'
                                },
                                yAxis: {
                                    labels: {
                                        align: 'left',
                                        x: 0,
                                        y: -5
                                    },
                                    title: {
                                        text: null
                                    }
                                },
                                subtitle: {
                                    text: null
                                },
                                credits: {
                                    enabled: false
                                }
                            }
                        }]
                    }
				});
			}
        };
    }]);
});
