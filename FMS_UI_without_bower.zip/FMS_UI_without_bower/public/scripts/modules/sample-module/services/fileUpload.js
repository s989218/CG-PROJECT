
define(['angular', '../sample-module'], function(angular, module) {
    'use strict';
    module.factory('fileUpload', ['$q','$http','$state','$rootScope','$timeout',function($q, $http,$state,$rootScope,$timeout) {
		
 
    	return{		
    		uploadFileToUrl: function(file, uploadUrl){
               var filename = file.name;
               var index = filename.lastIndexOf(".");
               var strsubstring = filename.substring(index, filename.length);
               if (strsubstring === '.csv') {
		           var fd = new FormData();
		           fd.append('file', file);
		           fd.append('mappingParam', $rootScope.mappingParam);
				   fd.append('userSSO', $rootScope.userSSO);
		           $rootScope.uploadMessage = "";
		           
				   $.ajax({
					    url:uploadUrl,
					    data:fd,
					    cache:false,
					    processData:false,
					    contentType:false,
					    type:'POST',
					    success:function (data, status, req) {
				    	    if (req.responseText === "SUCCESS") {
					    		  $rootScope.safeApply(function(){
						        	   $timeout(function (){
						        		   $('.uploadMessage').addClass("successMsg");
							    		   $('.uploadMessage').removeClass("failureMsg");
						                   angular.element("input[type='file']").val(null);
						               },200);       
						               $rootScope.uploadStatus = "SUCCESS";
					              });
                            } else {
                        	  $rootScope.safeApply(function(){
	                        	  $timeout(function (){
	                        		   $('.uploadMessage').removeClass("successMsg");
				                	   $('.uploadMessage').addClass("failureMsg");
					                   angular.element("input[type='file']").val(null);
					              },200);
	                              $rootScope.uploadStatus = "FAILURE";
                        	  });
                            }
					    },
					    error:function (req, status, error) {
					    	$rootScope.safeApply(function(){
	                        	  $timeout(function (){
	                        		   $('.uploadMessage').removeClass("successMsg");
				                	   $('.uploadMessage').addClass("failureMsg");
					                   angular.element("input[type='file']").val(null);
					              },200);
	                              $rootScope.uploadStatus = "FAILURE";
                      	  	});
					    }
					});
               } else {
            	   $rootScope.safeApply(function(){
                 	  $timeout(function (){
                 		  $('.uploadMessage').removeClass("successMsg");
                 		  $('.uploadMessage').addClass("failureMsg");
			        	  $rootScope.uploadMessage = 'Please choose .csv file';
		              },200);
                      $rootScope.uploadStatus = "WARNING";
       	  		   });
               }
            }
    	}
    }]);
});
    