define(['angular', '../sample-module'], function(angular, module) {
    'use strict';
    module.factory('InstalledbaseService', ['$q','$http','URLService','NetworkCallService',
	function($q, $http,URLService,NetworkCallService) {
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
        return {
			/* Network Call */
        	getLatLongByRegion: function(jsonData){
				var request = {
					"dataType"    : "json",
                    "method"      : "POST",
                    "contentType" : "application/json",
                    "data"        : jsonData,
					'url'         : URLService.newMetrics.getLatLongByRegion
					};
				return networkCall(request);
			},

			getInstldBaseDropdownsData: function(jsonData){
                var request = {
                    "dataType"    : "json",
                    "method"      : "POST",
                    "contentType" : "application/json",
                    "data"        : jsonData,
                    'url'         : URLService.newMetrics.getInstldBaseDropdownsData,		
                };
                return networkCall(request);
			},
        }
    }]);
});
    