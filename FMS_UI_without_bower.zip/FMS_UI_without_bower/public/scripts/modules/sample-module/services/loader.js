define(['angular', '../sample-module'], function(angular, module) {
    'use strict';
    module.factory('LoaderService', ['$q','$http',function($q, $http) {
		return{
			loaderOps: function (state){
				if(state===true)
					$(".loading").show(function(){
						$('#topCustBody').addClass('lightBg');
					});
				else
					$(".loading").hide(function(){
						$('#topCustBody').removeClass('lightBg');
					});
			}
		}
    }]);
});
    