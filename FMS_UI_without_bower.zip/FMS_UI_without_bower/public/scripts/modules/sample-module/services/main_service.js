define([
	/* Services */
	'./customerChart',
	'./technoRegion',
	'./regionChart',
	'./techRegionChart',
	'./installedBase',
	'./chartService',
	'./newMetricTechService',
	'./topCustomer',
	'./IBOServices/IBOMetricsService',
	'./DMServices/DMMetricsService',
	'./loader',
	'./predix-asset-service', 
	'./predix-user-service', 
	'./predix-view-service',
	'./IBOServices/iboFiles',
	'./OrderServices/OrderFiles',
	'./DMServices/dmFiles',
	'./OutageServices/OutageFiles',
	'./serviceReqServices/ServiceReqFiles',
	'./NewMetricServices/newMetricsFiles',
	'./fileUpload',
	'./orderFileUpload',
	/* Metric Services */
	'./MetricServices/metricFiles',
	/* Network Services */
	'./NetworkServices/networkFiles',
    './IPMServices/IPMServices',
    './CombinedAnalysis/CombinedAnalysisFiles',
    /* Admin Services */
    './AdminServices/AdminDataService'
	], function() {

});
