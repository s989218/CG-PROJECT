define(['angular', '../sample-module'], function(angular, module) {
    'use strict';
    module.factory('NewMetricTechService', ['$q','$http','$state','URLService','NetworkCallService','$rootScope',
	function($q, $http,$state,URLService,NetworkCallService,$rootScope) {
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
				}).then(function (response) {
					deferred.resolve(response.data);
				}, function (status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
        return {
			searchDataService: function(){
				var jsonData = [];
				var item                    = {};
				item["region"]              = "";
                item["unitStatusDesc"]      = "InService";
				item["siteCustCountry"]     = "";
				item["servRelationDescOng"] = "";
				item["technology"]          = "";
				item["equipCode"]           = "";
                item["marketSegmentDesc"]   = "";
				item["customerName"]        = "";
				item["maintPolicyCode"]     = "";
				jsonData.push(item);
				return jsonData;
			},
			/* Network Call */
			getIBMetricsData: function(){
                 var request = {
                    "dataType"    : "json",
					"method"      : "POST",
                    "contentType" : "application/json",
					"data"        : jsonData,
					"url"         : URLService.newMetrics.IBData,
                };
				return networkCall(request);
			},
        	getCustomerData: function(customerNameData){
				    /* Top 10 Customers */
					var regionWithCustomerCount = _.first(_.sortBy(customerNameData, function(custData){
						return parseInt(custData.custNameCount)}).reverse(),10);
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var customerCounts = {}, colorCodes = {};					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						createNestedObject(customerCounts, [region.region,customerCount.custName], 0);
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
						createNestedObject(customerCounts, [region.region,region.custName], (customerCounts[region.region])[region.custName]+parseInt(region.custNameCount));
						totalCustomerCount = totalCustomerCount + parseInt(region.custNameCount);
						colorCodes[region.region] = region.regId -1;
					});
					var chartData = [], chartObj = {}, colorIndex = 0, customers = [];
					_.forEach(Object.keys(customerCounts), function(data){
							chartObj ={};
							var keys = Object.keys(customerCounts[data]);
							var customerCountsObj = customerCounts[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							chartObj['_colorIndex']=colorCodes[data];
							colorIndex++;
							_.forEach(keys, function(key){
									chartObj['data'].push(customerCountsObj[key]);
							});
							customers = keys;
							chartData.push(chartObj);
					});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			},
			technoRegChart: function(technology,regionWithCount,id,chartColors)
			{
				Highcharts.setOptions({
			        global: {
			            useUTC: false,
			            
			        },
			        lang: {
			          decimalPoint: '.',
			          thousandsSep: ','
			        }
			    });
			   return new Highcharts.Chart({
						chart: {
							  renderTo: id,
									type: 'column',
								events: {
								click: function () {
									$state.go('ib/TechnoRegion');
								}
							}
						},
						title: {
							text:''
						},
						xAxis: {
							categories: technology
						},
						yAxis: {
							min: 0,
							title: {
								text: 'Count'
							}
						},
						colors: chartColors, 
						tooltip: {
							pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:,.0f}</b> ({point.percentage:.2f}%)<br/>',
							shared: true
						},
						legend: {
							itemStyle: {
								color: 'black',
								fontWeight: 'normal',
								fontSize: '12px'
							}
						},
						plotOptions: {
							column: {
								stacking: 'count',
								borderWidth:0
							}
						},
						credits: {
							 enabled: false
						},
						series: regionWithCount,
                        responsive: {
                            rules: [{
                                condition: {
                                    maxWidth: 500
                                },
                                chartOptions: {
                                    legend: {
                                        align: 'center',
                                        verticalAlign: 'bottom',
                                        layout: 'horizontal'
                                    },
                                    yAxis: {
                                        labels: {
                                            align: 'left',
                                            x: 0,
                                            y: -5
                                        },
                                        title: {
                                            text: null
                                        }
                                    },
                                    subtitle: {
                                        text: null
                                    },
                                    credits: {
                                        enabled: false
                                    }
                                }
                            }]
                        }
					});
			}
        };
    }]);
});
