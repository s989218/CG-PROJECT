define(['angular', '../sample-module'], function(angular, module) {
    'use strict';
    module.factory('RegionChartService', ['$q','$http','$state','URLService',function($q, $http,$state,URLService) {
		var chart;
    	var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: {'data' : request.data},
					url: request.url,
					headers: request.headers,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
        return {
			/* Network Call */
			getIBMetricsDropdownsData: function(){
				var request = {
					'method': 'GET',
					'url': URLService.newMetrics.IBDropdown,						
					};
				return networkCall(request);
			},
			getRegionWithCount(techRegionData){
						var region = [];
						var technology = [];
						var technologyCount = [];
						var regionWithCount = [];
						var totalcount = 0,i;
						for(i=0;i<techRegionData.length;i++)
						{		
								if(region.indexOf(techRegionData[i].mTechRegion)=== -1)
								{	
									region.push(techRegionData[i].mTechRegion);
								}
								if(technology.indexOf(techRegionData[i].mTechTechnology)=== -1)
								{	
									technology.push(techRegionData[i].mTechTechnology);
								}
						}
						for(i=0;i<region.length;i++) 
						{	 
							for(var j=0;j<technology.length;j++)
							{
							
								for(var k=0;k<techRegionData.length;k++)
								{
									if(region[i] === techRegionData[k].mTechRegion && technology[j] === techRegionData[k].mTechTechnology) {
										var temp = Number(techRegionData[k].mTechTechnologyCount); 
										totalcount=totalcount+temp;
										technologyCount.push(temp);
									}
								}

							}
							var obj = {'name':region[i],'data':technologyCount};
							regionWithCount.push(obj);
							technologyCount = [];
						}
						return regionWithCount;
			},
        	getTechnologyData: function(technologyDropdown,regionDropdown,regionWithCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var testData = {}, countryCount = {}, totalCount = {}, technology= [], techTotal = {},technologiesList = [];
					_.forEach(regionWithCount, function(reg){
						_.forEach(regionDropdown, function(tech){
						createNestedObject(testData, [reg.name,tech.mTechTechnology], -1);
						createNestedObject(testData, [reg.name,'~Total'], 0);
						createNestedObject(techTotal, [reg.name], 0);
						createNestedObject(totalCount, [tech.mTechTechnology , 'Total'] , 0);
						createNestedObject(countryCount, [tech.mTechTechnology , reg.name] , 0);
					});
					});
					var colorCodes = [];
					totalCount['gTotal'] = 0;
					_.forEach(regionDropdown, function(respData){						
						var tempObject = {};
						tempObject[respData.mTechTechnology]= respData.mTechTechnologyCount ;
						createNestedObject(testData, [respData.mTechRegion, respData.mTechTechnology ] , parseInt(respData.mTechTechnologyCount));
						createNestedObject(countryCount, [respData.mTechTechnology , respData.mTechRegion] , parseInt(respData.mTechTechnologyCount));
						createNestedObject(totalCount, [respData.mTechTechnology , 'Total'] , (totalCount[respData.mTechTechnology])['Total']+parseInt(respData.mTechTechnologyCount));
						createNestedObject(testData, [respData.mTechRegion,'~Total'] , (testData[respData.mTechRegion])['~Total']+parseInt(respData.mTechTechnologyCount));
						createNestedObject(techTotal, [respData.mTechRegion] , (techTotal[respData.mTechRegion])+parseInt(respData.mTechTechnologyCount));
						totalCount['gTotal']+=parseInt(respData.mTechTechnologyCount);
						/*Color Indexes As Per ID*/
						if(technologiesList.indexOf(respData.mTechTechnology) === -1){
							technologiesList.push(respData.mTechTechnology);
							colorCodes.push(respData.colorCode);							
						}	
						});
					techTotal = _.sortBy(_.pairs(techTotal), function (item) { return item[1]; });
					/* Descending Sort */
					techTotal = techTotal.reverse();
					var rankArray = [];
					_.forEach(techTotal, function(tech){
						rankArray.push(tech[0]);
					});
					_.forEach(testData, function(data){
							testData['regions'] = [];
							/* Sort Alphabetically */
							testData['regions'] = _.sortBy(Object.keys(data), function(o) { return o; });	
						return false;
					});

					var chartData = [], chartObj = {};
					_.forEach(Object.keys(countryCount), function(data){
							chartObj ={};
							var countryCountObj = countryCount[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							/*Color Indexes As Per ID*/
							_.forEach(rankArray, function(key){
									chartObj['data'].push(countryCountObj[key]);
							});
							chartData.push(chartObj);
							technology = rankArray;
					});
					var returnObj = {};
					returnObj['testData'] = testData;
					returnObj['countryCount'] = countryCount;
					returnObj['chartData'] = chartData;
					returnObj['totalCount'] = totalCount;
					returnObj['technology'] = technology;
					returnObj['colorCode'] = colorCodes;
					return returnObj;
			},
			technoFilterRegChart: function(technology,chartData,id,chartColors)
			{
				Highcharts.setOptions({
			        global: {
			            useUTC: false,
			            
			        },
			        lang: {
			          decimalPoint: '.',
			          thousandsSep: ','
			        }
			    });
				chart=new Highcharts.Chart({
						chart: {
							renderTo: id,
							type: 'column'
						},
						title: {
							text:''
						},
						colors: chartColors,
						xAxis: {
							categories: technology
						},
						yAxis: {
							min: 0,
							title: {
								text: 'Count'
							}
						},
						tooltip: {
							pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:,.0f}</b> ({point.percentage:.2f}%)<br/>',
							shared: true
						},
						legend: {
							itemStyle: {
								color: 'black',
								fontWeight: 'normal',
								fontSize: '12px'
							}
						},
						plotOptions: {
							column: {
								stacking: 'count',
								borderWidth:0
							}
						},
						credits: {
							 enabled: false
						},
						series: chartData
					});
				return chart;
			}

        };
    }]);
});
