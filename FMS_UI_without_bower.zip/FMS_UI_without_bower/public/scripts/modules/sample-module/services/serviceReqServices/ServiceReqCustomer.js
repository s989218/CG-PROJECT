define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('ServiceReqCustomerService', ['$q','$http','$state','URLService',function($q, $http,$state,URLService) {
		var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
		var dataProcessing = function(regionWithCustomerCount){
					var customerCounts = {}, colorCodes =[];
					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.technology!==null){
							createNestedObject(customerCounts, [region.technology,customerCount.customer_name], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
						if(region.technology!==null){
							createNestedObject(customerCounts, [region.technology,region.customer_name], (customerCounts[region.technology])[region.customer_name]+parseInt(region.technologyopenedcases));
								totalCustomerCount = totalCustomerCount + parseInt(region.technologyopenedcases);
								colorCodes[region.technology] = region.color_code;
							}
						});
						var chartData = [], chartObj = {}, customers = [];
						_.forEach(Object.keys(customerCounts), function(data){
								chartObj ={};
								var keys = Object.keys(customerCounts[data]);
								var customerCountsObj = customerCounts[data];
								chartObj['data'] = [];
								chartObj['name'] = data;
								chartObj['color']=colorCodes[data];
								_.forEach(keys, function(key){
										chartObj['data'].push(customerCountsObj[key]);
								});
								customers = keys;
								chartData.push(chartObj);
						});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			};
			var processCountryTable = function(customerData){
				var dataObj = {};
				var customers=[], regions=[], tableData = {}, columns = [];
				columns = [{'title':'Customer'}];
				_.forEach(customerData, function(obj){
					if(customers.indexOf(obj.geDunsName)=== -1){
						customers.push(obj.geDunsName);
					}
					if(regions.indexOf(obj.iBCustRegion)=== -1 && obj.iBCustRegion!==null){
						var colObj = {'title':obj.iBCustRegion};
						columns.push(colObj);
						regions.push(obj.iBCustRegion);
					}
				});
				var dataArr = [[]], totalCount = {}, regionCount={};
				_.forEach(customers, function(customer){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [customer, region], 0);
						createNestedObject(totalCount, [customer], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[customers.indexOf(customer)] = [];
						(dataArr[customers.indexOf(customer)])[0] = customer;
						for(var index=1; index<=regions.length; index++)
							(dataArr[customers.indexOf(customer)])[index] = 0;
					}
					});
				});
				var total = 0;
				_.forEach(customerData, function(obj){
				if(obj.iBCustRegion!==null){
					createNestedObject(tableData, [obj.geDunsName, obj.iBCustRegion], obj.iBCustAvtotSum);
					(dataArr[customers.indexOf(obj.geDunsName)])[regions.indexOf(obj.iBCustRegion)+1] = parseInt(obj.iBCustAvtotSum);
					createNestedObject(regionCount, [obj.iBCustRegion], regionCount[obj.iBCustRegion]+parseInt(obj.iBCustAvtotSum));
					total = total + parseInt(obj.iBCustAvtotSum);
					totalCount[obj.geDunsName]=totalCount[obj.geDunsName]+parseInt(obj.iBCustAvtotSum);
				}
				});
				columns.push({'title':'Grand Total'});
				regionCount['Grand Total']=total;
				_.forEach(customers, function(customer){					
					(dataArr[customers.indexOf(customer)])[(dataArr[customers.indexOf(customer)]).length] = totalCount[customer];
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
        return {
			/* Network Call */
			getIBMetricsData: function(){
				var request = {
					'method': 'POST',
					'url': URLService.newMetrics.IBData,						
					};
				return networkCall(request);
			},
        	getCustomerData: function(customerNameData){
				/* Top 10 Customers */
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var colorCodes =[];	
					var customerCounts = {};					
					_.forEach(customerNameData, function(region){ 
						_.forEach(customerNameData, function(customerCount){
						createNestedObject(customerCounts, [region.technology,customerCount.customer_name], 0);
						});
					});
					var totalCustomerCount = 0;
					_.forEach(customerNameData, function(region){
						createNestedObject(customerCounts, [region.technology,region.customer_name], (customerCounts[region.technology])[region.customer_name]+parseInt(region.technologyopenedcases));
						totalCustomerCount = totalCustomerCount + parseInt(region.technologyopenedcases);
							colorCodes[region.technology] = region.color_code;
					});
					var chartData = [], chartObj = {}, colorIndex = 0, customers = [];
					_.forEach(Object.keys(customerCounts), function(data){
							chartObj ={};
							var keys = Object.keys(customerCounts[data]);
							var customerCountsObj = customerCounts[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							chartObj['color']= colorCodes[data];
							colorIndex++;
							_.forEach(keys, function(key){
									chartObj['data'].push(customerCountsObj[key]);
							});
							customers = keys;
							chartData.push(chartObj);
					});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			},
			processCustomerData: function(customerData){
					return dataProcessing(customerData);
			},
			processAllCustomerData: function(customerData){
					return dataProcessing(customerData);
			},
			customerCountryTableData: function(customerData){
				return processCountryTable(customerData);
			}
        };
    }]);
});
