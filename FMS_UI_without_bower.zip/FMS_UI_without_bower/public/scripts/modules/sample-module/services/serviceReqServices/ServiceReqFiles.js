define([
	'./ServiceReqChart',
	'./ServiceReqCustomer',
	'./ServiceReqTable',
	'./ServiceReqMetricsService',
	'./ServiceReqTechRegion'
	], function() {

});
