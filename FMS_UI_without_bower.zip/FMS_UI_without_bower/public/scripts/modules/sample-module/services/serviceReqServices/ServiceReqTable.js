define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('ServiceReqTableService', ['$q','$http','$state','URLService',function($q, $http,$state,URLService) {
		var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
		var countryDataProcess = function(regionWithCustomerCount){
					var customerCounts = {}, colorCodes ={};
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.ocCountry!=null){
							createNestedObject(customerCounts, [region.ocCountry,customerCount.ocCustomerName], 0);
						}
						});
					});
					var totalCustomerCount = 0, count =0;
					_.forEach(regionWithCustomerCount, function(region){
						if(region.ocCountry!=null){
							createNestedObject(customerCounts, [region.ocCountry,region.ocCustomerName], (customerCounts[region.ocCountry])[region.ocCustomerName]+parseInt(region.ocOutages));
								totalCustomerCount = totalCustomerCount + parseInt(region.ocOutages);
								if(!colorCodes[region.ocCountry])
								{
									colorCodes[region.ocCountry] = count;
									count++;
								}
						}
						});
						var chartData = [], chartObj = {}, customers = [];
						_.forEach(Object.keys(customerCounts), function(data){
								chartObj ={};
								var keys = Object.keys(customerCounts[data]);
								var customerCountsObj = customerCounts[data];
								chartObj['data'] = [];
								chartObj['name'] = data;
								_.forEach(keys, function(key){
										chartObj['data'].push(customerCountsObj[key]);
								});
								customers = keys;
								chartData.push(chartObj);
						});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			};
		var dataProcessing = function(regionWithCustomerCount){
					var customerCounts = {}, colorCodes ={};
					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.region!==null){
							createNestedObject(customerCounts, [region.ocRegion,customerCount.ocCustomerName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
						if(region.region!==null){
							createNestedObject(customerCounts, [region.ocRegion,region.ocCustomerName], (customerCounts[region.ocRegion])[region.ocCustomerName]+parseInt(region.ocOutages));
								totalCustomerCount = totalCustomerCount + parseInt(region.ocOutages);
								colorCodes[region.ocRegId] = region.ocRegId - 1;
							}
						});
						var chartData = [], chartObj = {}, customers = [];
						_.forEach(Object.keys(customerCounts), function(data){
								chartObj ={};
								var keys = Object.keys(customerCounts[data]);
								var customerCountsObj = customerCounts[data];
								chartObj['data'] = [];
								chartObj['name'] = data;
								chartObj['_colorIndex']=colorCodes[data];
								_.forEach(keys, function(key){
										chartObj['data'].push(customerCountsObj[key]);
								});
								customers = keys;
								chartData.push(chartObj);
						});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			};
			//service Req top customer country Level
			var processCountryTable = function(customerData){
				var dataObj = {};
				var customers=[], regions=[], tableData = {}, columns = [];
				columns = [{'title':'Customer'}];
				_.forEach(customerData, function(obj){
					if(customers.indexOf(obj.ocCustomerName)=== -1){
						customers.push(obj.ocCustomerName);
					}
					if(regions.indexOf(obj.ocCountry)=== -1 && obj.ocCountry!==null){
						var colObj = {'title':obj.ocCountry};
						columns.push(colObj);
						regions.push(obj.ocCountry);
					}
				});
				var dataArr = [[]], totalCount = {}, regionCount={};
				_.forEach(customers, function(customer){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [customer, region], 0);
						createNestedObject(totalCount, [customer], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[customers.indexOf(customer)] = [];
						(dataArr[customers.indexOf(customer)])[0] = customer;
						for(var index=1; index<=regions.length; index++)
							(dataArr[customers.indexOf(customer)])[index] = 0;
					}
					});
				});
				var total = 0;
				_.forEach(customerData, function(obj){
				if(obj.country!==null){
					createNestedObject(tableData, [obj.ocCustomerName, obj.ocCountry], obj.ocOutages);
					var dmCustAvtotSumNum = parseInt(obj.ocOutages);
					(dataArr[customers.indexOf(obj.ocCustomerName)])[regions.indexOf(obj.ocCountry)+1] = numberWithCommas(dmCustAvtotSumNum);
					createNestedObject(regionCount, [obj.ocCountry], regionCount[obj.ocCountry]+parseInt(obj.ocOutages));
					total = total + parseInt(obj.ocOutages);
					totalCount[obj.ocCustomerName]=totalCount[obj.ocCustomerName]+parseInt(obj.ocOutages);
				}
				});
				columns.push({'title':'Grand Total'});
				regionCount['Grand Total']=total;
				_.forEach(customers, function(customer){					
					(dataArr[customers.indexOf(customer)])[(dataArr[customers.indexOf(customer)]).length] = numberWithCommas(totalCount[customer]);
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
			//Service Req top customer Region Level
			var processTable = function(customerData){
				var dataObj = {},custStates = [];
				var customers=[], technology=[], tableData = {}, columns = [],states = [];
				columns = [{'title':'Customer'}];
				columns.push({'title':'State'});
				_.forEach(customerData, function(obj){
					if(customers.indexOf(obj.customer_name)=== -1 || states.indexOf(obj.state)=== -1){
						customers.push(obj.customer_name);
						states.push(obj.state);
						custStates.push(obj.customer_name+obj.state);
					}
					if(technology.indexOf(obj.technology)=== -1 && obj.technology!==null){					
						var colObj = {'title':obj.technology};
						columns.push(colObj);
						technology.push(obj.technology);
					}
				});
				var dataArr = [[]], totalCount ={}, regionCount={},i=0,j=0;
				_.forEach(customers, function(customer){
					_.forEach(technology, function(tech){
						if(tech!==null){
							createNestedObject(tableData, [customers[i], technology[j]], 0);
							createNestedObject(totalCount, [customers[i]+states[i]], 0);
							createNestedObject(regionCount, [tech], 0);
							dataArr[i] = [];
							(dataArr[i])[0] = customers[i];
							(dataArr[i])[1] = states[i];
							for(var index=1; index<=technology.length; index++)
								(dataArr[i])[index+1] = 0;
						}
						j++
					});
					i++
				});
				var total = 0,p;
				_.forEach(customerData, function(obj){
					if(obj.technology!==null){
						createNestedObject(tableData, [obj.customer_name, obj.technology], obj.technologyopenedcases);
						createNestedObject(regionCount, [obj.technology], regionCount[obj.technology]+parseInt(obj.technologyopenedcases));
						var dmCustAvtotSumNum=parseInt(obj.technologyopenedcases);
						if( custStates[custStates.indexOf(obj.customer_name+obj.state)] === obj.customer_name+obj.state){
							p = custStates.indexOf(obj.customer_name+obj.state);
							(dataArr[p])[technology.indexOf(obj.technology)+2] = numberWithCommas(dmCustAvtotSumNum);
							totalCount[obj.customer_name+obj.state]=totalCount[obj.customer_name+obj.state]+parseInt(obj.technologyopenedcases);
							total = total +parseInt(obj.technologyopenedcases);
						}
					}
				});
				columns.push({'title':'Grand Total'});
				regionCount['Grand Total']=total;
				_.forEach(custStates, function(custState){					
					(dataArr[custStates.indexOf(custState)])[(dataArr[custStates.indexOf(custState)]).length] = numberWithCommas(totalCount[custState]);
				});
				tableData['regions'] = _.sortBy(technology,function(tech){return tech});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['regionCount'] = regionCount;
				dataObj['columns'] = columns;
				return dataObj;
			};
        return {
			initTable(data,columns,id) { 
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
				if ($.fn.DataTable.isDataTable( '#'+id )) {
						$('#'+id).dataTable().fnDestroy();        
						$('#'+id).empty(); 
						 $('#'+id).append('<tfoot></tfoot>');
					}  
				dt = $('#'+id).DataTable({
					"columnDefs": [
									{
									"render": function ( data1, type, row ) {
										
											data=data1;
											return data;
										
										
									},
								         targets: '_all'
									}
									],
				   "order": [[ columns.length-1, "desc"]],
				   columns : columns,
                   data: data,
				   fnDrawCallback : function() {
					if(footer && data[0].length>0){
					   $('#'+id+ ' > tfoot').html('');
					   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					   $('#'+id+ ' > tfoot').append('<th> </th>');
					   _.forEach(columns, function(column){                          
							if(footer[column.title] !== undefined){
								$('#'+id+ ' > tfoot').append('<th>'+numberWithCommas(footer[column.title])+'</th>');
							}
					   });
					}
					}
				});
				
				return dt;	
			},
			
			
			initTechTable(data,columns,id) { 
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
				if ($.fn.DataTable.isDataTable( '#'+id )) {
						$('#'+id).dataTable().fnDestroy();        
						$('#'+id).empty(); 
						 $('#'+id).append('<tfoot></tfoot>');
					}  
				dt = $('#'+id).DataTable({
					"columnDefs": [
									{
									"render": function ( data1, type, row ) {
										
											data=data1;
											return data;
										
										
									},
								         targets: '_all'
									}
									],
				   "order": [[ columns.length-1, "desc"]],
				   columns : columns,
                   data: data,
				   fnDrawCallback : function() {
					if(footer && data[0].length>0){
					   $('#'+id+ ' > tfoot').html('');
					   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					   _.forEach(columns, function(column){                          
							if(footer[column.title] !== undefined){
								$('#'+id+ ' > tfoot').append('<th>'+numberWithCommas(footer[column.title])+'</th>');
							}
					   });
					}
					}
				});
				return dt;	
			},
			processAllCustomerData: function(customerData){
					var regionWithCustomerCount = _.sortBy(customerData, function(custData){
						return parseInt(custData.openedcases)}).reverse();
					return dataProcessing(regionWithCustomerCount);
			},
			customerTableData: function(customerData){
				return processTable(customerData);
			},
			excelDownload: function(id){
				var footer = document.getElementById(id).tFoot.innerText;
				footer=footer.split(/(\s+)/).filter( function(e) { return e.trim().length > 0; } );
			    var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 	});
				 var tableToExcel = (function() {
					 var ctx,subHeader;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
	                      if (!table.nodeType) 
	                             table = document.getElementById(id);
	                      var excelContent = '';
	                      var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                     
	                      if(id ==='ServiceReq-by-Top-Cust-Data')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>Service Request Customer Level</span>"+
	                          "</td></tr>";
                    	  }
	                      
	                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                      excelContent = excelContent + subHeader;
	                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
	                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                      var td = "<td style='width: auto; padding-right:5px; background-color:#111;color:white'>";
	                      var tdNumber = "<td style='mso-number-format:0'>";
	                      excelContent =excelContent + '<tr>';
	                      _.forEach(columns, function(column){
	                                    excelContent = excelContent + th + column + '</th>';
	                      });
	                      excelContent = excelContent + '</tr>';
	                      _.forEach(getDataFromDT, function(row){
	                             excelContent =excelContent + '<tr>';
	                             _.forEach(row, function(rowData){
	                            	 
	                                    if((/^[0-9]{0,}$/).test(rowData))
	                                           excelContent = excelContent + tdNumber + rowData + '</td>';
	                                    else
	                                           excelContent = excelContent + '<td>' + rowData + '</td>';
	                            	 
	                            	
	                             });
	                             excelContent =excelContent + '</tr>';
	                      });
	                      excelContent =excelContent + '<tr>'; 
	                      if(columns[1]==="State"){
								_.forEach(footer, function(row){
									if(row === 'Total'){
										excelContent = excelContent + td+ row + '</td>'+td + '&nbsp'+ '</td>'
									}else{
										excelContent = excelContent + td+ row + '</td>';
									}
								});
							 }else{
								 _.forEach(footer, function(row){
										excelContent = excelContent + td+ row + '</td>';
									});
							 }
	                      excelContent =excelContent + '</tr>';
	                      if(id ==='ServiceReq-by-Top-Cust-Data'){
	                    	  ctx = {worksheet: 'Technology Data' , table: excelContent};
		                      document.getElementById('servicereqTechnoRegion').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('servicereqTechnoRegion').download = 'ServiceRequests.xls';
	                      }
	                }
	                })();
	                tableToExcel(id);
				return null;
			},
			customerCountryTableData: function(customerData){
				return processCountryTable(customerData);
			},
			topCustomerTableData: function(customerData){
				return processTable(customerData);
			},
			countryDataProcessing: function(customerData){
				var regionWithCustomerCount = _.sortBy(customerData, function(custData){
						return parseInt(custData.openedcases)}).reverse();
				return countryDataProcess(regionWithCustomerCount);
			}
        };
    }]);
});
