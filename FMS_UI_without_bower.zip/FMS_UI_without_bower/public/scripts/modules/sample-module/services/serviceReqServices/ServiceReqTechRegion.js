define(['angular', '../../sample-module'], function(angular, module) {
    'use strict';
    module.factory('ServiceReqTechnoRegionService', ['$q','$http','$state','URLService',function($q, $http,$state,URLService) {
    	var regionDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, colorCodes ={}, totalCounts = {}, regions = [], regionData ={};
					_.forEach(regionWithTechCount, function(region){
						if(region.technology!==null){
							regionData[region.technology] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.technology!==null){
							if(regions.indexOf(region.technology)===-1)
								regions.push(region.technology);
							createNestedObject(technologyCounts, [region.technology,techCount.state], 0);
							createNestedObject(totalCounts, [techCount.state], 0);
						}
						});
					});
					var totalCount = 0, count;
					_.forEach(regionWithTechCount, function(region){
						createNestedObject(technologyCounts, [region.technology,region.state], (technologyCounts[region.technology])[region.state]+parseInt(region.openedcases));
						totalCounts[region.state]=totalCounts[region.state]+parseInt(region.openedcases);
						totalCount = totalCount + parseInt(region.openedcases);
						colorCodes[region.technology] = region.color_code;
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							});
						});
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=
									parseInt((technologyCounts[region])[technology]); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region, '_colorIndex':colorCodes[region]});
						});
					var returnObj = {};
					returnObj['totalCount'] = totalCount;
					returnObj['technologies'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					return returnObj;
			};
			var countryDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, colorCodes =[], totalCounts = {}, regions = [], regionData ={}, testData = {},totalCount = {};
					_.forEach(regionWithTechCount, function(region){
						if(region.technology!==null){
							regionData[region.technology] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.technology!==null){
							if(regions.indexOf(region.technology)===-1){
								regions.push(region.technology);
								colorCodes.push(region.color_code);
							}								
							createNestedObject(technologyCounts, [region.technology,techCount.state], 0);
							createNestedObject(testData, [techCount.state,region.technology], -1);
							createNestedObject(testData, [techCount.state, '~Total'], 0);
							createNestedObject(totalCounts, [techCount.state], 0);
							createNestedObject(totalCount, [region.technology , 'Total'] , 0);
						}
						});
					});
					
					totalCount['gTotal'] = 0;
					_.forEach(regionWithTechCount, function(region){
					
						if(region.otCountry!==null){
							createNestedObject(technologyCounts, [region.technology,region.state], (technologyCounts[region.technology])[region.state]+parseInt(region.openedcases));
							createNestedObject(testData, [region.state, region.technology ] , parseInt(region.openedcases));
							createNestedObject(testData, [region.state,'~Total'] , (testData[region.state])['~Total']+parseInt(region.openedcases));
							createNestedObject(totalCount, [region.technology , 'Total'] , (totalCount[region.technology])['Total']+parseInt(region.openedcases));
							totalCounts[region.state]=totalCounts[region.state]+parseInt(region.openedcases);
							
							totalCount['gTotal']+=parseInt(region.openedcases);
						}
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							var count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							}); 
						});
						var highchartData = [];
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=parseInt((technologyCounts[region])[technology]); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region});
							highchartData.push({'data': regionData[region], 'name':region});
						});
						_.forEach(testData, function(data){
								testData['regions'] = [];
								/* Sort Alphabetically */
								testData['regions'] = _.sortBy(Object.keys(data), function(o) { return o; });	
							return false;
						});
					var returnObj = {};
					returnObj['technology'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					returnObj['highchartData'] = highchartData;
					returnObj['testData'] = testData;
					returnObj['totalCount'] = totalCount;
					returnObj['colorCode'] = colorCodes;
					
					return returnObj;
					
			};
			//IBO technology & region country level Table
			var processCountryTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Service Requests'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.technology)=== -1){
						technologies.push(obj.technology);
					}
					if(regions.indexOf(obj.state)=== -1 && obj.state !==null){
						var colObj = {'title':obj.state};
						columns.push(colObj);
						regions.push(obj.state);
					}
				});
				var dataArr = [[]], totalCount={}, regionCount= {};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
						if(!(region===null)){
							createNestedObject(tableData, [technology, region], 0);
							createNestedObject(totalCount, [technology], 0);
							createNestedObject(regionCount, [region], 0);
							dataArr[technologies.indexOf(technology)] = [];
							(dataArr[technologies.indexOf(technology)])[0] = technology;
							for(var index=1; index<=regions.length; index++)
								(dataArr[technologies.indexOf(technology)])[index] = 0;
						}
					});					
				});		
				regionCount['Grand Total']=0;
				_.forEach(technologyData, function(obj){
					if(!(obj.country===null)){
						createNestedObject(tableData, [obj.technology, obj.state], obj.openedcases);
						var dmTechAvtotSumNum =parseInt(obj.openedcases);
						(dataArr[technologies.indexOf(obj.technology)])[regions.indexOf(obj.state)+1] = numberWithCommas(dmTechAvtotSumNum);
						totalCount[obj.technology]=totalCount[obj.technology]+parseInt(obj.openedcases);
						regionCount[obj.state]=regionCount[obj.state]+parseInt(obj.openedcases);
						regionCount['Grand Total'] = regionCount['Grand Total'] +parseInt(obj.openedcases);
					}
				});
              
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){					
					(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = numberWithCommas(totalCount[technology]);
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['regionCount'] = regionCount;
				dataObj['columns'] = columns;
				return dataObj;
			};
			//outage technology & region Region level Table
			var processTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Service Requests'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.state)=== -1){
						technologies.push(obj.state);
					}
					if(regions.indexOf(obj.technology)=== -1 && obj.technology!==null){
						var colObj = {'title':obj.technology};
						columns.push(colObj);
						regions.push(obj.technology);
					}
				});

				var dataArr = [[]], totalCount={}, regionCount={};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [technology, region], 0);
						createNestedObject(totalCount, [technology], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[technologies.indexOf(technology)] = [];
						(dataArr[technologies.indexOf(technology)])[0] = technology;
						for(var index=1; index<=regions.length; index++)
							(dataArr[technologies.indexOf(technology)])[index] = 0;
					}
					});					
				});
				regionCount['Grand Total']=0;
				_.forEach(technologyData, function(obj){
				if(obj.region!==null){
					createNestedObject(tableData, [obj.state, obj.technology], obj.openedcases);
					var dmTechAvtotSumNum =parseInt(obj.openedcases);
					(dataArr[technologies.indexOf(obj.state)])[regions.indexOf(obj.technology)+1] = numberWithCommas(dmTechAvtotSumNum);
					totalCount[obj.state]=totalCount[obj.state]+parseInt(obj.openedcases);
					regionCount[obj.technology]=regionCount[obj.technology]+parseInt(obj.openedcases);
					regionCount['Grand Total'] = regionCount['Grand Total'] +parseInt(obj.openedcases);
				}
				});
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){
					(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = numberWithCommas(totalCount[technology]);
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
        return {
			searchDataService: function(){
				var jsonData = [];
				var item = {};
				item["case_number"] ="";
				item["opened"]="";
				item["current_type_of_issue"]="";						
				item["project_phase"]="";
				item["state"]="";				
				item["assigned_group"]="";
				item["status"]="";						
				item["entry_in_the_cur_status"]="";
				item["job_type"]="";						
				item["customer_name"]="";
				item["machine_technology_og"]="";
				item["event_year"]="";
				item["event_quarter"]="";
				jsonData.push(item);
				return jsonData;
			},
			getRegionWithCount: function(techRegionData){	
					return regionDataProcess(techRegionData)['chartData']
			},
			processedData: function(techRegionData){	
					return regionDataProcess(techRegionData);
			},
			countryDataProcess: function(techRegionData){	
					return countryDataProcess(techRegionData);
			},
			processTable: function(technologyData){
				return processTable(technologyData);
			},
			processCountryTable: function(technologyData){
				return processCountryTable(technologyData);
			},
			initTable(data,columns,id) { 
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
				if ($.fn.DataTable.isDataTable( '#'+id )) {
						$('#'+id).dataTable().fnDestroy();        
						$('#'+id).empty(); 
						 $('#'+id).append('<tfoot></tfoot>');
					}  
				dt = $('#'+id).DataTable({
				   "order": [[ columns.length-1, "desc" ]],
				   columns : columns,
                   data: data,
				   "pageLength": 10,
				   fnDrawCallback : function() {
					if(footer && data[0].length>0){
					   $('#'+id+ ' > tfoot').html('');
					   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					   _.forEach(columns, function(column){
							if(footer[column.title]){
								$('#'+id+ ' > tfoot').append('<th>'+footer[column.title]+'</th>');
							}
					   });
					}
					}
				});
				return dt;				
			},
			getTechnologyData: function(technologyDropdown,regionDropdown,regionWithCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var testData = {}, countryCount = {}, totalCount = {}, technology= [], techTotal = {};
					_.forEach(regionWithCount, function(reg){
						_.forEach(regionDropdown, function(tech){
						createNestedObject(testData, [reg.name,tech.state], -1);
						createNestedObject(testData, [reg.name,'~Total'], 0);
						createNestedObject(techTotal, [reg.name], 0);
						createNestedObject(totalCount, [tech.state , 'Total'] , 0);
						createNestedObject(countryCount, [tech.state , reg.name] , 0);
					});
					});
					var colorCodes = [];
					totalCount['gTotal'] = 0;
					_.forEach(regionDropdown, function(respData){
						var tempObject = {};
						tempObject[respData.state]= respData.openedcases ;
						createNestedObject(testData, [respData.technology, respData.state ] , parseInt(respData.openedcases));
						createNestedObject(countryCount, [respData.state , respData.technology] , parseInt(respData.openedcases));
						createNestedObject(totalCount, [respData.state , 'Total'] , (totalCount[respData.state])['Total']+parseInt(respData.openedcases));
						createNestedObject(testData, [respData.technology,'~Total'] , (testData[respData.technology])['~Total']+parseInt(respData.openedcases));
						createNestedObject(techTotal, [respData.technology] , (techTotal[respData.technology])+parseInt(respData.openedcases));
						totalCount['gTotal']+=parseInt(respData.openedcases);
						if(colorCodes.indexOf(respData.color_code)===-1)
							colorCodes.push(respData.color_code);
						});
					techTotal = _.sortBy(_.pairs(techTotal), function (item) { return item[1]; });
					/* Descending Sort */
					techTotal = techTotal.reverse();
					var rankArray = [];
					_.forEach(techTotal, function(tech){
						rankArray.push(tech[0]);
					});
					_.forEach(testData, function(data){
							testData['regions'] = [];
							/* Sort Alphabetically */
							testData['regions'] = _.sortBy(Object.keys(data), function(o) { return o; });	
						return false;
					});

					var chartData = [], chartObj = {};
					_.forEach(Object.keys(countryCount), function(data){
							chartObj ={};
							var countryCountObj = countryCount[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							_.forEach(rankArray, function(key){
									chartObj['data'].push(countryCountObj[key]);
							});
							chartData.push(chartObj);
							technology = rankArray;
					});
					var returnObj = {};
					returnObj['testData'] = testData;
					returnObj['countryCount'] = countryCount;
					returnObj['chartData'] = chartData;
					returnObj['totalCount'] = totalCount;
					returnObj['technology'] = technology;
					returnObj['colorCode'] = colorCodes;
					return returnObj;
			},
        	getCustomerData: function(customerNameData){
				/* Top 10 Customers */
					var regionWithCustomerCount = _.first(_.sortBy(customerNameData, function(custData){
						return parseInt(custData.iBTechAvtotSum)}).reverse(),10);
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var customerCounts = {}, colorCodes ={};					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.iBTchRegion!==null){
							createNestedObject(customerCounts, [region.iBTchRegion,customerCount.custName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
					if(region.iBTchRegion!==null){	
						createNestedObject(customerCounts, [region.iBTchRegion,region.custName], (customerCounts[region.iBTchRegion])[region.custName]+parseInt(region.iBTechAvtotSum));
						totalCustomerCount = totalCustomerCount + parseInt(region.iBTechAvtotSum);
						colorCodes[region.iBTchRegion] = region.iBTechRegionId - 1;
					}
					});
					var chartData = [], chartObj = {}, customers = [];
					_.forEach(Object.keys(customerCounts), function(data){
							chartObj ={};
							var keys = Object.keys(customerCounts[data]);
							var customerCountsObj = customerCounts[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							chartObj['_colorIndex']=colorCodes[data];
							_.forEach(keys, function(key){
									chartObj['data'].push(customerCountsObj[key]);
							});
							customers = keys;
							chartData.push(chartObj);
					});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			},
			updateTechReg: function(techRegionData){
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var totalcount = 0,regionWithCountData=[], regionData={};					
					var regions = [], _colorIndexes = [], technologies = [], summaryData = {}, totalCount={};
					_.forEach(techRegionData, function(responseObj){
						if(regions.indexOf(responseObj.state) === -1 && responseObj.state!==null){
							regions.push(responseObj.state);
							_colorIndexes.push(responseObj.color_code);
						}
						if(technologies.indexOf(responseObj.technology) === -1){
							technologies.push(responseObj.technology);
						}					
					});
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(summaryData, [region, technology], 0);
								createNestedObject(summaryData, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
							}
						});
					});		
		
					_.forEach(techRegionData, function(responseObj){
						if(responseObj.region!==null){
							createNestedObject(summaryData, [responseObj.state, responseObj.technology],responseObj.openedcases);
							totalCount[responseObj.technology]=totalCount[responseObj.technology]+parseInt(responseObj.openedcases);
							totalcount = totalcount + parseInt(responseObj.openedcases);
						}
					});
					totalCount = _.sortBy(_.pairs(totalCount), function (item) { return item[1]; });
					/* Descending Sort */
					totalCount = totalCount.reverse();
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					_.forEach(regions, function(region){
						_.forEach(rankArray, function(technology){
							((regionData[region])[rankArray.indexOf(technology)])=parseInt((summaryData[region])[technology]);
						});
						regionWithCountData.push({
							'data': regionData[region], 
							'name':region,
							});
					});
					
				var returnObj = {};
				returnObj['regionWithCount'] = regionWithCountData;
				returnObj['technology'] = rankArray;
				returnObj['totalcount'] = totalcount;
				returnObj['colorCode'] = _colorIndexes;
				return returnObj;
			}
			
        };
    }]);
});
