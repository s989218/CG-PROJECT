define(['angular', '../sample-module'], function(angular, module) {
    'use strict';
    module.factory('TechnologyRegionChart', [function() {
        return {
			updateTechReg: function(techRegionData){
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var totalcount = 0, regionData={}, techSummary ={}, techData={};					
					var regions = [], _colorIndexes = [], technologies = [], totalCount={};
					/* All Regions and Technologies */
					_.forEach(techRegionData, function(responseObj){
						if(regions.indexOf(responseObj.mTechRegion) === -1 && responseObj.mTechRegion!==null){
							regions.push(responseObj.mTechRegion);
							
						}
						if(technologies.indexOf(responseObj.mTechTechnology) === -1){
							technologies.push(responseObj.mTechTechnology);
							_colorIndexes.push(responseObj.colorCode);
						}					
					});
					var techTotalCount = {};
					_.forEach(regions, function(region){
						regionData[region] = [];
						var count = 0;
						_.forEach(technologies, function(technology){
							if(region!==null){
								(regionData[region])[count] = 0;
								count ++;
								createNestedObject(techSummary, [technology, region], 0);
								createNestedObject(totalCount, [technology], 0);
								createNestedObject(techTotalCount, [region], 0);
							}
						});
					});	
					_.forEach(technologies, function(technology){
					techData[technology] = [];
					var count = 0;
					_.forEach(regions, function(region){
						if(region!==null){
							(techData[technology])[count] = 0;
							count ++;
						}
					});
				});        
					_.forEach(techRegionData, function(responseObj){
						if(responseObj.mTechRegion!==null){
							totalCount[responseObj.mTechTechnology]=totalCount[responseObj.mTechTechnology]+parseInt(responseObj.mTechTechnologyCount);
							techTotalCount[responseObj.mTechRegion]=techTotalCount[responseObj.mTechRegion]+parseFloat(responseObj.mTechTechnologyCount);
							createNestedObject(techSummary, [responseObj.mTechTechnology, responseObj.mTechRegion], responseObj.mTechTechnologyCount);
							totalcount = totalcount + parseInt(responseObj.mTechTechnologyCount);
							
						}
					});
					totalCount = _.sortBy(_.pairs(totalCount), function (item) { return item[1]; });
					techTotalCount = _.sortBy(_.pairs(techTotalCount), function (item) { return item[1]; });
					/* Descending Sort */
					totalCount = totalCount.reverse();
					techTotalCount = techTotalCount.reverse();
					var rankArray = [];
					_.forEach(totalCount, function(tech){
						rankArray.push(tech[0]);
					});
					var techRankArray = [];
				_.forEach(techTotalCount, function(region){
					techRankArray.push(region[0]);
				});
					var tempArr=[];
				_.forEach(technologies, function(technology){
					_.forEach(techRankArray, function(region){
						((techData[technology])[techRankArray.indexOf(region)])=parseInt((techSummary[technology])[region]);
					});
					tempArr.push({'data': techData[technology], 'name':technology});
				});
				var returnObj = {};
				returnObj['regionWithCount'] = tempArr;
				returnObj['technology'] = techRankArray;
				returnObj['totalcount'] = techRankArray;
				returnObj['totalcount'] = totalcount;
				returnObj['colorCode'] = _colorIndexes;
				return returnObj;
			}
        };
    }]);
});
