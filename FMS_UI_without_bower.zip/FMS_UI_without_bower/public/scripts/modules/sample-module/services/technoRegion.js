define(['angular', '../sample-module'], function(angular, module) {
    'use strict';
    module.factory('TechnoRegionService', ['$q','$http','$state','URLService','$rootScope',function($q, $http,$state,URLService,$rootScope) {
		var regionDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, colorCodes ={}, totalCounts = {}, regions = [], regionData ={};
					_.forEach(regionWithTechCount, function(region){
						if(region.mTechRegion!==null){
							regionData[region.mTechRegion] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.mTechRegion!==null){
							if(regions.indexOf(region.mTechRegion)===-1)
								regions.push(region.mTechRegion);
							createNestedObject(technologyCounts, [region.mTechRegion,techCount.mTechTechnology], 0);
							createNestedObject(totalCounts, [techCount.mTechTechnology], 0);
						}
						});
					});
					var totalCount = 0, count;
					_.forEach(regionWithTechCount, function(region){
						createNestedObject(technologyCounts, [region.mTechRegion,region.mTechTechnology], (technologyCounts[region.mTechRegion])[region.mTechTechnology]+parseInt(region.mTechTechnologyCount));
						totalCounts[region.mTechTechnology]=totalCounts[region.mTechTechnology]+parseInt(region.mTechTechnologyCount);
						totalCount = totalCount + parseInt(region.mTechTechnologyCount);
						colorCodes[region.mTechRegion] = parseInt(region.mTechRegId);
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							});
						});
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=
									parseInt((technologyCounts[region])[technology]); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region, '_colorIndex':colorCodes[region]});
						});
					var returnObj = {};
					returnObj['totalCount'] = totalCount;
					returnObj['technologies'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					return returnObj;
			};
			var countryDataProcess = function(regionWithTechCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var technologyCounts = {}, colorCodes =[], totalCounts = {}, regions = [], regionData ={}, testData = {},totalCount = {};
					_.forEach(regionWithTechCount, function(region){
						if(region.mTechTechnology!==null){
							regionData[region.mTechTechnology] = [];
						}
						_.forEach(regionWithTechCount, function(techCount){
						if(region.mTechTechnology!==null){
							if(regions.indexOf(region.mTechTechnology)===-1){
								regions.push(region.mTechTechnology);
								colorCodes.push(region.colorCode);
							}
							createNestedObject(technologyCounts, [region.mTechTechnology,techCount.mTechCountry], 0);
							createNestedObject(testData, [techCount.mTechCountry,region.mTechTechnology], -1);
							createNestedObject(testData, [techCount.mTechCountry, '~Total'], 0);
							createNestedObject(totalCounts, [techCount.mTechCountry], 0);
							createNestedObject(totalCount, [region.mTechTechnology , 'Total'] , 0);
							
						}
						});
					});
					totalCount['gTotal'] = 0;
					_.forEach(regionWithTechCount, function(region){
						if(region.mTechCountry!==null){
							createNestedObject(technologyCounts, [region.mTechTechnology,region.mTechCountry], (technologyCounts[region.mTechTechnology])[region.mTechCountry]+parseInt(region.mTechTechnologyCount));
							createNestedObject(testData, [region.mTechCountry, region.mTechTechnology ] , parseInt(region.mTechTechnologyCount));
							createNestedObject(testData, [region.mTechCountry,'~Total'] , (testData[region.mTechCountry])['~Total']+parseInt(region.mTechTechnologyCount));
							createNestedObject(totalCount, [region.mTechTechnology , 'Total'] , (totalCount[region.mTechTechnology])['Total']+parseInt(region.mTechTechnologyCount));
							totalCounts[region.mTechCountry]=totalCounts[region.mTechCountry]+parseInt(region.mTechTechnologyCount);
							totalCount['gTotal']+=parseInt(region.mTechTechnologyCount);
						}
						});
						totalCounts = _.sortBy(_.pairs(totalCounts), function (item) { return item[1]; });
						/* Descending Sort */
						totalCounts = totalCounts.reverse();
						var rankArray = [];
						_.forEach(totalCounts, function(tech){
							rankArray.push(tech[0]);
						});
						var regionWithCountData=[];
						/* Initializing Array */
						_.forEach(regions, function(region){
							var count =0 ;
							_.forEach(rankArray, function(technology){
								((regionData[region])[count])=0; 
							}); 
						});
						var highchartData = [];
						_.forEach(regions, function(region){
							_.forEach(rankArray, function(technology){
								((regionData[region])[rankArray.indexOf(technology)])=parseInt((technologyCounts[region])[technology]); 
							});
							regionWithCountData.push({'data': technologyCounts[region], 'name':region});
							highchartData.push({'data': regionData[region], 'name':region});
						});
						_.forEach(testData, function(data){
								testData['regions'] = [];
								/* Sort Alphabetically */
								testData['regions'] = _.sortBy(Object.keys(data), function(o) { return o; });	
							return false;
						});
					var returnObj = {};
					returnObj['technology'] = rankArray;
					returnObj['chartData'] = regionWithCountData;
					returnObj['highchartData'] = highchartData;
					returnObj['testData'] = testData;
					returnObj['totalCount'] = totalCount;
					returnObj['colorCode'] = colorCodes;
					return returnObj;
			};
			var processCountryTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Technology'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.mTechTechnology)=== -1){
						technologies.push(obj.mTechTechnology);
					}
					if(regions.indexOf(obj.mTechCountry)=== -1 && obj.mTechCountry !==null){
						var colObj = {'title':obj.mTechCountry};
						columns.push(colObj);
						regions.push(obj.mTechCountry);
					}
				});
				var dataArr = [[]], totalCount={}, regionCount= {};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
						if(!(region===null)){
							createNestedObject(tableData, [technology, region], 0);
							createNestedObject(totalCount, [technology], 0);
							createNestedObject(regionCount, [region], 0);
							dataArr[technologies.indexOf(technology)] = [];
							(dataArr[technologies.indexOf(technology)])[0] = technology;
							for(var index=1; index<=regions.length; index++)
								(dataArr[technologies.indexOf(technology)])[index] = 0;
						}
					});					
				});		
				regionCount['Grand Total']=0;
				_.forEach(technologyData, function(obj){
					if(!(obj.mTechCountry===null)){
						createNestedObject(tableData, [obj.mTechTechnology, obj.mTechCountry], obj.mTechTechnologyCount);
						var mTechTechnologyCountNum= parseInt(obj.mTechTechnologyCount);
						(dataArr[technologies.indexOf(obj.mTechTechnology)])[regions.indexOf(obj.mTechCountry)+1] = numberWithCommas(mTechTechnologyCountNum);
						totalCount[obj.mTechTechnology]=totalCount[obj.mTechTechnology]+parseInt(obj.mTechTechnologyCount);
						regionCount[obj.mTechCountry]=regionCount[obj.mTechCountry]+parseInt(obj.mTechTechnologyCount);
						regionCount['Grand Total'] = regionCount['Grand Total'] +parseInt(obj.mTechTechnologyCount);
					}
				});
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){					
					(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = numberWithCommas(totalCount[technology]);
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['regionCount'] = regionCount;
				dataObj['columns'] = columns;
				return dataObj;
			};
			var processTable = function(technologyData){
				var dataObj = {};
				var technologies=[], regions=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Technology'}];
				_.forEach(technologyData, function(obj){
					if(technologies.indexOf(obj.mTechTechnology)=== -1){
						technologies.push(obj.mTechTechnology);
					}
					if(regions.indexOf(obj.mTechRegion)=== -1 && obj.mTechRegion!==null){
						var colObj = {'title':obj.mTechRegion};
						columns.push(colObj);
						regions.push(obj.mTechRegion);
					}
				});
				var dataArr = [[]], totalCount={}, regionCount={};
				_.forEach(technologies, function(technology){
					_.forEach(regions, function(region){
					if(region!==null){
						createNestedObject(tableData, [technology, region], 0);
						createNestedObject(totalCount, [technology], 0);
						createNestedObject(regionCount, [region], 0);
						dataArr[technologies.indexOf(technology)] = [];
						(dataArr[technologies.indexOf(technology)])[0] = technology;
						for(var index=1; index<=regions.length; index++)
							(dataArr[technologies.indexOf(technology)])[index] = 0;
					}
					});					
				});
				regionCount['Grand Total']=0;
				_.forEach(technologyData, function(obj){
				if(obj.mTechRegion!==null){
					createNestedObject(tableData, [obj.mTechTechnology, obj.mTechRegion], obj.mTechTechnologyCount);
					var mTechTechnologyCountNum= parseInt(obj.mTechTechnologyCount);
					(dataArr[technologies.indexOf(obj.mTechTechnology)])[regions.indexOf(obj.mTechRegion)+1] = numberWithCommas(mTechTechnologyCountNum);
					totalCount[obj.mTechTechnology]=totalCount[obj.mTechTechnology]+parseInt(obj.mTechTechnologyCount);
					regionCount[obj.mTechRegion]=regionCount[obj.mTechRegion]+parseInt(obj.mTechTechnologyCount);
					regionCount['Grand Total']=regionCount['Grand Total']+parseInt(obj.mTechTechnologyCount);
				}
				});
				columns.push({'title':'Grand Total'});
				_.forEach(technologies, function(technology){					
					(dataArr[technologies.indexOf(technology)])[(dataArr[technologies.indexOf(technology)]).length] = numberWithCommas(totalCount[technology]);
				});
				tableData['regions'] = _.sortBy(regions,function(region){return region});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};
        return {
			searchDataService: function(){
				var jsonData = [];
                
				var item                    = {};
				item["region"]              = "";
				item["unitStatusDesc"]      = "InService";
				item["siteCustCountry"]     = "";
				item["servRelationDescOng"] = "";
				item["technology"]          = "";
				item["equipCode"]           = "";
				item["marketSegmentDesc"]   = "";
				item["customerName"]        = "";
				item["maintPolicyCode"]     = "";
				item["siteCustName"]        = "";
				item["iboType"]             = "full_ibo";
				item["businessSegment"]     = $rootScope.businessSegment;
                item["accountManager"]      = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"]      = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
				jsonData.push(item);
				return jsonData;
			},
			/* Network Call */
			getIBMetricsFilterData:function(jsonData){
				var request = {
					'method': 'POST',
					'data': {'data' : jsonData},
					'url':	URLService.newMetrics.IBData,						
					};
				return networkCall(request);
			},
			getIBCountryMetricsFilterData: function(jsonData){
				var request = {
					'method': 'POST',
					"data": {'data' : jsonData},
					'url': URLService.newMetrics.IBCountry					
					};
				return networkCall(request);
			},
			getRegionWithCount: function(techRegionData){	
					return regionDataProcess(techRegionData)['chartData']
			},
			processedData: function(techRegionData){	
					return regionDataProcess(techRegionData);
			},
			countryDataProcess: function(techRegionData){	
					return countryDataProcess(techRegionData);
			},
			processTable: function(technologyData){
				return processTable(technologyData);
			},
			excelDownload: function(id){
			var footer = document.getElementById(id).tFoot.innerText;
				footer=footer.split(/(\s+)/).filter( function(e) { return e.trim().length > 0; } );
			    var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 });
				 var tableToExcel = (function() {
					 var ctx,subHeader;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
	                      if (!table.nodeType) 
	                             table = document.getElementById(id);
	                      var excelContent = '';
	                      var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                     
	                      if(id ==='Country_DT_TechRegion')
                    	  {
		                      subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>IB Techno Region Country Level</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='Region_DT_TechRegion')
                    	  {
	                    	  subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>IB Techno Region</span>"+
	                          "</td></tr>";
                    	  }
	                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                      excelContent = excelContent + subHeader;
	                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
	                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                      var td = "<td style='width: auto; padding-right:5px; background-color:#111;color:white'>";
	                      var tdNumber = "<td style='mso-number-format:0'>";
	                      excelContent =excelContent + '<tr>';
	                      _.forEach(columns, function(column){
	                                    excelContent = excelContent + th + column + '</th>';
	                      });
	                      excelContent = excelContent + '</tr>';
	                      _.forEach(getDataFromDT, function(row){
	                        
	                             excelContent =excelContent + '<tr>';
	                             _.forEach(row, function(rowData){
	                                    if((/^[0-9]{0,}$/).test(rowData))
	                                           excelContent = excelContent + tdNumber + rowData + '</td>';
	                                    else
	                                           excelContent = excelContent + '<td>' + rowData + '</td>';
	                             });
	                             excelContent =excelContent + '</tr>';
	                      });
	                      excelContent =excelContent + '<tr>';
	                      _.forEach(footer, function(row){
	                             excelContent = excelContent + td + row + '</td>';
	                      });
	                      excelContent =excelContent + '</tr>';
	                      
	                      if(id === 'Country_DT_TechRegion')
	                      {
	                    	  ctx = {worksheet:'Techno Region Data Country' , table: excelContent};
		                      document.getElementById('technoRegionCountrylevel').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('technoRegionCountrylevel').download = 'TechnoRegion_Country.xls';
	                      }
	                      if(id ==='Region_DT_TechRegion')
	                      {
	                    	  ctx = {worksheet: 'Techno Region Data' , table: excelContent};
		                      document.getElementById('technoRegion').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('technoRegion').download = 'Techno_Region.xls';
	                      }
	                }
	                })();
	                tableToExcel(id);
				return null;
			},
			processCountryTable: function(technologyData){
				return processCountryTable(technologyData);
			},
			initTable(data,columns,id) { 
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
                
                if ($.fn.DataTable.isDataTable( '#'+id ) ) {
                    $('#'+id).dataTable().api().clear().draw();
                    $('#'+id).dataTable().api().destroy();
                    $('#'+id).empty(); 
                    $('#'+id).append('<tfoot></tfoot>');
                }
                
				dt = $('#'+id).DataTable({
				   "order": [[ columns.length-1, "desc" ]],
				   columns : columns,
                   data: data,
				   "pageLength": 10,
				   fnDrawCallback : function() {
					if(footer && data[0].length>0){
					   $('#'+id+ ' > tfoot').html('');
					   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					   _.forEach(columns, function(column){
							if(footer[column.title] !== undefined){
								$('#'+id+ ' > tfoot').append('<th>'+numberWithCommas(footer[column.title])+'</th>');
							}
					   });
					}
					}
				});
				return dt;				
			},
        	getCustomerData: function(customerNameData){
				/* Top 10 Customers */
					var regionWithCustomerCount = _.first(_.sortBy(customerNameData, function(custData){
						return parseInt(custData.custNameCount)}).reverse(),10);
					var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var customerCounts = {}, colorCodes ={};					
					_.forEach(regionWithCustomerCount, function(region){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(region.mTechRegion!==null){
							createNestedObject(customerCounts, [region.mTechRegion,customerCount.custName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(region){
					if(region.mTechRegion!==null){	
						createNestedObject(customerCounts, [region.mTechRegion,region.custName], (customerCounts[region.mTechRegion])[region.custName]+parseInt(region.custNameCount));
						totalCustomerCount = totalCustomerCount + parseInt(region.custNameCount);
						colorCodes[region.mTechRegion] = region.mTechRegId - 1;
					}
					});
					var chartData = [], chartObj = {}, customers = [];
					_.forEach(Object.keys(customerCounts), function(data){
							chartObj ={};
							var keys = Object.keys(customerCounts[data]);
							var customerCountsObj = customerCounts[data];
							chartObj['data'] = [];
							chartObj['name'] = data;
							chartObj['_colorIndex']=colorCodes[data];
							_.forEach(keys, function(key){
									chartObj['data'].push(customerCountsObj[key]);
							});
							customers = keys;
							chartData.push(chartObj);
					});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			},
			getCountries: function(jsonData){
				var request = {
						"dataType"    : "json",
                        "method"      : "POST",
                        "contentType" : "application/json",
                        "data"        : jsonData,
						'url': URLService.newMetrics.getCountries,						
						};
				return networkCall(request);
			},
			topCustChart: function(custName,regionWithCustCount,id)
			{
					return new Highcharts.Chart({
					chart: {
						  renderTo: id,
								type: 'bar',
								events: {
									click: function () {
										$state.go('topCustomer');
									}
								}
						  },
					title: {
						text:''
					},
					xAxis: {
						categories: custName
					},
					yAxis: {
						min: 0,
						title: {
							text: ''
						}
					},
					tooltip: {
						pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.2f}%)<br/>',
						shared: true
					},
					legend: {
						itemStyle: {
							color: 'black',
							fontWeight: 'normal',
							fontSize: '12px',
						}
					},
					 plotOptions: {
							series: {
							stacking: 'normal',
							borderWidth:0
						}
					},
					credits: {
						 enabled: false
					},
					series: regionWithCustCount,
                    responsive: {
                        rules: [{
                            condition: {
                                maxWidth: 500
                            },
                            chartOptions: {
                                legend: {
                                    align: 'center',
                                    verticalAlign: 'bottom',
                                    layout: 'horizontal'
                                },
                                yAxis: {
                                    labels: {
                                        align: 'left',
                                        x: 0,
                                        y: -5
                                    },
                                    title: {
                                        text: null
                                    }
                                },
                                subtitle: {
                                    text: null
                                },
                                credits: {
                                    enabled: false
                                }
                            }
                        }]
                    }
				});
			}
        };
    }]);
});
