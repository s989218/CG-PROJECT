define(['angular', '../sample-module','highChartExport'], function(angular, module) {
    'use strict';
    module.factory('TopCustomerService', ['$q','$http','$state','URLService','$rootScope',function($q, $http,$state,URLService,$rootScope) {
	var chart;
    	var dataProcessing = function(regionWithCustomerCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var customerCounts = {}, colorCodes ={};
					
					_.forEach(regionWithCustomerCount, function(tech){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(tech.technologyIB!==null){
							createNestedObject(customerCounts, [tech.technologyIB,customerCount.custName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(tech){
						if(tech.technologyIB!==null){
							createNestedObject(customerCounts, [tech.technologyIB,tech.custName], (customerCounts[tech.technologyIB])[tech.custName]+parseInt(tech.techCountIB));
								totalCustomerCount = totalCustomerCount + parseInt(tech.custNameCount);
								colorCodes[tech.technologyIB] = tech.custColorCodeIB;
							}
						});
						var chartData = [], chartObj = {}, customers = [];
						_.forEach(Object.keys(customerCounts), function(data){
								chartObj ={};
								var keys = Object.keys(customerCounts[data]);
								var customerCountsObj = customerCounts[data];
								chartObj['data'] = [];
								chartObj['name'] = data;
								chartObj['color']=colorCodes[data];
								_.forEach(keys, function(key){
										chartObj['data'].push(customerCountsObj[key]);
								});
								customers = keys;
								chartData.push(chartObj);
						});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			};
		var countryDataProcess = function(regionWithCustomerCount){
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
					var customerCounts = {}, colorCodes ={};
					
					_.forEach(regionWithCustomerCount, function(tech){
						_.forEach(regionWithCustomerCount, function(customerCount){
						if(tech.technologyIB!=null){
							createNestedObject(customerCounts, [tech.technologyIB,customerCount.custName], 0);
						}
						});
					});
					var totalCustomerCount = 0;
					_.forEach(regionWithCustomerCount, function(tech){
						if(tech.technologyIB!=null){
							createNestedObject(customerCounts, [tech.technologyIB,tech.custName], (customerCounts[tech.technologyIB])[tech.custName]+parseInt(tech.techCountIB));
								totalCustomerCount = totalCustomerCount + parseInt(tech.custNameCount);
									colorCodes[tech.technologyIB] = tech.custColorCodeIB;
						}
						});
						var chartData = [], chartObj = {}, customers = [];
						_.forEach(Object.keys(customerCounts), function(data){
								chartObj ={};
								var keys = Object.keys(customerCounts[data]);
								var customerCountsObj = customerCounts[data];
								chartObj['data'] = [];
								chartObj['name'] = data;
								chartObj['color']=colorCodes[data];
								_.forEach(keys, function(key){
										chartObj['data'].push(customerCountsObj[key]);
								});
								customers = keys;
								chartData.push(chartObj);
						});
					var returnObj = {};
					returnObj['totalCustomerCount'] = totalCustomerCount;
					returnObj['customers'] = customers;
					returnObj['chartData'] = chartData;
					return returnObj;
			};
		var networkCall = function(request){
			var deferred  = $q.defer();            	
			$http({
					method: request.method,
					data: request.data,
					url: request.url,
					headers: request.headers,
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
				}, function errorCallback(status, error) {
					console.error("Data could not Be Retrieved. ERROR: Could not find data source. "+status);
					deferred.reject(error);
				});
			return deferred.promise;
		};//top customer region level datatable
		var processTable = function(customerData){
				var dataObj = {},regionNames = [],custRegion = [];
				var customers=[], technology=[], tableData = {}, columns = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Customer'}];
				columns.push({'title':'Region'});
				_.forEach(customerData, function(obj){
					if(customers.indexOf(obj.custName)=== -1 || regionNames.indexOf(obj.region)=== -1){
						customers.push(obj.custName);
						regionNames.push(obj.region);
						custRegion.push(obj.custName+obj.region);
					}
					if(technology.indexOf(obj.technologyIB)=== -1 && obj.technologyIB!==null){					
						var colObj = {'title':obj.technologyIB};
						columns.push(colObj);
						technology.push(obj.technologyIB);
					}
				});
				var dataArr = [[]], totalCount ={}, regionCount={},i=0,j=0;
				_.forEach(customers, function(customer){
					_.forEach(technology, function(tech){
						if(tech!==null){
							createNestedObject(tableData, [customers[i],technology[j]], 0);
							createNestedObject(totalCount, [customers[i]+regionNames[i]], 0);
							createNestedObject(regionCount, [tech], 0);
							dataArr[i] = [];
							(dataArr[i])[0] = customers[i];
							(dataArr[i])[1] = regionNames[i];
							for(var index=1; index<=technology.length; index++)
								(dataArr[i])[index+1] = 0;
						}
						j++;
					});
					i++;
				});
				var total = 0,p;
				_.forEach(customerData, function(obj){
					if(obj.technologyIB!==null){
						createNestedObject(tableData, [obj.custName, obj.technologyIB], obj.techCountIB);
						createNestedObject(regionCount, [obj.technologyIB], regionCount[obj.technologyIB]+parseInt(obj.techCountIB));
						var custNameCountNum= parseInt(obj.techCountIB);
						if( custRegion[custRegion.indexOf(obj.custName+obj.region)] === obj.custName+obj.region){
							p = custRegion.indexOf(obj.custName+obj.region);
							(dataArr[p])[technology.indexOf(obj.technologyIB)+2] =numberWithCommas(custNameCountNum);
							totalCount[obj.custName+obj.region]=totalCount[obj.custName+obj.region]+parseInt(obj.techCountIB);
							total = total +parseInt(obj.techCountIB);
						}
					}
				});
				columns.push({'title':'Grand Total'});
				regionCount['Grand Total']=total;
				_.forEach(custRegion, function(custReg){					
					(dataArr[custRegion.indexOf(custReg)])[(dataArr[custRegion.indexOf(custReg)]).length] = numberWithCommas(totalCount[custReg]);
				});
				tableData['regions'] = _.sortBy(technology,function(tech){return tech});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['regionCount'] = regionCount;
				dataObj['columns'] = columns;
				return dataObj;
			};//top customer country level datatable
			var processCountryTable = function(customerData){
				var dataObj = {},custCountry = [];
				var customers=[], technology=[], tableData = {}, columns = [],countryNames = [];
				var createNestedObject = function( base, names, value ) {
						var lastName = arguments.length === 3 ? names.pop() : false;
						for( var i = 0; i < names.length; i++ ) {
							base = base[ names[i] ] = base[ names[i] ] || {};
						}
						if( lastName ) base = base[ lastName ] = value;
						return base;
					};
				columns = [{'title':'Customer'}];
				columns.push({'title':'Country'});
				_.forEach(customerData, function(obj){
					if(customers.indexOf(obj.custName)=== -1 || countryNames.indexOf(obj.country)=== -1){
						customers.push(obj.custName);
						countryNames.push(obj.country);
						custCountry.push(obj.custName+obj.country)
					}
					if(technology.indexOf(obj.technologyIB)=== -1 && obj.technologyIB!==null){
						var colObj = {'title':obj.technologyIB};
						columns.push(colObj);
						technology.push(obj.technologyIB);
					}
				});
				var dataArr = [[]], totalCount = {}, regionCount={},i=0,j=0;
				_.forEach(customers, function(customer){
					_.forEach(technology, function(tech){
						if(tech!==null){
							createNestedObject(tableData, [customers[i], technology[j]], 0);
							createNestedObject(totalCount, [customers[i]+countryNames[i]], 0);
							createNestedObject(regionCount, [tech], 0);
							dataArr[i] = [];
							(dataArr[i])[0] = customers[i];
							(dataArr[i])[1] = countryNames[i];
							for(var index=1; index<=technology.length; index++)
								(dataArr[i])[index+1] = 0;
						}
						j++;
					});
					i++;
				});
				var total = 0,p;
				_.forEach(customerData, function(obj){
					if(obj.technologyIB!==null){
						createNestedObject(tableData, [obj.custName, obj.technologyIB], obj.techCountIB);
						createNestedObject(regionCount, [obj.technologyIB], regionCount[obj.technologyIB]+parseInt(obj.techCountIB));
						var custNameCountNum = parseInt(obj.techCountIB);
						if( custCountry[custCountry.indexOf(obj.custName+obj.country)] === obj.custName+obj.country){
							p = custCountry.indexOf(obj.custName+obj.country);
							(dataArr[p])[technology.indexOf(obj.technologyIB)+2] = numberWithCommas(custNameCountNum);
							total = total + parseInt(obj.techCountIB);
							totalCount[obj.custName+obj.country]=totalCount[obj.custName+obj.country]+parseInt(obj.techCountIB);
						}
					}
				});
				columns.push({'title':'Grand Total'});
				regionCount['Grand Total']=total;
				_.forEach(custCountry, function(custCntry){                                                                          
					(dataArr[custCountry.indexOf(custCntry)])[(dataArr[custCountry.indexOf(custCntry)]).length] = numberWithCommas(totalCount[custCntry]);
				});
				tableData['regions'] = _.sortBy(technology,function(tech){return tech});
				dataObj['tableData'] = tableData;
				dataObj['dataArr'] = dataArr;
				dataObj['columns'] = columns;
				dataObj['regionCount'] = regionCount;
				return dataObj;
			};
        return {
			/* Network Call */
			getIBMetricsDropdownsData: function(jsonData){
				var request = {
					"dataType"    : "json",
					"method"      : "POST",
                    "contentType" : "application/json",
					"data"        : jsonData,
					'url': URLService.newMetrics.IBDropdown+'/'+$rootScope.businessSegment,						
					};
				return networkCall(request);
			},
			getCountries: function(jsonData){
				var request = {
					"dataType"    : "json",
                    "method"      : "POST",
                    "contentType" : "application/json",
                    "data"        : jsonData,
					'url': URLService.newMetrics.getCountries,
					};
				return networkCall(request);
			},
			getIBMetricsFilterData: function(jsonData){
				var request = {
					'method': 'POST',
					"data": {'data' : jsonData},
					'url': URLService.newMetrics.IBData						
					};
				return networkCall(request);
			},
			getIBCountryMetricsFilterData: function(jsonData){
				var request = {
					'method': 'POST',
					"data": {'data' : jsonData},
					'url': URLService.newMetrics.IBCountry				
					};
				return networkCall(request);
			},
        	processCustomerData: function(customerData){
					var regionWithCustomerCount = customerData;
					return dataProcessing(regionWithCustomerCount);
			},
			countryDataProcessing: function(customerData){
				var regionWithCustomerCount = customerData;
				return countryDataProcess(regionWithCustomerCount);
			},
			processAllCustomerData: function(customerData){
					var regionWithCustomerCount = customerData;
					return dataProcessing(regionWithCustomerCount);
			},
			customerTableData: function(customerData){
				return processTable(customerData);
			},
			customerCountryTableData: function(customerData){
				return processCountryTable(customerData);
			},
			topCustomerTableData: function(customerData){
				return processTable(customerData);
			},
			searchDataService: function(){
				var jsonData = [];
                
				var item                    = {};
				item["region"]              = "";
				item["unitStatusDesc"]      = "InService";
				item["siteCustCountry"]     = "";
				item["servRelationDescOng"] = "";
				item["technology"]          = "";
				item["equipCode"]           = "";
				item["marketSegmentDesc"]   = "";
				item["customerName"]        = "";
				item["maintPolicyCode"]     = "";
				item["iboType"]             = "full_ibo";
				item["businessSegment"]     = $rootScope.businessSegment;
                item["accountManager"]      = $rootScope.accountManager ? $rootScope.accountManager : "";
                item["marketIndustry"]      = $rootScope.marketIndustry ? $rootScope.marketIndustry : "";
				jsonData.push(item);
				return jsonData;
			},
			customerSearchDataService: function(){
				var jsonData = [];
				var item = {};
				item["region"] = "Europe";
				item["unitStatusDesc"]="";
				item["siteCustCountry"]= "";
				item["servRelationDescOng"]="";
				item["technology"]="";
				item["equipCode"]="";
				item["marketSegmentDesc"]="";
				item["customerName"]="";
				item["maintPolicyCode"]="";
				jsonData.push(item);
				return jsonData;
			},
			excelDownload: function(id){
				var footer = document.getElementById(id).tFoot.innerText;
				footer=footer.split(/(\s+)/).filter( function(e) { return e.trim().length > 0; } );
			    var columns = [];
				 _.forEach($('#'+id+'').dataTable().api().columns().header(), function(data){
                     columns.push(data.innerHTML);
				 });
				 var tableToExcel = (function() {
					 var ctx,subHeader;
	                 var uri = 'data:application/vnd.ms-excel;base64,'
	                 , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
	                             , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	                             , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	                      return function(table) {
	                      if (!table.nodeType) 
	                             table = document.getElementById(id);
	                      var excelContent = '';
	                      var header = "<tr><td colspan='8' style='text-align:center'>" +
	                                    "</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style='font-size: 30px; text-align: center;font-style: italic;font-weight: bold;'>Fleet Mining System</span>"+
	                                    "<span style='font-size: 15px;'><i>Powered By GE Oil&Gas</i></span></td></tr>";
	                      if(id ==='IB-by-Top-Cust-Country-Data')
                    	  {
		                       subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>IB Top Customer Country Level</span>"+
	                          "</td></tr>";
                    	  }
	                      if(id ==='IB-by-Top-Cust-Data')
                    	  {
		                       subHeader="<tr><td colspan='8' style='text-align:center'>" +
	                          "</span><span style='font-size: 20px; text-align: center;font-style: italic;font-weight: bold;'>IB Top Customer</span>"+
	                          "</td></tr>";
                    	  }
	                      excelContent = excelContent + header + '<tr><td colspan="7" style="text-align:right; font-size: 15px">Created On: '+(new Date()).toLocaleString()+'</td></tr>';
	                      excelContent = excelContent + subHeader;
	                      var getDataFromDT  = $('#'+id+'').dataTable().api().rows( { filter: "applied" } ).data().toArray();
	                      var th = "<th style='width: auto; padding-right:5px; background-color:#00BCD4'>";
	                      var td = "<td style='width: auto; padding-right:5px; background-color:#111;color:white'>";
	                      var tdNumber = "<td style='mso-number-format:0'>";
	                      excelContent =excelContent + '<tr>';
	                      _.forEach(columns, function(column){
	                                    excelContent = excelContent + th + column + '</th>';
	                      });
	                      excelContent = excelContent + '</tr>';
	                      _.forEach(getDataFromDT, function(row){
	                             excelContent =excelContent + '<tr>';
	                             _.forEach(row, function(rowData){
	                            	 if((/^[0-9]{0,}$/).test(rowData))
	                                           excelContent = excelContent + tdNumber + rowData + '</td>';
	                                    else
	                                           excelContent = excelContent + '<td>' + rowData + '</td>';
	                             });
	                             excelContent =excelContent + '</tr>';
	                      });
	                     excelContent =excelContent + '<tr>';
	                      _.forEach(footer, function(row){
	                    	  if(row === 'Total'){
	                    	  		 excelContent = excelContent + td+ row + '</td>'+td + '&nbsp'+ '</td>'
	                    	  	}else{
	                    	  		excelContent = excelContent + td+ row + '</td>';
	                    	  	}
	                      });
	                      excelContent =excelContent + '</tr>';
	                      if(id ==='IB-by-Top-Cust-Country-Data')
                    	  {
	                    	  ctx = {worksheet:'Top Customer Country' , table: excelContent};
		                      document.getElementById('topCustomerpageCntryLvl').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('topCustomerpageCntryLvl').download = 'TopCustomer-CountryLevel.xls';
                    	  }
	                      if(id==='IB-by-Top-Cust-Data')
	                      {
	                    	  ctx = {worksheet: 'Top Customer' , table: excelContent};
		                      document.getElementById('topCustomerpage').href = (uri + base64(format(template, ctx)));
		                      document.getElementById('topCustomerpage').download = 'Top-Customer.xls';
	                      }
	                }
	                })();
	                tableToExcel(id);
				return null;
			},
			initTable(data,columns,id) { 
				var footer=null;
				if(arguments[3])
					footer = arguments[3];
				var dt;
				if ($.fn.DataTable.isDataTable( '#'+id )) {
						$('#'+id).dataTable().fnDestroy();        
						$('#'+id).empty(); 
						 $('#'+id).append('<tfoot></tfoot>');
					}  
				dt = $('#'+id).DataTable({
				   "order": [[ columns.length-1, "desc" ]],
				   columns : columns,
                   data: data,
                   "pageLength": 10,
				   fnDrawCallback : function() {
					if(footer && data[0].length>0){
					   $('#'+id+ ' > tfoot').html('');
					   $('#'+id+ ' > tfoot').append('<th>Total</th>');
					   $('#'+id+ ' > tfoot').append('<th> </th>');
					   _.forEach(columns, function(column){
							if(footer[column.title]){
								$('#'+id+ ' > tfoot').append('<th>'+numberWithCommas(footer[column.title])+'</th>');
							}
					   });
					}
					}
				});
				return dt;	
			},
			topCustChart: function(custName,regionWithCustCount,id)
			{
				$('.backClass').on('click',function(){
					$state.go('NewMetrics');
				});
				Highcharts.setOptions({
			        global: {
			            useUTC: false,
			            
			        },
			        lang: {
			          decimalPoint: '.',
			          thousandsSep: ','
			        }
			    });
				chart= new Highcharts.Chart({
				chart: {
						  renderTo: id,
								type: 'bar',
								events: {
									click: function () {
										$state.go('topCustomer');
									}
								}
						  },
					title: {
						text:''
					},
					xAxis: {
						categories: custName
					},
					yAxis: {
						min: 0,
						title: {
							text: 'Count'
						}
					},
					tooltip: {
						pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y:,.0f}</b> ({point.percentage:.2f}%)<br/>',
						shared: true
					},
					legend: {
						itemStyle: {
							color: 'black',
							fontWeight: 'normal',
							fontSize: '12px',
						}
					},
					 plotOptions: {
							series: {
							stacking: 'normal',
							borderWidth:0
						}
					},
					credits: {
						 enabled: false
					},
					series: regionWithCustCount,
                    responsive: {
                        rules: [{
                            condition: {
                                maxWidth: 500
                            },
                            chartOptions: {
                                legend: {
                                    align: 'center',
                                    verticalAlign: 'bottom',
                                    layout: 'horizontal'
                                },
                                yAxis: {
                                    labels: {
                                        align: 'left',
                                        x: 0,
                                        y: -5
                                    },
                                    title: {
                                        text: null
                                    }
                                },
                                subtitle: {
                                    text: null
                                },
                                credits: {
                                    enabled: false
                                }
                            }
                        }]
                    }
				});
				return chart;
			},
			exportChart : function(type){
			if(type === 'JPEG')
				{
				 chart.exportChart({type: 'image/jpeg', filename: 'Top-Customer'}, {subtitle: {text:''}});
				}
				if(type === 'XLS'){
				chart.exportChart({type: 'application/vnd.ms-excel', filename: 'Top-Customer'}, {subtitle: {text:''}});
				}
				}
        };
    }]);
});
