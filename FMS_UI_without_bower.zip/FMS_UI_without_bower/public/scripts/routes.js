/**
 * Router Config
 * This is the router definition that defines all application routes.
 */
define(['angular', 'angular-ui-router'], function(angular) {
    'use strict';
    return angular.module('app.routes', ['ui.router']).config(['$stateProvider', '$urlRouterProvider', '$locationProvider','$controllerProvider',
	function($stateProvider, $urlRouterProvider, $locationProvider,$controllerProvider) {

        //Turn on or off HTML5 mode which uses the # hash
        $locationProvider.html5Mode(true).hashPrefix('!');
		var registerController = $controllerProvider.register;
		var userRoles = [];


        /**
         * Router paths
         * This is where the name of the route is matched to the controller and view template.
         */
			$stateProvider
	        .state('secure', {
	            template: '<ui-view/>',
	            abstract: true,
	            resolve: {
	                authenticated: ['$q', 'PredixUserService', function ($q, predixUserService) {
	                    var deferred = $q.defer();
	                    predixUserService.isAuthenticated().then(function(userInfo){
	                        deferred.resolve(userInfo);
	                    }, function(){
	                        deferred.reject({code: 'UNAUTHORIZED'});
	                    });
	                    return deferred.promise;
	                }]
	            }
	        })		
			.state('InstalledBase', {
				parent: 'secure',
				url: '/InstalledBase',
                templateUrl: 'views/installedBase.html',
				controller:'installCtrl'
            })
			 .state('MaintenanceData', {
				parent: 'secure',
                url: '/MaintenanceData',
                templateUrl: 'views/Maintenance.html',
				controller:'updateMaintenanceDataCtrl'
            })
			.state('EquipmentData', {
                parent: 'secure',
                url: '/EquipmentData',
                templateUrl: 'views/IBASData.html',
				controller:'updateIBASDataCtrl'
            })
			.state('Metrics', {
                parent: 'secure',
                url: '/Metrics',
                templateUrl: 'views/Metrics.html',
				controller:'MetricsCtrl'
                
            })
            .state('IPMParts', {
            	parent: 'secure',
				url: '/IPMParts',
                templateUrl: 'views/IPMParts.html',
				controller:'IPMPartsCtrl'
            })
        
            .state('IPM', {
            	parent: 'secure',
				url: '/IPM',
                templateUrl: 'views/IPM/IPM-Main.html',
                controller:'IPMParentCtrl'
            })
            .state('Orders', {
            	parent: 'secure',
				url: '/Orders',
                templateUrl: 'views/orders.html',
				controller:'ordersCtrl'
            })
			.state('NewMetrics', {
                parent: 'secure',
				url: '/NewMetrics',
				templateUrl: 'views/NewMetrics.html',
				controller: 'NewMetricsCtrl'			
			})
			.state('ib/TechnoRegion', {
				parent: 'secure',
				url: '/ib/TechnoRegion',
				templateUrl: 'views/TechnoRegion.html',
				controller:'TechnoRegionController'
			})
			.state('ib/topCustomer', {
				parent: 'secure',
				url: '/ib/topCustomer',
				templateUrl: 'views/topCustomer.html',
				controller:'topCustomerCtrl'
			})
			/* IBO Routes */
			.state('ibo/technoRegion', {
				parent: 'secure',
				url: '/ibo/technoRegion',
				templateUrl: 'views/directive-html/ibo/iboSearchPage.html',
				onEnter: function($injector){
					var $state = $injector.get('$state');
					var $rootScope = $injector.get('$rootScope');
					$rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState) {
							toParams.typeRequest = 'Technology & Region';
					});				
				},
				controller: 'IBOTechnoRegionController'
			})
			.state('ibo/topCustomer', {
				parent: 'secure',
				url: '/ibo/topCustomer',
				templateUrl: 'views/directive-html/ibo/iboSearchPage.html',
				onEnter: function($injector){
					var $state = $injector.get('$state');
					var $rootScope = $injector.get('$rootScope');
					$rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState) {
							toParams.typeRequest = 'Top Customer';
					});				
				}, 
				controller: 'IBOTopCustomerCtrl'
			})
			/* Order Routes */
			.state('order/technoRegion', {
				parent: 'secure',
				url: '/order/technoRegion',
				templateUrl: 'views/orders/orderSearchPage.html',
				onEnter: function($injector){
					var $state = $injector.get('$state');
					var $rootScope = $injector.get('$rootScope');
					$rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState) {
							toParams.typeRequest = 'Technology & Region';
					});				
				},
				controller: 'OrderTechnoRegionController'
			})
			.state('order/topCustomer', {
				parent: 'secure',
				url: '/order/topCustomer',
				templateUrl: 'views/orders/orderSearchPage.html',
				onEnter: function($injector){
					var $state = $injector.get('$state');
					var $rootScope = $injector.get('$rootScope');
					$rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState) {
							toParams.typeRequest = 'Top Customer';
					});				
				}, 
				controller: 'OrderTopCustomerCtrl'
			})     
           /* DM Routes */
        .state('dm/technoRegion', {
			parent: 'secure',
			url: '/dm/technoRegion',
			templateUrl: 'views/directive-html/dmData/dmSearchPage.html',
			onEnter: function($injector){
				var $state = $injector.get('$state');
				var $rootScope = $injector.get('$rootScope');
				$rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState) {
						toParams.typeRequest = 'Region';
				});				
			},
			controller: 'DMTechnoRegionController'
		})
		.state('DealMachinesData', {
                url: '/DealMachinesData',
                templateUrl: 'views/directive-html/dmData/dealMachinesData.html',                
				controller: 'dealMachinesDataCtrl'
            })
		.state('dm/topCustomer', {
			parent: 'secure',
			url: '/dm/topCustomer',
			templateUrl: 'views/directive-html/dmData/dmSearchPage.html',
			onEnter: function($injector){
				var $state = $injector.get('$state');
				var $rootScope = $injector.get('$rootScope');
				$rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState) {
						toParams.typeRequest = 'Top Customer';
				});				
			}, 
			controller: 'DMTopCustomerCtrl'
		})        
        /* Outage Routes */
        .state('outage/technoRegion', {
			parent: 'secure',
			url: '/outage/technoRegion',
			templateUrl: 'views/directive-html/Outage/outageSearchPage.html',
			onEnter: function($injector){
				var $state = $injector.get('$state');
				var $rootScope = $injector.get('$rootScope');
				$rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState) {
						toParams.typeRequest = 'Region';
				});				
			},
			controller: 'OutageTechnoRegionController'
		})
		.state('outage/topCustomer', {
			parent: 'secure',
			url: '/outage/topCustomer',
			templateUrl: 'views/directive-html/Outage/outageSearchPage.html',
			onEnter: function($injector){
				var $state = $injector.get('$state');
				var $rootScope = $injector.get('$rootScope');
				$rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState) {
						toParams.typeRequest = 'Top Customer';
				});				
			}, 
			controller: 'OutageTopCustomerCtrl'
		
		})
		
		   /* ServiceReq Routes */
        .state('serviceReq/technology', {
			parent: 'secure',
			url: '/serviceReq/technology',
			templateUrl: 'views/directive-html/serviceReqData/serviceReqSearchPage.html',
			onEnter: function($injector){
				var $state = $injector.get('$state');
				var $rootScope = $injector.get('$rootScope');
				$rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState) {
						toParams.typeRequest = 'Technology';
				});				
			},
			controller: 'ServiceReqTechnoRegionController'
		})
		.state('serviceReq/topCustomer', {
			parent: 'secure',
			url: '/serviceReq/topCustomer',
			templateUrl: 'views/directive-html/serviceReqData/serviceReqSearchPage.html',
			onEnter: function($injector){
				var $state = $injector.get('$state');
				var $rootScope = $injector.get('$rootScope');
				$rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState) {
						toParams.typeRequest = 'Top Customer';
				});				
			}, 
			controller: 'ServiceReqTopCustomerCtrl'
		
		})
		
		.state('OutageData', {
			parent: 'secure',
                url: '/OutageData',
                templateUrl: 'views/directive-html/Outage/outageData.html',                
				controller: 'outageDataCtrl'
            })
        .state('ServiceReqData', {
        	parent: 'secure',
            url: '/ServiceReqData',
            templateUrl: 'views/directive-html/serviceReqData/serviceReqData.html',                
			controller: 'serviceReqDataCtrl'
        })
        .state('Authorization', {
				url: '/Authorization',
				templateUrl: 'index.html',
				onEnter: function($injector){
					var $state = $injector.get('$state');
					var $rootScope = $injector.get('$rootScope');
					$rootScope.shwAuthorizeMsg();		
				},
				controller: 'MainCtrl'			
			})
        .state('CombinedAnalysis', {
        	parent: 'secure',
			url: '/CombinedAnalysis',
			templateUrl: 'views/directive-html/combinedAnalysis/combinedAnalysisSearchPage.html',
			controller: 'combinedAnalysisCtrl'
        })
        .state('UserManual', {
        	parent: 'secure',
			url: '/UserManual',
			templateUrl: 'views/directive-html/UserManual/userManual.html',
			controller: 'userManualCtrl'
        })
        
        .state('homepage', {
            	parent: 'secure',
				url: '/homepage',
                templateUrl: 'views/homepage.html'
        })
//        .state('VariablesTable', {
//            	parent: 'secure',
//				url: '/VariablesTable',
//                templateUrl: 'views/VariablesTable.html',
//				controller:'VariablesTableCtrl'
//        })
        .state('Users', {
            	parent: 'secure',
				url: '/Users',
                templateUrl: 'views/Users.html',
				controller:'UsersCtrl'
        })
        .state('Roles', {
            	parent: 'secure',
				url: '/Roles',
                templateUrl: 'views/Roles.html',
				controller:'RolesCtrl'
        })
        .state('Documents', {
            	parent: 'secure',
				url: '/Documents',
                templateUrl: 'views/Documents.html',
				controller:'DocumentsCtrl'
        });
        
        
       $urlRouterProvider.otherwise(function ($injector) {
            var $state = $injector.get('$state');
            $state.go('homepage');
        });
 
    }]);
});
